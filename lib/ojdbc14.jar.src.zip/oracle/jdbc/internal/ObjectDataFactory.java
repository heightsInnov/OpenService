package oracle.jdbc.internal;

public abstract interface ObjectDataFactory {}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\ObjectDataFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */