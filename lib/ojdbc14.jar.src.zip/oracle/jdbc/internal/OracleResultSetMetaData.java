package oracle.jdbc.internal;

public abstract interface OracleResultSetMetaData
  extends oracle.jdbc.OracleResultSetMetaData
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\OracleResultSetMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */