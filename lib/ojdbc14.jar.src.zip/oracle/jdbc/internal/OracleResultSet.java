package oracle.jdbc.internal;

import java.sql.SQLException;

public abstract interface OracleResultSet
  extends oracle.jdbc.OracleResultSet
{
  public abstract void closeStatementOnClose()
    throws SQLException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\OracleResultSet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */