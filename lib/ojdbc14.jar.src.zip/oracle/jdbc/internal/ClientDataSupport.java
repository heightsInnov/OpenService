package oracle.jdbc.internal;

public abstract interface ClientDataSupport
{
  public abstract Object getClientData(Object paramObject);
  
  public abstract Object setClientData(Object paramObject1, Object paramObject2);
  
  public abstract Object removeClientData(Object paramObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\ClientDataSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */