package oracle.jdbc.internal;

public abstract interface ObjectData {}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\ObjectData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */