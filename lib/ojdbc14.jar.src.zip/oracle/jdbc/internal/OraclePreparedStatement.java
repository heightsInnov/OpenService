package oracle.jdbc.internal;

import java.sql.SQLException;

public abstract interface OraclePreparedStatement
  extends oracle.jdbc.OraclePreparedStatement, OracleStatement
{
  public abstract void setCheckBindTypes(boolean paramBoolean);
  
  public abstract void setInternalBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
    throws SQLException;
  
  public abstract void enterImplicitCache()
    throws SQLException;
  
  public abstract void enterExplicitCache()
    throws SQLException;
  
  public abstract void exitImplicitCacheToActive()
    throws SQLException;
  
  public abstract void exitExplicitCacheToActive()
    throws SQLException;
  
  public abstract void exitImplicitCacheToClose()
    throws SQLException;
  
  public abstract void exitExplicitCacheToClose()
    throws SQLException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\OraclePreparedStatement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */