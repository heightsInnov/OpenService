package oracle.jdbc.internal;

import java.sql.SQLException;

public abstract interface OracleCallableStatement
  extends oracle.jdbc.OracleCallableStatement, OraclePreparedStatement
{
  public abstract byte[] privateGetBytes(int paramInt)
    throws SQLException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\internal\OracleCallableStatement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */