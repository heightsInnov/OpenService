/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ import oracle.jdbc.driver.OracleConnection;
/*     */ import oracle.jdbc.driver.OracleDatabaseMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnectionMetaData
/*     */   implements ManagedConnectionMetaData
/*     */ {
/*  31 */   private OracleManagedConnection managedConnection = null;
/*  32 */   private OracleDatabaseMetaData databaseMetaData = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleManagedConnectionMetaData(OracleManagedConnection paramOracleManagedConnection)
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/*  47 */       this.managedConnection = paramOracleManagedConnection;
/*     */       
/*  49 */       OracleConnection localOracleConnection = (OracleConnection)paramOracleManagedConnection.getPhysicalConnection();
/*     */       
/*  51 */       this.databaseMetaData = ((OracleDatabaseMetaData)localOracleConnection.getMetaData());
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  55 */       EISSystemException localEISSystemException = new EISSystemException("Exception: " + localException.getMessage());
/*     */       
/*     */ 
/*  58 */       localEISSystemException.setLinkedException(localException);
/*     */       
/*  60 */       throw localEISSystemException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEISProductName()
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/*  83 */       return this.databaseMetaData.getDatabaseProductName();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*     */ 
/*     */ 
/*  91 */       EISSystemException localEISSystemException = new EISSystemException("SQLException: " + localSQLException.getMessage());
/*     */       
/*     */ 
/*  94 */       localEISSystemException.setLinkedException(localSQLException);
/*     */       
/*  96 */       throw localEISSystemException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEISProductVersion()
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/* 121 */       return this.databaseMetaData.getDatabaseProductVersion();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */ 
/* 128 */       EISSystemException localEISSystemException = new EISSystemException("Exception: " + localException.getMessage());
/*     */       
/*     */ 
/* 131 */       localEISSystemException.setLinkedException(localException);
/*     */       
/* 133 */       throw localEISSystemException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxConnections()
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/* 160 */       return this.databaseMetaData.getMaxConnections();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*     */ 
/*     */ 
/* 168 */       EISSystemException localEISSystemException = new EISSystemException("SQLException: " + localSQLException.getMessage());
/*     */       
/*     */ 
/* 171 */       localEISSystemException.setLinkedException(localSQLException);
/*     */       
/* 173 */       throw localEISSystemException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */     throws ResourceException
/*     */   {
/*     */     try
/*     */     {
/* 200 */       return this.databaseMetaData.getUserName();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*     */ 
/*     */ 
/* 208 */       EISSystemException localEISSystemException = new EISSystemException("SQLException: " + localSQLException.getMessage());
/*     */       
/*     */ 
/* 211 */       localEISSystemException.setLinkedException(localSQLException);
/*     */       
/* 213 */       throw localEISSystemException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 223 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:35_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\connector\OracleManagedConnectionMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */