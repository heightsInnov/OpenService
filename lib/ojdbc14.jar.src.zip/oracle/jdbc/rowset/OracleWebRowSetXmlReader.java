package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlReader;

public abstract interface OracleWebRowSetXmlReader
  extends XmlReader
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\rowset\OracleWebRowSetXmlReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */