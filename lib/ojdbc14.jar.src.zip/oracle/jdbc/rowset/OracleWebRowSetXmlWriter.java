package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlWriter;

public abstract interface OracleWebRowSetXmlWriter
  extends XmlWriter
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\rowset\OracleWebRowSetXmlWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */