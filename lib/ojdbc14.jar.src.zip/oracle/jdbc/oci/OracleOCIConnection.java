/*    */ package oracle.jdbc.oci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleOCIConnection
/*    */   extends oracle.jdbc.driver.OracleOCIConnection
/*    */ {
/*    */   public OracleOCIConnection(String paramString1, String paramString2, String paramString3, String paramString4, Properties paramProperties, Object paramObject)
/*    */     throws SQLException
/*    */   {
/* 38 */     super(paramString1, paramString2, paramString3, paramString4, paramProperties, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\oci\OracleOCIConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */