/*    */ package oracle.jdbc.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLStateRange
/*    */ {
/*    */   public int low;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int high;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String sqlState;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SQLStateRange(int paramInt1, int paramInt2, String paramString)
/*    */   {
/* 31 */     this.low = paramInt1;
/* 32 */     this.high = paramInt2;
/* 33 */     this.sqlState = paramString;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 38 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:34_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\util\SQLStateRange.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */