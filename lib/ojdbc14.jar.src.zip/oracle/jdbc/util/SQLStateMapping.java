/*    */ package oracle.jdbc.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLStateMapping
/*    */ {
/*    */   public int err;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String sqlState;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SQLStateMapping(int paramInt, String paramString)
/*    */   {
/* 30 */     this.err = paramInt;
/* 31 */     this.sqlState = paramString;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 36 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:34_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\util\SQLStateMapping.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */