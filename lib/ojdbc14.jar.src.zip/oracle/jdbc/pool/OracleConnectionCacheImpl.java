/*      */ package oracle.jdbc.pool;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Stack;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.Referenceable;
/*      */ import javax.naming.StringRefAddr;
/*      */ import javax.sql.ConnectionPoolDataSource;
/*      */ import javax.sql.PooledConnection;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ /**
/*      */  * @deprecated
/*      */  */
/*      */ public class OracleConnectionCacheImpl
/*      */   extends OracleDataSource
/*      */   implements OracleConnectionCache, Serializable, Referenceable
/*      */ {
/*   48 */   protected ConnectionPoolDataSource cpds = null;
/*      */   
/*   50 */   protected static int _DEFAULT_MIN_LIMIT = 0;
/*      */   
/*      */ 
/*   53 */   protected static int _DEFAULT_MAX_LIMIT = Integer.MAX_VALUE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   58 */   protected int _MIN_LIMIT = _DEFAULT_MIN_LIMIT;
/*   59 */   protected int _MAX_LIMIT = _DEFAULT_MAX_LIMIT;
/*      */   
/*      */   protected static final int DEFAULT_CACHE_TIMEOUT = -1;
/*      */   
/*      */   protected static final int DEFAULT_THREAD_INTERVAL = 900;
/*      */   
/*      */   public static final int ORAERROR_END_OF_FILE_ON_COCHANNEL = 3113;
/*      */   
/*      */   public static final int ORAERROR_NOT_CONNECTED_TO_ORACLE = 3114;
/*      */   
/*      */   public static final int ORAERROR_INIT_SHUTDOWN_IN_PROGRESS = 1033;
/*      */   public static final int ORAERROR_ORACLE_NOT_AVAILABLE = 1034;
/*      */   public static final int ORAERROR_IMMEDIATE_SHUTDOWN_IN_PROGRESS = 1089;
/*      */   public static final int ORAERROR_SHUTDOWN_IN_PROGRESS_NO_CONN = 1090;
/*      */   public static final int ORAERROR_NET_IO_EXCEPTION = 17002;
/*   74 */   protected long cacheTTLTimeOut = -1L;
/*   75 */   protected long cacheInactivityTimeOut = -1L;
/*   76 */   protected long cacheFixedWaitTimeOut = -1L;
/*   77 */   protected long threadInterval = 900L;
/*      */   
/*      */ 
/*   80 */   Stack cache = new Stack();
/*   81 */   Hashtable activeCache = new Hashtable(50);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   89 */   private Object CACHE_SIZE_LOCK = new String("");
/*   90 */   protected int cacheSize = 0;
/*   91 */   protected int activeSize = 0;
/*      */   
/*      */   protected int cacheScheme;
/*      */   
/*   95 */   protected long cleanupInterval = 30L;
/*   96 */   protected int[] fatalErrorCodes = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long DEFAULT_FIXED_WAIT_IDLE_TIME = 30L;
/*      */   
/*      */ 
/*      */ 
/*  105 */   protected long fixedWaitIdleTime = -1L;
/*      */   
/*      */   public static final int DYNAMIC_SCHEME = 1;
/*      */   
/*      */   public static final int FIXED_WAIT_SCHEME = 2;
/*      */   
/*      */   public static final int FIXED_RETURN_NULL_SCHEME = 3;
/*  112 */   protected OracleConnectionEventListener ocel = null;
/*      */   
/*      */ 
/*  115 */   protected int stmtCacheSize = 0;
/*  116 */   protected boolean stmtClearMetaData = false;
/*      */   
/*      */ 
/*  119 */   protected OracleConnectionCacheTimeOutThread timeOutThread = null;
/*      */   
/*      */ 
/*  122 */   SQLWarning warning = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public OracleConnectionCacheImpl()
/*      */     throws SQLException
/*      */   {
/*  142 */     this(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public OracleConnectionCacheImpl(ConnectionPoolDataSource paramConnectionPoolDataSource)
/*      */     throws SQLException
/*      */   {
/*  170 */     this.cacheScheme = 1;
/*      */     
/*      */ 
/*  173 */     this.cpds = paramConnectionPoolDataSource;
/*      */     
/*      */ 
/*  176 */     this.ocel = new OracleConnectionEventListener(this);
/*      */     
/*      */ 
/*  179 */     this.dataSourceName = "OracleConnectionCacheImpl";
/*  180 */     this.isOracleDataSource = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setConnectionPoolDataSource(ConnectionPoolDataSource paramConnectionPoolDataSource)
/*      */     throws SQLException
/*      */   {
/*  213 */     if (this.cacheSize > 0) {
/*  214 */       DatabaseError.throwSqlException(78);
/*      */     }
/*  216 */     this.cpds = paramConnectionPoolDataSource;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*  237 */     return getConnection(this.user, this.password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Connection getConnection(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/*  257 */     Connection localConnection = null;
/*      */     
/*  259 */     PooledConnection localPooledConnection = getPooledConnection(paramString1, paramString2);
/*      */     
/*  261 */     if (localPooledConnection != null)
/*      */     {
/*      */ 
/*      */ 
/*  265 */       localConnection = localPooledConnection.getConnection();
/*      */     }
/*      */     
/*      */ 
/*  269 */     if (localConnection != null) {
/*  270 */       ((OracleConnection)localConnection).setStartTime(System.currentTimeMillis());
/*      */     }
/*  272 */     return localConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PooledConnection getPooledConnection(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/*  282 */     PooledConnection localPooledConnection = null;
/*  283 */     int i = 0;
/*  284 */     int j = 0;
/*  285 */     long l = Long.MAX_VALUE;
/*  286 */     Properties localProperties = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  291 */     synchronized (this)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  301 */       if (!this.cache.empty())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */         checkCredentials(paramString1, paramString2);
/*      */         
/*  310 */         localPooledConnection = removeConnectionFromCache();
/*      */       }
/*  312 */       else if ((this.cacheSize < this._MAX_LIMIT) || (this.cacheScheme == 1))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */         String str1 = null;
/*  321 */         String str2 = null;
/*      */         
/*  323 */         if (this.cpds != null)
/*      */         {
/*  325 */           str1 = ((OracleConnectionPoolDataSource)this.cpds).getUser();
/*  326 */           str2 = ((OracleConnectionPoolDataSource)this.cpds).getPassword();
/*      */         }
/*      */         
/*      */ 
/*  330 */         if ((this.cacheSize > 0) && (paramString1 != null) && (!paramString1.equalsIgnoreCase(str1)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  337 */           DatabaseError.throwSqlException(79);
/*      */         }
/*      */         
/*  340 */         if ((this.cacheSize > 0) && (paramString2 != null) && (!paramString2.equalsIgnoreCase(str2)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  347 */           DatabaseError.throwSqlException(79);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  352 */         i = 1;
/*  353 */         localProperties = new Properties();
/*  354 */         if (this.url != null)
/*  355 */           localProperties.setProperty("connection_url", this.url);
/*  356 */         if (this.user != null) {
/*  357 */           localProperties.setProperty("user", this.user);
/*  358 */         } else if ((this.cpds != null) && (((OracleDataSource)this.cpds).user != null)) {
/*  359 */           localProperties.setProperty("user", ((OracleDataSource)this.cpds).user);
/*      */         }
/*  361 */         if (this.password != null) {
/*  362 */           localProperties.setProperty("password", this.password);
/*  363 */         } else if ((this.cpds != null) && (((OracleDataSource)this.cpds).password != null)) {
/*  364 */           localProperties.setProperty("password", ((OracleDataSource)this.cpds).password);
/*      */         }
/*  366 */         if ((this.stmtCacheSize == 0) && (this.cpds != null) && (((OracleDataSource)this.cpds).maxStatements != 0))
/*      */         {
/*      */ 
/*  369 */           localProperties.setProperty("stmt_cache_size", "" + ((OracleDataSource)this.cpds).maxStatements);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  374 */           localProperties.setProperty("stmt_cache_size", "" + this.stmtCacheSize);
/*      */           
/*  376 */           localProperties.setProperty("stmt_cache_clear_metadata", "" + this.stmtClearMetaData);
/*      */           
/*  378 */           localProperties.setProperty("ImplicitStatementCachingEnabled", "" + this.implicitCachingEnabled);
/*      */           
/*  380 */           localProperties.setProperty("ExplicitStatementCachingEnabled", "" + this.explicitCachingEnabled);
/*      */         }
/*      */         
/*  383 */         if (this.loginTimeout != 0) {
/*  384 */           localProperties.setProperty("LoginTimeout", "" + this.loginTimeout);
/*      */         }
/*  386 */         synchronized (this.CACHE_SIZE_LOCK) {
/*  387 */           this.cacheSize += 1;
/*      */         }
/*  389 */         if (this.cpds == null)
/*      */         {
/*  391 */           initializeConnectionPoolDataSource();
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  400 */       else if (this.cacheScheme != 3)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  409 */         checkCredentials(paramString1, paramString2);
/*      */         
/*      */ 
/*  412 */         l = System.currentTimeMillis();
/*  413 */         j = 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  419 */     if (i != 0)
/*      */     {
/*      */       try
/*      */       {
/*  423 */         localPooledConnection = getNewPoolOrXAConnection(localProperties);
/*      */       }
/*      */       catch (SQLException ???) {
/*  426 */         synchronized (this.CACHE_SIZE_LOCK)
/*      */         {
/*  428 */           this.cacheSize -= 1;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  434 */         throw ((Throwable)???);
/*      */       }
/*      */     }
/*      */     else {
/*  438 */       if (j != 0)
/*      */       {
/*  440 */         while ((localPooledConnection == null) && (this.cache.empty()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  445 */           synchronized (this)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */             if ((this.cacheFixedWaitTimeOut > 0L) && (System.currentTimeMillis() - l > this.cacheFixedWaitTimeOut * 1000L))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  461 */               DatabaseError.throwSqlException(126);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  467 */           synchronized (this.cache)
/*      */           {
/*      */             try
/*      */             {
/*  471 */               this.cache.wait((this.fixedWaitIdleTime == -1L ? 30L : this.fixedWaitIdleTime) * 1000L);
/*      */             }
/*      */             catch (InterruptedException localInterruptedException) {}
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  484 */             if (!this.cache.empty()) {
/*  485 */               localPooledConnection = removeConnectionFromCache();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  492 */       if ((localPooledConnection != null) && (this.stmtCacheSize > 0))
/*      */       {
/*      */ 
/*  495 */         if ((!this.explicitCachingEnabled) && (!this.implicitCachingEnabled))
/*      */         {
/*  497 */           ((OraclePooledConnection)localPooledConnection).setStmtCacheSize(this.stmtCacheSize);
/*      */         }
/*      */         else {
/*  500 */           ((OraclePooledConnection)localPooledConnection).setStatementCacheSize(this.stmtCacheSize);
/*  501 */           ((OraclePooledConnection)localPooledConnection).setExplicitCachingEnabled(this.explicitCachingEnabled);
/*      */           
/*  503 */           ((OraclePooledConnection)localPooledConnection).setImplicitCachingEnabled(this.implicitCachingEnabled);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  509 */     if (localPooledConnection != null)
/*      */     {
/*  511 */       if (i == 0)
/*      */       {
/*      */ 
/*  514 */         ((OraclePooledConnection)localPooledConnection).physicalConn.setDefaultRowPrefetch(10);
/*  515 */         ((OraclePooledConnection)localPooledConnection).physicalConn.setDefaultExecuteBatch(1);
/*      */       }
/*      */       
/*      */ 
/*  519 */       localPooledConnection.addConnectionEventListener(this.ocel);
/*      */       
/*      */ 
/*  522 */       this.activeCache.put(localPooledConnection, localPooledConnection);
/*      */       
/*  524 */       synchronized (this)
/*      */       {
/*  526 */         this.activeSize = this.activeCache.size();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  536 */     return localPooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PooledConnection getNewPoolOrXAConnection(Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  547 */     PooledConnection localPooledConnection = ((OracleConnectionPoolDataSource)this.cpds).getPooledConnection(paramProperties);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  553 */     return localPooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void reusePooledConnection(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/*  574 */     detachSingleConnection(paramPooledConnection);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  580 */     if ((this.cache.size() >= this._MAX_LIMIT) && (this.cacheScheme == 1))
/*      */     {
/*  582 */       closeSingleConnection(paramPooledConnection, false);
/*      */     } else {
/*  584 */       putConnectionToCache(paramPooledConnection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void closePooledConnection(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/*  606 */     detachSingleConnection(paramPooledConnection);
/*      */     
/*      */ 
/*  609 */     closeSingleConnection(paramPooledConnection, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void detachSingleConnection(PooledConnection paramPooledConnection)
/*      */   {
/*  622 */     paramPooledConnection.removeConnectionEventListener(this.ocel);
/*      */     
/*      */ 
/*  625 */     this.activeCache.remove(paramPooledConnection);
/*      */     
/*      */ 
/*  628 */     this.activeSize = this.activeCache.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void closeSingleConnection(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/*  645 */     closeSingleConnection(paramPooledConnection, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void closeSingleConnection(PooledConnection paramPooledConnection, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  655 */     if ((!removeConnectionFromCache(paramPooledConnection)) && (paramBoolean)) {
/*  656 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  662 */       paramPooledConnection.close();
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/*      */ 
/*  668 */       this.warning = DatabaseError.addSqlWarning(this.warning, new SQLWarning(localSQLException.getMessage()));
/*      */     }
/*      */     
/*      */ 
/*  672 */     synchronized (this.CACHE_SIZE_LOCK)
/*      */     {
/*      */ 
/*      */ 
/*  676 */       this.cacheSize -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/*  702 */     closeConnections();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  709 */     this.cache = null;
/*  710 */     this.activeCache = null;
/*  711 */     this.ocel = null;
/*  712 */     this.cpds = null;
/*  713 */     this.timeOutThread = null;
/*      */     
/*  715 */     clearWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeConnections()
/*      */   {
/*  732 */     Enumeration localEnumeration = this.activeCache.keys();
/*      */     
/*  734 */     while (localEnumeration.hasMoreElements())
/*      */     {
/*      */       try
/*      */       {
/*  738 */         OraclePooledConnection localOraclePooledConnection2 = (OraclePooledConnection)localEnumeration.nextElement();
/*  739 */         OraclePooledConnection localOraclePooledConnection1 = (OraclePooledConnection)this.activeCache.get(localOraclePooledConnection2);
/*      */         
/*  741 */         if (localOraclePooledConnection1 != null)
/*      */         {
/*      */ 
/*  744 */           OracleConnection localOracleConnection = (OracleConnection)localOraclePooledConnection1.getLogicalHandle();
/*      */           
/*      */ 
/*      */ 
/*  748 */           localOracleConnection.close();
/*      */         }
/*      */       }
/*      */       catch (Exception localException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  760 */     while (!this.cache.empty())
/*      */     {
/*      */       try
/*      */       {
/*  764 */         closeSingleConnection((PooledConnection)this.cache.peek(), false);
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setConnectionCleanupInterval(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  795 */     if (paramLong > 0L) {
/*  796 */       this.cleanupInterval = paramLong;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getConnectionCleanupInterval()
/*      */     throws SQLException
/*      */   {
/*  812 */     return this.cleanupInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setConnectionErrorCodes(int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/*  828 */     if (paramArrayOfInt != null) {
/*  829 */       paramArrayOfInt = paramArrayOfInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getConnectionErrorCodes()
/*      */     throws SQLException
/*      */   {
/*  845 */     return this.fatalErrorCodes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFatalConnectionError(SQLException paramSQLException)
/*      */   {
/*  862 */     if (this.cleanupInterval < 0L) {
/*  863 */       return false;
/*      */     }
/*  865 */     boolean bool = false;
/*  866 */     int i = paramSQLException.getErrorCode();
/*      */     
/*      */ 
/*  869 */     if ((i == 3113) || (i == 3114) || (i == 1033) || (i == 1034) || (i == 1089) || (i == 1090) || (i == 17002))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  877 */       bool = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  883 */     else if (this.fatalErrorCodes != null)
/*      */     {
/*  885 */       for (int j = 0; j < this.fatalErrorCodes.length; j++) {
/*  886 */         if (i == this.fatalErrorCodes[j]) {
/*  887 */           bool = true;
/*      */         }
/*      */       }
/*      */     }
/*  891 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setMinLimit(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  907 */     if ((paramInt < 0) || (paramInt > this._MAX_LIMIT)) {
/*  908 */       DatabaseError.throwSqlException(68);
/*      */     }
/*  910 */     this._MIN_LIMIT = paramInt;
/*  911 */     if (this.cpds == null)
/*      */     {
/*  913 */       initializeConnectionPoolDataSource();
/*      */     }
/*      */     
/*  916 */     if (this.cacheSize < this._MIN_LIMIT)
/*      */     {
/*  918 */       Properties localProperties = new Properties();
/*  919 */       if (this.url != null)
/*  920 */         localProperties.setProperty("connection_url", this.url);
/*  921 */       if (this.user != null)
/*  922 */         localProperties.setProperty("user", this.user);
/*  923 */       if (this.password != null) {
/*  924 */         localProperties.setProperty("password", this.password);
/*      */       }
/*  926 */       if ((this.stmtCacheSize == 0) && (this.maxStatements != 0))
/*      */       {
/*  928 */         localProperties.setProperty("stmt_cache_size", "" + this.maxStatements);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  933 */         localProperties.setProperty("stmt_cache_size", "" + this.stmtCacheSize);
/*  934 */         localProperties.setProperty("stmt_cache_clear_metadata", "" + this.stmtClearMetaData);
/*      */         
/*  936 */         localProperties.setProperty("ImplicitStatementCachingEnabled", "" + this.implicitCachingEnabled);
/*      */         
/*  938 */         localProperties.setProperty("ExplicitStatementCachingEnabled", "" + this.explicitCachingEnabled);
/*      */       }
/*      */       
/*  941 */       localProperties.setProperty("LoginTimeout", "" + this.loginTimeout);
/*      */       
/*      */ 
/*  944 */       for (int i = this.cacheSize; i < this._MIN_LIMIT; i++)
/*      */       {
/*  946 */         PooledConnection localPooledConnection = getNewPoolOrXAConnection(localProperties);
/*  947 */         putConnectionToCache(localPooledConnection);
/*      */       }
/*      */       
/*  950 */       this.cacheSize = this._MIN_LIMIT;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeConnectionPoolDataSource()
/*      */     throws SQLException
/*      */   {
/*  962 */     if (this.cpds == null)
/*      */     {
/*      */ 
/*  965 */       if ((this.user == null) || (this.password == null)) {
/*  966 */         DatabaseError.throwSqlException(79);
/*      */       }
/*  968 */       this.cpds = new OracleConnectionPoolDataSource();
/*      */       
/*  970 */       copy((OracleDataSource)this.cpds);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getMinLimit()
/*      */   {
/*  986 */     return this._MIN_LIMIT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setMaxLimit(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1002 */     if ((paramInt < 0) || (paramInt < this._MIN_LIMIT)) {
/* 1003 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 1005 */     this._MAX_LIMIT = paramInt;
/*      */     
/* 1007 */     if ((this.cacheSize > this._MAX_LIMIT) && (this.cacheScheme != 1))
/*      */     {
/* 1009 */       for (int i = this._MAX_LIMIT; i < this.cacheSize; i++)
/*      */       {
/* 1011 */         if (this.cache.empty()) {
/* 1012 */           DatabaseError.throwSqlException(78);
/*      */         } else {
/* 1014 */           removeConnectionFromCache().close();
/*      */         }
/*      */       }
/* 1017 */       this.cacheSize = this._MAX_LIMIT;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getMaxLimit()
/*      */   {
/* 1038 */     return this._MAX_LIMIT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getCacheScheme()
/*      */   {
/* 1054 */     return this.cacheScheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheScheme(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1073 */     if ((paramInt == 1) || (paramInt == 3) || (paramInt == 2))
/*      */     {
/*      */ 
/* 1076 */       this.cacheScheme = paramInt;
/*      */       
/* 1078 */       return;
/*      */     }
/*      */     
/* 1081 */     DatabaseError.throwSqlException(68);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheScheme(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1100 */     if (paramString.equalsIgnoreCase("DYNAMIC_SCHEME")) {
/* 1101 */       this.cacheScheme = 1;
/* 1102 */     } else if (paramString.equalsIgnoreCase("FIXED_RETURN_NULL_SCHEME")) {
/* 1103 */       this.cacheScheme = 3;
/* 1104 */     } else if (paramString.equalsIgnoreCase("FIXED_WAIT_SCHEME")) {
/* 1105 */       this.cacheScheme = 2;
/*      */     } else {
/* 1107 */       DatabaseError.throwSqlException(68);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getActiveSize()
/*      */   {
/* 1125 */     return this.activeSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getCacheSize()
/*      */   {
/* 1141 */     return this.cacheSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheTimeToLiveTimeout(long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1162 */     if (this.timeOutThread == null) {
/* 1163 */       this.timeOutThread = new OracleConnectionCacheTimeOutThread(this);
/*      */     }
/*      */     
/*      */ 
/* 1167 */     if (paramLong <= 0L)
/*      */     {
/* 1169 */       this.cacheTTLTimeOut = -1L;
/* 1170 */       this.warning = DatabaseError.addSqlWarning(this.warning, 111);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1176 */       this.cacheTTLTimeOut = paramLong;
/*      */       
/* 1178 */       checkAndStartTimeOutThread();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheInactivityTimeout(long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1200 */     if (this.timeOutThread == null) {
/* 1201 */       this.timeOutThread = new OracleConnectionCacheTimeOutThread(this);
/*      */     }
/*      */     
/*      */ 
/* 1205 */     if (paramLong <= 0L)
/*      */     {
/* 1207 */       this.cacheInactivityTimeOut = -1L;
/* 1208 */       this.warning = DatabaseError.addSqlWarning(this.warning, 124);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1214 */       this.cacheInactivityTimeOut = paramLong;
/*      */       
/* 1216 */       checkAndStartTimeOutThread();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheFixedWaitTimeout(long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1238 */     if (paramLong <= 0L)
/*      */     {
/* 1240 */       this.cacheFixedWaitTimeOut = -1L;
/* 1241 */       this.warning = DatabaseError.addSqlWarning(this.warning, 127);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1247 */       this.cacheFixedWaitTimeOut = paramLong;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public long getCacheTimeToLiveTimeout()
/*      */     throws SQLException
/*      */   {
/* 1266 */     return this.cacheTTLTimeOut;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public long getCacheInactivityTimeout()
/*      */     throws SQLException
/*      */   {
/* 1284 */     return this.cacheInactivityTimeOut;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public long getCacheFixedWaitTimeout()
/*      */     throws SQLException
/*      */   {
/* 1302 */     return this.cacheFixedWaitTimeOut;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setThreadWakeUpInterval(long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1323 */     if (paramLong <= 0L)
/*      */     {
/* 1325 */       this.threadInterval = 900L;
/* 1326 */       this.warning = DatabaseError.addSqlWarning(this.warning, 112);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1332 */       this.threadInterval = paramLong;
/*      */     }
/*      */     
/*      */ 
/* 1336 */     if (((this.cacheTTLTimeOut > 0L) && (this.threadInterval > this.cacheTTLTimeOut)) || ((this.cacheInactivityTimeOut > 0L) && (this.threadInterval > this.cacheInactivityTimeOut)))
/*      */     {
/*      */ 
/*      */ 
/* 1340 */       this.warning = DatabaseError.addSqlWarning(this.warning, 113);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public long getThreadWakeUpInterval()
/*      */     throws SQLException
/*      */   {
/* 1361 */     return this.threadInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkAndStartTimeOutThread()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1377 */       if (!this.timeOutThread.isAlive())
/*      */       {
/* 1379 */         this.timeOutThread.setDaemon(true);
/* 1380 */         this.timeOutThread.start();
/*      */       }
/*      */     }
/*      */     catch (IllegalThreadStateException localIllegalThreadStateException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 1402 */     return this.warning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/* 1416 */     this.warning = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void checkCredentials(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 1429 */     String str1 = null;
/* 1430 */     String str2 = null;
/*      */     
/* 1432 */     if (this.cpds != null)
/*      */     {
/* 1434 */       str1 = ((OracleConnectionPoolDataSource)this.cpds).getUser();
/* 1435 */       str2 = ((OracleConnectionPoolDataSource)this.cpds).getPassword();
/*      */     }
/*      */     
/* 1438 */     if (((paramString1 != null) && (!paramString1.equals(str1))) || ((paramString2 != null) && (!paramString2.equals(str2))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1444 */       DatabaseError.throwSqlException(79);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Reference getReference()
/*      */     throws NamingException
/*      */   {
/* 1459 */     Reference localReference = new Reference(getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1464 */     super.addRefProperties(localReference);
/*      */     
/* 1466 */     if (this._MIN_LIMIT != _DEFAULT_MIN_LIMIT) {
/* 1467 */       localReference.add(new StringRefAddr("minLimit", Integer.toString(this._MIN_LIMIT)));
/*      */     }
/* 1469 */     if (this._MAX_LIMIT != _DEFAULT_MAX_LIMIT) {
/* 1470 */       localReference.add(new StringRefAddr("maxLimit", Integer.toString(this._MAX_LIMIT)));
/*      */     }
/* 1472 */     if (this.cacheScheme != 1) {
/* 1473 */       localReference.add(new StringRefAddr("cacheScheme", Integer.toString(this.cacheScheme)));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1479 */     return localReference;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setStmtCacheSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1506 */     setStmtCacheSize(paramInt, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1535 */     if (paramInt < 0) {
/* 1536 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 1538 */     this.stmtCacheSize = paramInt;
/* 1539 */     this.stmtClearMetaData = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int getStmtCacheSize()
/*      */   {
/* 1555 */     return this.stmtCacheSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized boolean isStmtCacheEnabled()
/*      */   {
/* 1568 */     if (this.stmtCacheSize > 0) {
/* 1569 */       return true;
/*      */     }
/* 1571 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void putConnectionToCache(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1591 */     ((OraclePooledConnection)paramPooledConnection).setLastAccessedTime(System.currentTimeMillis());
/* 1592 */     this.cache.push(paramPooledConnection);
/*      */     
/*      */ 
/* 1595 */     synchronized (this.cache)
/*      */     {
/* 1597 */       this.cache.notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PooledConnection removeConnectionFromCache()
/*      */     throws SQLException
/*      */   {
/* 1610 */     return (PooledConnection)this.cache.pop();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean removeConnectionFromCache(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1623 */     return this.cache.removeElement(paramPooledConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized void setCacheFixedWaitIdleTime(long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1649 */     if (this.cacheScheme == 2)
/*      */     {
/* 1651 */       if (paramLong <= 0L)
/*      */       {
/* 1653 */         DatabaseError.addSqlWarning(this.warning, 68);
/*      */         
/*      */ 
/* 1656 */         this.fixedWaitIdleTime = 30L;
/*      */       }
/*      */       else {
/* 1659 */         this.fixedWaitIdleTime = paramLong;
/*      */       }
/*      */     } else {
/* 1662 */       DatabaseError.addSqlWarning(this.warning, new SQLWarning("Caching scheme is not FIXED_WAIT_SCHEME"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public long getCacheFixedWaitIdleTime()
/*      */     throws SQLException
/*      */   {
/* 1681 */     return this.fixedWaitIdleTime == -1L ? 30L : this.fixedWaitIdleTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1692 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */   public static final boolean PRIVATE_TRACE = false;
/*      */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:33_PST_2006";
/*      */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\pool\OracleConnectionCacheImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */