/*    */ package oracle.jdbc.pool;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OracleConnectionCacheEntry
/*    */ {
/* 24 */   Vector userConnList = null;
/* 25 */   HashMap attrConnMap = null;
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\pool\OracleConnectionCacheEntry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */