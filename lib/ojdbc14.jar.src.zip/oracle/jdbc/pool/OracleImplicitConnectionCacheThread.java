/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleImplicitConnectionCacheThread
/*     */   extends Thread
/*     */ {
/*  31 */   private OracleImplicitConnectionCache implicitCache = null;
/*  32 */   protected boolean timeToLive = true;
/*  33 */   protected boolean isSleeping = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache)
/*     */     throws SQLException
/*     */   {
/*  41 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*  50 */     long l1 = 0L;
/*  51 */     long l2 = 0L;
/*  52 */     long l3 = 0L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */     while (this.timeToLive)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*  66 */         if ((this.timeToLive) && ((l1 = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L))
/*     */         {
/*     */ 
/*  69 */           runTimeToLiveTimeout(l1);
/*     */         }
/*     */         
/*     */ 
/*  73 */         if ((this.timeToLive) && ((l2 = this.implicitCache.getCacheInactivityTimeout()) > 0L))
/*     */         {
/*  75 */           runInactivityTimeout();
/*     */         }
/*     */         
/*     */ 
/*  79 */         if ((this.timeToLive) && ((l3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L))
/*     */         {
/*  81 */           runAbandonedTimeout(l3);
/*     */         }
/*     */         
/*     */ 
/*  85 */         if (this.timeToLive)
/*     */         {
/*  87 */           this.isSleeping = true;
/*     */           
/*     */           try
/*     */           {
/*  91 */             sleep(this.implicitCache.getCachePropertyCheckInterval() * 1000);
/*     */           }
/*     */           catch (InterruptedException localInterruptedException) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */           this.isSleeping = false;
/*     */         }
/*     */         
/*     */ 
/* 104 */         if ((this.implicitCache == null) || ((l1 <= 0L) && (l2 <= 0L) && (l3 <= 0L)))
/*     */         {
/*     */ 
/* 107 */           this.timeToLive = false;
/*     */         }
/*     */       }
/*     */       catch (SQLException localSQLException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runTimeToLiveTimeout(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 123 */     long l1 = 0L;
/* 124 */     long l2 = 0L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0)
/*     */     {
/* 132 */       OraclePooledConnection localOraclePooledConnection = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 137 */       synchronized (this.implicitCache)
/*     */       {
/*     */ 
/*     */ 
/* 141 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/* 142 */         int i = this.implicitCache.checkedOutConnectionList.size();
/*     */         
/* 144 */         for (int j = 0; j < i; j++)
/*     */         {
/* 146 */           localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[j];
/*     */           
/* 148 */           Connection localConnection = localOraclePooledConnection.getLogicalHandle();
/*     */           
/* 150 */           if (localConnection != null)
/*     */           {
/* 152 */             l2 = ((OracleConnection)localConnection).getStartTime();
/*     */             
/* 154 */             l1 = System.currentTimeMillis();
/*     */             
/*     */ 
/* 157 */             if (l1 - l2 > paramLong * 1000L)
/*     */             {
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/* 165 */                 this.implicitCache.closeCheckedOutConnection(localOraclePooledConnection, true);
/*     */               }
/*     */               catch (SQLException localSQLException) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runInactivityTimeout()
/*     */   {
/*     */     try
/*     */     {
/* 187 */       this.implicitCache.doForEveryCachedConnection(4);
/*     */     }
/*     */     catch (SQLException localSQLException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runAbandonedTimeout(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 206 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0)
/*     */     {
/* 208 */       OraclePooledConnection localOraclePooledConnection = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 213 */       synchronized (this.implicitCache)
/*     */       {
/* 215 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/*     */         
/*     */ 
/* 218 */         for (int i = 0; i < arrayOfObject.length; i++)
/*     */         {
/* 220 */           localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[i];
/*     */           
/* 222 */           OracleConnection localOracleConnection = (OracleConnection)localOraclePooledConnection.getLogicalHandle();
/*     */           
/* 224 */           if (localOracleConnection != null)
/*     */           {
/*     */ 
/*     */ 
/* 228 */             OracleConnectionCacheCallback localOracleConnectionCacheCallback = localOracleConnection.getConnectionCacheCallbackObj();
/*     */             
/*     */ 
/* 231 */             if ((localOracleConnectionCacheCallback != null) && ((localOracleConnection.getConnectionCacheCallbackFlag() == 4) || (localOracleConnection.getConnectionCacheCallbackFlag() == 1)))
/*     */             {
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/* 238 */                 localOracleConnectionCacheCallback.handleAbandonedConnection(localOracleConnection, localOracleConnection.getConnectionCacheCallbackPrivObj());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               }
/*     */               catch (SQLException localSQLException1) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             }
/* 252 */             else if (localOracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval() > paramLong)
/*     */             {
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 261 */                 this.implicitCache.closeCheckedOutConnection(localOraclePooledConnection, true);
/*     */               }
/*     */               catch (SQLException localSQLException2) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:33_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\pool\OracleImplicitConnectionCacheThread.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */