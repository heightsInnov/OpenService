package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public abstract interface OracleConnectionCacheCallback
{
  public abstract boolean handleAbandonedConnection(OracleConnection paramOracleConnection, Object paramObject);
  
  public abstract void releaseConnection(OracleConnection paramOracleConnection, Object paramObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\pool\OracleConnectionCacheCallback.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */