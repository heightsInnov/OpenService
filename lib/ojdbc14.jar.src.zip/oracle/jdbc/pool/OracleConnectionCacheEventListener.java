/*    */ package oracle.jdbc.pool;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.ConnectionEvent;
/*    */ import javax.sql.ConnectionEventListener;
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OracleConnectionCacheEventListener
/*    */   implements ConnectionEventListener, Serializable
/*    */ {
/*    */   static final int CONNECTION_CLOSED_EVENT = 101;
/*    */   static final int CONNECTION_ERROROCCURED_EVENT = 102;
/* 39 */   protected OracleImplicitConnectionCache implicitCache = null;
/*    */   
/*    */ 
/*    */   public OracleConnectionCacheEventListener()
/*    */   {
/* 44 */     this(null);
/*    */   }
/*    */   
/*    */ 
/*    */   public OracleConnectionCacheEventListener(OracleImplicitConnectionCache paramOracleImplicitConnectionCache)
/*    */   {
/* 50 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized void connectionClosed(ConnectionEvent paramConnectionEvent)
/*    */   {
/*    */     try
/*    */     {
/* 69 */       if (this.implicitCache != null)
/*    */       {
/* 71 */         this.implicitCache.reusePooledConnection((PooledConnection)paramConnectionEvent.getSource());
/*    */       }
/*    */     }
/*    */     catch (SQLException localSQLException) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized void connectionErrorOccurred(ConnectionEvent paramConnectionEvent)
/*    */   {
/*    */     try
/*    */     {
/* 89 */       if (this.implicitCache != null)
/*    */       {
/* 91 */         this.implicitCache.closePooledConnection((PooledConnection)paramConnectionEvent.getSource());
/*    */       }
/*    */     }
/*    */     catch (SQLException localSQLException) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 99 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:33_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\pool\OracleConnectionCacheEventListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */