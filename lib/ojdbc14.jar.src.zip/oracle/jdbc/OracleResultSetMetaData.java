package oracle.jdbc;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public abstract interface OracleResultSetMetaData
  extends ResultSetMetaData
{
  public abstract boolean isNCHAR(int paramInt)
    throws SQLException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\OracleResultSetMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */