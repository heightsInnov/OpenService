package oracle.jdbc.oracore;

class NodeMapException
  extends Exception
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\oracore\NodeMapException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */