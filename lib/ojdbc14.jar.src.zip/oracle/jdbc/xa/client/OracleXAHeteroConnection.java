/*     */ package oracle.jdbc.xa.client;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import oracle.jdbc.xa.OracleXAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleXAHeteroConnection
/*     */   extends OracleXAConnection
/*     */ {
/*  37 */   private int rmid = -1;
/*  38 */   private String xaCloseString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OracleXAHeteroConnection()
/*     */     throws XAException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OracleXAHeteroConnection(Connection paramConnection)
/*     */     throws XAException
/*     */   {
/*  62 */     super(paramConnection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized XAResource getXAResource()
/*     */   {
/*     */     try
/*     */     {
/*  86 */       this.xaResource = new OracleXAHeteroResource(this.physicalConn, this);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */       ((OracleXAHeteroResource)this.xaResource).setRmid(this.rmid);
/*     */       
/*  94 */       if (this.logicalHandle != null)
/*     */       {
/*     */ 
/*     */ 
/*  98 */         ((OracleXAResource)this.xaResource).setLogicalConnection(this.logicalHandle);
/*     */       }
/*     */     }
/*     */     catch (XAException localXAException)
/*     */     {
/* 103 */       this.xaResource = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 109 */     return this.xaResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void setRmid(int paramInt)
/*     */   {
/* 126 */     this.rmid = paramInt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized int getRmid()
/*     */   {
/* 141 */     return this.rmid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void setXaCloseString(String paramString)
/*     */   {
/* 158 */     this.xaCloseString = paramString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized String getXaCloseString()
/*     */   {
/* 173 */     return this.xaCloseString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 178 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:34_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\xa\client\OracleXAHeteroConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */