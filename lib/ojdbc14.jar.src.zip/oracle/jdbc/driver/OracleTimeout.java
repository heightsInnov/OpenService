/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class OracleTimeout
/*    */ {
/*    */   static OracleTimeout newTimeout(String paramString)
/*    */     throws SQLException
/*    */   {
/* 38 */     OracleTimeoutThreadPerVM localOracleTimeoutThreadPerVM = new OracleTimeoutThreadPerVM(paramString);
/*    */     
/* 40 */     return localOracleTimeoutThreadPerVM;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 74 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:30_PST_2006";
/*    */   
/*    */   abstract void setTimeout(long paramLong, OracleStatement paramOracleStatement)
/*    */     throws SQLException;
/*    */   
/*    */   abstract void cancelTimeout()
/*    */     throws SQLException;
/*    */   
/*    */   abstract void close()
/*    */     throws SQLException;
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\OracleTimeout.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */