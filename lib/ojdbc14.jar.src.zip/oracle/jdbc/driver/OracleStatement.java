/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class OracleStatement
/*      */   implements oracle.jdbc.internal.OracleStatement, ScrollRsetStatement
/*      */ {
/*      */   static final int PLAIN_STMT = 0;
/*      */   static final int PREP_STMT = 1;
/*      */   static final int CALL_STMT = 2;
/*      */   static final byte IS_UNINITIALIZED = -1;
/*      */   static final byte IS_SELECT = 0;
/*      */   static final byte IS_PLSQL_BLOCK = 1;
/*      */   static final byte IS_DML = 2;
/*      */   static final byte IS_OTHER = 3;
/*      */   static final byte IS_CALL_BLOCK = 4;
/*      */   int cursorId;
/*      */   int numberOfDefinePositions;
/*      */   int definesBatchSize;
/*      */   Accessor[] accessors;
/*      */   int defineByteSubRange;
/*      */   int defineCharSubRange;
/*      */   int defineIndicatorSubRange;
/*      */   int defineLengthSubRange;
/*      */   byte[] defineBytes;
/*      */   char[] defineChars;
/*      */   short[] defineIndicators;
/*      */   
/*      */   abstract void doDescribe(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForDescribe()
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForRows(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void fetch()
/*      */     throws SQLException;
/*      */   
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  287 */     throw new SQLException("continueReadRow is only implemented by the T4C statements.");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  346 */   boolean described = false;
/*  347 */   boolean describedWithNames = false;
/*      */   
/*      */ 
/*      */   int rowsProcessed;
/*      */   
/*  352 */   int cachedDefineByteSize = 0;
/*  353 */   int cachedDefineCharSize = 0;
/*  354 */   int cachedDefineIndicatorSize = 0;
/*      */   
/*      */ 
/*      */   OracleStatement children;
/*      */   
/*      */ 
/*      */   OracleStatement nextChild;
/*      */   
/*      */ 
/*      */   OracleStatement next;
/*      */   
/*      */ 
/*      */   OracleStatement prev;
/*      */   
/*      */ 
/*      */   long c_state;
/*      */   
/*      */ 
/*      */   int numberOfBindPositions;
/*      */   
/*      */ 
/*      */   byte[] bindBytes;
/*      */   
/*      */ 
/*      */   char[] bindChars;
/*      */   
/*      */ 
/*      */   short[] bindIndicators;
/*      */   
/*      */   int bindByteOffset;
/*      */   
/*      */   int bindCharOffset;
/*      */   
/*      */   int bindIndicatorOffset;
/*      */   
/*      */   int bindByteSubRange;
/*      */   
/*      */   int bindCharSubRange;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   int firstRowInBatch;
/*      */   
/*  401 */   boolean hasIbtBind = false;
/*      */   
/*      */ 
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */ 
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */   int ibtBindByteOffset;
/*      */   
/*      */   int ibtBindCharOffset;
/*      */   
/*      */   int ibtBindIndicatorOffset;
/*      */   
/*      */   int ibtBindIndicatorSize;
/*      */   
/*      */   byte[] tmpByteArray;
/*      */   
/*  421 */   int sizeTmpByteArray = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */ 
/*      */ 
/*  429 */   boolean needToSendOalToFetch = false;
/*      */   
/*      */ 
/*      */ 
/*  433 */   int[] definedColumnType = null;
/*  434 */   int[] definedColumnSize = null;
/*  435 */   int[] definedColumnFormOfUse = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  441 */   T4CTTIoac[] oacdefSent = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  448 */   int[] nbPostPonedColumns = null;
/*  449 */   int[][] indexOfPostPonedColumn = (int[][])null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  470 */   int accessorByteOffset = 0;
/*  471 */   int accessorCharOffset = 0;
/*  472 */   int accessorShortOffset = 0;
/*      */   
/*      */ 
/*      */   static final int VALID_ROWS_UNINIT = -999;
/*      */   
/*      */   PhysicalConnection connection;
/*      */   
/*      */   OracleInputStream streamList;
/*      */   
/*      */   OracleInputStream nextStream;
/*      */   
/*      */   OracleResultSetImpl currentResultSet;
/*      */   
/*      */   boolean processEscapes;
/*      */   
/*      */   boolean convertNcharLiterals;
/*      */   
/*      */   int queryTimeout;
/*      */   
/*      */   int batch;
/*      */   
/*      */   int currentRank;
/*      */   
/*      */   int currentRow;
/*      */   
/*      */   int validRows;
/*      */   
/*      */   int maxFieldSize;
/*      */   
/*      */   int maxRows;
/*      */   
/*      */   int totalRowsVisited;
/*      */   
/*      */   int rowPrefetch;
/*      */   
/*  507 */   int rowPrefetchAtExecute = -1;
/*      */   
/*      */ 
/*      */ 
/*      */   int defaultRowPrefetch;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean rowPrefetchChanged;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean gotLastBatch;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean clearParameters;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean closed;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean sqlStringChanged;
/*      */   
/*      */ 
/*      */ 
/*      */   OracleSql sqlObject;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToParse;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToPrepareDefineBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean columnsDefinedByUser;
/*      */   
/*      */ 
/*      */ 
/*      */   byte sqlKind;
/*      */   
/*      */ 
/*      */ 
/*      */   int autoRollback;
/*      */   
/*      */ 
/*      */ 
/*      */   int defaultFetchDirection;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean autoRefetch;
/*      */   
/*      */ 
/*      */   boolean serverCursor;
/*      */   
/*      */ 
/*  569 */   boolean fixedString = false;
/*      */   
/*      */ 
/*  572 */   boolean noMoreUpdateCounts = false;
/*      */   
/*      */ 
/*  575 */   boolean isExecuting = false;
/*      */   
/*      */   static final byte EXECUTE_NONE = -1;
/*      */   
/*      */   static final byte EXECUTE_QUERY = 1;
/*      */   
/*      */   static final byte EXECUTE_UPDATE = 2;
/*      */   
/*      */   static final byte EXECUTE_NORMAL = 3;
/*  584 */   byte executionType = -1;
/*      */   
/*      */ 
/*      */   OracleResultSet scrollRset;
/*      */   
/*      */ 
/*      */   oracle.jdbc.OracleResultSetCache rsetCache;
/*      */   
/*      */   int userRsetType;
/*      */   
/*      */   int realRsetType;
/*      */   
/*      */   boolean needToAddIdentifier;
/*      */   
/*      */   SQLWarning sqlWarning;
/*      */   
/*  600 */   int cacheState = 1;
/*      */   
/*      */ 
/*  603 */   int creationState = 0;
/*      */   
/*  605 */   boolean isOpen = false;
/*      */   
/*      */ 
/*      */ 
/*  609 */   int statementType = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  615 */   boolean columnSetNull = false;
/*      */   
/*      */   int[] returnParamMeta;
/*      */   
/*      */   static final int DMLR_METADATA_PREFIX_SIZE = 3;
/*      */   
/*      */   static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
/*      */   
/*      */   static final int DMLR_METADATA_TYPE_OFFSET = 0;
/*      */   
/*      */   static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
/*      */   
/*      */   static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
/*      */   
/*      */   static final int DMLR_METADATA_PER_POSITION_SIZE = 3;
/*      */   
/*      */   Accessor[] returnParamAccessors;
/*      */   
/*      */   boolean returnParamsFetched;
/*      */   
/*      */   int rowsDmlReturned;
/*      */   
/*      */   int numReturnParams;
/*      */   
/*      */   byte[] returnParamBytes;
/*      */   char[] returnParamChars;
/*      */   short[] returnParamIndicators;
/*      */   int returnParamRowBytes;
/*      */   int returnParamRowChars;
/*      */   OracleReturnResultSet returnResultSet;
/*      */   boolean isAutoGeneratedKey;
/*      */   AutoKeyInfo autoKeyInfo;
/*  651 */   TimeZone defaultTZ = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int lastIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void doClose()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void closeQuery()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  681 */     this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  699 */     this.connection = paramPhysicalConnection;
/*      */     
/*  701 */     this.connection.needLine();
/*      */     
/*      */ 
/*      */ 
/*  705 */     this.connection.addStatement(this);
/*      */     
/*  707 */     this.sqlObject = new OracleSql(this.connection.conversion);
/*  708 */     this.sqlObject.isV8Compatible = this.connection.v8Compatible;
/*      */     
/*      */ 
/*      */ 
/*  712 */     this.processEscapes = this.connection.processEscapes;
/*  713 */     this.convertNcharLiterals = this.connection.convertNcharLiterals;
/*  714 */     this.autoRollback = 2;
/*  715 */     this.gotLastBatch = false;
/*  716 */     this.closed = false;
/*  717 */     this.clearParameters = true;
/*  718 */     this.serverCursor = false;
/*  719 */     this.needToAddIdentifier = false;
/*  720 */     this.defaultFetchDirection = 1000;
/*  721 */     this.fixedString = this.connection.getDefaultFixedString();
/*  722 */     this.rowPrefetchChanged = false;
/*  723 */     this.rowPrefetch = paramInt2;
/*  724 */     this.defaultRowPrefetch = paramInt2;
/*  725 */     this.batch = paramInt1;
/*  726 */     this.autoRefetch = this.connection.getDefaultAutoRefetch();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  732 */     this.sqlStringChanged = true;
/*  733 */     this.needToParse = true;
/*  734 */     this.needToPrepareDefineBuffer = true;
/*  735 */     this.columnsDefinedByUser = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  743 */     if ((paramInt3 != -1) || (paramInt4 != -1))
/*      */     {
/*  745 */       this.realRsetType = 0;
/*  746 */       this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4);
/*      */       
/*      */ 
/*  749 */       this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType);
/*      */     }
/*      */     else
/*      */     {
/*  753 */       this.userRsetType = 1;
/*  754 */       this.realRsetType = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeDefineSubRanges()
/*      */   {
/*  777 */     this.defineByteSubRange = 0;
/*  778 */     this.defineCharSubRange = 0;
/*  779 */     this.defineIndicatorSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareDefinePreambles() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareAccessors()
/*      */     throws SQLException
/*      */   {
/*  808 */     byte[] arrayOfByte = null;
/*  809 */     char[] arrayOfChar = null;
/*  810 */     short[] arrayOfShort = null;
/*  811 */     boolean bool = false;
/*      */     
/*  813 */     if (this.accessors == null) {
/*  814 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  819 */     int i = 0;
/*  820 */     int j = 0;
/*      */     Accessor localAccessor;
/*  822 */     for (int k = 0; k < this.numberOfDefinePositions; k++)
/*      */     {
/*  824 */       localAccessor = this.accessors[k];
/*      */       
/*  826 */       if (localAccessor == null) {
/*  827 */         DatabaseError.throwSqlException(21);
/*      */       }
/*  829 */       i += localAccessor.byteLength;
/*  830 */       j += localAccessor.charLength;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  835 */     if ((this.streamList != null) && (!this.connection.useFetchSizeWithLongColumn)) {
/*  836 */       this.rowPrefetch = 1;
/*      */     }
/*  838 */     k = this.rowPrefetch;
/*      */     
/*  840 */     this.definesBatchSize = k;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  848 */     initializeDefineSubRanges();
/*      */     
/*      */ 
/*  851 */     int m = this.defineByteSubRange + i * k;
/*      */     
/*  853 */     if ((this.defineBytes == null) || (this.defineBytes.length < m))
/*      */     {
/*  855 */       if (this.defineBytes != null) arrayOfByte = this.defineBytes;
/*  856 */       this.defineBytes = new byte[m];
/*      */     }
/*      */     
/*  859 */     this.defineByteSubRange += this.accessorByteOffset;
/*      */     
/*      */ 
/*  862 */     int n = this.defineCharSubRange + j * k;
/*      */     
/*  864 */     if (((this.defineChars == null) || (this.defineChars.length < n)) && (n > 0))
/*      */     {
/*      */ 
/*  867 */       if (this.defineChars != null) arrayOfChar = this.defineChars;
/*  868 */       this.defineChars = new char[n];
/*      */     }
/*      */     
/*  871 */     this.defineCharSubRange += this.accessorCharOffset;
/*      */     
/*      */ 
/*      */ 
/*  875 */     int i1 = this.numberOfDefinePositions * k;
/*  876 */     int i2 = this.defineIndicatorSubRange + i1 + i1;
/*      */     
/*      */ 
/*  879 */     if ((this.defineIndicators == null) || (this.defineIndicators.length < i2))
/*      */     {
/*      */ 
/*  882 */       if (this.defineIndicators != null) arrayOfShort = this.defineIndicators;
/*  883 */       this.defineIndicators = new short[i2];
/*  884 */     } else if (this.defineIndicators.length > i2)
/*      */     {
/*  886 */       bool = true;
/*  887 */       arrayOfShort = this.defineIndicators;
/*      */     }
/*      */     
/*  890 */     this.defineIndicatorSubRange += this.accessorShortOffset;
/*      */     
/*  892 */     int i3 = this.defineIndicatorSubRange + i1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  898 */     for (int i4 = 0; i4 < this.numberOfDefinePositions; i4++)
/*      */     {
/*  900 */       localAccessor = this.accessors[i4];
/*      */       
/*  902 */       localAccessor.lengthIndexLastRow = localAccessor.lengthIndex;
/*  903 */       localAccessor.indicatorIndexLastRow = localAccessor.indicatorIndex;
/*  904 */       localAccessor.columnIndexLastRow = localAccessor.columnIndex;
/*      */       
/*  906 */       localAccessor.setOffsets(k);
/*      */       
/*  908 */       localAccessor.lengthIndex = i3;
/*  909 */       localAccessor.indicatorIndex = this.defineIndicatorSubRange;
/*  910 */       localAccessor.rowSpaceByte = this.defineBytes;
/*  911 */       localAccessor.rowSpaceChar = this.defineChars;
/*  912 */       localAccessor.rowSpaceIndicator = this.defineIndicators;
/*  913 */       this.defineIndicatorSubRange += k;
/*  914 */       i3 += k;
/*      */     }
/*      */     
/*  917 */     prepareDefinePreambles();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  923 */     if ((arrayOfChar != null) || (arrayOfByte != null))
/*      */     {
/*      */ 
/*  926 */       saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte, arrayOfShort != null ? arrayOfShort : this.defineIndicators, bool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  932 */     else if ((bool) && (this.rowPrefetchAtExecute != -1) && (this.rowPrefetch != this.rowPrefetchAtExecute))
/*      */     {
/*      */ 
/*      */ 
/*  936 */       saveDefineBuffersIfRequired(this.defineChars, this.defineBytes, this.defineIndicators, bool);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  942 */     this.rowPrefetchAtExecute = this.rowPrefetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean checkAccessorsUsable()
/*      */     throws SQLException
/*      */   {
/*  954 */     int i = this.accessors.length;
/*      */     
/*  956 */     if (i < this.numberOfDefinePositions) {
/*  957 */       return false;
/*      */     }
/*  959 */     int j = 1;
/*  960 */     int k = 0;
/*  961 */     boolean bool = false;
/*      */     
/*  963 */     for (int m = 0; m < this.numberOfDefinePositions; m++)
/*      */     {
/*  965 */       Accessor localAccessor = this.accessors[m];
/*      */       
/*  967 */       if ((localAccessor == null) || (localAccessor.externalType == 0)) {
/*  968 */         j = 0;
/*      */       } else {
/*  970 */         k = 1;
/*      */       }
/*      */     }
/*  973 */     if (j != 0)
/*      */     {
/*      */ 
/*  976 */       bool = true;
/*  977 */     } else if (k != 0)
/*      */     {
/*      */ 
/*  980 */       DatabaseError.throwSqlException(21);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  985 */       this.columnsDefinedByUser = false;
/*      */     }
/*  987 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeMaybeDescribe()
/*      */     throws SQLException
/*      */   {
/* 1004 */     if (this.rowPrefetchChanged)
/*      */     {
/* 1006 */       if ((this.streamList == null) && (this.rowPrefetch != this.definesBatchSize)) {
/* 1007 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/* 1009 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */     
/* 1012 */     if (!this.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */ 
/* 1016 */       if (this.accessors == null)
/*      */       {
/*      */ 
/*      */ 
/* 1020 */         this.needToPrepareDefineBuffer = true;
/* 1021 */       } else if (this.columnsDefinedByUser) {
/* 1022 */         this.needToPrepareDefineBuffer = (!checkAccessorsUsable());
/*      */       }
/*      */     }
/* 1025 */     boolean bool = false;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1030 */       this.isExecuting = true;
/*      */       
/* 1032 */       if (this.needToPrepareDefineBuffer)
/*      */       {
/*      */ 
/* 1035 */         if (!this.columnsDefinedByUser)
/*      */         {
/* 1037 */           executeForDescribe();
/*      */           
/* 1039 */           bool = true;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1045 */         prepareAccessors();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1050 */       int i = this.accessors.length;
/*      */       
/* 1052 */       for (int j = this.numberOfDefinePositions; j < i; j++)
/*      */       {
/* 1054 */         Accessor localAccessor = this.accessors[j];
/*      */         
/* 1056 */         if (localAccessor != null) {
/* 1057 */           localAccessor.rowSpaceIndicator = null;
/*      */         }
/*      */       }
/* 1060 */       executeForRows(bool);
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 1065 */       this.needToParse = true;
/* 1066 */       throw localSQLException;
/*      */     }
/*      */     finally
/*      */     {
/* 1070 */       this.isExecuting = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void adjustGotLastBatch() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doExecuteWithTimeout()
/*      */     throws SQLException
/*      */   {
/* 1095 */     cleanOldTempLobs();
/*      */     
/*      */ 
/* 1098 */     this.rowsProcessed = 0;
/*      */     
/* 1100 */     if (this.sqlKind == 0)
/*      */     {
/* 1102 */       if ((this.connection.j2ee13Compliant) && (this.executionType == 2)) {
/* 1103 */         DatabaseError.throwSqlException(129);
/*      */       }
/* 1105 */       this.connection.needLine();
/*      */       
/* 1107 */       if (!this.isOpen)
/*      */       {
/* 1109 */         this.connection.open(this);
/*      */         
/* 1111 */         this.isOpen = true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1117 */       this.connection.registerHeartbeat();
/*      */       
/* 1119 */       if (this.queryTimeout != 0)
/*      */       {
/*      */         try
/*      */         {
/* 1123 */           this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/* 1124 */           executeMaybeDescribe();
/*      */         }
/*      */         finally
/*      */         {
/* 1128 */           this.connection.getTimeout().cancelTimeout();
/*      */         }
/*      */         
/*      */       } else {
/* 1132 */         executeMaybeDescribe();
/*      */       }
/* 1134 */       checkValidRowsStatus();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1139 */       if (this.serverCursor) {
/* 1140 */         adjustGotLastBatch();
/*      */       }
/*      */     }
/*      */     else {
/* 1144 */       if ((this.connection.j2ee13Compliant) && (this.sqlKind != 1) && (this.sqlKind != 4) && (this.executionType == 1))
/*      */       {
/* 1146 */         DatabaseError.throwSqlException(128);
/*      */       }
/* 1148 */       this.currentRank += 1;
/*      */       
/* 1150 */       if (this.currentRank >= this.batch)
/*      */       {
/*      */         try
/*      */         {
/* 1154 */           this.connection.needLine();
/*      */           
/* 1156 */           if (!this.isOpen)
/*      */           {
/* 1158 */             this.connection.open(this);
/*      */             
/* 1160 */             this.isOpen = true;
/*      */           }
/*      */           
/* 1163 */           if (this.queryTimeout != 0) {
/* 1164 */             this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */           }
/* 1166 */           this.isExecuting = true;
/*      */           
/* 1168 */           executeForRows(false);
/*      */         }
/*      */         catch (SQLException localSQLException)
/*      */         {
/* 1172 */           this.needToParse = true;
/* 1173 */           throw localSQLException;
/*      */         }
/*      */         finally
/*      */         {
/* 1177 */           if (this.queryTimeout != 0) {
/* 1178 */             this.connection.getTimeout().cancelTimeout();
/*      */           }
/* 1180 */           this.currentRank = 0;
/* 1181 */           this.isExecuting = false;
/*      */           
/* 1183 */           checkValidRowsStatus();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void open()
/*      */     throws SQLException
/*      */   {
/* 1210 */     if (!this.isOpen)
/*      */     {
/* 1212 */       this.connection.needLine();
/* 1213 */       this.connection.open(this);
/*      */       
/* 1215 */       this.isOpen = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1233 */     Object localObject1 = null;
/*      */     
/*      */ 
/*      */ 
/* 1237 */     synchronized (this.connection)
/*      */     {
/* 1239 */       synchronized (this)
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*      */ 
/* 1245 */           this.executionType = 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1251 */           this.noMoreUpdateCounts = false;
/*      */           
/* 1253 */           ensureOpen();
/* 1254 */           checkIfJdbcBatchExists();
/*      */           
/* 1256 */           sendBatch();
/*      */           
/*      */ 
/* 1259 */           this.sqlObject.initialize(paramString);
/*      */           
/* 1261 */           this.sqlKind = this.sqlObject.getSqlKind();
/* 1262 */           this.needToParse = true;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1268 */           prepareForNewResults(true, true);
/*      */           
/* 1270 */           if (this.userRsetType == 1)
/*      */           {
/* 1272 */             doExecuteWithTimeout();
/*      */             
/* 1274 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1275 */             localObject1 = this.currentResultSet;
/*      */           }
/*      */           else
/*      */           {
/* 1279 */             localObject1 = doScrollStmtExecuteQuery();
/*      */             
/* 1281 */             if (localObject1 == null)
/*      */             {
/* 1283 */               this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1284 */               localObject1 = this.currentResultSet;
/*      */             }
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/* 1290 */           this.executionType = -1;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1295 */     return (ResultSet)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeWithKey(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1305 */     DatabaseError.throwSqlException(23);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 1338 */     synchronized (this.connection)
/*      */     {
/* 1340 */       synchronized (this)
/*      */       {
/* 1342 */         closeOrCache(null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void closeOrCache(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1352 */     if (this.closed) {
/* 1353 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1362 */     if ((this.statementType != 0) && (this.cacheState != 0) && (this.cacheState != 3) && (this.connection.isStatementCacheInitialized()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1372 */       if (paramString == null)
/*      */       {
/* 1374 */         if (this.connection.getImplicitCachingEnabled())
/*      */         {
/* 1376 */           this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/* 1385 */           this.cacheState = 0;
/*      */           
/* 1387 */           hardClose();
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1393 */       else if (this.connection.getExplicitCachingEnabled())
/*      */       {
/* 1395 */         this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 1403 */         this.cacheState = 0;
/*      */         
/* 1405 */         hardClose();
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1413 */       hardClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void hardClose()
/*      */     throws SQLException
/*      */   {
/* 1424 */     hardClose(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void hardClose(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1436 */     alwaysOnClose();
/*      */     
/* 1438 */     this.describedWithNames = false;
/* 1439 */     this.described = false;
/*      */     
/*      */ 
/* 1442 */     this.connection.removeStatement(this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1448 */     cleanupDefines();
/*      */     
/* 1450 */     if ((this.isOpen) && (paramBoolean) && (!this.connection.isClosed()))
/*      */     {
/* 1452 */       doClose();
/*      */       
/* 1454 */       this.isOpen = false;
/*      */     }
/*      */     
/* 1457 */     this.sqlObject = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void alwaysOnClose()
/*      */     throws SQLException
/*      */   {
/* 1473 */     Object localObject = this.children;
/*      */     
/* 1475 */     while (localObject != null)
/*      */     {
/* 1477 */       OracleStatement localOracleStatement = ((OracleStatement)localObject).nextChild;
/*      */       
/* 1479 */       ((OracleStatement)localObject).close();
/*      */       
/* 1481 */       localObject = localOracleStatement;
/*      */     }
/*      */     
/* 1484 */     this.closed = true;
/*      */     
/*      */ 
/* 1487 */     if (!this.connection.isClosed())
/*      */     {
/*      */ 
/*      */ 
/* 1491 */       this.connection.needLine();
/*      */       
/*      */ 
/* 1494 */       if (this.currentResultSet != null)
/*      */       {
/* 1496 */         this.currentResultSet.internal_close(false);
/*      */         
/* 1498 */         this.currentResultSet = null;
/*      */       }
/*      */       
/* 1501 */       if (this.scrollRset != null)
/*      */       {
/* 1503 */         this.scrollRset.close();
/*      */         
/* 1505 */         this.scrollRset = null;
/*      */       }
/*      */       
/* 1508 */       if (this.returnResultSet != null)
/*      */       {
/* 1510 */         this.returnResultSet.close();
/* 1511 */         this.returnResultSet = null;
/*      */       }
/*      */     }
/*      */     
/* 1515 */     clearWarnings();
/*      */     
/* 1517 */     this.m_batchItems = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeLeaveCursorOpen()
/*      */     throws SQLException
/*      */   {
/* 1537 */     synchronized (this.connection)
/*      */     {
/* 1539 */       synchronized (this)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1545 */         if (this.closed)
/*      */         {
/* 1547 */           return;
/*      */         }
/*      */         
/* 1550 */         hardClose(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1574 */     synchronized (this.connection)
/*      */     {
/* 1576 */       synchronized (this)
/*      */       {
/* 1578 */         setNonAutoKey();
/* 1579 */         return executeUpdateInternal(paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   int executeUpdateInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1589 */       if (this.executionType == -1) {
/* 1590 */         this.executionType = 2;
/*      */       }
/*      */       
/* 1593 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1595 */       ensureOpen();
/* 1596 */       checkIfJdbcBatchExists();
/*      */       
/* 1598 */       sendBatch();
/*      */       
/*      */ 
/* 1601 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1603 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1604 */       this.needToParse = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1610 */       prepareForNewResults(true, true);
/*      */       
/* 1612 */       if (this.userRsetType == 1)
/*      */       {
/* 1614 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1618 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1621 */       return this.validRows;
/*      */     }
/*      */     finally
/*      */     {
/* 1625 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1645 */     synchronized (this.connection)
/*      */     {
/* 1647 */       synchronized (this)
/*      */       {
/* 1649 */         setNonAutoKey();
/*      */         
/*      */ 
/*      */ 
/* 1653 */         return executeInternal(paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   boolean executeInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1663 */       this.executionType = 3;
/*      */       
/*      */ 
/* 1666 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1668 */       ensureOpen();
/* 1669 */       checkIfJdbcBatchExists();
/*      */       
/* 1671 */       sendBatch();
/*      */       
/*      */ 
/* 1674 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1676 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1677 */       this.needToParse = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1683 */       prepareForNewResults(true, true);
/*      */       
/* 1685 */       if (this.userRsetType == 1)
/*      */       {
/* 1687 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1691 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1694 */       return this.sqlKind == 0;
/*      */     }
/*      */     finally
/*      */     {
/* 1698 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */   int getNumberOfColumns() throws SQLException
/*      */   {
/* 1704 */     if (!this.described) {
/* 1705 */       synchronized (this.connection)
/*      */       {
/* 1707 */         synchronized (this)
/*      */         {
/* 1709 */           this.connection.needLine();
/* 1710 */           doDescribe(false);
/*      */           
/* 1712 */           this.described = true;
/*      */         }
/*      */       }
/*      */     }
/* 1716 */     return this.numberOfDefinePositions;
/*      */   }
/*      */   
/*      */   Accessor[] getDescription() throws SQLException
/*      */   {
/* 1721 */     if (!this.described) {
/* 1722 */       synchronized (this.connection)
/*      */       {
/* 1724 */         synchronized (this)
/*      */         {
/* 1726 */           this.connection.needLine();
/* 1727 */           doDescribe(false);
/*      */           
/* 1729 */           this.described = true;
/*      */         }
/*      */       }
/*      */     }
/* 1733 */     return this.accessors;
/*      */   }
/*      */   
/*      */   Accessor[] getDescriptionWithNames() throws SQLException
/*      */   {
/* 1738 */     if (!this.describedWithNames) {
/* 1739 */       synchronized (this.connection)
/*      */       {
/* 1741 */         synchronized (this)
/*      */         {
/* 1743 */           this.connection.needLine();
/* 1744 */           doDescribe(true);
/*      */           
/* 1746 */           this.described = true;
/* 1747 */           this.describedWithNames = true;
/*      */         }
/*      */       }
/*      */     }
/* 1751 */     return this.accessors;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte getSqlKind()
/*      */   {
/* 1764 */     return this.sqlKind;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearDefines()
/*      */     throws SQLException
/*      */   {
/* 1789 */     freeLine();
/*      */     
/* 1791 */     this.streamList = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1798 */     this.columnsDefinedByUser = false;
/* 1799 */     this.needToPrepareDefineBuffer = true;
/*      */     
/*      */ 
/* 1802 */     this.numberOfDefinePositions = 0;
/* 1803 */     this.definesBatchSize = 0;
/*      */     
/* 1805 */     this.described = false;
/* 1806 */     this.describedWithNames = false;
/*      */     
/* 1808 */     cleanupDefines();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1824 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1833 */     if (this.connection.disableDefineColumnType)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1838 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1845 */     if (paramInt1 < 1) {
/* 1846 */       DatabaseError.throwSqlException(3);
/*      */     }
/* 1848 */     if (paramInt2 == 0) {
/* 1849 */       DatabaseError.throwSqlException(4);
/*      */     }
/* 1851 */     int i = paramInt1 - 1;
/* 1852 */     int j = this.maxFieldSize;
/*      */     
/* 1854 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/* 1858 */       if ((paramInt2 == 1) || (paramInt2 == 12)) {
/* 1859 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 1865 */       if (paramInt3 < 0) {
/* 1866 */         DatabaseError.throwSqlException(53);
/*      */       }
/* 1868 */       if ((j == 0) || (paramInt3 < j)) {
/* 1869 */         j = paramInt3;
/*      */       }
/*      */     }
/* 1872 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed)) {
/* 1873 */       DatabaseError.throwSqlException(28);
/*      */     }
/* 1875 */     if (!this.columnsDefinedByUser)
/*      */     {
/*      */ 
/*      */ 
/* 1879 */       clearDefines();
/*      */       
/* 1881 */       this.columnsDefinedByUser = true;
/*      */     }
/*      */     
/* 1884 */     if (this.numberOfDefinePositions < paramInt1)
/*      */     {
/* 1886 */       if ((this.accessors == null) || (this.accessors.length < paramInt1))
/*      */       {
/* 1888 */         Accessor[] arrayOfAccessor = new Accessor[paramInt1 << 1];
/*      */         
/* 1890 */         if (this.accessors != null) {
/* 1891 */           System.arraycopy(this.accessors, 0, arrayOfAccessor, 0, this.numberOfDefinePositions);
/*      */         }
/* 1893 */         this.accessors = arrayOfAccessor;
/*      */       }
/*      */       
/* 1896 */       this.numberOfDefinePositions = paramInt1;
/*      */     }
/*      */     
/* 1899 */     int k = getInternalType(paramInt2);
/*      */     
/* 1901 */     if (((k == 109) || (k == 111)) && ((paramString == null) || (paramString.equals(""))))
/*      */     {
/* 1903 */       DatabaseError.throwSqlException(60, "Invalid arguments");
/*      */     }
/*      */     
/* 1906 */     Accessor localAccessor = this.accessors[i];
/* 1907 */     int m = 1;
/*      */     
/* 1909 */     if (localAccessor != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1914 */       int n = localAccessor.useForDataAccessIfPossible(k, paramInt2, j, paramString);
/*      */       
/*      */ 
/* 1917 */       if (n == 0)
/*      */       {
/* 1919 */         paramShort = localAccessor.formOfUse;
/* 1920 */         localAccessor = null;
/*      */         
/* 1922 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 1924 */       else if (n == 1)
/*      */       {
/* 1926 */         localAccessor = null;
/*      */         
/* 1928 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 1930 */       else if (n == 2) {
/* 1931 */         m = 0;
/*      */       }
/*      */     }
/* 1934 */     if (m != 0) {
/* 1935 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/* 1937 */     if (localAccessor == null)
/*      */     {
/* 1939 */       this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
/*      */       
/* 1941 */       this.described = false;
/* 1942 */       this.describedWithNames = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     Object localObject;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1985 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/* 1989 */       if ((paramBoolean) && (paramString != null)) {
/* 1990 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 1993 */       return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 8: 
/* 1996 */       if ((paramBoolean) && (paramString != null)) {
/* 1997 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2000 */       if (!paramBoolean) {
/* 2001 */         return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */     case 1: 
/* 2006 */       if ((paramBoolean) && (paramString != null)) {
/* 2007 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2010 */       return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 2: 
/* 2013 */       if ((paramBoolean) && (paramString != null)) {
/* 2014 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2017 */       return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 6: 
/* 2020 */       if ((paramBoolean) && (paramString != null)) {
/* 2021 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2024 */       return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 24: 
/* 2027 */       if ((paramBoolean) && (paramString != null)) {
/* 2028 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2031 */       if (!paramBoolean) {
/* 2032 */         return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/* 2038 */       if ((paramBoolean) && (paramString != null)) {
/* 2039 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2042 */       if (paramBoolean) {
/* 2043 */         return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */       }
/* 2045 */       return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
/*      */     
/*      */     case 100: 
/* 2048 */       if ((paramBoolean) && (paramString != null)) {
/* 2049 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2052 */       return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 101: 
/* 2056 */       if ((paramBoolean) && (paramString != null)) {
/* 2057 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2060 */       return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 104: 
/* 2064 */       if ((paramBoolean) && (paramString != null)) {
/* 2065 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2068 */       return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 102: 
/* 2071 */       if ((paramBoolean) && (paramString != null)) {
/* 2072 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2075 */       return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 12: 
/* 2078 */       if ((paramBoolean) && (paramString != null)) {
/* 2079 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2082 */       return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 113: 
/* 2085 */       if ((paramBoolean) && (paramString != null)) {
/* 2086 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2089 */       return new BlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 112: 
/* 2092 */       if ((paramBoolean) && (paramString != null)) {
/* 2093 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2096 */       return new ClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 114: 
/* 2099 */       if ((paramBoolean) && (paramString != null)) {
/* 2100 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2103 */       return new BfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 109: 
/* 2106 */       if (paramString == null) {
/* 2107 */         if (paramBoolean) {
/* 2108 */           DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */         }
/*      */         else {
/* 2111 */           DatabaseError.throwSqlException(60, "Unable to resolve type \"null\"");
/*      */         }
/*      */       }
/* 2114 */       localObject = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2117 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2119 */       return (Accessor)localObject;
/*      */     
/*      */     case 111: 
/* 2122 */       if (paramString == null) {
/* 2123 */         if (paramBoolean) {
/* 2124 */           DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */         }
/*      */         else {
/* 2127 */           DatabaseError.throwSqlException(60, "Unable to resolve type \"null\"");
/*      */         }
/*      */       }
/* 2130 */       localObject = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2133 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2135 */       return (Accessor)localObject;
/*      */     
/*      */     case 180: 
/* 2138 */       if ((paramBoolean) && (paramString != null)) {
/* 2139 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2142 */       if (this.connection.v8Compatible) {
/* 2143 */         return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       }
/* 2145 */       return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 181: 
/* 2149 */       if ((paramBoolean) && (paramString != null)) {
/* 2150 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2153 */       return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 231: 
/* 2157 */       if ((paramBoolean) && (paramString != null)) {
/* 2158 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2161 */       return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 182: 
/* 2165 */       if ((paramBoolean) && (paramString != null)) {
/* 2166 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2169 */       return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 183: 
/* 2173 */       if ((paramBoolean) && (paramString != null)) {
/* 2174 */         DatabaseError.throwSqlException(12, "sqlType=" + paramInt2);
/*      */       }
/*      */       
/* 2177 */       return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/* 2192 */       DatabaseError.throwSqlException(89);
/*      */     }
/*      */     
/* 2195 */     DatabaseError.throwSqlException(4);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2203 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void defineColumnType(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2259 */     defineColumnTypeInternal(paramInt1, paramInt2, 0, true, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2279 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2303 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2379 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2453 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2502 */     synchronized (this.connection)
/*      */     {
/* 2504 */       synchronized (this)
/*      */       {
/* 2506 */         defineColumnTypeInternal(paramInt1, paramInt2, 0, true, paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setCursorId(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2523 */     this.cursorId = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/* 2540 */     if (paramBoolean1)
/*      */     {
/* 2542 */       if (paramInt <= 0) {
/* 2543 */         DatabaseError.throwSqlException(20);
/*      */       }
/*      */       
/*      */     }
/* 2547 */     else if (paramInt < 0) {
/* 2548 */       DatabaseError.throwSqlException(68, "setFetchSize");
/*      */     }
/* 2550 */     else if (paramInt == 0) {
/* 2551 */       paramInt = this.connection.getDefaultRowPrefetch();
/*      */     }
/*      */     
/*      */ 
/* 2555 */     if (paramBoolean2)
/*      */     {
/* 2557 */       if (paramInt != this.defaultRowPrefetch)
/*      */       {
/* 2559 */         this.defaultRowPrefetch = paramInt;
/*      */         
/*      */ 
/*      */ 
/* 2563 */         if ((this.currentResultSet == null) || (this.currentResultSet.closed)) {
/* 2564 */           this.rowPrefetchChanged = true;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 2571 */     else if ((paramInt != this.rowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/* 2574 */       this.rowPrefetch = paramInt;
/* 2575 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setRowPrefetch(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2608 */     setPrefetchInternal(paramInt, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getPrefetchInternal(boolean paramBoolean)
/*      */   {
/* 2628 */     int i = paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2633 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getRowPrefetch()
/*      */   {
/* 2649 */     return getPrefetchInternal(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFixedString(boolean paramBoolean)
/*      */   {
/* 2677 */     this.fixedString = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFixedString()
/*      */   {
/* 2704 */     return this.fixedString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void check_row_prefetch_changed()
/*      */     throws SQLException
/*      */   {
/* 2718 */     if (this.rowPrefetchChanged)
/*      */     {
/* 2720 */       if (this.streamList == null)
/*      */       {
/* 2722 */         prepareAccessors();
/*      */         
/* 2724 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/*      */       
/* 2727 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDefinesInitialized(boolean paramBoolean) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void printState(String paramString)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkValidRowsStatus()
/*      */     throws SQLException
/*      */   {
/* 2762 */     if (this.validRows == -2)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2768 */       this.validRows = 1;
/*      */       
/* 2770 */       this.connection.holdLine(this);
/*      */       
/*      */ 
/* 2773 */       OracleInputStream localOracleInputStream = this.streamList;
/*      */       
/* 2775 */       while (localOracleInputStream != null)
/*      */       {
/* 2777 */         if (localOracleInputStream.hasBeenOpen) {
/* 2778 */           localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2785 */         localOracleInputStream.closed = false;
/* 2786 */         localOracleInputStream.hasBeenOpen = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2791 */         localOracleInputStream = localOracleInputStream.nextStream;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2796 */       this.nextStream = this.streamList;
/*      */ 
/*      */     }
/* 2799 */     else if (this.sqlKind == 0)
/*      */     {
/* 2801 */       if (this.validRows < this.rowPrefetch) {
/* 2802 */         this.gotLastBatch = true;
/*      */       }
/* 2804 */     } else if ((this.sqlKind != 1) && (this.sqlKind != 4))
/*      */     {
/*      */ 
/* 2807 */       this.rowsProcessed = this.validRows;
/*      */     }
/*      */   }
/*      */   
/*      */   void cleanupDefines()
/*      */   {
/* 2813 */     if (this.accessors != null) {
/* 2814 */       for (int i = 0; i < this.accessors.length; i++)
/* 2815 */         this.accessors[i] = null;
/*      */     }
/* 2817 */     this.accessors = null;
/*      */     
/*      */ 
/* 2820 */     if (this.defineBytes != null)
/*      */     {
/* 2822 */       this.defineBytes = null;
/*      */     }
/*      */     
/* 2825 */     if (this.defineChars != null)
/*      */     {
/* 2827 */       this.defineChars = null;
/*      */     }
/*      */     
/* 2830 */     if (this.defineIndicators != null)
/*      */     {
/* 2832 */       this.defineIndicators = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized int getMaxFieldSize() throws SQLException
/*      */   {
/* 2838 */     return this.maxFieldSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setMaxFieldSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2845 */     if (paramInt < 0) {
/* 2846 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 2848 */     this.maxFieldSize = paramInt;
/*      */   }
/*      */   
/*      */   public int getMaxRows() throws SQLException
/*      */   {
/* 2853 */     return this.maxRows;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setMaxRows(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2860 */     if (paramInt < 0) {
/* 2861 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 2863 */     this.maxRows = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setEscapeProcessing(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2872 */     this.processEscapes = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/* 2888 */     return this.queryTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setQueryTimeout(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2906 */     if (paramInt < 0) {
/* 2907 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 2909 */     this.queryTimeout = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/* 2926 */     if (this.closed) {
/* 2927 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2939 */     if (this.connection.statementHoldingLine != null) {
/* 2940 */       freeLine();
/* 2941 */     } else if (this.isExecuting) {
/* 2942 */       this.connection.doCancel();
/*      */     }
/* 2944 */     this.connection.releaseLineForCancel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 2963 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/* 2971 */     this.sqlWarning = null;
/*      */   }
/*      */   
/*      */   void foundPlsqlCompilerWarning()
/*      */     throws SQLException
/*      */   {
/* 2977 */     SQLWarning localSQLWarning = DatabaseError.newSqlWarning("Found Plsql compiler warnings.", "99999", 24439);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2982 */     if (this.sqlWarning != null) {
/* 2983 */       this.sqlWarning.setNextWarning(localSQLWarning);
/*      */     } else {
/* 2985 */       this.sqlWarning = localSQLWarning;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursorName(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2997 */     DatabaseError.throwSqlException(23);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 3012 */     if (this.userRsetType == 1)
/*      */     {
/* 3014 */       if (this.sqlKind == 0)
/*      */       {
/* 3016 */         if (this.currentResultSet == null) {
/* 3017 */           this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*      */         }
/* 3019 */         return this.currentResultSet;
/*      */       }
/*      */       
/*      */     }
/*      */     else {
/* 3024 */       return this.scrollRset;
/*      */     }
/*      */     
/* 3027 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 3045 */     int i = -1;
/*      */     
/* 3047 */     switch (this.sqlKind)
/*      */     {
/*      */     case -1: 
/*      */     case 0: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 3: 
/* 3056 */       if (!this.noMoreUpdateCounts) {
/* 3057 */         i = this.rowsProcessed;
/*      */       }
/* 3059 */       this.noMoreUpdateCounts = true;
/*      */       
/* 3061 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 4: 
/* 3067 */       this.noMoreUpdateCounts = true;
/*      */       
/* 3069 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/* 3074 */       if (!this.noMoreUpdateCounts) {
/* 3075 */         i = this.rowsProcessed;
/*      */       }
/* 3077 */       this.noMoreUpdateCounts = true;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 3082 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 3094 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int sendBatch()
/*      */     throws SQLException
/*      */   {
/* 3107 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/* 3116 */     clearWarnings();
/*      */     
/* 3118 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 3122 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3126 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3130 */           DatabaseError.throwSqlException(localIOException);
/*      */         }
/*      */         
/* 3133 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */       
/* 3136 */       if (paramBoolean2)
/*      */       {
/*      */ 
/* 3139 */         OracleInputStream localOracleInputStream1 = this.streamList;
/* 3140 */         OracleInputStream localOracleInputStream2 = null;
/*      */         
/* 3142 */         this.streamList = null;
/*      */         
/* 3144 */         while (localOracleInputStream1 != null)
/*      */         {
/* 3146 */           if (!localOracleInputStream1.hasBeenOpen)
/*      */           {
/* 3148 */             if (localOracleInputStream2 == null) {
/* 3149 */               this.streamList = localOracleInputStream1;
/*      */             } else {
/* 3151 */               localOracleInputStream2.nextStream = localOracleInputStream1;
/*      */             }
/* 3153 */             localOracleInputStream2 = localOracleInputStream1;
/*      */           }
/*      */           
/* 3156 */           localOracleInputStream1 = localOracleInputStream1.nextStream;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3161 */     if (this.currentResultSet != null)
/*      */     {
/* 3163 */       this.currentResultSet.internal_close(true);
/*      */       
/* 3165 */       this.currentResultSet = null;
/*      */     }
/*      */     
/* 3168 */     this.currentRow = -1;
/* 3169 */     this.validRows = 0;
/* 3170 */     this.totalRowsVisited = 0;
/* 3171 */     this.gotLastBatch = false;
/*      */     
/* 3173 */     if ((this.needToParse) && (!this.columnsDefinedByUser))
/*      */     {
/* 3175 */       if ((paramBoolean2) && (this.numberOfDefinePositions != 0)) {
/* 3176 */         this.numberOfDefinePositions = 0;
/*      */       }
/* 3178 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/*      */     
/*      */ 
/* 3182 */     if ((paramBoolean1) && (this.rowPrefetch != this.defaultRowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/*      */ 
/* 3186 */       this.rowPrefetch = this.defaultRowPrefetch;
/* 3187 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reopenStreams()
/*      */     throws SQLException
/*      */   {
/* 3200 */     OracleInputStream localOracleInputStream = this.streamList;
/*      */     
/* 3202 */     while (localOracleInputStream != null)
/*      */     {
/* 3204 */       if (localOracleInputStream.hasBeenOpen) {
/* 3205 */         localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */       }
/* 3207 */       localOracleInputStream.closed = false;
/* 3208 */       localOracleInputStream.hasBeenOpen = true;
/* 3209 */       localOracleInputStream = localOracleInputStream.nextStream;
/*      */     }
/*      */     
/* 3212 */     this.nextStream = this.streamList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void endOfResultSet(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3225 */     if (!paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/* 3229 */       prepareForNewResults(false, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3234 */     clearDefines();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean wasNullValue()
/*      */     throws SQLException
/*      */   {
/* 3256 */     if (this.lastIndex == 0) {
/* 3257 */       DatabaseError.throwSqlException(24);
/*      */     }
/* 3259 */     if (this.sqlKind == 0) {
/* 3260 */       return this.accessors[(this.lastIndex - 1)].isNull(this.currentRow);
/*      */     }
/* 3262 */     return this.outBindAccessors[(this.lastIndex - 1)].isNull(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnIndex(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3274 */     if (!this.describedWithNames) {
/* 3275 */       synchronized (this.connection)
/*      */       {
/* 3277 */         synchronized (this)
/*      */         {
/* 3279 */           this.connection.needLine();
/* 3280 */           doDescribe(true);
/*      */           
/* 3282 */           this.described = true;
/* 3283 */           this.describedWithNames = true;
/*      */         }
/*      */       }
/*      */     }
/* 3287 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/* 3288 */       if (this.accessors[i].columnName.equalsIgnoreCase(paramString))
/* 3289 */         return i + 1;
/*      */     }
/* 3291 */     DatabaseError.throwSqlException(6);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3297 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getInternalType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3305 */     int i = 0;
/*      */     
/* 3307 */     switch (paramInt)
/*      */     {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 3319 */       i = 6;
/* 3320 */       break;
/*      */     
/*      */     case 100: 
/* 3323 */       i = 100;
/* 3324 */       break;
/*      */     
/*      */     case 101: 
/* 3327 */       i = 101;
/* 3328 */       break;
/*      */     
/*      */     case 999: 
/* 3331 */       i = 999;
/* 3332 */       break;
/*      */     
/*      */     case 1: 
/* 3335 */       i = 96;
/* 3336 */       break;
/*      */     
/*      */     case 12: 
/* 3339 */       i = 1;
/* 3340 */       break;
/*      */     
/*      */     case -1: 
/* 3343 */       i = 8;
/* 3344 */       break;
/*      */     
/*      */     case 91: 
/*      */     case 92: 
/* 3348 */       i = 12;
/* 3349 */       break;
/*      */     
/*      */     case -100: 
/*      */     case 93: 
/* 3353 */       i = 180;
/* 3354 */       break;
/*      */     
/*      */     case -101: 
/* 3357 */       i = 181;
/* 3358 */       break;
/*      */     
/*      */     case -102: 
/* 3361 */       i = 231;
/* 3362 */       break;
/*      */     
/*      */ 
/*      */     case -103: 
/* 3366 */       i = 182;
/* 3367 */       break;
/*      */     
/*      */     case -104: 
/* 3370 */       i = 183;
/* 3371 */       break;
/*      */     
/*      */     case -3: 
/*      */     case -2: 
/* 3375 */       i = 23;
/* 3376 */       break;
/*      */     
/*      */     case -4: 
/* 3379 */       i = 24;
/* 3380 */       break;
/*      */     
/*      */     case -8: 
/* 3383 */       i = 104;
/* 3384 */       break;
/*      */     
/*      */     case 2004: 
/* 3387 */       i = 113;
/* 3388 */       break;
/*      */     
/*      */     case 2005: 
/* 3391 */       i = 112;
/* 3392 */       break;
/*      */     
/*      */     case -13: 
/* 3395 */       i = 114;
/* 3396 */       break;
/*      */     
/*      */     case -10: 
/* 3399 */       i = 102;
/* 3400 */       break;
/*      */     
/*      */     case 2002: 
/*      */     case 2003: 
/*      */     case 2007: 
/*      */     case 2008: 
/* 3406 */       i = 109;
/* 3407 */       break;
/*      */     
/*      */     case 2006: 
/* 3410 */       i = 111;
/* 3411 */       break;
/*      */     
/*      */     case -14: 
/* 3414 */       i = 998;
/* 3415 */       break;
/*      */     
/*      */     case 70: 
/* 3418 */       i = 1;
/* 3419 */       break;
/*      */     
/*      */     case 0: 
/* 3422 */       i = 995;
/* 3423 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 3428 */       DatabaseError.throwSqlException(4);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 3434 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void describe()
/*      */     throws SQLException
/*      */   {
/* 3451 */     synchronized (this.connection)
/*      */     {
/* 3453 */       synchronized (this)
/*      */       {
/* 3455 */         if (!this.described)
/*      */         {
/* 3457 */           this.connection.needLine();
/* 3458 */           doDescribe(false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void freeLine() throws SQLException
/*      */   {
/* 3466 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 3470 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3474 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3478 */           DatabaseError.throwSqlException(localIOException);
/*      */         }
/*      */         
/* 3481 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeUsedStreams(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3492 */     while ((this.nextStream != null) && (this.nextStream.columnIndex < paramInt))
/*      */     {
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 3499 */         this.nextStream.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 3503 */         DatabaseError.throwSqlException(localIOException);
/*      */       }
/*      */       
/* 3506 */       this.nextStream = this.nextStream.nextStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void ensureOpen()
/*      */     throws SQLException
/*      */   {
/* 3516 */     if (this.connection.lifecycle != 1)
/* 3517 */       DatabaseError.throwSqlException(8);
/* 3518 */     if (this.closed) {
/* 3519 */       DatabaseError.throwSqlException(9);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3546 */     if (paramInt == 1000)
/*      */     {
/*      */ 
/* 3549 */       this.defaultFetchDirection = paramInt;
/*      */     }
/* 3551 */     else if ((paramInt == 1001) || (paramInt == 1002))
/*      */     {
/*      */ 
/* 3554 */       this.defaultFetchDirection = 1000;
/* 3555 */       this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 3560 */       DatabaseError.throwSqlException(68, "setFetchDirection");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 3580 */     return this.defaultFetchDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3603 */     setPrefetchInternal(paramInt, false, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 3624 */     return getPrefetchInternal(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/* 3634 */     return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/* 3644 */     return ResultSetUtil.getScrollType(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 3657 */     return this.connection.getWrapper();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setResultSetCache(oracle.jdbc.OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3671 */       if (paramOracleResultSetCache == null) {
/* 3672 */         DatabaseError.throwSqlException(68);
/*      */       }
/* 3674 */       if (this.rsetCache != null) {
/* 3675 */         this.rsetCache.close();
/*      */       }
/* 3677 */       this.rsetCache = paramOracleResultSetCache;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3681 */       DatabaseError.throwSqlException(localIOException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setResultSetCache(OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/* 3695 */     setResultSetCache(paramOracleResultSetCache);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized OracleResultSetCache getResultSetCache()
/*      */     throws SQLException
/*      */   {
/* 3704 */     return (OracleResultSetCache)this.rsetCache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3722 */   Vector m_batchItems = new Vector();
/*      */   
/*      */   void initBatch() {}
/*      */   
/*      */   int getBatchSize()
/*      */   {
/* 3728 */     return this.m_batchItems.size();
/*      */   }
/*      */   
/*      */   void addBatchItem(String paramString)
/*      */   {
/* 3733 */     this.m_batchItems.addElement(paramString);
/*      */   }
/*      */   
/*      */   String getBatchItem(int paramInt)
/*      */   {
/* 3738 */     return (String)this.m_batchItems.elementAt(paramInt);
/*      */   }
/*      */   
/*      */   void clearBatchItems()
/*      */   {
/* 3743 */     this.m_batchItems.removeAllElements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkIfJdbcBatchExists()
/*      */     throws SQLException
/*      */   {
/* 3757 */     if (getBatchSize() > 0)
/*      */     {
/* 3759 */       DatabaseError.throwSqlException(81, "batch must be either executed or cleared");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addBatch(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3788 */     addBatchItem(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearBatch()
/*      */     throws SQLException
/*      */   {
/* 3805 */     clearBatchItems();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 3837 */     synchronized (this.connection)
/*      */     {
/* 3839 */       synchronized (this)
/*      */       {
/* 3841 */         cleanOldTempLobs();
/* 3842 */         int i = 0;
/* 3843 */         int j = getBatchSize();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3848 */         if (j <= 0)
/*      */         {
/*      */ 
/*      */ 
/* 3852 */           return new int[0];
/*      */         }
/*      */         
/* 3855 */         int[] arrayOfInt = new int[j];
/*      */         
/* 3857 */         ensureOpen();
/*      */         
/*      */ 
/* 3860 */         prepareForNewResults(true, true);
/*      */         
/* 3862 */         int k = this.numberOfDefinePositions;
/* 3863 */         String str = this.sqlObject.getOriginalSql();
/* 3864 */         byte b = this.sqlKind;
/*      */         
/*      */ 
/* 3867 */         this.noMoreUpdateCounts = false;
/*      */         
/* 3869 */         int m = 0;
/*      */         
/*      */         try
/*      */         {
/* 3873 */           this.connection.needLine();
/*      */           
/* 3875 */           for (i = 0; i < j; i++)
/*      */           {
/* 3877 */             this.sqlObject.initialize(getBatchItem(i));
/*      */             
/* 3879 */             this.sqlKind = this.sqlObject.getSqlKind();
/*      */             
/* 3881 */             this.needToParse = true;
/* 3882 */             this.numberOfDefinePositions = 0;
/*      */             
/*      */ 
/* 3885 */             this.rowsProcessed = 0;
/* 3886 */             this.currentRank = 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 3891 */             if (this.sqlKind == 0)
/*      */             {
/* 3893 */               DatabaseError.throwBatchUpdateException(80, "invalid SELECT batch command " + i, i, arrayOfInt);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 3899 */             if (!this.isOpen)
/*      */             {
/* 3901 */               this.connection.open(this);
/*      */               
/* 3903 */               this.isOpen = true;
/*      */             }
/*      */             
/* 3906 */             int n = -1;
/*      */             
/*      */             try
/*      */             {
/* 3910 */               if (this.queryTimeout != 0) {
/* 3911 */                 this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */               }
/* 3913 */               this.isExecuting = true;
/*      */               
/* 3915 */               executeForRows(false);
/*      */               
/* 3917 */               if (this.validRows > 0) {
/* 3918 */                 m += this.validRows;
/*      */               }
/* 3920 */               n = this.validRows;
/*      */             }
/*      */             catch (SQLException localSQLException2)
/*      */             {
/* 3924 */               this.needToParse = true;
/* 3925 */               throw localSQLException2;
/*      */             }
/*      */             finally
/*      */             {
/* 3929 */               if (this.queryTimeout != 0) {
/* 3930 */                 this.connection.getTimeout().cancelTimeout();
/*      */               }
/* 3932 */               this.validRows = m;
/*      */               
/* 3934 */               checkValidRowsStatus();
/*      */               
/* 3936 */               this.isExecuting = false;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 3942 */             arrayOfInt[i] = n;
/*      */             
/* 3944 */             if (arrayOfInt[i] < 0)
/*      */             {
/* 3946 */               DatabaseError.throwBatchUpdateException(81, "command return value " + arrayOfInt[i], i, arrayOfInt);
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         catch (SQLException localSQLException1)
/*      */         {
/* 3955 */           if ((localSQLException1 instanceof BatchUpdateException))
/*      */           {
/* 3957 */             throw localSQLException1;
/*      */           }
/*      */           
/*      */ 
/* 3961 */           DatabaseError.throwBatchUpdateException(81, localSQLException1.getMessage(), i, arrayOfInt);
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/* 3968 */           clearBatchItems();
/*      */           
/* 3970 */           this.numberOfDefinePositions = k;
/*      */           
/* 3972 */           if (str != null)
/*      */           {
/* 3974 */             this.sqlObject.initialize(str);
/*      */             
/* 3976 */             this.sqlKind = b;
/*      */           }
/*      */           
/* 3979 */           this.currentRank = 0;
/*      */         }
/*      */         
/* 3982 */         return arrayOfInt;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int copyBinds(Statement paramStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4002 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyCloseRset()
/*      */     throws SQLException
/*      */   {
/* 4011 */     this.scrollRset = null;
/*      */     
/* 4013 */     endOfResultSet(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getOriginalSql()
/*      */     throws SQLException
/*      */   {
/* 4021 */     return this.sqlObject.getOriginalSql();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doScrollExecuteCommon()
/*      */     throws SQLException
/*      */   {
/* 4029 */     if (this.scrollRset != null)
/*      */     {
/* 4031 */       this.scrollRset.close();
/*      */       
/* 4033 */       this.scrollRset = null;
/*      */     }
/*      */     
/*      */ 
/* 4037 */     if (this.sqlKind != 0)
/*      */     {
/* 4039 */       doExecuteWithTimeout();
/*      */       
/* 4041 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4047 */     if (!this.needToAddIdentifier)
/*      */     {
/*      */ 
/*      */ 
/* 4051 */       doExecuteWithTimeout();
/*      */       
/* 4053 */       this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4054 */       this.realRsetType = this.userRsetType;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/* 4062 */         this.sqlObject.setIncludeRowid(true);
/*      */         
/* 4064 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4073 */         prepareForNewResults(true, false);
/*      */         
/* 4075 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4077 */           Accessor[] arrayOfAccessor = this.accessors;
/*      */           
/* 4079 */           if ((this.accessors == null) || (this.accessors.length <= this.numberOfDefinePositions)) {
/* 4080 */             this.accessors = new Accessor[this.numberOfDefinePositions + 1];
/*      */           }
/* 4082 */           if (arrayOfAccessor != null) {
/* 4083 */             for (i = this.numberOfDefinePositions; i > 0; i--)
/*      */             {
/* 4085 */               localAccessor = arrayOfAccessor[(i - 1)];
/*      */               
/* 4087 */               this.accessors[i] = localAccessor;
/*      */               
/* 4089 */               if (localAccessor.isColumnNumberAware)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 4094 */                 localAccessor.updateColumnNumber(i);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 4099 */           allocateRowidAccessor();
/*      */           
/* 4101 */           this.numberOfDefinePositions += 1;
/*      */         }
/*      */         
/* 4104 */         doExecuteWithTimeout();
/*      */         
/* 4106 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4107 */         this.realRsetType = this.userRsetType;
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*      */         int i;
/*      */         
/*      */ 
/*      */         Accessor localAccessor;
/*      */         
/*      */ 
/* 4117 */         if (this.userRsetType > 3) {
/* 4118 */           this.realRsetType = 3;
/*      */         } else {
/* 4120 */           this.realRsetType = 1;
/*      */         }
/* 4122 */         this.sqlObject.setIncludeRowid(false);
/*      */         
/* 4124 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4133 */         prepareForNewResults(true, false);
/*      */         
/* 4135 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4137 */           this.needToPrepareDefineBuffer = true;
/* 4138 */           this.numberOfDefinePositions -= 1;
/*      */           
/* 4140 */           System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions);
/*      */           
/* 4142 */           this.accessors[this.numberOfDefinePositions] = null;
/*      */           
/* 4144 */           for (i = 0; i < this.numberOfDefinePositions; i++)
/*      */           {
/* 4146 */             localAccessor = this.accessors[i];
/*      */             
/* 4148 */             if (localAccessor.isColumnNumberAware)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 4153 */               localAccessor.updateColumnNumber(i);
/*      */             }
/*      */           }
/*      */         }
/* 4157 */         doExecuteWithTimeout();
/*      */         
/* 4159 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4160 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, localSQLException.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4168 */     this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/* 4180 */     this.accessors[0] = new RowidAccessor(this, 128, 1, -8, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleResultSet doScrollStmtExecuteQuery()
/*      */     throws SQLException
/*      */   {
/* 4191 */     doScrollExecuteCommon();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4196 */     return this.scrollRset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void processDmlReturningBind()
/*      */     throws SQLException
/*      */   {
/* 4204 */     if (this.returnResultSet != null) { this.returnResultSet.close();
/*      */     }
/* 4206 */     this.returnParamsFetched = false;
/* 4207 */     this.returnParamRowBytes = 0;
/* 4208 */     this.returnParamRowChars = 0;
/*      */     
/* 4210 */     int i = 0;
/* 4211 */     for (int j = 0; j < this.numberOfBindPositions; j++)
/*      */     {
/* 4213 */       Accessor localAccessor = this.returnParamAccessors[j];
/*      */       
/* 4215 */       if (localAccessor != null)
/*      */       {
/* 4217 */         i++;
/*      */         
/* 4219 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4221 */           this.returnParamRowChars += localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4225 */           this.returnParamRowBytes += localAccessor.byteLength;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4230 */     if (this.isAutoGeneratedKey)
/*      */     {
/* 4232 */       this.numReturnParams = i;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 4237 */       if (this.numReturnParams <= 0) {
/* 4238 */         this.numReturnParams = OraclePreparedStatement.getReturnParameterCount(this.sqlObject.getOriginalSql());
/*      */       }
/*      */       
/* 4241 */       if (this.numReturnParams != i) {
/* 4242 */         DatabaseError.throwSqlException(173);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4247 */     this.returnParamMeta[0] = this.numReturnParams;
/* 4248 */     this.returnParamMeta[1] = this.returnParamRowBytes;
/* 4249 */     this.returnParamMeta[2] = this.returnParamRowChars;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateDmlReturnStorage()
/*      */   {
/* 4255 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4257 */     int i = this.returnParamRowBytes * this.rowsDmlReturned;
/* 4258 */     int j = this.returnParamRowChars * this.rowsDmlReturned;
/* 4259 */     int k = 2 * this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4261 */     this.returnParamBytes = new byte[i];
/* 4262 */     this.returnParamChars = new char[j];
/* 4263 */     this.returnParamIndicators = new short[k];
/*      */     
/*      */ 
/* 4266 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 4268 */       Accessor localAccessor = this.returnParamAccessors[m];
/*      */       
/*      */ 
/* 4271 */       if ((localAccessor != null) && ((localAccessor.internalType == 111) || (localAccessor.internalType == 109)))
/*      */       {
/*      */ 
/*      */ 
/* 4275 */         TypeAccessor localTypeAccessor = (TypeAccessor)localAccessor;
/* 4276 */         if ((localTypeAccessor.pickledBytes == null) || (localTypeAccessor.pickledBytes.length < this.rowsDmlReturned))
/*      */         {
/* 4278 */           localTypeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetchDmlReturnParams()
/*      */     throws SQLException
/*      */   {
/* 4291 */     DatabaseError.throwSqlException(23);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setupReturnParamAccessors()
/*      */   {
/* 4300 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4302 */     int i = 0;
/* 4303 */     int j = 0;
/* 4304 */     int k = 0;
/* 4305 */     int m = this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4307 */     for (int n = 0; n < this.numberOfBindPositions; n++)
/*      */     {
/* 4309 */       Accessor localAccessor = this.returnParamAccessors[n];
/*      */       
/* 4311 */       if (localAccessor != null)
/*      */       {
/* 4313 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4315 */           localAccessor.rowSpaceChar = this.returnParamChars;
/* 4316 */           localAccessor.columnIndex = j;
/* 4317 */           j += this.rowsDmlReturned * localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4321 */           localAccessor.rowSpaceByte = this.returnParamBytes;
/* 4322 */           localAccessor.columnIndex = i;
/* 4323 */           i += this.rowsDmlReturned * localAccessor.byteLength;
/*      */         }
/*      */         
/* 4326 */         localAccessor.rowSpaceIndicator = this.returnParamIndicators;
/* 4327 */         localAccessor.indicatorIndex = k;
/* 4328 */         k += this.rowsDmlReturned;
/* 4329 */         localAccessor.lengthIndex = m;
/* 4330 */         m += this.rowsDmlReturned;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4344 */     if (this.returnParamAccessors == null) {
/* 4345 */       this.returnParamAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/* 4347 */     if (this.returnParamMeta == null)
/*      */     {
/* 4349 */       this.returnParamMeta = new int[3 + this.numberOfBindPositions * 3];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4354 */     Accessor localAccessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4362 */     localAccessor.isDMLReturnedParam = true;
/* 4363 */     this.returnParamAccessors[paramInt1] = localAccessor;
/*      */     
/* 4365 */     int i = localAccessor.charLength > 0 ? 1 : 0;
/*      */     
/*      */ 
/* 4368 */     this.returnParamMeta[(3 + paramInt1 * 3 + 0)] = localAccessor.defineType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4373 */     this.returnParamMeta[(3 + paramInt1 * 3 + 1)] = (i != 0 ? 1 : 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4378 */     this.returnParamMeta[(3 + paramInt1 * 3 + 2)] = (i != 0 ? localAccessor.charLength : localAccessor.byteLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoRefetch(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4406 */     this.autoRefetch = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutoRefetch()
/*      */     throws SQLException
/*      */   {
/* 4421 */     return this.autoRefetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized int creationState()
/*      */   {
/* 4438 */     return this.creationState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isColumnSetNull(int paramInt)
/*      */   {
/* 4454 */     return this.columnSetNull;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4470 */     if (!this.described) {
/* 4471 */       describe();
/*      */     }
/* 4473 */     int i = paramInt - 1;
/* 4474 */     if ((i < 0) || (i >= this.numberOfDefinePositions)) {
/* 4475 */       DatabaseError.throwSqlException(3);
/*      */     }
/* 4477 */     boolean bool = this.accessors[i].formOfUse == 2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4483 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addChild(OracleStatement paramOracleStatement)
/*      */   {
/* 4493 */     paramOracleStatement.nextChild = this.children;
/* 4494 */     this.children = paramOracleStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4531 */     DatabaseError.throwUnsupportedFeatureSqlException();
/*      */     
/*      */ 
/*      */ 
/* 4535 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/* 4559 */     if (this.closed) {
/* 4560 */       DatabaseError.throwSqlException(9);
/*      */     }
/* 4562 */     if (!this.isAutoGeneratedKey) {
/* 4563 */       DatabaseError.throwSqlException(90);
/*      */     }
/* 4565 */     if ((this.returnParamAccessors == null) || (this.numReturnParams == 0)) {
/* 4566 */       DatabaseError.throwSqlException(144);
/*      */     }
/* 4568 */     if (this.returnResultSet == null)
/*      */     {
/* 4570 */       this.returnResultSet = new OracleReturnResultSet(this);
/*      */     }
/*      */     
/* 4573 */     return this.returnResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4606 */     if ((paramInt == 2) || (!AutoKeyInfo.isInsertSqlStmt(paramString)))
/*      */     {
/* 4608 */       return executeUpdate(paramString);
/*      */     }
/* 4610 */     if (paramInt != 1) {
/* 4611 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4613 */     synchronized (this.connection)
/*      */     {
/* 4615 */       synchronized (this)
/*      */       {
/* 4617 */         this.isAutoGeneratedKey = true;
/* 4618 */         this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 4619 */         String str = this.autoKeyInfo.getNewSql();
/* 4620 */         this.numberOfBindPositions = 1;
/*      */         
/*      */ 
/* 4623 */         autoKeyRegisterReturnParams();
/*      */         
/* 4625 */         processDmlReturningBind();
/*      */         
/* 4627 */         return executeUpdateInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 4657 */     if (!AutoKeyInfo.isInsertSqlStmt(paramString)) { return executeUpdate(paramString);
/*      */     }
/* 4659 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0)) {
/* 4660 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4662 */     synchronized (this.connection)
/*      */     {
/* 4664 */       synchronized (this)
/*      */       {
/* 4666 */         this.isAutoGeneratedKey = true;
/* 4667 */         this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/*      */         
/*      */ 
/* 4670 */         this.connection.doDescribeTable(this.autoKeyInfo);
/*      */         
/* 4672 */         String str = this.autoKeyInfo.getNewSql();
/* 4673 */         this.numberOfBindPositions = paramArrayOfInt.length;
/*      */         
/*      */ 
/* 4676 */         autoKeyRegisterReturnParams();
/*      */         
/* 4678 */         processDmlReturningBind();
/*      */         
/* 4680 */         return executeUpdateInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 4709 */     if (!AutoKeyInfo.isInsertSqlStmt(paramString)) { return executeUpdate(paramString);
/*      */     }
/* 4711 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0)) {
/* 4712 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4714 */     synchronized (this.connection)
/*      */     {
/* 4716 */       synchronized (this)
/*      */       {
/* 4718 */         this.isAutoGeneratedKey = true;
/* 4719 */         this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*      */         
/*      */ 
/* 4722 */         this.connection.doDescribeTable(this.autoKeyInfo);
/*      */         
/* 4724 */         String str = this.autoKeyInfo.getNewSql();
/* 4725 */         this.numberOfBindPositions = paramArrayOfString.length;
/*      */         
/*      */ 
/* 4728 */         autoKeyRegisterReturnParams();
/*      */         
/* 4730 */         processDmlReturningBind();
/*      */         
/* 4732 */         return executeUpdateInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4780 */     if ((paramInt == 2) || (!AutoKeyInfo.isInsertSqlStmt(paramString)))
/*      */     {
/* 4782 */       return execute(paramString);
/*      */     }
/* 4784 */     if (paramInt != 1) {
/* 4785 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4787 */     synchronized (this.connection)
/*      */     {
/* 4789 */       synchronized (this)
/*      */       {
/* 4791 */         this.isAutoGeneratedKey = true;
/* 4792 */         this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 4793 */         String str = this.autoKeyInfo.getNewSql();
/* 4794 */         this.numberOfBindPositions = 1;
/*      */         
/*      */ 
/* 4797 */         autoKeyRegisterReturnParams();
/*      */         
/* 4799 */         processDmlReturningBind();
/*      */         
/* 4801 */         return executeInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 4848 */     if (!AutoKeyInfo.isInsertSqlStmt(paramString)) { return execute(paramString);
/*      */     }
/* 4850 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0)) {
/* 4851 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4853 */     synchronized (this.connection)
/*      */     {
/* 4855 */       synchronized (this)
/*      */       {
/* 4857 */         this.isAutoGeneratedKey = true;
/* 4858 */         this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/*      */         
/*      */ 
/* 4861 */         this.connection.doDescribeTable(this.autoKeyInfo);
/*      */         
/* 4863 */         String str = this.autoKeyInfo.getNewSql();
/* 4864 */         this.numberOfBindPositions = paramArrayOfInt.length;
/*      */         
/*      */ 
/* 4867 */         autoKeyRegisterReturnParams();
/*      */         
/* 4869 */         processDmlReturningBind();
/*      */         
/* 4871 */         return executeInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 4919 */     if (!AutoKeyInfo.isInsertSqlStmt(paramString)) { return execute(paramString);
/*      */     }
/* 4921 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0)) {
/* 4922 */       DatabaseError.throwSqlException(68);
/*      */     }
/* 4924 */     synchronized (this.connection)
/*      */     {
/* 4926 */       synchronized (this)
/*      */       {
/* 4928 */         this.isAutoGeneratedKey = true;
/* 4929 */         this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*      */         
/*      */ 
/* 4932 */         this.connection.doDescribeTable(this.autoKeyInfo);
/*      */         
/* 4934 */         String str = this.autoKeyInfo.getNewSql();
/* 4935 */         this.numberOfBindPositions = paramArrayOfString.length;
/*      */         
/*      */ 
/* 4938 */         autoKeyRegisterReturnParams();
/*      */         
/* 4940 */         processDmlReturningBind();
/*      */         
/* 4942 */         return executeInternal(str);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 4965 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getcacheState()
/*      */   {
/* 4973 */     return this.cacheState;
/*      */   }
/*      */   
/*      */   public int getstatementType()
/*      */   {
/* 4978 */     return this.statementType;
/*      */   }
/*      */   
/*      */   public boolean getserverCursor()
/*      */   {
/* 4983 */     return this.serverCursor;
/*      */   }
/*      */   
/*      */ 
/*      */   void initializeIndicatorSubRange()
/*      */   {
/* 4989 */     this.bindIndicatorSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autoKeyRegisterReturnParams()
/*      */     throws SQLException
/*      */   {
/* 4998 */     initializeIndicatorSubRange();
/*      */     
/* 5000 */     int i = this.bindIndicatorSubRange + 3 + this.numberOfBindPositions * 10;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5006 */     int j = i + 2 * this.numberOfBindPositions;
/*      */     
/*      */ 
/*      */ 
/* 5010 */     this.bindIndicators = new short[j];
/*      */     
/* 5012 */     int k = this.bindIndicatorSubRange;
/*      */     
/* 5014 */     this.bindIndicators[(k + 0)] = ((short)this.numberOfBindPositions);
/*      */     
/*      */ 
/*      */ 
/* 5018 */     this.bindIndicators[(k + 1)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5022 */     this.bindIndicators[(k + 2)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5026 */     k += 3;
/*      */     
/*      */ 
/* 5029 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 5030 */     int[] arrayOfInt = this.autoKeyInfo.columnIndexes;
/*      */     
/* 5032 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 5034 */       this.bindIndicators[(k + 0)] = 994;
/*      */       
/*      */ 
/*      */ 
/* 5038 */       short s = 0;
/*      */       
/* 5040 */       if ((arrayOfShort != null) && (arrayOfInt != null))
/*      */       {
/* 5042 */         if (arrayOfShort[(arrayOfInt[m] - 1)] == 2)
/*      */         {
/*      */ 
/* 5045 */           s = 2;
/* 5046 */           this.bindIndicators[(k + 9)] = s;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5052 */       k += 10;
/*      */       
/*      */ 
/* 5055 */       checkTypeForAutoKey(this.autoKeyInfo.returnTypes[m]);
/*      */       
/* 5057 */       String str = null;
/* 5058 */       if (this.autoKeyInfo.returnTypes[m] == 111) {
/* 5059 */         str = this.autoKeyInfo.tableTypeNames[(arrayOfInt[m] - 1)];
/*      */       }
/*      */       
/* 5062 */       registerReturnParameterInternal(m, this.autoKeyInfo.returnTypes[m], this.autoKeyInfo.returnTypes[m], -1, s, str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final void setNonAutoKey()
/*      */   {
/* 5070 */     this.isAutoGeneratedKey = false;
/* 5071 */     this.numberOfBindPositions = 0;
/* 5072 */     this.bindIndicators = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void checkTypeForAutoKey(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5092 */     if (paramInt == 109) {
/* 5093 */       DatabaseError.throwSqlException(5);
/*      */     }
/*      */   }
/*      */   
/* 5097 */   ArrayList tempClobsToFree = null;
/* 5098 */   ArrayList tempBlobsToFree = null;
/*      */   
/* 5100 */   ArrayList oldTempClobsToFree = null;
/* 5101 */   ArrayList oldTempBlobsToFree = null;
/*      */   
/*      */   void addToTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5105 */     if (this.tempClobsToFree == null)
/* 5106 */       this.tempClobsToFree = new ArrayList();
/* 5107 */     this.tempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */   void addToTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5112 */     if (this.tempBlobsToFree == null)
/* 5113 */       this.tempBlobsToFree = new ArrayList();
/* 5114 */     this.tempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */   void addToOldTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5119 */     if (this.oldTempClobsToFree == null)
/* 5120 */       this.oldTempClobsToFree = new ArrayList();
/* 5121 */     this.oldTempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */   void addToOldTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5126 */     if (this.oldTempBlobsToFree == null)
/* 5127 */       this.oldTempBlobsToFree = new ArrayList();
/* 5128 */     this.oldTempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */   void cleanAllTempLobs()
/*      */   {
/* 5133 */     cleanTempClobs(this.tempClobsToFree);
/* 5134 */     this.tempClobsToFree = null;
/* 5135 */     cleanTempBlobs(this.tempBlobsToFree);
/* 5136 */     this.tempBlobsToFree = null;
/* 5137 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5138 */     this.oldTempClobsToFree = null;
/* 5139 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5140 */     this.oldTempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanOldTempLobs()
/*      */   {
/* 5148 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5149 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5150 */     this.oldTempClobsToFree = this.tempClobsToFree;
/* 5151 */     this.tempClobsToFree = null;
/* 5152 */     this.oldTempBlobsToFree = this.tempBlobsToFree;
/* 5153 */     this.tempBlobsToFree = null;
/*      */   }
/*      */   
/*      */   void cleanTempClobs(ArrayList paramArrayList)
/*      */   {
/* 5158 */     if (paramArrayList != null)
/*      */     {
/* 5160 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5162 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5166 */           ((CLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanTempBlobs(ArrayList paramArrayList)
/*      */   {
/* 5180 */     if (paramArrayList != null)
/*      */     {
/* 5182 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5184 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5188 */           ((BLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   TimeZone getDefaultTimeZone()
/*      */   {
/* 5201 */     if (this.defaultTZ == null) {
/* 5202 */       this.defaultTZ = TimeZone.getDefault();
/*      */     }
/* 5204 */     return this.defaultTZ;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 5209 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */   public static final boolean PRIVATE_TRACE = false;
/*      */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:29_PST_2006";
/*      */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\OracleStatement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */