/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIfob
/*    */   extends T4CTTIMsg
/*    */ {
/*    */   T4CTTIfob(T4CMAREngine paramT4CMAREngine)
/*    */     throws IOException, SQLException
/*    */   {
/* 37 */     super((byte)19);
/* 38 */     setMarshalingEngine(paramT4CMAREngine);
/*    */   }
/*    */   
/*    */   void marshal() throws IOException, SQLException
/*    */   {
/* 43 */     this.meg.marshalUB1((short)19);
/*    */   }
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4CTTIfob.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */