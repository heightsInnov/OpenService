package oracle.jdbc.driver;

public abstract interface OracleResultSetCache
  extends oracle.jdbc.internal.OracleResultSetCache
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\OracleResultSetCache.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */