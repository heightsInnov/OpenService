/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4CTTIoses
/*    */   extends T4CTTIfun
/*    */ {
/*    */   static final int OSESSWS = 1;
/*    */   static final int OSESDET = 3;
/*    */   
/*    */   T4CTTIoses(T4CMAREngine paramT4CMAREngine)
/*    */     throws IOException, SQLException
/*    */   {
/* 47 */     super((byte)17, 0);
/*    */     
/* 49 */     setMarshalingEngine(paramT4CMAREngine);
/* 50 */     setFunCode((short)107);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   void marshal(int paramInt1, int paramInt2, int paramInt3)
/*    */     throws IOException, SQLException
/*    */   {
/* 61 */     if ((paramInt3 != 1) && (paramInt3 != 3)) {
/* 62 */       throw new SQLException("Wrong operation : can only do switch or detach");
/*    */     }
/* 64 */     marshalFunHeader();
/* 65 */     this.meg.marshalUB4(paramInt1);
/* 66 */     this.meg.marshalUB4(paramInt2);
/* 67 */     this.meg.marshalUB4(paramInt3);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 75 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:32_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4CTTIoses.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */