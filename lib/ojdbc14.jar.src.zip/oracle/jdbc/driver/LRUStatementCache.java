/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LRUStatementCache
/*     */ {
/*     */   private int cacheSize;
/*     */   private int numElements;
/*     */   private OracleStatementCacheEntry applicationCacheStart;
/*     */   private OracleStatementCacheEntry applicationCacheEnd;
/*     */   private OracleStatementCacheEntry implicitCacheStart;
/*     */   private OracleStatementCacheEntry explicitCacheStart;
/*     */   boolean implicitCacheEnabled;
/*     */   boolean explicitCacheEnabled;
/*  50 */   private boolean debug = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LRUStatementCache(int paramInt)
/*     */     throws SQLException
/*     */   {
/*  69 */     if (paramInt < 0) {
/*  70 */       DatabaseError.throwSqlException(123);
/*     */     }
/*  72 */     this.cacheSize = paramInt;
/*  73 */     this.numElements = 0;
/*     */     
/*  75 */     this.implicitCacheStart = null;
/*  76 */     this.explicitCacheStart = null;
/*     */     
/*  78 */     this.implicitCacheEnabled = false;
/*  79 */     this.explicitCacheEnabled = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void resize(int paramInt)
/*     */     throws SQLException
/*     */   {
/*  99 */     if (paramInt < 0) {
/* 100 */       DatabaseError.throwSqlException(123);
/*     */     }
/* 102 */     if ((paramInt >= this.cacheSize) || (paramInt >= this.numElements))
/*     */     {
/*     */ 
/* 105 */       this.cacheSize = paramInt;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 111 */       for (OracleStatementCacheEntry localOracleStatementCacheEntry = this.applicationCacheEnd; 
/* 112 */           this.numElements > paramInt; localOracleStatementCacheEntry = localOracleStatementCacheEntry.applicationPrev) {
/* 113 */         purgeCacheEntry(localOracleStatementCacheEntry);
/*     */       }
/* 115 */       this.cacheSize = paramInt;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImplicitCachingEnabled(boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/* 138 */     if (!paramBoolean) {
/* 139 */       purgeImplicitCache();
/*     */     }
/* 141 */     this.implicitCacheEnabled = paramBoolean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getImplicitCachingEnabled()
/*     */     throws SQLException
/*     */   {
/*     */     boolean bool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 156 */     if (this.cacheSize == 0) {
/* 157 */       bool = false;
/*     */     } else {
/* 159 */       bool = this.implicitCacheEnabled;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 164 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExplicitCachingEnabled(boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/* 183 */     if (!paramBoolean) {
/* 184 */       purgeExplicitCache();
/*     */     }
/* 186 */     this.explicitCacheEnabled = paramBoolean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getExplicitCachingEnabled()
/*     */     throws SQLException
/*     */   {
/*     */     boolean bool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 201 */     if (this.cacheSize == 0) {
/* 202 */       bool = false;
/*     */     } else {
/* 204 */       bool = this.explicitCacheEnabled;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 209 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addToImplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 233 */     if ((!this.implicitCacheEnabled) || (this.cacheSize == 0) || (paramOraclePreparedStatement.cacheState == 2))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */       return;
/*     */     }
/*     */     
/*     */ 
/* 245 */     if (this.numElements == this.cacheSize) {
/* 246 */       purgeCacheEntry(this.applicationCacheEnd);
/*     */     }
/*     */     
/*     */ 
/* 250 */     paramOraclePreparedStatement.enterImplicitCache();
/*     */     
/*     */ 
/* 253 */     OracleStatementCacheEntry localOracleStatementCacheEntry = new OracleStatementCacheEntry();
/*     */     
/* 255 */     localOracleStatementCacheEntry.statement = paramOraclePreparedStatement;
/* 256 */     localOracleStatementCacheEntry.onImplicit = true;
/*     */     
/* 258 */     localOracleStatementCacheEntry.sql = paramString;
/* 259 */     localOracleStatementCacheEntry.statementType = paramInt1;
/* 260 */     localOracleStatementCacheEntry.scrollType = paramInt2;
/*     */     
/*     */ 
/* 263 */     localOracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
/* 264 */     localOracleStatementCacheEntry.applicationPrev = null;
/*     */     
/* 266 */     if (this.applicationCacheStart != null) {
/* 267 */       this.applicationCacheStart.applicationPrev = localOracleStatementCacheEntry;
/*     */     }
/* 269 */     this.applicationCacheStart = localOracleStatementCacheEntry;
/*     */     
/* 271 */     localOracleStatementCacheEntry.implicitNext = this.implicitCacheStart;
/* 272 */     localOracleStatementCacheEntry.implicitPrev = null;
/*     */     
/* 274 */     if (this.implicitCacheStart != null) {
/* 275 */       this.implicitCacheStart.implicitPrev = localOracleStatementCacheEntry;
/*     */     }
/* 277 */     this.implicitCacheStart = localOracleStatementCacheEntry;
/*     */     
/*     */ 
/* 280 */     if (this.applicationCacheEnd == null) {
/* 281 */       this.applicationCacheEnd = localOracleStatementCacheEntry;
/*     */     }
/*     */     
/*     */ 
/* 285 */     this.numElements += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addToExplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString)
/*     */     throws SQLException
/*     */   {
/* 306 */     if ((!this.explicitCacheEnabled) || (this.cacheSize == 0) || (paramOraclePreparedStatement.cacheState == 2))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */       return;
/*     */     }
/*     */     
/*     */ 
/* 318 */     if (this.numElements == this.cacheSize) {
/* 319 */       purgeCacheEntry(this.applicationCacheEnd);
/*     */     }
/*     */     
/*     */ 
/* 323 */     paramOraclePreparedStatement.enterExplicitCache();
/*     */     
/*     */ 
/* 326 */     OracleStatementCacheEntry localOracleStatementCacheEntry = new OracleStatementCacheEntry();
/*     */     
/* 328 */     localOracleStatementCacheEntry.statement = paramOraclePreparedStatement;
/* 329 */     localOracleStatementCacheEntry.sql = paramString;
/* 330 */     localOracleStatementCacheEntry.onImplicit = false;
/*     */     
/*     */ 
/* 333 */     localOracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
/* 334 */     localOracleStatementCacheEntry.applicationPrev = null;
/*     */     
/* 336 */     if (this.applicationCacheStart != null) {
/* 337 */       this.applicationCacheStart.applicationPrev = localOracleStatementCacheEntry;
/*     */     }
/* 339 */     this.applicationCacheStart = localOracleStatementCacheEntry;
/*     */     
/* 341 */     localOracleStatementCacheEntry.explicitNext = this.explicitCacheStart;
/* 342 */     localOracleStatementCacheEntry.explicitPrev = null;
/*     */     
/* 344 */     if (this.explicitCacheStart != null) {
/* 345 */       this.explicitCacheStart.explicitPrev = localOracleStatementCacheEntry;
/*     */     }
/* 347 */     this.explicitCacheStart = localOracleStatementCacheEntry;
/*     */     
/*     */ 
/* 350 */     if (this.applicationCacheEnd == null) {
/* 351 */       this.applicationCacheEnd = localOracleStatementCacheEntry;
/*     */     }
/*     */     
/*     */ 
/* 355 */     this.numElements += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleStatement searchImplicitCache(String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 381 */     if (!this.implicitCacheEnabled)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 387 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 391 */     OracleStatementCacheEntry localOracleStatementCacheEntry = null;
/*     */     
/* 393 */     for (localOracleStatementCacheEntry = this.implicitCacheStart; localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.implicitNext)
/*     */     {
/* 395 */       if ((localOracleStatementCacheEntry.statementType == paramInt1) && (localOracleStatementCacheEntry.scrollType == paramInt2) && (localOracleStatementCacheEntry.sql.equals(paramString))) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 400 */     if (localOracleStatementCacheEntry != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 411 */       if (localOracleStatementCacheEntry.applicationPrev != null) {
/* 412 */         localOracleStatementCacheEntry.applicationPrev.applicationNext = localOracleStatementCacheEntry.applicationNext;
/*     */       }
/* 414 */       if (localOracleStatementCacheEntry.applicationNext != null) {
/* 415 */         localOracleStatementCacheEntry.applicationNext.applicationPrev = localOracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 417 */       if (this.applicationCacheStart == localOracleStatementCacheEntry) {
/* 418 */         this.applicationCacheStart = localOracleStatementCacheEntry.applicationNext;
/*     */       }
/* 420 */       if (this.applicationCacheEnd == localOracleStatementCacheEntry) {
/* 421 */         this.applicationCacheEnd = localOracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 423 */       if (localOracleStatementCacheEntry.implicitPrev != null) {
/* 424 */         localOracleStatementCacheEntry.implicitPrev.implicitNext = localOracleStatementCacheEntry.implicitNext;
/*     */       }
/* 426 */       if (localOracleStatementCacheEntry.implicitNext != null) {
/* 427 */         localOracleStatementCacheEntry.implicitNext.implicitPrev = localOracleStatementCacheEntry.implicitPrev;
/*     */       }
/* 429 */       if (this.implicitCacheStart == localOracleStatementCacheEntry) {
/* 430 */         this.implicitCacheStart = localOracleStatementCacheEntry.implicitNext;
/*     */       }
/*     */       
/*     */ 
/* 434 */       this.numElements -= 1;
/*     */       
/*     */ 
/* 437 */       localOracleStatementCacheEntry.statement.exitImplicitCacheToActive();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 444 */       return localOracleStatementCacheEntry.statement;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 457 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleStatement searchExplicitCache(String paramString)
/*     */     throws SQLException
/*     */   {
/* 477 */     if (!this.explicitCacheEnabled)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 483 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 487 */     OracleStatementCacheEntry localOracleStatementCacheEntry = null;
/*     */     
/* 489 */     for (localOracleStatementCacheEntry = this.explicitCacheStart; localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.explicitNext)
/*     */     {
/* 491 */       if (localOracleStatementCacheEntry.sql.equals(paramString)) {
/*     */         break;
/*     */       }
/*     */     }
/* 495 */     if (localOracleStatementCacheEntry != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 506 */       if (localOracleStatementCacheEntry.applicationPrev != null) {
/* 507 */         localOracleStatementCacheEntry.applicationPrev.applicationNext = localOracleStatementCacheEntry.applicationNext;
/*     */       }
/* 509 */       if (localOracleStatementCacheEntry.applicationNext != null) {
/* 510 */         localOracleStatementCacheEntry.applicationNext.applicationPrev = localOracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 512 */       if (this.applicationCacheStart == localOracleStatementCacheEntry) {
/* 513 */         this.applicationCacheStart = localOracleStatementCacheEntry.applicationNext;
/*     */       }
/* 515 */       if (this.applicationCacheEnd == localOracleStatementCacheEntry) {
/* 516 */         this.applicationCacheEnd = localOracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 518 */       if (localOracleStatementCacheEntry.explicitPrev != null) {
/* 519 */         localOracleStatementCacheEntry.explicitPrev.explicitNext = localOracleStatementCacheEntry.explicitNext;
/*     */       }
/* 521 */       if (localOracleStatementCacheEntry.explicitNext != null) {
/* 522 */         localOracleStatementCacheEntry.explicitNext.explicitPrev = localOracleStatementCacheEntry.explicitPrev;
/*     */       }
/* 524 */       if (this.explicitCacheStart == localOracleStatementCacheEntry) {
/* 525 */         this.explicitCacheStart = localOracleStatementCacheEntry.explicitNext;
/*     */       }
/*     */       
/*     */ 
/* 529 */       this.numElements -= 1;
/*     */       
/*     */ 
/* 532 */       localOracleStatementCacheEntry.statement.exitExplicitCacheToActive();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 538 */       return localOracleStatementCacheEntry.statement;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 549 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void purgeImplicitCache()
/*     */     throws SQLException
/*     */   {
/* 566 */     for (OracleStatementCacheEntry localOracleStatementCacheEntry = this.implicitCacheStart; localOracleStatementCacheEntry != null; 
/* 567 */         localOracleStatementCacheEntry = localOracleStatementCacheEntry.implicitNext) {
/* 568 */       purgeCacheEntry(localOracleStatementCacheEntry);
/*     */     }
/* 570 */     this.implicitCacheStart = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void purgeExplicitCache()
/*     */     throws SQLException
/*     */   {
/* 587 */     for (OracleStatementCacheEntry localOracleStatementCacheEntry = this.explicitCacheStart; localOracleStatementCacheEntry != null; 
/* 588 */         localOracleStatementCacheEntry = localOracleStatementCacheEntry.explicitNext) {
/* 589 */       purgeCacheEntry(localOracleStatementCacheEntry);
/*     */     }
/* 591 */     this.explicitCacheStart = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void purgeCacheEntry(OracleStatementCacheEntry paramOracleStatementCacheEntry)
/*     */     throws SQLException
/*     */   {
/* 610 */     if (paramOracleStatementCacheEntry.applicationNext != null) {
/* 611 */       paramOracleStatementCacheEntry.applicationNext.applicationPrev = paramOracleStatementCacheEntry.applicationPrev;
/*     */     }
/* 613 */     if (paramOracleStatementCacheEntry.applicationPrev != null) {
/* 614 */       paramOracleStatementCacheEntry.applicationPrev.applicationNext = paramOracleStatementCacheEntry.applicationNext;
/*     */     }
/* 616 */     if (this.applicationCacheStart == paramOracleStatementCacheEntry) {
/* 617 */       this.applicationCacheStart = paramOracleStatementCacheEntry.applicationNext;
/*     */     }
/* 619 */     if (this.applicationCacheEnd == paramOracleStatementCacheEntry) {
/* 620 */       this.applicationCacheEnd = paramOracleStatementCacheEntry.applicationPrev;
/*     */     }
/* 622 */     if (paramOracleStatementCacheEntry.onImplicit)
/*     */     {
/* 624 */       if (paramOracleStatementCacheEntry.implicitNext != null) {
/* 625 */         paramOracleStatementCacheEntry.implicitNext.implicitPrev = paramOracleStatementCacheEntry.implicitPrev;
/*     */       }
/* 627 */       if (paramOracleStatementCacheEntry.implicitPrev != null) {
/* 628 */         paramOracleStatementCacheEntry.implicitPrev.implicitNext = paramOracleStatementCacheEntry.implicitNext;
/*     */       }
/* 630 */       if (this.implicitCacheStart == paramOracleStatementCacheEntry) {
/* 631 */         this.implicitCacheStart = paramOracleStatementCacheEntry.implicitNext;
/*     */       }
/*     */     }
/*     */     else {
/* 635 */       if (paramOracleStatementCacheEntry.explicitNext != null) {
/* 636 */         paramOracleStatementCacheEntry.explicitNext.explicitPrev = paramOracleStatementCacheEntry.explicitPrev;
/*     */       }
/* 638 */       if (paramOracleStatementCacheEntry.explicitPrev != null) {
/* 639 */         paramOracleStatementCacheEntry.explicitPrev.explicitNext = paramOracleStatementCacheEntry.explicitNext;
/*     */       }
/* 641 */       if (this.explicitCacheStart == paramOracleStatementCacheEntry) {
/* 642 */         this.explicitCacheStart = paramOracleStatementCacheEntry.explicitNext;
/*     */       }
/*     */     }
/*     */     
/* 646 */     this.numElements -= 1;
/*     */     
/*     */ 
/* 649 */     if (paramOracleStatementCacheEntry.onImplicit) {
/* 650 */       paramOracleStatementCacheEntry.statement.exitImplicitCacheToClose();
/*     */     } else {
/* 652 */       paramOracleStatementCacheEntry.statement.exitExplicitCacheToClose();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCacheSize()
/*     */   {
/* 665 */     return this.cacheSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printCache(String paramString)
/*     */     throws SQLException
/*     */   {
/* 681 */     System.out.println("*** Start of Statement Cache Dump (" + paramString + ") ***");
/* 682 */     System.out.println("cache size: " + this.cacheSize + " num elements: " + this.numElements + " implicit enabled: " + this.implicitCacheEnabled + " explicit enabled: " + this.explicitCacheEnabled);
/*     */     
/*     */ 
/*     */ 
/* 686 */     System.out.println("applicationStart: " + this.applicationCacheStart + "  applicationEnd: " + this.applicationCacheEnd);
/*     */     
/*     */ 
/* 689 */     for (OracleStatementCacheEntry localOracleStatementCacheEntry = this.applicationCacheStart; localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.applicationNext) {
/* 690 */       localOracleStatementCacheEntry.print();
/*     */     }
/* 692 */     System.out.println("implicitStart: " + this.implicitCacheStart);
/*     */     
/* 694 */     for (localOracleStatementCacheEntry = this.implicitCacheStart; localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.implicitNext) {
/* 695 */       localOracleStatementCacheEntry.print();
/*     */     }
/* 697 */     System.out.println("explicitStart: " + this.explicitCacheStart);
/*     */     
/* 699 */     for (localOracleStatementCacheEntry = this.explicitCacheStart; localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.explicitNext) {
/* 700 */       localOracleStatementCacheEntry.print();
/*     */     }
/* 702 */     System.out.println("*** End of Statement Cache Dump (" + paramString + ") ***");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 718 */     for (OracleStatementCacheEntry localOracleStatementCacheEntry = this.applicationCacheStart; 
/* 719 */         localOracleStatementCacheEntry != null; localOracleStatementCacheEntry = localOracleStatementCacheEntry.applicationNext)
/*     */     {
/*     */ 
/*     */ 
/* 723 */       if (localOracleStatementCacheEntry.onImplicit) {
/* 724 */         localOracleStatementCacheEntry.statement.exitImplicitCacheToClose();
/*     */       } else {
/* 726 */         localOracleStatementCacheEntry.statement.exitExplicitCacheToClose();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 732 */     this.applicationCacheStart = null;
/* 733 */     this.applicationCacheEnd = null;
/* 734 */     this.implicitCacheStart = null;
/* 735 */     this.explicitCacheStart = null;
/* 736 */     this.numElements = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 741 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:28_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\LRUStatementCache.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */