/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleBufferedStream
/*     */   extends InputStream
/*     */ {
/*     */   byte[] buf;
/*     */   int pos;
/*     */   int count;
/*     */   boolean closed;
/*     */   int chunkSize;
/*     */   OracleStatement statement;
/*     */   
/*     */   public OracleBufferedStream(int paramInt)
/*     */   {
/*  39 */     this.pos = 0;
/*  40 */     this.count = 0;
/*  41 */     this.closed = false;
/*  42 */     this.chunkSize = paramInt;
/*  43 */     this.buf = new byte[paramInt];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OracleBufferedStream(OracleStatement paramOracleStatement, int paramInt)
/*     */   {
/*  52 */     this(paramInt);
/*     */     
/*     */ 
/*     */ 
/*  56 */     this.statement = paramOracleStatement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  68 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needBytes()
/*     */     throws IOException
/*     */   {
/*  79 */     throw new IOException("You should not call this method");
/*     */   }
/*     */   
/*     */   public int flushBytes(int paramInt)
/*     */   {
/*  84 */     int i = paramInt > this.count - this.pos ? this.count - this.pos : paramInt;
/*     */     
/*  86 */     this.pos += i;
/*     */     
/*  88 */     return i;
/*     */   }
/*     */   
/*     */   public int writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/*  93 */     int i = paramInt2 > this.count - this.pos ? this.count - this.pos : paramInt2;
/*     */     
/*  95 */     System.arraycopy(this.buf, this.pos, paramArrayOfByte, paramInt1, i);
/*     */     
/*  97 */     this.pos += i;
/*     */     
/*  99 */     return i;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   4: ifnonnull +19 -> 23
/*     */     //   7: aload_0
/*     */     //   8: dup
/*     */     //   9: astore_1
/*     */     //   10: monitorenter
/*     */     //   11: aload_0
/*     */     //   12: invokespecial 13	oracle/jdbc/driver/OracleBufferedStream:readInternal	()I
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: ireturn
/*     */     //   18: astore_2
/*     */     //   19: aload_1
/*     */     //   20: monitorexit
/*     */     //   21: aload_2
/*     */     //   22: athrow
/*     */     //   23: aload_0
/*     */     //   24: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   27: getfield 14	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*     */     //   30: dup
/*     */     //   31: astore_1
/*     */     //   32: monitorenter
/*     */     //   33: aload_0
/*     */     //   34: dup
/*     */     //   35: astore_2
/*     */     //   36: monitorenter
/*     */     //   37: aload_0
/*     */     //   38: invokespecial 13	oracle/jdbc/driver/OracleBufferedStream:readInternal	()I
/*     */     //   41: aload_2
/*     */     //   42: monitorexit
/*     */     //   43: aload_1
/*     */     //   44: monitorexit
/*     */     //   45: ireturn
/*     */     //   46: astore_3
/*     */     //   47: aload_2
/*     */     //   48: monitorexit
/*     */     //   49: aload_3
/*     */     //   50: athrow
/*     */     //   51: astore 4
/*     */     //   53: aload_1
/*     */     //   54: monitorexit
/*     */     //   55: aload 4
/*     */     //   57: athrow
/*     */     // Line number table:
/*     */     //   Java source line #104	-> byte code offset #0
/*     */     //   Java source line #106	-> byte code offset #7
/*     */     //   Java source line #108	-> byte code offset #11
/*     */     //   Java source line #109	-> byte code offset #18
/*     */     //   Java source line #112	-> byte code offset #23
/*     */     //   Java source line #114	-> byte code offset #33
/*     */     //   Java source line #116	-> byte code offset #37
/*     */     //   Java source line #117	-> byte code offset #46
/*     */     //   Java source line #118	-> byte code offset #51
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	58	0	this	OracleBufferedStream
/*     */     //   9	45	1	Ljava/lang/Object;	Object
/*     */     //   18	4	2	localObject1	Object
/*     */     //   35	13	2	Ljava/lang/Object;	Object
/*     */     //   46	4	3	localObject2	Object
/*     */     //   51	5	4	localObject3	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   11	17	18	finally
/*     */     //   18	21	18	finally
/*     */     //   37	43	46	finally
/*     */     //   46	49	46	finally
/*     */     //   33	45	51	finally
/*     */     //   46	55	51	finally
/*     */   }
/*     */   
/*     */   private final int readInternal()
/*     */     throws IOException
/*     */   {
/* 127 */     if ((this.closed) || (isNull())) {
/* 128 */       return -1;
/*     */     }
/* 130 */     if (needBytes()) {
/* 131 */       return this.buf[(this.pos++)] & 0xFF;
/*     */     }
/* 133 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte)
/*     */     throws IOException
/*     */   {
/* 142 */     return read(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   4: ifnonnull +27 -> 31
/*     */     //   7: aload_0
/*     */     //   8: dup
/*     */     //   9: astore 4
/*     */     //   11: monitorenter
/*     */     //   12: aload_0
/*     */     //   13: aload_1
/*     */     //   14: iload_2
/*     */     //   15: iload_3
/*     */     //   16: invokespecial 18	oracle/jdbc/driver/OracleBufferedStream:readInternal	([BII)I
/*     */     //   19: aload 4
/*     */     //   21: monitorexit
/*     */     //   22: ireturn
/*     */     //   23: astore 5
/*     */     //   25: aload 4
/*     */     //   27: monitorexit
/*     */     //   28: aload 5
/*     */     //   30: athrow
/*     */     //   31: aload_0
/*     */     //   32: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   35: getfield 14	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*     */     //   38: dup
/*     */     //   39: astore 4
/*     */     //   41: monitorenter
/*     */     //   42: aload_0
/*     */     //   43: dup
/*     */     //   44: astore 5
/*     */     //   46: monitorenter
/*     */     //   47: aload_0
/*     */     //   48: aload_1
/*     */     //   49: iload_2
/*     */     //   50: iload_3
/*     */     //   51: invokespecial 18	oracle/jdbc/driver/OracleBufferedStream:readInternal	([BII)I
/*     */     //   54: aload 5
/*     */     //   56: monitorexit
/*     */     //   57: aload 4
/*     */     //   59: monitorexit
/*     */     //   60: ireturn
/*     */     //   61: astore 6
/*     */     //   63: aload 5
/*     */     //   65: monitorexit
/*     */     //   66: aload 6
/*     */     //   68: athrow
/*     */     //   69: astore 7
/*     */     //   71: aload 4
/*     */     //   73: monitorexit
/*     */     //   74: aload 7
/*     */     //   76: athrow
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     //   Java source line #150	-> byte code offset #7
/*     */     //   Java source line #152	-> byte code offset #12
/*     */     //   Java source line #153	-> byte code offset #23
/*     */     //   Java source line #156	-> byte code offset #31
/*     */     //   Java source line #158	-> byte code offset #42
/*     */     //   Java source line #160	-> byte code offset #47
/*     */     //   Java source line #161	-> byte code offset #61
/*     */     //   Java source line #162	-> byte code offset #69
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	77	0	this	OracleBufferedStream
/*     */     //   0	77	1	paramArrayOfByte	byte[]
/*     */     //   0	77	2	paramInt1	int
/*     */     //   0	77	3	paramInt2	int
/*     */     //   9	63	4	Ljava/lang/Object;	Object
/*     */     //   23	6	5	localObject1	Object
/*     */     //   44	20	5	Ljava/lang/Object;	Object
/*     */     //   61	6	6	localObject2	Object
/*     */     //   69	6	7	localObject3	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   12	22	23	finally
/*     */     //   23	28	23	finally
/*     */     //   47	57	61	finally
/*     */     //   61	66	61	finally
/*     */     //   42	60	69	finally
/*     */     //   61	74	69	finally
/*     */   }
/*     */   
/*     */   private final int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/* 170 */     int j = paramInt1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 175 */     if ((this.closed) || (isNull()))
/* 176 */       return -1;
/*     */     int i;
/* 178 */     if (paramInt2 > paramArrayOfByte.length) {
/* 179 */       i = j + paramArrayOfByte.length;
/*     */     } else {
/* 181 */       i = j + paramInt2;
/*     */     }
/* 183 */     if (!needBytes()) {
/* 184 */       return -1;
/*     */     }
/* 186 */     j += writeBytes(paramArrayOfByte, j, i - j);
/*     */     
/* 188 */     while ((j < i) && (needBytes()))
/*     */     {
/* 190 */       j += writeBytes(paramArrayOfByte, j, i - j);
/*     */     }
/*     */     
/* 193 */     return j - paramInt1;
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/* 198 */     if ((this.closed) || (isNull())) {
/* 199 */       return 0;
/*     */     }
/* 201 */     return this.count - this.pos;
/*     */   }
/*     */   
/*     */   public boolean isNull() throws IOException
/*     */   {
/* 206 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized void mark(int paramInt) {}
/*     */   
/*     */   public synchronized void reset() throws IOException
/*     */   {
/* 213 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */   
/*     */   public boolean markSupported()
/*     */   {
/* 218 */     return false;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public long skip(int paramInt)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   4: ifnonnull +21 -> 25
/*     */     //   7: aload_0
/*     */     //   8: dup
/*     */     //   9: astore_2
/*     */     //   10: monitorenter
/*     */     //   11: aload_0
/*     */     //   12: iload_1
/*     */     //   13: invokespecial 21	oracle/jdbc/driver/OracleBufferedStream:skipInternal	(I)I
/*     */     //   16: i2l
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: lreturn
/*     */     //   20: astore_3
/*     */     //   21: aload_2
/*     */     //   22: monitorexit
/*     */     //   23: aload_3
/*     */     //   24: athrow
/*     */     //   25: aload_0
/*     */     //   26: getfield 8	oracle/jdbc/driver/OracleBufferedStream:statement	Loracle/jdbc/driver/OracleStatement;
/*     */     //   29: getfield 14	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*     */     //   32: dup
/*     */     //   33: astore_2
/*     */     //   34: monitorenter
/*     */     //   35: aload_0
/*     */     //   36: dup
/*     */     //   37: astore_3
/*     */     //   38: monitorenter
/*     */     //   39: aload_0
/*     */     //   40: iload_1
/*     */     //   41: invokespecial 21	oracle/jdbc/driver/OracleBufferedStream:skipInternal	(I)I
/*     */     //   44: i2l
/*     */     //   45: aload_3
/*     */     //   46: monitorexit
/*     */     //   47: aload_2
/*     */     //   48: monitorexit
/*     */     //   49: lreturn
/*     */     //   50: astore 4
/*     */     //   52: aload_3
/*     */     //   53: monitorexit
/*     */     //   54: aload 4
/*     */     //   56: athrow
/*     */     //   57: astore 5
/*     */     //   59: aload_2
/*     */     //   60: monitorexit
/*     */     //   61: aload 5
/*     */     //   63: athrow
/*     */     // Line number table:
/*     */     //   Java source line #229	-> byte code offset #0
/*     */     //   Java source line #231	-> byte code offset #7
/*     */     //   Java source line #233	-> byte code offset #11
/*     */     //   Java source line #234	-> byte code offset #20
/*     */     //   Java source line #237	-> byte code offset #25
/*     */     //   Java source line #239	-> byte code offset #35
/*     */     //   Java source line #241	-> byte code offset #39
/*     */     //   Java source line #242	-> byte code offset #50
/*     */     //   Java source line #243	-> byte code offset #57
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	64	0	this	OracleBufferedStream
/*     */     //   0	64	1	paramInt	int
/*     */     //   9	51	2	Ljava/lang/Object;	Object
/*     */     //   20	4	3	localObject1	Object
/*     */     //   37	16	3	Ljava/lang/Object;	Object
/*     */     //   50	5	4	localObject2	Object
/*     */     //   57	5	5	localObject3	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   11	19	20	finally
/*     */     //   20	23	20	finally
/*     */     //   39	47	50	finally
/*     */     //   50	54	50	finally
/*     */     //   35	49	57	finally
/*     */     //   50	61	57	finally
/*     */   }
/*     */   
/*     */   private final int skipInternal(int paramInt)
/*     */     throws IOException
/*     */   {
/* 249 */     int i = 0;
/* 250 */     int j = paramInt;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 255 */     if ((this.closed) || (isNull())) {
/* 256 */       return -1;
/*     */     }
/* 258 */     if (!needBytes()) {
/* 259 */       return -1;
/*     */     }
/* 261 */     while ((i < j) && (needBytes()))
/*     */     {
/* 263 */       i += flushBytes(j - i);
/*     */     }
/*     */     
/* 266 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 271 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:28_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\OracleBufferedStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */