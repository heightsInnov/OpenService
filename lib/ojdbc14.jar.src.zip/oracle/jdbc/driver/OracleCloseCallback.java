package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;

public abstract interface OracleCloseCallback
{
  public abstract void beforeClose(OracleConnection paramOracleConnection, Object paramObject);
  
  public abstract void afterClose(Object paramObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\OracleCloseCallback.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */