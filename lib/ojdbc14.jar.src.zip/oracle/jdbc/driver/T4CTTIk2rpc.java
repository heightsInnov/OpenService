/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIk2rpc
/*     */   extends T4CTTIfun
/*     */ {
/*     */   T4CConnection connection;
/*     */   static final int K2RPClogon = 1;
/*     */   static final int K2RPCbegin = 2;
/*     */   static final int K2RPCend = 3;
/*     */   static final int K2RPCrecover = 4;
/*     */   static final int K2RPCsession = 5;
/*     */   
/*     */   T4CTTIk2rpc(T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer, T4CConnection paramT4CConnection)
/*     */     throws SQLException
/*     */   {
/*  64 */     super((byte)3, 0, (short)67);
/*     */     
/*  66 */     this.oer = paramT4CTTIoer;
/*     */     
/*  68 */     setMarshalingEngine(paramT4CMAREngine);
/*     */     
/*  70 */     this.connection = paramT4CConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void marshal(int paramInt1, int paramInt2)
/*     */     throws IOException, SQLException
/*     */   {
/*  78 */     super.marshalFunHeader();
/*     */     
/*     */ 
/*  81 */     this.meg.marshalUB4(0L);
/*  82 */     this.meg.marshalUB4(paramInt1);
/*  83 */     this.meg.marshalPTR();
/*  84 */     this.meg.marshalUB4(3L);
/*  85 */     this.meg.marshalNULLPTR();
/*  86 */     this.meg.marshalUB4(0L);
/*  87 */     this.meg.marshalNULLPTR();
/*  88 */     this.meg.marshalUB4(0L);
/*  89 */     this.meg.marshalPTR();
/*  90 */     this.meg.marshalUB4(3L);
/*  91 */     this.meg.marshalPTR();
/*  92 */     this.meg.marshalNULLPTR();
/*  93 */     this.meg.marshalUB4(0L);
/*  94 */     this.meg.marshalNULLPTR();
/*  95 */     this.meg.marshalNULLPTR();
/*  96 */     this.meg.marshalUB4(0L);
/*  97 */     this.meg.marshalNULLPTR();
/*     */     
/*     */ 
/*     */ 
/* 101 */     this.meg.marshalUB4(paramInt2);
/* 102 */     this.meg.marshalUB4(0L);
/* 103 */     this.meg.marshalUB4(0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void receive()
/*     */     throws SQLException, IOException
/*     */   {
/*     */     try
/*     */     {
/*     */       for (;;)
/*     */       {
/* 117 */         int i = this.meg.unmarshalSB1();
/*     */         int j;
/* 119 */         int k; switch (i)
/*     */         {
/*     */ 
/*     */         case 9: 
/* 123 */           if (this.meg.versionNumber >= 10000)
/*     */           {
/* 125 */             j = (short)this.meg.unmarshalUB2();
/*     */             
/* 127 */             this.connection.endToEndECIDSequenceNumber = j;
/*     */           }
/*     */           
/* 130 */           break;
/*     */         
/*     */         case 8: 
/* 133 */           j = this.meg.unmarshalUB2();
/*     */           
/* 135 */           for (k = 0; k < j;)
/*     */           {
/* 137 */             this.meg.unmarshalUB4();k++; continue;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */             DatabaseError.throwSqlException(401);
/*     */           }
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (BreakNetException localBreakNetException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:32_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4CTTIk2rpc.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */