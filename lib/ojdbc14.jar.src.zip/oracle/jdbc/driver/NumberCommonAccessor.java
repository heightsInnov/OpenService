/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class NumberCommonAccessor
/*      */   extends Accessor
/*      */ {
/*      */   static final boolean GET_XXX_ROUNDS = false;
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*   28 */     init(paramOracleStatement, 6, 6, paramShort, paramBoolean);
/*   29 */     initForDataAccess(paramInt2, paramInt1, null);
/*      */   }
/*      */   
/*      */ 
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort)
/*      */     throws SQLException
/*      */   {
/*   36 */     init(paramOracleStatement, 6, 6, paramShort, false);
/*   37 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*      */     
/*   39 */     initForDataAccess(0, paramInt2, null);
/*      */   }
/*      */   
/*      */   void initForDataAccess(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/*   45 */     if (paramInt1 != 0) {
/*   46 */       this.externalType = paramInt1;
/*      */     }
/*   48 */     this.internalTypeMaxLength = 21;
/*      */     
/*   50 */     if ((paramInt2 > 0) && (paramInt2 < this.internalTypeMaxLength)) {
/*   51 */       this.internalTypeMaxLength = paramInt2;
/*      */     }
/*   53 */     this.byteLength = (this.internalTypeMaxLength + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*   69 */     int i = 0;
/*      */     
/*   71 */     if (this.rowSpaceIndicator == null) {
/*   72 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*   76 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*   78 */       byte[] arrayOfByte = this.rowSpaceByte;
/*   79 */       int j = this.columnIndex + this.byteLength * paramInt + 1;
/*   80 */       int k = arrayOfByte[(j - 1)];
/*   81 */       int m = arrayOfByte[j];
/*      */       
/*   83 */       int n = 0;
/*      */       int i1;
/*      */       int i2;
/*      */       int i3;
/*   87 */       int i4; int i7; if ((m & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*   92 */         i1 = (byte)((m & 0xFF7F) - 65);
/*   93 */         i2 = (byte)(k - 1);
/*      */         
/*   95 */         i3 = i2 > i1 + 1 ? i1 + 2 : i2 + 1;
/*   96 */         i4 = i3 + j;
/*      */         
/*   98 */         if (i1 >= 4)
/*      */         {
/*  100 */           if (i1 > 4)
/*      */           {
/*      */ 
/*  103 */             throwOverflow();
/*      */           }
/*  105 */           long l1 = 0L;
/*      */           
/*  107 */           if (i3 > 1)
/*      */           {
/*  109 */             l1 = arrayOfByte[(j + 1)] - 1;
/*      */             
/*  111 */             for (i7 = 2 + j; i7 < i4; i7++) {
/*  112 */               l1 = l1 * 100L + (arrayOfByte[i7] - 1);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  119 */           for (i7 = i1 - i2; i7 >= 0; i7--) {
/*  120 */             l1 *= 100L;
/*      */           }
/*  122 */           if (l1 > 2147483647L) {
/*  123 */             throwOverflow();
/*      */           }
/*  125 */           n = (int)l1;
/*      */         }
/*      */         else
/*      */         {
/*  129 */           if (i3 > 1)
/*      */           {
/*  131 */             n = arrayOfByte[(j + 1)] - 1;
/*      */             
/*  133 */             for (i5 = 2 + j; i5 < i4; i5++) {
/*  134 */               n = n * 100 + (arrayOfByte[i5] - 1);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  141 */           for (int i5 = i1 - i2; i5 >= 0; i5--) {
/*  142 */             n *= 100;
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  150 */         i1 = (byte)(((m ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*  151 */         i2 = (byte)(k - 1);
/*      */         
/*  153 */         if ((i2 != 20) || (arrayOfByte[(j + i2)] == 102)) {
/*  154 */           i2 = (byte)(i2 - 1);
/*      */         }
/*  156 */         i3 = i2 > i1 + 1 ? i1 + 2 : i2 + 1;
/*  157 */         i4 = i3 + j;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */         if (i1 >= 4)
/*      */         {
/*  169 */           if (i1 > 4)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */             throwOverflow();
/*      */           }
/*      */           
/*  186 */           long l2 = 0L;
/*      */           
/*  188 */           if (i3 > 1)
/*      */           {
/*  190 */             l2 = 101 - arrayOfByte[(j + 1)];
/*      */             
/*  192 */             for (i7 = 2 + j; i7 < i4; i7++) {
/*  193 */               l2 = l2 * 100L + (101 - arrayOfByte[i7]);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  200 */           for (i7 = i1 - i2; i7 >= 0; i7--) {
/*  201 */             l2 *= 100L;
/*      */           }
/*  203 */           l2 = -l2;
/*      */           
/*  205 */           if (l2 < -2147483648L) {
/*  206 */             throwOverflow();
/*      */           }
/*  208 */           n = (int)l2;
/*      */         }
/*      */         else
/*      */         {
/*  212 */           if (i3 > 1)
/*      */           {
/*  214 */             n = 101 - arrayOfByte[(j + 1)];
/*      */             
/*  216 */             for (i6 = 2 + j; i6 < i4; i6++) {
/*  217 */               n = n * 100 + (101 - arrayOfByte[i6]);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  224 */           for (int i6 = i1 - i2; i6 >= 0; i6--) {
/*  225 */             n *= 100;
/*      */           }
/*  227 */           n = -n;
/*      */         }
/*      */       }
/*      */       
/*  231 */       i = n;
/*      */     }
/*      */     
/*  234 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  248 */     boolean bool = false;
/*      */     
/*  250 */     if (this.rowSpaceIndicator == null) {
/*  251 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  255 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*  257 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  258 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  259 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*  261 */       bool = (j != 1) || (arrayOfByte[i] != Byte.MIN_VALUE);
/*      */     }
/*      */     
/*  264 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  278 */     short s = 0;
/*      */     
/*  280 */     if (this.rowSpaceIndicator == null) {
/*  281 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  285 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/*  288 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  289 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  290 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*  292 */       int k = arrayOfByte[i];
/*      */       
/*  294 */       int m = 0;
/*      */       int n;
/*      */       int i1;
/*      */       int i2;
/*  298 */       int i3; int i4; if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  303 */         n = (byte)((k & 0xFF7F) - 65);
/*      */         
/*  305 */         if (n > 2)
/*      */         {
/*      */ 
/*  308 */           throwOverflow();
/*      */         }
/*  310 */         i1 = (byte)(j - 1);
/*      */         
/*  312 */         i2 = i1 > n + 1 ? n + 2 : i1 + 1;
/*  313 */         i3 = i2 + i;
/*      */         
/*  315 */         if (i2 > 1)
/*      */         {
/*  317 */           m = arrayOfByte[(i + 1)] - 1;
/*      */           
/*  319 */           for (i4 = 2 + i; i4 < i3; i4++) {
/*  320 */             m = m * 100 + (arrayOfByte[i4] - 1);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  327 */         for (i4 = n - i1; i4 >= 0; i4--) {
/*  328 */           m *= 100;
/*      */         }
/*  330 */         if ((n == 2) && 
/*  331 */           (m > 32767)) {
/*  332 */           throwOverflow();
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  339 */         n = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */         
/*  341 */         if (n > 2)
/*      */         {
/*      */ 
/*  344 */           throwOverflow();
/*      */         }
/*  346 */         i1 = (byte)(j - 1);
/*      */         
/*  348 */         if ((i1 != 20) || (arrayOfByte[(i + i1)] == 102)) {
/*  349 */           i1 = (byte)(i1 - 1);
/*      */         }
/*  351 */         i2 = i1 > n + 1 ? n + 2 : i1 + 1;
/*  352 */         i3 = i2 + i;
/*      */         
/*  354 */         if (i2 > 1)
/*      */         {
/*  356 */           m = 101 - arrayOfByte[(i + 1)];
/*      */           
/*  358 */           for (i4 = 2 + i; i4 < i3; i4++) {
/*  359 */             m = m * 100 + (101 - arrayOfByte[i4]);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  366 */         for (i4 = n - i1; i4 >= 0; i4--) {
/*  367 */           m *= 100;
/*      */         }
/*  369 */         m = -m;
/*      */         
/*  371 */         if ((n == 2) && 
/*  372 */           (m < 32768)) {
/*  373 */           throwOverflow();
/*      */         }
/*      */       }
/*  376 */       s = (short)m;
/*      */     }
/*      */     
/*  379 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  393 */     byte b = 0;
/*      */     
/*  395 */     if (this.rowSpaceIndicator == null) {
/*  396 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  400 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/*  403 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  404 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  405 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*  407 */       int k = arrayOfByte[i];
/*      */       
/*  409 */       int m = 0;
/*      */       
/*      */       int n;
/*      */       int i1;
/*  413 */       if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  418 */         n = (byte)((k & 0xFF7F) - 65);
/*      */         
/*  420 */         if (n > 1)
/*      */         {
/*      */ 
/*  423 */           throwOverflow();
/*      */         }
/*  425 */         i1 = (byte)(j - 1);
/*      */         
/*  427 */         if (i1 > n + 1)
/*      */         {
/*  429 */           switch (n)
/*      */           {
/*      */           default: 
/*      */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case -1: 
/*      */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 0: 
/*  442 */             m = arrayOfByte[(i + 1)] - 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  447 */             break;
/*      */           
/*      */           case 1: 
/*  450 */             m = (arrayOfByte[(i + 1)] - 1) * 100 + (arrayOfByte[(i + 2)] - 1);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  456 */             if (m <= 127) break;
/*  457 */             throwOverflow();break;
/*      */           
/*      */           }
/*      */           
/*      */         }
/*  462 */         else if (i1 == 1)
/*      */         {
/*  464 */           if (n == 1)
/*      */           {
/*  466 */             m = (arrayOfByte[(i + 1)] - 1) * 100;
/*      */             
/*  468 */             if (m > 127) {
/*  469 */               throwOverflow();
/*      */             }
/*      */           } else {
/*  472 */             m = arrayOfByte[(i + 1)] - 1;
/*      */           }
/*  474 */         } else if (i1 == 2)
/*      */         {
/*  476 */           m = (arrayOfByte[(i + 1)] - 1) * 100 + (arrayOfByte[(i + 2)] - 1);
/*      */           
/*      */ 
/*  479 */           if (m > 127) {
/*  480 */             throwOverflow();
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  488 */         n = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */         
/*  490 */         if (n > 1)
/*      */         {
/*      */ 
/*  493 */           throwOverflow();
/*      */         }
/*  495 */         i1 = (byte)(j - 1);
/*      */         
/*  497 */         if ((i1 != 20) || (arrayOfByte[(i + i1)] == 102)) {
/*  498 */           i1 = (byte)(i1 - 1);
/*      */         }
/*  500 */         if (i1 > n + 1)
/*      */         {
/*  502 */           switch (n)
/*      */           {
/*      */           default: 
/*      */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case -1: 
/*      */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 0: 
/*  515 */             m = -(101 - arrayOfByte[(i + 1)]);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  520 */             break;
/*      */           
/*      */           case 1: 
/*  523 */             m = -((101 - arrayOfByte[(i + 1)]) * 100 + (101 - arrayOfByte[(i + 2)]));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  529 */             if (m >= -128) break;
/*  530 */             throwOverflow();break;
/*      */           
/*      */           }
/*      */           
/*      */         }
/*  535 */         else if (i1 == 1)
/*      */         {
/*  537 */           if (n == 1)
/*      */           {
/*  539 */             m = -(101 - arrayOfByte[(i + 1)]) * 100;
/*      */             
/*  541 */             if (m < -128) {
/*  542 */               throwOverflow();
/*      */             }
/*      */           } else {
/*  545 */             m = -(101 - arrayOfByte[(i + 1)]);
/*      */           }
/*  547 */         } else if (i1 == 2)
/*      */         {
/*  549 */           m = -((101 - arrayOfByte[(i + 1)]) * 100 + (101 - arrayOfByte[(i + 2)]));
/*      */           
/*      */ 
/*  552 */           if (m < -128) {
/*  553 */             throwOverflow();
/*      */           }
/*      */         }
/*      */       }
/*  557 */       b = (byte)m;
/*      */     }
/*      */     
/*  560 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  574 */     long l1 = 0L;
/*      */     
/*  576 */     if (this.rowSpaceIndicator == null) {
/*  577 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  581 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/*  584 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  585 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  586 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*  588 */       int k = arrayOfByte[i];
/*  589 */       long l2 = 0L;
/*      */       
/*      */ 
/*      */ 
/*      */       int i4;
/*      */       
/*      */ 
/*      */ 
/*  597 */       if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  602 */         if ((k == -128) && (j == 1)) {
/*  603 */           return 0L;
/*      */         }
/*  605 */         m = (byte)((k & 0xFF7F) - 65);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  610 */         if (m > 9)
/*      */         {
/*      */ 
/*  613 */           throwOverflow();
/*      */         }
/*  615 */         if (m == 9)
/*      */         {
/*  617 */           i1 = 1;
/*  618 */           i2 = j;
/*      */           
/*  620 */           if (j > 11) {
/*  621 */             i2 = 11;
/*      */           }
/*  623 */           while (i1 < i2)
/*      */           {
/*      */ 
/*      */ 
/*  627 */             i3 = arrayOfByte[(i + i1)] & 0xFF;
/*  628 */             i4 = MAX_LONG[i1];
/*      */             
/*  630 */             if (i3 != i4)
/*      */             {
/*  632 */               if (i3 < i4) {
/*      */                 break;
/*      */               }
/*  635 */               throwOverflow();
/*      */             }
/*      */             
/*  638 */             i1++;
/*      */           }
/*      */           
/*  641 */           if ((i1 == i2) && (j > 11)) {
/*  642 */             throwOverflow();
/*      */           }
/*      */         }
/*  645 */         n = (byte)(j - 1);
/*      */         
/*  647 */         i1 = n > m + 1 ? m + 2 : n + 1;
/*  648 */         i2 = i1 + i;
/*      */         
/*  650 */         if (i1 > 1)
/*      */         {
/*  652 */           l2 = arrayOfByte[(i + 1)] - 1;
/*      */           
/*  654 */           for (i3 = 2 + i; i3 < i2; i3++) {
/*  655 */             l2 = l2 * 100L + (arrayOfByte[i3] - 1);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  662 */         for (i3 = m - n; i3 >= 0; i3--) {
/*  663 */           l2 *= 100L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  670 */       int m = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  675 */       if (m > 9)
/*      */       {
/*      */ 
/*  678 */         throwOverflow();
/*      */       }
/*  680 */       if (m == 9)
/*      */       {
/*  682 */         i1 = 1;
/*  683 */         i2 = j;
/*      */         
/*  685 */         if (j > 12) {
/*  686 */           i2 = 12;
/*      */         }
/*  688 */         while (i1 < i2)
/*      */         {
/*      */ 
/*      */ 
/*  692 */           i3 = arrayOfByte[(i + i1)] & 0xFF;
/*  693 */           i4 = MIN_LONG[i1];
/*      */           
/*  695 */           if (i3 != i4)
/*      */           {
/*  697 */             if (i3 > i4) {
/*      */               break;
/*      */             }
/*  700 */             throwOverflow();
/*      */           }
/*      */           
/*  703 */           i1++;
/*      */         }
/*      */         
/*  706 */         if ((i1 == i2) && (j < 12)) {
/*  707 */           throwOverflow();
/*      */         }
/*      */       }
/*  710 */       int n = (byte)(j - 1);
/*      */       
/*  712 */       if ((n != 20) || (arrayOfByte[(i + n)] == 102)) {
/*  713 */         n = (byte)(n - 1);
/*      */       }
/*  715 */       int i1 = n > m + 1 ? m + 2 : n + 1;
/*  716 */       int i2 = i1 + i;
/*      */       
/*  718 */       if (i1 > 1)
/*      */       {
/*  720 */         l2 = 101 - arrayOfByte[(i + 1)];
/*      */         
/*  722 */         for (i3 = 2 + i; i3 < i2; i3++) {
/*  723 */           l2 = l2 * 100L + (101 - arrayOfByte[i3]);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  730 */       for (int i3 = m - n; i3 >= 0; i3--) {
/*  731 */         l2 *= 100L;
/*      */       }
/*  733 */       l2 = -l2;
/*      */       
/*      */ 
/*  736 */       l1 = l2;
/*      */     }
/*      */     
/*  739 */     return l1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  753 */     float f = 0.0F;
/*      */     
/*  755 */     if (this.rowSpaceIndicator == null) {
/*  756 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  760 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/*  763 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  764 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  765 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*  767 */       int k = arrayOfByte[i];
/*      */       
/*      */ 
/*  770 */       double d = 0.0D;
/*      */       
/*  772 */       int i1 = i + 1;
/*      */       
/*      */ 
/*      */       int m;
/*      */       
/*      */ 
/*      */       int i2;
/*      */       
/*      */ 
/*      */       int n;
/*      */       
/*  783 */       if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  788 */         if ((k == -128) && (j == 1)) {
/*  789 */           return 0.0F;
/*      */         }
/*  791 */         if ((j == 2) && (k == -1) && (arrayOfByte[(i + 1)] == 101))
/*      */         {
/*  793 */           return Float.POSITIVE_INFINITY;
/*      */         }
/*  795 */         m = (byte)((k & 0xFF7F) - 65);
/*      */         
/*  797 */         i2 = j - 1;
/*      */         
/*  799 */         while ((arrayOfByte[i1] == 1) && (i2 > 0))
/*      */         {
/*  801 */           i1++;
/*  802 */           i2--;
/*  803 */           m = (byte)(m - 1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  811 */         n = (int)(127.0D - m);
/*      */         
/*  813 */         switch (i2)
/*      */         {
/*      */ 
/*      */         case 1: 
/*  817 */           d = (arrayOfByte[i1] - 1) * factorTable[n];
/*      */           
/*  819 */           break;
/*      */         
/*      */         case 2: 
/*  822 */           d = ((arrayOfByte[i1] - 1) * 100 + (arrayOfByte[(i1 + 1)] - 1)) * factorTable[(n + 1)];
/*      */           
/*      */ 
/*  825 */           break;
/*      */         
/*      */         case 3: 
/*  828 */           d = ((arrayOfByte[i1] - 1) * 10000 + (arrayOfByte[(i1 + 1)] - 1) * 100 + (arrayOfByte[(i1 + 2)] - 1)) * factorTable[(n + 2)];
/*      */           
/*      */ 
/*      */ 
/*  832 */           break;
/*      */         
/*      */         case 4: 
/*  835 */           d = ((arrayOfByte[i1] - 1) * 1000000 + (arrayOfByte[(i1 + 1)] - 1) * 10000 + (arrayOfByte[(i1 + 2)] - 1) * 100 + (arrayOfByte[(i1 + 3)] - 1)) * factorTable[(n + 3)];
/*      */           
/*      */ 
/*      */ 
/*  839 */           break;
/*      */         
/*      */         case 5: 
/*  842 */           d = ((arrayOfByte[(i1 + 1)] - 1) * 1000000 + (arrayOfByte[(i1 + 2)] - 1) * 10000 + (arrayOfByte[(i1 + 3)] - 1) * 100 + (arrayOfByte[(i1 + 4)] - 1)) * factorTable[(n + 4)] + (arrayOfByte[i1] - 1) * factorTable[n];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  848 */           break;
/*      */         
/*      */         case 6: 
/*  851 */           d = ((arrayOfByte[(i1 + 2)] - 1) * 1000000 + (arrayOfByte[(i1 + 3)] - 1) * 10000 + (arrayOfByte[(i1 + 4)] - 1) * 100 + (arrayOfByte[(i1 + 5)] - 1)) * factorTable[(n + 5)] + ((arrayOfByte[i1] - 1) * 100 + (arrayOfByte[(i1 + 1)] - 1)) * factorTable[(n + 1)];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  857 */           break;
/*      */         
/*      */         default: 
/*  860 */           d = ((arrayOfByte[(i1 + 3)] - 1) * 1000000 + (arrayOfByte[(i1 + 4)] - 1) * 10000 + (arrayOfByte[(i1 + 5)] - 1) * 100 + (arrayOfByte[(i1 + 6)] - 1)) * factorTable[(n + 6)] + ((arrayOfByte[i1] - 1) * 10000 + (arrayOfByte[(i1 + 1)] - 1) * 100 + (arrayOfByte[(i1 + 2)] - 1)) * factorTable[(n + 2)];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  866 */           break;
/*      */         
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  874 */         if ((k == 0) && (j == 1)) {
/*  875 */           return Float.NEGATIVE_INFINITY;
/*      */         }
/*  877 */         m = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */         
/*  879 */         i2 = j - 1;
/*      */         
/*  881 */         if ((i2 != 20) || (arrayOfByte[(i + i2)] == 102)) {
/*  882 */           i2--;
/*      */         }
/*  884 */         while ((arrayOfByte[i1] == 1) && (i2 > 0))
/*      */         {
/*  886 */           i1++;
/*  887 */           i2--;
/*  888 */           m = (byte)(m - 1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  896 */         n = (int)(127.0D - m);
/*      */         
/*  898 */         switch (i2)
/*      */         {
/*      */ 
/*      */         case 1: 
/*  902 */           d = -(101 - arrayOfByte[i1]) * factorTable[n];
/*      */           
/*  904 */           break;
/*      */         
/*      */         case 2: 
/*  907 */           d = -((101 - arrayOfByte[i1]) * 100 + (101 - arrayOfByte[(i1 + 1)])) * factorTable[(n + 1)];
/*      */           
/*      */ 
/*  910 */           break;
/*      */         
/*      */         case 3: 
/*  913 */           d = -((101 - arrayOfByte[i1]) * 10000 + (101 - arrayOfByte[(i1 + 1)]) * 100 + (101 - arrayOfByte[(i1 + 2)])) * factorTable[(n + 2)];
/*      */           
/*      */ 
/*      */ 
/*  917 */           break;
/*      */         
/*      */         case 4: 
/*  920 */           d = -((101 - arrayOfByte[i1]) * 1000000 + (101 - arrayOfByte[(i1 + 1)]) * 10000 + (101 - arrayOfByte[(i1 + 2)]) * 100 + (101 - arrayOfByte[(i1 + 3)])) * factorTable[(n + 3)];
/*      */           
/*      */ 
/*      */ 
/*  924 */           break;
/*      */         
/*      */         case 5: 
/*  927 */           d = -(((101 - arrayOfByte[(i1 + 1)]) * 1000000 + (101 - arrayOfByte[(i1 + 2)]) * 10000 + (101 - arrayOfByte[(i1 + 3)]) * 100 + (101 - arrayOfByte[(i1 + 4)])) * factorTable[(n + 4)] + (101 - arrayOfByte[i1]) * factorTable[n]);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  933 */           break;
/*      */         
/*      */         case 6: 
/*  936 */           d = -(((101 - arrayOfByte[(i1 + 2)]) * 1000000 + (101 - arrayOfByte[(i1 + 3)]) * 10000 + (101 - arrayOfByte[(i1 + 4)]) * 100 + (101 - arrayOfByte[(i1 + 5)])) * factorTable[(n + 5)] + ((101 - arrayOfByte[i1]) * 100 + (101 - arrayOfByte[(i1 + 1)])) * factorTable[(n + 1)]);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  942 */           break;
/*      */         
/*      */         default: 
/*  945 */           d = -(((101 - arrayOfByte[(i1 + 3)]) * 1000000 + (101 - arrayOfByte[(i1 + 4)]) * 10000 + (101 - arrayOfByte[(i1 + 5)]) * 100 + (101 - arrayOfByte[(i1 + 6)])) * factorTable[(n + 6)] + ((101 - arrayOfByte[i1]) * 10000 + (101 - arrayOfByte[(i1 + 1)]) * 100 + (101 - arrayOfByte[(i1 + 2)])) * factorTable[(n + 2)]);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  956 */       f = (float)d;
/*      */     }
/*      */     
/*  959 */     return f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  973 */     double d1 = 0.0D;
/*      */     
/*  975 */     if (this.rowSpaceIndicator == null) {
/*  976 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/*  980 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/*  983 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  984 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  985 */       int j = arrayOfByte[(i - 1)];
/*      */       
/*      */ 
/*  988 */       int k = arrayOfByte[i];
/*      */       
/*  990 */       int n = i + 1;
/*  991 */       int i1 = j - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  996 */       int i7 = 1;
/*      */       
/*      */ 
/*      */       int m;
/*      */       
/*      */ 
/*      */       int i6;
/*      */       
/*      */       int i4;
/*      */       
/* 1006 */       if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1011 */         if ((k == -128) && (j == 1)) {
/* 1012 */           return 0.0D;
/*      */         }
/* 1014 */         if ((j == 2) && (k == -1) && (arrayOfByte[(i + 1)] == 101))
/*      */         {
/* 1016 */           return Double.POSITIVE_INFINITY;
/*      */         }
/* 1018 */         m = (byte)((k & 0xFF7F) - 65);
/*      */         
/* 1020 */         i6 = (arrayOfByte[(n + i1 - 1)] - 1) % 10 == 0 ? 1 : 0;
/*      */         
/* 1022 */         i4 = arrayOfByte[n] - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1035 */         i7 = 0;
/*      */         
/* 1037 */         if ((k == 0) && (j == 1)) {
/* 1038 */           return Double.NEGATIVE_INFINITY;
/*      */         }
/* 1040 */         m = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */         
/* 1042 */         if ((i1 != 20) || (arrayOfByte[(i + i1)] == 102)) {
/* 1043 */           i1--;
/*      */         }
/* 1045 */         i6 = (101 - arrayOfByte[(n + i1 - 1)]) % 10 == 0 ? 1 : 0;
/*      */         
/* 1047 */         i4 = 101 - arrayOfByte[n];
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1056 */       int i5 = i1 << 1;
/*      */       
/* 1058 */       if (i6 != 0) {
/* 1059 */         i5--;
/*      */       }
/* 1061 */       int i8 = (m + 1 << 1) - i5;
/*      */       
/* 1063 */       if (i4 < 10)
/* 1064 */         i5--;
/*      */       int i9;
/* 1066 */       int i10; int i11; int i12; int i13; int i14; int i15; int i18; int i19; double d2; int i20; if ((i5 <= 15) && (((i8 >= 0) && (i8 <= 37 - i5)) || ((i8 < 0) && (i8 >= -22))))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1071 */         i9 = 0;
/* 1072 */         i10 = 0;
/* 1073 */         i11 = 0;
/* 1074 */         i12 = 0;
/* 1075 */         i13 = 0;
/* 1076 */         i14 = 0;
/* 1077 */         i15 = 0;
/*      */         
/* 1079 */         if (i7 != 0) {
/* 1080 */           switch (i1)
/*      */           {
/*      */ 
/*      */           default: 
/* 1084 */             i15 = arrayOfByte[(n + 7)] - 1;
/*      */           
/*      */           case 7: 
/* 1087 */             i14 = arrayOfByte[(n + 6)] - 1;
/*      */           
/*      */           case 6: 
/* 1090 */             i13 = arrayOfByte[(n + 5)] - 1;
/*      */           
/*      */           case 5: 
/* 1093 */             i12 = arrayOfByte[(n + 4)] - 1;
/*      */           
/*      */           case 4: 
/* 1096 */             i11 = arrayOfByte[(n + 3)] - 1;
/*      */           
/*      */           case 3: 
/* 1099 */             i10 = arrayOfByte[(n + 2)] - 1;
/*      */           
/*      */           case 2: 
/* 1102 */             i9 = arrayOfByte[(n + 1)] - 1;
/*      */           
/*      */ 
/*      */           }
/*      */           
/*      */         } else {
/* 1108 */           switch (i1)
/*      */           {
/*      */ 
/*      */           default: 
/* 1112 */             i15 = 101 - arrayOfByte[(n + 7)];
/*      */           
/*      */           case 7: 
/* 1115 */             i14 = 101 - arrayOfByte[(n + 6)];
/*      */           
/*      */           case 6: 
/* 1118 */             i13 = 101 - arrayOfByte[(n + 5)];
/*      */           
/*      */           case 5: 
/* 1121 */             i12 = 101 - arrayOfByte[(n + 4)];
/*      */           
/*      */           case 4: 
/* 1124 */             i11 = 101 - arrayOfByte[(n + 3)];
/*      */           
/*      */           case 3: 
/* 1127 */             i10 = 101 - arrayOfByte[(n + 2)];
/*      */           
/*      */           case 2: 
/* 1130 */             i9 = 101 - arrayOfByte[(n + 1)];
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */         double d3;
/*      */         
/*      */ 
/* 1139 */         if (i6 != 0)
/* 1140 */           switch (i1)
/*      */           {
/*      */ 
/*      */           default: 
/* 1144 */             d3 = i4 / 10;
/*      */             
/* 1146 */             break;
/*      */           
/*      */           case 2: 
/* 1149 */             d3 = i4 * 10 + i9 / 10;
/*      */             
/* 1151 */             break;
/*      */           
/*      */           case 3: 
/* 1154 */             d3 = i4 * 1000 + i9 * 10 + i10 / 10;
/*      */             
/* 1156 */             break;
/*      */           
/*      */           case 4: 
/* 1159 */             d3 = i4 * 100000 + i9 * 1000 + i10 * 10 + i11 / 10;
/*      */             
/*      */ 
/* 1162 */             break;
/*      */           
/*      */           case 5: 
/* 1165 */             d3 = i4 * 10000000 + i9 * 100000 + i10 * 1000 + i11 * 10 + i12 / 10;
/*      */             
/*      */ 
/* 1168 */             break;
/*      */           
/*      */           case 6: 
/* 1171 */             i18 = i9 * 10000000 + i10 * 100000 + i11 * 1000 + i12 * 10 + i13 / 10;
/*      */             
/* 1173 */             d3 = i4 * 1000000000L + i18;
/*      */             
/* 1175 */             break;
/*      */           
/*      */           case 7: 
/* 1178 */             i18 = i10 * 10000000 + i11 * 100000 + i12 * 1000 + i13 * 10 + i14 / 10;
/*      */             
/* 1180 */             i19 = i4 * 100 + i9;
/* 1181 */             d3 = i19 * 1000000000L + i18;
/*      */             
/* 1183 */             break;
/*      */           
/*      */           case 8: 
/* 1186 */             i18 = i11 * 10000000 + i12 * 100000 + i13 * 1000 + i14 * 10 + i15 / 10;
/*      */             
/* 1188 */             i19 = i4 * 10000 + i9 * 100 + i10;
/* 1189 */             d3 = i19 * 1000000000L + i18;
/*      */             
/* 1191 */             break;
/*      */           }
/*      */            else {
/* 1194 */           switch (i1)
/*      */           {
/*      */ 
/*      */           default: 
/* 1198 */             d3 = i4;
/*      */             
/* 1200 */             break;
/*      */           
/*      */           case 2: 
/* 1203 */             d3 = i4 * 100 + i9;
/*      */             
/* 1205 */             break;
/*      */           
/*      */           case 3: 
/* 1208 */             d3 = i4 * 10000 + i9 * 100 + i10;
/*      */             
/* 1210 */             break;
/*      */           
/*      */           case 4: 
/* 1213 */             d3 = i4 * 1000000 + i9 * 10000 + i10 * 100 + i11;
/*      */             
/*      */ 
/* 1216 */             break;
/*      */           
/*      */           case 5: 
/* 1219 */             i18 = i9 * 1000000 + i10 * 10000 + i11 * 100 + i12;
/* 1220 */             d3 = i4 * 100000000L + i18;
/*      */             
/* 1222 */             break;
/*      */           
/*      */           case 6: 
/* 1225 */             i18 = i10 * 1000000 + i11 * 10000 + i12 * 100 + i13;
/* 1226 */             i19 = i4 * 100 + i9;
/* 1227 */             d3 = i19 * 100000000L + i18;
/*      */             
/* 1229 */             break;
/*      */           
/*      */           case 7: 
/* 1232 */             i18 = i11 * 1000000 + i12 * 10000 + i13 * 100 + i14;
/* 1233 */             i19 = i4 * 10000 + i9 * 100 + i10;
/* 1234 */             d3 = i19 * 100000000L + i18;
/*      */             
/* 1236 */             break;
/*      */           
/*      */           case 8: 
/* 1239 */             i18 = i12 * 1000000 + i13 * 10000 + i14 * 100 + i15;
/* 1240 */             i19 = i4 * 1000000 + i9 * 10000 + i10 * 100 + i11;
/* 1241 */             d3 = i19 * 100000000L + i18;
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1249 */         if ((i8 == 0) || (d3 == 0.0D)) {
/* 1250 */           d2 = d3;
/* 1251 */         } else if (i8 >= 0)
/*      */         {
/* 1253 */           if (i8 <= 22)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1260 */             d2 = d3 * small10pow[i8];
/*      */           }
/*      */           else
/*      */           {
/* 1264 */             i20 = 15 - i5;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1272 */             d3 *= small10pow[i20];
/* 1273 */             d2 = d3 * small10pow[(i8 - i20)];
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/* 1286 */           d2 = d3 / small10pow[(-i8)];
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1291 */         i9 = 0;
/* 1292 */         i10 = 0;
/* 1293 */         i11 = 0;
/* 1294 */         i12 = 0;
/* 1295 */         i13 = 0;
/* 1296 */         i14 = 0;
/* 1297 */         i15 = 0;
/* 1298 */         int i16 = 0;
/* 1299 */         int i17 = 0;
/* 1300 */         i18 = 0;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1307 */         int i24 = 0;
/* 1308 */         int i25 = 0;
/* 1309 */         int i26 = 0;
/* 1310 */         int i27 = 0;
/* 1311 */         int i28 = 0;
/*      */         
/*      */ 
/*      */ 
/* 1315 */         int i32 = 0;
/* 1316 */         int i33 = 0;
/*      */         int i2;
/* 1318 */         if (i7 != 0)
/*      */         {
/* 1320 */           if ((i1 & 0x1) != 0)
/*      */           {
/* 1322 */             i2 = 2;
/* 1323 */             i9 = i4;
/*      */           }
/*      */           else
/*      */           {
/* 1327 */             i2 = 3;
/* 1328 */             i9 = i4 * 100 + (arrayOfByte[(n + 1)] - 1);
/*      */           }
/* 1331 */           for (; 
/* 1331 */               i2 < i1; i2 += 2)
/*      */           {
/* 1333 */             i34 = (arrayOfByte[(n + i2 - 1)] - 1) * 100 + (arrayOfByte[(n + i2)] - 1) + i9 * 10000;
/*      */             
/*      */ 
/* 1336 */             switch (i18)
/*      */             {
/*      */ 
/*      */             default: 
/* 1340 */               i9 = i34 & 0xFFFF;
/* 1341 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1342 */               i10 = i34 & 0xFFFF;
/* 1343 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1344 */               i11 = i34 & 0xFFFF;
/* 1345 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1346 */               i12 = i34 & 0xFFFF;
/* 1347 */               i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1348 */               i13 = i34 & 0xFFFF;
/* 1349 */               i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1350 */               i14 = i34 & 0xFFFF;
/* 1351 */               i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1352 */               i15 = i34 & 0xFFFF;
/* 1353 */               i34 = (i34 >> 16 & 0xFFFF) + i16 * 10000;
/* 1354 */               i16 = i34 & 0xFFFF;
/* 1355 */               i34 = (i34 >> 16 & 0xFFFF) + i17 * 10000;
/* 1356 */               i17 = i34 & 0xFFFF;
/*      */               
/* 1358 */               break;
/*      */             
/*      */             case 7: 
/* 1361 */               i9 = i34 & 0xFFFF;
/* 1362 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1363 */               i10 = i34 & 0xFFFF;
/* 1364 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1365 */               i11 = i34 & 0xFFFF;
/* 1366 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1367 */               i12 = i34 & 0xFFFF;
/* 1368 */               i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1369 */               i13 = i34 & 0xFFFF;
/* 1370 */               i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1371 */               i14 = i34 & 0xFFFF;
/* 1372 */               i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1373 */               i15 = i34 & 0xFFFF;
/* 1374 */               i34 = (i34 >> 16 & 0xFFFF) + i16 * 10000;
/* 1375 */               i16 = i34 & 0xFFFF;
/*      */               
/* 1377 */               break;
/*      */             
/*      */             case 6: 
/* 1380 */               i9 = i34 & 0xFFFF;
/* 1381 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1382 */               i10 = i34 & 0xFFFF;
/* 1383 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1384 */               i11 = i34 & 0xFFFF;
/* 1385 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1386 */               i12 = i34 & 0xFFFF;
/* 1387 */               i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1388 */               i13 = i34 & 0xFFFF;
/* 1389 */               i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1390 */               i14 = i34 & 0xFFFF;
/* 1391 */               i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1392 */               i15 = i34 & 0xFFFF;
/*      */               
/* 1394 */               break;
/*      */             
/*      */             case 5: 
/* 1397 */               i9 = i34 & 0xFFFF;
/* 1398 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1399 */               i10 = i34 & 0xFFFF;
/* 1400 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1401 */               i11 = i34 & 0xFFFF;
/* 1402 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1403 */               i12 = i34 & 0xFFFF;
/* 1404 */               i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1405 */               i13 = i34 & 0xFFFF;
/* 1406 */               i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1407 */               i14 = i34 & 0xFFFF;
/*      */               
/* 1409 */               break;
/*      */             
/*      */             case 4: 
/* 1412 */               i9 = i34 & 0xFFFF;
/* 1413 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1414 */               i10 = i34 & 0xFFFF;
/* 1415 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1416 */               i11 = i34 & 0xFFFF;
/* 1417 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1418 */               i12 = i34 & 0xFFFF;
/* 1419 */               i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1420 */               i13 = i34 & 0xFFFF;
/*      */               
/* 1422 */               break;
/*      */             
/*      */             case 3: 
/* 1425 */               i9 = i34 & 0xFFFF;
/* 1426 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1427 */               i10 = i34 & 0xFFFF;
/* 1428 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1429 */               i11 = i34 & 0xFFFF;
/* 1430 */               i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1431 */               i12 = i34 & 0xFFFF;
/*      */               
/* 1433 */               break;
/*      */             
/*      */             case 2: 
/* 1436 */               i9 = i34 & 0xFFFF;
/* 1437 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1438 */               i10 = i34 & 0xFFFF;
/* 1439 */               i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1440 */               i11 = i34 & 0xFFFF;
/*      */               
/* 1442 */               break;
/*      */             
/*      */             case 1: 
/* 1445 */               i9 = i34 & 0xFFFF;
/* 1446 */               i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1447 */               i10 = i34 & 0xFFFF;
/*      */               
/* 1449 */               break;
/*      */             
/*      */             case 0: 
/* 1452 */               i9 = i34 & 0xFFFF;
/*      */             }
/*      */             
/*      */             
/*      */ 
/* 1457 */             i34 = i34 >> 16 & 0xFFFF;
/*      */             
/* 1459 */             if (i34 != 0)
/*      */             {
/* 1461 */               i18++;
/*      */               
/* 1463 */               switch (i18)
/*      */               {
/*      */ 
/*      */               case 8: 
/* 1467 */                 i17 = i34;
/*      */                 
/* 1469 */                 break;
/*      */               
/*      */               case 7: 
/* 1472 */                 i16 = i34;
/*      */                 
/* 1474 */                 break;
/*      */               
/*      */               case 6: 
/* 1477 */                 i15 = i34;
/*      */                 
/* 1479 */                 break;
/*      */               
/*      */               case 5: 
/* 1482 */                 i14 = i34;
/*      */                 
/* 1484 */                 break;
/*      */               
/*      */               case 4: 
/* 1487 */                 i13 = i34;
/*      */                 
/* 1489 */                 break;
/*      */               
/*      */               case 3: 
/* 1492 */                 i12 = i34;
/*      */                 
/* 1494 */                 break;
/*      */               
/*      */               case 2: 
/* 1497 */                 i11 = i34;
/*      */                 
/* 1499 */                 break;
/*      */               
/*      */               case 1: 
/* 1502 */                 i10 = i34;
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1514 */         if ((i1 & 0x1) != 0)
/*      */         {
/* 1516 */           i2 = 2;
/* 1517 */           i9 = i4;
/*      */         }
/*      */         else
/*      */         {
/* 1521 */           i2 = 3;
/* 1522 */           i9 = i4 * 100 + (101 - arrayOfByte[(n + 1)]);
/*      */         }
/* 1525 */         for (; 
/* 1525 */             i2 < i1; i2 += 2)
/*      */         {
/* 1527 */           i34 = (101 - arrayOfByte[(n + i2 - 1)]) * 100 + (101 - arrayOfByte[(n + i2)]) + i9 * 10000;
/*      */           
/*      */ 
/* 1530 */           switch (i18)
/*      */           {
/*      */ 
/*      */           default: 
/* 1534 */             i9 = i34 & 0xFFFF;
/* 1535 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1536 */             i10 = i34 & 0xFFFF;
/* 1537 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1538 */             i11 = i34 & 0xFFFF;
/* 1539 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1540 */             i12 = i34 & 0xFFFF;
/* 1541 */             i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1542 */             i13 = i34 & 0xFFFF;
/* 1543 */             i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1544 */             i14 = i34 & 0xFFFF;
/* 1545 */             i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1546 */             i15 = i34 & 0xFFFF;
/* 1547 */             i34 = (i34 >> 16 & 0xFFFF) + i16 * 10000;
/* 1548 */             i16 = i34 & 0xFFFF;
/* 1549 */             i34 = (i34 >> 16 & 0xFFFF) + i17 * 10000;
/* 1550 */             i17 = i34 & 0xFFFF;
/*      */             
/* 1552 */             break;
/*      */           
/*      */           case 7: 
/* 1555 */             i9 = i34 & 0xFFFF;
/* 1556 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1557 */             i10 = i34 & 0xFFFF;
/* 1558 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1559 */             i11 = i34 & 0xFFFF;
/* 1560 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1561 */             i12 = i34 & 0xFFFF;
/* 1562 */             i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1563 */             i13 = i34 & 0xFFFF;
/* 1564 */             i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1565 */             i14 = i34 & 0xFFFF;
/* 1566 */             i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1567 */             i15 = i34 & 0xFFFF;
/* 1568 */             i34 = (i34 >> 16 & 0xFFFF) + i16 * 10000;
/* 1569 */             i16 = i34 & 0xFFFF;
/*      */             
/* 1571 */             break;
/*      */           
/*      */           case 6: 
/* 1574 */             i9 = i34 & 0xFFFF;
/* 1575 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1576 */             i10 = i34 & 0xFFFF;
/* 1577 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1578 */             i11 = i34 & 0xFFFF;
/* 1579 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1580 */             i12 = i34 & 0xFFFF;
/* 1581 */             i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1582 */             i13 = i34 & 0xFFFF;
/* 1583 */             i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1584 */             i14 = i34 & 0xFFFF;
/* 1585 */             i34 = (i34 >> 16 & 0xFFFF) + i15 * 10000;
/* 1586 */             i15 = i34 & 0xFFFF;
/*      */             
/* 1588 */             break;
/*      */           
/*      */           case 5: 
/* 1591 */             i9 = i34 & 0xFFFF;
/* 1592 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1593 */             i10 = i34 & 0xFFFF;
/* 1594 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1595 */             i11 = i34 & 0xFFFF;
/* 1596 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1597 */             i12 = i34 & 0xFFFF;
/* 1598 */             i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1599 */             i13 = i34 & 0xFFFF;
/* 1600 */             i34 = (i34 >> 16 & 0xFFFF) + i14 * 10000;
/* 1601 */             i14 = i34 & 0xFFFF;
/*      */             
/* 1603 */             break;
/*      */           
/*      */           case 4: 
/* 1606 */             i9 = i34 & 0xFFFF;
/* 1607 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1608 */             i10 = i34 & 0xFFFF;
/* 1609 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1610 */             i11 = i34 & 0xFFFF;
/* 1611 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1612 */             i12 = i34 & 0xFFFF;
/* 1613 */             i34 = (i34 >> 16 & 0xFFFF) + i13 * 10000;
/* 1614 */             i13 = i34 & 0xFFFF;
/*      */             
/* 1616 */             break;
/*      */           
/*      */           case 3: 
/* 1619 */             i9 = i34 & 0xFFFF;
/* 1620 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1621 */             i10 = i34 & 0xFFFF;
/* 1622 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1623 */             i11 = i34 & 0xFFFF;
/* 1624 */             i34 = (i34 >> 16 & 0xFFFF) + i12 * 10000;
/* 1625 */             i12 = i34 & 0xFFFF;
/*      */             
/* 1627 */             break;
/*      */           
/*      */           case 2: 
/* 1630 */             i9 = i34 & 0xFFFF;
/* 1631 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1632 */             i10 = i34 & 0xFFFF;
/* 1633 */             i34 = (i34 >> 16 & 0xFFFF) + i11 * 10000;
/* 1634 */             i11 = i34 & 0xFFFF;
/*      */             
/* 1636 */             break;
/*      */           
/*      */           case 1: 
/* 1639 */             i9 = i34 & 0xFFFF;
/* 1640 */             i34 = (i34 >> 16 & 0xFFFF) + i10 * 10000;
/* 1641 */             i10 = i34 & 0xFFFF;
/*      */             
/* 1643 */             break;
/*      */           
/*      */           case 0: 
/* 1646 */             i9 = i34 & 0xFFFF;
/*      */           }
/*      */           
/*      */           
/*      */ 
/* 1651 */           i34 = i34 >> 16 & 0xFFFF;
/*      */           
/* 1653 */           if (i34 != 0)
/*      */           {
/* 1655 */             i18++;
/*      */             
/* 1657 */             switch (i18)
/*      */             {
/*      */ 
/*      */             case 8: 
/* 1661 */               i17 = i34;
/*      */               
/* 1663 */               break;
/*      */             
/*      */             case 7: 
/* 1666 */               i16 = i34;
/*      */               
/* 1668 */               break;
/*      */             
/*      */             case 6: 
/* 1671 */               i15 = i34;
/*      */               
/* 1673 */               break;
/*      */             
/*      */             case 5: 
/* 1676 */               i14 = i34;
/*      */               
/* 1678 */               break;
/*      */             
/*      */             case 4: 
/* 1681 */               i13 = i34;
/*      */               
/* 1683 */               break;
/*      */             
/*      */             case 3: 
/* 1686 */               i12 = i34;
/*      */               
/* 1688 */               break;
/*      */             
/*      */             case 2: 
/* 1691 */               i11 = i34;
/*      */               
/* 1693 */               break;
/*      */             
/*      */             case 1: 
/* 1696 */               i10 = i34;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1740 */         int i31 = i18;
/*      */         
/* 1742 */         i18++;
/*      */         
/* 1744 */         int i21 = 62 - m + i1;
/*      */         
/* 1746 */         int i22 = nexpdigstable[i21];
/* 1747 */         int[] arrayOfInt = expdigstable[i21];
/* 1748 */         i33 = i18 + 5;
/*      */         
/* 1750 */         int i34 = 0;
/*      */         
/* 1752 */         if (i22 > i33)
/*      */         {
/* 1754 */           i34 = i22 - i33;
/* 1755 */           i22 = i33;
/*      */         }
/*      */         
/* 1758 */         i20 = 0;
/* 1759 */         int i23 = 0;
/* 1760 */         int i29 = i22 - 1 + (i18 - 1) - 4;
/*      */         int i35;
/* 1762 */         int i3; for (i19 = 0; i19 < i29; i19++)
/*      */         {
/* 1764 */           i35 = i23 & 0xFFFF;
/*      */           
/* 1766 */           i23 = i23 >> 16 & 0xFFFF;
/*      */           
/* 1768 */           i36 = i18 < i19 + 1 ? i18 : i19 + 1;
/*      */           
/* 1770 */           for (i3 = i19 - i22 + 1 > 0 ? i19 - i22 + 1 : 0; i3 < i36; 
/* 1771 */               i3++)
/*      */           {
/* 1773 */             i37 = i34 + i19 - i3;
/*      */             
/*      */ 
/* 1776 */             switch (i3)
/*      */             {
/*      */ 
/*      */             case 8: 
/* 1780 */               i38 = i17 * arrayOfInt[i37];
/*      */               
/* 1782 */               break;
/*      */             
/*      */             case 7: 
/* 1785 */               i38 = i16 * arrayOfInt[i37];
/*      */               
/* 1787 */               break;
/*      */             
/*      */             case 6: 
/* 1790 */               i38 = i15 * arrayOfInt[i37];
/*      */               
/* 1792 */               break;
/*      */             
/*      */             case 5: 
/* 1795 */               i38 = i14 * arrayOfInt[i37];
/*      */               
/* 1797 */               break;
/*      */             
/*      */             case 4: 
/* 1800 */               i38 = i13 * arrayOfInt[i37];
/*      */               
/* 1802 */               break;
/*      */             
/*      */             case 3: 
/* 1805 */               i38 = i12 * arrayOfInt[i37];
/*      */               
/* 1807 */               break;
/*      */             
/*      */             case 2: 
/* 1810 */               i38 = i11 * arrayOfInt[i37];
/*      */               
/* 1812 */               break;
/*      */             
/*      */             case 1: 
/* 1815 */               i38 = i10 * arrayOfInt[i37];
/*      */               
/* 1817 */               break;
/*      */             
/*      */             default: 
/* 1820 */               i38 = i9 * arrayOfInt[i37];
/*      */             }
/*      */             
/*      */             
/*      */ 
/* 1825 */             i35 += (i38 & 0xFFFF);
/* 1826 */             i23 += (i38 >> 16 & 0xFFFF);
/*      */           }
/*      */           
/* 1829 */           i32 = (i32 != 0) || ((i35 & 0xFFFF) != 0) ? 1 : 0;
/* 1830 */           i23 += (i35 >> 16 & 0xFFFF);
/*      */         }
/*      */         
/* 1833 */         i29 += 5;
/* 1835 */         for (; 
/* 1835 */             i19 < i29; i19++)
/*      */         {
/* 1837 */           i35 = i23 & 0xFFFF;
/*      */           
/* 1839 */           i23 = i23 >> 16 & 0xFFFF;
/*      */           
/* 1841 */           i36 = i18 < i19 + 1 ? i18 : i19 + 1;
/*      */           
/* 1843 */           for (i3 = i19 - i22 + 1 > 0 ? i19 - i22 + 1 : 0; i3 < i36; 
/* 1844 */               i3++)
/*      */           {
/* 1846 */             i37 = i34 + i19 - i3;
/*      */             
/*      */ 
/* 1849 */             switch (i3)
/*      */             {
/*      */ 
/*      */             case 8: 
/* 1853 */               i38 = i17 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1858 */               break;
/*      */             
/*      */             case 7: 
/* 1861 */               i38 = i16 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1866 */               break;
/*      */             
/*      */             case 6: 
/* 1869 */               i38 = i15 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1874 */               break;
/*      */             
/*      */             case 5: 
/* 1877 */               i38 = i14 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1882 */               break;
/*      */             
/*      */             case 4: 
/* 1885 */               i38 = i13 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1890 */               break;
/*      */             
/*      */             case 3: 
/* 1893 */               i38 = i12 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1898 */               break;
/*      */             
/*      */             case 2: 
/* 1901 */               i38 = i11 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1906 */               break;
/*      */             
/*      */             case 1: 
/* 1909 */               i38 = i10 * arrayOfInt[i37];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1914 */               break;
/*      */             
/*      */             default: 
/* 1917 */               i38 = i9 * arrayOfInt[i37];
/*      */             }
/*      */             
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1925 */             i35 += (i38 & 0xFFFF);
/* 1926 */             i23 += (i38 >> 16 & 0xFFFF);
/*      */           }
/*      */           
/* 1929 */           switch (i20++)
/*      */           {
/*      */ 
/*      */           case 4: 
/* 1933 */             i28 = i35 & 0xFFFF;
/*      */             
/* 1935 */             break;
/*      */           
/*      */           case 3: 
/* 1938 */             i27 = i35 & 0xFFFF;
/*      */             
/* 1940 */             break;
/*      */           
/*      */           case 2: 
/* 1943 */             i26 = i35 & 0xFFFF;
/*      */             
/* 1945 */             break;
/*      */           
/*      */           case 1: 
/* 1948 */             i25 = i35 & 0xFFFF;
/*      */             
/* 1950 */             break;
/*      */           
/*      */           default: 
/* 1953 */             i24 = i35 & 0xFFFF;
/*      */           }
/*      */           
/*      */           
/*      */ 
/* 1958 */           i23 += (i35 >> 16 & 0xFFFF);
/*      */         }
/*      */         
/* 1961 */         while (i23 != 0)
/*      */         {
/* 1963 */           if (i20 < 5) {
/* 1964 */             switch (i20++)
/*      */             {
/*      */ 
/*      */             case 4: 
/* 1968 */               i28 = i23 & 0xFFFF;
/*      */               
/* 1970 */               break;
/*      */             
/*      */             case 3: 
/* 1973 */               i27 = i23 & 0xFFFF;
/*      */               
/* 1975 */               break;
/*      */             
/*      */             case 2: 
/* 1978 */               i26 = i23 & 0xFFFF;
/*      */               
/* 1980 */               break;
/*      */             
/*      */             case 1: 
/* 1983 */               i25 = i23 & 0xFFFF;
/*      */               
/* 1985 */               break;
/*      */             
/*      */             default: 
/* 1988 */               i24 = i23 & 0xFFFF;
/*      */               
/* 1990 */               break;
/*      */             }
/*      */             
/*      */           } else {
/* 1994 */             i32 = (i32 != 0) || (i24 != 0) ? 1 : 0;
/* 1995 */             i24 = i25;
/* 1996 */             i25 = i26;
/* 1997 */             i26 = i27;
/* 1998 */             i27 = i28;
/* 1999 */             i28 = i23 & 0xFFFF;
/*      */           }
/*      */           
/* 2002 */           i23 = i23 >> 16 & 0xFFFF;
/* 2003 */           i31++;
/*      */         }
/*      */         
/* 2006 */         int i30 = (binexpstable[i21] + i31) * 16 - 1;
/*      */         
/*      */ 
/*      */ 
/* 2010 */         switch (i20)
/*      */         {
/*      */ 
/*      */         case 5: 
/* 2014 */           i35 = i28;
/*      */           
/* 2016 */           break;
/*      */         
/*      */         case 4: 
/* 2019 */           i35 = i27;
/*      */           
/* 2021 */           break;
/*      */         
/*      */         case 3: 
/* 2024 */           i35 = i26;
/*      */           
/* 2026 */           break;
/*      */         
/*      */         case 2: 
/* 2029 */           i35 = i25;
/*      */           
/* 2031 */           break;
/*      */         
/*      */         default: 
/* 2034 */           i35 = i24;
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 2039 */         for (int i36 = i35 >> 1; i36 != 0; i36 >>= 1) {
/* 2040 */           i30++;
/*      */         }
/*      */         
/* 2043 */         i36 = 5;
/* 2044 */         int i37 = i35 << 5;
/* 2045 */         int i38 = 0;
/*      */         
/* 2047 */         i23 = 0;
/*      */         
/* 2049 */         while ((i37 & 0x100000) == 0)
/*      */         {
/* 2051 */           i37 <<= 1;
/* 2052 */           i36++;
/*      */         }
/*      */         
/* 2055 */         switch (i20)
/*      */         {
/*      */ 
/*      */         case 5: 
/* 2059 */           if (i36 > 16)
/*      */           {
/*      */ 
/* 2062 */             i37 |= i27 << i36 - 16 | i26 >> 32 - i36;
/* 2063 */             i38 = i26 << i36 | i25 << i36 - 16 | i24 >> 32 - i36;
/*      */             
/* 2065 */             i23 = i24 & 1 << 31 - i36;
/* 2066 */             i32 = (i32 != 0) || (i24 << i36 + 1 != 0) ? 1 : 0;
/*      */ 
/*      */           }
/* 2069 */           else if (i36 == 16)
/*      */           {
/*      */ 
/* 2072 */             i37 |= i27;
/* 2073 */             i38 = i26 << 16 | i25;
/* 2074 */             i23 = i24 & 0x8000;
/* 2075 */             i32 = (i32 != 0) || ((i24 & 0x7FFF) != 0) ? 1 : 0;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 2081 */             i37 |= i27 >> 16 - i36;
/* 2082 */             i38 = i27 << 16 + i36 | i26 << i36 | i25 >> 16 - i36;
/*      */             
/* 2084 */             i23 = i25 & 1 << 15 - i36;
/*      */             
/* 2086 */             if (i36 < 15) {
/* 2087 */               i32 = (i32 != 0) || (i25 << i36 + 17 != 0) ? 1 : 0;
/*      */             }
/* 2089 */             i32 = (i32 != 0) || (i24 != 0) ? 1 : 0;
/*      */           }
/*      */           
/*      */ 
/* 2093 */           break;
/*      */         
/*      */         case 4: 
/* 2096 */           if (i36 > 16)
/*      */           {
/*      */ 
/* 2099 */             i37 |= i26 << i36 - 16 | i25 >> 32 - i36;
/* 2100 */             i38 = i25 << i36 | i24 << i36 - 16;
/*      */ 
/*      */           }
/* 2103 */           else if (i36 == 16)
/*      */           {
/*      */ 
/* 2106 */             i37 |= i26;
/*      */             
/* 2108 */             i38 = i25 << 16 | i24;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 2114 */             i37 |= i26 >> 16 - i36;
/* 2115 */             i38 = i26 << 16 + i36 | i25 << i36 | i24 >> 16 - i36;
/*      */             
/* 2117 */             i23 = i24 & 1 << 15 - i36;
/*      */             
/* 2119 */             if (i36 < 15) {
/* 2120 */               i32 = (i32 != 0) || (i24 << i36 + 17 != 0) ? 1 : 0;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 3: 
/* 2127 */           if (i36 > 16)
/*      */           {
/*      */ 
/* 2130 */             i37 |= i25 << i36 - 16 | i24 >> 32 - i36;
/* 2131 */             i38 = i24 << i36;
/*      */ 
/*      */           }
/* 2134 */           else if (i36 == 16)
/*      */           {
/*      */ 
/* 2137 */             i37 |= i25;
/*      */             
/* 2139 */             i38 = i24 << 16;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 2145 */             i37 |= i25 >> 16 - i36;
/* 2146 */             i38 = i25 << 16 + i36;
/*      */             
/* 2148 */             i38 |= i24 << i36;
/*      */           }
/*      */           
/*      */ 
/* 2152 */           break;
/*      */         
/*      */         case 2: 
/* 2155 */           if (i36 > 16)
/*      */           {
/*      */ 
/* 2158 */             i37 |= i24 << i36 - 16;
/*      */ 
/*      */           }
/* 2161 */           else if (i36 == 16)
/*      */           {
/*      */ 
/* 2164 */             i37 |= i24;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 2170 */             i37 |= i24 >> 16 - i36;
/* 2171 */             i38 = i24 << 16 + i36;
/*      */           }
/*      */           
/*      */ 
/* 2175 */           break;
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/* 2181 */         if ((i23 != 0) && ((i32 != 0) || ((i38 & 0x1) != 0)))
/*      */         {
/* 2183 */           if (i38 == -1)
/*      */           {
/* 2185 */             i38 = 0;
/* 2186 */             i37++;
/*      */             
/* 2188 */             if ((i37 & 0x200000) != 0)
/*      */             {
/* 2190 */               i38 = i38 >> 1 | i37 << 31;
/* 2191 */               i37 >>= 1;
/* 2192 */               i30++;
/*      */             }
/*      */           }
/*      */           else {
/* 2196 */             i38++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2209 */         long l = i30 << 52 | (i37 & 0xFFFFF) << 32 | i38 & 0xFFFFFFFF;
/*      */         
/*      */ 
/* 2212 */         d2 = Double.longBitsToDouble(l);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2221 */       d1 = i7 != 0 ? d2 : -d2;
/*      */     }
/*      */     
/* 2224 */     return d1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   double getDoubleImprecise(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2239 */     double d1 = 0.0D;
/*      */     
/* 2241 */     if (this.rowSpaceIndicator == null) {
/* 2242 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 2246 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/* 2249 */       byte[] arrayOfByte = this.rowSpaceByte;
/* 2250 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 2251 */       int j = arrayOfByte[(i - 1)];
/*      */       
/* 2253 */       int k = arrayOfByte[i];
/*      */       
/*      */ 
/* 2256 */       double d2 = 0.0D;
/*      */       
/* 2258 */       int i1 = i + 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2269 */       if ((k & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2274 */         if ((k == -128) && (j == 1)) {
/* 2275 */           return 0.0D;
/*      */         }
/* 2277 */         if ((j == 2) && (k == -1) && (arrayOfByte[(i + 1)] == 101))
/*      */         {
/* 2279 */           return Double.POSITIVE_INFINITY;
/*      */         }
/* 2281 */         m = (byte)((k & 0xFF7F) - 65);
/*      */         
/* 2283 */         i3 = j - 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2291 */         n = (int)(127.0D - m);
/*      */         
/* 2293 */         i2 = i3 % 4;
/*      */         
/* 2295 */         switch (i2)
/*      */         {
/*      */ 
/*      */         case 1: 
/* 2299 */           d2 = (arrayOfByte[i1] - 1) * factorTable[n];
/*      */           
/* 2301 */           break;
/*      */         
/*      */         case 2: 
/* 2304 */           d2 = ((arrayOfByte[i1] - 1) * 100 + (arrayOfByte[(i1 + 1)] - 1)) * factorTable[(n + 1)];
/*      */           
/*      */ 
/* 2307 */           break;
/*      */         
/*      */         case 3: 
/* 2310 */           d2 = ((arrayOfByte[i1] - 1) * 10000 + (arrayOfByte[(i1 + 1)] - 1) * 100 + (arrayOfByte[(i1 + 2)] - 1)) * factorTable[(n + 2)];
/*      */           
/*      */ 
/*      */ 
/* 2314 */           break;
/*      */         }
/*      */         
/* 2320 */         for (; 
/*      */             
/*      */ 
/* 2320 */             i2 < i3; i2 += 4) {
/* 2321 */           d2 += ((arrayOfByte[(i1 + i2)] - 1) * 1000000 + (arrayOfByte[(i1 + i2 + 1)] - 1) * 10000 + (arrayOfByte[(i1 + i2 + 2)] - 1) * 100 + (arrayOfByte[(i1 + i2 + 3)] - 1)) * factorTable[(n + i2 + 3)];
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2331 */       if ((k == 0) && (j == 1)) {
/* 2332 */         return Double.NEGATIVE_INFINITY;
/*      */       }
/* 2334 */       int m = (byte)(((k ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */       
/* 2336 */       int i3 = j - 1;
/*      */       
/* 2338 */       if ((i3 != 20) || (arrayOfByte[(i + i3)] == 102)) {
/* 2339 */         i3--;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2347 */       int n = (int)(127.0D - m);
/*      */       
/* 2349 */       int i2 = i3 % 4;
/*      */       
/* 2351 */       switch (i2)
/*      */       {
/*      */ 
/*      */       case 1: 
/* 2355 */         d2 = (101 - arrayOfByte[i1]) * factorTable[n];
/*      */         
/* 2357 */         break;
/*      */       
/*      */       case 2: 
/* 2360 */         d2 = ((101 - arrayOfByte[i1]) * 100 + (101 - arrayOfByte[(i1 + 1)])) * factorTable[(n + 1)];
/*      */         
/*      */ 
/* 2363 */         break;
/*      */       
/*      */       case 3: 
/* 2366 */         d2 = ((101 - arrayOfByte[i1]) * 10000 + (101 - arrayOfByte[(i1 + 1)]) * 100 + (101 - arrayOfByte[(i1 + 2)])) * factorTable[(n + 2)];
/*      */         
/*      */ 
/*      */ 
/* 2370 */         break;
/*      */       }
/*      */       
/* 2376 */       for (; 
/*      */           
/*      */ 
/* 2376 */           i2 < i3; i2 += 4) {
/* 2377 */         d2 += ((101 - arrayOfByte[(i1 + i2)]) * 1000000 + (101 - arrayOfByte[(i1 + i2 + 1)]) * 10000 + (101 - arrayOfByte[(i1 + i2 + 2)]) * 100 + (101 - arrayOfByte[(i1 + i2 + 3)])) * factorTable[(n + i2 + 3)];
/*      */       }
/*      */       
/*      */ 
/* 2381 */       d2 = -d2;
/*      */       
/*      */ 
/*      */ 
/* 2385 */       d1 = d2;
/*      */     }
/*      */     
/* 2388 */     return d1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2404 */     BigDecimal localBigDecimal = null;
/*      */     
/* 2406 */     if (this.rowSpaceIndicator == null) {
/* 2407 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 2411 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/* 2414 */       byte[] arrayOfByte1 = this.rowSpaceByte;
/* 2415 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 2416 */       int j = arrayOfByte1[(i - 1)];
/*      */       
/* 2418 */       int k = 0;
/* 2419 */       int m = 0;
/* 2420 */       int n = 0;
/* 2421 */       int i1 = 0;
/* 2422 */       int i2 = 0;
/* 2423 */       int i3 = 0;
/* 2424 */       int i4 = 0;
/* 2425 */       int i5 = 0;
/* 2426 */       int i6 = 0;
/* 2427 */       int i7 = 0;
/* 2428 */       int i8 = 0;
/* 2429 */       int i9 = 0;
/* 2430 */       int i10 = 0;
/* 2431 */       int i11 = 0;
/* 2432 */       int i12 = 0;
/* 2433 */       int i13 = 0;
/* 2434 */       int i14 = 0;
/* 2435 */       int i15 = 0;
/* 2436 */       int i16 = 0;
/* 2437 */       int i17 = 0;
/* 2438 */       int i18 = 0;
/* 2439 */       int i19 = 0;
/* 2440 */       int i20 = 0;
/* 2441 */       int i21 = 0;
/* 2442 */       int i22 = 0;
/* 2443 */       int i23 = 0;
/* 2444 */       int i24 = 0;
/* 2445 */       int i25 = 1;
/*      */       
/* 2447 */       int i27 = 26;
/* 2448 */       int i28 = 0;
/*      */       
/*      */ 
/* 2451 */       int i31 = arrayOfByte1[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2456 */       int i36 = 0;
/*      */       
/* 2458 */       if ((i31 & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2466 */         if ((i31 == -128) && (j == 1)) {
/* 2467 */           return BIGDEC_ZERO;
/*      */         }
/* 2469 */         if ((j == 2) && (i31 == -1) && (arrayOfByte1[(i + 1)] == 101))
/*      */         {
/*      */ 
/*      */ 
/* 2473 */           throwOverflow();
/*      */         }
/* 2475 */         i32 = 1;
/* 2476 */         i33 = (byte)((i31 & 0xFF7F) - 65);
/*      */         
/*      */ 
/* 2479 */         i30 = j - 1;
/* 2480 */         i26 = i30 - 1;
/* 2481 */         i34 = i33 - i30 + 1 << 1;
/*      */         
/* 2483 */         if (i34 > 0)
/*      */         {
/* 2485 */           i34 = 0;
/* 2486 */           i26 = i33;
/*      */         }
/* 2488 */         else if (i34 < 0) {
/* 2489 */           i36 = (arrayOfByte1[(i + i30)] - 1) % 10 == 0 ? 1 : 0;
/*      */         }
/* 2491 */         i25 = (byte)(i25 + 1);i24 = arrayOfByte1[(i + i25)] - 1;
/*      */         
/* 2493 */         while ((i26 & 0x1) != 0)
/*      */         {
/* 2495 */           if (i25 > i30) {
/* 2496 */             i24 *= 100;
/*      */           } else {
/* 2498 */             i25 = (byte)(i25 + 1);i24 = i24 * 100 + (arrayOfByte1[(i + i25)] - 1);
/*      */           }
/* 2500 */           i26--;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2511 */       if ((i31 == 0) && (j == 1))
/*      */       {
/*      */ 
/* 2514 */         throwOverflow();
/*      */       }
/* 2516 */       int i32 = -1;
/* 2517 */       int i33 = (byte)(((i31 ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */       
/*      */ 
/* 2520 */       int i30 = j - 1;
/*      */       
/* 2522 */       if ((i30 != 20) || (arrayOfByte1[(i + i30)] == 102)) {
/* 2523 */         i30--;
/*      */       }
/* 2525 */       int i26 = i30 - 1;
/*      */       
/* 2527 */       int i34 = i33 - i30 + 1 << 1;
/*      */       
/* 2529 */       if (i34 > 0)
/*      */       {
/* 2531 */         i34 = 0;
/* 2532 */         i26 = i33;
/*      */       }
/* 2534 */       else if (i34 < 0) {
/* 2535 */         i36 = (101 - arrayOfByte1[(i + i30)]) % 10 == 0 ? 1 : 0;
/*      */       }
/* 2537 */       i25 = (byte)(i25 + 1);i24 = 101 - arrayOfByte1[(i + i25)];
/*      */       
/* 2539 */       while ((i26 & 0x1) != 0)
/*      */       {
/* 2541 */         if (i25 > i30) {
/* 2542 */           i24 *= 100;
/*      */         } else {
/* 2544 */           i25 = (byte)(i25 + 1);i24 = i24 * 100 + (101 - arrayOfByte1[(i + i25)]);
/*      */         }
/* 2546 */         i26--;
/*      */       }
/*      */       
/*      */ 
/* 2550 */       if (i36 != 0)
/*      */       {
/* 2552 */         i34++;
/* 2553 */         i24 /= 10;
/*      */       }
/*      */       
/* 2556 */       int i35 = i30 - 1;
/*      */       
/* 2558 */       while (i26 != 0) {
/*      */         int i37;
/* 2560 */         if (i32 == 1)
/*      */         {
/* 2562 */           if (i36 != 0)
/*      */           {
/* 2564 */             i28 = (arrayOfByte1[(i + i25 - 1)] - 1) % 10 * 1000 + (arrayOfByte1[(i + i25)] - 1) * 10 + (arrayOfByte1[(i + i25 + 1)] - 1) / 10 + i24 * 10000;
/*      */             
/*      */ 
/* 2567 */             i25 = (byte)(i25 + 2);
/*      */           }
/* 2569 */           else if (i25 < i35)
/*      */           {
/* 2571 */             i28 = (arrayOfByte1[(i + i25)] - 1) * 100 + (arrayOfByte1[(i + i25 + 1)] - 1) + i24 * 10000;
/*      */             
/*      */ 
/* 2574 */             i25 = (byte)(i25 + 2);
/*      */           }
/*      */           else
/*      */           {
/* 2578 */             i28 = 0;
/*      */             
/* 2580 */             if (i25 <= i30)
/*      */             {
/* 2582 */               for (i37 = 0; 
/*      */                   
/* 2584 */                   i25 <= i30; i37++) {
/* 2585 */                 i25 = (byte)(i25 + 1);i28 = i28 * 100 + (arrayOfByte1[(i + i25)] - 1);
/*      */               }
/* 2587 */               for (; i37 < 2; i37++) {
/* 2588 */                 i28 *= 100;
/*      */               }
/*      */             }
/* 2591 */             i28 += i24 * 10000;
/*      */           }
/*      */         }
/* 2594 */         else if (i36 != 0)
/*      */         {
/* 2596 */           i28 = (101 - arrayOfByte1[(i + i25 - 1)]) % 10 * 1000 + (101 - arrayOfByte1[(i + i25)]) * 10 + (101 - arrayOfByte1[(i + i25 + 1)]) / 10 + i24 * 10000;
/*      */           
/*      */ 
/* 2599 */           i25 = (byte)(i25 + 2);
/*      */         }
/* 2601 */         else if (i25 < i35)
/*      */         {
/* 2603 */           i28 = (101 - arrayOfByte1[(i + i25)]) * 100 + (101 - arrayOfByte1[(i + i25 + 1)]) + i24 * 10000;
/*      */           
/*      */ 
/* 2606 */           i25 = (byte)(i25 + 2);
/*      */         }
/*      */         else
/*      */         {
/* 2610 */           i28 = 0;
/*      */           
/* 2612 */           if (i25 <= i30)
/*      */           {
/* 2614 */             for (i37 = 0; 
/*      */                 
/* 2616 */                 i25 <= i30; i37++) {
/* 2617 */               i25 = (byte)(i25 + 1);i28 = i28 * 100 + (101 - arrayOfByte1[(i + i25)]);
/*      */             }
/* 2619 */             for (; i37 < 2; i37++) {
/* 2620 */               i28 *= 100;
/*      */             }
/*      */           }
/* 2623 */           i28 += i24 * 10000;
/*      */         }
/*      */         
/* 2626 */         switch (i27)
/*      */         {
/*      */ 
/*      */         case 26: 
/* 2630 */           i24 = i28 & 0xFFFF;
/* 2631 */           i28 >>= 16;
/*      */           
/* 2633 */           if (i28 != 0)
/*      */           {
/* 2635 */             i27 = (byte)(i27 - 1);
/* 2636 */             i23 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 25: 
/* 2642 */           i24 = i28 & 0xFFFF;
/* 2643 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2644 */           i23 = i28 & 0xFFFF;
/* 2645 */           i28 >>= 16;
/*      */           
/* 2647 */           if (i28 != 0)
/*      */           {
/* 2649 */             i27 = (byte)(i27 - 1);
/* 2650 */             i22 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 24: 
/* 2656 */           i24 = i28 & 0xFFFF;
/* 2657 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2658 */           i23 = i28 & 0xFFFF;
/* 2659 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2660 */           i22 = i28 & 0xFFFF;
/* 2661 */           i28 >>= 16;
/*      */           
/* 2663 */           if (i28 != 0)
/*      */           {
/* 2665 */             i27 = (byte)(i27 - 1);
/* 2666 */             i21 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 23: 
/* 2672 */           i24 = i28 & 0xFFFF;
/* 2673 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2674 */           i23 = i28 & 0xFFFF;
/* 2675 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2676 */           i22 = i28 & 0xFFFF;
/* 2677 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2678 */           i21 = i28 & 0xFFFF;
/* 2679 */           i28 >>= 16;
/*      */           
/* 2681 */           if (i28 != 0)
/*      */           {
/* 2683 */             i27 = (byte)(i27 - 1);
/* 2684 */             i20 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 22: 
/* 2690 */           i24 = i28 & 0xFFFF;
/* 2691 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2692 */           i23 = i28 & 0xFFFF;
/* 2693 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2694 */           i22 = i28 & 0xFFFF;
/* 2695 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2696 */           i21 = i28 & 0xFFFF;
/* 2697 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2698 */           i20 = i28 & 0xFFFF;
/* 2699 */           i28 >>= 16;
/*      */           
/* 2701 */           if (i28 != 0)
/*      */           {
/* 2703 */             i27 = (byte)(i27 - 1);
/* 2704 */             i19 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 21: 
/* 2710 */           i24 = i28 & 0xFFFF;
/* 2711 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2712 */           i23 = i28 & 0xFFFF;
/* 2713 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2714 */           i22 = i28 & 0xFFFF;
/* 2715 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2716 */           i21 = i28 & 0xFFFF;
/* 2717 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2718 */           i20 = i28 & 0xFFFF;
/* 2719 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2720 */           i19 = i28 & 0xFFFF;
/* 2721 */           i28 >>= 16;
/*      */           
/* 2723 */           if (i28 != 0)
/*      */           {
/* 2725 */             i27 = (byte)(i27 - 1);
/* 2726 */             i18 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 20: 
/* 2732 */           i24 = i28 & 0xFFFF;
/* 2733 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2734 */           i23 = i28 & 0xFFFF;
/* 2735 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2736 */           i22 = i28 & 0xFFFF;
/* 2737 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2738 */           i21 = i28 & 0xFFFF;
/* 2739 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2740 */           i20 = i28 & 0xFFFF;
/* 2741 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2742 */           i19 = i28 & 0xFFFF;
/* 2743 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2744 */           i18 = i28 & 0xFFFF;
/* 2745 */           i28 >>= 16;
/*      */           
/* 2747 */           if (i28 != 0)
/*      */           {
/* 2749 */             i27 = (byte)(i27 - 1);
/* 2750 */             i17 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 19: 
/* 2756 */           i24 = i28 & 0xFFFF;
/* 2757 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2758 */           i23 = i28 & 0xFFFF;
/* 2759 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2760 */           i22 = i28 & 0xFFFF;
/* 2761 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2762 */           i21 = i28 & 0xFFFF;
/* 2763 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2764 */           i20 = i28 & 0xFFFF;
/* 2765 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2766 */           i19 = i28 & 0xFFFF;
/* 2767 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2768 */           i18 = i28 & 0xFFFF;
/* 2769 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2770 */           i17 = i28 & 0xFFFF;
/* 2771 */           i28 >>= 16;
/*      */           
/* 2773 */           if (i28 != 0)
/*      */           {
/* 2775 */             i27 = (byte)(i27 - 1);
/* 2776 */             i16 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 18: 
/* 2782 */           i24 = i28 & 0xFFFF;
/* 2783 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2784 */           i23 = i28 & 0xFFFF;
/* 2785 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2786 */           i22 = i28 & 0xFFFF;
/* 2787 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2788 */           i21 = i28 & 0xFFFF;
/* 2789 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2790 */           i20 = i28 & 0xFFFF;
/* 2791 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2792 */           i19 = i28 & 0xFFFF;
/* 2793 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2794 */           i18 = i28 & 0xFFFF;
/* 2795 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2796 */           i17 = i28 & 0xFFFF;
/* 2797 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2798 */           i16 = i28 & 0xFFFF;
/* 2799 */           i28 >>= 16;
/*      */           
/* 2801 */           if (i28 != 0)
/*      */           {
/* 2803 */             i27 = (byte)(i27 - 1);
/* 2804 */             i15 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 17: 
/* 2810 */           i24 = i28 & 0xFFFF;
/* 2811 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2812 */           i23 = i28 & 0xFFFF;
/* 2813 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2814 */           i22 = i28 & 0xFFFF;
/* 2815 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2816 */           i21 = i28 & 0xFFFF;
/* 2817 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2818 */           i20 = i28 & 0xFFFF;
/* 2819 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2820 */           i19 = i28 & 0xFFFF;
/* 2821 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2822 */           i18 = i28 & 0xFFFF;
/* 2823 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2824 */           i17 = i28 & 0xFFFF;
/* 2825 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2826 */           i16 = i28 & 0xFFFF;
/* 2827 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2828 */           i15 = i28 & 0xFFFF;
/* 2829 */           i28 >>= 16;
/*      */           
/* 2831 */           if (i28 != 0)
/*      */           {
/* 2833 */             i27 = (byte)(i27 - 1);
/* 2834 */             i14 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 16: 
/* 2840 */           i24 = i28 & 0xFFFF;
/* 2841 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2842 */           i23 = i28 & 0xFFFF;
/* 2843 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2844 */           i22 = i28 & 0xFFFF;
/* 2845 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2846 */           i21 = i28 & 0xFFFF;
/* 2847 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2848 */           i20 = i28 & 0xFFFF;
/* 2849 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2850 */           i19 = i28 & 0xFFFF;
/* 2851 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2852 */           i18 = i28 & 0xFFFF;
/* 2853 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2854 */           i17 = i28 & 0xFFFF;
/* 2855 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2856 */           i16 = i28 & 0xFFFF;
/* 2857 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2858 */           i15 = i28 & 0xFFFF;
/* 2859 */           i28 = (i28 >> 16) + i14 * 10000;
/* 2860 */           i14 = i28 & 0xFFFF;
/* 2861 */           i28 >>= 16;
/*      */           
/* 2863 */           if (i28 != 0)
/*      */           {
/* 2865 */             i27 = (byte)(i27 - 1);
/* 2866 */             i13 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 15: 
/* 2872 */           i24 = i28 & 0xFFFF;
/* 2873 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2874 */           i23 = i28 & 0xFFFF;
/* 2875 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2876 */           i22 = i28 & 0xFFFF;
/* 2877 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2878 */           i21 = i28 & 0xFFFF;
/* 2879 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2880 */           i20 = i28 & 0xFFFF;
/* 2881 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2882 */           i19 = i28 & 0xFFFF;
/* 2883 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2884 */           i18 = i28 & 0xFFFF;
/* 2885 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2886 */           i17 = i28 & 0xFFFF;
/* 2887 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2888 */           i16 = i28 & 0xFFFF;
/* 2889 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2890 */           i15 = i28 & 0xFFFF;
/* 2891 */           i28 = (i28 >> 16) + i14 * 10000;
/* 2892 */           i14 = i28 & 0xFFFF;
/* 2893 */           i28 = (i28 >> 16) + i13 * 10000;
/* 2894 */           i13 = i28 & 0xFFFF;
/* 2895 */           i28 >>= 16;
/*      */           
/* 2897 */           if (i28 != 0)
/*      */           {
/* 2899 */             i27 = (byte)(i27 - 1);
/* 2900 */             i12 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 14: 
/* 2906 */           i24 = i28 & 0xFFFF;
/* 2907 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2908 */           i23 = i28 & 0xFFFF;
/* 2909 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2910 */           i22 = i28 & 0xFFFF;
/* 2911 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2912 */           i21 = i28 & 0xFFFF;
/* 2913 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2914 */           i20 = i28 & 0xFFFF;
/* 2915 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2916 */           i19 = i28 & 0xFFFF;
/* 2917 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2918 */           i18 = i28 & 0xFFFF;
/* 2919 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2920 */           i17 = i28 & 0xFFFF;
/* 2921 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2922 */           i16 = i28 & 0xFFFF;
/* 2923 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2924 */           i15 = i28 & 0xFFFF;
/* 2925 */           i28 = (i28 >> 16) + i14 * 10000;
/* 2926 */           i14 = i28 & 0xFFFF;
/* 2927 */           i28 = (i28 >> 16) + i13 * 10000;
/* 2928 */           i13 = i28 & 0xFFFF;
/* 2929 */           i28 = (i28 >> 16) + i12 * 10000;
/* 2930 */           i12 = i28 & 0xFFFF;
/* 2931 */           i28 >>= 16;
/*      */           
/* 2933 */           if (i28 != 0)
/*      */           {
/* 2935 */             i27 = (byte)(i27 - 1);
/* 2936 */             i11 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 13: 
/* 2942 */           i24 = i28 & 0xFFFF;
/* 2943 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2944 */           i23 = i28 & 0xFFFF;
/* 2945 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2946 */           i22 = i28 & 0xFFFF;
/* 2947 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2948 */           i21 = i28 & 0xFFFF;
/* 2949 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2950 */           i20 = i28 & 0xFFFF;
/* 2951 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2952 */           i19 = i28 & 0xFFFF;
/* 2953 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2954 */           i18 = i28 & 0xFFFF;
/* 2955 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2956 */           i17 = i28 & 0xFFFF;
/* 2957 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2958 */           i16 = i28 & 0xFFFF;
/* 2959 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2960 */           i15 = i28 & 0xFFFF;
/* 2961 */           i28 = (i28 >> 16) + i14 * 10000;
/* 2962 */           i14 = i28 & 0xFFFF;
/* 2963 */           i28 = (i28 >> 16) + i13 * 10000;
/* 2964 */           i13 = i28 & 0xFFFF;
/* 2965 */           i28 = (i28 >> 16) + i12 * 10000;
/* 2966 */           i12 = i28 & 0xFFFF;
/* 2967 */           i28 = (i28 >> 16) + i11 * 10000;
/* 2968 */           i11 = i28 & 0xFFFF;
/* 2969 */           i28 >>= 16;
/*      */           
/* 2971 */           if (i28 != 0)
/*      */           {
/* 2973 */             i27 = (byte)(i27 - 1);
/* 2974 */             i10 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 12: 
/* 2980 */           i24 = i28 & 0xFFFF;
/* 2981 */           i28 = (i28 >> 16) + i23 * 10000;
/* 2982 */           i23 = i28 & 0xFFFF;
/* 2983 */           i28 = (i28 >> 16) + i22 * 10000;
/* 2984 */           i22 = i28 & 0xFFFF;
/* 2985 */           i28 = (i28 >> 16) + i21 * 10000;
/* 2986 */           i21 = i28 & 0xFFFF;
/* 2987 */           i28 = (i28 >> 16) + i20 * 10000;
/* 2988 */           i20 = i28 & 0xFFFF;
/* 2989 */           i28 = (i28 >> 16) + i19 * 10000;
/* 2990 */           i19 = i28 & 0xFFFF;
/* 2991 */           i28 = (i28 >> 16) + i18 * 10000;
/* 2992 */           i18 = i28 & 0xFFFF;
/* 2993 */           i28 = (i28 >> 16) + i17 * 10000;
/* 2994 */           i17 = i28 & 0xFFFF;
/* 2995 */           i28 = (i28 >> 16) + i16 * 10000;
/* 2996 */           i16 = i28 & 0xFFFF;
/* 2997 */           i28 = (i28 >> 16) + i15 * 10000;
/* 2998 */           i15 = i28 & 0xFFFF;
/* 2999 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3000 */           i14 = i28 & 0xFFFF;
/* 3001 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3002 */           i13 = i28 & 0xFFFF;
/* 3003 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3004 */           i12 = i28 & 0xFFFF;
/* 3005 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3006 */           i11 = i28 & 0xFFFF;
/* 3007 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3008 */           i10 = i28 & 0xFFFF;
/* 3009 */           i28 >>= 16;
/*      */           
/* 3011 */           if (i28 != 0)
/*      */           {
/* 3013 */             i27 = (byte)(i27 - 1);
/* 3014 */             i9 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 11: 
/* 3020 */           i24 = i28 & 0xFFFF;
/* 3021 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3022 */           i23 = i28 & 0xFFFF;
/* 3023 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3024 */           i22 = i28 & 0xFFFF;
/* 3025 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3026 */           i21 = i28 & 0xFFFF;
/* 3027 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3028 */           i20 = i28 & 0xFFFF;
/* 3029 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3030 */           i19 = i28 & 0xFFFF;
/* 3031 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3032 */           i18 = i28 & 0xFFFF;
/* 3033 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3034 */           i17 = i28 & 0xFFFF;
/* 3035 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3036 */           i16 = i28 & 0xFFFF;
/* 3037 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3038 */           i15 = i28 & 0xFFFF;
/* 3039 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3040 */           i14 = i28 & 0xFFFF;
/* 3041 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3042 */           i13 = i28 & 0xFFFF;
/* 3043 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3044 */           i12 = i28 & 0xFFFF;
/* 3045 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3046 */           i11 = i28 & 0xFFFF;
/* 3047 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3048 */           i10 = i28 & 0xFFFF;
/* 3049 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3050 */           i9 = i28 & 0xFFFF;
/* 3051 */           i28 >>= 16;
/*      */           
/* 3053 */           if (i28 != 0)
/*      */           {
/* 3055 */             i27 = (byte)(i27 - 1);
/* 3056 */             i8 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 10: 
/* 3062 */           i24 = i28 & 0xFFFF;
/* 3063 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3064 */           i23 = i28 & 0xFFFF;
/* 3065 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3066 */           i22 = i28 & 0xFFFF;
/* 3067 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3068 */           i21 = i28 & 0xFFFF;
/* 3069 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3070 */           i20 = i28 & 0xFFFF;
/* 3071 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3072 */           i19 = i28 & 0xFFFF;
/* 3073 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3074 */           i18 = i28 & 0xFFFF;
/* 3075 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3076 */           i17 = i28 & 0xFFFF;
/* 3077 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3078 */           i16 = i28 & 0xFFFF;
/* 3079 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3080 */           i15 = i28 & 0xFFFF;
/* 3081 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3082 */           i14 = i28 & 0xFFFF;
/* 3083 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3084 */           i13 = i28 & 0xFFFF;
/* 3085 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3086 */           i12 = i28 & 0xFFFF;
/* 3087 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3088 */           i11 = i28 & 0xFFFF;
/* 3089 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3090 */           i10 = i28 & 0xFFFF;
/* 3091 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3092 */           i9 = i28 & 0xFFFF;
/* 3093 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3094 */           i8 = i28 & 0xFFFF;
/* 3095 */           i28 >>= 16;
/*      */           
/* 3097 */           if (i28 != 0)
/*      */           {
/* 3099 */             i27 = (byte)(i27 - 1);
/* 3100 */             i7 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 9: 
/* 3106 */           i24 = i28 & 0xFFFF;
/* 3107 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3108 */           i23 = i28 & 0xFFFF;
/* 3109 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3110 */           i22 = i28 & 0xFFFF;
/* 3111 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3112 */           i21 = i28 & 0xFFFF;
/* 3113 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3114 */           i20 = i28 & 0xFFFF;
/* 3115 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3116 */           i19 = i28 & 0xFFFF;
/* 3117 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3118 */           i18 = i28 & 0xFFFF;
/* 3119 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3120 */           i17 = i28 & 0xFFFF;
/* 3121 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3122 */           i16 = i28 & 0xFFFF;
/* 3123 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3124 */           i15 = i28 & 0xFFFF;
/* 3125 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3126 */           i14 = i28 & 0xFFFF;
/* 3127 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3128 */           i13 = i28 & 0xFFFF;
/* 3129 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3130 */           i12 = i28 & 0xFFFF;
/* 3131 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3132 */           i11 = i28 & 0xFFFF;
/* 3133 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3134 */           i10 = i28 & 0xFFFF;
/* 3135 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3136 */           i9 = i28 & 0xFFFF;
/* 3137 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3138 */           i8 = i28 & 0xFFFF;
/* 3139 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3140 */           i7 = i28 & 0xFFFF;
/* 3141 */           i28 >>= 16;
/*      */           
/* 3143 */           if (i28 != 0)
/*      */           {
/* 3145 */             i27 = (byte)(i27 - 1);
/* 3146 */             i6 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 8: 
/* 3152 */           i24 = i28 & 0xFFFF;
/* 3153 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3154 */           i23 = i28 & 0xFFFF;
/* 3155 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3156 */           i22 = i28 & 0xFFFF;
/* 3157 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3158 */           i21 = i28 & 0xFFFF;
/* 3159 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3160 */           i20 = i28 & 0xFFFF;
/* 3161 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3162 */           i19 = i28 & 0xFFFF;
/* 3163 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3164 */           i18 = i28 & 0xFFFF;
/* 3165 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3166 */           i17 = i28 & 0xFFFF;
/* 3167 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3168 */           i16 = i28 & 0xFFFF;
/* 3169 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3170 */           i15 = i28 & 0xFFFF;
/* 3171 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3172 */           i14 = i28 & 0xFFFF;
/* 3173 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3174 */           i13 = i28 & 0xFFFF;
/* 3175 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3176 */           i12 = i28 & 0xFFFF;
/* 3177 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3178 */           i11 = i28 & 0xFFFF;
/* 3179 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3180 */           i10 = i28 & 0xFFFF;
/* 3181 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3182 */           i9 = i28 & 0xFFFF;
/* 3183 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3184 */           i8 = i28 & 0xFFFF;
/* 3185 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3186 */           i7 = i28 & 0xFFFF;
/* 3187 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3188 */           i6 = i28 & 0xFFFF;
/* 3189 */           i28 >>= 16;
/*      */           
/* 3191 */           if (i28 != 0)
/*      */           {
/* 3193 */             i27 = (byte)(i27 - 1);
/* 3194 */             i5 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 7: 
/* 3200 */           i24 = i28 & 0xFFFF;
/* 3201 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3202 */           i23 = i28 & 0xFFFF;
/* 3203 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3204 */           i22 = i28 & 0xFFFF;
/* 3205 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3206 */           i21 = i28 & 0xFFFF;
/* 3207 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3208 */           i20 = i28 & 0xFFFF;
/* 3209 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3210 */           i19 = i28 & 0xFFFF;
/* 3211 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3212 */           i18 = i28 & 0xFFFF;
/* 3213 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3214 */           i17 = i28 & 0xFFFF;
/* 3215 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3216 */           i16 = i28 & 0xFFFF;
/* 3217 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3218 */           i15 = i28 & 0xFFFF;
/* 3219 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3220 */           i14 = i28 & 0xFFFF;
/* 3221 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3222 */           i13 = i28 & 0xFFFF;
/* 3223 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3224 */           i12 = i28 & 0xFFFF;
/* 3225 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3226 */           i11 = i28 & 0xFFFF;
/* 3227 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3228 */           i10 = i28 & 0xFFFF;
/* 3229 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3230 */           i9 = i28 & 0xFFFF;
/* 3231 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3232 */           i8 = i28 & 0xFFFF;
/* 3233 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3234 */           i7 = i28 & 0xFFFF;
/* 3235 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3236 */           i6 = i28 & 0xFFFF;
/* 3237 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3238 */           i5 = i28 & 0xFFFF;
/* 3239 */           i28 >>= 16;
/*      */           
/* 3241 */           if (i28 != 0)
/*      */           {
/* 3243 */             i27 = (byte)(i27 - 1);
/* 3244 */             i4 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 6: 
/* 3250 */           i24 = i28 & 0xFFFF;
/* 3251 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3252 */           i23 = i28 & 0xFFFF;
/* 3253 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3254 */           i22 = i28 & 0xFFFF;
/* 3255 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3256 */           i21 = i28 & 0xFFFF;
/* 3257 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3258 */           i20 = i28 & 0xFFFF;
/* 3259 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3260 */           i19 = i28 & 0xFFFF;
/* 3261 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3262 */           i18 = i28 & 0xFFFF;
/* 3263 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3264 */           i17 = i28 & 0xFFFF;
/* 3265 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3266 */           i16 = i28 & 0xFFFF;
/* 3267 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3268 */           i15 = i28 & 0xFFFF;
/* 3269 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3270 */           i14 = i28 & 0xFFFF;
/* 3271 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3272 */           i13 = i28 & 0xFFFF;
/* 3273 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3274 */           i12 = i28 & 0xFFFF;
/* 3275 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3276 */           i11 = i28 & 0xFFFF;
/* 3277 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3278 */           i10 = i28 & 0xFFFF;
/* 3279 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3280 */           i9 = i28 & 0xFFFF;
/* 3281 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3282 */           i8 = i28 & 0xFFFF;
/* 3283 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3284 */           i7 = i28 & 0xFFFF;
/* 3285 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3286 */           i6 = i28 & 0xFFFF;
/* 3287 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3288 */           i5 = i28 & 0xFFFF;
/* 3289 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3290 */           i4 = i28 & 0xFFFF;
/* 3291 */           i28 >>= 16;
/*      */           
/* 3293 */           if (i28 != 0)
/*      */           {
/* 3295 */             i27 = (byte)(i27 - 1);
/* 3296 */             i3 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 5: 
/* 3302 */           i24 = i28 & 0xFFFF;
/* 3303 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3304 */           i23 = i28 & 0xFFFF;
/* 3305 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3306 */           i22 = i28 & 0xFFFF;
/* 3307 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3308 */           i21 = i28 & 0xFFFF;
/* 3309 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3310 */           i20 = i28 & 0xFFFF;
/* 3311 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3312 */           i19 = i28 & 0xFFFF;
/* 3313 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3314 */           i18 = i28 & 0xFFFF;
/* 3315 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3316 */           i17 = i28 & 0xFFFF;
/* 3317 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3318 */           i16 = i28 & 0xFFFF;
/* 3319 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3320 */           i15 = i28 & 0xFFFF;
/* 3321 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3322 */           i14 = i28 & 0xFFFF;
/* 3323 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3324 */           i13 = i28 & 0xFFFF;
/* 3325 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3326 */           i12 = i28 & 0xFFFF;
/* 3327 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3328 */           i11 = i28 & 0xFFFF;
/* 3329 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3330 */           i10 = i28 & 0xFFFF;
/* 3331 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3332 */           i9 = i28 & 0xFFFF;
/* 3333 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3334 */           i8 = i28 & 0xFFFF;
/* 3335 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3336 */           i7 = i28 & 0xFFFF;
/* 3337 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3338 */           i6 = i28 & 0xFFFF;
/* 3339 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3340 */           i5 = i28 & 0xFFFF;
/* 3341 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3342 */           i4 = i28 & 0xFFFF;
/* 3343 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3344 */           i3 = i28 & 0xFFFF;
/* 3345 */           i28 >>= 16;
/*      */           
/* 3347 */           if (i28 != 0)
/*      */           {
/* 3349 */             i27 = (byte)(i27 - 1);
/* 3350 */             i2 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 4: 
/* 3356 */           i24 = i28 & 0xFFFF;
/* 3357 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3358 */           i23 = i28 & 0xFFFF;
/* 3359 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3360 */           i22 = i28 & 0xFFFF;
/* 3361 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3362 */           i21 = i28 & 0xFFFF;
/* 3363 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3364 */           i20 = i28 & 0xFFFF;
/* 3365 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3366 */           i19 = i28 & 0xFFFF;
/* 3367 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3368 */           i18 = i28 & 0xFFFF;
/* 3369 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3370 */           i17 = i28 & 0xFFFF;
/* 3371 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3372 */           i16 = i28 & 0xFFFF;
/* 3373 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3374 */           i15 = i28 & 0xFFFF;
/* 3375 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3376 */           i14 = i28 & 0xFFFF;
/* 3377 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3378 */           i13 = i28 & 0xFFFF;
/* 3379 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3380 */           i12 = i28 & 0xFFFF;
/* 3381 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3382 */           i11 = i28 & 0xFFFF;
/* 3383 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3384 */           i10 = i28 & 0xFFFF;
/* 3385 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3386 */           i9 = i28 & 0xFFFF;
/* 3387 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3388 */           i8 = i28 & 0xFFFF;
/* 3389 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3390 */           i7 = i28 & 0xFFFF;
/* 3391 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3392 */           i6 = i28 & 0xFFFF;
/* 3393 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3394 */           i5 = i28 & 0xFFFF;
/* 3395 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3396 */           i4 = i28 & 0xFFFF;
/* 3397 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3398 */           i3 = i28 & 0xFFFF;
/* 3399 */           i28 = (i28 >> 16) + i2 * 10000;
/* 3400 */           i2 = i28 & 0xFFFF;
/* 3401 */           i28 >>= 16;
/*      */           
/* 3403 */           if (i28 != 0)
/*      */           {
/* 3405 */             i27 = (byte)(i27 - 1);
/* 3406 */             i1 = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 3: 
/* 3412 */           i24 = i28 & 0xFFFF;
/* 3413 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3414 */           i23 = i28 & 0xFFFF;
/* 3415 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3416 */           i22 = i28 & 0xFFFF;
/* 3417 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3418 */           i21 = i28 & 0xFFFF;
/* 3419 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3420 */           i20 = i28 & 0xFFFF;
/* 3421 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3422 */           i19 = i28 & 0xFFFF;
/* 3423 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3424 */           i18 = i28 & 0xFFFF;
/* 3425 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3426 */           i17 = i28 & 0xFFFF;
/* 3427 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3428 */           i16 = i28 & 0xFFFF;
/* 3429 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3430 */           i15 = i28 & 0xFFFF;
/* 3431 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3432 */           i14 = i28 & 0xFFFF;
/* 3433 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3434 */           i13 = i28 & 0xFFFF;
/* 3435 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3436 */           i12 = i28 & 0xFFFF;
/* 3437 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3438 */           i11 = i28 & 0xFFFF;
/* 3439 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3440 */           i10 = i28 & 0xFFFF;
/* 3441 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3442 */           i9 = i28 & 0xFFFF;
/* 3443 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3444 */           i8 = i28 & 0xFFFF;
/* 3445 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3446 */           i7 = i28 & 0xFFFF;
/* 3447 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3448 */           i6 = i28 & 0xFFFF;
/* 3449 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3450 */           i5 = i28 & 0xFFFF;
/* 3451 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3452 */           i4 = i28 & 0xFFFF;
/* 3453 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3454 */           i3 = i28 & 0xFFFF;
/* 3455 */           i28 = (i28 >> 16) + i2 * 10000;
/* 3456 */           i2 = i28 & 0xFFFF;
/* 3457 */           i28 = (i28 >> 16) + i1 * 10000;
/* 3458 */           i1 = i28 & 0xFFFF;
/* 3459 */           i28 >>= 16;
/*      */           
/* 3461 */           if (i28 != 0)
/*      */           {
/* 3463 */             i27 = (byte)(i27 - 1);
/* 3464 */             n = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 2: 
/* 3470 */           i24 = i28 & 0xFFFF;
/* 3471 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3472 */           i23 = i28 & 0xFFFF;
/* 3473 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3474 */           i22 = i28 & 0xFFFF;
/* 3475 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3476 */           i21 = i28 & 0xFFFF;
/* 3477 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3478 */           i20 = i28 & 0xFFFF;
/* 3479 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3480 */           i19 = i28 & 0xFFFF;
/* 3481 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3482 */           i18 = i28 & 0xFFFF;
/* 3483 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3484 */           i17 = i28 & 0xFFFF;
/* 3485 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3486 */           i16 = i28 & 0xFFFF;
/* 3487 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3488 */           i15 = i28 & 0xFFFF;
/* 3489 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3490 */           i14 = i28 & 0xFFFF;
/* 3491 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3492 */           i13 = i28 & 0xFFFF;
/* 3493 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3494 */           i12 = i28 & 0xFFFF;
/* 3495 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3496 */           i11 = i28 & 0xFFFF;
/* 3497 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3498 */           i10 = i28 & 0xFFFF;
/* 3499 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3500 */           i9 = i28 & 0xFFFF;
/* 3501 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3502 */           i8 = i28 & 0xFFFF;
/* 3503 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3504 */           i7 = i28 & 0xFFFF;
/* 3505 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3506 */           i6 = i28 & 0xFFFF;
/* 3507 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3508 */           i5 = i28 & 0xFFFF;
/* 3509 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3510 */           i4 = i28 & 0xFFFF;
/* 3511 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3512 */           i3 = i28 & 0xFFFF;
/* 3513 */           i28 = (i28 >> 16) + i2 * 10000;
/* 3514 */           i2 = i28 & 0xFFFF;
/* 3515 */           i28 = (i28 >> 16) + i1 * 10000;
/* 3516 */           i1 = i28 & 0xFFFF;
/* 3517 */           i28 = (i28 >> 16) + n * 10000;
/* 3518 */           n = i28 & 0xFFFF;
/* 3519 */           i28 >>= 16;
/*      */           
/* 3521 */           if (i28 != 0)
/*      */           {
/* 3523 */             i27 = (byte)(i27 - 1);
/* 3524 */             m = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 1: 
/* 3530 */           i24 = i28 & 0xFFFF;
/* 3531 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3532 */           i23 = i28 & 0xFFFF;
/* 3533 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3534 */           i22 = i28 & 0xFFFF;
/* 3535 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3536 */           i21 = i28 & 0xFFFF;
/* 3537 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3538 */           i20 = i28 & 0xFFFF;
/* 3539 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3540 */           i19 = i28 & 0xFFFF;
/* 3541 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3542 */           i18 = i28 & 0xFFFF;
/* 3543 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3544 */           i17 = i28 & 0xFFFF;
/* 3545 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3546 */           i16 = i28 & 0xFFFF;
/* 3547 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3548 */           i15 = i28 & 0xFFFF;
/* 3549 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3550 */           i14 = i28 & 0xFFFF;
/* 3551 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3552 */           i13 = i28 & 0xFFFF;
/* 3553 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3554 */           i12 = i28 & 0xFFFF;
/* 3555 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3556 */           i11 = i28 & 0xFFFF;
/* 3557 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3558 */           i10 = i28 & 0xFFFF;
/* 3559 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3560 */           i9 = i28 & 0xFFFF;
/* 3561 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3562 */           i8 = i28 & 0xFFFF;
/* 3563 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3564 */           i7 = i28 & 0xFFFF;
/* 3565 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3566 */           i6 = i28 & 0xFFFF;
/* 3567 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3568 */           i5 = i28 & 0xFFFF;
/* 3569 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3570 */           i4 = i28 & 0xFFFF;
/* 3571 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3572 */           i3 = i28 & 0xFFFF;
/* 3573 */           i28 = (i28 >> 16) + i2 * 10000;
/* 3574 */           i2 = i28 & 0xFFFF;
/* 3575 */           i28 = (i28 >> 16) + i1 * 10000;
/* 3576 */           i1 = i28 & 0xFFFF;
/* 3577 */           i28 = (i28 >> 16) + n * 10000;
/* 3578 */           n = i28 & 0xFFFF;
/* 3579 */           i28 = (i28 >> 16) + m * 10000;
/* 3580 */           m = i28 & 0xFFFF;
/* 3581 */           i28 >>= 16;
/*      */           
/* 3583 */           if (i28 != 0)
/*      */           {
/* 3585 */             i27 = (byte)(i27 - 1);
/* 3586 */             k = i28;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 0: 
/* 3592 */           i24 = i28 & 0xFFFF;
/* 3593 */           i28 = (i28 >> 16) + i23 * 10000;
/* 3594 */           i23 = i28 & 0xFFFF;
/* 3595 */           i28 = (i28 >> 16) + i22 * 10000;
/* 3596 */           i22 = i28 & 0xFFFF;
/* 3597 */           i28 = (i28 >> 16) + i21 * 10000;
/* 3598 */           i21 = i28 & 0xFFFF;
/* 3599 */           i28 = (i28 >> 16) + i20 * 10000;
/* 3600 */           i20 = i28 & 0xFFFF;
/* 3601 */           i28 = (i28 >> 16) + i19 * 10000;
/* 3602 */           i19 = i28 & 0xFFFF;
/* 3603 */           i28 = (i28 >> 16) + i18 * 10000;
/* 3604 */           i18 = i28 & 0xFFFF;
/* 3605 */           i28 = (i28 >> 16) + i17 * 10000;
/* 3606 */           i17 = i28 & 0xFFFF;
/* 3607 */           i28 = (i28 >> 16) + i16 * 10000;
/* 3608 */           i16 = i28 & 0xFFFF;
/* 3609 */           i28 = (i28 >> 16) + i15 * 10000;
/* 3610 */           i15 = i28 & 0xFFFF;
/* 3611 */           i28 = (i28 >> 16) + i14 * 10000;
/* 3612 */           i14 = i28 & 0xFFFF;
/* 3613 */           i28 = (i28 >> 16) + i13 * 10000;
/* 3614 */           i13 = i28 & 0xFFFF;
/* 3615 */           i28 = (i28 >> 16) + i12 * 10000;
/* 3616 */           i12 = i28 & 0xFFFF;
/* 3617 */           i28 = (i28 >> 16) + i11 * 10000;
/* 3618 */           i11 = i28 & 0xFFFF;
/* 3619 */           i28 = (i28 >> 16) + i10 * 10000;
/* 3620 */           i10 = i28 & 0xFFFF;
/* 3621 */           i28 = (i28 >> 16) + i9 * 10000;
/* 3622 */           i9 = i28 & 0xFFFF;
/* 3623 */           i28 = (i28 >> 16) + i8 * 10000;
/* 3624 */           i8 = i28 & 0xFFFF;
/* 3625 */           i28 = (i28 >> 16) + i7 * 10000;
/* 3626 */           i7 = i28 & 0xFFFF;
/* 3627 */           i28 = (i28 >> 16) + i6 * 10000;
/* 3628 */           i6 = i28 & 0xFFFF;
/* 3629 */           i28 = (i28 >> 16) + i5 * 10000;
/* 3630 */           i5 = i28 & 0xFFFF;
/* 3631 */           i28 = (i28 >> 16) + i4 * 10000;
/* 3632 */           i4 = i28 & 0xFFFF;
/* 3633 */           i28 = (i28 >> 16) + i3 * 10000;
/* 3634 */           i3 = i28 & 0xFFFF;
/* 3635 */           i28 = (i28 >> 16) + i2 * 10000;
/* 3636 */           i2 = i28 & 0xFFFF;
/* 3637 */           i28 = (i28 >> 16) + i1 * 10000;
/* 3638 */           i1 = i28 & 0xFFFF;
/* 3639 */           i28 = (i28 >> 16) + n * 10000;
/* 3640 */           n = i28 & 0xFFFF;
/* 3641 */           i28 = (i28 >> 16) + m * 10000;
/* 3642 */           m = i28 & 0xFFFF;
/* 3643 */           i28 = (i28 >> 16) + k * 10000;
/* 3644 */           k = i28 & 0xFFFF;
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 3649 */         i26 -= 2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       int i38;
/*      */       
/*      */ 
/*      */       int i29;
/*      */       
/*      */ 
/*      */       byte[] arrayOfByte2;
/*      */       
/*      */ 
/* 3663 */       switch (i27)
/*      */       {
/*      */ 
/*      */       default: 
/* 3667 */         i38 = (byte)(k >> 8 & 0xFF);
/*      */         
/* 3669 */         if (i38 == 0)
/*      */         {
/* 3671 */           i29 = 53;
/* 3672 */           arrayOfByte2 = new byte[i29];
/* 3673 */           arrayOfByte2[51] = ((byte)(i24 >> 8 & 0xFF));
/* 3674 */           arrayOfByte2[52] = ((byte)(i24 & 0xFF));
/* 3675 */           arrayOfByte2[49] = ((byte)(i23 >> 8 & 0xFF));
/* 3676 */           arrayOfByte2[50] = ((byte)(i23 & 0xFF));
/* 3677 */           arrayOfByte2[47] = ((byte)(i22 >> 8 & 0xFF));
/* 3678 */           arrayOfByte2[48] = ((byte)(i22 & 0xFF));
/* 3679 */           arrayOfByte2[45] = ((byte)(i21 >> 8 & 0xFF));
/* 3680 */           arrayOfByte2[46] = ((byte)(i21 & 0xFF));
/* 3681 */           arrayOfByte2[43] = ((byte)(i20 >> 8 & 0xFF));
/* 3682 */           arrayOfByte2[44] = ((byte)(i20 & 0xFF));
/* 3683 */           arrayOfByte2[41] = ((byte)(i19 >> 8 & 0xFF));
/* 3684 */           arrayOfByte2[42] = ((byte)(i19 & 0xFF));
/* 3685 */           arrayOfByte2[39] = ((byte)(i18 >> 8 & 0xFF));
/* 3686 */           arrayOfByte2[40] = ((byte)(i18 & 0xFF));
/* 3687 */           arrayOfByte2[37] = ((byte)(i17 >> 8 & 0xFF));
/* 3688 */           arrayOfByte2[38] = ((byte)(i17 & 0xFF));
/* 3689 */           arrayOfByte2[35] = ((byte)(i16 >> 8 & 0xFF));
/* 3690 */           arrayOfByte2[36] = ((byte)(i16 & 0xFF));
/* 3691 */           arrayOfByte2[33] = ((byte)(i15 >> 8 & 0xFF));
/* 3692 */           arrayOfByte2[34] = ((byte)(i15 & 0xFF));
/* 3693 */           arrayOfByte2[31] = ((byte)(i14 >> 8 & 0xFF));
/* 3694 */           arrayOfByte2[32] = ((byte)(i14 & 0xFF));
/* 3695 */           arrayOfByte2[29] = ((byte)(i13 >> 8 & 0xFF));
/* 3696 */           arrayOfByte2[30] = ((byte)(i13 & 0xFF));
/* 3697 */           arrayOfByte2[27] = ((byte)(i12 >> 8 & 0xFF));
/* 3698 */           arrayOfByte2[28] = ((byte)(i12 & 0xFF));
/* 3699 */           arrayOfByte2[25] = ((byte)(i11 >> 8 & 0xFF));
/* 3700 */           arrayOfByte2[26] = ((byte)(i11 & 0xFF));
/* 3701 */           arrayOfByte2[23] = ((byte)(i10 >> 8 & 0xFF));
/* 3702 */           arrayOfByte2[24] = ((byte)(i10 & 0xFF));
/* 3703 */           arrayOfByte2[21] = ((byte)(i9 >> 8 & 0xFF));
/* 3704 */           arrayOfByte2[22] = ((byte)(i9 & 0xFF));
/* 3705 */           arrayOfByte2[19] = ((byte)(i8 >> 8 & 0xFF));
/* 3706 */           arrayOfByte2[20] = ((byte)(i8 & 0xFF));
/* 3707 */           arrayOfByte2[17] = ((byte)(i7 >> 8 & 0xFF));
/* 3708 */           arrayOfByte2[18] = ((byte)(i7 & 0xFF));
/* 3709 */           arrayOfByte2[15] = ((byte)(i6 >> 8 & 0xFF));
/* 3710 */           arrayOfByte2[16] = ((byte)(i6 & 0xFF));
/* 3711 */           arrayOfByte2[13] = ((byte)(i5 >> 8 & 0xFF));
/* 3712 */           arrayOfByte2[14] = ((byte)(i5 & 0xFF));
/* 3713 */           arrayOfByte2[11] = ((byte)(i4 >> 8 & 0xFF));
/* 3714 */           arrayOfByte2[12] = ((byte)(i4 & 0xFF));
/* 3715 */           arrayOfByte2[9] = ((byte)(i3 >> 8 & 0xFF));
/* 3716 */           arrayOfByte2[10] = ((byte)(i3 & 0xFF));
/* 3717 */           arrayOfByte2[7] = ((byte)(i2 >> 8 & 0xFF));
/* 3718 */           arrayOfByte2[8] = ((byte)(i2 & 0xFF));
/* 3719 */           arrayOfByte2[5] = ((byte)(i1 >> 8 & 0xFF));
/* 3720 */           arrayOfByte2[6] = ((byte)(i1 & 0xFF));
/* 3721 */           arrayOfByte2[3] = ((byte)(n >> 8 & 0xFF));
/* 3722 */           arrayOfByte2[4] = ((byte)(n & 0xFF));
/* 3723 */           arrayOfByte2[1] = ((byte)(m >> 8 & 0xFF));
/* 3724 */           arrayOfByte2[2] = ((byte)(m & 0xFF));
/* 3725 */           arrayOfByte2[0] = ((byte)(k & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 3729 */           i29 = 54;
/* 3730 */           arrayOfByte2 = new byte[i29];
/* 3731 */           arrayOfByte2[52] = ((byte)(i24 >> 8 & 0xFF));
/* 3732 */           arrayOfByte2[53] = ((byte)(i24 & 0xFF));
/* 3733 */           arrayOfByte2[50] = ((byte)(i23 >> 8 & 0xFF));
/* 3734 */           arrayOfByte2[51] = ((byte)(i23 & 0xFF));
/* 3735 */           arrayOfByte2[48] = ((byte)(i22 >> 8 & 0xFF));
/* 3736 */           arrayOfByte2[49] = ((byte)(i22 & 0xFF));
/* 3737 */           arrayOfByte2[46] = ((byte)(i21 >> 8 & 0xFF));
/* 3738 */           arrayOfByte2[47] = ((byte)(i21 & 0xFF));
/* 3739 */           arrayOfByte2[44] = ((byte)(i20 >> 8 & 0xFF));
/* 3740 */           arrayOfByte2[45] = ((byte)(i20 & 0xFF));
/* 3741 */           arrayOfByte2[42] = ((byte)(i19 >> 8 & 0xFF));
/* 3742 */           arrayOfByte2[43] = ((byte)(i19 & 0xFF));
/* 3743 */           arrayOfByte2[40] = ((byte)(i18 >> 8 & 0xFF));
/* 3744 */           arrayOfByte2[41] = ((byte)(i18 & 0xFF));
/* 3745 */           arrayOfByte2[38] = ((byte)(i17 >> 8 & 0xFF));
/* 3746 */           arrayOfByte2[39] = ((byte)(i17 & 0xFF));
/* 3747 */           arrayOfByte2[36] = ((byte)(i16 >> 8 & 0xFF));
/* 3748 */           arrayOfByte2[37] = ((byte)(i16 & 0xFF));
/* 3749 */           arrayOfByte2[34] = ((byte)(i15 >> 8 & 0xFF));
/* 3750 */           arrayOfByte2[35] = ((byte)(i15 & 0xFF));
/* 3751 */           arrayOfByte2[32] = ((byte)(i14 >> 8 & 0xFF));
/* 3752 */           arrayOfByte2[33] = ((byte)(i14 & 0xFF));
/* 3753 */           arrayOfByte2[30] = ((byte)(i13 >> 8 & 0xFF));
/* 3754 */           arrayOfByte2[31] = ((byte)(i13 & 0xFF));
/* 3755 */           arrayOfByte2[28] = ((byte)(i12 >> 8 & 0xFF));
/* 3756 */           arrayOfByte2[29] = ((byte)(i12 & 0xFF));
/* 3757 */           arrayOfByte2[26] = ((byte)(i11 >> 8 & 0xFF));
/* 3758 */           arrayOfByte2[27] = ((byte)(i11 & 0xFF));
/* 3759 */           arrayOfByte2[24] = ((byte)(i10 >> 8 & 0xFF));
/* 3760 */           arrayOfByte2[25] = ((byte)(i10 & 0xFF));
/* 3761 */           arrayOfByte2[22] = ((byte)(i9 >> 8 & 0xFF));
/* 3762 */           arrayOfByte2[23] = ((byte)(i9 & 0xFF));
/* 3763 */           arrayOfByte2[20] = ((byte)(i8 >> 8 & 0xFF));
/* 3764 */           arrayOfByte2[21] = ((byte)(i8 & 0xFF));
/* 3765 */           arrayOfByte2[18] = ((byte)(i7 >> 8 & 0xFF));
/* 3766 */           arrayOfByte2[19] = ((byte)(i7 & 0xFF));
/* 3767 */           arrayOfByte2[16] = ((byte)(i6 >> 8 & 0xFF));
/* 3768 */           arrayOfByte2[17] = ((byte)(i6 & 0xFF));
/* 3769 */           arrayOfByte2[14] = ((byte)(i5 >> 8 & 0xFF));
/* 3770 */           arrayOfByte2[15] = ((byte)(i5 & 0xFF));
/* 3771 */           arrayOfByte2[12] = ((byte)(i4 >> 8 & 0xFF));
/* 3772 */           arrayOfByte2[13] = ((byte)(i4 & 0xFF));
/* 3773 */           arrayOfByte2[10] = ((byte)(i3 >> 8 & 0xFF));
/* 3774 */           arrayOfByte2[11] = ((byte)(i3 & 0xFF));
/* 3775 */           arrayOfByte2[8] = ((byte)(i2 >> 8 & 0xFF));
/* 3776 */           arrayOfByte2[9] = ((byte)(i2 & 0xFF));
/* 3777 */           arrayOfByte2[6] = ((byte)(i1 >> 8 & 0xFF));
/* 3778 */           arrayOfByte2[7] = ((byte)(i1 & 0xFF));
/* 3779 */           arrayOfByte2[4] = ((byte)(n >> 8 & 0xFF));
/* 3780 */           arrayOfByte2[5] = ((byte)(n & 0xFF));
/* 3781 */           arrayOfByte2[2] = ((byte)(m >> 8 & 0xFF));
/* 3782 */           arrayOfByte2[3] = ((byte)(m & 0xFF));
/* 3783 */           arrayOfByte2[0] = i38;
/* 3784 */           arrayOfByte2[1] = ((byte)(k & 0xFF));
/*      */         }
/*      */         
/* 3787 */         break;
/*      */       
/*      */       case 1: 
/* 3790 */         i38 = (byte)(m >> 8 & 0xFF);
/*      */         
/* 3792 */         if (i38 == 0)
/*      */         {
/* 3794 */           i29 = 51;
/* 3795 */           arrayOfByte2 = new byte[i29];
/* 3796 */           arrayOfByte2[49] = ((byte)(i24 >> 8 & 0xFF));
/* 3797 */           arrayOfByte2[50] = ((byte)(i24 & 0xFF));
/* 3798 */           arrayOfByte2[47] = ((byte)(i23 >> 8 & 0xFF));
/* 3799 */           arrayOfByte2[48] = ((byte)(i23 & 0xFF));
/* 3800 */           arrayOfByte2[45] = ((byte)(i22 >> 8 & 0xFF));
/* 3801 */           arrayOfByte2[46] = ((byte)(i22 & 0xFF));
/* 3802 */           arrayOfByte2[43] = ((byte)(i21 >> 8 & 0xFF));
/* 3803 */           arrayOfByte2[44] = ((byte)(i21 & 0xFF));
/* 3804 */           arrayOfByte2[41] = ((byte)(i20 >> 8 & 0xFF));
/* 3805 */           arrayOfByte2[42] = ((byte)(i20 & 0xFF));
/* 3806 */           arrayOfByte2[39] = ((byte)(i19 >> 8 & 0xFF));
/* 3807 */           arrayOfByte2[40] = ((byte)(i19 & 0xFF));
/* 3808 */           arrayOfByte2[37] = ((byte)(i18 >> 8 & 0xFF));
/* 3809 */           arrayOfByte2[38] = ((byte)(i18 & 0xFF));
/* 3810 */           arrayOfByte2[35] = ((byte)(i17 >> 8 & 0xFF));
/* 3811 */           arrayOfByte2[36] = ((byte)(i17 & 0xFF));
/* 3812 */           arrayOfByte2[33] = ((byte)(i16 >> 8 & 0xFF));
/* 3813 */           arrayOfByte2[34] = ((byte)(i16 & 0xFF));
/* 3814 */           arrayOfByte2[31] = ((byte)(i15 >> 8 & 0xFF));
/* 3815 */           arrayOfByte2[32] = ((byte)(i15 & 0xFF));
/* 3816 */           arrayOfByte2[29] = ((byte)(i14 >> 8 & 0xFF));
/* 3817 */           arrayOfByte2[30] = ((byte)(i14 & 0xFF));
/* 3818 */           arrayOfByte2[27] = ((byte)(i13 >> 8 & 0xFF));
/* 3819 */           arrayOfByte2[28] = ((byte)(i13 & 0xFF));
/* 3820 */           arrayOfByte2[25] = ((byte)(i12 >> 8 & 0xFF));
/* 3821 */           arrayOfByte2[26] = ((byte)(i12 & 0xFF));
/* 3822 */           arrayOfByte2[23] = ((byte)(i11 >> 8 & 0xFF));
/* 3823 */           arrayOfByte2[24] = ((byte)(i11 & 0xFF));
/* 3824 */           arrayOfByte2[21] = ((byte)(i10 >> 8 & 0xFF));
/* 3825 */           arrayOfByte2[22] = ((byte)(i10 & 0xFF));
/* 3826 */           arrayOfByte2[19] = ((byte)(i9 >> 8 & 0xFF));
/* 3827 */           arrayOfByte2[20] = ((byte)(i9 & 0xFF));
/* 3828 */           arrayOfByte2[17] = ((byte)(i8 >> 8 & 0xFF));
/* 3829 */           arrayOfByte2[18] = ((byte)(i8 & 0xFF));
/* 3830 */           arrayOfByte2[15] = ((byte)(i7 >> 8 & 0xFF));
/* 3831 */           arrayOfByte2[16] = ((byte)(i7 & 0xFF));
/* 3832 */           arrayOfByte2[13] = ((byte)(i6 >> 8 & 0xFF));
/* 3833 */           arrayOfByte2[14] = ((byte)(i6 & 0xFF));
/* 3834 */           arrayOfByte2[11] = ((byte)(i5 >> 8 & 0xFF));
/* 3835 */           arrayOfByte2[12] = ((byte)(i5 & 0xFF));
/* 3836 */           arrayOfByte2[9] = ((byte)(i4 >> 8 & 0xFF));
/* 3837 */           arrayOfByte2[10] = ((byte)(i4 & 0xFF));
/* 3838 */           arrayOfByte2[7] = ((byte)(i3 >> 8 & 0xFF));
/* 3839 */           arrayOfByte2[8] = ((byte)(i3 & 0xFF));
/* 3840 */           arrayOfByte2[5] = ((byte)(i2 >> 8 & 0xFF));
/* 3841 */           arrayOfByte2[6] = ((byte)(i2 & 0xFF));
/* 3842 */           arrayOfByte2[3] = ((byte)(i1 >> 8 & 0xFF));
/* 3843 */           arrayOfByte2[4] = ((byte)(i1 & 0xFF));
/* 3844 */           arrayOfByte2[1] = ((byte)(n >> 8 & 0xFF));
/* 3845 */           arrayOfByte2[2] = ((byte)(n & 0xFF));
/* 3846 */           arrayOfByte2[0] = ((byte)(m & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 3850 */           i29 = 52;
/* 3851 */           arrayOfByte2 = new byte[i29];
/* 3852 */           arrayOfByte2[50] = ((byte)(i24 >> 8 & 0xFF));
/* 3853 */           arrayOfByte2[51] = ((byte)(i24 & 0xFF));
/* 3854 */           arrayOfByte2[48] = ((byte)(i23 >> 8 & 0xFF));
/* 3855 */           arrayOfByte2[49] = ((byte)(i23 & 0xFF));
/* 3856 */           arrayOfByte2[46] = ((byte)(i22 >> 8 & 0xFF));
/* 3857 */           arrayOfByte2[47] = ((byte)(i22 & 0xFF));
/* 3858 */           arrayOfByte2[44] = ((byte)(i21 >> 8 & 0xFF));
/* 3859 */           arrayOfByte2[45] = ((byte)(i21 & 0xFF));
/* 3860 */           arrayOfByte2[42] = ((byte)(i20 >> 8 & 0xFF));
/* 3861 */           arrayOfByte2[43] = ((byte)(i20 & 0xFF));
/* 3862 */           arrayOfByte2[40] = ((byte)(i19 >> 8 & 0xFF));
/* 3863 */           arrayOfByte2[41] = ((byte)(i19 & 0xFF));
/* 3864 */           arrayOfByte2[38] = ((byte)(i18 >> 8 & 0xFF));
/* 3865 */           arrayOfByte2[39] = ((byte)(i18 & 0xFF));
/* 3866 */           arrayOfByte2[36] = ((byte)(i17 >> 8 & 0xFF));
/* 3867 */           arrayOfByte2[37] = ((byte)(i17 & 0xFF));
/* 3868 */           arrayOfByte2[34] = ((byte)(i16 >> 8 & 0xFF));
/* 3869 */           arrayOfByte2[35] = ((byte)(i16 & 0xFF));
/* 3870 */           arrayOfByte2[32] = ((byte)(i15 >> 8 & 0xFF));
/* 3871 */           arrayOfByte2[33] = ((byte)(i15 & 0xFF));
/* 3872 */           arrayOfByte2[30] = ((byte)(i14 >> 8 & 0xFF));
/* 3873 */           arrayOfByte2[31] = ((byte)(i14 & 0xFF));
/* 3874 */           arrayOfByte2[28] = ((byte)(i13 >> 8 & 0xFF));
/* 3875 */           arrayOfByte2[29] = ((byte)(i13 & 0xFF));
/* 3876 */           arrayOfByte2[26] = ((byte)(i12 >> 8 & 0xFF));
/* 3877 */           arrayOfByte2[27] = ((byte)(i12 & 0xFF));
/* 3878 */           arrayOfByte2[24] = ((byte)(i11 >> 8 & 0xFF));
/* 3879 */           arrayOfByte2[25] = ((byte)(i11 & 0xFF));
/* 3880 */           arrayOfByte2[22] = ((byte)(i10 >> 8 & 0xFF));
/* 3881 */           arrayOfByte2[23] = ((byte)(i10 & 0xFF));
/* 3882 */           arrayOfByte2[20] = ((byte)(i9 >> 8 & 0xFF));
/* 3883 */           arrayOfByte2[21] = ((byte)(i9 & 0xFF));
/* 3884 */           arrayOfByte2[18] = ((byte)(i8 >> 8 & 0xFF));
/* 3885 */           arrayOfByte2[19] = ((byte)(i8 & 0xFF));
/* 3886 */           arrayOfByte2[16] = ((byte)(i7 >> 8 & 0xFF));
/* 3887 */           arrayOfByte2[17] = ((byte)(i7 & 0xFF));
/* 3888 */           arrayOfByte2[14] = ((byte)(i6 >> 8 & 0xFF));
/* 3889 */           arrayOfByte2[15] = ((byte)(i6 & 0xFF));
/* 3890 */           arrayOfByte2[12] = ((byte)(i5 >> 8 & 0xFF));
/* 3891 */           arrayOfByte2[13] = ((byte)(i5 & 0xFF));
/* 3892 */           arrayOfByte2[10] = ((byte)(i4 >> 8 & 0xFF));
/* 3893 */           arrayOfByte2[11] = ((byte)(i4 & 0xFF));
/* 3894 */           arrayOfByte2[8] = ((byte)(i3 >> 8 & 0xFF));
/* 3895 */           arrayOfByte2[9] = ((byte)(i3 & 0xFF));
/* 3896 */           arrayOfByte2[6] = ((byte)(i2 >> 8 & 0xFF));
/* 3897 */           arrayOfByte2[7] = ((byte)(i2 & 0xFF));
/* 3898 */           arrayOfByte2[4] = ((byte)(i1 >> 8 & 0xFF));
/* 3899 */           arrayOfByte2[5] = ((byte)(i1 & 0xFF));
/* 3900 */           arrayOfByte2[2] = ((byte)(n >> 8 & 0xFF));
/* 3901 */           arrayOfByte2[3] = ((byte)(n & 0xFF));
/* 3902 */           arrayOfByte2[0] = i38;
/* 3903 */           arrayOfByte2[1] = ((byte)(m & 0xFF));
/*      */         }
/*      */         
/* 3906 */         break;
/*      */       
/*      */       case 2: 
/* 3909 */         i38 = (byte)(n >> 8 & 0xFF);
/*      */         
/* 3911 */         if (i38 == 0)
/*      */         {
/* 3913 */           i29 = 49;
/* 3914 */           arrayOfByte2 = new byte[i29];
/* 3915 */           arrayOfByte2[47] = ((byte)(i24 >> 8 & 0xFF));
/* 3916 */           arrayOfByte2[48] = ((byte)(i24 & 0xFF));
/* 3917 */           arrayOfByte2[45] = ((byte)(i23 >> 8 & 0xFF));
/* 3918 */           arrayOfByte2[46] = ((byte)(i23 & 0xFF));
/* 3919 */           arrayOfByte2[43] = ((byte)(i22 >> 8 & 0xFF));
/* 3920 */           arrayOfByte2[44] = ((byte)(i22 & 0xFF));
/* 3921 */           arrayOfByte2[41] = ((byte)(i21 >> 8 & 0xFF));
/* 3922 */           arrayOfByte2[42] = ((byte)(i21 & 0xFF));
/* 3923 */           arrayOfByte2[39] = ((byte)(i20 >> 8 & 0xFF));
/* 3924 */           arrayOfByte2[40] = ((byte)(i20 & 0xFF));
/* 3925 */           arrayOfByte2[37] = ((byte)(i19 >> 8 & 0xFF));
/* 3926 */           arrayOfByte2[38] = ((byte)(i19 & 0xFF));
/* 3927 */           arrayOfByte2[35] = ((byte)(i18 >> 8 & 0xFF));
/* 3928 */           arrayOfByte2[36] = ((byte)(i18 & 0xFF));
/* 3929 */           arrayOfByte2[33] = ((byte)(i17 >> 8 & 0xFF));
/* 3930 */           arrayOfByte2[34] = ((byte)(i17 & 0xFF));
/* 3931 */           arrayOfByte2[31] = ((byte)(i16 >> 8 & 0xFF));
/* 3932 */           arrayOfByte2[32] = ((byte)(i16 & 0xFF));
/* 3933 */           arrayOfByte2[29] = ((byte)(i15 >> 8 & 0xFF));
/* 3934 */           arrayOfByte2[30] = ((byte)(i15 & 0xFF));
/* 3935 */           arrayOfByte2[27] = ((byte)(i14 >> 8 & 0xFF));
/* 3936 */           arrayOfByte2[28] = ((byte)(i14 & 0xFF));
/* 3937 */           arrayOfByte2[25] = ((byte)(i13 >> 8 & 0xFF));
/* 3938 */           arrayOfByte2[26] = ((byte)(i13 & 0xFF));
/* 3939 */           arrayOfByte2[23] = ((byte)(i12 >> 8 & 0xFF));
/* 3940 */           arrayOfByte2[24] = ((byte)(i12 & 0xFF));
/* 3941 */           arrayOfByte2[21] = ((byte)(i11 >> 8 & 0xFF));
/* 3942 */           arrayOfByte2[22] = ((byte)(i11 & 0xFF));
/* 3943 */           arrayOfByte2[19] = ((byte)(i10 >> 8 & 0xFF));
/* 3944 */           arrayOfByte2[20] = ((byte)(i10 & 0xFF));
/* 3945 */           arrayOfByte2[17] = ((byte)(i9 >> 8 & 0xFF));
/* 3946 */           arrayOfByte2[18] = ((byte)(i9 & 0xFF));
/* 3947 */           arrayOfByte2[15] = ((byte)(i8 >> 8 & 0xFF));
/* 3948 */           arrayOfByte2[16] = ((byte)(i8 & 0xFF));
/* 3949 */           arrayOfByte2[13] = ((byte)(i7 >> 8 & 0xFF));
/* 3950 */           arrayOfByte2[14] = ((byte)(i7 & 0xFF));
/* 3951 */           arrayOfByte2[11] = ((byte)(i6 >> 8 & 0xFF));
/* 3952 */           arrayOfByte2[12] = ((byte)(i6 & 0xFF));
/* 3953 */           arrayOfByte2[9] = ((byte)(i5 >> 8 & 0xFF));
/* 3954 */           arrayOfByte2[10] = ((byte)(i5 & 0xFF));
/* 3955 */           arrayOfByte2[7] = ((byte)(i4 >> 8 & 0xFF));
/* 3956 */           arrayOfByte2[8] = ((byte)(i4 & 0xFF));
/* 3957 */           arrayOfByte2[5] = ((byte)(i3 >> 8 & 0xFF));
/* 3958 */           arrayOfByte2[6] = ((byte)(i3 & 0xFF));
/* 3959 */           arrayOfByte2[3] = ((byte)(i2 >> 8 & 0xFF));
/* 3960 */           arrayOfByte2[4] = ((byte)(i2 & 0xFF));
/* 3961 */           arrayOfByte2[1] = ((byte)(i1 >> 8 & 0xFF));
/* 3962 */           arrayOfByte2[2] = ((byte)(i1 & 0xFF));
/* 3963 */           arrayOfByte2[0] = ((byte)(n & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 3967 */           i29 = 50;
/* 3968 */           arrayOfByte2 = new byte[i29];
/* 3969 */           arrayOfByte2[48] = ((byte)(i24 >> 8 & 0xFF));
/* 3970 */           arrayOfByte2[49] = ((byte)(i24 & 0xFF));
/* 3971 */           arrayOfByte2[46] = ((byte)(i23 >> 8 & 0xFF));
/* 3972 */           arrayOfByte2[47] = ((byte)(i23 & 0xFF));
/* 3973 */           arrayOfByte2[44] = ((byte)(i22 >> 8 & 0xFF));
/* 3974 */           arrayOfByte2[45] = ((byte)(i22 & 0xFF));
/* 3975 */           arrayOfByte2[42] = ((byte)(i21 >> 8 & 0xFF));
/* 3976 */           arrayOfByte2[43] = ((byte)(i21 & 0xFF));
/* 3977 */           arrayOfByte2[40] = ((byte)(i20 >> 8 & 0xFF));
/* 3978 */           arrayOfByte2[41] = ((byte)(i20 & 0xFF));
/* 3979 */           arrayOfByte2[38] = ((byte)(i19 >> 8 & 0xFF));
/* 3980 */           arrayOfByte2[39] = ((byte)(i19 & 0xFF));
/* 3981 */           arrayOfByte2[36] = ((byte)(i18 >> 8 & 0xFF));
/* 3982 */           arrayOfByte2[37] = ((byte)(i18 & 0xFF));
/* 3983 */           arrayOfByte2[34] = ((byte)(i17 >> 8 & 0xFF));
/* 3984 */           arrayOfByte2[35] = ((byte)(i17 & 0xFF));
/* 3985 */           arrayOfByte2[32] = ((byte)(i16 >> 8 & 0xFF));
/* 3986 */           arrayOfByte2[33] = ((byte)(i16 & 0xFF));
/* 3987 */           arrayOfByte2[30] = ((byte)(i15 >> 8 & 0xFF));
/* 3988 */           arrayOfByte2[31] = ((byte)(i15 & 0xFF));
/* 3989 */           arrayOfByte2[28] = ((byte)(i14 >> 8 & 0xFF));
/* 3990 */           arrayOfByte2[29] = ((byte)(i14 & 0xFF));
/* 3991 */           arrayOfByte2[26] = ((byte)(i13 >> 8 & 0xFF));
/* 3992 */           arrayOfByte2[27] = ((byte)(i13 & 0xFF));
/* 3993 */           arrayOfByte2[24] = ((byte)(i12 >> 8 & 0xFF));
/* 3994 */           arrayOfByte2[25] = ((byte)(i12 & 0xFF));
/* 3995 */           arrayOfByte2[22] = ((byte)(i11 >> 8 & 0xFF));
/* 3996 */           arrayOfByte2[23] = ((byte)(i11 & 0xFF));
/* 3997 */           arrayOfByte2[20] = ((byte)(i10 >> 8 & 0xFF));
/* 3998 */           arrayOfByte2[21] = ((byte)(i10 & 0xFF));
/* 3999 */           arrayOfByte2[18] = ((byte)(i9 >> 8 & 0xFF));
/* 4000 */           arrayOfByte2[19] = ((byte)(i9 & 0xFF));
/* 4001 */           arrayOfByte2[16] = ((byte)(i8 >> 8 & 0xFF));
/* 4002 */           arrayOfByte2[17] = ((byte)(i8 & 0xFF));
/* 4003 */           arrayOfByte2[14] = ((byte)(i7 >> 8 & 0xFF));
/* 4004 */           arrayOfByte2[15] = ((byte)(i7 & 0xFF));
/* 4005 */           arrayOfByte2[12] = ((byte)(i6 >> 8 & 0xFF));
/* 4006 */           arrayOfByte2[13] = ((byte)(i6 & 0xFF));
/* 4007 */           arrayOfByte2[10] = ((byte)(i5 >> 8 & 0xFF));
/* 4008 */           arrayOfByte2[11] = ((byte)(i5 & 0xFF));
/* 4009 */           arrayOfByte2[8] = ((byte)(i4 >> 8 & 0xFF));
/* 4010 */           arrayOfByte2[9] = ((byte)(i4 & 0xFF));
/* 4011 */           arrayOfByte2[6] = ((byte)(i3 >> 8 & 0xFF));
/* 4012 */           arrayOfByte2[7] = ((byte)(i3 & 0xFF));
/* 4013 */           arrayOfByte2[4] = ((byte)(i2 >> 8 & 0xFF));
/* 4014 */           arrayOfByte2[5] = ((byte)(i2 & 0xFF));
/* 4015 */           arrayOfByte2[2] = ((byte)(i1 >> 8 & 0xFF));
/* 4016 */           arrayOfByte2[3] = ((byte)(i1 & 0xFF));
/* 4017 */           arrayOfByte2[0] = i38;
/* 4018 */           arrayOfByte2[1] = ((byte)(n & 0xFF));
/*      */         }
/*      */         
/* 4021 */         break;
/*      */       
/*      */       case 3: 
/* 4024 */         i38 = (byte)(i1 >> 8 & 0xFF);
/*      */         
/* 4026 */         if (i38 == 0)
/*      */         {
/* 4028 */           i29 = 47;
/* 4029 */           arrayOfByte2 = new byte[i29];
/* 4030 */           arrayOfByte2[45] = ((byte)(i24 >> 8 & 0xFF));
/* 4031 */           arrayOfByte2[46] = ((byte)(i24 & 0xFF));
/* 4032 */           arrayOfByte2[43] = ((byte)(i23 >> 8 & 0xFF));
/* 4033 */           arrayOfByte2[44] = ((byte)(i23 & 0xFF));
/* 4034 */           arrayOfByte2[41] = ((byte)(i22 >> 8 & 0xFF));
/* 4035 */           arrayOfByte2[42] = ((byte)(i22 & 0xFF));
/* 4036 */           arrayOfByte2[39] = ((byte)(i21 >> 8 & 0xFF));
/* 4037 */           arrayOfByte2[40] = ((byte)(i21 & 0xFF));
/* 4038 */           arrayOfByte2[37] = ((byte)(i20 >> 8 & 0xFF));
/* 4039 */           arrayOfByte2[38] = ((byte)(i20 & 0xFF));
/* 4040 */           arrayOfByte2[35] = ((byte)(i19 >> 8 & 0xFF));
/* 4041 */           arrayOfByte2[36] = ((byte)(i19 & 0xFF));
/* 4042 */           arrayOfByte2[33] = ((byte)(i18 >> 8 & 0xFF));
/* 4043 */           arrayOfByte2[34] = ((byte)(i18 & 0xFF));
/* 4044 */           arrayOfByte2[31] = ((byte)(i17 >> 8 & 0xFF));
/* 4045 */           arrayOfByte2[32] = ((byte)(i17 & 0xFF));
/* 4046 */           arrayOfByte2[29] = ((byte)(i16 >> 8 & 0xFF));
/* 4047 */           arrayOfByte2[30] = ((byte)(i16 & 0xFF));
/* 4048 */           arrayOfByte2[27] = ((byte)(i15 >> 8 & 0xFF));
/* 4049 */           arrayOfByte2[28] = ((byte)(i15 & 0xFF));
/* 4050 */           arrayOfByte2[25] = ((byte)(i14 >> 8 & 0xFF));
/* 4051 */           arrayOfByte2[26] = ((byte)(i14 & 0xFF));
/* 4052 */           arrayOfByte2[23] = ((byte)(i13 >> 8 & 0xFF));
/* 4053 */           arrayOfByte2[24] = ((byte)(i13 & 0xFF));
/* 4054 */           arrayOfByte2[21] = ((byte)(i12 >> 8 & 0xFF));
/* 4055 */           arrayOfByte2[22] = ((byte)(i12 & 0xFF));
/* 4056 */           arrayOfByte2[19] = ((byte)(i11 >> 8 & 0xFF));
/* 4057 */           arrayOfByte2[20] = ((byte)(i11 & 0xFF));
/* 4058 */           arrayOfByte2[17] = ((byte)(i10 >> 8 & 0xFF));
/* 4059 */           arrayOfByte2[18] = ((byte)(i10 & 0xFF));
/* 4060 */           arrayOfByte2[15] = ((byte)(i9 >> 8 & 0xFF));
/* 4061 */           arrayOfByte2[16] = ((byte)(i9 & 0xFF));
/* 4062 */           arrayOfByte2[13] = ((byte)(i8 >> 8 & 0xFF));
/* 4063 */           arrayOfByte2[14] = ((byte)(i8 & 0xFF));
/* 4064 */           arrayOfByte2[11] = ((byte)(i7 >> 8 & 0xFF));
/* 4065 */           arrayOfByte2[12] = ((byte)(i7 & 0xFF));
/* 4066 */           arrayOfByte2[9] = ((byte)(i6 >> 8 & 0xFF));
/* 4067 */           arrayOfByte2[10] = ((byte)(i6 & 0xFF));
/* 4068 */           arrayOfByte2[7] = ((byte)(i5 >> 8 & 0xFF));
/* 4069 */           arrayOfByte2[8] = ((byte)(i5 & 0xFF));
/* 4070 */           arrayOfByte2[5] = ((byte)(i4 >> 8 & 0xFF));
/* 4071 */           arrayOfByte2[6] = ((byte)(i4 & 0xFF));
/* 4072 */           arrayOfByte2[3] = ((byte)(i3 >> 8 & 0xFF));
/* 4073 */           arrayOfByte2[4] = ((byte)(i3 & 0xFF));
/* 4074 */           arrayOfByte2[1] = ((byte)(i2 >> 8 & 0xFF));
/* 4075 */           arrayOfByte2[2] = ((byte)(i2 & 0xFF));
/* 4076 */           arrayOfByte2[0] = ((byte)(i1 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4080 */           i29 = 48;
/* 4081 */           arrayOfByte2 = new byte[i29];
/* 4082 */           arrayOfByte2[46] = ((byte)(i24 >> 8 & 0xFF));
/* 4083 */           arrayOfByte2[47] = ((byte)(i24 & 0xFF));
/* 4084 */           arrayOfByte2[44] = ((byte)(i23 >> 8 & 0xFF));
/* 4085 */           arrayOfByte2[45] = ((byte)(i23 & 0xFF));
/* 4086 */           arrayOfByte2[42] = ((byte)(i22 >> 8 & 0xFF));
/* 4087 */           arrayOfByte2[43] = ((byte)(i22 & 0xFF));
/* 4088 */           arrayOfByte2[40] = ((byte)(i21 >> 8 & 0xFF));
/* 4089 */           arrayOfByte2[41] = ((byte)(i21 & 0xFF));
/* 4090 */           arrayOfByte2[38] = ((byte)(i20 >> 8 & 0xFF));
/* 4091 */           arrayOfByte2[39] = ((byte)(i20 & 0xFF));
/* 4092 */           arrayOfByte2[36] = ((byte)(i19 >> 8 & 0xFF));
/* 4093 */           arrayOfByte2[37] = ((byte)(i19 & 0xFF));
/* 4094 */           arrayOfByte2[34] = ((byte)(i18 >> 8 & 0xFF));
/* 4095 */           arrayOfByte2[35] = ((byte)(i18 & 0xFF));
/* 4096 */           arrayOfByte2[32] = ((byte)(i17 >> 8 & 0xFF));
/* 4097 */           arrayOfByte2[33] = ((byte)(i17 & 0xFF));
/* 4098 */           arrayOfByte2[30] = ((byte)(i16 >> 8 & 0xFF));
/* 4099 */           arrayOfByte2[31] = ((byte)(i16 & 0xFF));
/* 4100 */           arrayOfByte2[28] = ((byte)(i15 >> 8 & 0xFF));
/* 4101 */           arrayOfByte2[29] = ((byte)(i15 & 0xFF));
/* 4102 */           arrayOfByte2[26] = ((byte)(i14 >> 8 & 0xFF));
/* 4103 */           arrayOfByte2[27] = ((byte)(i14 & 0xFF));
/* 4104 */           arrayOfByte2[24] = ((byte)(i13 >> 8 & 0xFF));
/* 4105 */           arrayOfByte2[25] = ((byte)(i13 & 0xFF));
/* 4106 */           arrayOfByte2[22] = ((byte)(i12 >> 8 & 0xFF));
/* 4107 */           arrayOfByte2[23] = ((byte)(i12 & 0xFF));
/* 4108 */           arrayOfByte2[20] = ((byte)(i11 >> 8 & 0xFF));
/* 4109 */           arrayOfByte2[21] = ((byte)(i11 & 0xFF));
/* 4110 */           arrayOfByte2[18] = ((byte)(i10 >> 8 & 0xFF));
/* 4111 */           arrayOfByte2[19] = ((byte)(i10 & 0xFF));
/* 4112 */           arrayOfByte2[16] = ((byte)(i9 >> 8 & 0xFF));
/* 4113 */           arrayOfByte2[17] = ((byte)(i9 & 0xFF));
/* 4114 */           arrayOfByte2[14] = ((byte)(i8 >> 8 & 0xFF));
/* 4115 */           arrayOfByte2[15] = ((byte)(i8 & 0xFF));
/* 4116 */           arrayOfByte2[12] = ((byte)(i7 >> 8 & 0xFF));
/* 4117 */           arrayOfByte2[13] = ((byte)(i7 & 0xFF));
/* 4118 */           arrayOfByte2[10] = ((byte)(i6 >> 8 & 0xFF));
/* 4119 */           arrayOfByte2[11] = ((byte)(i6 & 0xFF));
/* 4120 */           arrayOfByte2[8] = ((byte)(i5 >> 8 & 0xFF));
/* 4121 */           arrayOfByte2[9] = ((byte)(i5 & 0xFF));
/* 4122 */           arrayOfByte2[6] = ((byte)(i4 >> 8 & 0xFF));
/* 4123 */           arrayOfByte2[7] = ((byte)(i4 & 0xFF));
/* 4124 */           arrayOfByte2[4] = ((byte)(i3 >> 8 & 0xFF));
/* 4125 */           arrayOfByte2[5] = ((byte)(i3 & 0xFF));
/* 4126 */           arrayOfByte2[2] = ((byte)(i2 >> 8 & 0xFF));
/* 4127 */           arrayOfByte2[3] = ((byte)(i2 & 0xFF));
/* 4128 */           arrayOfByte2[0] = i38;
/* 4129 */           arrayOfByte2[1] = ((byte)(i1 & 0xFF));
/*      */         }
/*      */         
/* 4132 */         break;
/*      */       
/*      */       case 4: 
/* 4135 */         i38 = (byte)(i2 >> 8 & 0xFF);
/*      */         
/* 4137 */         if (i38 == 0)
/*      */         {
/* 4139 */           i29 = 45;
/* 4140 */           arrayOfByte2 = new byte[i29];
/* 4141 */           arrayOfByte2[43] = ((byte)(i24 >> 8 & 0xFF));
/* 4142 */           arrayOfByte2[44] = ((byte)(i24 & 0xFF));
/* 4143 */           arrayOfByte2[41] = ((byte)(i23 >> 8 & 0xFF));
/* 4144 */           arrayOfByte2[42] = ((byte)(i23 & 0xFF));
/* 4145 */           arrayOfByte2[39] = ((byte)(i22 >> 8 & 0xFF));
/* 4146 */           arrayOfByte2[40] = ((byte)(i22 & 0xFF));
/* 4147 */           arrayOfByte2[37] = ((byte)(i21 >> 8 & 0xFF));
/* 4148 */           arrayOfByte2[38] = ((byte)(i21 & 0xFF));
/* 4149 */           arrayOfByte2[35] = ((byte)(i20 >> 8 & 0xFF));
/* 4150 */           arrayOfByte2[36] = ((byte)(i20 & 0xFF));
/* 4151 */           arrayOfByte2[33] = ((byte)(i19 >> 8 & 0xFF));
/* 4152 */           arrayOfByte2[34] = ((byte)(i19 & 0xFF));
/* 4153 */           arrayOfByte2[31] = ((byte)(i18 >> 8 & 0xFF));
/* 4154 */           arrayOfByte2[32] = ((byte)(i18 & 0xFF));
/* 4155 */           arrayOfByte2[29] = ((byte)(i17 >> 8 & 0xFF));
/* 4156 */           arrayOfByte2[30] = ((byte)(i17 & 0xFF));
/* 4157 */           arrayOfByte2[27] = ((byte)(i16 >> 8 & 0xFF));
/* 4158 */           arrayOfByte2[28] = ((byte)(i16 & 0xFF));
/* 4159 */           arrayOfByte2[25] = ((byte)(i15 >> 8 & 0xFF));
/* 4160 */           arrayOfByte2[26] = ((byte)(i15 & 0xFF));
/* 4161 */           arrayOfByte2[23] = ((byte)(i14 >> 8 & 0xFF));
/* 4162 */           arrayOfByte2[24] = ((byte)(i14 & 0xFF));
/* 4163 */           arrayOfByte2[21] = ((byte)(i13 >> 8 & 0xFF));
/* 4164 */           arrayOfByte2[22] = ((byte)(i13 & 0xFF));
/* 4165 */           arrayOfByte2[19] = ((byte)(i12 >> 8 & 0xFF));
/* 4166 */           arrayOfByte2[20] = ((byte)(i12 & 0xFF));
/* 4167 */           arrayOfByte2[17] = ((byte)(i11 >> 8 & 0xFF));
/* 4168 */           arrayOfByte2[18] = ((byte)(i11 & 0xFF));
/* 4169 */           arrayOfByte2[15] = ((byte)(i10 >> 8 & 0xFF));
/* 4170 */           arrayOfByte2[16] = ((byte)(i10 & 0xFF));
/* 4171 */           arrayOfByte2[13] = ((byte)(i9 >> 8 & 0xFF));
/* 4172 */           arrayOfByte2[14] = ((byte)(i9 & 0xFF));
/* 4173 */           arrayOfByte2[11] = ((byte)(i8 >> 8 & 0xFF));
/* 4174 */           arrayOfByte2[12] = ((byte)(i8 & 0xFF));
/* 4175 */           arrayOfByte2[9] = ((byte)(i7 >> 8 & 0xFF));
/* 4176 */           arrayOfByte2[10] = ((byte)(i7 & 0xFF));
/* 4177 */           arrayOfByte2[7] = ((byte)(i6 >> 8 & 0xFF));
/* 4178 */           arrayOfByte2[8] = ((byte)(i6 & 0xFF));
/* 4179 */           arrayOfByte2[5] = ((byte)(i5 >> 8 & 0xFF));
/* 4180 */           arrayOfByte2[6] = ((byte)(i5 & 0xFF));
/* 4181 */           arrayOfByte2[3] = ((byte)(i4 >> 8 & 0xFF));
/* 4182 */           arrayOfByte2[4] = ((byte)(i4 & 0xFF));
/* 4183 */           arrayOfByte2[1] = ((byte)(i3 >> 8 & 0xFF));
/* 4184 */           arrayOfByte2[2] = ((byte)(i3 & 0xFF));
/* 4185 */           arrayOfByte2[0] = ((byte)(i2 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4189 */           i29 = 46;
/* 4190 */           arrayOfByte2 = new byte[i29];
/* 4191 */           arrayOfByte2[44] = ((byte)(i24 >> 8 & 0xFF));
/* 4192 */           arrayOfByte2[45] = ((byte)(i24 & 0xFF));
/* 4193 */           arrayOfByte2[42] = ((byte)(i23 >> 8 & 0xFF));
/* 4194 */           arrayOfByte2[43] = ((byte)(i23 & 0xFF));
/* 4195 */           arrayOfByte2[40] = ((byte)(i22 >> 8 & 0xFF));
/* 4196 */           arrayOfByte2[41] = ((byte)(i22 & 0xFF));
/* 4197 */           arrayOfByte2[38] = ((byte)(i21 >> 8 & 0xFF));
/* 4198 */           arrayOfByte2[39] = ((byte)(i21 & 0xFF));
/* 4199 */           arrayOfByte2[36] = ((byte)(i20 >> 8 & 0xFF));
/* 4200 */           arrayOfByte2[37] = ((byte)(i20 & 0xFF));
/* 4201 */           arrayOfByte2[34] = ((byte)(i19 >> 8 & 0xFF));
/* 4202 */           arrayOfByte2[35] = ((byte)(i19 & 0xFF));
/* 4203 */           arrayOfByte2[32] = ((byte)(i18 >> 8 & 0xFF));
/* 4204 */           arrayOfByte2[33] = ((byte)(i18 & 0xFF));
/* 4205 */           arrayOfByte2[30] = ((byte)(i17 >> 8 & 0xFF));
/* 4206 */           arrayOfByte2[31] = ((byte)(i17 & 0xFF));
/* 4207 */           arrayOfByte2[28] = ((byte)(i16 >> 8 & 0xFF));
/* 4208 */           arrayOfByte2[29] = ((byte)(i16 & 0xFF));
/* 4209 */           arrayOfByte2[26] = ((byte)(i15 >> 8 & 0xFF));
/* 4210 */           arrayOfByte2[27] = ((byte)(i15 & 0xFF));
/* 4211 */           arrayOfByte2[24] = ((byte)(i14 >> 8 & 0xFF));
/* 4212 */           arrayOfByte2[25] = ((byte)(i14 & 0xFF));
/* 4213 */           arrayOfByte2[22] = ((byte)(i13 >> 8 & 0xFF));
/* 4214 */           arrayOfByte2[23] = ((byte)(i13 & 0xFF));
/* 4215 */           arrayOfByte2[20] = ((byte)(i12 >> 8 & 0xFF));
/* 4216 */           arrayOfByte2[21] = ((byte)(i12 & 0xFF));
/* 4217 */           arrayOfByte2[18] = ((byte)(i11 >> 8 & 0xFF));
/* 4218 */           arrayOfByte2[19] = ((byte)(i11 & 0xFF));
/* 4219 */           arrayOfByte2[16] = ((byte)(i10 >> 8 & 0xFF));
/* 4220 */           arrayOfByte2[17] = ((byte)(i10 & 0xFF));
/* 4221 */           arrayOfByte2[14] = ((byte)(i9 >> 8 & 0xFF));
/* 4222 */           arrayOfByte2[15] = ((byte)(i9 & 0xFF));
/* 4223 */           arrayOfByte2[12] = ((byte)(i8 >> 8 & 0xFF));
/* 4224 */           arrayOfByte2[13] = ((byte)(i8 & 0xFF));
/* 4225 */           arrayOfByte2[10] = ((byte)(i7 >> 8 & 0xFF));
/* 4226 */           arrayOfByte2[11] = ((byte)(i7 & 0xFF));
/* 4227 */           arrayOfByte2[8] = ((byte)(i6 >> 8 & 0xFF));
/* 4228 */           arrayOfByte2[9] = ((byte)(i6 & 0xFF));
/* 4229 */           arrayOfByte2[6] = ((byte)(i5 >> 8 & 0xFF));
/* 4230 */           arrayOfByte2[7] = ((byte)(i5 & 0xFF));
/* 4231 */           arrayOfByte2[4] = ((byte)(i4 >> 8 & 0xFF));
/* 4232 */           arrayOfByte2[5] = ((byte)(i4 & 0xFF));
/* 4233 */           arrayOfByte2[2] = ((byte)(i3 >> 8 & 0xFF));
/* 4234 */           arrayOfByte2[3] = ((byte)(i3 & 0xFF));
/* 4235 */           arrayOfByte2[0] = i38;
/* 4236 */           arrayOfByte2[1] = ((byte)(i2 & 0xFF));
/*      */         }
/*      */         
/* 4239 */         break;
/*      */       
/*      */       case 5: 
/* 4242 */         i38 = (byte)(i3 >> 8 & 0xFF);
/*      */         
/* 4244 */         if (i38 == 0)
/*      */         {
/* 4246 */           i29 = 43;
/* 4247 */           arrayOfByte2 = new byte[i29];
/* 4248 */           arrayOfByte2[41] = ((byte)(i24 >> 8 & 0xFF));
/* 4249 */           arrayOfByte2[42] = ((byte)(i24 & 0xFF));
/* 4250 */           arrayOfByte2[39] = ((byte)(i23 >> 8 & 0xFF));
/* 4251 */           arrayOfByte2[40] = ((byte)(i23 & 0xFF));
/* 4252 */           arrayOfByte2[37] = ((byte)(i22 >> 8 & 0xFF));
/* 4253 */           arrayOfByte2[38] = ((byte)(i22 & 0xFF));
/* 4254 */           arrayOfByte2[35] = ((byte)(i21 >> 8 & 0xFF));
/* 4255 */           arrayOfByte2[36] = ((byte)(i21 & 0xFF));
/* 4256 */           arrayOfByte2[33] = ((byte)(i20 >> 8 & 0xFF));
/* 4257 */           arrayOfByte2[34] = ((byte)(i20 & 0xFF));
/* 4258 */           arrayOfByte2[31] = ((byte)(i19 >> 8 & 0xFF));
/* 4259 */           arrayOfByte2[32] = ((byte)(i19 & 0xFF));
/* 4260 */           arrayOfByte2[29] = ((byte)(i18 >> 8 & 0xFF));
/* 4261 */           arrayOfByte2[30] = ((byte)(i18 & 0xFF));
/* 4262 */           arrayOfByte2[27] = ((byte)(i17 >> 8 & 0xFF));
/* 4263 */           arrayOfByte2[28] = ((byte)(i17 & 0xFF));
/* 4264 */           arrayOfByte2[25] = ((byte)(i16 >> 8 & 0xFF));
/* 4265 */           arrayOfByte2[26] = ((byte)(i16 & 0xFF));
/* 4266 */           arrayOfByte2[23] = ((byte)(i15 >> 8 & 0xFF));
/* 4267 */           arrayOfByte2[24] = ((byte)(i15 & 0xFF));
/* 4268 */           arrayOfByte2[21] = ((byte)(i14 >> 8 & 0xFF));
/* 4269 */           arrayOfByte2[22] = ((byte)(i14 & 0xFF));
/* 4270 */           arrayOfByte2[19] = ((byte)(i13 >> 8 & 0xFF));
/* 4271 */           arrayOfByte2[20] = ((byte)(i13 & 0xFF));
/* 4272 */           arrayOfByte2[17] = ((byte)(i12 >> 8 & 0xFF));
/* 4273 */           arrayOfByte2[18] = ((byte)(i12 & 0xFF));
/* 4274 */           arrayOfByte2[15] = ((byte)(i11 >> 8 & 0xFF));
/* 4275 */           arrayOfByte2[16] = ((byte)(i11 & 0xFF));
/* 4276 */           arrayOfByte2[13] = ((byte)(i10 >> 8 & 0xFF));
/* 4277 */           arrayOfByte2[14] = ((byte)(i10 & 0xFF));
/* 4278 */           arrayOfByte2[11] = ((byte)(i9 >> 8 & 0xFF));
/* 4279 */           arrayOfByte2[12] = ((byte)(i9 & 0xFF));
/* 4280 */           arrayOfByte2[9] = ((byte)(i8 >> 8 & 0xFF));
/* 4281 */           arrayOfByte2[10] = ((byte)(i8 & 0xFF));
/* 4282 */           arrayOfByte2[7] = ((byte)(i7 >> 8 & 0xFF));
/* 4283 */           arrayOfByte2[8] = ((byte)(i7 & 0xFF));
/* 4284 */           arrayOfByte2[5] = ((byte)(i6 >> 8 & 0xFF));
/* 4285 */           arrayOfByte2[6] = ((byte)(i6 & 0xFF));
/* 4286 */           arrayOfByte2[3] = ((byte)(i5 >> 8 & 0xFF));
/* 4287 */           arrayOfByte2[4] = ((byte)(i5 & 0xFF));
/* 4288 */           arrayOfByte2[1] = ((byte)(i4 >> 8 & 0xFF));
/* 4289 */           arrayOfByte2[2] = ((byte)(i4 & 0xFF));
/* 4290 */           arrayOfByte2[0] = ((byte)(i3 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4294 */           i29 = 44;
/* 4295 */           arrayOfByte2 = new byte[i29];
/* 4296 */           arrayOfByte2[42] = ((byte)(i24 >> 8 & 0xFF));
/* 4297 */           arrayOfByte2[43] = ((byte)(i24 & 0xFF));
/* 4298 */           arrayOfByte2[40] = ((byte)(i23 >> 8 & 0xFF));
/* 4299 */           arrayOfByte2[41] = ((byte)(i23 & 0xFF));
/* 4300 */           arrayOfByte2[38] = ((byte)(i22 >> 8 & 0xFF));
/* 4301 */           arrayOfByte2[39] = ((byte)(i22 & 0xFF));
/* 4302 */           arrayOfByte2[36] = ((byte)(i21 >> 8 & 0xFF));
/* 4303 */           arrayOfByte2[37] = ((byte)(i21 & 0xFF));
/* 4304 */           arrayOfByte2[34] = ((byte)(i20 >> 8 & 0xFF));
/* 4305 */           arrayOfByte2[35] = ((byte)(i20 & 0xFF));
/* 4306 */           arrayOfByte2[32] = ((byte)(i19 >> 8 & 0xFF));
/* 4307 */           arrayOfByte2[33] = ((byte)(i19 & 0xFF));
/* 4308 */           arrayOfByte2[30] = ((byte)(i18 >> 8 & 0xFF));
/* 4309 */           arrayOfByte2[31] = ((byte)(i18 & 0xFF));
/* 4310 */           arrayOfByte2[28] = ((byte)(i17 >> 8 & 0xFF));
/* 4311 */           arrayOfByte2[29] = ((byte)(i17 & 0xFF));
/* 4312 */           arrayOfByte2[26] = ((byte)(i16 >> 8 & 0xFF));
/* 4313 */           arrayOfByte2[27] = ((byte)(i16 & 0xFF));
/* 4314 */           arrayOfByte2[24] = ((byte)(i15 >> 8 & 0xFF));
/* 4315 */           arrayOfByte2[25] = ((byte)(i15 & 0xFF));
/* 4316 */           arrayOfByte2[22] = ((byte)(i14 >> 8 & 0xFF));
/* 4317 */           arrayOfByte2[23] = ((byte)(i14 & 0xFF));
/* 4318 */           arrayOfByte2[20] = ((byte)(i13 >> 8 & 0xFF));
/* 4319 */           arrayOfByte2[21] = ((byte)(i13 & 0xFF));
/* 4320 */           arrayOfByte2[18] = ((byte)(i12 >> 8 & 0xFF));
/* 4321 */           arrayOfByte2[19] = ((byte)(i12 & 0xFF));
/* 4322 */           arrayOfByte2[16] = ((byte)(i11 >> 8 & 0xFF));
/* 4323 */           arrayOfByte2[17] = ((byte)(i11 & 0xFF));
/* 4324 */           arrayOfByte2[14] = ((byte)(i10 >> 8 & 0xFF));
/* 4325 */           arrayOfByte2[15] = ((byte)(i10 & 0xFF));
/* 4326 */           arrayOfByte2[12] = ((byte)(i9 >> 8 & 0xFF));
/* 4327 */           arrayOfByte2[13] = ((byte)(i9 & 0xFF));
/* 4328 */           arrayOfByte2[10] = ((byte)(i8 >> 8 & 0xFF));
/* 4329 */           arrayOfByte2[11] = ((byte)(i8 & 0xFF));
/* 4330 */           arrayOfByte2[8] = ((byte)(i7 >> 8 & 0xFF));
/* 4331 */           arrayOfByte2[9] = ((byte)(i7 & 0xFF));
/* 4332 */           arrayOfByte2[6] = ((byte)(i6 >> 8 & 0xFF));
/* 4333 */           arrayOfByte2[7] = ((byte)(i6 & 0xFF));
/* 4334 */           arrayOfByte2[4] = ((byte)(i5 >> 8 & 0xFF));
/* 4335 */           arrayOfByte2[5] = ((byte)(i5 & 0xFF));
/* 4336 */           arrayOfByte2[2] = ((byte)(i4 >> 8 & 0xFF));
/* 4337 */           arrayOfByte2[3] = ((byte)(i4 & 0xFF));
/* 4338 */           arrayOfByte2[0] = i38;
/* 4339 */           arrayOfByte2[1] = ((byte)(i3 & 0xFF));
/*      */         }
/*      */         
/* 4342 */         break;
/*      */       
/*      */       case 6: 
/* 4345 */         i38 = (byte)(i4 >> 8 & 0xFF);
/*      */         
/* 4347 */         if (i38 == 0)
/*      */         {
/* 4349 */           i29 = 41;
/* 4350 */           arrayOfByte2 = new byte[i29];
/* 4351 */           arrayOfByte2[39] = ((byte)(i24 >> 8 & 0xFF));
/* 4352 */           arrayOfByte2[40] = ((byte)(i24 & 0xFF));
/* 4353 */           arrayOfByte2[37] = ((byte)(i23 >> 8 & 0xFF));
/* 4354 */           arrayOfByte2[38] = ((byte)(i23 & 0xFF));
/* 4355 */           arrayOfByte2[35] = ((byte)(i22 >> 8 & 0xFF));
/* 4356 */           arrayOfByte2[36] = ((byte)(i22 & 0xFF));
/* 4357 */           arrayOfByte2[33] = ((byte)(i21 >> 8 & 0xFF));
/* 4358 */           arrayOfByte2[34] = ((byte)(i21 & 0xFF));
/* 4359 */           arrayOfByte2[31] = ((byte)(i20 >> 8 & 0xFF));
/* 4360 */           arrayOfByte2[32] = ((byte)(i20 & 0xFF));
/* 4361 */           arrayOfByte2[29] = ((byte)(i19 >> 8 & 0xFF));
/* 4362 */           arrayOfByte2[30] = ((byte)(i19 & 0xFF));
/* 4363 */           arrayOfByte2[27] = ((byte)(i18 >> 8 & 0xFF));
/* 4364 */           arrayOfByte2[28] = ((byte)(i18 & 0xFF));
/* 4365 */           arrayOfByte2[25] = ((byte)(i17 >> 8 & 0xFF));
/* 4366 */           arrayOfByte2[26] = ((byte)(i17 & 0xFF));
/* 4367 */           arrayOfByte2[23] = ((byte)(i16 >> 8 & 0xFF));
/* 4368 */           arrayOfByte2[24] = ((byte)(i16 & 0xFF));
/* 4369 */           arrayOfByte2[21] = ((byte)(i15 >> 8 & 0xFF));
/* 4370 */           arrayOfByte2[22] = ((byte)(i15 & 0xFF));
/* 4371 */           arrayOfByte2[19] = ((byte)(i14 >> 8 & 0xFF));
/* 4372 */           arrayOfByte2[20] = ((byte)(i14 & 0xFF));
/* 4373 */           arrayOfByte2[17] = ((byte)(i13 >> 8 & 0xFF));
/* 4374 */           arrayOfByte2[18] = ((byte)(i13 & 0xFF));
/* 4375 */           arrayOfByte2[15] = ((byte)(i12 >> 8 & 0xFF));
/* 4376 */           arrayOfByte2[16] = ((byte)(i12 & 0xFF));
/* 4377 */           arrayOfByte2[13] = ((byte)(i11 >> 8 & 0xFF));
/* 4378 */           arrayOfByte2[14] = ((byte)(i11 & 0xFF));
/* 4379 */           arrayOfByte2[11] = ((byte)(i10 >> 8 & 0xFF));
/* 4380 */           arrayOfByte2[12] = ((byte)(i10 & 0xFF));
/* 4381 */           arrayOfByte2[9] = ((byte)(i9 >> 8 & 0xFF));
/* 4382 */           arrayOfByte2[10] = ((byte)(i9 & 0xFF));
/* 4383 */           arrayOfByte2[7] = ((byte)(i8 >> 8 & 0xFF));
/* 4384 */           arrayOfByte2[8] = ((byte)(i8 & 0xFF));
/* 4385 */           arrayOfByte2[5] = ((byte)(i7 >> 8 & 0xFF));
/* 4386 */           arrayOfByte2[6] = ((byte)(i7 & 0xFF));
/* 4387 */           arrayOfByte2[3] = ((byte)(i6 >> 8 & 0xFF));
/* 4388 */           arrayOfByte2[4] = ((byte)(i6 & 0xFF));
/* 4389 */           arrayOfByte2[1] = ((byte)(i5 >> 8 & 0xFF));
/* 4390 */           arrayOfByte2[2] = ((byte)(i5 & 0xFF));
/* 4391 */           arrayOfByte2[0] = ((byte)(i4 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4395 */           i29 = 42;
/* 4396 */           arrayOfByte2 = new byte[i29];
/* 4397 */           arrayOfByte2[40] = ((byte)(i24 >> 8 & 0xFF));
/* 4398 */           arrayOfByte2[41] = ((byte)(i24 & 0xFF));
/* 4399 */           arrayOfByte2[38] = ((byte)(i23 >> 8 & 0xFF));
/* 4400 */           arrayOfByte2[39] = ((byte)(i23 & 0xFF));
/* 4401 */           arrayOfByte2[36] = ((byte)(i22 >> 8 & 0xFF));
/* 4402 */           arrayOfByte2[37] = ((byte)(i22 & 0xFF));
/* 4403 */           arrayOfByte2[34] = ((byte)(i21 >> 8 & 0xFF));
/* 4404 */           arrayOfByte2[35] = ((byte)(i21 & 0xFF));
/* 4405 */           arrayOfByte2[32] = ((byte)(i20 >> 8 & 0xFF));
/* 4406 */           arrayOfByte2[33] = ((byte)(i20 & 0xFF));
/* 4407 */           arrayOfByte2[30] = ((byte)(i19 >> 8 & 0xFF));
/* 4408 */           arrayOfByte2[31] = ((byte)(i19 & 0xFF));
/* 4409 */           arrayOfByte2[28] = ((byte)(i18 >> 8 & 0xFF));
/* 4410 */           arrayOfByte2[29] = ((byte)(i18 & 0xFF));
/* 4411 */           arrayOfByte2[26] = ((byte)(i17 >> 8 & 0xFF));
/* 4412 */           arrayOfByte2[27] = ((byte)(i17 & 0xFF));
/* 4413 */           arrayOfByte2[24] = ((byte)(i16 >> 8 & 0xFF));
/* 4414 */           arrayOfByte2[25] = ((byte)(i16 & 0xFF));
/* 4415 */           arrayOfByte2[22] = ((byte)(i15 >> 8 & 0xFF));
/* 4416 */           arrayOfByte2[23] = ((byte)(i15 & 0xFF));
/* 4417 */           arrayOfByte2[20] = ((byte)(i14 >> 8 & 0xFF));
/* 4418 */           arrayOfByte2[21] = ((byte)(i14 & 0xFF));
/* 4419 */           arrayOfByte2[18] = ((byte)(i13 >> 8 & 0xFF));
/* 4420 */           arrayOfByte2[19] = ((byte)(i13 & 0xFF));
/* 4421 */           arrayOfByte2[16] = ((byte)(i12 >> 8 & 0xFF));
/* 4422 */           arrayOfByte2[17] = ((byte)(i12 & 0xFF));
/* 4423 */           arrayOfByte2[14] = ((byte)(i11 >> 8 & 0xFF));
/* 4424 */           arrayOfByte2[15] = ((byte)(i11 & 0xFF));
/* 4425 */           arrayOfByte2[12] = ((byte)(i10 >> 8 & 0xFF));
/* 4426 */           arrayOfByte2[13] = ((byte)(i10 & 0xFF));
/* 4427 */           arrayOfByte2[10] = ((byte)(i9 >> 8 & 0xFF));
/* 4428 */           arrayOfByte2[11] = ((byte)(i9 & 0xFF));
/* 4429 */           arrayOfByte2[8] = ((byte)(i8 >> 8 & 0xFF));
/* 4430 */           arrayOfByte2[9] = ((byte)(i8 & 0xFF));
/* 4431 */           arrayOfByte2[6] = ((byte)(i7 >> 8 & 0xFF));
/* 4432 */           arrayOfByte2[7] = ((byte)(i7 & 0xFF));
/* 4433 */           arrayOfByte2[4] = ((byte)(i6 >> 8 & 0xFF));
/* 4434 */           arrayOfByte2[5] = ((byte)(i6 & 0xFF));
/* 4435 */           arrayOfByte2[2] = ((byte)(i5 >> 8 & 0xFF));
/* 4436 */           arrayOfByte2[3] = ((byte)(i5 & 0xFF));
/* 4437 */           arrayOfByte2[0] = i38;
/* 4438 */           arrayOfByte2[1] = ((byte)(i4 & 0xFF));
/*      */         }
/*      */         
/* 4441 */         break;
/*      */       
/*      */       case 7: 
/* 4444 */         i38 = (byte)(i5 >> 8 & 0xFF);
/*      */         
/* 4446 */         if (i38 == 0)
/*      */         {
/* 4448 */           i29 = 39;
/* 4449 */           arrayOfByte2 = new byte[i29];
/* 4450 */           arrayOfByte2[37] = ((byte)(i24 >> 8 & 0xFF));
/* 4451 */           arrayOfByte2[38] = ((byte)(i24 & 0xFF));
/* 4452 */           arrayOfByte2[35] = ((byte)(i23 >> 8 & 0xFF));
/* 4453 */           arrayOfByte2[36] = ((byte)(i23 & 0xFF));
/* 4454 */           arrayOfByte2[33] = ((byte)(i22 >> 8 & 0xFF));
/* 4455 */           arrayOfByte2[34] = ((byte)(i22 & 0xFF));
/* 4456 */           arrayOfByte2[31] = ((byte)(i21 >> 8 & 0xFF));
/* 4457 */           arrayOfByte2[32] = ((byte)(i21 & 0xFF));
/* 4458 */           arrayOfByte2[29] = ((byte)(i20 >> 8 & 0xFF));
/* 4459 */           arrayOfByte2[30] = ((byte)(i20 & 0xFF));
/* 4460 */           arrayOfByte2[27] = ((byte)(i19 >> 8 & 0xFF));
/* 4461 */           arrayOfByte2[28] = ((byte)(i19 & 0xFF));
/* 4462 */           arrayOfByte2[25] = ((byte)(i18 >> 8 & 0xFF));
/* 4463 */           arrayOfByte2[26] = ((byte)(i18 & 0xFF));
/* 4464 */           arrayOfByte2[23] = ((byte)(i17 >> 8 & 0xFF));
/* 4465 */           arrayOfByte2[24] = ((byte)(i17 & 0xFF));
/* 4466 */           arrayOfByte2[21] = ((byte)(i16 >> 8 & 0xFF));
/* 4467 */           arrayOfByte2[22] = ((byte)(i16 & 0xFF));
/* 4468 */           arrayOfByte2[19] = ((byte)(i15 >> 8 & 0xFF));
/* 4469 */           arrayOfByte2[20] = ((byte)(i15 & 0xFF));
/* 4470 */           arrayOfByte2[17] = ((byte)(i14 >> 8 & 0xFF));
/* 4471 */           arrayOfByte2[18] = ((byte)(i14 & 0xFF));
/* 4472 */           arrayOfByte2[15] = ((byte)(i13 >> 8 & 0xFF));
/* 4473 */           arrayOfByte2[16] = ((byte)(i13 & 0xFF));
/* 4474 */           arrayOfByte2[13] = ((byte)(i12 >> 8 & 0xFF));
/* 4475 */           arrayOfByte2[14] = ((byte)(i12 & 0xFF));
/* 4476 */           arrayOfByte2[11] = ((byte)(i11 >> 8 & 0xFF));
/* 4477 */           arrayOfByte2[12] = ((byte)(i11 & 0xFF));
/* 4478 */           arrayOfByte2[9] = ((byte)(i10 >> 8 & 0xFF));
/* 4479 */           arrayOfByte2[10] = ((byte)(i10 & 0xFF));
/* 4480 */           arrayOfByte2[7] = ((byte)(i9 >> 8 & 0xFF));
/* 4481 */           arrayOfByte2[8] = ((byte)(i9 & 0xFF));
/* 4482 */           arrayOfByte2[5] = ((byte)(i8 >> 8 & 0xFF));
/* 4483 */           arrayOfByte2[6] = ((byte)(i8 & 0xFF));
/* 4484 */           arrayOfByte2[3] = ((byte)(i7 >> 8 & 0xFF));
/* 4485 */           arrayOfByte2[4] = ((byte)(i7 & 0xFF));
/* 4486 */           arrayOfByte2[1] = ((byte)(i6 >> 8 & 0xFF));
/* 4487 */           arrayOfByte2[2] = ((byte)(i6 & 0xFF));
/* 4488 */           arrayOfByte2[0] = ((byte)(i5 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4492 */           i29 = 40;
/* 4493 */           arrayOfByte2 = new byte[i29];
/* 4494 */           arrayOfByte2[38] = ((byte)(i24 >> 8 & 0xFF));
/* 4495 */           arrayOfByte2[39] = ((byte)(i24 & 0xFF));
/* 4496 */           arrayOfByte2[36] = ((byte)(i23 >> 8 & 0xFF));
/* 4497 */           arrayOfByte2[37] = ((byte)(i23 & 0xFF));
/* 4498 */           arrayOfByte2[34] = ((byte)(i22 >> 8 & 0xFF));
/* 4499 */           arrayOfByte2[35] = ((byte)(i22 & 0xFF));
/* 4500 */           arrayOfByte2[32] = ((byte)(i21 >> 8 & 0xFF));
/* 4501 */           arrayOfByte2[33] = ((byte)(i21 & 0xFF));
/* 4502 */           arrayOfByte2[30] = ((byte)(i20 >> 8 & 0xFF));
/* 4503 */           arrayOfByte2[31] = ((byte)(i20 & 0xFF));
/* 4504 */           arrayOfByte2[28] = ((byte)(i19 >> 8 & 0xFF));
/* 4505 */           arrayOfByte2[29] = ((byte)(i19 & 0xFF));
/* 4506 */           arrayOfByte2[26] = ((byte)(i18 >> 8 & 0xFF));
/* 4507 */           arrayOfByte2[27] = ((byte)(i18 & 0xFF));
/* 4508 */           arrayOfByte2[24] = ((byte)(i17 >> 8 & 0xFF));
/* 4509 */           arrayOfByte2[25] = ((byte)(i17 & 0xFF));
/* 4510 */           arrayOfByte2[22] = ((byte)(i16 >> 8 & 0xFF));
/* 4511 */           arrayOfByte2[23] = ((byte)(i16 & 0xFF));
/* 4512 */           arrayOfByte2[20] = ((byte)(i15 >> 8 & 0xFF));
/* 4513 */           arrayOfByte2[21] = ((byte)(i15 & 0xFF));
/* 4514 */           arrayOfByte2[18] = ((byte)(i14 >> 8 & 0xFF));
/* 4515 */           arrayOfByte2[19] = ((byte)(i14 & 0xFF));
/* 4516 */           arrayOfByte2[16] = ((byte)(i13 >> 8 & 0xFF));
/* 4517 */           arrayOfByte2[17] = ((byte)(i13 & 0xFF));
/* 4518 */           arrayOfByte2[14] = ((byte)(i12 >> 8 & 0xFF));
/* 4519 */           arrayOfByte2[15] = ((byte)(i12 & 0xFF));
/* 4520 */           arrayOfByte2[12] = ((byte)(i11 >> 8 & 0xFF));
/* 4521 */           arrayOfByte2[13] = ((byte)(i11 & 0xFF));
/* 4522 */           arrayOfByte2[10] = ((byte)(i10 >> 8 & 0xFF));
/* 4523 */           arrayOfByte2[11] = ((byte)(i10 & 0xFF));
/* 4524 */           arrayOfByte2[8] = ((byte)(i9 >> 8 & 0xFF));
/* 4525 */           arrayOfByte2[9] = ((byte)(i9 & 0xFF));
/* 4526 */           arrayOfByte2[6] = ((byte)(i8 >> 8 & 0xFF));
/* 4527 */           arrayOfByte2[7] = ((byte)(i8 & 0xFF));
/* 4528 */           arrayOfByte2[4] = ((byte)(i7 >> 8 & 0xFF));
/* 4529 */           arrayOfByte2[5] = ((byte)(i7 & 0xFF));
/* 4530 */           arrayOfByte2[2] = ((byte)(i6 >> 8 & 0xFF));
/* 4531 */           arrayOfByte2[3] = ((byte)(i6 & 0xFF));
/* 4532 */           arrayOfByte2[0] = i38;
/* 4533 */           arrayOfByte2[1] = ((byte)(i5 & 0xFF));
/*      */         }
/*      */         
/* 4536 */         break;
/*      */       
/*      */       case 8: 
/* 4539 */         i38 = (byte)(i6 >> 8 & 0xFF);
/*      */         
/* 4541 */         if (i38 == 0)
/*      */         {
/* 4543 */           i29 = 37;
/* 4544 */           arrayOfByte2 = new byte[i29];
/* 4545 */           arrayOfByte2[35] = ((byte)(i24 >> 8 & 0xFF));
/* 4546 */           arrayOfByte2[36] = ((byte)(i24 & 0xFF));
/* 4547 */           arrayOfByte2[33] = ((byte)(i23 >> 8 & 0xFF));
/* 4548 */           arrayOfByte2[34] = ((byte)(i23 & 0xFF));
/* 4549 */           arrayOfByte2[31] = ((byte)(i22 >> 8 & 0xFF));
/* 4550 */           arrayOfByte2[32] = ((byte)(i22 & 0xFF));
/* 4551 */           arrayOfByte2[29] = ((byte)(i21 >> 8 & 0xFF));
/* 4552 */           arrayOfByte2[30] = ((byte)(i21 & 0xFF));
/* 4553 */           arrayOfByte2[27] = ((byte)(i20 >> 8 & 0xFF));
/* 4554 */           arrayOfByte2[28] = ((byte)(i20 & 0xFF));
/* 4555 */           arrayOfByte2[25] = ((byte)(i19 >> 8 & 0xFF));
/* 4556 */           arrayOfByte2[26] = ((byte)(i19 & 0xFF));
/* 4557 */           arrayOfByte2[23] = ((byte)(i18 >> 8 & 0xFF));
/* 4558 */           arrayOfByte2[24] = ((byte)(i18 & 0xFF));
/* 4559 */           arrayOfByte2[21] = ((byte)(i17 >> 8 & 0xFF));
/* 4560 */           arrayOfByte2[22] = ((byte)(i17 & 0xFF));
/* 4561 */           arrayOfByte2[19] = ((byte)(i16 >> 8 & 0xFF));
/* 4562 */           arrayOfByte2[20] = ((byte)(i16 & 0xFF));
/* 4563 */           arrayOfByte2[17] = ((byte)(i15 >> 8 & 0xFF));
/* 4564 */           arrayOfByte2[18] = ((byte)(i15 & 0xFF));
/* 4565 */           arrayOfByte2[15] = ((byte)(i14 >> 8 & 0xFF));
/* 4566 */           arrayOfByte2[16] = ((byte)(i14 & 0xFF));
/* 4567 */           arrayOfByte2[13] = ((byte)(i13 >> 8 & 0xFF));
/* 4568 */           arrayOfByte2[14] = ((byte)(i13 & 0xFF));
/* 4569 */           arrayOfByte2[11] = ((byte)(i12 >> 8 & 0xFF));
/* 4570 */           arrayOfByte2[12] = ((byte)(i12 & 0xFF));
/* 4571 */           arrayOfByte2[9] = ((byte)(i11 >> 8 & 0xFF));
/* 4572 */           arrayOfByte2[10] = ((byte)(i11 & 0xFF));
/* 4573 */           arrayOfByte2[7] = ((byte)(i10 >> 8 & 0xFF));
/* 4574 */           arrayOfByte2[8] = ((byte)(i10 & 0xFF));
/* 4575 */           arrayOfByte2[5] = ((byte)(i9 >> 8 & 0xFF));
/* 4576 */           arrayOfByte2[6] = ((byte)(i9 & 0xFF));
/* 4577 */           arrayOfByte2[3] = ((byte)(i8 >> 8 & 0xFF));
/* 4578 */           arrayOfByte2[4] = ((byte)(i8 & 0xFF));
/* 4579 */           arrayOfByte2[1] = ((byte)(i7 >> 8 & 0xFF));
/* 4580 */           arrayOfByte2[2] = ((byte)(i7 & 0xFF));
/* 4581 */           arrayOfByte2[0] = ((byte)(i6 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4585 */           i29 = 38;
/* 4586 */           arrayOfByte2 = new byte[i29];
/* 4587 */           arrayOfByte2[36] = ((byte)(i24 >> 8 & 0xFF));
/* 4588 */           arrayOfByte2[37] = ((byte)(i24 & 0xFF));
/* 4589 */           arrayOfByte2[34] = ((byte)(i23 >> 8 & 0xFF));
/* 4590 */           arrayOfByte2[35] = ((byte)(i23 & 0xFF));
/* 4591 */           arrayOfByte2[32] = ((byte)(i22 >> 8 & 0xFF));
/* 4592 */           arrayOfByte2[33] = ((byte)(i22 & 0xFF));
/* 4593 */           arrayOfByte2[30] = ((byte)(i21 >> 8 & 0xFF));
/* 4594 */           arrayOfByte2[31] = ((byte)(i21 & 0xFF));
/* 4595 */           arrayOfByte2[28] = ((byte)(i20 >> 8 & 0xFF));
/* 4596 */           arrayOfByte2[29] = ((byte)(i20 & 0xFF));
/* 4597 */           arrayOfByte2[26] = ((byte)(i19 >> 8 & 0xFF));
/* 4598 */           arrayOfByte2[27] = ((byte)(i19 & 0xFF));
/* 4599 */           arrayOfByte2[24] = ((byte)(i18 >> 8 & 0xFF));
/* 4600 */           arrayOfByte2[25] = ((byte)(i18 & 0xFF));
/* 4601 */           arrayOfByte2[22] = ((byte)(i17 >> 8 & 0xFF));
/* 4602 */           arrayOfByte2[23] = ((byte)(i17 & 0xFF));
/* 4603 */           arrayOfByte2[20] = ((byte)(i16 >> 8 & 0xFF));
/* 4604 */           arrayOfByte2[21] = ((byte)(i16 & 0xFF));
/* 4605 */           arrayOfByte2[18] = ((byte)(i15 >> 8 & 0xFF));
/* 4606 */           arrayOfByte2[19] = ((byte)(i15 & 0xFF));
/* 4607 */           arrayOfByte2[16] = ((byte)(i14 >> 8 & 0xFF));
/* 4608 */           arrayOfByte2[17] = ((byte)(i14 & 0xFF));
/* 4609 */           arrayOfByte2[14] = ((byte)(i13 >> 8 & 0xFF));
/* 4610 */           arrayOfByte2[15] = ((byte)(i13 & 0xFF));
/* 4611 */           arrayOfByte2[12] = ((byte)(i12 >> 8 & 0xFF));
/* 4612 */           arrayOfByte2[13] = ((byte)(i12 & 0xFF));
/* 4613 */           arrayOfByte2[10] = ((byte)(i11 >> 8 & 0xFF));
/* 4614 */           arrayOfByte2[11] = ((byte)(i11 & 0xFF));
/* 4615 */           arrayOfByte2[8] = ((byte)(i10 >> 8 & 0xFF));
/* 4616 */           arrayOfByte2[9] = ((byte)(i10 & 0xFF));
/* 4617 */           arrayOfByte2[6] = ((byte)(i9 >> 8 & 0xFF));
/* 4618 */           arrayOfByte2[7] = ((byte)(i9 & 0xFF));
/* 4619 */           arrayOfByte2[4] = ((byte)(i8 >> 8 & 0xFF));
/* 4620 */           arrayOfByte2[5] = ((byte)(i8 & 0xFF));
/* 4621 */           arrayOfByte2[2] = ((byte)(i7 >> 8 & 0xFF));
/* 4622 */           arrayOfByte2[3] = ((byte)(i7 & 0xFF));
/* 4623 */           arrayOfByte2[0] = i38;
/* 4624 */           arrayOfByte2[1] = ((byte)(i6 & 0xFF));
/*      */         }
/*      */         
/* 4627 */         break;
/*      */       
/*      */       case 9: 
/* 4630 */         i38 = (byte)(i7 >> 8 & 0xFF);
/*      */         
/* 4632 */         if (i38 == 0)
/*      */         {
/* 4634 */           i29 = 35;
/* 4635 */           arrayOfByte2 = new byte[i29];
/* 4636 */           arrayOfByte2[33] = ((byte)(i24 >> 8 & 0xFF));
/* 4637 */           arrayOfByte2[34] = ((byte)(i24 & 0xFF));
/* 4638 */           arrayOfByte2[31] = ((byte)(i23 >> 8 & 0xFF));
/* 4639 */           arrayOfByte2[32] = ((byte)(i23 & 0xFF));
/* 4640 */           arrayOfByte2[29] = ((byte)(i22 >> 8 & 0xFF));
/* 4641 */           arrayOfByte2[30] = ((byte)(i22 & 0xFF));
/* 4642 */           arrayOfByte2[27] = ((byte)(i21 >> 8 & 0xFF));
/* 4643 */           arrayOfByte2[28] = ((byte)(i21 & 0xFF));
/* 4644 */           arrayOfByte2[25] = ((byte)(i20 >> 8 & 0xFF));
/* 4645 */           arrayOfByte2[26] = ((byte)(i20 & 0xFF));
/* 4646 */           arrayOfByte2[23] = ((byte)(i19 >> 8 & 0xFF));
/* 4647 */           arrayOfByte2[24] = ((byte)(i19 & 0xFF));
/* 4648 */           arrayOfByte2[21] = ((byte)(i18 >> 8 & 0xFF));
/* 4649 */           arrayOfByte2[22] = ((byte)(i18 & 0xFF));
/* 4650 */           arrayOfByte2[19] = ((byte)(i17 >> 8 & 0xFF));
/* 4651 */           arrayOfByte2[20] = ((byte)(i17 & 0xFF));
/* 4652 */           arrayOfByte2[17] = ((byte)(i16 >> 8 & 0xFF));
/* 4653 */           arrayOfByte2[18] = ((byte)(i16 & 0xFF));
/* 4654 */           arrayOfByte2[15] = ((byte)(i15 >> 8 & 0xFF));
/* 4655 */           arrayOfByte2[16] = ((byte)(i15 & 0xFF));
/* 4656 */           arrayOfByte2[13] = ((byte)(i14 >> 8 & 0xFF));
/* 4657 */           arrayOfByte2[14] = ((byte)(i14 & 0xFF));
/* 4658 */           arrayOfByte2[11] = ((byte)(i13 >> 8 & 0xFF));
/* 4659 */           arrayOfByte2[12] = ((byte)(i13 & 0xFF));
/* 4660 */           arrayOfByte2[9] = ((byte)(i12 >> 8 & 0xFF));
/* 4661 */           arrayOfByte2[10] = ((byte)(i12 & 0xFF));
/* 4662 */           arrayOfByte2[7] = ((byte)(i11 >> 8 & 0xFF));
/* 4663 */           arrayOfByte2[8] = ((byte)(i11 & 0xFF));
/* 4664 */           arrayOfByte2[5] = ((byte)(i10 >> 8 & 0xFF));
/* 4665 */           arrayOfByte2[6] = ((byte)(i10 & 0xFF));
/* 4666 */           arrayOfByte2[3] = ((byte)(i9 >> 8 & 0xFF));
/* 4667 */           arrayOfByte2[4] = ((byte)(i9 & 0xFF));
/* 4668 */           arrayOfByte2[1] = ((byte)(i8 >> 8 & 0xFF));
/* 4669 */           arrayOfByte2[2] = ((byte)(i8 & 0xFF));
/* 4670 */           arrayOfByte2[0] = ((byte)(i7 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4674 */           i29 = 36;
/* 4675 */           arrayOfByte2 = new byte[i29];
/* 4676 */           arrayOfByte2[34] = ((byte)(i24 >> 8 & 0xFF));
/* 4677 */           arrayOfByte2[35] = ((byte)(i24 & 0xFF));
/* 4678 */           arrayOfByte2[32] = ((byte)(i23 >> 8 & 0xFF));
/* 4679 */           arrayOfByte2[33] = ((byte)(i23 & 0xFF));
/* 4680 */           arrayOfByte2[30] = ((byte)(i22 >> 8 & 0xFF));
/* 4681 */           arrayOfByte2[31] = ((byte)(i22 & 0xFF));
/* 4682 */           arrayOfByte2[28] = ((byte)(i21 >> 8 & 0xFF));
/* 4683 */           arrayOfByte2[29] = ((byte)(i21 & 0xFF));
/* 4684 */           arrayOfByte2[26] = ((byte)(i20 >> 8 & 0xFF));
/* 4685 */           arrayOfByte2[27] = ((byte)(i20 & 0xFF));
/* 4686 */           arrayOfByte2[24] = ((byte)(i19 >> 8 & 0xFF));
/* 4687 */           arrayOfByte2[25] = ((byte)(i19 & 0xFF));
/* 4688 */           arrayOfByte2[22] = ((byte)(i18 >> 8 & 0xFF));
/* 4689 */           arrayOfByte2[23] = ((byte)(i18 & 0xFF));
/* 4690 */           arrayOfByte2[20] = ((byte)(i17 >> 8 & 0xFF));
/* 4691 */           arrayOfByte2[21] = ((byte)(i17 & 0xFF));
/* 4692 */           arrayOfByte2[18] = ((byte)(i16 >> 8 & 0xFF));
/* 4693 */           arrayOfByte2[19] = ((byte)(i16 & 0xFF));
/* 4694 */           arrayOfByte2[16] = ((byte)(i15 >> 8 & 0xFF));
/* 4695 */           arrayOfByte2[17] = ((byte)(i15 & 0xFF));
/* 4696 */           arrayOfByte2[14] = ((byte)(i14 >> 8 & 0xFF));
/* 4697 */           arrayOfByte2[15] = ((byte)(i14 & 0xFF));
/* 4698 */           arrayOfByte2[12] = ((byte)(i13 >> 8 & 0xFF));
/* 4699 */           arrayOfByte2[13] = ((byte)(i13 & 0xFF));
/* 4700 */           arrayOfByte2[10] = ((byte)(i12 >> 8 & 0xFF));
/* 4701 */           arrayOfByte2[11] = ((byte)(i12 & 0xFF));
/* 4702 */           arrayOfByte2[8] = ((byte)(i11 >> 8 & 0xFF));
/* 4703 */           arrayOfByte2[9] = ((byte)(i11 & 0xFF));
/* 4704 */           arrayOfByte2[6] = ((byte)(i10 >> 8 & 0xFF));
/* 4705 */           arrayOfByte2[7] = ((byte)(i10 & 0xFF));
/* 4706 */           arrayOfByte2[4] = ((byte)(i9 >> 8 & 0xFF));
/* 4707 */           arrayOfByte2[5] = ((byte)(i9 & 0xFF));
/* 4708 */           arrayOfByte2[2] = ((byte)(i8 >> 8 & 0xFF));
/* 4709 */           arrayOfByte2[3] = ((byte)(i8 & 0xFF));
/* 4710 */           arrayOfByte2[0] = i38;
/* 4711 */           arrayOfByte2[1] = ((byte)(i7 & 0xFF));
/*      */         }
/*      */         
/* 4714 */         break;
/*      */       
/*      */       case 10: 
/* 4717 */         i38 = (byte)(i8 >> 8 & 0xFF);
/*      */         
/* 4719 */         if (i38 == 0)
/*      */         {
/* 4721 */           i29 = 33;
/* 4722 */           arrayOfByte2 = new byte[i29];
/* 4723 */           arrayOfByte2[31] = ((byte)(i24 >> 8 & 0xFF));
/* 4724 */           arrayOfByte2[32] = ((byte)(i24 & 0xFF));
/* 4725 */           arrayOfByte2[29] = ((byte)(i23 >> 8 & 0xFF));
/* 4726 */           arrayOfByte2[30] = ((byte)(i23 & 0xFF));
/* 4727 */           arrayOfByte2[27] = ((byte)(i22 >> 8 & 0xFF));
/* 4728 */           arrayOfByte2[28] = ((byte)(i22 & 0xFF));
/* 4729 */           arrayOfByte2[25] = ((byte)(i21 >> 8 & 0xFF));
/* 4730 */           arrayOfByte2[26] = ((byte)(i21 & 0xFF));
/* 4731 */           arrayOfByte2[23] = ((byte)(i20 >> 8 & 0xFF));
/* 4732 */           arrayOfByte2[24] = ((byte)(i20 & 0xFF));
/* 4733 */           arrayOfByte2[21] = ((byte)(i19 >> 8 & 0xFF));
/* 4734 */           arrayOfByte2[22] = ((byte)(i19 & 0xFF));
/* 4735 */           arrayOfByte2[19] = ((byte)(i18 >> 8 & 0xFF));
/* 4736 */           arrayOfByte2[20] = ((byte)(i18 & 0xFF));
/* 4737 */           arrayOfByte2[17] = ((byte)(i17 >> 8 & 0xFF));
/* 4738 */           arrayOfByte2[18] = ((byte)(i17 & 0xFF));
/* 4739 */           arrayOfByte2[15] = ((byte)(i16 >> 8 & 0xFF));
/* 4740 */           arrayOfByte2[16] = ((byte)(i16 & 0xFF));
/* 4741 */           arrayOfByte2[13] = ((byte)(i15 >> 8 & 0xFF));
/* 4742 */           arrayOfByte2[14] = ((byte)(i15 & 0xFF));
/* 4743 */           arrayOfByte2[11] = ((byte)(i14 >> 8 & 0xFF));
/* 4744 */           arrayOfByte2[12] = ((byte)(i14 & 0xFF));
/* 4745 */           arrayOfByte2[9] = ((byte)(i13 >> 8 & 0xFF));
/* 4746 */           arrayOfByte2[10] = ((byte)(i13 & 0xFF));
/* 4747 */           arrayOfByte2[7] = ((byte)(i12 >> 8 & 0xFF));
/* 4748 */           arrayOfByte2[8] = ((byte)(i12 & 0xFF));
/* 4749 */           arrayOfByte2[5] = ((byte)(i11 >> 8 & 0xFF));
/* 4750 */           arrayOfByte2[6] = ((byte)(i11 & 0xFF));
/* 4751 */           arrayOfByte2[3] = ((byte)(i10 >> 8 & 0xFF));
/* 4752 */           arrayOfByte2[4] = ((byte)(i10 & 0xFF));
/* 4753 */           arrayOfByte2[1] = ((byte)(i9 >> 8 & 0xFF));
/* 4754 */           arrayOfByte2[2] = ((byte)(i9 & 0xFF));
/* 4755 */           arrayOfByte2[0] = ((byte)(i8 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4759 */           i29 = 34;
/* 4760 */           arrayOfByte2 = new byte[i29];
/* 4761 */           arrayOfByte2[32] = ((byte)(i24 >> 8 & 0xFF));
/* 4762 */           arrayOfByte2[33] = ((byte)(i24 & 0xFF));
/* 4763 */           arrayOfByte2[30] = ((byte)(i23 >> 8 & 0xFF));
/* 4764 */           arrayOfByte2[31] = ((byte)(i23 & 0xFF));
/* 4765 */           arrayOfByte2[28] = ((byte)(i22 >> 8 & 0xFF));
/* 4766 */           arrayOfByte2[29] = ((byte)(i22 & 0xFF));
/* 4767 */           arrayOfByte2[26] = ((byte)(i21 >> 8 & 0xFF));
/* 4768 */           arrayOfByte2[27] = ((byte)(i21 & 0xFF));
/* 4769 */           arrayOfByte2[24] = ((byte)(i20 >> 8 & 0xFF));
/* 4770 */           arrayOfByte2[25] = ((byte)(i20 & 0xFF));
/* 4771 */           arrayOfByte2[22] = ((byte)(i19 >> 8 & 0xFF));
/* 4772 */           arrayOfByte2[23] = ((byte)(i19 & 0xFF));
/* 4773 */           arrayOfByte2[20] = ((byte)(i18 >> 8 & 0xFF));
/* 4774 */           arrayOfByte2[21] = ((byte)(i18 & 0xFF));
/* 4775 */           arrayOfByte2[18] = ((byte)(i17 >> 8 & 0xFF));
/* 4776 */           arrayOfByte2[19] = ((byte)(i17 & 0xFF));
/* 4777 */           arrayOfByte2[16] = ((byte)(i16 >> 8 & 0xFF));
/* 4778 */           arrayOfByte2[17] = ((byte)(i16 & 0xFF));
/* 4779 */           arrayOfByte2[14] = ((byte)(i15 >> 8 & 0xFF));
/* 4780 */           arrayOfByte2[15] = ((byte)(i15 & 0xFF));
/* 4781 */           arrayOfByte2[12] = ((byte)(i14 >> 8 & 0xFF));
/* 4782 */           arrayOfByte2[13] = ((byte)(i14 & 0xFF));
/* 4783 */           arrayOfByte2[10] = ((byte)(i13 >> 8 & 0xFF));
/* 4784 */           arrayOfByte2[11] = ((byte)(i13 & 0xFF));
/* 4785 */           arrayOfByte2[8] = ((byte)(i12 >> 8 & 0xFF));
/* 4786 */           arrayOfByte2[9] = ((byte)(i12 & 0xFF));
/* 4787 */           arrayOfByte2[6] = ((byte)(i11 >> 8 & 0xFF));
/* 4788 */           arrayOfByte2[7] = ((byte)(i11 & 0xFF));
/* 4789 */           arrayOfByte2[4] = ((byte)(i10 >> 8 & 0xFF));
/* 4790 */           arrayOfByte2[5] = ((byte)(i10 & 0xFF));
/* 4791 */           arrayOfByte2[2] = ((byte)(i9 >> 8 & 0xFF));
/* 4792 */           arrayOfByte2[3] = ((byte)(i9 & 0xFF));
/* 4793 */           arrayOfByte2[0] = i38;
/* 4794 */           arrayOfByte2[1] = ((byte)(i8 & 0xFF));
/*      */         }
/*      */         
/* 4797 */         break;
/*      */       
/*      */       case 11: 
/* 4800 */         i38 = (byte)(i9 >> 8 & 0xFF);
/*      */         
/* 4802 */         if (i38 == 0)
/*      */         {
/* 4804 */           i29 = 31;
/* 4805 */           arrayOfByte2 = new byte[i29];
/* 4806 */           arrayOfByte2[29] = ((byte)(i24 >> 8 & 0xFF));
/* 4807 */           arrayOfByte2[30] = ((byte)(i24 & 0xFF));
/* 4808 */           arrayOfByte2[27] = ((byte)(i23 >> 8 & 0xFF));
/* 4809 */           arrayOfByte2[28] = ((byte)(i23 & 0xFF));
/* 4810 */           arrayOfByte2[25] = ((byte)(i22 >> 8 & 0xFF));
/* 4811 */           arrayOfByte2[26] = ((byte)(i22 & 0xFF));
/* 4812 */           arrayOfByte2[23] = ((byte)(i21 >> 8 & 0xFF));
/* 4813 */           arrayOfByte2[24] = ((byte)(i21 & 0xFF));
/* 4814 */           arrayOfByte2[21] = ((byte)(i20 >> 8 & 0xFF));
/* 4815 */           arrayOfByte2[22] = ((byte)(i20 & 0xFF));
/* 4816 */           arrayOfByte2[19] = ((byte)(i19 >> 8 & 0xFF));
/* 4817 */           arrayOfByte2[20] = ((byte)(i19 & 0xFF));
/* 4818 */           arrayOfByte2[17] = ((byte)(i18 >> 8 & 0xFF));
/* 4819 */           arrayOfByte2[18] = ((byte)(i18 & 0xFF));
/* 4820 */           arrayOfByte2[15] = ((byte)(i17 >> 8 & 0xFF));
/* 4821 */           arrayOfByte2[16] = ((byte)(i17 & 0xFF));
/* 4822 */           arrayOfByte2[13] = ((byte)(i16 >> 8 & 0xFF));
/* 4823 */           arrayOfByte2[14] = ((byte)(i16 & 0xFF));
/* 4824 */           arrayOfByte2[11] = ((byte)(i15 >> 8 & 0xFF));
/* 4825 */           arrayOfByte2[12] = ((byte)(i15 & 0xFF));
/* 4826 */           arrayOfByte2[9] = ((byte)(i14 >> 8 & 0xFF));
/* 4827 */           arrayOfByte2[10] = ((byte)(i14 & 0xFF));
/* 4828 */           arrayOfByte2[7] = ((byte)(i13 >> 8 & 0xFF));
/* 4829 */           arrayOfByte2[8] = ((byte)(i13 & 0xFF));
/* 4830 */           arrayOfByte2[5] = ((byte)(i12 >> 8 & 0xFF));
/* 4831 */           arrayOfByte2[6] = ((byte)(i12 & 0xFF));
/* 4832 */           arrayOfByte2[3] = ((byte)(i11 >> 8 & 0xFF));
/* 4833 */           arrayOfByte2[4] = ((byte)(i11 & 0xFF));
/* 4834 */           arrayOfByte2[1] = ((byte)(i10 >> 8 & 0xFF));
/* 4835 */           arrayOfByte2[2] = ((byte)(i10 & 0xFF));
/* 4836 */           arrayOfByte2[0] = ((byte)(i9 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4840 */           i29 = 32;
/* 4841 */           arrayOfByte2 = new byte[i29];
/* 4842 */           arrayOfByte2[30] = ((byte)(i24 >> 8 & 0xFF));
/* 4843 */           arrayOfByte2[31] = ((byte)(i24 & 0xFF));
/* 4844 */           arrayOfByte2[28] = ((byte)(i23 >> 8 & 0xFF));
/* 4845 */           arrayOfByte2[29] = ((byte)(i23 & 0xFF));
/* 4846 */           arrayOfByte2[26] = ((byte)(i22 >> 8 & 0xFF));
/* 4847 */           arrayOfByte2[27] = ((byte)(i22 & 0xFF));
/* 4848 */           arrayOfByte2[24] = ((byte)(i21 >> 8 & 0xFF));
/* 4849 */           arrayOfByte2[25] = ((byte)(i21 & 0xFF));
/* 4850 */           arrayOfByte2[22] = ((byte)(i20 >> 8 & 0xFF));
/* 4851 */           arrayOfByte2[23] = ((byte)(i20 & 0xFF));
/* 4852 */           arrayOfByte2[20] = ((byte)(i19 >> 8 & 0xFF));
/* 4853 */           arrayOfByte2[21] = ((byte)(i19 & 0xFF));
/* 4854 */           arrayOfByte2[18] = ((byte)(i18 >> 8 & 0xFF));
/* 4855 */           arrayOfByte2[19] = ((byte)(i18 & 0xFF));
/* 4856 */           arrayOfByte2[16] = ((byte)(i17 >> 8 & 0xFF));
/* 4857 */           arrayOfByte2[17] = ((byte)(i17 & 0xFF));
/* 4858 */           arrayOfByte2[14] = ((byte)(i16 >> 8 & 0xFF));
/* 4859 */           arrayOfByte2[15] = ((byte)(i16 & 0xFF));
/* 4860 */           arrayOfByte2[12] = ((byte)(i15 >> 8 & 0xFF));
/* 4861 */           arrayOfByte2[13] = ((byte)(i15 & 0xFF));
/* 4862 */           arrayOfByte2[10] = ((byte)(i14 >> 8 & 0xFF));
/* 4863 */           arrayOfByte2[11] = ((byte)(i14 & 0xFF));
/* 4864 */           arrayOfByte2[8] = ((byte)(i13 >> 8 & 0xFF));
/* 4865 */           arrayOfByte2[9] = ((byte)(i13 & 0xFF));
/* 4866 */           arrayOfByte2[6] = ((byte)(i12 >> 8 & 0xFF));
/* 4867 */           arrayOfByte2[7] = ((byte)(i12 & 0xFF));
/* 4868 */           arrayOfByte2[4] = ((byte)(i11 >> 8 & 0xFF));
/* 4869 */           arrayOfByte2[5] = ((byte)(i11 & 0xFF));
/* 4870 */           arrayOfByte2[2] = ((byte)(i10 >> 8 & 0xFF));
/* 4871 */           arrayOfByte2[3] = ((byte)(i10 & 0xFF));
/* 4872 */           arrayOfByte2[0] = i38;
/* 4873 */           arrayOfByte2[1] = ((byte)(i9 & 0xFF));
/*      */         }
/*      */         
/* 4876 */         break;
/*      */       
/*      */       case 12: 
/* 4879 */         i38 = (byte)(i10 >> 8 & 0xFF);
/*      */         
/* 4881 */         if (i38 == 0)
/*      */         {
/* 4883 */           i29 = 29;
/* 4884 */           arrayOfByte2 = new byte[i29];
/* 4885 */           arrayOfByte2[27] = ((byte)(i24 >> 8 & 0xFF));
/* 4886 */           arrayOfByte2[28] = ((byte)(i24 & 0xFF));
/* 4887 */           arrayOfByte2[25] = ((byte)(i23 >> 8 & 0xFF));
/* 4888 */           arrayOfByte2[26] = ((byte)(i23 & 0xFF));
/* 4889 */           arrayOfByte2[23] = ((byte)(i22 >> 8 & 0xFF));
/* 4890 */           arrayOfByte2[24] = ((byte)(i22 & 0xFF));
/* 4891 */           arrayOfByte2[21] = ((byte)(i21 >> 8 & 0xFF));
/* 4892 */           arrayOfByte2[22] = ((byte)(i21 & 0xFF));
/* 4893 */           arrayOfByte2[19] = ((byte)(i20 >> 8 & 0xFF));
/* 4894 */           arrayOfByte2[20] = ((byte)(i20 & 0xFF));
/* 4895 */           arrayOfByte2[17] = ((byte)(i19 >> 8 & 0xFF));
/* 4896 */           arrayOfByte2[18] = ((byte)(i19 & 0xFF));
/* 4897 */           arrayOfByte2[15] = ((byte)(i18 >> 8 & 0xFF));
/* 4898 */           arrayOfByte2[16] = ((byte)(i18 & 0xFF));
/* 4899 */           arrayOfByte2[13] = ((byte)(i17 >> 8 & 0xFF));
/* 4900 */           arrayOfByte2[14] = ((byte)(i17 & 0xFF));
/* 4901 */           arrayOfByte2[11] = ((byte)(i16 >> 8 & 0xFF));
/* 4902 */           arrayOfByte2[12] = ((byte)(i16 & 0xFF));
/* 4903 */           arrayOfByte2[9] = ((byte)(i15 >> 8 & 0xFF));
/* 4904 */           arrayOfByte2[10] = ((byte)(i15 & 0xFF));
/* 4905 */           arrayOfByte2[7] = ((byte)(i14 >> 8 & 0xFF));
/* 4906 */           arrayOfByte2[8] = ((byte)(i14 & 0xFF));
/* 4907 */           arrayOfByte2[5] = ((byte)(i13 >> 8 & 0xFF));
/* 4908 */           arrayOfByte2[6] = ((byte)(i13 & 0xFF));
/* 4909 */           arrayOfByte2[3] = ((byte)(i12 >> 8 & 0xFF));
/* 4910 */           arrayOfByte2[4] = ((byte)(i12 & 0xFF));
/* 4911 */           arrayOfByte2[1] = ((byte)(i11 >> 8 & 0xFF));
/* 4912 */           arrayOfByte2[2] = ((byte)(i11 & 0xFF));
/* 4913 */           arrayOfByte2[0] = ((byte)(i10 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4917 */           i29 = 30;
/* 4918 */           arrayOfByte2 = new byte[i29];
/* 4919 */           arrayOfByte2[28] = ((byte)(i24 >> 8 & 0xFF));
/* 4920 */           arrayOfByte2[29] = ((byte)(i24 & 0xFF));
/* 4921 */           arrayOfByte2[26] = ((byte)(i23 >> 8 & 0xFF));
/* 4922 */           arrayOfByte2[27] = ((byte)(i23 & 0xFF));
/* 4923 */           arrayOfByte2[24] = ((byte)(i22 >> 8 & 0xFF));
/* 4924 */           arrayOfByte2[25] = ((byte)(i22 & 0xFF));
/* 4925 */           arrayOfByte2[22] = ((byte)(i21 >> 8 & 0xFF));
/* 4926 */           arrayOfByte2[23] = ((byte)(i21 & 0xFF));
/* 4927 */           arrayOfByte2[20] = ((byte)(i20 >> 8 & 0xFF));
/* 4928 */           arrayOfByte2[21] = ((byte)(i20 & 0xFF));
/* 4929 */           arrayOfByte2[18] = ((byte)(i19 >> 8 & 0xFF));
/* 4930 */           arrayOfByte2[19] = ((byte)(i19 & 0xFF));
/* 4931 */           arrayOfByte2[16] = ((byte)(i18 >> 8 & 0xFF));
/* 4932 */           arrayOfByte2[17] = ((byte)(i18 & 0xFF));
/* 4933 */           arrayOfByte2[14] = ((byte)(i17 >> 8 & 0xFF));
/* 4934 */           arrayOfByte2[15] = ((byte)(i17 & 0xFF));
/* 4935 */           arrayOfByte2[12] = ((byte)(i16 >> 8 & 0xFF));
/* 4936 */           arrayOfByte2[13] = ((byte)(i16 & 0xFF));
/* 4937 */           arrayOfByte2[10] = ((byte)(i15 >> 8 & 0xFF));
/* 4938 */           arrayOfByte2[11] = ((byte)(i15 & 0xFF));
/* 4939 */           arrayOfByte2[8] = ((byte)(i14 >> 8 & 0xFF));
/* 4940 */           arrayOfByte2[9] = ((byte)(i14 & 0xFF));
/* 4941 */           arrayOfByte2[6] = ((byte)(i13 >> 8 & 0xFF));
/* 4942 */           arrayOfByte2[7] = ((byte)(i13 & 0xFF));
/* 4943 */           arrayOfByte2[4] = ((byte)(i12 >> 8 & 0xFF));
/* 4944 */           arrayOfByte2[5] = ((byte)(i12 & 0xFF));
/* 4945 */           arrayOfByte2[2] = ((byte)(i11 >> 8 & 0xFF));
/* 4946 */           arrayOfByte2[3] = ((byte)(i11 & 0xFF));
/* 4947 */           arrayOfByte2[0] = i38;
/* 4948 */           arrayOfByte2[1] = ((byte)(i10 & 0xFF));
/*      */         }
/*      */         
/* 4951 */         break;
/*      */       
/*      */       case 13: 
/* 4954 */         i38 = (byte)(i11 >> 8 & 0xFF);
/*      */         
/* 4956 */         if (i38 == 0)
/*      */         {
/* 4958 */           i29 = 27;
/* 4959 */           arrayOfByte2 = new byte[i29];
/* 4960 */           arrayOfByte2[25] = ((byte)(i24 >> 8 & 0xFF));
/* 4961 */           arrayOfByte2[26] = ((byte)(i24 & 0xFF));
/* 4962 */           arrayOfByte2[23] = ((byte)(i23 >> 8 & 0xFF));
/* 4963 */           arrayOfByte2[24] = ((byte)(i23 & 0xFF));
/* 4964 */           arrayOfByte2[21] = ((byte)(i22 >> 8 & 0xFF));
/* 4965 */           arrayOfByte2[22] = ((byte)(i22 & 0xFF));
/* 4966 */           arrayOfByte2[19] = ((byte)(i21 >> 8 & 0xFF));
/* 4967 */           arrayOfByte2[20] = ((byte)(i21 & 0xFF));
/* 4968 */           arrayOfByte2[17] = ((byte)(i20 >> 8 & 0xFF));
/* 4969 */           arrayOfByte2[18] = ((byte)(i20 & 0xFF));
/* 4970 */           arrayOfByte2[15] = ((byte)(i19 >> 8 & 0xFF));
/* 4971 */           arrayOfByte2[16] = ((byte)(i19 & 0xFF));
/* 4972 */           arrayOfByte2[13] = ((byte)(i18 >> 8 & 0xFF));
/* 4973 */           arrayOfByte2[14] = ((byte)(i18 & 0xFF));
/* 4974 */           arrayOfByte2[11] = ((byte)(i17 >> 8 & 0xFF));
/* 4975 */           arrayOfByte2[12] = ((byte)(i17 & 0xFF));
/* 4976 */           arrayOfByte2[9] = ((byte)(i16 >> 8 & 0xFF));
/* 4977 */           arrayOfByte2[10] = ((byte)(i16 & 0xFF));
/* 4978 */           arrayOfByte2[7] = ((byte)(i15 >> 8 & 0xFF));
/* 4979 */           arrayOfByte2[8] = ((byte)(i15 & 0xFF));
/* 4980 */           arrayOfByte2[5] = ((byte)(i14 >> 8 & 0xFF));
/* 4981 */           arrayOfByte2[6] = ((byte)(i14 & 0xFF));
/* 4982 */           arrayOfByte2[3] = ((byte)(i13 >> 8 & 0xFF));
/* 4983 */           arrayOfByte2[4] = ((byte)(i13 & 0xFF));
/* 4984 */           arrayOfByte2[1] = ((byte)(i12 >> 8 & 0xFF));
/* 4985 */           arrayOfByte2[2] = ((byte)(i12 & 0xFF));
/* 4986 */           arrayOfByte2[0] = ((byte)(i11 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 4990 */           i29 = 28;
/* 4991 */           arrayOfByte2 = new byte[i29];
/* 4992 */           arrayOfByte2[26] = ((byte)(i24 >> 8 & 0xFF));
/* 4993 */           arrayOfByte2[27] = ((byte)(i24 & 0xFF));
/* 4994 */           arrayOfByte2[24] = ((byte)(i23 >> 8 & 0xFF));
/* 4995 */           arrayOfByte2[25] = ((byte)(i23 & 0xFF));
/* 4996 */           arrayOfByte2[22] = ((byte)(i22 >> 8 & 0xFF));
/* 4997 */           arrayOfByte2[23] = ((byte)(i22 & 0xFF));
/* 4998 */           arrayOfByte2[20] = ((byte)(i21 >> 8 & 0xFF));
/* 4999 */           arrayOfByte2[21] = ((byte)(i21 & 0xFF));
/* 5000 */           arrayOfByte2[18] = ((byte)(i20 >> 8 & 0xFF));
/* 5001 */           arrayOfByte2[19] = ((byte)(i20 & 0xFF));
/* 5002 */           arrayOfByte2[16] = ((byte)(i19 >> 8 & 0xFF));
/* 5003 */           arrayOfByte2[17] = ((byte)(i19 & 0xFF));
/* 5004 */           arrayOfByte2[14] = ((byte)(i18 >> 8 & 0xFF));
/* 5005 */           arrayOfByte2[15] = ((byte)(i18 & 0xFF));
/* 5006 */           arrayOfByte2[12] = ((byte)(i17 >> 8 & 0xFF));
/* 5007 */           arrayOfByte2[13] = ((byte)(i17 & 0xFF));
/* 5008 */           arrayOfByte2[10] = ((byte)(i16 >> 8 & 0xFF));
/* 5009 */           arrayOfByte2[11] = ((byte)(i16 & 0xFF));
/* 5010 */           arrayOfByte2[8] = ((byte)(i15 >> 8 & 0xFF));
/* 5011 */           arrayOfByte2[9] = ((byte)(i15 & 0xFF));
/* 5012 */           arrayOfByte2[6] = ((byte)(i14 >> 8 & 0xFF));
/* 5013 */           arrayOfByte2[7] = ((byte)(i14 & 0xFF));
/* 5014 */           arrayOfByte2[4] = ((byte)(i13 >> 8 & 0xFF));
/* 5015 */           arrayOfByte2[5] = ((byte)(i13 & 0xFF));
/* 5016 */           arrayOfByte2[2] = ((byte)(i12 >> 8 & 0xFF));
/* 5017 */           arrayOfByte2[3] = ((byte)(i12 & 0xFF));
/* 5018 */           arrayOfByte2[0] = i38;
/* 5019 */           arrayOfByte2[1] = ((byte)(i11 & 0xFF));
/*      */         }
/*      */         
/* 5022 */         break;
/*      */       
/*      */       case 14: 
/* 5025 */         i38 = (byte)(i12 >> 8 & 0xFF);
/*      */         
/* 5027 */         if (i38 == 0)
/*      */         {
/* 5029 */           i29 = 25;
/* 5030 */           arrayOfByte2 = new byte[i29];
/* 5031 */           arrayOfByte2[23] = ((byte)(i24 >> 8 & 0xFF));
/* 5032 */           arrayOfByte2[24] = ((byte)(i24 & 0xFF));
/* 5033 */           arrayOfByte2[21] = ((byte)(i23 >> 8 & 0xFF));
/* 5034 */           arrayOfByte2[22] = ((byte)(i23 & 0xFF));
/* 5035 */           arrayOfByte2[19] = ((byte)(i22 >> 8 & 0xFF));
/* 5036 */           arrayOfByte2[20] = ((byte)(i22 & 0xFF));
/* 5037 */           arrayOfByte2[17] = ((byte)(i21 >> 8 & 0xFF));
/* 5038 */           arrayOfByte2[18] = ((byte)(i21 & 0xFF));
/* 5039 */           arrayOfByte2[15] = ((byte)(i20 >> 8 & 0xFF));
/* 5040 */           arrayOfByte2[16] = ((byte)(i20 & 0xFF));
/* 5041 */           arrayOfByte2[13] = ((byte)(i19 >> 8 & 0xFF));
/* 5042 */           arrayOfByte2[14] = ((byte)(i19 & 0xFF));
/* 5043 */           arrayOfByte2[11] = ((byte)(i18 >> 8 & 0xFF));
/* 5044 */           arrayOfByte2[12] = ((byte)(i18 & 0xFF));
/* 5045 */           arrayOfByte2[9] = ((byte)(i17 >> 8 & 0xFF));
/* 5046 */           arrayOfByte2[10] = ((byte)(i17 & 0xFF));
/* 5047 */           arrayOfByte2[7] = ((byte)(i16 >> 8 & 0xFF));
/* 5048 */           arrayOfByte2[8] = ((byte)(i16 & 0xFF));
/* 5049 */           arrayOfByte2[5] = ((byte)(i15 >> 8 & 0xFF));
/* 5050 */           arrayOfByte2[6] = ((byte)(i15 & 0xFF));
/* 5051 */           arrayOfByte2[3] = ((byte)(i14 >> 8 & 0xFF));
/* 5052 */           arrayOfByte2[4] = ((byte)(i14 & 0xFF));
/* 5053 */           arrayOfByte2[1] = ((byte)(i13 >> 8 & 0xFF));
/* 5054 */           arrayOfByte2[2] = ((byte)(i13 & 0xFF));
/* 5055 */           arrayOfByte2[0] = ((byte)(i12 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5059 */           i29 = 26;
/* 5060 */           arrayOfByte2 = new byte[i29];
/* 5061 */           arrayOfByte2[24] = ((byte)(i24 >> 8 & 0xFF));
/* 5062 */           arrayOfByte2[25] = ((byte)(i24 & 0xFF));
/* 5063 */           arrayOfByte2[22] = ((byte)(i23 >> 8 & 0xFF));
/* 5064 */           arrayOfByte2[23] = ((byte)(i23 & 0xFF));
/* 5065 */           arrayOfByte2[20] = ((byte)(i22 >> 8 & 0xFF));
/* 5066 */           arrayOfByte2[21] = ((byte)(i22 & 0xFF));
/* 5067 */           arrayOfByte2[18] = ((byte)(i21 >> 8 & 0xFF));
/* 5068 */           arrayOfByte2[19] = ((byte)(i21 & 0xFF));
/* 5069 */           arrayOfByte2[16] = ((byte)(i20 >> 8 & 0xFF));
/* 5070 */           arrayOfByte2[17] = ((byte)(i20 & 0xFF));
/* 5071 */           arrayOfByte2[14] = ((byte)(i19 >> 8 & 0xFF));
/* 5072 */           arrayOfByte2[15] = ((byte)(i19 & 0xFF));
/* 5073 */           arrayOfByte2[12] = ((byte)(i18 >> 8 & 0xFF));
/* 5074 */           arrayOfByte2[13] = ((byte)(i18 & 0xFF));
/* 5075 */           arrayOfByte2[10] = ((byte)(i17 >> 8 & 0xFF));
/* 5076 */           arrayOfByte2[11] = ((byte)(i17 & 0xFF));
/* 5077 */           arrayOfByte2[8] = ((byte)(i16 >> 8 & 0xFF));
/* 5078 */           arrayOfByte2[9] = ((byte)(i16 & 0xFF));
/* 5079 */           arrayOfByte2[6] = ((byte)(i15 >> 8 & 0xFF));
/* 5080 */           arrayOfByte2[7] = ((byte)(i15 & 0xFF));
/* 5081 */           arrayOfByte2[4] = ((byte)(i14 >> 8 & 0xFF));
/* 5082 */           arrayOfByte2[5] = ((byte)(i14 & 0xFF));
/* 5083 */           arrayOfByte2[2] = ((byte)(i13 >> 8 & 0xFF));
/* 5084 */           arrayOfByte2[3] = ((byte)(i13 & 0xFF));
/* 5085 */           arrayOfByte2[0] = i38;
/* 5086 */           arrayOfByte2[1] = ((byte)(i12 & 0xFF));
/*      */         }
/*      */         
/* 5089 */         break;
/*      */       
/*      */       case 15: 
/* 5092 */         i38 = (byte)(i13 >> 8 & 0xFF);
/*      */         
/* 5094 */         if (i38 == 0)
/*      */         {
/* 5096 */           i29 = 23;
/* 5097 */           arrayOfByte2 = new byte[i29];
/* 5098 */           arrayOfByte2[21] = ((byte)(i24 >> 8 & 0xFF));
/* 5099 */           arrayOfByte2[22] = ((byte)(i24 & 0xFF));
/* 5100 */           arrayOfByte2[19] = ((byte)(i23 >> 8 & 0xFF));
/* 5101 */           arrayOfByte2[20] = ((byte)(i23 & 0xFF));
/* 5102 */           arrayOfByte2[17] = ((byte)(i22 >> 8 & 0xFF));
/* 5103 */           arrayOfByte2[18] = ((byte)(i22 & 0xFF));
/* 5104 */           arrayOfByte2[15] = ((byte)(i21 >> 8 & 0xFF));
/* 5105 */           arrayOfByte2[16] = ((byte)(i21 & 0xFF));
/* 5106 */           arrayOfByte2[13] = ((byte)(i20 >> 8 & 0xFF));
/* 5107 */           arrayOfByte2[14] = ((byte)(i20 & 0xFF));
/* 5108 */           arrayOfByte2[11] = ((byte)(i19 >> 8 & 0xFF));
/* 5109 */           arrayOfByte2[12] = ((byte)(i19 & 0xFF));
/* 5110 */           arrayOfByte2[9] = ((byte)(i18 >> 8 & 0xFF));
/* 5111 */           arrayOfByte2[10] = ((byte)(i18 & 0xFF));
/* 5112 */           arrayOfByte2[7] = ((byte)(i17 >> 8 & 0xFF));
/* 5113 */           arrayOfByte2[8] = ((byte)(i17 & 0xFF));
/* 5114 */           arrayOfByte2[5] = ((byte)(i16 >> 8 & 0xFF));
/* 5115 */           arrayOfByte2[6] = ((byte)(i16 & 0xFF));
/* 5116 */           arrayOfByte2[3] = ((byte)(i15 >> 8 & 0xFF));
/* 5117 */           arrayOfByte2[4] = ((byte)(i15 & 0xFF));
/* 5118 */           arrayOfByte2[1] = ((byte)(i14 >> 8 & 0xFF));
/* 5119 */           arrayOfByte2[2] = ((byte)(i14 & 0xFF));
/* 5120 */           arrayOfByte2[0] = ((byte)(i13 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5124 */           i29 = 24;
/* 5125 */           arrayOfByte2 = new byte[i29];
/* 5126 */           arrayOfByte2[22] = ((byte)(i24 >> 8 & 0xFF));
/* 5127 */           arrayOfByte2[23] = ((byte)(i24 & 0xFF));
/* 5128 */           arrayOfByte2[20] = ((byte)(i23 >> 8 & 0xFF));
/* 5129 */           arrayOfByte2[21] = ((byte)(i23 & 0xFF));
/* 5130 */           arrayOfByte2[18] = ((byte)(i22 >> 8 & 0xFF));
/* 5131 */           arrayOfByte2[19] = ((byte)(i22 & 0xFF));
/* 5132 */           arrayOfByte2[16] = ((byte)(i21 >> 8 & 0xFF));
/* 5133 */           arrayOfByte2[17] = ((byte)(i21 & 0xFF));
/* 5134 */           arrayOfByte2[14] = ((byte)(i20 >> 8 & 0xFF));
/* 5135 */           arrayOfByte2[15] = ((byte)(i20 & 0xFF));
/* 5136 */           arrayOfByte2[12] = ((byte)(i19 >> 8 & 0xFF));
/* 5137 */           arrayOfByte2[13] = ((byte)(i19 & 0xFF));
/* 5138 */           arrayOfByte2[10] = ((byte)(i18 >> 8 & 0xFF));
/* 5139 */           arrayOfByte2[11] = ((byte)(i18 & 0xFF));
/* 5140 */           arrayOfByte2[8] = ((byte)(i17 >> 8 & 0xFF));
/* 5141 */           arrayOfByte2[9] = ((byte)(i17 & 0xFF));
/* 5142 */           arrayOfByte2[6] = ((byte)(i16 >> 8 & 0xFF));
/* 5143 */           arrayOfByte2[7] = ((byte)(i16 & 0xFF));
/* 5144 */           arrayOfByte2[4] = ((byte)(i15 >> 8 & 0xFF));
/* 5145 */           arrayOfByte2[5] = ((byte)(i15 & 0xFF));
/* 5146 */           arrayOfByte2[2] = ((byte)(i14 >> 8 & 0xFF));
/* 5147 */           arrayOfByte2[3] = ((byte)(i14 & 0xFF));
/* 5148 */           arrayOfByte2[0] = i38;
/* 5149 */           arrayOfByte2[1] = ((byte)(i13 & 0xFF));
/*      */         }
/*      */         
/* 5152 */         break;
/*      */       
/*      */       case 16: 
/* 5155 */         i38 = (byte)(i14 >> 8 & 0xFF);
/*      */         
/* 5157 */         if (i38 == 0)
/*      */         {
/* 5159 */           i29 = 21;
/* 5160 */           arrayOfByte2 = new byte[i29];
/* 5161 */           arrayOfByte2[19] = ((byte)(i24 >> 8 & 0xFF));
/* 5162 */           arrayOfByte2[20] = ((byte)(i24 & 0xFF));
/* 5163 */           arrayOfByte2[17] = ((byte)(i23 >> 8 & 0xFF));
/* 5164 */           arrayOfByte2[18] = ((byte)(i23 & 0xFF));
/* 5165 */           arrayOfByte2[15] = ((byte)(i22 >> 8 & 0xFF));
/* 5166 */           arrayOfByte2[16] = ((byte)(i22 & 0xFF));
/* 5167 */           arrayOfByte2[13] = ((byte)(i21 >> 8 & 0xFF));
/* 5168 */           arrayOfByte2[14] = ((byte)(i21 & 0xFF));
/* 5169 */           arrayOfByte2[11] = ((byte)(i20 >> 8 & 0xFF));
/* 5170 */           arrayOfByte2[12] = ((byte)(i20 & 0xFF));
/* 5171 */           arrayOfByte2[9] = ((byte)(i19 >> 8 & 0xFF));
/* 5172 */           arrayOfByte2[10] = ((byte)(i19 & 0xFF));
/* 5173 */           arrayOfByte2[7] = ((byte)(i18 >> 8 & 0xFF));
/* 5174 */           arrayOfByte2[8] = ((byte)(i18 & 0xFF));
/* 5175 */           arrayOfByte2[5] = ((byte)(i17 >> 8 & 0xFF));
/* 5176 */           arrayOfByte2[6] = ((byte)(i17 & 0xFF));
/* 5177 */           arrayOfByte2[3] = ((byte)(i16 >> 8 & 0xFF));
/* 5178 */           arrayOfByte2[4] = ((byte)(i16 & 0xFF));
/* 5179 */           arrayOfByte2[1] = ((byte)(i15 >> 8 & 0xFF));
/* 5180 */           arrayOfByte2[2] = ((byte)(i15 & 0xFF));
/* 5181 */           arrayOfByte2[0] = ((byte)(i14 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5185 */           i29 = 22;
/* 5186 */           arrayOfByte2 = new byte[i29];
/* 5187 */           arrayOfByte2[20] = ((byte)(i24 >> 8 & 0xFF));
/* 5188 */           arrayOfByte2[21] = ((byte)(i24 & 0xFF));
/* 5189 */           arrayOfByte2[18] = ((byte)(i23 >> 8 & 0xFF));
/* 5190 */           arrayOfByte2[19] = ((byte)(i23 & 0xFF));
/* 5191 */           arrayOfByte2[16] = ((byte)(i22 >> 8 & 0xFF));
/* 5192 */           arrayOfByte2[17] = ((byte)(i22 & 0xFF));
/* 5193 */           arrayOfByte2[14] = ((byte)(i21 >> 8 & 0xFF));
/* 5194 */           arrayOfByte2[15] = ((byte)(i21 & 0xFF));
/* 5195 */           arrayOfByte2[12] = ((byte)(i20 >> 8 & 0xFF));
/* 5196 */           arrayOfByte2[13] = ((byte)(i20 & 0xFF));
/* 5197 */           arrayOfByte2[10] = ((byte)(i19 >> 8 & 0xFF));
/* 5198 */           arrayOfByte2[11] = ((byte)(i19 & 0xFF));
/* 5199 */           arrayOfByte2[8] = ((byte)(i18 >> 8 & 0xFF));
/* 5200 */           arrayOfByte2[9] = ((byte)(i18 & 0xFF));
/* 5201 */           arrayOfByte2[6] = ((byte)(i17 >> 8 & 0xFF));
/* 5202 */           arrayOfByte2[7] = ((byte)(i17 & 0xFF));
/* 5203 */           arrayOfByte2[4] = ((byte)(i16 >> 8 & 0xFF));
/* 5204 */           arrayOfByte2[5] = ((byte)(i16 & 0xFF));
/* 5205 */           arrayOfByte2[2] = ((byte)(i15 >> 8 & 0xFF));
/* 5206 */           arrayOfByte2[3] = ((byte)(i15 & 0xFF));
/* 5207 */           arrayOfByte2[0] = i38;
/* 5208 */           arrayOfByte2[1] = ((byte)(i14 & 0xFF));
/*      */         }
/*      */         
/* 5211 */         break;
/*      */       
/*      */       case 17: 
/* 5214 */         i38 = (byte)(i15 >> 8 & 0xFF);
/*      */         
/* 5216 */         if (i38 == 0)
/*      */         {
/* 5218 */           i29 = 19;
/* 5219 */           arrayOfByte2 = new byte[i29];
/* 5220 */           arrayOfByte2[17] = ((byte)(i24 >> 8 & 0xFF));
/* 5221 */           arrayOfByte2[18] = ((byte)(i24 & 0xFF));
/* 5222 */           arrayOfByte2[15] = ((byte)(i23 >> 8 & 0xFF));
/* 5223 */           arrayOfByte2[16] = ((byte)(i23 & 0xFF));
/* 5224 */           arrayOfByte2[13] = ((byte)(i22 >> 8 & 0xFF));
/* 5225 */           arrayOfByte2[14] = ((byte)(i22 & 0xFF));
/* 5226 */           arrayOfByte2[11] = ((byte)(i21 >> 8 & 0xFF));
/* 5227 */           arrayOfByte2[12] = ((byte)(i21 & 0xFF));
/* 5228 */           arrayOfByte2[9] = ((byte)(i20 >> 8 & 0xFF));
/* 5229 */           arrayOfByte2[10] = ((byte)(i20 & 0xFF));
/* 5230 */           arrayOfByte2[7] = ((byte)(i19 >> 8 & 0xFF));
/* 5231 */           arrayOfByte2[8] = ((byte)(i19 & 0xFF));
/* 5232 */           arrayOfByte2[5] = ((byte)(i18 >> 8 & 0xFF));
/* 5233 */           arrayOfByte2[6] = ((byte)(i18 & 0xFF));
/* 5234 */           arrayOfByte2[3] = ((byte)(i17 >> 8 & 0xFF));
/* 5235 */           arrayOfByte2[4] = ((byte)(i17 & 0xFF));
/* 5236 */           arrayOfByte2[1] = ((byte)(i16 >> 8 & 0xFF));
/* 5237 */           arrayOfByte2[2] = ((byte)(i16 & 0xFF));
/* 5238 */           arrayOfByte2[0] = ((byte)(i15 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5242 */           i29 = 20;
/* 5243 */           arrayOfByte2 = new byte[i29];
/* 5244 */           arrayOfByte2[18] = ((byte)(i24 >> 8 & 0xFF));
/* 5245 */           arrayOfByte2[19] = ((byte)(i24 & 0xFF));
/* 5246 */           arrayOfByte2[16] = ((byte)(i23 >> 8 & 0xFF));
/* 5247 */           arrayOfByte2[17] = ((byte)(i23 & 0xFF));
/* 5248 */           arrayOfByte2[14] = ((byte)(i22 >> 8 & 0xFF));
/* 5249 */           arrayOfByte2[15] = ((byte)(i22 & 0xFF));
/* 5250 */           arrayOfByte2[12] = ((byte)(i21 >> 8 & 0xFF));
/* 5251 */           arrayOfByte2[13] = ((byte)(i21 & 0xFF));
/* 5252 */           arrayOfByte2[10] = ((byte)(i20 >> 8 & 0xFF));
/* 5253 */           arrayOfByte2[11] = ((byte)(i20 & 0xFF));
/* 5254 */           arrayOfByte2[8] = ((byte)(i19 >> 8 & 0xFF));
/* 5255 */           arrayOfByte2[9] = ((byte)(i19 & 0xFF));
/* 5256 */           arrayOfByte2[6] = ((byte)(i18 >> 8 & 0xFF));
/* 5257 */           arrayOfByte2[7] = ((byte)(i18 & 0xFF));
/* 5258 */           arrayOfByte2[4] = ((byte)(i17 >> 8 & 0xFF));
/* 5259 */           arrayOfByte2[5] = ((byte)(i17 & 0xFF));
/* 5260 */           arrayOfByte2[2] = ((byte)(i16 >> 8 & 0xFF));
/* 5261 */           arrayOfByte2[3] = ((byte)(i16 & 0xFF));
/* 5262 */           arrayOfByte2[0] = i38;
/* 5263 */           arrayOfByte2[1] = ((byte)(i15 & 0xFF));
/*      */         }
/*      */         
/* 5266 */         break;
/*      */       
/*      */       case 18: 
/* 5269 */         i38 = (byte)(i16 >> 8 & 0xFF);
/*      */         
/* 5271 */         if (i38 == 0)
/*      */         {
/* 5273 */           i29 = 17;
/* 5274 */           arrayOfByte2 = new byte[i29];
/* 5275 */           arrayOfByte2[15] = ((byte)(i24 >> 8 & 0xFF));
/* 5276 */           arrayOfByte2[16] = ((byte)(i24 & 0xFF));
/* 5277 */           arrayOfByte2[13] = ((byte)(i23 >> 8 & 0xFF));
/* 5278 */           arrayOfByte2[14] = ((byte)(i23 & 0xFF));
/* 5279 */           arrayOfByte2[11] = ((byte)(i22 >> 8 & 0xFF));
/* 5280 */           arrayOfByte2[12] = ((byte)(i22 & 0xFF));
/* 5281 */           arrayOfByte2[9] = ((byte)(i21 >> 8 & 0xFF));
/* 5282 */           arrayOfByte2[10] = ((byte)(i21 & 0xFF));
/* 5283 */           arrayOfByte2[7] = ((byte)(i20 >> 8 & 0xFF));
/* 5284 */           arrayOfByte2[8] = ((byte)(i20 & 0xFF));
/* 5285 */           arrayOfByte2[5] = ((byte)(i19 >> 8 & 0xFF));
/* 5286 */           arrayOfByte2[6] = ((byte)(i19 & 0xFF));
/* 5287 */           arrayOfByte2[3] = ((byte)(i18 >> 8 & 0xFF));
/* 5288 */           arrayOfByte2[4] = ((byte)(i18 & 0xFF));
/* 5289 */           arrayOfByte2[1] = ((byte)(i17 >> 8 & 0xFF));
/* 5290 */           arrayOfByte2[2] = ((byte)(i17 & 0xFF));
/* 5291 */           arrayOfByte2[0] = ((byte)(i16 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5295 */           i29 = 18;
/* 5296 */           arrayOfByte2 = new byte[i29];
/* 5297 */           arrayOfByte2[16] = ((byte)(i24 >> 8 & 0xFF));
/* 5298 */           arrayOfByte2[17] = ((byte)(i24 & 0xFF));
/* 5299 */           arrayOfByte2[14] = ((byte)(i23 >> 8 & 0xFF));
/* 5300 */           arrayOfByte2[15] = ((byte)(i23 & 0xFF));
/* 5301 */           arrayOfByte2[12] = ((byte)(i22 >> 8 & 0xFF));
/* 5302 */           arrayOfByte2[13] = ((byte)(i22 & 0xFF));
/* 5303 */           arrayOfByte2[10] = ((byte)(i21 >> 8 & 0xFF));
/* 5304 */           arrayOfByte2[11] = ((byte)(i21 & 0xFF));
/* 5305 */           arrayOfByte2[8] = ((byte)(i20 >> 8 & 0xFF));
/* 5306 */           arrayOfByte2[9] = ((byte)(i20 & 0xFF));
/* 5307 */           arrayOfByte2[6] = ((byte)(i19 >> 8 & 0xFF));
/* 5308 */           arrayOfByte2[7] = ((byte)(i19 & 0xFF));
/* 5309 */           arrayOfByte2[4] = ((byte)(i18 >> 8 & 0xFF));
/* 5310 */           arrayOfByte2[5] = ((byte)(i18 & 0xFF));
/* 5311 */           arrayOfByte2[2] = ((byte)(i17 >> 8 & 0xFF));
/* 5312 */           arrayOfByte2[3] = ((byte)(i17 & 0xFF));
/* 5313 */           arrayOfByte2[0] = i38;
/* 5314 */           arrayOfByte2[1] = ((byte)(i16 & 0xFF));
/*      */         }
/*      */         
/* 5317 */         break;
/*      */       
/*      */       case 19: 
/* 5320 */         i38 = (byte)(i17 >> 8 & 0xFF);
/*      */         
/* 5322 */         if (i38 == 0)
/*      */         {
/* 5324 */           i29 = 15;
/* 5325 */           arrayOfByte2 = new byte[i29];
/* 5326 */           arrayOfByte2[13] = ((byte)(i24 >> 8 & 0xFF));
/* 5327 */           arrayOfByte2[14] = ((byte)(i24 & 0xFF));
/* 5328 */           arrayOfByte2[11] = ((byte)(i23 >> 8 & 0xFF));
/* 5329 */           arrayOfByte2[12] = ((byte)(i23 & 0xFF));
/* 5330 */           arrayOfByte2[9] = ((byte)(i22 >> 8 & 0xFF));
/* 5331 */           arrayOfByte2[10] = ((byte)(i22 & 0xFF));
/* 5332 */           arrayOfByte2[7] = ((byte)(i21 >> 8 & 0xFF));
/* 5333 */           arrayOfByte2[8] = ((byte)(i21 & 0xFF));
/* 5334 */           arrayOfByte2[5] = ((byte)(i20 >> 8 & 0xFF));
/* 5335 */           arrayOfByte2[6] = ((byte)(i20 & 0xFF));
/* 5336 */           arrayOfByte2[3] = ((byte)(i19 >> 8 & 0xFF));
/* 5337 */           arrayOfByte2[4] = ((byte)(i19 & 0xFF));
/* 5338 */           arrayOfByte2[1] = ((byte)(i18 >> 8 & 0xFF));
/* 5339 */           arrayOfByte2[2] = ((byte)(i18 & 0xFF));
/* 5340 */           arrayOfByte2[0] = ((byte)(i17 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5344 */           i29 = 16;
/* 5345 */           arrayOfByte2 = new byte[i29];
/* 5346 */           arrayOfByte2[14] = ((byte)(i24 >> 8 & 0xFF));
/* 5347 */           arrayOfByte2[15] = ((byte)(i24 & 0xFF));
/* 5348 */           arrayOfByte2[12] = ((byte)(i23 >> 8 & 0xFF));
/* 5349 */           arrayOfByte2[13] = ((byte)(i23 & 0xFF));
/* 5350 */           arrayOfByte2[10] = ((byte)(i22 >> 8 & 0xFF));
/* 5351 */           arrayOfByte2[11] = ((byte)(i22 & 0xFF));
/* 5352 */           arrayOfByte2[8] = ((byte)(i21 >> 8 & 0xFF));
/* 5353 */           arrayOfByte2[9] = ((byte)(i21 & 0xFF));
/* 5354 */           arrayOfByte2[6] = ((byte)(i20 >> 8 & 0xFF));
/* 5355 */           arrayOfByte2[7] = ((byte)(i20 & 0xFF));
/* 5356 */           arrayOfByte2[4] = ((byte)(i19 >> 8 & 0xFF));
/* 5357 */           arrayOfByte2[5] = ((byte)(i19 & 0xFF));
/* 5358 */           arrayOfByte2[2] = ((byte)(i18 >> 8 & 0xFF));
/* 5359 */           arrayOfByte2[3] = ((byte)(i18 & 0xFF));
/* 5360 */           arrayOfByte2[0] = i38;
/* 5361 */           arrayOfByte2[1] = ((byte)(i17 & 0xFF));
/*      */         }
/*      */         
/* 5364 */         break;
/*      */       
/*      */       case 20: 
/* 5367 */         i38 = (byte)(i18 >> 8 & 0xFF);
/*      */         
/* 5369 */         if (i38 == 0)
/*      */         {
/* 5371 */           i29 = 13;
/* 5372 */           arrayOfByte2 = new byte[i29];
/* 5373 */           arrayOfByte2[11] = ((byte)(i24 >> 8 & 0xFF));
/* 5374 */           arrayOfByte2[12] = ((byte)(i24 & 0xFF));
/* 5375 */           arrayOfByte2[9] = ((byte)(i23 >> 8 & 0xFF));
/* 5376 */           arrayOfByte2[10] = ((byte)(i23 & 0xFF));
/* 5377 */           arrayOfByte2[7] = ((byte)(i22 >> 8 & 0xFF));
/* 5378 */           arrayOfByte2[8] = ((byte)(i22 & 0xFF));
/* 5379 */           arrayOfByte2[5] = ((byte)(i21 >> 8 & 0xFF));
/* 5380 */           arrayOfByte2[6] = ((byte)(i21 & 0xFF));
/* 5381 */           arrayOfByte2[3] = ((byte)(i20 >> 8 & 0xFF));
/* 5382 */           arrayOfByte2[4] = ((byte)(i20 & 0xFF));
/* 5383 */           arrayOfByte2[1] = ((byte)(i19 >> 8 & 0xFF));
/* 5384 */           arrayOfByte2[2] = ((byte)(i19 & 0xFF));
/* 5385 */           arrayOfByte2[0] = ((byte)(i18 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5389 */           i29 = 14;
/* 5390 */           arrayOfByte2 = new byte[i29];
/* 5391 */           arrayOfByte2[12] = ((byte)(i24 >> 8 & 0xFF));
/* 5392 */           arrayOfByte2[13] = ((byte)(i24 & 0xFF));
/* 5393 */           arrayOfByte2[10] = ((byte)(i23 >> 8 & 0xFF));
/* 5394 */           arrayOfByte2[11] = ((byte)(i23 & 0xFF));
/* 5395 */           arrayOfByte2[8] = ((byte)(i22 >> 8 & 0xFF));
/* 5396 */           arrayOfByte2[9] = ((byte)(i22 & 0xFF));
/* 5397 */           arrayOfByte2[6] = ((byte)(i21 >> 8 & 0xFF));
/* 5398 */           arrayOfByte2[7] = ((byte)(i21 & 0xFF));
/* 5399 */           arrayOfByte2[4] = ((byte)(i20 >> 8 & 0xFF));
/* 5400 */           arrayOfByte2[5] = ((byte)(i20 & 0xFF));
/* 5401 */           arrayOfByte2[2] = ((byte)(i19 >> 8 & 0xFF));
/* 5402 */           arrayOfByte2[3] = ((byte)(i19 & 0xFF));
/* 5403 */           arrayOfByte2[0] = i38;
/* 5404 */           arrayOfByte2[1] = ((byte)(i18 & 0xFF));
/*      */         }
/*      */         
/* 5407 */         break;
/*      */       
/*      */       case 21: 
/* 5410 */         i38 = (byte)(i19 >> 8 & 0xFF);
/*      */         
/* 5412 */         if (i38 == 0)
/*      */         {
/* 5414 */           i29 = 11;
/* 5415 */           arrayOfByte2 = new byte[i29];
/* 5416 */           arrayOfByte2[9] = ((byte)(i24 >> 8 & 0xFF));
/* 5417 */           arrayOfByte2[10] = ((byte)(i24 & 0xFF));
/* 5418 */           arrayOfByte2[7] = ((byte)(i23 >> 8 & 0xFF));
/* 5419 */           arrayOfByte2[8] = ((byte)(i23 & 0xFF));
/* 5420 */           arrayOfByte2[5] = ((byte)(i22 >> 8 & 0xFF));
/* 5421 */           arrayOfByte2[6] = ((byte)(i22 & 0xFF));
/* 5422 */           arrayOfByte2[3] = ((byte)(i21 >> 8 & 0xFF));
/* 5423 */           arrayOfByte2[4] = ((byte)(i21 & 0xFF));
/* 5424 */           arrayOfByte2[1] = ((byte)(i20 >> 8 & 0xFF));
/* 5425 */           arrayOfByte2[2] = ((byte)(i20 & 0xFF));
/* 5426 */           arrayOfByte2[0] = ((byte)(i19 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5430 */           i29 = 12;
/* 5431 */           arrayOfByte2 = new byte[i29];
/* 5432 */           arrayOfByte2[10] = ((byte)(i24 >> 8 & 0xFF));
/* 5433 */           arrayOfByte2[11] = ((byte)(i24 & 0xFF));
/* 5434 */           arrayOfByte2[8] = ((byte)(i23 >> 8 & 0xFF));
/* 5435 */           arrayOfByte2[9] = ((byte)(i23 & 0xFF));
/* 5436 */           arrayOfByte2[6] = ((byte)(i22 >> 8 & 0xFF));
/* 5437 */           arrayOfByte2[7] = ((byte)(i22 & 0xFF));
/* 5438 */           arrayOfByte2[4] = ((byte)(i21 >> 8 & 0xFF));
/* 5439 */           arrayOfByte2[5] = ((byte)(i21 & 0xFF));
/* 5440 */           arrayOfByte2[2] = ((byte)(i20 >> 8 & 0xFF));
/* 5441 */           arrayOfByte2[3] = ((byte)(i20 & 0xFF));
/* 5442 */           arrayOfByte2[0] = i38;
/* 5443 */           arrayOfByte2[1] = ((byte)(i19 & 0xFF));
/*      */         }
/*      */         
/* 5446 */         break;
/*      */       
/*      */       case 22: 
/* 5449 */         i38 = (byte)(i20 >> 8 & 0xFF);
/*      */         
/* 5451 */         if (i38 == 0)
/*      */         {
/* 5453 */           i29 = 9;
/* 5454 */           arrayOfByte2 = new byte[i29];
/* 5455 */           arrayOfByte2[7] = ((byte)(i24 >> 8 & 0xFF));
/* 5456 */           arrayOfByte2[8] = ((byte)(i24 & 0xFF));
/* 5457 */           arrayOfByte2[5] = ((byte)(i23 >> 8 & 0xFF));
/* 5458 */           arrayOfByte2[6] = ((byte)(i23 & 0xFF));
/* 5459 */           arrayOfByte2[3] = ((byte)(i22 >> 8 & 0xFF));
/* 5460 */           arrayOfByte2[4] = ((byte)(i22 & 0xFF));
/* 5461 */           arrayOfByte2[1] = ((byte)(i21 >> 8 & 0xFF));
/* 5462 */           arrayOfByte2[2] = ((byte)(i21 & 0xFF));
/* 5463 */           arrayOfByte2[0] = ((byte)(i20 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5467 */           i29 = 10;
/* 5468 */           arrayOfByte2 = new byte[i29];
/* 5469 */           arrayOfByte2[8] = ((byte)(i24 >> 8 & 0xFF));
/* 5470 */           arrayOfByte2[9] = ((byte)(i24 & 0xFF));
/* 5471 */           arrayOfByte2[6] = ((byte)(i23 >> 8 & 0xFF));
/* 5472 */           arrayOfByte2[7] = ((byte)(i23 & 0xFF));
/* 5473 */           arrayOfByte2[4] = ((byte)(i22 >> 8 & 0xFF));
/* 5474 */           arrayOfByte2[5] = ((byte)(i22 & 0xFF));
/* 5475 */           arrayOfByte2[2] = ((byte)(i21 >> 8 & 0xFF));
/* 5476 */           arrayOfByte2[3] = ((byte)(i21 & 0xFF));
/* 5477 */           arrayOfByte2[0] = i38;
/* 5478 */           arrayOfByte2[1] = ((byte)(i20 & 0xFF));
/*      */         }
/*      */         
/* 5481 */         break;
/*      */       
/*      */       case 23: 
/* 5484 */         i38 = (byte)(i21 >> 8 & 0xFF);
/*      */         
/* 5486 */         if (i38 == 0)
/*      */         {
/* 5488 */           i29 = 7;
/* 5489 */           arrayOfByte2 = new byte[i29];
/* 5490 */           arrayOfByte2[5] = ((byte)(i24 >> 8 & 0xFF));
/* 5491 */           arrayOfByte2[6] = ((byte)(i24 & 0xFF));
/* 5492 */           arrayOfByte2[3] = ((byte)(i23 >> 8 & 0xFF));
/* 5493 */           arrayOfByte2[4] = ((byte)(i23 & 0xFF));
/* 5494 */           arrayOfByte2[1] = ((byte)(i22 >> 8 & 0xFF));
/* 5495 */           arrayOfByte2[2] = ((byte)(i22 & 0xFF));
/* 5496 */           arrayOfByte2[0] = ((byte)(i21 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5500 */           i29 = 8;
/* 5501 */           arrayOfByte2 = new byte[i29];
/* 5502 */           arrayOfByte2[6] = ((byte)(i24 >> 8 & 0xFF));
/* 5503 */           arrayOfByte2[7] = ((byte)(i24 & 0xFF));
/* 5504 */           arrayOfByte2[4] = ((byte)(i23 >> 8 & 0xFF));
/* 5505 */           arrayOfByte2[5] = ((byte)(i23 & 0xFF));
/* 5506 */           arrayOfByte2[2] = ((byte)(i22 >> 8 & 0xFF));
/* 5507 */           arrayOfByte2[3] = ((byte)(i22 & 0xFF));
/* 5508 */           arrayOfByte2[0] = i38;
/* 5509 */           arrayOfByte2[1] = ((byte)(i21 & 0xFF));
/*      */         }
/*      */         
/* 5512 */         break;
/*      */       
/*      */       case 24: 
/* 5515 */         i38 = (byte)(i22 >> 8 & 0xFF);
/*      */         
/* 5517 */         if (i38 == 0)
/*      */         {
/* 5519 */           i29 = 5;
/* 5520 */           arrayOfByte2 = new byte[i29];
/* 5521 */           arrayOfByte2[3] = ((byte)(i24 >> 8 & 0xFF));
/* 5522 */           arrayOfByte2[4] = ((byte)(i24 & 0xFF));
/* 5523 */           arrayOfByte2[1] = ((byte)(i23 >> 8 & 0xFF));
/* 5524 */           arrayOfByte2[2] = ((byte)(i23 & 0xFF));
/* 5525 */           arrayOfByte2[0] = ((byte)(i22 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5529 */           i29 = 6;
/* 5530 */           arrayOfByte2 = new byte[i29];
/* 5531 */           arrayOfByte2[4] = ((byte)(i24 >> 8 & 0xFF));
/* 5532 */           arrayOfByte2[5] = ((byte)(i24 & 0xFF));
/* 5533 */           arrayOfByte2[2] = ((byte)(i23 >> 8 & 0xFF));
/* 5534 */           arrayOfByte2[3] = ((byte)(i23 & 0xFF));
/* 5535 */           arrayOfByte2[0] = i38;
/* 5536 */           arrayOfByte2[1] = ((byte)(i22 & 0xFF));
/*      */         }
/*      */         
/* 5539 */         break;
/*      */       
/*      */       case 25: 
/* 5542 */         i38 = (byte)(i23 >> 8 & 0xFF);
/*      */         
/* 5544 */         if (i38 == 0)
/*      */         {
/* 5546 */           i29 = 3;
/* 5547 */           arrayOfByte2 = new byte[i29];
/* 5548 */           arrayOfByte2[1] = ((byte)(i24 >> 8 & 0xFF));
/* 5549 */           arrayOfByte2[2] = ((byte)(i24 & 0xFF));
/* 5550 */           arrayOfByte2[0] = ((byte)(i23 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5554 */           i29 = 4;
/* 5555 */           arrayOfByte2 = new byte[i29];
/* 5556 */           arrayOfByte2[2] = ((byte)(i24 >> 8 & 0xFF));
/* 5557 */           arrayOfByte2[3] = ((byte)(i24 & 0xFF));
/* 5558 */           arrayOfByte2[0] = i38;
/* 5559 */           arrayOfByte2[1] = ((byte)(i23 & 0xFF));
/*      */         }
/*      */         
/* 5562 */         break;
/*      */       
/*      */       case 26: 
/* 5565 */         i38 = (byte)(i24 >> 8 & 0xFF);
/*      */         
/* 5567 */         if (i38 == 0)
/*      */         {
/* 5569 */           i29 = 1;
/* 5570 */           arrayOfByte2 = new byte[i29];
/* 5571 */           arrayOfByte2[0] = ((byte)(i24 & 0xFF));
/*      */         }
/*      */         else
/*      */         {
/* 5575 */           i29 = 2;
/* 5576 */           arrayOfByte2 = new byte[i29];
/* 5577 */           arrayOfByte2[0] = i38;
/* 5578 */           arrayOfByte2[1] = ((byte)(i24 & 0xFF));
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       }
/*      */       
/*      */       
/* 5586 */       BigInteger localBigInteger = new BigInteger(i32, arrayOfByte2);
/*      */       
/* 5588 */       localBigDecimal = new BigDecimal(localBigInteger, -i34);
/*      */     }
/*      */     
/*      */ 
/* 5592 */     return localBigDecimal;
/*      */   }
/*      */   
/* 5595 */   int[] digs = new int[27];
/*      */   static final int LNXSGNBT = 128;
/*      */   static final byte LNXDIGS = 20;
/*      */   
/* 5599 */   BigDecimal getBigDecimaln(int paramInt) throws SQLException { BigDecimal localBigDecimal = null;
/*      */     
/* 5601 */     if (this.rowSpaceIndicator == null) {
/* 5602 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 5606 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/* 5609 */       byte[] arrayOfByte1 = this.rowSpaceByte;
/* 5610 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 5611 */       int j = arrayOfByte1[(i - 1)];
/*      */       
/* 5613 */       for (int k = 0; k < 27; k++) {
/* 5614 */         this.digs[k] = 0;
/*      */       }
/* 5616 */       k = 0;
/* 5617 */       int m = 1;
/*      */       
/* 5619 */       int i1 = 26;
/* 5620 */       int i2 = 0;
/*      */       
/*      */ 
/* 5623 */       int i5 = arrayOfByte1[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5628 */       int i10 = 0;
/*      */       
/* 5630 */       if ((i5 & 0xFFFFFF80) != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5638 */         if ((i5 == -128) && (j == 1)) {
/* 5639 */           return BIGDEC_ZERO;
/*      */         }
/* 5641 */         if ((j == 2) && (i5 == -1) && (arrayOfByte1[(i + 1)] == 101))
/*      */         {
/*      */ 
/*      */ 
/* 5645 */           throwOverflow();
/*      */         }
/* 5647 */         i6 = 1;
/* 5648 */         i7 = (byte)((i5 & 0xFF7F) - 65);
/*      */         
/*      */ 
/* 5651 */         i4 = j - 1;
/* 5652 */         n = i4 - 1;
/* 5653 */         i8 = i7 - i4 + 1 << 1;
/*      */         
/* 5655 */         if (i8 > 0)
/*      */         {
/* 5657 */           i8 = 0;
/* 5658 */           n = i7;
/*      */         }
/* 5660 */         else if (i8 < 0) {
/* 5661 */           i10 = (arrayOfByte1[(i + i4)] - 1) % 10 == 0 ? 1 : 0;
/*      */         }
/* 5663 */         m = (byte)(m + 1);k = arrayOfByte1[(i + m)] - 1;
/*      */         
/* 5665 */         while ((n & 0x1) != 0)
/*      */         {
/* 5667 */           if (m > i4) {
/* 5668 */             k *= 100;
/*      */           } else {
/* 5670 */             m = (byte)(m + 1);k = k * 100 + (arrayOfByte1[(i + m)] - 1);
/*      */           }
/* 5672 */           n--;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5683 */       if ((i5 == 0) && (j == 1))
/*      */       {
/*      */ 
/* 5686 */         throwOverflow();
/*      */       }
/* 5688 */       int i6 = -1;
/* 5689 */       int i7 = (byte)(((i5 ^ 0xFFFFFFFF) & 0xFF7F) - 65);
/*      */       
/*      */ 
/* 5692 */       int i4 = j - 1;
/*      */       
/* 5694 */       if ((i4 != 20) || (arrayOfByte1[(i + i4)] == 102)) {
/* 5695 */         i4--;
/*      */       }
/* 5697 */       int n = i4 - 1;
/*      */       
/* 5699 */       int i8 = i7 - i4 + 1 << 1;
/*      */       
/* 5701 */       if (i8 > 0)
/*      */       {
/* 5703 */         i8 = 0;
/* 5704 */         n = i7;
/*      */       }
/* 5706 */       else if (i8 < 0) {
/* 5707 */         i10 = (101 - arrayOfByte1[(i + i4)]) % 10 == 0 ? 1 : 0;
/*      */       }
/* 5709 */       m = (byte)(m + 1);k = 101 - arrayOfByte1[(i + m)];
/*      */       
/* 5711 */       while ((n & 0x1) != 0)
/*      */       {
/* 5713 */         if (m > i4) {
/* 5714 */           k *= 100;
/*      */         } else {
/* 5716 */           m = (byte)(m + 1);k = k * 100 + (101 - arrayOfByte1[(i + m)]);
/*      */         }
/* 5718 */         n--;
/*      */       }
/*      */       
/*      */ 
/* 5722 */       if (i10 != 0)
/*      */       {
/* 5724 */         i8++;
/* 5725 */         k /= 10;
/*      */       }
/*      */       
/* 5728 */       int i9 = i4 - 1;
/*      */       
/* 5730 */       while (n != 0)
/*      */       {
/* 5732 */         if (i6 == 1)
/*      */         {
/* 5734 */           if (i10 != 0)
/*      */           {
/* 5736 */             i2 = (arrayOfByte1[(i + m - 1)] - 1) % 10 * 1000 + (arrayOfByte1[(i + m)] - 1) * 10 + (arrayOfByte1[(i + m + 1)] - 1) / 10 + k * 10000;
/*      */             
/*      */ 
/* 5739 */             m = (byte)(m + 2);
/*      */           }
/* 5741 */           else if (m < i9)
/*      */           {
/* 5743 */             i2 = (arrayOfByte1[(i + m)] - 1) * 100 + (arrayOfByte1[(i + m + 1)] - 1) + k * 10000;
/*      */             
/*      */ 
/* 5746 */             m = (byte)(m + 2);
/*      */           }
/*      */           else
/*      */           {
/* 5750 */             i2 = 0;
/*      */             
/* 5752 */             if (m <= i4)
/*      */             {
/* 5754 */               for (i11 = 0; 
/*      */                   
/* 5756 */                   m <= i4; i11++) {
/* 5757 */                 m = (byte)(m + 1);i2 = i2 * 100 + (arrayOfByte1[(i + m)] - 1);
/*      */               }
/* 5759 */               for (; i11 < 2; i11++) {
/* 5760 */                 i2 *= 100;
/*      */               }
/*      */             }
/* 5763 */             i2 += k * 10000;
/*      */           }
/*      */         }
/* 5766 */         else if (i10 != 0)
/*      */         {
/* 5768 */           i2 = (101 - arrayOfByte1[(i + m - 1)]) % 10 * 1000 + (101 - arrayOfByte1[(i + m)]) * 10 + (101 - arrayOfByte1[(i + m + 1)]) / 10 + k * 10000;
/*      */           
/*      */ 
/* 5771 */           m = (byte)(m + 2);
/*      */         }
/* 5773 */         else if (m < i9)
/*      */         {
/* 5775 */           i2 = (101 - arrayOfByte1[(i + m)]) * 100 + (101 - arrayOfByte1[(i + m + 1)]) + k * 10000;
/*      */           
/*      */ 
/* 5778 */           m = (byte)(m + 2);
/*      */         }
/*      */         else
/*      */         {
/* 5782 */           i2 = 0;
/*      */           
/* 5784 */           if (m <= i4)
/*      */           {
/* 5786 */             for (i11 = 0; 
/*      */                 
/* 5788 */                 m <= i4; i11++) {
/* 5789 */               m = (byte)(m + 1);i2 = i2 * 100 + (101 - arrayOfByte1[(i + m)]);
/*      */             }
/* 5791 */             for (; i11 < 2; i11++) {
/* 5792 */               i2 *= 100;
/*      */             }
/*      */           }
/* 5795 */           i2 += k * 10000;
/*      */         }
/*      */         
/* 5798 */         k = i2 & 0xFFFF;
/*      */         
/* 5800 */         for (int i11 = 25; i11 >= i1; i11--)
/*      */         {
/* 5802 */           i2 = (i2 >> 16) + this.digs[i11] * 10000;
/* 5803 */           this.digs[i11] = (i2 & 0xFFFF);
/*      */         }
/*      */         
/* 5806 */         if (i2 != 0) {
/* 5807 */           i1 = (byte)(i1 - 1);this.digs[i1] = i2;
/*      */         }
/* 5809 */         n -= 2;
/*      */       }
/*      */       
/* 5812 */       this.digs[26] = k;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5823 */       int i12 = (byte)(this.digs[i1] >> 8 & 0xFF);
/*      */       int i3;
/* 5825 */       byte[] arrayOfByte2; int i13; int i14; if (i12 == 0)
/*      */       {
/* 5827 */         i3 = 53 - (i1 << 1);
/* 5828 */         arrayOfByte2 = new byte[i3];
/*      */         
/* 5830 */         for (i13 = 26; i13 > i1; i13--)
/*      */         {
/* 5832 */           i14 = i13 - i1 << 1;
/*      */           
/* 5834 */           arrayOfByte2[(i14 - 1)] = ((byte)(this.digs[i13] >> 8 & 0xFF));
/* 5835 */           arrayOfByte2[i14] = ((byte)(this.digs[i13] & 0xFF));
/*      */         }
/*      */         
/* 5838 */         arrayOfByte2[0] = ((byte)(this.digs[i1] & 0xFF));
/*      */       }
/*      */       else
/*      */       {
/* 5842 */         i3 = 54 - (i1 << 1);
/* 5843 */         arrayOfByte2 = new byte[i3];
/*      */         
/* 5845 */         for (i13 = 26; i13 > i1; i13--)
/*      */         {
/* 5847 */           i14 = i13 - i1 << 1;
/*      */           
/* 5849 */           arrayOfByte2[i14] = ((byte)(this.digs[i13] >> 8 & 0xFF));
/* 5850 */           arrayOfByte2[(i14 + 1)] = ((byte)(this.digs[i13] & 0xFF));
/*      */         }
/*      */         
/* 5853 */         arrayOfByte2[0] = i12;
/* 5854 */         arrayOfByte2[1] = ((byte)(this.digs[i1] & 0xFF));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5859 */       BigInteger localBigInteger = new BigInteger(i6, arrayOfByte2);
/*      */       
/* 5861 */       localBigDecimal = new BigDecimal(localBigInteger, -i8);
/*      */     }
/*      */     
/*      */ 
/* 5865 */     return localBigDecimal;
/*      */   }
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5871 */     if (this.rowSpaceIndicator == null) {
/* 5872 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 5876 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt1)] == -1)
/*      */     {
/* 5878 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 5882 */     return getBigDecimal(paramInt1).setScale(paramInt2, 6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5898 */     String str1 = null;
/*      */     
/* 5900 */     if (this.rowSpaceIndicator == null) {
/* 5901 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 5905 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*      */ 
/* 5908 */       byte[] arrayOfByte1 = this.rowSpaceByte;
/* 5909 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 5910 */       int j = arrayOfByte1[(i - 1)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6191 */       byte[] arrayOfByte2 = new byte[j];
/*      */       
/* 6193 */       System.arraycopy(arrayOfByte1, i, arrayOfByte2, 0, j);
/*      */       
/* 6195 */       NUMBER localNUMBER = new NUMBER(arrayOfByte2);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6204 */       String str2 = NUMBER.toString(arrayOfByte2);
/* 6205 */       int k = str2.length();
/*      */       
/* 6207 */       if ((str2.startsWith("0.")) || (str2.startsWith("-0."))) {
/* 6208 */         k--;
/*      */       }
/* 6210 */       if (k > 38)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6220 */         str2 = localNUMBER.toText(-44, null);
/*      */         
/*      */ 
/*      */ 
/* 6224 */         int m = str2.indexOf('E');
/* 6225 */         int n = str2.indexOf('+');
/*      */         
/* 6227 */         if (m == -1)
/*      */         {
/* 6229 */           m = str2.indexOf('e');
/*      */         }
/*      */         
/* 6232 */         int i1 = m - 1;
/*      */         
/* 6234 */         while (str2.charAt(i1) == '0')
/*      */         {
/* 6236 */           i1--;
/*      */         }
/*      */         
/* 6239 */         String str3 = str2.substring(0, i1 + 1);
/* 6240 */         String str4 = null;
/*      */         
/* 6242 */         if (n > 0)
/*      */         {
/* 6244 */           str4 = str2.substring(n + 1);
/*      */         }
/*      */         else
/*      */         {
/* 6248 */           str4 = str2.substring(m + 1);
/*      */         }
/*      */         
/* 6251 */         return (str3 + "E" + str4).trim();
/*      */       }
/*      */       
/* 6254 */       return localNUMBER.toText(38, null).trim();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6260 */     return str1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6274 */     NUMBER localNUMBER = null;
/*      */     
/* 6276 */     if (this.rowSpaceIndicator == null) {
/* 6277 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 6281 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/* 6283 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 6284 */       int j = this.rowSpaceByte[(i - 1)];
/* 6285 */       byte[] arrayOfByte = new byte[j];
/*      */       
/* 6287 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, j);
/*      */       
/* 6289 */       localNUMBER = new NUMBER(arrayOfByte);
/*      */     }
/*      */     
/* 6292 */     return localNUMBER;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6306 */     Object localObject = null;
/*      */     
/* 6308 */     if (this.rowSpaceIndicator == null) {
/* 6309 */       DatabaseError.throwSqlException(21);
/*      */     }
/* 6311 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/* 6313 */       if (this.externalType == 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6343 */         if ((this.statement.connection.j2ee13Compliant) && (this.precision != 0) && (this.scale == -127))
/*      */         {
/* 6345 */           localObject = new Double(getDouble(paramInt));
/*      */         } else {
/* 6347 */           localObject = getBigDecimal(paramInt);
/*      */         }
/*      */       }
/*      */       else {
/* 6351 */         switch (this.externalType)
/*      */         {
/*      */ 
/*      */         case -7: 
/* 6355 */           return new Boolean(getBoolean(paramInt));
/*      */         
/*      */         case -6: 
/* 6358 */           return new Byte(getByte(paramInt));
/*      */         
/*      */         case 5: 
/* 6361 */           return new Short(getShort(paramInt));
/*      */         
/*      */         case 4: 
/* 6364 */           return new Integer(getInt(paramInt));
/*      */         
/*      */         case -5: 
/* 6367 */           return new Long(getLong(paramInt));
/*      */         
/*      */ 
/*      */         case 6: 
/*      */         case 8: 
/* 6372 */           return new Double(getDouble(paramInt));
/*      */         
/*      */         case 7: 
/* 6375 */           return new Float(getFloat(paramInt));
/*      */         
/*      */ 
/*      */         case 2: 
/*      */         case 3: 
/* 6380 */           return getBigDecimal(paramInt);
/*      */         }
/*      */         
/* 6383 */         DatabaseError.throwSqlException(4);
/*      */         
/* 6385 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 6390 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 6404 */     return getObject(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6418 */     return getNUMBER(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6436 */     byte[] arrayOfByte = null;
/*      */     
/* 6438 */     if (this.rowSpaceIndicator == null) {
/* 6439 */       DatabaseError.throwSqlException(21);
/*      */     }
/*      */     
/*      */ 
/* 6443 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/* 6445 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 6446 */       int j = this.rowSpaceByte[(i - 1)];
/*      */       
/* 6448 */       arrayOfByte = new byte[j];
/*      */       
/* 6450 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, j);
/*      */     }
/*      */     
/* 6453 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte LNXEXPBS = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LNXEXPMX = 127;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6478 */   static final BigDecimal BIGDEC_ZERO = BigDecimal.valueOf(0L);
/*      */   
/*      */   static final byte MAX_LONG_EXPONENT = 9;
/*      */   
/*      */   static final byte MIN_LONG_EXPONENT = 9;
/*      */   static final byte MAX_INT_EXPONENT = 4;
/*      */   static final byte MIN_INT_EXPONENT = 4;
/*      */   static final byte MAX_SHORT_EXPONENT = 2;
/*      */   static final byte MIN_SHORT_EXPONENT = 2;
/*      */   static final byte MAX_BYTE_EXPONENT = 1;
/*      */   static final byte MIN_BYTE_EXPONENT = 1;
/* 6489 */   static final int[] MAX_LONG = { 202, 10, 23, 34, 73, 4, 69, 55, 78, 59, 8 };
/*      */   
/*      */ 
/*      */ 
/* 6493 */   static final int[] MIN_LONG = { 53, 92, 79, 68, 29, 98, 33, 47, 24, 43, 93, 102 };
/*      */   
/*      */ 
/*      */ 
/*      */   static final int MAX_LONG_length = 11;
/*      */   
/*      */ 
/*      */   static final int MIN_LONG_length = 12;
/*      */   
/*      */ 
/* 6503 */   static final double[] factorTable = { 1.0E254D, 1.0E252D, 1.0E250D, 1.0E248D, 1.0E246D, 1.0E244D, 1.0E242D, 1.0E240D, 1.0E238D, 1.0E236D, 1.0E234D, 1.0E232D, 1.0E230D, 1.0E228D, 1.0E226D, 1.0E224D, 1.0E222D, 1.0E220D, 1.0E218D, 1.0E216D, 1.0E214D, 1.0E212D, 1.0E210D, 1.0E208D, 1.0E206D, 1.0E204D, 1.0E202D, 1.0E200D, 1.0E198D, 1.0E196D, 1.0E194D, 1.0E192D, 1.0E190D, 1.0E188D, 1.0E186D, 1.0E184D, 1.0E182D, 1.0E180D, 1.0E178D, 1.0E176D, 1.0E174D, 1.0E172D, 1.0E170D, 1.0E168D, 1.0E166D, 1.0E164D, 1.0E162D, 1.0E160D, 1.0E158D, 1.0E156D, 1.0E154D, 1.0E152D, 1.0E150D, 1.0E148D, 1.0E146D, 1.0E144D, 1.0E142D, 1.0E140D, 1.0E138D, 1.0E136D, 1.0E134D, 1.0E132D, 1.0E130D, 1.0E128D, 1.0E126D, 1.0E124D, 1.0E122D, 1.0E120D, 1.0E118D, 1.0E116D, 1.0E114D, 1.0E112D, 1.0E110D, 1.0E108D, 1.0E106D, 1.0E104D, 1.0E102D, 1.0E100D, 1.0E98D, 1.0E96D, 1.0E94D, 1.0E92D, 1.0E90D, 1.0E88D, 1.0E86D, 1.0E84D, 1.0E82D, 1.0E80D, 1.0E78D, 1.0E76D, 1.0E74D, 1.0E72D, 1.0E70D, 1.0E68D, 1.0E66D, 1.0E64D, 1.0E62D, 1.0E60D, 1.0E58D, 1.0E56D, 1.0E54D, 1.0E52D, 1.0E50D, 1.0E48D, 1.0E46D, 1.0E44D, 1.0E42D, 1.0E40D, 1.0E38D, 1.0E36D, 1.0E34D, 1.0E32D, 1.0E30D, 1.0E28D, 1.0E26D, 1.0E24D, 1.0E22D, 1.0E20D, 1.0E18D, 1.0E16D, 1.0E14D, 1.0E12D, 1.0E10D, 1.0E8D, 1000000.0D, 10000.0D, 100.0D, 1.0D, 0.01D, 1.0E-4D, 1.0E-6D, 1.0E-8D, 1.0E-10D, 1.0E-12D, 1.0E-14D, 1.0E-16D, 1.0E-18D, 1.0E-20D, 1.0E-22D, 1.0E-24D, 1.0E-26D, 1.0E-28D, 1.0E-30D, 1.0E-32D, 1.0E-34D, 1.0E-36D, 1.0E-38D, 1.0E-40D, 1.0E-42D, 1.0E-44D, 1.0E-46D, 1.0E-48D, 1.0E-50D, 1.0E-52D, 1.0E-54D, 1.0E-56D, 1.0E-58D, 1.0E-60D, 1.0E-62D, 1.0E-64D, 1.0E-66D, 1.0E-68D, 1.0E-70D, 1.0E-72D, 1.0E-74D, 1.0E-76D, 1.0E-78D, 1.0E-80D, 1.0E-82D, 1.0E-84D, 1.0E-86D, 1.0E-88D, 1.0E-90D, 1.0E-92D, 1.0E-94D, 1.0E-96D, 1.0E-98D, 1.0E-100D, 1.0E-102D, 1.0E-104D, 1.0E-106D, 1.0E-108D, 1.0E-110D, 1.0E-112D, 1.0E-114D, 1.0E-116D, 1.0E-118D, 1.0E-120D, 1.0E-122D, 1.0E-124D, 1.0E-126D, 1.0E-128D, 1.0E-130D, 1.0E-132D, 1.0E-134D, 1.0E-136D, 1.0E-138D, 1.0E-140D, 1.0E-142D, 1.0E-144D, 1.0E-146D, 1.0E-148D, 1.0E-150D, 1.0E-152D, 1.0E-154D, 1.0E-156D, 1.0E-158D, 1.0E-160D, 1.0E-162D, 1.0E-164D, 1.0E-166D, 1.0E-168D, 1.0E-170D, 1.0E-172D, 1.0E-174D, 1.0E-176D, 1.0E-178D, 1.0E-180D, 1.0E-182D, 1.0E-184D, 1.0E-186D, 1.0E-188D, 1.0E-190D, 1.0E-192D, 1.0E-194D, 1.0E-196D, 1.0E-198D, 1.0E-200D, 1.0E-202D, 1.0E-204D, 1.0E-206D, 1.0E-208D, 1.0E-210D, 1.0E-212D, 1.0E-214D, 1.0E-216D, 1.0E-218D, 1.0E-220D, 1.0E-222D, 1.0E-224D, 1.0E-226D, 1.0E-228D, 1.0E-230D, 1.0E-232D, 1.0E-234D, 1.0E-236D, 1.0E-238D, 1.0E-240D, 1.0E-242D, 1.0E-244D, 1.0E-246D, 1.0E-248D, 1.0E-250D, 1.0E-252D, 1.0E-254D };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6540 */   static final double[] small10pow = { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 1.0E20D, 1.0E21D, 1.0E22D };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6547 */   static final int tablemax = factorTable.length;
/*      */   static final double tablemaxexponent = 127.0D;
/* 6549 */   static final double tableminexponent = 127.0D - (tablemax - 20);
/*      */   
/*      */ 
/*      */   static final int MANTISSA_SIZE = 53;
/*      */   
/* 6554 */   static final int[] expdigs0 = { 25597, 55634, 18440, 18324, 42485, 50370, 56862, 11593, 45703, 57341, 10255, 12549, 59579, 5 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6560 */   static final int[] expdigs1 = { 50890, 19916, 24149, 23777, 11324, 41057, 14921, 56274, 30917, 19462, 54968, 47943, 38791, 3872 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6566 */   static final int[] expdigs2 = { 24101, 29690, 40218, 29073, 29604, 22037, 27674, 9082, 56670, 55244, 20865, 54874, 47573, 38 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6572 */   static final int[] expdigs3 = { 22191, 40873, 1607, 45622, 23883, 24544, 32988, 43530, 61694, 55616, 43150, 32976, 27418, 25379 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6578 */   static final int[] expdigs4 = { 55927, 44317, 6569, 54851, 238, 63160, 51447, 12231, 55667, 25459, 5674, 40962, 52047, 253 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6584 */   static final int[] expdigs5 = { 56264, 8962, 51839, 64773, 39323, 49783, 15587, 30924, 36601, 56615, 27581, 36454, 35254, 2 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6590 */   static final int[] expdigs6 = { 21545, 25466, 59727, 37873, 13099, 7602, 15571, 49963, 37664, 46896, 14328, 59258, 17403, 1663 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6596 */   static final int[] expdigs7 = { 12011, 4842, 3874, 57395, 38141, 46606, 49307, 60792, 31833, 21440, 9318, 47123, 41461, 16 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6602 */   static final int[] expdigs8 = { 52383, 25023, 56409, 43947, 51036, 17420, 62725, 5735, 53692, 44882, 64439, 36137, 24719, 10900 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6608 */   static final int[] expdigs9 = { 65404, 27119, 57580, 26653, 42453, 19179, 26186, 42000, 1847, 62708, 14406, 12813, 247, 109 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6614 */   static final int[] expdigs10 = { 36698, 50078, 40552, 35000, 49576, 56552, 261, 49572, 31475, 59609, 45363, 46658, 5900, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6620 */   static final int[] expdigs11 = { 33321, 54106, 42443, 60698, 47535, 24088, 45785, 18352, 47026, 40291, 5183, 35843, 24059, 714 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6626 */   static final int[] expdigs12 = { 12129, 44450, 22706, 34030, 37175, 8760, 31915, 56544, 23407, 52176, 7260, 41646, 9415, 7 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6632 */   static final int[] expdigs13 = { 43054, 17160, 43698, 6780, 36385, 52800, 62346, 52747, 33988, 2855, 31979, 38083, 44325, 4681 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6638 */   static final int[] expdigs14 = { 60723, 40803, 16165, 19073, 2985, 9703, 41911, 37227, 41627, 1994, 38986, 27250, 53527, 46 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6644 */   static final int[] expdigs15 = { 36481, 57623, 45627, 58488, 53274, 7238, 2063, 31221, 62631, 25319, 35409, 25293, 54667, 30681 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6650 */   static final int[] expdigs16 = { 52138, 47106, 3077, 4517, 41165, 38738, 39997, 10142, 13078, 16637, 53438, 54647, 53630, 306 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6656 */   static final int[] expdigs17 = { 25425, 24719, 55736, 8564, 12208, 3664, 51518, 17140, 61079, 30312, 2500, 30693, 4468, 3 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6662 */   static final int[] expdigs18 = { 58368, 65134, 52675, 3178, 26300, 7986, 11833, 515, 23109, 63525, 29138, 19030, 50114, 2010 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6668 */   static final int[] expdigs19 = { 41216, 15724, 12323, 26246, 59245, 58406, 46648, 13767, 11372, 15053, 61895, 48686, 7054, 20 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6674 */   static final int[] expdigs20 = { 0, 29248, 62416, 1433, 14025, 43846, 39905, 44375, 137, 47955, 62409, 33386, 48983, 13177 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6680 */   static final int[] expdigs21 = { 0, 21264, 53708, 60962, 25043, 64008, 31200, 50906, 9831, 56185, 43877, 36378, 50952, 131 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6686 */   static final int[] expdigs22 = { 0, 50020, 25440, 60247, 44814, 39961, 6865, 26068, 34832, 9081, 17478, 44928, 20825, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6692 */   static final int[] expdigs23 = { 0, 0, 52929, 10084, 25506, 6346, 61348, 31525, 52689, 61296, 27615, 15903, 40426, 863 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6698 */   static final int[] expdigs24 = { 0, 16384, 24122, 53840, 43508, 13170, 51076, 37670, 58198, 31414, 57292, 61762, 41691, 8 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6704 */   static final int[] expdigs25 = { 0, 0, 4096, 29077, 42481, 30581, 10617, 59493, 46251, 1892, 5557, 4505, 52391, 5659 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6710 */   static final int[] expdigs26 = { 0, 0, 58368, 11431, 1080, 29797, 47947, 36639, 42405, 50481, 29546, 9875, 39190, 56 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6716 */   static final int[] expdigs27 = { 0, 0, 0, 57600, 63028, 53094, 12749, 18174, 21993, 48265, 14922, 59933, 4030, 37092 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6722 */   static final int[] expdigs28 = { 0, 0, 0, 576, 1941, 35265, 9302, 42780, 50682, 28007, 29640, 28124, 60333, 370 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6728 */   static final int[] expdigs29 = { 0, 0, 0, 5904, 8539, 12149, 36793, 43681, 12958, 60573, 21267, 35015, 46478, 3 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6734 */   static final int[] expdigs30 = { 0, 0, 0, 0, 7268, 50548, 47962, 3644, 22719, 26999, 41893, 7421, 56711, 2430 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6739 */   static final int[] expdigs31 = { 0, 0, 0, 0, 7937, 49002, 60772, 28216, 38893, 55975, 63988, 59711, 20227, 24 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6744 */   static final int[] expdigs32 = { 0, 0, 0, 16384, 38090, 63404, 55657, 8801, 62648, 13666, 57656, 60234, 15930 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6749 */   static final int[] expdigs33 = { 0, 0, 0, 4096, 37081, 37989, 16940, 55138, 17665, 39458, 9751, 20263, 159 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6754 */   static final int[] expdigs34 = { 0, 0, 0, 58368, 35104, 16108, 61773, 14313, 30323, 54789, 57113, 38868, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6759 */   static final int[] expdigs35 = { 0, 0, 0, 8448, 18701, 29652, 51080, 65023, 27172, 37903, 3192, 1044 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6764 */   static final int[] expdigs36 = { 0, 0, 0, 37440, 63101, 2917, 39177, 50457, 25830, 50186, 28867, 10 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6769 */   static final int[] expdigs37 = { 0, 0, 0, 56080, 45850, 37384, 3668, 12301, 38269, 18196, 6842 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6774 */   static final int[] expdigs38 = { 0, 0, 0, 46436, 13565, 50181, 34770, 37478, 5625, 27707, 68 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6779 */   static final int[] expdigs39 = { 0, 0, 0, 32577, 45355, 38512, 38358, 3651, 36101, 44841 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6784 */   static final int[] expdigs40 = { 0, 0, 16384, 28506, 5696, 56746, 15456, 50499, 27230, 448 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6789 */   static final int[] expdigs41 = { 0, 0, 4096, 285, 9232, 58239, 57170, 38515, 31729, 4 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6794 */   static final int[] expdigs42 = { 0, 0, 58368, 41945, 57108, 12378, 28752, 48226, 2938 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6799 */   static final int[] expdigs43 = { 0, 0, 24832, 47605, 49067, 23716, 61891, 25385, 29 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6804 */   static final int[] expdigs44 = { 0, 0, 8768, 2442, 50298, 23174, 19624, 19259 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6809 */   static final int[] expdigs45 = { 0, 0, 40720, 45899, 1813, 31689, 38862, 192 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6814 */   static final int[] expdigs46 = { 0, 0, 36452, 14221, 34752, 48813, 60681, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6819 */   static final int[] expdigs47 = { 0, 0, 61313, 34220, 16731, 11629, 1262 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6824 */   static final int[] expdigs48 = { 0, 16384, 60906, 18036, 40144, 40748, 12 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6829 */   static final int[] expdigs49 = { 0, 4096, 609, 15909, 52830, 8271 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6834 */   static final int[] expdigs50 = { 0, 58368, 3282, 56520, 47058, 82 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6839 */   static final int[] expdigs51 = { 0, 41216, 52461, 7118, 54210 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6844 */   static final int[] expdigs52 = { 0, 45632, 51642, 6624, 542 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6849 */   static final int[] expdigs53 = { 0, 25360, 24109, 27591, 5 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6854 */   static final int[] expdigs54 = { 0, 42852, 46771, 3552 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6859 */   static final int[] expdigs55 = { 0, 28609, 34546, 35 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6864 */   static final int[] expdigs56 = { 16384, 4218, 23283 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6869 */   static final int[] expdigs57 = { 4096, 54437, 232 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6874 */   static final int[] expdigs58 = { 58368, 21515, 2 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6879 */   static final int[] expdigs59 = { 57600, 1525 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6884 */   static final int[] expdigs60 = { 16960, 15 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6889 */   static final int[] expdigs61 = { 10000 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6894 */   static final int[] expdigs62 = { 100 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6899 */   static final int[] expdigs63 = { 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6904 */   static final int[] expdigs64 = { 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 655 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6910 */   static final int[] expdigs65 = { 14784, 18979, 33659, 19503, 2726, 9542, 629, 2202, 40475, 10590, 4299, 47815, 36280, 6 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6916 */   static final int[] expdigs66 = { 16332, 9978, 33613, 31138, 35584, 64252, 13857, 14424, 62281, 46279, 36150, 46573, 63392, 4294 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6922 */   static final int[] expdigs67 = { 6716, 24348, 22618, 23904, 21327, 3919, 44703, 19149, 28803, 48959, 6259, 50273, 62237, 42 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6928 */   static final int[] expdigs68 = { 8471, 23660, 38254, 26440, 33662, 38879, 9869, 11588, 41479, 23225, 60127, 24310, 32615, 28147 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6934 */   static final int[] expdigs69 = { 13191, 6790, 63297, 30410, 12788, 42987, 23691, 28296, 32527, 38898, 41233, 4830, 31128, 281 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6940 */   static final int[] expdigs70 = { 4064, 53152, 62236, 29139, 46658, 12881, 31694, 4870, 19986, 24637, 9587, 28884, 53395, 2 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6946 */   static final int[] expdigs71 = { 26266, 10526, 16260, 55017, 35680, 40443, 19789, 17356, 30195, 55905, 28426, 63010, 44197, 1844 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6952 */   static final int[] expdigs72 = { 38273, 7969, 37518, 26764, 23294, 63974, 18547, 17868, 24550, 41191, 17323, 53714, 29277, 18 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6958 */   static final int[] expdigs73 = { 16739, 37738, 38090, 26589, 43521, 1543, 15713, 10671, 11975, 41533, 18106, 9348, 16921, 12089 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6964 */   static final int[] expdigs74 = { 14585, 61981, 58707, 16649, 25994, 39992, 28337, 17801, 37475, 22697, 31638, 16477, 58496, 120 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6970 */   static final int[] expdigs75 = { 58472, 2585, 40564, 27691, 44824, 27269, 58610, 54572, 35108, 30373, 35050, 10650, 13692, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6976 */   static final int[] expdigs76 = { 50392, 58911, 41968, 49557, 29112, 29939, 43526, 63500, 55595, 27220, 25207, 38361, 18456, 792 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6982 */   static final int[] expdigs77 = { 26062, 32046, 3696, 45060, 46821, 40931, 50242, 60272, 24148, 20588, 6150, 44948, 60477, 7 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6988 */   static final int[] expdigs78 = { 12430, 30407, 320, 41980, 58777, 41755, 41041, 13609, 45167, 13348, 40838, 60354, 19454, 5192 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6994 */   static final int[] expdigs79 = { 30926, 26518, 13110, 43018, 54982, 48258, 24658, 15209, 63366, 11929, 20069, 43857, 60487, 51 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7000 */   static final int[] expdigs80 = { 51263, 54048, 48761, 48627, 30576, 49046, 4414, 61195, 61755, 48474, 19124, 55906, 15511, 34028 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7006 */   static final int[] expdigs81 = { 39834, 11681, 47018, 3107, 64531, 54229, 41331, 41899, 51735, 42427, 59173, 13010, 18505, 340 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7012 */   static final int[] expdigs82 = { 27268, 6670, 31272, 9861, 45865, 10372, 12865, 62678, 23454, 35158, 20252, 29621, 26399, 3 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7018 */   static final int[] expdigs83 = { 57738, 46147, 66, 48154, 11239, 21430, 55809, 46003, 15044, 25138, 52780, 48043, 4883, 2230 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7024 */   static final int[] expdigs84 = { 20893, 62065, 64225, 52254, 59094, 55919, 60195, 5702, 48647, 50058, 7736, 41768, 19709, 22 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7030 */   static final int[] expdigs85 = { 37714, 32321, 45840, 36031, 33290, 47121, 5146, 28127, 9887, 25390, 52929, 2698, 1073, 14615 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7036 */   static final int[] expdigs86 = { 35111, 8187, 18153, 56721, 40309, 59453, 51824, 4868, 45974, 3530, 43783, 8546, 9841, 146 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7042 */   static final int[] expdigs87 = { 23288, 61030, 42779, 19572, 29894, 47780, 45082, 32816, 43713, 33458, 25341, 63655, 30244, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7048 */   static final int[] expdigs88 = { 58138, 33000, 62869, 37127, 61799, 298, 46353, 5693, 63898, 62040, 989, 23191, 53065, 957 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7054 */   static final int[] expdigs89 = { 42524, 32442, 36673, 15444, 22900, 658, 61412, 32824, 21610, 64190, 1975, 11373, 37886, 9 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7060 */   static final int[] expdigs90 = { 26492, 4357, 32437, 10852, 34233, 53968, 55056, 34692, 64553, 38226, 41929, 21646, 6667, 6277 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7066 */   static final int[] expdigs91 = { 61213, 698, 16053, 50571, 2963, 50347, 13657, 48188, 46520, 19387, 33187, 25775, 50529, 62 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7072 */   static final int[] expdigs92 = { 42864, 54351, 45226, 20476, 23443, 17724, 3780, 44701, 52910, 23402, 28374, 46862, 40234, 41137 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7078 */   static final int[] expdigs93 = { 23366, 62147, 58123, 44113, 55284, 39498, 3314, 9622, 9704, 27759, 25187, 43722, 24650, 411 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7084 */   static final int[] expdigs94 = { 38899, 44530, 19586, 37141, 1863, 9570, 32801, 31553, 51870, 62536, 51369, 30583, 7455, 4 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7090 */   static final int[] expdigs95 = { 10421, 4321, 43699, 3472, 65252, 17057, 13858, 29819, 14733, 21490, 40602, 31315, 65186, 2695 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7096 */   static final int[] expdigs96 = { 6002, 54438, 29272, 34113, 17036, 25074, 36183, 953, 25051, 12011, 20722, 4245, 62911, 26 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7102 */   static final int[] expdigs97 = { 14718, 45935, 8408, 42891, 21312, 56531, 44159, 45581, 20325, 36295, 35509, 24455, 30844, 17668 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7108 */   static final int[] expdigs98 = { 54542, 45023, 23021, 3050, 31015, 20881, 50904, 40432, 33626, 14125, 44264, 60537, 44872, 176 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7114 */   static final int[] expdigs99 = { 60183, 8969, 14648, 17725, 11451, 50016, 34587, 46279, 19341, 42084, 16826, 5848, 50256, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7120 */   static final int[] expdigs100 = { 64999, 53685, 60382, 19151, 25736, 5357, 31302, 23283, 14225, 52622, 56781, 39489, 60351, 1157 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7126 */   static final int[] expdigs101 = { 1305, 4469, 39270, 18541, 63827, 59035, 54707, 16616, 32910, 48367, 64137, 2360, 37959, 11 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7132 */   static final int[] expdigs102 = { 45449, 32125, 19705, 56098, 51958, 5225, 18285, 13654, 9341, 25888, 50946, 26855, 36068, 7588 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7138 */   static final int[] expdigs103 = { 27324, 53405, 43450, 25464, 3796, 3329, 46058, 53220, 26307, 53998, 33932, 23861, 58032, 75 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7144 */   static final int[] expdigs104 = { 63080, 50735, 1844, 21406, 57926, 63607, 24936, 52889, 23469, 64488, 539, 8859, 21210, 49732 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7150 */   static final int[] expdigs105 = { 62890, 39828, 3950, 32982, 39245, 21607, 40226, 50991, 18584, 10475, 59643, 40720, 21183, 497 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7156 */   static final int[] expdigs106 = { 37329, 64623, 11835, 985, 46923, 48712, 28582, 21481, 28366, 41392, 13703, 49559, 63781, 4 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7162 */   static final int[] expdigs107 = { 3316, 60011, 41933, 47959, 54404, 39790, 12283, 941, 46090, 42226, 18108, 38803, 16879, 3259 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7168 */   static final int[] expdigs108 = { 46563, 56305, 5006, 45044, 49040, 12849, 778, 6563, 46336, 3043, 7390, 2354, 38835, 32 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7174 */   static final int[] expdigs109 = { 28653, 3742, 33331, 2671, 39772, 29981, 56489, 1973, 26280, 26022, 56391, 56434, 57039, 21359 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7180 */   static final int[] expdigs110 = { 9461, 17732, 7542, 26241, 8917, 24548, 61513, 13126, 59245, 41547, 1874, 41852, 39236, 213 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7186 */   static final int[] expdigs111 = { 36794, 22459, 63645, 14024, 42032, 53329, 25518, 11272, 18287, 20076, 62933, 3039, 8912, 2 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7192 */   static final int[] expdigs112 = { 14926, 15441, 32337, 42579, 26354, 35154, 22815, 36955, 12564, 8047, 856, 41917, 55080, 1399 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7198 */   static final int[] expdigs113 = { 8668, 50617, 10153, 17465, 1574, 28532, 15301, 58041, 38791, 60373, 663, 29255, 65431, 13 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7204 */   static final int[] expdigs114 = { 21589, 32199, 24754, 45321, 9349, 26230, 35019, 37508, 20896, 42986, 31405, 12458, 65173, 9173 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7210 */   static final int[] expdigs115 = { 46746, 1632, 61196, 50915, 64318, 41549, 2971, 23968, 59191, 58756, 61917, 779, 48493, 91 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7216 */   static final int[] expdigs116 = { 1609, 63382, 15744, 15685, 51627, 56348, 33838, 52458, 44148, 11077, 56293, 41906, 45227, 60122 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7222 */   static final int[] expdigs117 = { 19676, 45198, 6055, 38823, 8380, 49060, 17377, 58196, 43039, 21737, 59545, 12870, 14870, 601 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7228 */   static final int[] expdigs118 = { 4128, 2418, 28241, 13495, 26298, 3767, 31631, 5169, 8950, 27087, 56956, 4060, 804, 6 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7234 */   static final int[] expdigs119 = { 39930, 40673, 19029, 54677, 38145, 23200, 41325, 24564, 24955, 54484, 23863, 52998, 13147, 3940 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7240 */   static final int[] expdigs120 = { 3676, 24655, 34924, 27416, 23974, 887, 10899, 4833, 21221, 28725, 19899, 57546, 26345, 39 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7246 */   static final int[] expdigs121 = { 28904, 41324, 18596, 42292, 12070, 52013, 30810, 61057, 55753, 32324, 38953, 6752, 32688, 25822 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7252 */   static final int[] expdigs122 = { 42232, 26627, 2807, 27948, 50583, 49016, 32420, 64180, 3178, 3600, 21361, 52496, 14744, 258 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7258 */   static final int[] expdigs123 = { 2388, 59904, 28863, 7488, 31963, 8354, 47510, 15059, 2653, 58363, 31670, 21496, 38158, 2 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7264 */   static final int[] expdigs124 = { 50070, 5266, 26158, 10774, 15148, 6873, 30230, 33898, 63720, 51799, 4515, 50124, 19875, 1692 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7270 */   static final int[] expdigs125 = { 54240, 3984, 12058, 2729, 13914, 11865, 38313, 39660, 10467, 20834, 36745, 57517, 60491, 16 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7276 */   static final int[] expdigs126 = { 5387, 58214, 9214, 13883, 14445, 34873, 21745, 13490, 23334, 25008, 58535, 19372, 44484, 11090 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7282 */   static final int[] expdigs127 = { 27578, 64807, 12543, 794, 13907, 61297, 12013, 64360, 15961, 20566, 24178, 15922, 59427, 110 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7288 */   static final int[] expdigs128 = { 49427, 41935, 46000, 59645, 45358, 51075, 15848, 32756, 38170, 14623, 35631, 57175, 7147, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7294 */   static final int[] expdigs129 = { 33941, 39160, 55469, 45679, 22878, 60091, 37210, 18508, 1638, 57398, 65026, 41643, 54966, 726 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7300 */   static final int[] expdigs130 = { 60632, 24639, 41842, 62060, 20544, 59583, 52800, 1495, 48513, 43827, 10480, 1727, 17589, 7 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7306 */   static final int[] expdigs131 = { 5590, 60244, 53985, 26632, 53049, 33628, 58267, 54922, 21641, 62744, 58109, 2070, 26887, 4763 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7312 */   static final int[] expdigs132 = { 62970, 37957, 34618, 29757, 24123, 2302, 17622, 58876, 44780, 6525, 33349, 36065, 41556, 47 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7318 */   static final int[] expdigs133 = { 1615, 24878, 20040, 11487, 23235, 27766, 59005, 57847, 60881, 11588, 63635, 61281, 31817, 31217 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7324 */   static final int[] expdigs134 = { 14434, 2870, 65081, 44023, 40864, 40254, 47120, 6476, 32066, 23053, 17020, 19618, 11459, 312 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7330 */   static final int[] expdigs135 = { 43398, 40005, 36695, 8304, 12205, 16131, 42414, 38075, 63890, 2851, 61774, 59833, 7978, 3 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7336 */   static final int[] expdigs136 = { 56426, 22060, 15473, 31824, 19088, 38788, 64386, 12875, 35770, 65519, 11824, 19623, 56959, 2045 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7342 */   static final int[] expdigs137 = { 16292, 32333, 10640, 47504, 29026, 30534, 23581, 6682, 10188, 24248, 44027, 51969, 30060, 20 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7348 */   static final int[] expdigs138 = { 29432, 37518, 55373, 2727, 33243, 22572, 16689, 35625, 34145, 15830, 59880, 32552, 52948, 13407 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7354 */   static final int[] expdigs139 = { 61898, 27244, 41841, 33450, 18682, 13988, 24415, 11497, 1652, 34237, 34677, 325, 5117, 134 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7360 */   static final int[] expdigs140 = { 16347, 3549, 48915, 22616, 21158, 51913, 32356, 21086, 3293, 8862, 1002, 26873, 22333, 1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7366 */   static final int[] expdigs141 = { 25966, 63733, 28215, 31946, 40858, 58538, 11004, 6877, 6109, 3965, 35478, 37365, 45488, 878 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7372 */   static final int[] expdigs142 = { 45479, 34060, 17321, 19980, 1719, 16314, 29601, 8588, 58388, 22321, 14117, 63288, 51572, 8 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7378 */   static final int[] expdigs143 = { 46861, 47640, 11481, 23766, 46730, 53756, 8682, 60589, 42028, 27453, 29714, 31598, 39954, 5758 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7384 */   static final int[] expdigs144 = { 29304, 58803, 51232, 27762, 60760, 17576, 19092, 26820, 11561, 48771, 6850, 27841, 38410, 57 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7390 */   static final int[] expdigs145 = { 2916, 49445, 34666, 46387, 18627, 58279, 60468, 190, 3545, 51889, 51605, 47909, 40910, 37739 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7396 */   static final int[] expdigs146 = { 19034, 62098, 15419, 33887, 38852, 53011, 28129, 37357, 11176, 48360, 9035, 9654, 25968, 377 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7402 */   static final int[] expdigs147 = { 25094, 10451, 7363, 55389, 57404, 27399, 11422, 39695, 28947, 12935, 61694, 26310, 50722, 3 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7408 */   static final int[][] expdigstable = { expdigs0, expdigs1, expdigs2, expdigs3, expdigs4, expdigs5, expdigs6, expdigs7, expdigs8, expdigs9, expdigs10, expdigs11, expdigs12, expdigs13, expdigs14, expdigs15, expdigs16, expdigs17, expdigs18, expdigs19, expdigs20, expdigs21, expdigs22, expdigs23, expdigs24, expdigs25, expdigs26, expdigs27, expdigs28, expdigs29, expdigs30, expdigs31, expdigs32, expdigs33, expdigs34, expdigs35, expdigs36, expdigs37, expdigs38, expdigs39, expdigs40, expdigs41, expdigs42, expdigs43, expdigs44, expdigs45, expdigs46, expdigs47, expdigs48, expdigs49, expdigs50, expdigs51, expdigs52, expdigs53, expdigs54, expdigs55, expdigs56, expdigs57, expdigs58, expdigs59, expdigs60, expdigs61, expdigs62, expdigs63, expdigs64, expdigs65, expdigs66, expdigs67, expdigs68, expdigs69, expdigs70, expdigs71, expdigs72, expdigs73, expdigs74, expdigs75, expdigs76, expdigs77, expdigs78, expdigs79, expdigs80, expdigs81, expdigs82, expdigs83, expdigs84, expdigs85, expdigs86, expdigs87, expdigs88, expdigs89, expdigs90, expdigs91, expdigs92, expdigs93, expdigs94, expdigs95, expdigs96, expdigs97, expdigs98, expdigs99, expdigs100, expdigs101, expdigs102, expdigs103, expdigs104, expdigs105, expdigs106, expdigs107, expdigs108, expdigs109, expdigs110, expdigs111, expdigs112, expdigs113, expdigs114, expdigs115, expdigs116, expdigs117, expdigs118, expdigs119, expdigs120, expdigs121, expdigs122, expdigs123, expdigs124, expdigs125, expdigs126, expdigs127, expdigs128, expdigs129, expdigs130, expdigs131, expdigs132, expdigs133, expdigs134, expdigs135, expdigs136, expdigs137, expdigs138, expdigs139, expdigs140, expdigs141, expdigs142, expdigs143, expdigs144, expdigs145, expdigs146, expdigs147 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7437 */   static final int[] nexpdigstable = { 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 13, 12, 12, 11, 11, 10, 10, 10, 9, 9, 8, 8, 8, 7, 7, 6, 6, 5, 5, 5, 4, 4, 3, 3, 3, 2, 2, 1, 1, 1, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7449 */   static final int[] binexpstable = { 90, 89, 89, 88, 88, 88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 83, 83, 83, 82, 82, 81, 81, 81, 80, 80, 79, 79, 78, 78, 78, 77, 77, 76, 76, 76, 75, 75, 74, 74, 73, 73, 73, 72, 72, 71, 71, 71, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66, 66, 66, 65, 65, 64, 64, 64, 63, 63, 62, 62, 61, 61, 61, 60, 60, 59, 59, 59, 58, 58, 57, 57, 56, 56, 56, 55, 55, 54, 54, 54, 53, 53, 52, 52, 51, 51, 51, 50, 50, 49, 49, 49, 48, 48, 47, 47, 46, 46, 46, 45, 45, 44, 44, 44, 43, 43, 42, 42, 41, 41, 41, 40, 40, 39, 39, 39, 38, 38, 37, 37, 37, 36, 36, 35, 35, 34, 34, 34, 33, 33, 32, 32, 32, 31, 31, 30, 30, 29, 29, 29 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void throwOverflow()
/*      */     throws SQLException
/*      */   {
/* 7465 */     DatabaseError.throwSqlException(26);
/*      */   }
/*      */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\NumberCommonAccessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */