package oracle.jdbc.driver;

public abstract interface Message
{
  public abstract String msg(String paramString, Object paramObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\Message.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */