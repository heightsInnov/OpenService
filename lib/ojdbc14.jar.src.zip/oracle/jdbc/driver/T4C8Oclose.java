/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T4C8Oclose
/*    */   extends T4CTTIfun
/*    */ {
/*    */   T4C8Oclose(T4CMAREngine paramT4CMAREngine)
/*    */     throws IOException, SQLException
/*    */   {
/* 28 */     super((byte)17, 0);
/*    */     
/* 30 */     setMarshalingEngine(paramT4CMAREngine);
/* 31 */     setFunCode((short)120);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   void initCloseQuery()
/*    */     throws IOException, SQLException
/*    */   {
/* 39 */     setFunCode((short)120);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   void initCloseStatement()
/*    */     throws IOException, SQLException
/*    */   {
/* 47 */     setFunCode((short)105);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   void marshal(int[] paramArrayOfInt, int paramInt)
/*    */     throws IOException
/*    */   {
/* 55 */     marshalFunHeader();
/*    */     
/*    */ 
/* 58 */     this.meg.marshalPTR();
/* 59 */     this.meg.marshalUB4(paramInt);
/*    */     
/* 61 */     for (int i = 0; i < paramInt; i++)
/*    */     {
/* 63 */       this.meg.marshalUB4(paramArrayOfInt[i]);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 72 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:30_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4C8Oclose.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */