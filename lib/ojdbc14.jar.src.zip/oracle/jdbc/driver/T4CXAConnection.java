/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import javax.transaction.xa.XAException;
/*    */ import javax.transaction.xa.XAResource;
/*    */ import oracle.jdbc.xa.OracleXAResource;
/*    */ import oracle.jdbc.xa.client.OracleXAConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class T4CXAConnection
/*    */   extends OracleXAConnection
/*    */ {
/*    */   T4CTTIOtxen otxen;
/*    */   T4CTTIOtxse otxse;
/*    */   T4CConnection physicalConnection;
/*    */   
/*    */   public T4CXAConnection(Connection paramConnection)
/*    */     throws XAException
/*    */   {
/* 36 */     super(paramConnection);
/*    */     
/*    */ 
/*    */ 
/* 40 */     this.physicalConnection = ((T4CConnection)paramConnection);
/* 41 */     this.xaResource = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized XAResource getXAResource()
/*    */   {
/*    */     try
/*    */     {
/* 51 */       if (this.xaResource == null)
/*    */       {
/* 53 */         this.xaResource = new T4CXAResource(this.physicalConnection, this, this.isXAResourceTransLoose);
/*    */         
/*    */ 
/* 56 */         if (this.logicalHandle != null)
/*    */         {
/*    */ 
/*    */ 
/* 60 */           ((OracleXAResource)this.xaResource).setLogicalConnection(this.logicalHandle);
/*    */         }
/*    */         
/*    */       }
/*    */       
/*    */ 
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 69 */       this.xaResource = null;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 74 */     return this.xaResource;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 79 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */   public static final boolean PRIVATE_TRACE = false;
/*    */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:33_PST_2006";
/*    */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4CXAConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */