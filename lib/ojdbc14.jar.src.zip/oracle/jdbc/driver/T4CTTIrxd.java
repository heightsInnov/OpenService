/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.BitSet;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIrxd
/*     */   extends T4CTTIMsg
/*     */ {
/*  47 */   static final byte[] NO_BYTES = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] buffer;
/*     */   
/*     */ 
/*     */   byte[] bufferCHAR;
/*     */   
/*     */ 
/*  57 */   BitSet bvcColSent = null;
/*  58 */   int nbOfColumns = 0;
/*  59 */   boolean bvcFound = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isFirstCol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   T4CTTIrxd(T4CMAREngine paramT4CMAREngine)
/*     */   {
/*  74 */     super((byte)7);
/*     */     
/*  76 */     setMarshalingEngine(paramT4CMAREngine);
/*     */     
/*  78 */     this.isFirstCol = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void init()
/*     */   {
/*  86 */     this.isFirstCol = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setNumberOfColumns(int paramInt)
/*     */   {
/*  94 */     this.nbOfColumns = paramInt;
/*  95 */     this.bvcFound = false;
/*     */     
/*     */ 
/*     */ 
/*  99 */     this.bvcColSent = new BitSet(this.nbOfColumns);
/*     */   }
/*     */   
/*     */   void unmarshalBVC(int paramInt) throws SQLException, IOException
/*     */   {
/* 104 */     int i = 0;
/*     */     
/*     */ 
/* 107 */     for (int j = 0; j < this.bvcColSent.length(); j++) {
/* 108 */       this.bvcColSent.clear(j);
/*     */     }
/*     */     
/*     */ 
/* 112 */     j = this.nbOfColumns / 8 + (this.nbOfColumns % 8 != 0 ? 1 : 0);
/*     */     
/*     */ 
/* 115 */     for (int k = 0; k < j; k++)
/*     */     {
/* 117 */       int m = (byte)(this.meg.unmarshalUB1() & 0xFF);
/*     */       
/* 119 */       for (int n = 0; n < 8; n++)
/*     */       {
/* 121 */         if ((m & 1 << n) != 0)
/*     */         {
/* 123 */           this.bvcColSent.set(k * 8 + n);
/*     */           
/* 125 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 130 */     if (i != paramInt)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */       DatabaseError.throwSqlException(-1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     this.bvcFound = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void readBitVector(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 153 */     for (int i = 0; i < this.bvcColSent.length(); i++) {
/* 154 */       this.bvcColSent.clear(i);
/*     */     }
/* 156 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/* 157 */       this.bvcFound = false;
/*     */     }
/*     */     else {
/* 160 */       for (i = 0; i < paramArrayOfByte.length; i++) {
/* 161 */         int j = paramArrayOfByte[i];
/* 162 */         for (int k = 0; k < 8; k++) {
/* 163 */           if ((j & 1 << k) != 0)
/* 164 */             this.bvcColSent.set(i * 8 + k);
/*     */         }
/*     */       }
/* 167 */       this.bvcFound = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void marshal(byte[] paramArrayOfByte1, char[] paramArrayOfChar1, short[] paramArrayOfShort1, int paramInt1, byte[] paramArrayOfByte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfByte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfByte3, char[] paramArrayOfChar2, short[] paramArrayOfShort2, byte[] paramArrayOfByte4, int paramInt2, int[] paramArrayOfInt1, boolean paramBoolean, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[][] paramArrayOfInt)
/*     */     throws IOException, SQLException
/*     */   {
/* 197 */     marshalTTCcode();
/*     */     
/*     */ 
/* 200 */     int i = paramArrayOfShort1[(paramInt1 + 0)] & 0xFFFF;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */     int i10 = 0;
/* 223 */     int i11 = paramArrayOfInt3[0];
/* 224 */     Object localObject1 = paramArrayOfInt[0];
/*     */     
/* 226 */     int i12 = 0;
/*     */     int i14;
/* 228 */     int j; int i7; int k; int i9; int m; int i8; int i22; int i23; int i4; int i6; int i5; int i1; int i3; int i17; int i19; for (int i13 = 0; i13 < i; i13++)
/*     */     {
/* 230 */       if ((i10 < i11) && (localObject1[i10] == i13))
/*     */       {
/*     */ 
/* 233 */         i10++;
/*     */       }
/*     */       else
/*     */       {
/* 237 */         i14 = 0;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */         j = paramInt1 + 3 + 10 * i13;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 249 */         i7 = paramArrayOfShort1[(j + 0)] & 0xFFFF;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 254 */         if ((paramArrayOfByte4 != null) && ((paramArrayOfByte4[i13] & 0x20) == 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 259 */           if (i7 == 998) {
/* 260 */             i12++;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 265 */           k = ((paramArrayOfShort1[(j + 7)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 8)] & 0xFFFF) + paramInt2;
/*     */           
/*     */ 
/*     */ 
/* 269 */           i9 = ((paramArrayOfShort1[(j + 5)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 6)] & 0xFFFF) + paramInt2;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 274 */           m = paramArrayOfShort1[k] & 0xFFFF;
/*     */           
/* 276 */           i8 = paramArrayOfShort1[i9];
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 281 */           if (i7 == 116)
/*     */           {
/* 283 */             this.meg.marshalUB1((short)1);
/* 284 */             this.meg.marshalUB1((short)0);
/*     */           }
/*     */           else
/*     */           {
/* 288 */             if (i7 == 994)
/*     */             {
/* 290 */               i8 = -1;
/* 291 */               int i15 = paramArrayOfInt2[(3 + i13 * 3 + 0)];
/*     */               
/*     */ 
/*     */ 
/* 295 */               if (i15 == 109) {
/* 296 */                 i14 = 1;
/*     */               }
/* 298 */             } else if ((i7 == 8) || (i7 == 24) || ((!paramBoolean) && (paramArrayOfInt1 != null) && (paramArrayOfInt1.length > i13) && (paramArrayOfInt1[i13] > 4000)))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 315 */               if (i11 >= localObject1.length)
/*     */               {
/* 317 */                 int[] arrayOfInt = new int[localObject1.length << 1];
/*     */                 
/*     */ 
/* 320 */                 System.arraycopy(localObject1, 0, arrayOfInt, 0, localObject1.length);
/*     */                 
/*     */ 
/*     */ 
/* 324 */                 localObject1 = arrayOfInt;
/*     */               }
/*     */               
/* 327 */               localObject1[(i11++)] = i13;
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 332 */               continue;
/*     */             }
/*     */             
/*     */ 
/* 336 */             if (i8 == -1)
/*     */             {
/* 338 */               if ((i7 == 109) || (i14 != 0))
/*     */               {
/*     */ 
/*     */ 
/* 342 */                 this.meg.marshalDALC(NO_BYTES);
/* 343 */                 this.meg.marshalDALC(NO_BYTES);
/* 344 */                 this.meg.marshalDALC(NO_BYTES);
/* 345 */                 this.meg.marshalUB2(0);
/* 346 */                 this.meg.marshalUB4(0L);
/* 347 */                 this.meg.marshalUB2(1);
/*     */                 
/* 349 */                 continue;
/*     */               }
/* 351 */               if (i7 == 998)
/*     */               {
/* 353 */                 i12++;
/* 354 */                 this.meg.marshalUB4(0L);
/* 355 */                 continue;
/*     */               }
/* 357 */               if ((i7 == 112) || (i7 == 113) || (i7 == 114))
/*     */               {
/* 359 */                 this.meg.marshalUB4(0L);
/* 360 */                 continue;
/*     */               }
/* 362 */               if ((i7 != 8) && (i7 != 24))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 372 */                 this.meg.marshalUB1((short)0);
/*     */                 
/* 374 */                 continue;
/*     */               } }
/*     */             int i18;
/*     */             int i24;
/* 378 */             if (i7 == 998)
/*     */             {
/*     */ 
/* 381 */               int i16 = (paramArrayOfShort2[(6 + i12 * 8 + 4)] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfShort2[(6 + i12 * 8 + 5)] & 0xFFFF;
/*     */               
/*     */ 
/* 384 */               i18 = (paramArrayOfShort2[(6 + i12 * 8 + 6)] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfShort2[(6 + i12 * 8 + 7)] & 0xFFFF;
/*     */               
/*     */ 
/* 387 */               int i20 = paramArrayOfShort2[(6 + i12 * 8)] & 0xFFFF;
/* 388 */               i22 = paramArrayOfShort2[(6 + i12 * 8 + 1)] & 0xFFFF;
/*     */               
/* 390 */               this.meg.marshalUB4(i16);
/*     */               
/* 392 */               for (i23 = 0; i23 < i16; i23++)
/*     */               {
/* 394 */                 i24 = i18 + i23 * i22;
/*     */                 
/* 396 */                 if (i20 == 9)
/*     */                 {
/* 398 */                   i4 = paramArrayOfChar2[i24] / '\002';
/* 399 */                   i6 = 0;
/* 400 */                   i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar2, i24 + 1, paramArrayOfByte2, 0, i4);
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 406 */                   this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */                 }
/*     */                 else
/*     */                 {
/* 410 */                   m = paramArrayOfByte3[i24];
/*     */                   
/* 412 */                   if (m < 1) {
/* 413 */                     this.meg.marshalUB1((short)0);
/*     */                   } else {
/* 415 */                     this.meg.marshalCLR(paramArrayOfByte3, i24 + 1, m);
/*     */                   }
/*     */                 }
/*     */               }
/* 419 */               i12++;
/*     */ 
/*     */ 
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/*     */ 
/* 428 */               int n = paramArrayOfShort1[(j + 1)] & 0xFFFF;
/*     */               
/*     */ 
/*     */ 
/* 432 */               if (n != 0)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 439 */                 int i2 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + n * paramInt2;
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 446 */                 if (i7 == 6)
/*     */                 {
/* 448 */                   i2++;
/* 449 */                   m--;
/*     */                 }
/* 451 */                 else if (i7 == 9)
/*     */                 {
/* 453 */                   i2 += 2;
/*     */                   
/* 455 */                   m -= 2;
/*     */                 }
/* 457 */                 else if ((i7 == 114) || (i7 == 113) || (i7 == 112))
/*     */                 {
/*     */ 
/* 460 */                   this.meg.marshalUB4(m);
/*     */                 }
/*     */                 
/*     */                 Object localObject2;
/* 464 */                 if ((i7 == 109) || (i7 == 111))
/*     */                 {
/* 466 */                   if (paramArrayOfByte == null)
/*     */                   {
/*     */ 
/*     */ 
/*     */ 
/* 471 */                     DatabaseError.throwSqlException(-1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/* 476 */                   localObject2 = paramArrayOfByte[i13];
/*     */                   
/* 478 */                   m = localObject2 == null ? 0 : localObject2.length;
/*     */                   
/* 480 */                   if (i7 == 109)
/*     */                   {
/* 482 */                     this.meg.marshalDALC(NO_BYTES);
/* 483 */                     this.meg.marshalDALC(NO_BYTES);
/* 484 */                     this.meg.marshalDALC(NO_BYTES);
/* 485 */                     this.meg.marshalUB2(0);
/*     */                     
/* 487 */                     this.meg.marshalUB4(m);
/* 488 */                     this.meg.marshalUB2(1);
/*     */                   }
/*     */                   
/* 491 */                   if (m > 0) {
/* 492 */                     this.meg.marshalCLR((byte[])localObject2, 0, m);
/*     */                   }
/* 494 */                 } else if (i7 == 104)
/*     */                 {
/*     */ 
/*     */ 
/* 498 */                   i2 += 2;
/*     */                   
/* 500 */                   localObject2 = T4CRowidAccessor.stringToRowid(paramArrayOfByte1, i2, 18);
/*     */                   
/* 502 */                   i18 = 14;
/* 503 */                   long l1 = localObject2[0];
/* 504 */                   i23 = (int)localObject2[1];
/* 505 */                   i24 = 0;
/* 506 */                   long l2 = localObject2[2];
/* 507 */                   int i25 = (int)localObject2[3];
/*     */                   
/*     */ 
/*     */ 
/* 511 */                   if ((l1 == 0L) && (i23 == 0) && (l2 == 0L) && (i25 == 0))
/*     */                   {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 517 */                     this.meg.marshalUB1((short)0);
/*     */                   }
/*     */                   else
/*     */                   {
/* 521 */                     this.meg.marshalUB1(i18);
/* 522 */                     this.meg.marshalUB4(l1);
/* 523 */                     this.meg.marshalUB2(i23);
/* 524 */                     this.meg.marshalUB1(i24);
/* 525 */                     this.meg.marshalUB4(l2);
/* 526 */                     this.meg.marshalUB2(i25);
/*     */                   }
/*     */                   
/*     */ 
/*     */                 }
/* 531 */                 else if (m < 1) {
/* 532 */                   this.meg.marshalUB1((short)0);
/*     */                 } else {
/* 534 */                   this.meg.marshalCLR(paramArrayOfByte1, i2, m);
/*     */ 
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/*     */ 
/* 544 */                 i5 = paramArrayOfShort1[(j + 9)] & 0xFFFF;
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 552 */                 i1 = paramArrayOfShort1[(j + 2)] & 0xFFFF;
/*     */                 
/*     */ 
/* 555 */                 i3 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + i1 * paramInt2 + 1;
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/* 560 */                 if (i7 == 996)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 569 */                   i17 = paramArrayOfChar1[(i3 - 1)];
/*     */                   
/* 571 */                   if ((this.bufferCHAR == null) || (this.bufferCHAR.length < i17)) {
/* 572 */                     this.bufferCHAR = new byte[i17];
/*     */                   }
/* 574 */                   for (i19 = 0; i19 < i17; i19++)
/*     */                   {
/* 576 */                     this.bufferCHAR[i19] = ((byte)((paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF00) >> '\b' & 0xFF));
/*     */                     
/*     */ 
/*     */ 
/* 580 */                     if (i19 < i17 - 1)
/*     */                     {
/* 582 */                       this.bufferCHAR[(i19 + 1)] = ((byte)(paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF & 0xFF));
/*     */                       
/*     */ 
/* 585 */                       i19++;
/*     */                     }
/*     */                   }
/*     */                   
/* 589 */                   this.meg.marshalCLR(this.bufferCHAR, i17);
/*     */                   
/* 591 */                   if (this.bufferCHAR.length > 4000) {
/* 592 */                     this.bufferCHAR = null;
/*     */ 
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */                 }
/*     */                 else
/*     */                 {
/*     */ 
/*     */ 
/* 603 */                   if (i7 == 96)
/*     */                   {
/*     */ 
/*     */ 
/* 607 */                     i4 = m / 2;
/* 608 */                     i3--;
/*     */                   }
/*     */                   else
/*     */                   {
/* 612 */                     i4 = (m - 2) / 2;
/*     */                   }
/*     */                   
/*     */ 
/* 616 */                   i6 = 0;
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 621 */                   if (i5 == 2)
/*     */                   {
/* 623 */                     i6 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */ 
/*     */                   }
/*     */                   else
/*     */                   {
/* 628 */                     i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 634 */                   this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 644 */     if (i11 > 0)
/*     */     {
/* 646 */       for (i13 = 0; i13 < i11; i13++)
/*     */       {
/* 648 */         i14 = localObject1[i13];
/*     */         
/* 650 */         j = paramInt1 + 3 + 10 * i14;
/*     */         
/*     */ 
/*     */ 
/* 654 */         i7 = paramArrayOfShort1[(j + 0)] & 0xFFFF;
/*     */         
/*     */ 
/*     */ 
/* 658 */         k = ((paramArrayOfShort1[(j + 7)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 8)] & 0xFFFF) + paramInt2;
/*     */         
/*     */ 
/*     */ 
/* 662 */         i9 = ((paramArrayOfShort1[(j + 5)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 6)] & 0xFFFF) + paramInt2;
/*     */         
/*     */ 
/*     */ 
/* 666 */         i8 = paramArrayOfShort1[i9];
/* 667 */         m = paramArrayOfShort1[k] & 0xFFFF;
/*     */         
/* 669 */         i1 = paramArrayOfShort1[(j + 2)] & 0xFFFF;
/*     */         
/*     */ 
/* 672 */         i3 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + i1 * paramInt2 + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 677 */         if (i8 == -1)
/*     */         {
/* 679 */           this.meg.marshalUB1((short)0);
/*     */ 
/*     */ 
/*     */         }
/* 683 */         else if (i7 == 996)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 692 */           i17 = paramArrayOfChar1[(i3 - 1)];
/*     */           
/* 694 */           if ((this.bufferCHAR == null) || (this.bufferCHAR.length < i17)) {
/* 695 */             this.bufferCHAR = new byte[i17];
/*     */           }
/* 697 */           for (i19 = 0; i19 < i17; i19++)
/*     */           {
/* 699 */             this.bufferCHAR[i19] = ((byte)((paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF00) >> '\b' & 0xFF));
/*     */             
/*     */ 
/*     */ 
/* 703 */             if (i19 < i17 - 1)
/*     */             {
/* 705 */               this.bufferCHAR[(i19 + 1)] = ((byte)(paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF & 0xFF));
/*     */               
/* 707 */               i19++;
/*     */             }
/*     */           }
/*     */           
/* 711 */           this.meg.marshalCLR(this.bufferCHAR, i17);
/*     */           
/* 713 */           if (this.bufferCHAR.length > 4000) {
/* 714 */             this.bufferCHAR = null;
/*     */           }
/* 716 */         } else if ((i7 != 8) && (i7 != 24))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 723 */           if (i7 == 96)
/*     */           {
/*     */ 
/*     */ 
/* 727 */             i4 = m / 2;
/* 728 */             i3--;
/*     */           }
/*     */           else
/*     */           {
/* 732 */             i4 = (m - 2) / 2;
/*     */           }
/*     */           
/* 735 */           i5 = paramArrayOfShort1[(j + 9)] & 0xFFFF;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 740 */           i6 = 0;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 745 */           if (i5 == 2)
/*     */           {
/* 747 */             i6 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 752 */             i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 758 */           this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 763 */           i17 = i14;
/*     */           
/*     */ 
/*     */ 
/* 767 */           if (paramArrayOfInputStream != null)
/*     */           {
/* 769 */             InputStream localInputStream = paramArrayOfInputStream[i17];
/*     */             
/* 771 */             if (localInputStream != null)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 776 */               int i21 = 64;
/*     */               
/* 778 */               if (this.buffer == null) {
/* 779 */                 this.buffer = new byte[i21];
/*     */               }
/* 781 */               i22 = 0;
/*     */               
/*     */ 
/* 784 */               this.meg.marshalUB1((short)254);
/*     */               
/* 786 */               i23 = 0;
/*     */               
/* 788 */               while (i23 == 0)
/*     */               {
/* 790 */                 i22 = localInputStream.read(this.buffer, 0, i21);
/*     */                 
/* 792 */                 if (i22 < i21) {
/* 793 */                   i23 = 1;
/*     */                 }
/* 795 */                 if (i22 > 0)
/*     */                 {
/*     */ 
/*     */ 
/* 799 */                   this.meg.marshalUB1((short)(i22 & 0xFF));
/*     */                   
/*     */ 
/* 802 */                   this.meg.marshalB1Array(this.buffer, 0, i22);
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/* 807 */               this.meg.marshalSB1((byte)0);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 826 */     paramArrayOfInt3[0] = i11;
/* 827 */     paramArrayOfInt[0] = localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 843 */     return unmarshal(paramArrayOfAccessor, 0, paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2)
/*     */     throws SQLException, IOException
/*     */   {
/* 861 */     if (paramInt1 == 0) {
/* 862 */       this.isFirstCol = true;
/*     */     }
/* 864 */     for (int i = paramInt1; (i < paramInt2) && (i < paramArrayOfAccessor.length); i++)
/*     */     {
/* 866 */       if (paramArrayOfAccessor[i] != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 883 */         if (paramArrayOfAccessor[i].physicalColumnIndex < 0)
/*     */         {
/*     */ 
/*     */ 
/* 887 */           int j = 0;
/*     */           
/* 889 */           for (int k = 0; (k < paramInt2) && (k < paramArrayOfAccessor.length); k++)
/*     */           {
/* 891 */             if (paramArrayOfAccessor[k] != null)
/*     */             {
/* 893 */               paramArrayOfAccessor[k].physicalColumnIndex = j;
/*     */               
/* 895 */               if (!paramArrayOfAccessor[k].isUseLess) {
/* 896 */                 j++;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 901 */         if ((this.bvcFound) && (!paramArrayOfAccessor[i].isUseLess))
/*     */         {
/* 903 */           if (this.bvcColSent.get(paramArrayOfAccessor[i].physicalColumnIndex))
/*     */           {
/* 905 */             if (paramArrayOfAccessor[i].unmarshalOneRow()) {
/* 906 */               return true;
/*     */             }
/* 908 */             this.isFirstCol = false;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 914 */             paramArrayOfAccessor[i].copyRow();
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 919 */           if (paramArrayOfAccessor[i].unmarshalOneRow()) {
/* 920 */             return true;
/*     */           }
/* 922 */           this.isFirstCol = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 927 */     this.bvcFound = false;
/*     */     
/*     */ 
/*     */ 
/* 931 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3)
/*     */     throws SQLException, IOException
/*     */   {
/* 946 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 951 */   private static final String _Copyright_2004_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   public static final boolean PRIVATE_TRACE = false;
/*     */   public static final String BUILD_DATE = "Tue_Jan_24_08:54:32_PST_2006";
/*     */ }


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\jdbc\driver\T4CTTIrxd.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */