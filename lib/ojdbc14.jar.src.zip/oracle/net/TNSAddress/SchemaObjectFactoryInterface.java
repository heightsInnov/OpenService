package oracle.net.TNSAddress;

public abstract interface SchemaObjectFactoryInterface
{
  public static final int ADDR = 0;
  public static final int ADDR_LIST = 1;
  public static final int DESC = 2;
  public static final int DESC_LIST = 3;
  public static final int ALIAS = 4;
  public static final int SERVICE = 5;
  public static final int DB_SERVICE = 6;
  
  public abstract SchemaObject create(int paramInt);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\TNSAddress\SchemaObjectFactoryInterface.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */