package oracle.net.TNSAddress;

import oracle.net.nl.NLException;
import oracle.net.nl.NVFactory;
import oracle.net.nl.NVNavigator;
import oracle.net.nl.NVPair;

public class Address
  implements SchemaObject
{
  public String addr;
  public String prot;
  protected SchemaObjectFactoryInterface f = null;
  
  public Address(SchemaObjectFactoryInterface paramSchemaObjectFactoryInterface)
  {
    this.f = paramSchemaObjectFactoryInterface;
  }
  
  public int isA()
  {
    return 0;
  }
  
  public String isA_String()
  {
    return "ADDRESS";
  }
  
  public void initFromString(String paramString)
    throws NLException, SOException
  {
    NVPair localNVPair = new NVFactory().createNVPair(paramString);
    initFromNVPair(localNVPair);
  }
  
  public void initFromNVPair(NVPair paramNVPair)
    throws SOException
  {
    init();
    if ((paramNVPair == null) || (!paramNVPair.getName().equalsIgnoreCase("address"))) {
      throw new SOException();
    }
    NVNavigator localNVNavigator = new NVNavigator();
    NVPair localNVPair = localNVNavigator.findNVPair(paramNVPair, "PROTOCOL");
    if (localNVPair == null) {
      throw new SOException();
    }
    this.prot = localNVPair.getAtom();
    if (this.addr == null) {
      this.addr = paramNVPair.toString();
    }
  }
  
  public String toString()
  {
    return this.addr;
  }
  
  public String getProtocol()
  {
    return this.prot;
  }
  
  protected void init()
  {
    this.addr = null;
    this.prot = null;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\TNSAddress\Address.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */