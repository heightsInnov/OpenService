package oracle.net.TNSAddress;

public class SOException
  extends Throwable
{
  public String error = null;
  
  public SOException() {}
  
  public SOException(String paramString)
  {
    super(paramString);
    this.error = paramString;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\TNSAddress\SOException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */