package oracle.net.aso;

public abstract interface C07
{
  public abstract byte a();
  
  public abstract void b();
  
  public abstract byte[] c();
  
  public abstract void d();
  
  public abstract void e();
  
  public abstract void f();
  
  public abstract byte[] g();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\aso\C07.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */