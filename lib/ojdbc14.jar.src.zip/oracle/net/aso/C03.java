package oracle.net.aso;

public abstract interface C03
{
  public abstract int takeSessionKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract void renew();
  
  public abstract boolean compare(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract byte[] compute(byte[] paramArrayOfByte, int paramInt);
  
  public abstract void init(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract int size();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\aso\C03.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */