package oracle.net.aso;

public abstract interface C00
{
  public static final int f = 220;
  public static final int g = 256;
  public static final int h = 0;
  public static final int i = 4;
  public static final int j = 1;
  public static final int k = 223;
  public static final int l = 222;
  public static final int m = 128;
  public static final int n = 56;
  public static final int o = 2;
  public static final int p = 142;
  public static final int q = 141;
  public static final int r = 211;
  public static final int s = 210;
  public static final int t = 140;
  public static final int u = 40;
  public static final int v = 143;
  public static final int w = 3;
  public static final int x = 213;
  public static final int y = 212;
  public static final int z = 221;
  
  public abstract void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws C02;
  
  public abstract int b();
  
  public abstract void c(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws C02;
  
  public abstract byte[] d(byte[] paramArrayOfByte)
    throws C02;
  
  public abstract byte[] e(byte[] paramArrayOfByte)
    throws C02;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\aso\C00.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */