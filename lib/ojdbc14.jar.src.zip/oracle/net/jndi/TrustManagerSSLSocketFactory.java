package oracle.net.jndi;

import javax.net.ssl.SSLContext;

public final class TrustManagerSSLSocketFactory
  extends CustomSSLSocketFactory
{
  private static final boolean DEBUG = false;
  
  protected void setDefaultFactory()
  {
    try
    {
      SSLContext localSSLContext = SSLContext.getInstance("SSL");
      localSSLContext.init(null, new javax.net.ssl.TrustManager[] { new TrustManager() }, null);
      setFactory(localSSLContext.getSocketFactory());
    }
    catch (Exception localException)
    {
      super.setDefaultFactory();
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\jndi\TrustManagerSSLSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */