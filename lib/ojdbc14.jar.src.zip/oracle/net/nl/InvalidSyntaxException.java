package oracle.net.nl;

public class InvalidSyntaxException
  extends NLException
{
  public InvalidSyntaxException(String paramString)
  {
    super(paramString);
  }
  
  public InvalidSyntaxException(String paramString, Object paramObject)
  {
    super(paramString, paramObject);
  }
  
  public InvalidSyntaxException(String paramString, Object[] paramArrayOfObject)
  {
    super(paramString, paramArrayOfObject);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\ojdbc14.jar!\oracle\net\nl\InvalidSyntaxException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */