package org.bouncycastle.tsp;

import java.io.IOException;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.Date;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.tsp.Accuracy;
import org.bouncycastle.asn1.tsp.MessageImprint;
import org.bouncycastle.asn1.tsp.TSTInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class TimeStampTokenInfo
{
  TSTInfo tstInfo;
  Date genTime;
  
  TimeStampTokenInfo(TSTInfo paramTSTInfo)
    throws TSPException, IOException
  {
    this.tstInfo = paramTSTInfo;
    try
    {
      this.genTime = paramTSTInfo.getGenTime().getDate();
    }
    catch (ParseException localParseException)
    {
      throw new TSPException("unable to parse genTime field");
    }
  }
  
  public boolean isOrdered()
  {
    return this.tstInfo.getOrdering().isTrue();
  }
  
  public Accuracy getAccuracy()
  {
    return this.tstInfo.getAccuracy();
  }
  
  public Date getGenTime()
  {
    return this.genTime;
  }
  
  public GenTimeAccuracy getGenTimeAccuracy()
  {
    if (getAccuracy() != null) {
      return new GenTimeAccuracy(getAccuracy());
    }
    return null;
  }
  
  public String getPolicy()
  {
    return this.tstInfo.getPolicy().getId();
  }
  
  public BigInteger getSerialNumber()
  {
    return this.tstInfo.getSerialNumber().getValue();
  }
  
  public BigInteger getNonce()
  {
    if (this.tstInfo.getNonce() != null) {
      return this.tstInfo.getNonce().getValue();
    }
    return null;
  }
  
  public String getMessageImprintAlgOID()
  {
    return this.tstInfo.getMessageImprint().getHashAlgorithm().getObjectId().getId();
  }
  
  public byte[] getMessageImprintDigest()
  {
    return this.tstInfo.getMessageImprint().getHashedMessage();
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.tstInfo.getEncoded();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctsp-jdk16-137.jar!\org\bouncycastle\tsp\TimeStampTokenInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */