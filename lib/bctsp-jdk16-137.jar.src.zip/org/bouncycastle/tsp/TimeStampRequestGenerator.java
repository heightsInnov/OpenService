package org.bouncycastle.tsp;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.tsp.MessageImprint;
import org.bouncycastle.asn1.tsp.TimeStampReq;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;

public class TimeStampRequestGenerator
{
  private DERObjectIdentifier reqPolicy;
  private DERBoolean certReq;
  private Hashtable extensions = new Hashtable();
  private Vector extOrdering = new Vector();
  
  public void setReqPolicy(String paramString)
  {
    this.reqPolicy = new DERObjectIdentifier(paramString);
  }
  
  public void setCertReq(boolean paramBoolean)
  {
    this.certReq = new DERBoolean(paramBoolean);
  }
  
  public void addExtension(String paramString, boolean paramBoolean, ASN1Encodable paramASN1Encodable)
    throws IOException
  {
    addExtension(paramString, paramBoolean, paramASN1Encodable.getEncoded());
  }
  
  public void addExtension(String paramString, boolean paramBoolean, byte[] paramArrayOfByte)
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString);
    this.extensions.put(localDERObjectIdentifier, new X509Extension(paramBoolean, new DEROctetString(paramArrayOfByte)));
    this.extOrdering.addElement(localDERObjectIdentifier);
  }
  
  public TimeStampRequest generate(String paramString, byte[] paramArrayOfByte)
  {
    return generate(paramString, paramArrayOfByte, null);
  }
  
  public TimeStampRequest generate(String paramString, byte[] paramArrayOfByte, BigInteger paramBigInteger)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("No digest algorithm specified");
    }
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier(paramString);
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(localDERObjectIdentifier, new DERNull());
    MessageImprint localMessageImprint = new MessageImprint(localAlgorithmIdentifier, paramArrayOfByte);
    X509Extensions localX509Extensions = null;
    if (this.extOrdering.size() != 0) {
      localX509Extensions = new X509Extensions(this.extOrdering, this.extensions);
    }
    if (paramBigInteger != null) {
      return new TimeStampRequest(new TimeStampReq(localMessageImprint, this.reqPolicy, new DERInteger(paramBigInteger), this.certReq, localX509Extensions));
    }
    return new TimeStampRequest(new TimeStampReq(localMessageImprint, this.reqPolicy, null, this.certReq, localX509Extensions));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctsp-jdk16-137.jar!\org\bouncycastle\tsp\TimeStampRequestGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */