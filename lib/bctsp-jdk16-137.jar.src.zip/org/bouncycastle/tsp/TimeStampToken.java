package org.bouncycastle.tsp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertStore;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.ess.ESSCertID;
import org.bouncycastle.asn1.ess.SigningCertificate;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.tsp.TSTInfo;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.IssuerSerial;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerId;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;

public class TimeStampToken
{
  CMSSignedData tsToken;
  SignerInformation tsaSignerInfo;
  Date genTime;
  TimeStampTokenInfo tstInfo;
  ESSCertID certID;
  
  TimeStampToken(ContentInfo paramContentInfo)
    throws TSPException, IOException
  {
    this(new CMSSignedData(paramContentInfo));
  }
  
  public TimeStampToken(CMSSignedData paramCMSSignedData)
    throws TSPException, IOException
  {
    this.tsToken = paramCMSSignedData;
    if (!this.tsToken.getSignedContentTypeOID().equals(PKCSObjectIdentifiers.id_ct_TSTInfo.getId())) {
      throw new TSPValidationException("ContentInfo object not for a time stamp.");
    }
    Collection localCollection = this.tsToken.getSignerInfos().getSigners();
    if (localCollection.size() != 1) {
      throw new IllegalArgumentException("Time-stamp token signed by " + localCollection.size() + " signers, but it must contain just the TSA signature.");
    }
    this.tsaSignerInfo = ((SignerInformation)localCollection.iterator().next());
    try
    {
      CMSProcessable localCMSProcessable = this.tsToken.getSignedContent();
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localCMSProcessable.write(localByteArrayOutputStream);
      ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
      this.tstInfo = new TimeStampTokenInfo(TSTInfo.getInstance(localASN1InputStream.readObject()));
      Attribute localAttribute = this.tsaSignerInfo.getSignedAttributes().get(PKCSObjectIdentifiers.id_aa_signingCertificate);
      if (localAttribute == null) {
        throw new TSPValidationException("no signing certificate attribute found, time stamp invalid.");
      }
      SigningCertificate localSigningCertificate = SigningCertificate.getInstance(localAttribute.getAttrValues().getObjectAt(0));
      this.certID = ESSCertID.getInstance(localSigningCertificate.getCerts()[0]);
    }
    catch (CMSException localCMSException)
    {
      throw new TSPException(localCMSException.getMessage(), localCMSException.getUnderlyingException());
    }
  }
  
  public TimeStampTokenInfo getTimeStampInfo()
  {
    return this.tstInfo;
  }
  
  public SignerId getSID()
  {
    return this.tsaSignerInfo.getSID();
  }
  
  public AttributeTable getSignedAttributes()
  {
    return this.tsaSignerInfo.getSignedAttributes();
  }
  
  public AttributeTable getUnsignedAttributes()
  {
    return this.tsaSignerInfo.getUnsignedAttributes();
  }
  
  public CertStore getCertificatesAndCRLs(String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    return this.tsToken.getCertificatesAndCRLs(paramString1, paramString2);
  }
  
  public void validate(X509Certificate paramX509Certificate, String paramString)
    throws TSPException, TSPValidationException, CertificateExpiredException, CertificateNotYetValidException, NoSuchProviderException
  {
    try
    {
      if (!MessageDigest.isEqual(this.certID.getCertHash(), MessageDigest.getInstance("SHA-1").digest(paramX509Certificate.getEncoded()))) {
        throw new TSPValidationException("certificate hash does not match certID hash.");
      }
      if (this.certID.getIssuerSerial() != null)
      {
        if (!this.certID.getIssuerSerial().getSerial().getValue().equals(paramX509Certificate.getSerialNumber())) {
          throw new TSPValidationException("certificate serial number does not match certID for signature.");
        }
        GeneralName[] arrayOfGeneralName = this.certID.getIssuerSerial().getIssuer().getNames();
        X509Principal localX509Principal = PrincipalUtil.getIssuerX509Principal(paramX509Certificate);
        int i = 0;
        for (int j = 0; j != arrayOfGeneralName.length; j++) {
          if ((arrayOfGeneralName[j].getTagNo() == 4) && (new X509Principal(X509Name.getInstance(arrayOfGeneralName[j].getName())).equals(localX509Principal)))
          {
            i = 1;
            break;
          }
        }
        if (i == 0) {
          throw new TSPValidationException("certificate name does not match certID for signature. ");
        }
      }
      TSPUtil.validateCertificate(paramX509Certificate);
      paramX509Certificate.checkValidity(this.tstInfo.getGenTime());
      if (!this.tsaSignerInfo.verify(paramX509Certificate, paramString)) {
        throw new TSPValidationException("signature not created by certificate.");
      }
    }
    catch (CMSException localCMSException)
    {
      if (localCMSException.getUnderlyingException() != null) {
        throw new TSPException(localCMSException.getMessage(), localCMSException.getUnderlyingException());
      }
      throw new TSPException("CMS exception: " + localCMSException, localCMSException);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new TSPException("cannot find algorithm: " + localNoSuchAlgorithmException, localNoSuchAlgorithmException);
    }
    catch (CertificateEncodingException localCertificateEncodingException)
    {
      throw new TSPException("problem processing certificate: " + localCertificateEncodingException, localCertificateEncodingException);
    }
  }
  
  public CMSSignedData toCMSSignedData()
  {
    return this.tsToken;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    return this.tsToken.getEncoded();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctsp-jdk16-137.jar!\org\bouncycastle\tsp\TimeStampToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */