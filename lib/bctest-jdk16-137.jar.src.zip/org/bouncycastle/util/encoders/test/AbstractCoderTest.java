package org.bouncycastle.util.encoders.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import junit.framework.TestCase;
import org.bouncycastle.util.encoders.Encoder;

public abstract class AbstractCoderTest
  extends TestCase
{
  private static final int[] SIZES_TO_CHECK = { 64, 128, 1024, 1025, 1026, 2048, 2049, 2050, 4096, 4097, 4098, 8192, 8193, 8194 };
  protected Encoder enc;
  private Random r;
  
  AbstractCoderTest(String paramString)
  {
    super(paramString);
  }
  
  protected void setUp()
  {
    this.r = new Random();
  }
  
  private void checkArrayOfSize(int paramInt)
    throws IOException
  {
    byte[] arrayOfByte1 = new byte[paramInt];
    this.r.nextBytes(arrayOfByte1);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.enc.encode(arrayOfByte1, 0, arrayOfByte1.length, localByteArrayOutputStream);
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    assertTrue(arrayOfByte2.length > arrayOfByte1.length);
    assertTrue(arrayOfByte2.length <= arrayOfByte1.length * 2);
    checkEncoding(arrayOfByte2);
    checkSimpleDecode(arrayOfByte1, arrayOfByte2);
    checkStringDecode(arrayOfByte1, arrayOfByte2);
    checkOutputStreamDecode(arrayOfByte1, arrayOfByte2);
    int i = this.r.nextInt(20);
    byte[] arrayOfByte3 = new byte[i + arrayOfByte2.length];
    System.arraycopy(arrayOfByte2, 0, arrayOfByte3, i, arrayOfByte2.length);
    checkOffsetDecode(arrayOfByte1, arrayOfByte3, i, arrayOfByte2.length);
    i = this.r.nextInt(20);
    byte[] arrayOfByte4 = new byte[i + arrayOfByte1.length];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte4, i, arrayOfByte1.length);
    checkOffsetEncode(arrayOfByte1, arrayOfByte4, i, arrayOfByte1.length);
    byte[] arrayOfByte5 = addWhitespace(arrayOfByte2);
    checkSimpleDecode(arrayOfByte1, arrayOfByte5);
    checkStringDecode(arrayOfByte1, arrayOfByte5);
    checkOutputStreamDecode(arrayOfByte1, arrayOfByte5);
  }
  
  public void testEncode()
    throws IOException
  {
    for (int i = 0; i < SIZES_TO_CHECK.length; i++) {
      checkArrayOfSize(SIZES_TO_CHECK[i]);
    }
  }
  
  private void checkEncoding(byte[] paramArrayOfByte)
  {
    String str = convertBytesToString(paramArrayOfByte);
    for (int i = 0; i < str.length(); i++)
    {
      char c = str.charAt(i);
      if (c == paddingChar()) {
        assertTrue(i > str.length() - 3);
      } else if (!isEncodedChar(c)) {
        fail("Unexpected encoded character " + c);
      }
    }
  }
  
  private void checkOutputStreamDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    String str = convertBytesToString(paramArrayOfByte2);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      assertEquals(paramArrayOfByte1.length, this.enc.decode(str, localByteArrayOutputStream));
      assertTrue(Arrays.equals(paramArrayOfByte1, localByteArrayOutputStream.toByteArray()));
    }
    catch (IOException localIOException)
    {
      fail("This shouldn't happen");
    }
  }
  
  private void checkSimpleDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.enc.decode(paramArrayOfByte2, 0, paramArrayOfByte2.length, localByteArrayOutputStream);
    assertTrue(Arrays.equals(paramArrayOfByte1, localByteArrayOutputStream.toByteArray()));
  }
  
  private void checkOffsetEncode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.enc.encode(paramArrayOfByte2, paramInt1, paramInt2, localByteArrayOutputStream);
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    localByteArrayOutputStream.reset();
    this.enc.decode(arrayOfByte, 0, arrayOfByte.length, localByteArrayOutputStream);
    assertTrue(Arrays.equals(paramArrayOfByte1, localByteArrayOutputStream.toByteArray()));
  }
  
  private void checkOffsetDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.enc.decode(paramArrayOfByte2, paramInt1, paramInt2, localByteArrayOutputStream);
    assertTrue(Arrays.equals(paramArrayOfByte1, localByteArrayOutputStream.toByteArray()));
  }
  
  private void checkStringDecode(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws IOException
  {
    String str = convertBytesToString(paramArrayOfByte2);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.enc.decode(str, localByteArrayOutputStream);
    assertTrue(Arrays.equals(paramArrayOfByte1, localByteArrayOutputStream.toByteArray()));
  }
  
  private byte[] addWhitespace(byte[] paramArrayOfByte)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    addSpace(localByteArrayOutputStream);
    for (int i = 0; i < paramArrayOfByte.length - 5; i++)
    {
      localByteArrayOutputStream.write(paramArrayOfByte, i, 1);
      if (this.r.nextInt(100) < 5) {
        addSpace(localByteArrayOutputStream);
      }
    }
    for (i = paramArrayOfByte.length - 5; i < paramArrayOfByte.length; i++) {
      localByteArrayOutputStream.write(paramArrayOfByte, i, 1);
    }
    addSpace(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  private void addSpace(ByteArrayOutputStream paramByteArrayOutputStream)
  {
    do
    {
      switch (this.r.nextInt(3))
      {
      case 0: 
        paramByteArrayOutputStream.write(10);
        break;
      case 1: 
        paramByteArrayOutputStream.write(13);
        break;
      case 2: 
        paramByteArrayOutputStream.write(9);
        break;
      case 3: 
        paramByteArrayOutputStream.write(32);
      }
    } while (this.r.nextBoolean());
  }
  
  private String convertBytesToString(byte[] paramArrayOfByte)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i != paramArrayOfByte.length; i++) {
      localStringBuffer.append((char)(paramArrayOfByte[i] & 0xFF));
    }
    return localStringBuffer.toString();
  }
  
  protected abstract char paddingChar();
  
  protected abstract boolean isEncodedChar(char paramChar);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\AbstractCoderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */