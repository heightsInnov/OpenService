package org.bouncycastle.util.encoders.test;

import org.bouncycastle.util.encoders.UrlBase64Encoder;

public class UrlBase64Test
  extends AbstractCoderTest
{
  public UrlBase64Test(String paramString)
  {
    super(paramString);
  }
  
  protected void setUp()
  {
    super.setUp();
    this.enc = new UrlBase64Encoder();
  }
  
  protected char paddingChar()
  {
    return '.';
  }
  
  protected boolean isEncodedChar(char paramChar)
  {
    if (Character.isLetterOrDigit(paramChar)) {
      return true;
    }
    if (paramChar == '-') {
      return true;
    }
    return paramChar == '_';
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\UrlBase64Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */