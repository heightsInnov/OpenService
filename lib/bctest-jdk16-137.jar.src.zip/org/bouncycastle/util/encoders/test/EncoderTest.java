package org.bouncycastle.util.encoders.test;

import java.util.Arrays;
import java.util.Random;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class EncoderTest
  extends SimpleTest
{
  public static final boolean DEBUG = true;
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new EncoderTest());
  }
  
  public String getName()
  {
    return "Encoder";
  }
  
  public void performTest()
  {
    testHex();
    testBase64();
    testBase64WithNL();
  }
  
  public void testBase64()
  {
    try
    {
      Random localRandom = new Random();
      byte[] arrayOfByte1 = new byte['Ѐ'];
      localRandom.nextBytes(arrayOfByte1);
      byte[] arrayOfByte2 = new byte['ࠀ'];
      localRandom.nextBytes(arrayOfByte2);
      byte[] arrayOfByte3 = new byte['က'];
      localRandom.nextBytes(arrayOfByte3);
      byte[] arrayOfByte4 = new byte[' '];
      localRandom.nextBytes(arrayOfByte4);
      byte[] arrayOfByte5 = Base64.encode(arrayOfByte1);
      byte[] arrayOfByte6 = Base64.encode(arrayOfByte2);
      byte[] arrayOfByte7 = Base64.encode(arrayOfByte3);
      byte[] arrayOfByte8 = Base64.encode(arrayOfByte4);
      byte[] arrayOfByte9 = Base64.decode(arrayOfByte5);
      byte[] arrayOfByte10 = Base64.decode(arrayOfByte6);
      byte[] arrayOfByte11 = Base64.decode(arrayOfByte7);
      byte[] arrayOfByte12 = Base64.decode(arrayOfByte8);
      if (!Arrays.equals(arrayOfByte1, arrayOfByte9)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte2, arrayOfByte10)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte3, arrayOfByte11)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte4, arrayOfByte12)) {
        fail("Failed Base64 test");
      }
      byte[] arrayOfByte13 = new byte['Ё'];
      localRandom.nextBytes(arrayOfByte13);
      byte[] arrayOfByte14 = new byte['ࠁ'];
      localRandom.nextBytes(arrayOfByte14);
      byte[] arrayOfByte15 = new byte['ခ'];
      localRandom.nextBytes(arrayOfByte15);
      byte[] arrayOfByte16 = new byte[' '];
      localRandom.nextBytes(arrayOfByte16);
      byte[] arrayOfByte17 = Base64.encode(arrayOfByte13);
      byte[] arrayOfByte18 = Base64.encode(arrayOfByte14);
      byte[] arrayOfByte19 = Base64.encode(arrayOfByte15);
      byte[] arrayOfByte20 = Base64.encode(arrayOfByte16);
      byte[] arrayOfByte21 = Base64.decode(arrayOfByte17);
      byte[] arrayOfByte22 = Base64.decode(arrayOfByte18);
      byte[] arrayOfByte23 = Base64.decode(arrayOfByte19);
      byte[] arrayOfByte24 = Base64.decode(arrayOfByte20);
      if (!Arrays.equals(arrayOfByte13, arrayOfByte21)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte14, arrayOfByte22)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte15, arrayOfByte23)) {
        fail("Failed Base64 test");
      }
      if (!Arrays.equals(arrayOfByte16, arrayOfByte24)) {
        fail("Failed Base64 test");
      }
    }
    catch (Exception localException)
    {
      fail("Failed Base64 test");
    }
  }
  
  public void testBase64WithNL()
  {
    byte[] arrayOfByte = Base64.decode("SVNC\nQUQ=\n");
    if (arrayOfByte.length != 5) {
      fail("got length " + arrayOfByte.length + " when expecting 10");
    }
    if (!areEqual(arrayOfByte, Base64.decode("SVNCQUQ="))) {
      fail("decodings are not equal");
    }
  }
  
  public void testHex()
  {
    try
    {
      Random localRandom = new Random();
      byte[] arrayOfByte1 = new byte['Ѐ'];
      localRandom.nextBytes(arrayOfByte1);
      byte[] arrayOfByte2 = new byte['ࠀ'];
      localRandom.nextBytes(arrayOfByte2);
      byte[] arrayOfByte3 = new byte['က'];
      localRandom.nextBytes(arrayOfByte3);
      byte[] arrayOfByte4 = new byte[' '];
      localRandom.nextBytes(arrayOfByte4);
      byte[] arrayOfByte5 = Hex.encode(arrayOfByte1);
      byte[] arrayOfByte6 = Hex.encode(arrayOfByte2);
      byte[] arrayOfByte7 = Hex.encode(arrayOfByte3);
      byte[] arrayOfByte8 = Hex.encode(arrayOfByte4);
      byte[] arrayOfByte9 = Hex.decode(arrayOfByte5);
      byte[] arrayOfByte10 = Hex.decode(arrayOfByte6);
      byte[] arrayOfByte11 = Hex.decode(arrayOfByte7);
      byte[] arrayOfByte12 = Hex.decode(arrayOfByte8);
      if (!Arrays.equals(arrayOfByte1, arrayOfByte9)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte2, arrayOfByte10)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte3, arrayOfByte11)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte4, arrayOfByte12)) {
        fail("Failed Hex test");
      }
      byte[] arrayOfByte13 = new byte['Ё'];
      localRandom.nextBytes(arrayOfByte13);
      byte[] arrayOfByte14 = new byte['ࠁ'];
      localRandom.nextBytes(arrayOfByte14);
      byte[] arrayOfByte15 = new byte['ခ'];
      localRandom.nextBytes(arrayOfByte15);
      byte[] arrayOfByte16 = new byte[' '];
      localRandom.nextBytes(arrayOfByte16);
      byte[] arrayOfByte17 = Hex.encode(arrayOfByte13);
      byte[] arrayOfByte18 = Hex.encode(arrayOfByte14);
      byte[] arrayOfByte19 = Hex.encode(arrayOfByte15);
      byte[] arrayOfByte20 = Hex.encode(arrayOfByte16);
      byte[] arrayOfByte21 = Hex.decode(arrayOfByte17);
      byte[] arrayOfByte22 = Hex.decode(arrayOfByte18);
      byte[] arrayOfByte23 = Hex.decode(arrayOfByte19);
      byte[] arrayOfByte24 = Hex.decode(arrayOfByte20);
      if (!Arrays.equals(arrayOfByte13, arrayOfByte21)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte14, arrayOfByte22)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte15, arrayOfByte23)) {
        fail("Failed Hex test");
      }
      if (!Arrays.equals(arrayOfByte16, arrayOfByte24)) {
        fail("Failed Hex test");
      }
    }
    catch (Exception localException)
    {
      fail("Failed Hex test");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\EncoderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */