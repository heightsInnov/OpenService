package org.bouncycastle.util.encoders.test;

import org.bouncycastle.util.encoders.HexEncoder;

public class HexTest
  extends AbstractCoderTest
{
  public HexTest(String paramString)
  {
    super(paramString);
  }
  
  protected void setUp()
  {
    super.setUp();
    this.enc = new HexEncoder();
  }
  
  protected char paddingChar()
  {
    return '\000';
  }
  
  protected boolean isEncodedChar(char paramChar)
  {
    if (('A' <= paramChar) && (paramChar <= 'F')) {
      return true;
    }
    if (('a' <= paramChar) && (paramChar <= 'f')) {
      return true;
    }
    return ('0' <= paramChar) && (paramChar <= '9');
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\HexTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */