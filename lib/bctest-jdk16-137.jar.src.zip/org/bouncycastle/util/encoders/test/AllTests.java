package org.bouncycastle.util.encoders.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class AllTests
{
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
  {
    TestSuite localTestSuite = new TestSuite("encoder tests");
    localTestSuite.addTestSuite(Base64Test.class);
    localTestSuite.addTestSuite(UrlBase64Test.class);
    localTestSuite.addTestSuite(HexTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */