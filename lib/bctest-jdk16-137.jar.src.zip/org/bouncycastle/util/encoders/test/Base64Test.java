package org.bouncycastle.util.encoders.test;

import org.bouncycastle.util.encoders.Base64Encoder;

public class Base64Test
  extends AbstractCoderTest
{
  public Base64Test(String paramString)
  {
    super(paramString);
  }
  
  protected void setUp()
  {
    super.setUp();
    this.enc = new Base64Encoder();
  }
  
  protected char paddingChar()
  {
    return '=';
  }
  
  protected boolean isEncodedChar(char paramChar)
  {
    if (Character.isLetterOrDigit(paramChar)) {
      return true;
    }
    if (paramChar == '+') {
      return true;
    }
    return paramChar == '/';
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\encoders\test\Base64Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */