package org.bouncycastle.util.test;

public abstract interface Test
{
  public abstract String getName();
  
  public abstract TestResult perform();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */