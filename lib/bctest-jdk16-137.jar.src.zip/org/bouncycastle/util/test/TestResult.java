package org.bouncycastle.util.test;

public abstract interface TestResult
{
  public abstract boolean isSuccessful();
  
  public abstract Throwable getException();
  
  public abstract String toString();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\TestResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */