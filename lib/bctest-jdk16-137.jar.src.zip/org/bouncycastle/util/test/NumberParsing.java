package org.bouncycastle.util.test;

public final class NumberParsing
{
  public static long decodeLongFromHex(String paramString)
  {
    if ((paramString.charAt(1) == 'x') || (paramString.charAt(1) == 'X')) {
      return Long.parseLong(paramString.substring(2), 16);
    }
    return Long.parseLong(paramString, 16);
  }
  
  public static int decodeIntFromHex(String paramString)
  {
    if ((paramString.charAt(1) == 'x') || (paramString.charAt(1) == 'X')) {
      return Integer.parseInt(paramString.substring(2), 16);
    }
    return Integer.parseInt(paramString, 16);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\NumberParsing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */