package org.bouncycastle.util.test;

import java.io.PrintStream;
import org.bouncycastle.util.Arrays;

public abstract class SimpleTest
  implements Test
{
  public abstract String getName();
  
  private TestResult success()
  {
    return SimpleTestResult.successful(this, "Okay");
  }
  
  protected void fail(String paramString)
  {
    throw new TestFailedException(SimpleTestResult.failed(this, paramString));
  }
  
  protected void fail(String paramString, Throwable paramThrowable)
  {
    throw new TestFailedException(SimpleTestResult.failed(this, paramString, paramThrowable));
  }
  
  protected void fail(String paramString, Object paramObject1, Object paramObject2)
  {
    throw new TestFailedException(SimpleTestResult.failed(this, paramString, paramObject1, paramObject2));
  }
  
  protected boolean areEqual(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    return Arrays.areEqual(paramArrayOfByte1, paramArrayOfByte2);
  }
  
  public TestResult perform()
  {
    try
    {
      performTest();
      return success();
    }
    catch (TestFailedException localTestFailedException)
    {
      return localTestFailedException.getResult();
    }
    catch (Exception localException)
    {
      return SimpleTestResult.failed(this, "Exception: " + localException, localException);
    }
  }
  
  protected static void runTest(Test paramTest)
  {
    runTest(paramTest, System.out);
  }
  
  protected static void runTest(Test paramTest, PrintStream paramPrintStream)
  {
    TestResult localTestResult = paramTest.perform();
    paramPrintStream.println(localTestResult.toString());
    if (localTestResult.getException() != null) {
      localTestResult.getException().printStackTrace(paramPrintStream);
    }
  }
  
  public abstract void performTest()
    throws Exception;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\SimpleTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */