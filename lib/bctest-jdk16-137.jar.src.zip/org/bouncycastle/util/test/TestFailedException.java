package org.bouncycastle.util.test;

public class TestFailedException
  extends RuntimeException
{
  private TestResult _result;
  
  public TestFailedException(TestResult paramTestResult)
  {
    this._result = paramTestResult;
  }
  
  public TestResult getResult()
  {
    return this._result;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\TestFailedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */