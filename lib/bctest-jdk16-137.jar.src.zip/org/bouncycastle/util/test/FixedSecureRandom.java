package org.bouncycastle.util.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;

public class FixedSecureRandom
  extends SecureRandom
{
  private byte[] _data;
  private int _index;
  private int _intPad;
  
  public FixedSecureRandom(byte[] paramArrayOfByte)
  {
    this(false, new byte[][] { paramArrayOfByte });
  }
  
  public FixedSecureRandom(byte[][] paramArrayOfByte)
  {
    this(false, paramArrayOfByte);
  }
  
  public FixedSecureRandom(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    this(paramBoolean, new byte[][] { paramArrayOfByte });
  }
  
  public FixedSecureRandom(boolean paramBoolean, byte[][] paramArrayOfByte)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    for (int i = 0; i != paramArrayOfByte.length; i++) {
      try
      {
        localByteArrayOutputStream.write(paramArrayOfByte[i]);
      }
      catch (IOException localIOException)
      {
        throw new IllegalArgumentException("can't save value array.");
      }
    }
    this._data = localByteArrayOutputStream.toByteArray();
    if (paramBoolean) {
      this._intPad = (this._data.length % 4);
    }
  }
  
  public void nextBytes(byte[] paramArrayOfByte)
  {
    System.arraycopy(this._data, this._index, paramArrayOfByte, 0, paramArrayOfByte.length);
    this._index += paramArrayOfByte.length;
  }
  
  public int nextInt()
  {
    int i = 0;
    i |= nextValue() << 24;
    i |= nextValue() << 16;
    if (this._intPad == 2) {
      this._intPad -= 1;
    } else {
      i |= nextValue() << 8;
    }
    if (this._intPad == 1) {
      this._intPad -= 1;
    } else {
      i |= nextValue();
    }
    return i;
  }
  
  public long nextLong()
  {
    long l = 0L;
    l |= nextValue() << 56;
    l |= nextValue() << 48;
    l |= nextValue() << 40;
    l |= nextValue() << 32;
    l |= nextValue() << 24;
    l |= nextValue() << 16;
    l |= nextValue() << 8;
    l |= nextValue();
    return l;
  }
  
  public boolean isExhausted()
  {
    return this._index == this._data.length;
  }
  
  private int nextValue()
  {
    return this._data[(this._index++)] & 0xFF;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\util\test\FixedSecureRandom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */