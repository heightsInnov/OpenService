package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509CRL;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.jce.MultiCertStoreParameters;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTest;

public class MultiCertStoreTest
  extends SimpleTest
{
  public void performTest()
    throws Exception
  {
    basicTest();
  }
  
  private void basicTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    X509CRL localX509CRL1 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.rootCrlBin));
    X509CRL localX509CRL2 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.interCrlBin));
    ArrayList localArrayList1 = new ArrayList();
    localArrayList1.add(localX509Certificate1);
    localArrayList1.add(localX509Certificate2);
    localArrayList1.add(localX509Certificate3);
    localArrayList1.add(localX509CRL1);
    localArrayList1.add(localX509CRL2);
    CollectionCertStoreParameters localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList1);
    CertStore localCertStore1 = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    CertStore localCertStore2 = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    ArrayList localArrayList2 = new ArrayList();
    localArrayList2.add(localCertStore1);
    localArrayList2.add(localCertStore2);
    CertStore localCertStore3 = CertStore.getInstance("Multi", new MultiCertStoreParameters(localArrayList2));
    X509CertSelector localX509CertSelector = new X509CertSelector();
    localX509CertSelector.setSubject(localX509Certificate1.getSubjectX500Principal().getName());
    Collection localCollection = localCertStore3.getCertificates(localX509CertSelector);
    if ((localCollection.size() != 2) || (!localCollection.contains(localX509Certificate1))) {
      fail("2 rootCerts not found by subjectDN");
    }
    localCertStore3 = CertStore.getInstance("Multi", new MultiCertStoreParameters(localArrayList2, false));
    localCollection = localCertStore3.getCertificates(localX509CertSelector);
    if ((localCollection.size() != 1) || (!localCollection.contains(localX509Certificate1))) {
      fail("1 rootCert not found by subjectDN");
    }
  }
  
  public String getName()
  {
    return "MultiCertStore";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new MultiCertStoreTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\MultiCertStoreTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */