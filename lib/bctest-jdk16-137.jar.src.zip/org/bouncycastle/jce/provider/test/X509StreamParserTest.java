package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.Security;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.Collection;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.SignedData;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509CertificatePair;
import org.bouncycastle.x509.X509StreamParser;

public class X509StreamParserTest
  extends SimpleTest
{
  byte[] attrCert = Base64.decode("MIIHQDCCBqkCAQEwgZChgY2kgYowgYcxHDAaBgkqhkiG9w0BCQEWDW1sb3JjaEB2dC5lZHUxHjAcBgNVBAMTFU1hcmt1cyBMb3JjaCAobWxvcmNoKTEbMBkGA1UECxMSVmlyZ2luaWEgVGVjaCBVc2VyMRAwDgYDVQQLEwdDbGFzcyAyMQswCQYDVQQKEwJ2dDELMAkGA1UEBhMCVVMwgYmkgYYwgYMxGzAZBgkqhkiG9w0BCQEWDHNzaGFoQHZ0LmVkdTEbMBkGA1UEAxMSU3VtaXQgU2hhaCAoc3NoYWgpMRswGQYDVQQLExJWaXJnaW5pYSBUZWNoIFVzZXIxEDAOBgNVBAsTB0NsYXNzIDExCzAJBgNVBAoTAnZ0MQswCQYDVQQGEwJVUzANBgkqhkiG9w0BAQQFAAIBBTAiGA8yMDAzMDcxODE2MDgwMloYDzIwMDMwNzI1MTYwODAyWjCCBU0wggVJBgorBgEEAbRoCAEBMYIFORaCBTU8UnVsZSBSdWxlSWQ9IkZpbGUtUHJpdmlsZWdlLVJ1bGUiIEVmZmVjdD0iUGVybWl0Ij4KIDxUYXJnZXQ+CiAgPFN1YmplY3RzPgogICA8U3ViamVjdD4KICAgIDxTdWJqZWN0TWF0Y2ggTWF0Y2hJZD0idXJuOm9hc2lzOm5hbWVzOnRjOnhhY21sOjEuMDpmdW5jdGlvbjpzdHJpbmctZXF1YWwiPgogICAgIDxBdHRyaWJ1dGVWYWx1ZSBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjc3RyaW5nIj4KICAgICAgIENOPU1hcmt1cyBMb3JjaDwvQXR0cmlidXRlVmFsdWU+CiAgICAgPFN1YmplY3RBdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOnN1YmplY3Q6c3ViamVjdC1pZCIgRGF0YVR5cGU9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hI3N0cmluZyIgLz4gCiAgICA8L1N1YmplY3RNYXRjaD4KICAgPC9TdWJqZWN0PgogIDwvU3ViamVjdHM+CiAgPFJlc291cmNlcz4KICAgPFJlc291cmNlPgogICAgPFJlc291cmNlTWF0Y2ggTWF0Y2hJZD0idXJuOm9hc2lzOm5hbWVzOnRjOnhhY21sOjEuMDpmdW5jdGlvbjpzdHJpbmctZXF1YWwiPgogICAgIDxBdHRyaWJ1dGVWYWx1ZSBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjYW55VVJJIj4KICAgICAgaHR0cDovL3p1bmkuY3MudnQuZWR1PC9BdHRyaWJ1dGVWYWx1ZT4KICAgICA8UmVzb3VyY2VBdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOnJlc291cmNlOnJlc291cmNlLWlkIiBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjYW55VVJJIiAvPiAKICAgIDwvUmVzb3VyY2VNYXRjaD4KICAgPC9SZXNvdXJjZT4KICA8L1Jlc291cmNlcz4KICA8QWN0aW9ucz4KICAgPEFjdGlvbj4KICAgIDxBY3Rpb25NYXRjaCBNYXRjaElkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOmZ1bmN0aW9uOnN0cmluZy1lcXVhbCI+CiAgICAgPEF0dHJpYnV0ZVZhbHVlIERhdGFUeXBlPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSNzdHJpbmciPgpEZWxlZ2F0ZSBBY2Nlc3MgICAgIDwvQXR0cmlidXRlVmFsdWU+CgkgIDxBY3Rpb25BdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOmFjdGlvbjphY3Rpb24taWQiIERhdGFUeXBlPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSNzdHJpbmciIC8+IAogICAgPC9BY3Rpb25NYXRjaD4KICAgPC9BY3Rpb24+CiAgPC9BY3Rpb25zPgogPC9UYXJnZXQ+CjwvUnVsZT4KMA0GCSqGSIb3DQEBBAUAA4GBAGiJSM48XsY90HlYxGmGVSmNR6ZW2As+bot3KAfiCIkUIOAqhcphBS23egTr6asYwy151HshbPNYz+Cgeqs45KkVzh7bL/0e1r8sDVIaaGIkjHK3CqBABnfSayr3Rd1yBoDdEv8Qb+3eEPH6ab9021AsLEnJ6LWTmybbOpMNZ3tv");
  
  public void performTest()
    throws Exception
  {
    X509StreamParser localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate = (X509Certificate)localX509StreamParser.read();
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(new ByteArrayInputStream(CertPathTest.rootCrlBin));
    X509CRL localX509CRL = (X509CRL)localX509StreamParser.read();
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(new ByteArrayInputStream(this.attrCert));
    X509AttributeCertificate localX509AttributeCertificate = (X509AttributeCertificate)localX509StreamParser.read();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(CertPathTest.rootCertBin);
    localByteArrayOutputStream.write(CertPathTest.interCertBin);
    localByteArrayOutputStream.write(CertPathTest.finalCertBin);
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(localByteArrayOutputStream.toByteArray());
    Collection localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 3) {
      fail("wrong number of certificates found");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(CertPathTest.rootCrlBin);
    localByteArrayOutputStream.write(CertPathTest.interCrlBin);
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(localByteArrayOutputStream.toByteArray());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 2) {
      fail("wrong number of CRLs found");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(this.attrCert);
    localByteArrayOutputStream.write(this.attrCert);
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(localByteArrayOutputStream.toByteArray());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 2) {
      fail("wrong number of Attribute Certificates found");
    }
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(PEMData.CERTIFICATE_1.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Certificates found");
    }
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(PEMData.CERTIFICATE_2.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Certificates found");
    }
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(PEMData.CRL_1.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of CRLs found");
    }
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(PEMData.CRL_2.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of CRLs found");
    }
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(PEMData.ATTRIBUTE_CERTIFICATE_1.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Attribute Certificates found");
    }
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(PEMData.ATTRIBUTE_CERTIFICATE_2.getBytes("US-ASCII"));
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Attribute Certificates found");
    }
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    localASN1EncodableVector1.add(new ASN1InputStream(CertPathTest.rootCertBin).readObject());
    localASN1EncodableVector1.add(new DERTaggedObject(false, 2, new ASN1InputStream(this.attrCert).readObject()));
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    localASN1EncodableVector2.add(new ASN1InputStream(CertPathTest.rootCrlBin).readObject());
    localX509StreamParser = X509StreamParser.getInstance("CertificatePair", "BC");
    localX509StreamParser.init(new X509CertificatePair(localX509Certificate, localX509Certificate).getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of CertificatePairs found");
    }
    SignedData localSignedData = new SignedData(new DERSet(), new ContentInfo(CMSObjectIdentifiers.data, null), new DERSet(localASN1EncodableVector1), new DERSet(localASN1EncodableVector2), new DERSet());
    ContentInfo localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Certificates found");
    }
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of CRLs found");
    }
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 1) {
      fail("wrong number of Attribute Certificates found");
    }
    localSignedData = new SignedData(new DERSet(), new ContentInfo(CMSObjectIdentifiers.data, null), new DERSet(), new DERSet(), new DERSet());
    localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of Certificates found - expected 0");
    }
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of CRLs found - expected 0");
    }
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of Attribute Certificates found - expected 0");
    }
    localSignedData = new SignedData(new DERSet(), new ContentInfo(CMSObjectIdentifiers.data, null), null, null, new DERSet());
    localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
    localX509StreamParser = X509StreamParser.getInstance("Certificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of Certificates found - expected 0");
    }
    localX509StreamParser = X509StreamParser.getInstance("CRL", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of CRLs found - expected 0");
    }
    localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(localContentInfo.getEncoded());
    localCollection = localX509StreamParser.readAll();
    if (localCollection.size() != 0) {
      fail("wrong number of Attribute Certificates found - expected 0");
    }
  }
  
  public String getName()
  {
    return "X509StreamParser";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new X509StreamParserTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\X509StreamParserTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */