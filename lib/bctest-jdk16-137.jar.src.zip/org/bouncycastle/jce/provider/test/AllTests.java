package org.bouncycastle.jce.provider.test;

import java.security.Security;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.provider.test.rsa3.RSA3CertTest;
import org.bouncycastle.util.test.SimpleTestResult;

public class AllTests
  extends TestCase
{
  public void testJCE()
  {
    org.bouncycastle.util.test.Test[] arrayOfTest = RegressionTest.tests;
    for (int i = 0; i != arrayOfTest.length; i++)
    {
      SimpleTestResult localSimpleTestResult = (SimpleTestResult)arrayOfTest[i].perform();
      if (!localSimpleTestResult.isSuccessful()) {
        fail(localSimpleTestResult.toString());
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static junit.framework.Test suite()
  {
    TestSuite localTestSuite = new TestSuite("JCE Tests");
    if (Security.getProvider("BC") == null) {
      Security.addProvider(new BouncyCastleProvider());
    }
    localTestSuite.addTestSuite(RSA3CertTest.class);
    localTestSuite.addTestSuite(AllTests.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */