package org.bouncycastle.jce.provider.test;

import java.io.PrintStream;
import java.security.AlgorithmParameters;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class EncryptedPrivateKeyInfoTest
  implements Test
{
  String alg = "1.2.840.113549.1.12.1.3";
  
  public TestResult perform()
  {
    try
    {
      KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
      localKeyPairGenerator.initialize(512, new SecureRandom());
      KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
      PrivateKey localPrivateKey = localKeyPair.getPrivate();
      PublicKey localPublicKey = localKeyPair.getPublic();
      byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
      int i = 100;
      PBEParameterSpec localPBEParameterSpec = new PBEParameterSpec(arrayOfByte1, i);
      AlgorithmParameters localAlgorithmParameters = AlgorithmParameters.getInstance(this.alg, "BC");
      localAlgorithmParameters.init(localPBEParameterSpec);
      char[] arrayOfChar1 = { 'h', 'e', 'l', 'l', 'o' };
      PBEKeySpec localPBEKeySpec = new PBEKeySpec(arrayOfChar1);
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(this.alg, "BC");
      Cipher localCipher = Cipher.getInstance(this.alg, "BC");
      localCipher.init(3, localSecretKeyFactory.generateSecret(localPBEKeySpec), localAlgorithmParameters);
      byte[] arrayOfByte2 = localCipher.wrap(localPrivateKey);
      EncryptedPrivateKeyInfo localEncryptedPrivateKeyInfo = new EncryptedPrivateKeyInfo(localAlgorithmParameters, arrayOfByte2);
      char[] arrayOfChar2 = { 'h', 'e', 'l', 'l', 'o' };
      localPBEKeySpec = new PBEKeySpec(arrayOfChar2);
      localCipher = Cipher.getInstance(localEncryptedPrivateKeyInfo.getAlgName(), "BC");
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec), localEncryptedPrivateKeyInfo.getAlgParameters());
      PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = localEncryptedPrivateKeyInfo.getKeySpec(localCipher);
      if (!MessageDigest.isEqual(localPrivateKey.getEncoded(), localPKCS8EncodedKeySpec.getEncoded())) {
        return new SimpleTestResult(false, "Private key does not match");
      }
      localPBEKeySpec = new PBEKeySpec(arrayOfChar1);
      localSecretKeyFactory = SecretKeyFactory.getInstance(this.alg, "BC");
      localCipher = Cipher.getInstance(this.alg, "BC");
      localCipher.init(3, localSecretKeyFactory.generateSecret(localPBEKeySpec), localAlgorithmParameters);
      arrayOfByte2 = localCipher.wrap(localPrivateKey);
      localEncryptedPrivateKeyInfo = new EncryptedPrivateKeyInfo(localCipher.getParameters(), arrayOfByte2);
      localPBEKeySpec = new PBEKeySpec(arrayOfChar2);
      localCipher = Cipher.getInstance(localEncryptedPrivateKeyInfo.getAlgName(), "BC");
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec), localEncryptedPrivateKeyInfo.getAlgParameters());
      localPKCS8EncodedKeySpec = localEncryptedPrivateKeyInfo.getKeySpec(localCipher);
      if (!MessageDigest.isEqual(localPrivateKey.getEncoded(), localPKCS8EncodedKeySpec.getEncoded())) {
        return new SimpleTestResult(false, "Private key does not match");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
    }
  }
  
  public String getName()
  {
    return "EncryptedPrivateKeyInfoTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    EncryptedPrivateKeyInfoTest localEncryptedPrivateKeyInfoTest = new EncryptedPrivateKeyInfoTest();
    TestResult localTestResult = localEncryptedPrivateKeyInfoTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\EncryptedPrivateKeyInfoTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */