package org.bouncycastle.jce.provider.test;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.ECKey;
import java.security.spec.ECFieldFp;
import java.security.spec.EllipticCurve;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.ECPointUtil;
import org.bouncycastle.jce.interfaces.ConfigurableProvider;
import org.bouncycastle.jce.interfaces.ECPrivateKey;
import org.bouncycastle.jce.interfaces.ECPublicKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECPrivateKeySpec;
import org.bouncycastle.jce.spec.ECPublicKeySpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTest;

public class ImplicitlyCaTest
  extends SimpleTest
{
  byte[] k1 = Hex.decode("d5014e4b60ef2ba8b6211b4062ba3224e0427dd3");
  byte[] k2 = Hex.decode("345e8d05c075c3a508df729a1685690e68fcfb8c8117847e89063bca1f85d968fd281540b6e13bd1af989a1fbf17e06462bf511f9d0b140fb48ac1b1baa5bded");
  SecureRandom random = new FixedSecureRandom(new byte[][] { this.k1, this.k2 });
  
  public void performTest()
    throws Exception
  {
    testBCAPI();
    testJDKAPI();
    testKeyFactory();
    testBasicThreadLocal();
  }
  
  private void testBCAPI()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    org.bouncycastle.jce.spec.ECParameterSpec localECParameterSpec = new org.bouncycastle.jce.spec.ECParameterSpec(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    ConfigurableProvider localConfigurableProvider = (ConfigurableProvider)Security.getProvider("BC");
    localConfigurableProvider.setParameter("ecImplicitlyCa", localECParameterSpec);
    localKeyPairGenerator.initialize(null, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyPair.getPrivate();
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyPair.getPublic();
    testECDSA(localECPrivateKey, localECPublicKey);
    testBCParamsAndQ(localECPrivateKey, localECPublicKey);
    testEC5Params(localECPrivateKey, localECPublicKey);
    testEncoding(localECPrivateKey, localECPublicKey);
  }
  
  private void testKeyFactory()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    org.bouncycastle.jce.spec.ECParameterSpec localECParameterSpec = new org.bouncycastle.jce.spec.ECParameterSpec(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    ConfigurableProvider localConfigurableProvider = (ConfigurableProvider)Security.getProvider("BC");
    localConfigurableProvider.setParameter("ecImplicitlyCa", localECParameterSpec);
    localKeyPairGenerator.initialize(null, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    ECPrivateKey localECPrivateKey1 = (ECPrivateKey)localKeyPair.getPrivate();
    ECPublicKey localECPublicKey1 = (ECPublicKey)localKeyPair.getPublic();
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDSA", "BC");
    localECPublicKey1 = (ECPublicKey)localKeyFactory.generatePublic(new ECPublicKeySpec(localECPublicKey1.getQ(), null));
    localECPrivateKey1 = (ECPrivateKey)localKeyFactory.generatePrivate(new ECPrivateKeySpec(localECPrivateKey1.getD(), null));
    testECDSA(localECPrivateKey1, localECPublicKey1);
    testBCParamsAndQ(localECPrivateKey1, localECPublicKey1);
    testEC5Params(localECPrivateKey1, localECPublicKey1);
    testEncoding(localECPrivateKey1, localECPublicKey1);
    ECPublicKey localECPublicKey2 = (ECPublicKey)localKeyFactory.generatePublic(new ECPublicKeySpec(localECPublicKey1.getQ(), localECParameterSpec));
    ECPrivateKey localECPrivateKey2 = (ECPrivateKey)localKeyFactory.generatePrivate(new ECPrivateKeySpec(localECPrivateKey1.getD(), localECParameterSpec));
    if ((!localECPublicKey1.equals(localECPublicKey2)) || (localECPublicKey1.hashCode() != localECPublicKey2.hashCode())) {
      fail("private equals/hashCode failed");
    }
    if ((!localECPrivateKey1.equals(localECPrivateKey2)) || (localECPrivateKey1.hashCode() != localECPrivateKey2.hashCode())) {
      fail("private equals/hashCode failed");
    }
  }
  
  private void testJDKAPI()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    EllipticCurve localEllipticCurve = new EllipticCurve(new ECFieldFp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839")), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    java.security.spec.ECParameterSpec localECParameterSpec = new java.security.spec.ECParameterSpec(localEllipticCurve, ECPointUtil.decodePoint(localEllipticCurve, Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"), 1);
    ConfigurableProvider localConfigurableProvider = (ConfigurableProvider)Security.getProvider("BC");
    localConfigurableProvider.setParameter("ecImplicitlyCa", localECParameterSpec);
    localKeyPairGenerator.initialize(null, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyPair.getPrivate();
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyPair.getPublic();
    testECDSA(localECPrivateKey, localECPublicKey);
    testBCParamsAndQ(localECPrivateKey, localECPublicKey);
    testEC5Params(localECPrivateKey, localECPublicKey);
    testEncoding(localECPrivateKey, localECPublicKey);
  }
  
  private void testBasicThreadLocal()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    EllipticCurve localEllipticCurve = new EllipticCurve(new ECFieldFp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839")), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    java.security.spec.ECParameterSpec localECParameterSpec = new java.security.spec.ECParameterSpec(localEllipticCurve, ECPointUtil.decodePoint(localEllipticCurve, Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"), 1);
    ConfigurableProvider localConfigurableProvider = (ConfigurableProvider)Security.getProvider("BC");
    localConfigurableProvider.setParameter("threadLocalEcImplicitlyCa", localECParameterSpec);
    localKeyPairGenerator.initialize(null, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyPair.getPrivate();
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyPair.getPublic();
    testECDSA(localECPrivateKey, localECPublicKey);
    testBCParamsAndQ(localECPrivateKey, localECPublicKey);
    testEC5Params(localECPrivateKey, localECPublicKey);
    testEncoding(localECPrivateKey, localECPublicKey);
  }
  
  private void testECDSA(ECPrivateKey paramECPrivateKey, ECPublicKey paramECPublicKey)
    throws Exception
  {
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
    Signature localSignature = Signature.getInstance("ECDSA", "BC");
    localSignature.initSign(paramECPrivateKey);
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("ECDSA", "BC");
    localSignature.initVerify(paramECPublicKey);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("ECDSA verification failed");
    }
  }
  
  private void testEncoding(ECPrivateKey paramECPrivateKey, ECPublicKey paramECPublicKey)
    throws Exception
  {
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDSA", "BC");
    byte[] arrayOfByte = paramECPrivateKey.getEncoded();
    PrivateKeyInfo localPrivateKeyInfo = PrivateKeyInfo.getInstance(new ASN1InputStream(arrayOfByte).readObject());
    if (!localPrivateKeyInfo.getAlgorithmId().getParameters().equals(DERNull.INSTANCE)) {
      fail("private key parameters wrong");
    }
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyFactory.generatePrivate(new PKCS8EncodedKeySpec(arrayOfByte));
    if (!localECPrivateKey.equals(paramECPrivateKey)) {
      fail("private equals failed");
    }
    if (localECPrivateKey.hashCode() != paramECPrivateKey.hashCode()) {
      fail("private hashCode failed");
    }
    arrayOfByte = paramECPublicKey.getEncoded();
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = SubjectPublicKeyInfo.getInstance(new ASN1InputStream(arrayOfByte).readObject());
    if (!localSubjectPublicKeyInfo.getAlgorithmId().getParameters().equals(DERNull.INSTANCE)) {
      fail("public key parameters wrong");
    }
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyFactory.generatePublic(new X509EncodedKeySpec(arrayOfByte));
    if ((!localECPublicKey.equals(paramECPublicKey)) || (localECPublicKey.hashCode() != paramECPublicKey.hashCode())) {
      fail("public equals/hashCode failed");
    }
    testBCParamsAndQ(localECPrivateKey, localECPublicKey);
    testEC5Params(localECPrivateKey, localECPublicKey);
    testECDSA(localECPrivateKey, localECPublicKey);
  }
  
  private void testBCParamsAndQ(ECPrivateKey paramECPrivateKey, ECPublicKey paramECPublicKey)
  {
    if (paramECPrivateKey.getParameters() != null) {
      fail("parameters exposed in private key");
    }
    if (paramECPublicKey.getParameters() != null) {
      fail("parameters exposed in public key");
    }
    if (paramECPublicKey.getQ().getCurve() != null) {
      fail("curve exposed in public point");
    }
  }
  
  private void testEC5Params(ECPrivateKey paramECPrivateKey, ECPublicKey paramECPublicKey)
  {
    ECKey localECKey = (ECKey)paramECPrivateKey;
    if (localECKey.getParams() != null) {
      fail("parameters exposed in private key");
    }
    localECKey = (ECKey)paramECPublicKey;
    if (localECKey.getParams() != null) {
      fail("parameters exposed in public key");
    }
  }
  
  public String getName()
  {
    return "ImplicitlyCA";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new ImplicitlyCaTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\ImplicitlyCaTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */