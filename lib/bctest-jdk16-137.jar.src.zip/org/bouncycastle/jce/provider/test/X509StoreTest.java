package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.x509.AttributeCertificateHolder;
import org.bouncycastle.x509.AttributeCertificateIssuer;
import org.bouncycastle.x509.X509AttributeCertStoreSelector;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509CRLStoreSelector;
import org.bouncycastle.x509.X509CertPairStoreSelector;
import org.bouncycastle.x509.X509CertStoreSelector;
import org.bouncycastle.x509.X509CertificatePair;
import org.bouncycastle.x509.X509CollectionStoreParameters;
import org.bouncycastle.x509.X509Store;
import org.bouncycastle.x509.X509V2AttributeCertificate;

public class X509StoreTest
  extends SimpleTest
{
  private void certPairTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    X509CertificatePair localX509CertificatePair = new X509CertificatePair(localX509Certificate1, localX509Certificate2);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509CertificatePair);
    localArrayList.add(new X509CertificatePair(localX509Certificate2, localX509Certificate3));
    X509CollectionStoreParameters localX509CollectionStoreParameters = new X509CollectionStoreParameters(localArrayList);
    X509Store localX509Store = X509Store.getInstance("CertificatePair/Collection", localX509CollectionStoreParameters, "BC");
    X509CertPairStoreSelector localX509CertPairStoreSelector = new X509CertPairStoreSelector();
    X509CertStoreSelector localX509CertStoreSelector = new X509CertStoreSelector();
    localX509CertStoreSelector.setSerialNumber(localX509Certificate1.getSerialNumber());
    localX509CertPairStoreSelector.setForwardSelector(localX509CertStoreSelector);
    Collection localCollection = localX509Store.getMatches(localX509CertPairStoreSelector);
    if ((localCollection.size() != 1) || (!localCollection.contains(localX509CertificatePair))) {
      fail("failed pair1 test");
    }
    localCollection = localX509Store.getMatches(null);
    if (localCollection.size() != 2) {
      fail("failed null test");
    }
  }
  
  public void performTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    X509CRL localX509CRL1 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.rootCrlBin));
    X509CRL localX509CRL2 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.interCrlBin));
    ArrayList localArrayList1 = new ArrayList();
    localArrayList1.add(localX509Certificate1);
    localArrayList1.add(localX509Certificate2);
    localArrayList1.add(localX509Certificate3);
    X509CollectionStoreParameters localX509CollectionStoreParameters = new X509CollectionStoreParameters(localArrayList1);
    X509Store localX509Store1 = X509Store.getInstance("Certificate/Collection", localX509CollectionStoreParameters, "BC");
    X509Principal.DefaultReverse = true;
    X509CertStoreSelector localX509CertStoreSelector = new X509CertStoreSelector();
    localX509CertStoreSelector.setSubject(PrincipalUtil.getSubjectX509Principal(localX509Certificate1).getEncoded());
    Collection localCollection1 = localX509Store1.getMatches(localX509CertStoreSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by subjectDN");
    }
    localX509CertStoreSelector = new X509CertStoreSelector();
    localX509CertStoreSelector.setSubject(PrincipalUtil.getSubjectX509Principal(localX509Certificate1).getEncoded());
    localCollection1 = localX509Store1.getMatches(localX509CertStoreSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by encoded subjectDN");
    }
    X509Principal.DefaultReverse = false;
    localX509CertStoreSelector = new X509CertStoreSelector();
    localX509CertStoreSelector.setSubjectPublicKey(localX509Certificate1.getPublicKey().getEncoded());
    localCollection1 = localX509Store1.getMatches(localX509CertStoreSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by encoded public key");
    }
    localX509CertStoreSelector = new X509CertStoreSelector();
    localX509CertStoreSelector.setIssuer(PrincipalUtil.getSubjectX509Principal(localX509Certificate1).getEncoded());
    localCollection1 = localX509Store1.getMatches(localX509CertStoreSelector);
    if (localCollection1.size() != 2) {
      fail("did not found 2 certs");
    }
    if (!localCollection1.contains(localX509Certificate1)) {
      fail("rootCert not found");
    }
    if (!localCollection1.contains(localX509Certificate2)) {
      fail("interCert not found");
    }
    ArrayList localArrayList2 = new ArrayList();
    localArrayList2.add(localX509CRL1);
    localArrayList2.add(localX509CRL2);
    localX509CollectionStoreParameters = new X509CollectionStoreParameters(localArrayList2);
    X509Store localX509Store2 = X509Store.getInstance("CRL/Collection", localX509CollectionStoreParameters, "BC");
    X509CRLStoreSelector localX509CRLStoreSelector = new X509CRLStoreSelector();
    localX509CRLStoreSelector.setIssuers(Collections.singleton(localX509CRL1.getIssuerX500Principal()));
    Collection localCollection2 = localX509Store2.getMatches(localX509CRLStoreSelector);
    if ((localCollection2.size() != 1) || (!localCollection2.contains(localX509CRL1))) {
      fail("rootCrl not found");
    }
    localCollection2 = localX509Store1.getMatches(localX509CRLStoreSelector);
    if (localCollection2.size() != 0) {
      fail("error using wrong selector (CRL)");
    }
    localCollection1 = localX509Store2.getMatches(localX509CertStoreSelector);
    if (localCollection1.size() != 0) {
      fail("error using wrong selector (certs)");
    }
    X509V2AttributeCertificate localX509V2AttributeCertificate1 = new X509V2AttributeCertificate(AttrCertTest.attrCert);
    X509V2AttributeCertificate localX509V2AttributeCertificate2 = new X509V2AttributeCertificate(AttrCertTest.certWithBaseCertificateID);
    ArrayList localArrayList3 = new ArrayList();
    localArrayList3.add(localX509V2AttributeCertificate1);
    localArrayList3.add(localX509V2AttributeCertificate2);
    localX509CollectionStoreParameters = new X509CollectionStoreParameters(localArrayList3);
    localX509Store2 = X509Store.getInstance("AttributeCertificate/Collection", localX509CollectionStoreParameters, "BC");
    X509AttributeCertStoreSelector localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setHolder(localX509V2AttributeCertificate1.getHolder());
    if (!localX509AttributeCertStoreSelector.getHolder().equals(localX509V2AttributeCertificate1.getHolder())) {
      fail("holder get not correct");
    }
    Collection localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on holder");
    }
    localX509AttributeCertStoreSelector.setHolder(localX509V2AttributeCertificate2.getHolder());
    if (localX509AttributeCertStoreSelector.getHolder().equals(localX509V2AttributeCertificate1.getHolder())) {
      fail("holder get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate2))) {
      fail("attrCert2 not found on holder");
    }
    localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setIssuer(localX509V2AttributeCertificate1.getIssuer());
    if (!localX509AttributeCertStoreSelector.getIssuer().equals(localX509V2AttributeCertificate1.getIssuer())) {
      fail("issuer get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on issuer");
    }
    localX509AttributeCertStoreSelector.setIssuer(localX509V2AttributeCertificate2.getIssuer());
    if (localX509AttributeCertStoreSelector.getIssuer().equals(localX509V2AttributeCertificate1.getIssuer())) {
      fail("issuer get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate2))) {
      fail("attrCert2 not found on issuer");
    }
    localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setAttributeCert(localX509V2AttributeCertificate1);
    if (!localX509AttributeCertStoreSelector.getAttributeCert().equals(localX509V2AttributeCertificate1)) {
      fail("attrCert get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on attrCert");
    }
    localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setSerialNumber(localX509V2AttributeCertificate1.getSerialNumber());
    if (!localX509AttributeCertStoreSelector.getSerialNumber().equals(localX509V2AttributeCertificate1.getSerialNumber())) {
      fail("serial number get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on serial number");
    }
    localX509AttributeCertStoreSelector = (X509AttributeCertStoreSelector)localX509AttributeCertStoreSelector.clone();
    if (!localX509AttributeCertStoreSelector.getSerialNumber().equals(localX509V2AttributeCertificate1.getSerialNumber())) {
      fail("serial number get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on serial number");
    }
    localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setAttributeCertificateValid(localX509V2AttributeCertificate1.getNotBefore());
    if (!localX509AttributeCertStoreSelector.getAttributeCertificateValid().equals(localX509V2AttributeCertificate1.getNotBefore())) {
      fail("valid get not correct");
    }
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if ((localCollection3.size() != 1) || (!localCollection3.contains(localX509V2AttributeCertificate1))) {
      fail("attrCert not found on valid");
    }
    localX509AttributeCertStoreSelector = new X509AttributeCertStoreSelector();
    localX509AttributeCertStoreSelector.setAttributeCertificateValid(new Date(localX509V2AttributeCertificate1.getNotBefore().getTime() - 100L));
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if (localCollection3.size() != 0) {
      fail("attrCert found on before");
    }
    localX509AttributeCertStoreSelector.setAttributeCertificateValid(new Date(localX509V2AttributeCertificate1.getNotAfter().getTime() + 100L));
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if (localCollection3.size() != 0) {
      fail("attrCert found on after");
    }
    localX509AttributeCertStoreSelector.setSerialNumber(BigInteger.valueOf(10000L));
    localCollection3 = localX509Store2.getMatches(localX509AttributeCertStoreSelector);
    if (localCollection3.size() != 0) {
      fail("attrCert found on wrong serial number");
    }
    localX509AttributeCertStoreSelector.setAttributeCert(null);
    localX509AttributeCertStoreSelector.setAttributeCertificateValid(null);
    localX509AttributeCertStoreSelector.setHolder(null);
    localX509AttributeCertStoreSelector.setIssuer(null);
    localX509AttributeCertStoreSelector.setSerialNumber(null);
    if (localX509AttributeCertStoreSelector.getAttributeCert() != null) {
      fail("null attrCert");
    }
    if (localX509AttributeCertStoreSelector.getAttributeCertificateValid() != null) {
      fail("null attrCertValid");
    }
    if (localX509AttributeCertStoreSelector.getHolder() != null) {
      fail("null attrCert holder");
    }
    if (localX509AttributeCertStoreSelector.getIssuer() != null) {
      fail("null attrCert issuer");
    }
    if (localX509AttributeCertStoreSelector.getSerialNumber() != null) {
      fail("null attrCert serial");
    }
    localCollection3 = localX509Store1.getMatches(localX509AttributeCertStoreSelector);
    if (localCollection3.size() != 0) {
      fail("error using wrong selector (attrs)");
    }
    certPairTest();
  }
  
  public String getName()
  {
    return "X509Store";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new X509StoreTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\X509StoreTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */