package org.bouncycastle.jce.provider.test;

import java.security.AlgorithmParameters;
import java.security.Security;
import java.security.spec.InvalidParameterSpecException;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.OpenSSLPBEParametersGenerator;
import org.bouncycastle.crypto.generators.PKCS12ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class PBETest
  extends SimpleTest
{
  private PKCS12Test[] pkcs12Tests = { new PKCS12Test("DESede", "PBEWITHSHAAND3-KEYTRIPLEDES-CBC", new SHA1Digest(), 192, 64), new PKCS12Test("DESede", "PBEWITHSHAAND2-KEYTRIPLEDES-CBC", new SHA1Digest(), 128, 64), new PKCS12Test("RC4", "PBEWITHSHAAND128BITRC4", new SHA1Digest(), 128, 0), new PKCS12Test("RC4", "PBEWITHSHAAND40BITRC4", new SHA1Digest(), 40, 0), new PKCS12Test("RC2", "PBEWITHSHAAND128BITRC2-CBC", new SHA1Digest(), 128, 64), new PKCS12Test("RC2", "PBEWITHSHAAND40BITRC2-CBC", new SHA1Digest(), 40, 64), new PKCS12Test("AES", "PBEWithSHA1And128BitAES-CBC-BC", new SHA1Digest(), 128, 128), new PKCS12Test("AES", "PBEWithSHA1And192BitAES-CBC-BC", new SHA1Digest(), 192, 128), new PKCS12Test("AES", "PBEWithSHA1And256BitAES-CBC-BC", new SHA1Digest(), 256, 128), new PKCS12Test("AES", "PBEWithSHA256And128BitAES-CBC-BC", new SHA256Digest(), 128, 128), new PKCS12Test("AES", "PBEWithSHA256And192BitAES-CBC-BC", new SHA256Digest(), 192, 128), new PKCS12Test("AES", "PBEWithSHA256And256BitAES-CBC-BC", new SHA256Digest(), 256, 128), new PKCS12Test("Twofish", "PBEWithSHAAndTwofish-CBC", new SHA1Digest(), 256, 128), new PKCS12Test("IDEA", "PBEWithSHAAndIDEA-CBC", new SHA1Digest(), 128, 64) };
  private OpenSSLTest[] openSSLTests = { new OpenSSLTest("AES", "PBEWITHMD5AND128BITAES-CBC-OPENSSL", 128, 128), new OpenSSLTest("AES", "PBEWITHMD5AND192BITAES-CBC-OPENSSL", 192, 128), new OpenSSLTest("AES", "PBEWITHMD5AND256BITAES-CBC-OPENSSL", 256, 128) };
  static byte[] message = Hex.decode("4869205468657265");
  private byte[] hMac1 = Hex.decode("bcc42174ccb04f425d9a5c8c4a95d6fd7c372911");
  private byte[] hMac2 = Hex.decode("cb1d8bdb6aca9e3fa8980d6eb41ab28a7eb2cfd6");
  
  private Cipher makePBECipherUsingParam(String paramString, int paramInt1, char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt2)
    throws Exception
  {
    PBEKeySpec localPBEKeySpec = new PBEKeySpec(paramArrayOfChar);
    SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(paramString, "BC");
    PBEParameterSpec localPBEParameterSpec = new PBEParameterSpec(paramArrayOfByte, paramInt2);
    Cipher localCipher = Cipher.getInstance(paramString, "BC");
    localCipher.init(paramInt1, localSecretKeyFactory.generateSecret(localPBEKeySpec), localPBEParameterSpec);
    return localCipher;
  }
  
  private Cipher makePBECipherWithoutParam(String paramString, int paramInt1, char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt2)
    throws Exception
  {
    PBEKeySpec localPBEKeySpec = new PBEKeySpec(paramArrayOfChar, paramArrayOfByte, paramInt2);
    SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(paramString, "BC");
    Cipher localCipher = Cipher.getInstance(paramString, "BC");
    localCipher.init(paramInt1, localSecretKeyFactory.generateSecret(localPBEKeySpec));
    return localCipher;
  }
  
  private boolean arrayEquals(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public void testPBEHMac(String paramString, byte[] paramArrayOfByte)
  {
    SecretKey localSecretKey;
    Mac localMac;
    try
    {
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(paramString, "BC");
      localSecretKey = localSecretKeyFactory.generateSecret(new PBEKeySpec("hello".toCharArray()));
      localMac = Mac.getInstance(paramString, "BC");
    }
    catch (Exception localException1)
    {
      fail("Failed - exception " + localException1.toString(), localException1);
      return;
    }
    try
    {
      localMac.init(localSecretKey, new PBEParameterSpec(new byte[20], 100));
    }
    catch (Exception localException2)
    {
      fail("Failed - exception " + localException2.toString(), localException2);
      return;
    }
    localMac.reset();
    localMac.update(message, 0, message.length);
    byte[] arrayOfByte = localMac.doFinal();
    if (!arrayEquals(arrayOfByte, paramArrayOfByte)) {
      fail("Failed - expected " + new String(Hex.encode(paramArrayOfByte)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public void performTest()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("1234567890abcdefabcdef1234567890fedbca098765");
    Cipher localCipher1 = Cipher.getInstance("DES/CBC/PKCS7Padding", "BC");
    localCipher1.init(1, new SecretKeySpec(Hex.decode("30e69252758e5346"), "DES"), new IvParameterSpec(Hex.decode("7c1c1ab9c454a688")));
    byte[] arrayOfByte2 = localCipher1.doFinal(arrayOfByte1);
    char[] arrayOfChar = { 'p', 'a', 's', 's', 'w', 'o', 'r', 'd' };
    Cipher localCipher2 = makePBECipherUsingParam("PBEWithSHA1AndDES", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    byte[] arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("DES failed");
    }
    localCipher2 = makePBECipherWithoutParam("PBEWithSHA1AndDES", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("DES failed without param");
    }
    localCipher1 = Cipher.getInstance("DESede/CBC/PKCS7Padding", "BC");
    localCipher1.init(1, new SecretKeySpec(Hex.decode("732f2d33c801732b7206756cbd44f9c1c103ddd97c7cbe8e"), "DES"), new IvParameterSpec(Hex.decode("b07bf522c8d608b8")));
    arrayOfByte2 = localCipher1.doFinal(arrayOfByte1);
    localCipher2 = makePBECipherUsingParam("PBEWithSHAAnd3-KeyTripleDES-CBC", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("DESede failed");
    }
    localCipher1 = Cipher.getInstance("RC2/CBC/PKCS7Padding", "BC");
    localCipher1.init(1, new SecretKeySpec(Hex.decode("732f2d33c8"), "RC2"), new IvParameterSpec(Hex.decode("b07bf522c8d608b8")));
    arrayOfByte2 = localCipher1.doFinal(arrayOfByte1);
    localCipher2 = makePBECipherUsingParam("PBEWithSHAAnd40BitRC2-CBC", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("RC2 failed");
    }
    localCipher1 = Cipher.getInstance("RC4", "BC");
    localCipher1.init(1, new SecretKeySpec(Hex.decode("732f2d33c801732b7206756cbd44f9c1"), "RC4"));
    arrayOfByte2 = localCipher1.doFinal(arrayOfByte1);
    localCipher2 = makePBECipherUsingParam("PBEWithSHAAnd128BitRC4", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("RC4 failed");
    }
    localCipher2 = makePBECipherWithoutParam("PBEWithSHAAnd128BitRC4", 2, arrayOfChar, Hex.decode("7d60435f02e9e0ae"), 2048);
    arrayOfByte3 = localCipher2.doFinal(arrayOfByte2);
    if (!arrayEquals(arrayOfByte1, arrayOfByte3)) {
      fail("RC4 failed without param");
    }
    for (int i = 0; i != this.pkcs12Tests.length; i++) {
      this.pkcs12Tests[i].perform();
    }
    for (i = 0; i != this.openSSLTests.length; i++) {
      this.openSSLTests[i].perform();
    }
    testPBEHMac("PBEWithHMacSHA1", this.hMac1);
    testPBEHMac("PBEWithHMacRIPEMD160", this.hMac2);
  }
  
  public String getName()
  {
    return "PBETest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PBETest());
  }
  
  private class PKCS12Test
    extends SimpleTest
  {
    char[] password;
    String baseAlgorithm;
    String algorithm;
    Digest digest;
    int keySize;
    int ivSize;
    
    PKCS12Test(String paramString1, String paramString2, Digest paramDigest, int paramInt1, int paramInt2)
    {
      this.password = paramString2.toCharArray();
      this.baseAlgorithm = paramString1;
      this.algorithm = paramString2;
      this.digest = paramDigest;
      this.keySize = paramInt1;
      this.ivSize = paramInt2;
    }
    
    public String getName()
    {
      return "PKCS12PBE";
    }
    
    public void performTest()
      throws Exception
    {
      byte[] arrayOfByte1 = new byte[this.digest.getDigestSize()];
      int i = 100;
      this.digest.doFinal(arrayOfByte1, 0);
      PKCS12ParametersGenerator localPKCS12ParametersGenerator = new PKCS12ParametersGenerator(this.digest);
      localPKCS12ParametersGenerator.init(PBEParametersGenerator.PKCS12PasswordToBytes(this.password), arrayOfByte1, i);
      ParametersWithIV localParametersWithIV = (ParametersWithIV)localPKCS12ParametersGenerator.generateDerivedParameters(this.keySize, this.ivSize);
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(((KeyParameter)localParametersWithIV.getParameters()).getKey(), this.baseAlgorithm);
      if (this.baseAlgorithm.equals("RC4"))
      {
        localCipher = Cipher.getInstance(this.baseAlgorithm, "BC");
        localCipher.init(1, localSecretKeySpec);
      }
      else
      {
        localCipher = Cipher.getInstance(this.baseAlgorithm + "/CBC/PKCS7Padding", "BC");
        localCipher.init(1, localSecretKeySpec, new IvParameterSpec(localParametersWithIV.getIV()));
      }
      byte[] arrayOfByte2 = localCipher.doFinal(arrayOfByte1);
      Cipher localCipher = Cipher.getInstance(this.algorithm, "BC");
      PBEKeySpec localPBEKeySpec = new PBEKeySpec(this.password, arrayOfByte1, i);
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(this.algorithm, "BC");
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec));
      byte[] arrayOfByte3 = localCipher.doFinal(arrayOfByte2);
      if (!PBETest.this.arrayEquals(arrayOfByte1, arrayOfByte3)) {
        fail("" + this.algorithm + "failed encryption/decryption test");
      }
      AlgorithmParameters localAlgorithmParameters = checkParameters(localCipher, arrayOfByte1, i);
      localCipher = Cipher.getInstance(this.algorithm, "BC");
      localPBEKeySpec = new PBEKeySpec(this.password);
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec), localAlgorithmParameters);
      checkParameters(localCipher, arrayOfByte1, i);
      arrayOfByte3 = localCipher.doFinal(arrayOfByte2);
      if (!PBETest.this.arrayEquals(arrayOfByte1, arrayOfByte3)) {
        fail("" + this.algorithm + "failed encryption/decryption test");
      }
      localCipher = Cipher.getInstance(this.algorithm, "BC");
      localPBEKeySpec = new PBEKeySpec(this.password);
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec), localAlgorithmParameters.getParameterSpec(PBEParameterSpec.class));
      checkParameters(localCipher, arrayOfByte1, i);
      arrayOfByte3 = localCipher.doFinal(arrayOfByte2);
      if (!PBETest.this.arrayEquals(arrayOfByte1, arrayOfByte3)) {
        fail("" + this.algorithm + "failed encryption/decryption test");
      }
    }
    
    private AlgorithmParameters checkParameters(Cipher paramCipher, byte[] paramArrayOfByte, int paramInt)
      throws InvalidParameterSpecException
    {
      AlgorithmParameters localAlgorithmParameters = paramCipher.getParameters();
      PBEParameterSpec localPBEParameterSpec = (PBEParameterSpec)localAlgorithmParameters.getParameterSpec(PBEParameterSpec.class);
      if (!PBETest.this.arrayEquals(paramArrayOfByte, localPBEParameterSpec.getSalt())) {
        fail("" + this.algorithm + "failed salt test");
      }
      if (paramInt != localPBEParameterSpec.getIterationCount()) {
        fail("" + this.algorithm + "failed count test");
      }
      return localAlgorithmParameters;
    }
  }
  
  private class OpenSSLTest
    extends SimpleTest
  {
    char[] password;
    String baseAlgorithm;
    String algorithm;
    int keySize;
    int ivSize;
    
    OpenSSLTest(String paramString1, String paramString2, int paramInt1, int paramInt2)
    {
      this.password = paramString2.toCharArray();
      this.baseAlgorithm = paramString1;
      this.algorithm = paramString2;
      this.keySize = paramInt1;
      this.ivSize = paramInt2;
    }
    
    public String getName()
    {
      return "OpenSSLPBE";
    }
    
    public void performTest()
      throws Exception
    {
      byte[] arrayOfByte1 = new byte[16];
      int i = 100;
      for (int j = 0; j != arrayOfByte1.length; j++) {
        arrayOfByte1[j] = ((byte)j);
      }
      OpenSSLPBEParametersGenerator localOpenSSLPBEParametersGenerator = new OpenSSLPBEParametersGenerator();
      localOpenSSLPBEParametersGenerator.init(PBEParametersGenerator.PKCS5PasswordToBytes(this.password), arrayOfByte1, i);
      ParametersWithIV localParametersWithIV = (ParametersWithIV)localOpenSSLPBEParametersGenerator.generateDerivedParameters(this.keySize, this.ivSize);
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(((KeyParameter)localParametersWithIV.getParameters()).getKey(), this.baseAlgorithm);
      if (this.baseAlgorithm.equals("RC4"))
      {
        localCipher = Cipher.getInstance(this.baseAlgorithm, "BC");
        localCipher.init(1, localSecretKeySpec);
      }
      else
      {
        localCipher = Cipher.getInstance(this.baseAlgorithm + "/CBC/PKCS7Padding", "BC");
        localCipher.init(1, localSecretKeySpec, new IvParameterSpec(localParametersWithIV.getIV()));
      }
      byte[] arrayOfByte2 = localCipher.doFinal(arrayOfByte1);
      Cipher localCipher = Cipher.getInstance(this.algorithm, "BC");
      PBEKeySpec localPBEKeySpec = new PBEKeySpec(this.password, arrayOfByte1, i);
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(this.algorithm, "BC");
      localCipher.init(2, localSecretKeyFactory.generateSecret(localPBEKeySpec));
      byte[] arrayOfByte3 = localCipher.doFinal(arrayOfByte2);
      if (!PBETest.this.arrayEquals(arrayOfByte1, arrayOfByte3)) {
        fail("" + this.algorithm + "failed encryption/decryption test");
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\PBETest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */