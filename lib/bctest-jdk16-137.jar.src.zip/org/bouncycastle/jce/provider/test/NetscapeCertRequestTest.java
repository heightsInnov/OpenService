package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.jce.netscape.NetscapeCertRequest;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class NetscapeCertRequestTest
  implements Test
{
  static final String test1 = "MIIBRzCBsTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAmwdh+LJXQ8AtXczo4EIGfXjpmDwsoIRpPaXEx1CBHhpon/Dpo/o5Vw2WoWNICXj5lmqhftIpCPO9qKxx85x6k/fuyTPH8P02hkmscAYsgqOgb/1yRCNXFryuFOATqxw1tsuye5Q3lTU9JCLUUilQ6BV8n3fm2egtPPUaJEuCvcsCAwEAARYNZml4ZWQtZm9yLW5vdzANBgkqhkiG9w0BAQQFAAOBgQAImbJD6xHbJtXl6kOTbCFoMnDk7U0o6pHy9l56DYVsiluXegiY6twB4o7OWsrqTb+gVvzK65FfP+NBVVzxY8UzcjbqC51yvO/9wnpUsIBqD/Gvi1gEqvw7RHwVEhdzsvLwlL22G8CfDxHnWLww39j8uRJsmoNiKJly3BcsZkLd9g==";
  
  public String getName()
  {
    return "NetscapeCertRequest";
  }
  
  public TestResult perform()
  {
    try
    {
      String str = "fixed-for-now";
      byte[] arrayOfByte = Base64.decode("MIIBRzCBsTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAmwdh+LJXQ8AtXczo4EIGfXjpmDwsoIRpPaXEx1CBHhpon/Dpo/o5Vw2WoWNICXj5lmqhftIpCPO9qKxx85x6k/fuyTPH8P02hkmscAYsgqOgb/1yRCNXFryuFOATqxw1tsuye5Q3lTU9JCLUUilQ6BV8n3fm2egtPPUaJEuCvcsCAwEAARYNZml4ZWQtZm9yLW5vdzANBgkqhkiG9w0BAQQFAAOBgQAImbJD6xHbJtXl6kOTbCFoMnDk7U0o6pHy9l56DYVsiluXegiY6twB4o7OWsrqTb+gVvzK65FfP+NBVVzxY8UzcjbqC51yvO/9wnpUsIBqD/Gvi1gEqvw7RHwVEhdzsvLwlL22G8CfDxHnWLww39j8uRJsmoNiKJly3BcsZkLd9g==");
      ASN1InputStream localASN1InputStream1 = new ASN1InputStream(new ByteArrayInputStream(arrayOfByte));
      ASN1Sequence localASN1Sequence1 = (ASN1Sequence)localASN1InputStream1.readObject();
      NetscapeCertRequest localNetscapeCertRequest1 = new NetscapeCertRequest(localASN1Sequence1);
      if (!localNetscapeCertRequest1.verify(str)) {
        return new SimpleTestResult(false, getName() + ": 1 - not verified");
      }
      KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance(localNetscapeCertRequest1.getKeyAlgorithm().getObjectId().getId(), "BC");
      localKeyPairGenerator.initialize(1024);
      KeyPair localKeyPair = localKeyPairGenerator.genKeyPair();
      localNetscapeCertRequest1.setPublicKey(localKeyPair.getPublic());
      localNetscapeCertRequest1.sign(localKeyPair.getPrivate());
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
      localDEROutputStream.writeObject(localNetscapeCertRequest1);
      localDEROutputStream.close();
      ASN1InputStream localASN1InputStream2 = new ASN1InputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
      ASN1Sequence localASN1Sequence2 = (ASN1Sequence)localASN1InputStream2.readObject();
      NetscapeCertRequest localNetscapeCertRequest2 = new NetscapeCertRequest(localASN1Sequence2);
      if (!localNetscapeCertRequest2.verify(str)) {
        return new SimpleTestResult(false, getName() + ": 2 - not verified");
      }
      str = "try it";
      NetscapeCertRequest localNetscapeCertRequest3 = new NetscapeCertRequest(str, new AlgorithmIdentifier(PKCSObjectIdentifiers.sha1WithRSAEncryption, null), localKeyPair.getPublic());
      localNetscapeCertRequest3.sign(localKeyPair.getPrivate());
      if (localNetscapeCertRequest3.verify(str)) {
        return new SimpleTestResult(true, getName() + ": Okay");
      }
      return new SimpleTestResult(false, getName() + ": 3 - not verified");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException.toString());
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    NetscapeCertRequestTest localNetscapeCertRequestTest = new NetscapeCertRequestTest();
    TestResult localTestResult = localNetscapeCertRequestTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\NetscapeCertRequestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */