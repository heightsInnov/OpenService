package org.bouncycastle.jce.provider.test;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.TestFailedException;

public abstract class BaseBlockCipherTest
  extends SimpleTest
{
  String algorithm;
  
  BaseBlockCipherTest(String paramString)
  {
    this.algorithm = paramString;
  }
  
  public String getName()
  {
    return this.algorithm;
  }
  
  protected void oidTest(String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt)
    throws Exception
  {
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
    IvParameterSpec localIvParameterSpec = new IvParameterSpec(new byte[16]);
    for (int i = 0; i != paramArrayOfString1.length; i++)
    {
      Cipher localCipher1 = Cipher.getInstance(paramArrayOfString1[i], "BC");
      Cipher localCipher2 = Cipher.getInstance(paramArrayOfString2[i], "BC");
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance(paramArrayOfString1[i], "BC");
      SecretKey localSecretKey = localKeyGenerator.generateKey();
      if (paramArrayOfString2[i].indexOf("/ECB/") > 0)
      {
        localCipher1.init(1, localSecretKey);
        localCipher2.init(2, localSecretKey);
      }
      else
      {
        localCipher1.init(1, localSecretKey, localIvParameterSpec);
        localCipher2.init(2, localSecretKey, localIvParameterSpec);
      }
      byte[] arrayOfByte2 = localCipher2.doFinal(localCipher1.doFinal(arrayOfByte1));
      if (!areEqual(arrayOfByte1, arrayOfByte2)) {
        fail("failed OID test");
      }
      if (localSecretKey.getEncoded().length != 16 + i / paramInt * 8) {
        fail("failed key length test");
      }
    }
  }
  
  protected void wrapOidTest(String[] paramArrayOfString, String paramString)
    throws Exception
  {
    byte[] arrayOfByte = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
    for (int i = 0; i != paramArrayOfString.length; i++)
    {
      Cipher localCipher1 = Cipher.getInstance(paramArrayOfString[i], "BC");
      Cipher localCipher2 = Cipher.getInstance(paramString, "BC");
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance(paramArrayOfString[i], "BC");
      SecretKey localSecretKey = localKeyGenerator.generateKey();
      localCipher1.init(3, localSecretKey);
      localCipher2.init(4, localSecretKey);
      Key localKey = localCipher2.unwrap(localCipher1.wrap(new SecretKeySpec(arrayOfByte, this.algorithm)), this.algorithm, 3);
      if (!areEqual(arrayOfByte, localKey.getEncoded())) {
        fail("failed wrap OID test");
      }
      if (localSecretKey.getEncoded().length != 16 + i * 8) {
        fail("failed key length test");
      }
    }
  }
  
  protected void wrapTest(int paramInt, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    Cipher localCipher = Cipher.getInstance(paramString, "BC");
    localCipher.init(3, new SecretKeySpec(paramArrayOfByte1, this.algorithm));
    try
    {
      byte[] arrayOfByte = localCipher.wrap(new SecretKeySpec(paramArrayOfByte2, this.algorithm));
      if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
        fail("failed wrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
      }
    }
    catch (TestFailedException localTestFailedException)
    {
      throw localTestFailedException;
    }
    catch (Exception localException1)
    {
      fail("failed wrap test exception " + localException1.toString(), localException1);
    }
    localCipher.init(4, new SecretKeySpec(paramArrayOfByte1, this.algorithm));
    try
    {
      Key localKey = localCipher.unwrap(paramArrayOfByte3, this.algorithm, 3);
      if (!areEqual(localKey.getEncoded(), paramArrayOfByte2)) {
        fail("failed unwrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(localKey.getEncoded())));
      }
    }
    catch (Exception localException2)
    {
      fail("failed unwrap test exception " + localException2.toString(), localException2);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\BaseBlockCipherTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */