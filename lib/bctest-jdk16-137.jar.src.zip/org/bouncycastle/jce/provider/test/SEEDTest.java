package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class SEEDTest
  extends BaseBlockCipherTest
{
  static String[] cipherTests = { "128", "28DBC3BC49FFD87DCFA509B11D422BE7", "B41E6BE2EBA84A148E2EED84593C5EC7", "9B9B7BFCD1813CB95D0B3618F40F5122" };
  
  public SEEDTest()
  {
    super("SEED");
  }
  
  public void test(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "SEED");
    Cipher localCipher1 = Cipher.getInstance("SEED/ECB/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("SEED/ECB/NoPadding", "BC");
    try
    {
      localCipher2.init(1, localSecretKeySpec);
    }
    catch (Exception localException1)
    {
      fail("SEED failed initialisation - " + localException1.toString(), localException1);
    }
    try
    {
      localCipher1.init(2, localSecretKeySpec);
    }
    catch (Exception localException2)
    {
      fail("SEED failed initialisation - " + localException2.toString(), localException2);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte2[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      fail("SEED failed encryption - " + localIOException.toString(), localIOException);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
      fail("SEED failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte2.length];
      for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte2.length / 2, arrayOfByte.length - paramArrayOfByte2.length / 2);
    }
    catch (Exception localException3)
    {
      fail("SEED failed encryption - " + localException3.toString(), localException3);
    }
    if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
      fail("SEED failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != cipherTests.length; i += 4) {
      test(Integer.parseInt(cipherTests[i]), Hex.decode(cipherTests[(i + 1)]), Hex.decode(cipherTests[(i + 2)]), Hex.decode(cipherTests[(i + 3)]));
    }
    byte[] arrayOfByte1 = Hex.decode("000102030405060708090a0b0c0d0e0f");
    byte[] arrayOfByte2 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte3 = Hex.decode("bf71f77138b5afea05232a8dad54024e812dc8dd7d132559");
    wrapTest(1, "SEEDWrap", arrayOfByte1, arrayOfByte2, arrayOfByte3);
    String[] arrayOfString1 = { KISAObjectIdentifiers.id_seedCBC.getId() };
    String[] arrayOfString2 = { "SEED/CBC/PKCS7Padding" };
    oidTest(arrayOfString1, arrayOfString2, 1);
    String[] arrayOfString3 = { KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap.getId() };
    wrapOidTest(arrayOfString3, "SEEDWrap");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new SEEDTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\SEEDTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */