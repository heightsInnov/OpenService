package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class CipherStreamTest
  extends SimpleTest
{
  private static byte[] RK = Hex.decode("0123456789ABCDEF");
  private static byte[] RIN = Hex.decode("4e6f772069732074");
  private static byte[] ROUT = Hex.decode("3afbb5c77938280d");
  private static byte[] SIN = Hex.decode("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
  private static final byte[] SK = Hex.decode("80000000000000000000000000000000");
  private static final byte[] SIV = Hex.decode("0000000000000000");
  private static final byte[] SOUT = Hex.decode("4DFA5E481DA23EA09A31022050859936DA52FCEE218005164F267CB65F5CFD7F2B4F97E0FF16924A52DF269515110A07F9E460BC65EF95DA58F740B7D1DBB0AA");
  private static final byte[] HCIN = new byte[64];
  private static final byte[] HCIV = new byte[32];
  private static final byte[] HCK256A = new byte[32];
  private static final byte[] HC256A = Hex.decode("8589075b0df3f6d82fc0c5425179b6a63465f053f2891f808b24744e18480b72ec2792cdbf4dcfeb7769bf8dfa14aee47b4c50e8eaf3a9c8f506016c81697e32");
  private static final byte[] HCK128A = new byte[16];
  private static final byte[] HC128A = Hex.decode("731500823bfd03a0fb2fd77faa63af0ede122fc6a7dc29b662a685278b75ec689036db1e8189600500ade078491fbf9a1cdc30136c3d6e2490f664b29cd57102");
  
  private void runTest(String paramString)
    throws Exception
  {
    String str1 = "ABCDEFGHIJKLMNOPQRSTUVWXY0123456789";
    KeyGenerator localKeyGenerator;
    if (paramString.indexOf('/') < 0) {
      localKeyGenerator = KeyGenerator.getInstance(paramString, "BC");
    } else {
      localKeyGenerator = KeyGenerator.getInstance(paramString.substring(0, paramString.indexOf('/')), "BC");
    }
    Cipher localCipher1 = Cipher.getInstance(paramString, "BC");
    Cipher localCipher2 = Cipher.getInstance(paramString, "BC");
    SecretKey localSecretKey = localKeyGenerator.generateKey();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(str1.getBytes());
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localCipher1.init(1, localSecretKey);
    if (localCipher1.getIV() != null) {
      localCipher2.init(2, localSecretKey, new IvParameterSpec(localCipher1.getIV()));
    } else {
      localCipher2.init(2, localSecretKey);
    }
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    int i;
    while ((i = localCipherInputStream.read()) >= 0) {
      localCipherOutputStream.write(i);
    }
    localCipherInputStream.close();
    localCipherOutputStream.flush();
    localCipherOutputStream.close();
    String str2 = new String(localByteArrayOutputStream.toByteArray());
    if (!str2.equals(str1)) {
      fail("Failed - decrypted data doesn't match.");
    }
  }
  
  private void testAlgorithm(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, paramString);
    Cipher localCipher1 = Cipher.getInstance(paramString, "BC");
    Cipher localCipher2 = Cipher.getInstance(paramString, "BC");
    if (paramArrayOfByte2 != null)
    {
      localCipher1.init(1, localSecretKeySpec, new IvParameterSpec(paramArrayOfByte2));
      localCipher2.init(2, localSecretKeySpec, new IvParameterSpec(paramArrayOfByte2));
    }
    else
    {
      localCipher1.init(1, localSecretKeySpec);
      localCipher2.init(2, localSecretKeySpec);
    }
    byte[] arrayOfByte1 = localCipher1.doFinal(paramArrayOfByte3);
    if (!areEqual(arrayOfByte1, paramArrayOfByte4)) {
      fail(paramString + ": cipher text doesn't match");
    }
    byte[] arrayOfByte2 = localCipher2.doFinal(arrayOfByte1);
    if (!areEqual(arrayOfByte2, paramArrayOfByte3)) {
      fail(paramString + ": plain text doesn't match");
    }
  }
  
  private void testException(String paramString)
  {
    try
    {
      byte[] arrayOfByte1 = { Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113, Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113 };
      byte[] arrayOfByte2 = { Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113, Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113, Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113, Byte.MIN_VALUE, -125, -123, -122, -119, -118, -116, -113 };
      byte[] arrayOfByte3;
      if (paramString.equals("HC256")) {
        arrayOfByte3 = arrayOfByte2;
      } else {
        arrayOfByte3 = arrayOfByte1;
      }
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(arrayOfByte3, paramString);
      Cipher localCipher1 = Cipher.getInstance(paramString, "BC");
      localCipher1.init(1, localSecretKeySpec);
      byte[] arrayOfByte4 = new byte[0];
      try
      {
        localCipher1.update(new byte[20], 0, 20, arrayOfByte4);
        fail("failed exception test - no ShortBufferException thrown");
      }
      catch (ShortBufferException localShortBufferException) {}
      Object localObject;
      try
      {
        Cipher localCipher2 = Cipher.getInstance(paramString, "BC");
        localObject = new PublicKey()
        {
          public String getAlgorithm()
          {
            return "STUB";
          }
          
          public String getFormat()
          {
            return null;
          }
          
          public byte[] getEncoded()
          {
            return null;
          }
        };
        localCipher2.init(1, (Key)localObject);
        fail("failed exception test - no InvalidKeyException thrown for public key");
      }
      catch (InvalidKeyException localInvalidKeyException1) {}
      try
      {
        Cipher localCipher3 = Cipher.getInstance(paramString, "BC");
        localObject = new PrivateKey()
        {
          public String getAlgorithm()
          {
            return "STUB";
          }
          
          public String getFormat()
          {
            return null;
          }
          
          public byte[] getEncoded()
          {
            return null;
          }
        };
        localCipher3.init(2, (Key)localObject);
        fail("failed exception test - no InvalidKeyException thrown for private key");
      }
      catch (InvalidKeyException localInvalidKeyException2) {}
    }
    catch (Exception localException)
    {
      fail("unexpected exception.", localException);
    }
  }
  
  public void performTest()
    throws Exception
  {
    runTest("RC4");
    testException("RC4");
    testAlgorithm("RC4", RK, null, RIN, ROUT);
    runTest("Salsa20");
    testException("Salsa20");
    testAlgorithm("Salsa20", SK, SIV, SIN, SOUT);
    runTest("HC128");
    testException("HC128");
    testAlgorithm("HC128", HCK128A, HCIV, HCIN, HC128A);
    runTest("HC256");
    testException("HC256");
    testAlgorithm("HC256", HCK256A, HCIV, HCIN, HC256A);
    runTest("DES/ECB/PKCS7Padding");
    runTest("DES/CFB8/NoPadding");
  }
  
  public String getName()
  {
    return "CipherStreamTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new CipherStreamTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\CipherStreamTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */