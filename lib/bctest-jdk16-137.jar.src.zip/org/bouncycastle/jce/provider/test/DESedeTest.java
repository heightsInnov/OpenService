package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.Key;
import java.security.SecureRandom;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;
import javax.crypto.spec.RC5ParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class DESedeTest
  extends SimpleTest
{
  static String[] cipherTests1 = { "112", "2f4bc6b30c893fa549d82c560d61cf3eb088aed020603de249d82c560d61cf3e529e95ecd8e05394", "128", "2f4bc6b30c893fa549d82c560d61cf3eb088aed020603de249d82c560d61cf3e529e95ecd8e05394", "168", "50ddb583a25c21e6c9233f8e57a86d40bb034af421c03096c9233f8e57a86d402fce91e8eb639f89", "192", "50ddb583a25c21e6c9233f8e57a86d40bb034af421c03096c9233f8e57a86d402fce91e8eb639f89" };
  static byte[] input1 = Hex.decode("000102030405060708090a0b0c0d0e0fff0102030405060708090a0b0c0d0e0f");
  static byte[] input2 = Hex.decode("000102030405060708090a0b0c0d0e0fff0102030405060708090a0b0c");
  static RC2ParameterSpec rc2Spec = new RC2ParameterSpec(128, Hex.decode("0123456789abcdef"));
  static RC5ParameterSpec rc5Spec = new RC5ParameterSpec(16, 16, 32, Hex.decode("0123456789abcdef"));
  
  public String getName()
  {
    return "DESEDE";
  }
  
  private boolean equalArray(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  private boolean equalArray(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    if (paramArrayOfByte1.length < paramInt) {
      return false;
    }
    if (paramArrayOfByte2.length < paramInt) {
      return false;
    }
    for (int i = 0; i != paramInt; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  private void wrapTest(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    try
    {
      Cipher localCipher = Cipher.getInstance("DESedeWrap", "BC");
      localCipher.init(3, new SecretKeySpec(paramArrayOfByte1, "DESEDE"), new IvParameterSpec(paramArrayOfByte2));
      try
      {
        byte[] arrayOfByte = localCipher.wrap(new SecretKeySpec(paramArrayOfByte3, "DESEDE"));
        if (!equalArray(arrayOfByte, paramArrayOfByte4)) {
          fail("failed wrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte4)) + " got " + new String(Hex.encode(arrayOfByte)));
        }
      }
      catch (Exception localException2)
      {
        fail("failed wrap test exception " + localException2.toString());
      }
      localCipher.init(4, new SecretKeySpec(paramArrayOfByte1, "DESEDE"));
      try
      {
        Key localKey = localCipher.unwrap(paramArrayOfByte4, "DESede", 3);
        if (!equalArray(localKey.getEncoded(), paramArrayOfByte3)) {
          fail("failed unwrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(localKey.getEncoded())));
        }
      }
      catch (Exception localException3)
      {
        fail("failed unwrap test exception " + localException3.toString());
      }
    }
    catch (Exception localException1)
    {
      fail("failed exception " + localException1.toString());
    }
  }
  
  public void test(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    SecretKey localSecretKey = null;
    Cipher localCipher1 = null;
    Cipher localCipher2 = null;
    FixedSecureRandom localFixedSecureRandom = new FixedSecureRandom(null);
    try
    {
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance("DESEDE", "BC");
      localKeyGenerator.init(paramInt, localFixedSecureRandom);
      localSecretKey = localKeyGenerator.generateKey();
      localCipher1 = Cipher.getInstance("DESEDE/ECB/PKCS7Padding", "BC");
      localCipher2 = Cipher.getInstance("DESEDE/ECB/PKCS7Padding", "BC");
      localCipher2.init(1, localSecretKey, localFixedSecureRandom);
    }
    catch (Exception localException1)
    {
      fail("DESEDE failed initialisation - " + localException1.toString());
    }
    try
    {
      localCipher1.init(2, localSecretKey);
    }
    catch (Exception localException2)
    {
      fail("DESEDE failed initialisation - " + localException2.toString());
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte1.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte1[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte1, paramArrayOfByte1.length / 2, paramArrayOfByte1.length - paramArrayOfByte1.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      fail("DESEDE failed encryption - " + localIOException.toString());
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!equalArray(arrayOfByte, paramArrayOfByte2)) {
      fail("DESEDE failed encryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte1.length];
      for (int j = 0; j != paramArrayOfByte1.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte1.length / 2, arrayOfByte.length - paramArrayOfByte1.length / 2);
    }
    catch (Exception localException3)
    {
      fail("DESEDE failed encryption - " + localException3.toString());
    }
    if (!equalArray(arrayOfByte, paramArrayOfByte1)) {
      fail("DESEDE failed decryption - expected " + new String(Hex.encode(paramArrayOfByte1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    try
    {
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance("DESede", "BC");
      DESedeKeySpec localDESedeKeySpec = (DESedeKeySpec)localSecretKeyFactory.getKeySpec((SecretKey)localSecretKey, DESedeKeySpec.class);
      if (!equalArray(localSecretKey.getEncoded(), localDESedeKeySpec.getKey(), 16)) {
        fail("DESEDE KeySpec does not match key.");
      }
    }
    catch (Exception localException4)
    {
      fail("DESEDE failed keyspec - " + localException4.toString());
    }
  }
  
  public void performTest()
  {
    for (int i = 0; i != cipherTests1.length; i += 2) {
      test(Integer.parseInt(cipherTests1[i]), input1, Hex.decode(cipherTests1[(i + 1)]));
    }
    byte[] arrayOfByte1 = Hex.decode("255e0d1c07b646dfb3134cc843ba8aa71f025b7c0838251f");
    byte[] arrayOfByte2 = Hex.decode("5dd4cbfc96f5453b");
    byte[] arrayOfByte3 = Hex.decode("2923bf85e06dd6ae529149f1f1bae9eab3a7da3d860d3e98");
    byte[] arrayOfByte4 = Hex.decode("690107618ef092b3b48ca1796b234ae9fa33ebb4159604037db5d6a84eb3aac2768c632775a467d4");
    wrapTest(1, arrayOfByte1, arrayOfByte2, arrayOfByte3, arrayOfByte4);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new DESedeTest());
  }
  
  private class FixedSecureRandom
    extends SecureRandom
  {
    byte[] seed = { -86, -3, 18, -10, 89, -54, -26, 52, -119, -76, 121, -27, 7, 109, -34, -62, -16, 108, -75, -113 };
    
    private FixedSecureRandom() {}
    
    public void nextBytes(byte[] paramArrayOfByte)
    {
      int i = 0;
      while (i + this.seed.length < paramArrayOfByte.length)
      {
        System.arraycopy(this.seed, 0, paramArrayOfByte, i, this.seed.length);
        i += this.seed.length;
      }
      System.arraycopy(this.seed, 0, paramArrayOfByte, i, paramArrayOfByte.length - i);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\DESedeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */