package org.bouncycastle.jce.provider.test;

import java.io.PrintStream;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SealedTest
  implements Test
{
  static final String provider = "BC";
  
  public String getName()
  {
    return "SealedObject";
  }
  
  public TestResult perform()
  {
    try
    {
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance("DES", "BC");
      SecretKey localSecretKey = localKeyGenerator.generateKey();
      Cipher localCipher = Cipher.getInstance("DES/ECB/PKCS5Padding", "BC");
      localCipher.init(1, localSecretKey);
      String str = "Hello world";
      SealedObject localSealedObject = new SealedObject(str, localCipher);
      localCipher.init(2, localSecretKey);
      Object localObject = localSealedObject.getObject(localCipher);
      if (!localObject.equals(str)) {
        return new SimpleTestResult(false, "Result object 1 not equalorig: " + str + " res: " + localObject);
      }
      localObject = localSealedObject.getObject(localSecretKey);
      if (!localObject.equals(str)) {
        return new SimpleTestResult(false, "Result object 2 not equalorig: " + str + " res: " + localObject);
      }
      localObject = localSealedObject.getObject(localSecretKey, "BC");
      if (!localObject.equals(str)) {
        return new SimpleTestResult(false, "Result object 3 not equalorig: " + str + " res: " + localObject);
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": failed excpetion - " + localException.toString(), localException);
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    SealedTest localSealedTest = new SealedTest();
    TestResult localTestResult = localSealedTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\SealedTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */