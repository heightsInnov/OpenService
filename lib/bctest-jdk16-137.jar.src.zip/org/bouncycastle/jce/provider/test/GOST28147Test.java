package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class GOST28147Test
  extends SimpleTest
{
  static String[] cipherTests = { "256", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "4e6f77206973207468652074696d6520666f7220616c6c20", "281630d0d5770030068c252d841e84149ccc1912052dbc02", "256", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", "4e6f77206973207468652074696d65208a920c6ed1a804f5", "88e543dfc04dc4f764fa7b624741cec07de49b007bf36065" };
  
  public String getName()
  {
    return "GOST28147";
  }
  
  public void testECB(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "GOST28147");
    Cipher localCipher1 = Cipher.getInstance("GOST28147/ECB/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("GOST28147/ECB/NoPadding", "BC");
    localCipher2.init(1, localSecretKeySpec);
    localCipher1.init(2, localSecretKeySpec);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
      localCipherOutputStream.write(paramArrayOfByte2[i]);
    }
    localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
    localCipherOutputStream.close();
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
      fail("GOST28147 failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
    arrayOfByte = new byte[paramArrayOfByte2.length];
    for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
      arrayOfByte[j] = ((byte)localDataInputStream.read());
    }
    localDataInputStream.readFully(arrayOfByte, paramArrayOfByte2.length / 2, arrayOfByte.length - paramArrayOfByte2.length / 2);
    if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
      fail("GOST28147 failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public void testCFB(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "GOST28147");
    Cipher localCipher1 = Cipher.getInstance("GOST28147/CFB8/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("GOST28147/CFB8/NoPadding", "BC");
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
    localCipher2.init(1, localSecretKeySpec, new IvParameterSpec(arrayOfByte1));
    localCipher1.init(2, localSecretKeySpec, new IvParameterSpec(arrayOfByte1));
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
      localCipherOutputStream.write(paramArrayOfByte2[i]);
    }
    localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
    localCipherOutputStream.close();
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte2, paramArrayOfByte3)) {
      fail("GOST28147 failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte2)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte2);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
    arrayOfByte2 = new byte[paramArrayOfByte2.length];
    for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
      arrayOfByte2[j] = ((byte)localDataInputStream.read());
    }
    localDataInputStream.readFully(arrayOfByte2, paramArrayOfByte2.length / 2, arrayOfByte2.length - paramArrayOfByte2.length / 2);
    if (!areEqual(arrayOfByte2, paramArrayOfByte2)) {
      fail("GOST28147 failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte2)));
    }
  }
  
  private void oidTest()
  {
    String[] arrayOfString1 = { CryptoProObjectIdentifiers.gostR28147_cbc.getId() };
    String[] arrayOfString2 = { "GOST28147/CBC/PKCS7Padding" };
    try
    {
      byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(new byte[8]);
      for (int i = 0; i != arrayOfString1.length; i++)
      {
        Cipher localCipher1 = Cipher.getInstance(arrayOfString1[i], "BC");
        Cipher localCipher2 = Cipher.getInstance(arrayOfString2[i], "BC");
        KeyGenerator localKeyGenerator = KeyGenerator.getInstance(arrayOfString1[i], "BC");
        SecretKey localSecretKey = localKeyGenerator.generateKey();
        localCipher1.init(1, localSecretKey, localIvParameterSpec);
        localCipher2.init(2, localSecretKey, localIvParameterSpec);
        byte[] arrayOfByte2 = localCipher2.doFinal(localCipher1.doFinal(arrayOfByte1));
        if (!areEqual(arrayOfByte1, arrayOfByte2)) {
          fail("failed OID test");
        }
      }
    }
    catch (Exception localException)
    {
      fail("failed exception " + localException.toString(), localException);
    }
  }
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != cipherTests.length; i += 8)
    {
      testECB(Integer.parseInt(cipherTests[i]), Hex.decode(cipherTests[(i + 1)]), Hex.decode(cipherTests[(i + 2)]), Hex.decode(cipherTests[(i + 3)]));
      testCFB(Integer.parseInt(cipherTests[(i + 4)]), Hex.decode(cipherTests[(i + 4 + 1)]), Hex.decode(cipherTests[(i + 4 + 2)]), Hex.decode(cipherTests[(i + 4 + 3)]));
      oidTest();
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new GOST28147Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\GOST28147Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */