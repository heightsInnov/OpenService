package org.bouncycastle.jce.provider.test;

import java.security.Security;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class MacTest
  extends SimpleTest
{
  static byte[] keyBytes = Hex.decode("0123456789abcdef");
  static byte[] ivBytes = Hex.decode("1234567890abcdef");
  static byte[] input = Hex.decode("37363534333231204e6f77206973207468652074696d6520666f7220");
  static byte[] output1 = Hex.decode("f1d30f68");
  static byte[] output2 = Hex.decode("58d2e77e");
  static byte[] output3 = Hex.decode("cd647403");
  static byte[] keyBytesISO9797 = Hex.decode("7CA110454A1A6E570131D9619DC1376E");
  static byte[] inputISO9797 = "Hello World !!!!".getBytes();
  static byte[] outputISO9797 = Hex.decode("F09B856213BAB83B");
  static byte[] inputDesEDE64 = "Hello World !!!!".getBytes();
  static byte[] outputDesEDE64 = Hex.decode("862304d33af01096");
  
  private void aliasTest(SecretKey paramSecretKey, String paramString, String[] paramArrayOfString)
    throws Exception
  {
    Mac localMac = Mac.getInstance(paramString, "BC");
    localMac.init(paramSecretKey);
    localMac.update(input, 0, input.length);
    byte[] arrayOfByte1 = localMac.doFinal();
    for (int i = 0; i != paramArrayOfString.length; i++)
    {
      localMac = Mac.getInstance(paramArrayOfString[i], "BC");
      localMac.init(paramSecretKey);
      localMac.update(input, 0, input.length);
      byte[] arrayOfByte2 = localMac.doFinal();
      if (!areEqual(arrayOfByte2, arrayOfByte1)) {
        fail("Failed - expected " + new String(Hex.encode(arrayOfByte1)) + " got " + new String(Hex.encode(arrayOfByte2)));
      }
    }
  }
  
  public void performTest()
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(keyBytes, "DES");
    Mac localMac = Mac.getInstance("DESMac", "BC");
    localMac.init(localSecretKeySpec);
    localMac.update(input, 0, input.length);
    byte[] arrayOfByte = localMac.doFinal();
    if (!areEqual(arrayOfByte, output1)) {
      fail("Failed - expected " + new String(Hex.encode(output1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localMac.init(localSecretKeySpec, new IvParameterSpec(ivBytes));
    localMac.update(input, 0, input.length);
    arrayOfByte = localMac.doFinal();
    if (!areEqual(arrayOfByte, output2)) {
      fail("Failed - expected " + new String(Hex.encode(output2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localMac = Mac.getInstance("DESMac/CFB8", "BC");
    localMac.init(localSecretKeySpec, new IvParameterSpec(ivBytes));
    localMac.update(input, 0, input.length);
    arrayOfByte = localMac.doFinal();
    if (!areEqual(arrayOfByte, output3)) {
      fail("Failed - expected " + new String(Hex.encode(output3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localSecretKeySpec = new SecretKeySpec(keyBytesISO9797, "DESEDE");
    localMac = Mac.getInstance("ISO9797ALG3", "BC");
    localMac.init(localSecretKeySpec);
    localMac.update(inputISO9797, 0, inputISO9797.length);
    arrayOfByte = localMac.doFinal();
    if (!areEqual(arrayOfByte, outputISO9797)) {
      fail("Failed - expected " + new String(Hex.encode(outputISO9797)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localSecretKeySpec = new SecretKeySpec(keyBytesISO9797, "DESEDE");
    localMac = Mac.getInstance("DESEDE64", "BC");
    localMac.init(localSecretKeySpec);
    localMac.update(inputDesEDE64, 0, inputDesEDE64.length);
    arrayOfByte = localMac.doFinal();
    if (!areEqual(arrayOfByte, outputDesEDE64)) {
      fail("Failed - expected " + new String(Hex.encode(outputDesEDE64)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    aliasTest(new SecretKeySpec(keyBytesISO9797, "DESede"), "DESedeMac64withISO7816-4Padding", new String[] { "DESEDE64WITHISO7816-4PADDING", "DESEDEISO9797ALG1MACWITHISO7816-4PADDING", "DESEDEISO9797ALG1WITHISO7816-4PADDING" });
    aliasTest(new SecretKeySpec(keyBytesISO9797, "DESede"), "ISO9797ALG3WITHISO7816-4PADDING", new String[] { "ISO9797ALG3MACWITHISO7816-4PADDING" });
  }
  
  public String getName()
  {
    return "Mac";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new MacTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\MacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */