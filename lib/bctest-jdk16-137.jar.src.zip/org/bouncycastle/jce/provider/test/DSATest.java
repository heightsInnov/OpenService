package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.DSAParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.bouncycastle.jce.spec.ECPrivateKeySpec;
import org.bouncycastle.jce.spec.ECPublicKeySpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.F2m;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.util.BigIntegers;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTest;

public class DSATest
  extends SimpleTest
{
  byte[] k1 = Hex.decode("d5014e4b60ef2ba8b6211b4062ba3224e0427dd3");
  byte[] k2 = Hex.decode("345e8d05c075c3a508df729a1685690e68fcfb8c8117847e89063bca1f85d968fd281540b6e13bd1af989a1fbf17e06462bf511f9d0b140fb48ac1b1baa5bded");
  SecureRandom random = new FixedSecureRandom(new byte[][] { this.k1, this.k2 });
  
  public void testCompat()
    throws Exception
  {
    Signature localSignature = Signature.getInstance("DSA", "SUN");
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("DSA", "SUN");
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
    localKeyPairGenerator.initialize(512, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PrivateKey localPrivateKey = localKeyPair.getPrivate();
    Object localObject = localKeyPair.getPublic();
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("DSA", "BC");
    localSignature.initVerify((PublicKey)localObject);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SUN -> BC verification failed");
    }
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("DSA", "SUN");
    localSignature.initVerify((PublicKey)localObject);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("BC -> SUN verification failed");
    }
    KeyFactory localKeyFactory = KeyFactory.getInstance("DSA", "BC");
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(((PublicKey)localObject).getEncoded());
    DSAPublicKey localDSAPublicKey = (DSAPublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
    checkPublic(localDSAPublicKey, (PublicKey)localObject);
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(localPrivateKey.getEncoded());
    DSAPrivateKey localDSAPrivateKey = (DSAPrivateKey)localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    checkPrivateKey(localDSAPrivateKey, localPrivateKey);
    localKeyFactory = KeyFactory.getInstance("DSA", "SUN");
    localX509EncodedKeySpec = new X509EncodedKeySpec(localDSAPublicKey.getEncoded());
    localObject = (DSAPublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
    checkPublic(localDSAPublicKey, (PublicKey)localObject);
    localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(localDSAPrivateKey.getEncoded());
    localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    checkPrivateKey(localDSAPrivateKey, localPrivateKey);
  }
  
  private void checkPublic(DSAPublicKey paramDSAPublicKey, PublicKey paramPublicKey)
  {
    if (!paramDSAPublicKey.getY().equals(((DSAPublicKey)paramPublicKey).getY())) {
      fail("public number not decoded properly");
    }
    if (!paramDSAPublicKey.getParams().getG().equals(((DSAPublicKey)paramPublicKey).getParams().getG())) {
      fail("public generator not decoded properly");
    }
    if (!paramDSAPublicKey.getParams().getP().equals(((DSAPublicKey)paramPublicKey).getParams().getP())) {
      fail("public p value not decoded properly");
    }
    if (!paramDSAPublicKey.getParams().getQ().equals(((DSAPublicKey)paramPublicKey).getParams().getQ())) {
      fail("public q value not decoded properly");
    }
  }
  
  private void checkPrivateKey(DSAPrivateKey paramDSAPrivateKey, PrivateKey paramPrivateKey)
  {
    if (!paramDSAPrivateKey.getX().equals(((DSAPrivateKey)paramPrivateKey).getX())) {
      fail("private number not decoded properly");
    }
    if (!paramDSAPrivateKey.getParams().getG().equals(((DSAPrivateKey)paramPrivateKey).getParams().getG())) {
      fail("private generator not decoded properly");
    }
    if (!paramDSAPrivateKey.getParams().getP().equals(((DSAPrivateKey)paramPrivateKey).getParams().getP())) {
      fail("private p value not decoded properly");
    }
    if (!paramDSAPrivateKey.getParams().getQ().equals(((DSAPrivateKey)paramPrivateKey).getParams().getQ())) {
      fail("private q value not decoded properly");
    }
  }
  
  private Object serializeDeserialize(Object paramObject)
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
    localObjectOutputStream.writeObject(paramObject);
    localObjectOutputStream.close();
    ObjectInputStream localObjectInputStream = new ObjectInputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
    return localObjectInputStream.readObject();
  }
  
  private void testECDSA239bitPrime()
    throws Exception
  {
    BigInteger localBigInteger1 = new BigInteger("308636143175167811492622547300668018854959378758531778147462058306432176");
    BigInteger localBigInteger2 = new BigInteger("323813553209797357708078776831250505931891051755007842781978505179448783");
    byte[] arrayOfByte1 = BigIntegers.asUnsignedByteArray(new BigInteger("700000017569056646655505781757157107570501575775705779575555657156756655"));
    FixedSecureRandom localFixedSecureRandom = new FixedSecureRandom(arrayOfByte1);
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    ECPrivateKeySpec localECPrivateKeySpec = new ECPrivateKeySpec(new BigInteger("876300101507107567501066130761671078357010671067781776716671676178726717"), localECParameterSpec);
    ECPublicKeySpec localECPublicKeySpec = new ECPublicKeySpec(localFp.decodePoint(Hex.decode("025b6dc53bc61a2548ffb0f671472de6c9521a9d2d2534e65abfcbd5fe0c70")), localECParameterSpec);
    Signature localSignature = Signature.getInstance("ECDSA", "BC");
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localECPrivateKeySpec);
    PublicKey localPublicKey = localKeyFactory.generatePublic(localECPublicKeySpec);
    localSignature.initSign(localPrivateKey, localFixedSecureRandom);
    byte[] arrayOfByte2 = { 97, 98, 99 };
    localSignature.update(arrayOfByte2);
    byte[] arrayOfByte3 = localSignature.sign();
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte2);
    if (!localSignature.verify(arrayOfByte3)) {
      fail("239 Bit EC verification failed");
    }
    BigInteger[] arrayOfBigInteger = derDecode(arrayOfByte3);
    if (!localBigInteger1.equals(arrayOfBigInteger[0])) {
      fail("r component wrong." + System.getProperty("line.separator") + " expecting: " + localBigInteger1 + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[0]);
    }
    if (!localBigInteger2.equals(arrayOfBigInteger[1])) {
      fail("s component wrong." + System.getProperty("line.separator") + " expecting: " + localBigInteger2 + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[1]);
    }
  }
  
  private void testECDSA239bitBinary()
    throws Exception
  {
    BigInteger localBigInteger1 = new BigInteger("21596333210419611985018340039034612628818151486841789642455876922391552");
    BigInteger localBigInteger2 = new BigInteger("197030374000731686738334997654997227052849804072198819102649413465737174");
    byte[] arrayOfByte1 = BigIntegers.asUnsignedByteArray(new BigInteger("171278725565216523967285789236956265265265235675811949404040041670216363"));
    FixedSecureRandom localFixedSecureRandom = new FixedSecureRandom(arrayOfByte1);
    ECCurve.F2m localF2m = new ECCurve.F2m(239, 36, new BigInteger("32010857077C5431123A46B808906756F543423E8D27877578125778AC76", 16), new BigInteger("790408F2EEDAF392B012EDEFB3392F30F4327C0CA3F31FC383C422AA8C16", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec(localF2m, localF2m.decodePoint(Hex.decode("0457927098FA932E7C0A96D3FD5B706EF7E5F5C156E16B7E7C86038552E91D61D8EE5077C33FECF6F1A16B268DE469C3C7744EA9A971649FC7A9616305")), new BigInteger("220855883097298041197912187592864814557886993776713230936715041207411783"), BigInteger.valueOf(4L));
    ECPrivateKeySpec localECPrivateKeySpec = new ECPrivateKeySpec(new BigInteger("145642755521911534651321230007534120304391871461646461466464667494947990"), localECParameterSpec);
    ECPublicKeySpec localECPublicKeySpec = new ECPublicKeySpec(localF2m.decodePoint(Hex.decode("045894609CCECF9A92533F630DE713A958E96C97CCB8F5ABB5A688A238DEED6DC2D9D0C94EBFB7D526BA6A61764175B99CB6011E2047F9F067293F57F5")), localECParameterSpec);
    Signature localSignature = Signature.getInstance("ECDSA", "BC");
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localECPrivateKeySpec);
    PublicKey localPublicKey = localKeyFactory.generatePublic(localECPublicKeySpec);
    byte[] arrayOfByte2 = { 97, 98, 99 };
    localSignature.initSign(localPrivateKey, localFixedSecureRandom);
    localSignature.update(arrayOfByte2);
    byte[] arrayOfByte3 = localSignature.sign();
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte2);
    if (!localSignature.verify(arrayOfByte3)) {
      fail("239 Bit EC verification failed");
    }
    BigInteger[] arrayOfBigInteger = derDecode(arrayOfByte3);
    if (!localBigInteger1.equals(arrayOfBigInteger[0])) {
      fail("r component wrong." + System.getProperty("line.separator") + " expecting: " + localBigInteger1 + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[0]);
    }
    if (!localBigInteger2.equals(arrayOfBigInteger[1])) {
      fail("s component wrong." + System.getProperty("line.separator") + " expecting: " + localBigInteger2 + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[1]);
    }
  }
  
  private void testECDSA239bitBinary(String paramString, DERObjectIdentifier paramDERObjectIdentifier)
    throws Exception
  {
    BigInteger localBigInteger1 = new BigInteger("21596333210419611985018340039034612628818151486841789642455876922391552");
    BigInteger localBigInteger2 = new BigInteger("197030374000731686738334997654997227052849804072198819102649413465737174");
    byte[] arrayOfByte1 = BigIntegers.asUnsignedByteArray(new BigInteger("171278725565216523967285789236956265265265235675811949404040041670216363"));
    FixedSecureRandom localFixedSecureRandom = new FixedSecureRandom(arrayOfByte1);
    ECCurve.F2m localF2m = new ECCurve.F2m(239, 36, new BigInteger("32010857077C5431123A46B808906756F543423E8D27877578125778AC76", 16), new BigInteger("790408F2EEDAF392B012EDEFB3392F30F4327C0CA3F31FC383C422AA8C16", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec(localF2m, localF2m.decodePoint(Hex.decode("0457927098FA932E7C0A96D3FD5B706EF7E5F5C156E16B7E7C86038552E91D61D8EE5077C33FECF6F1A16B268DE469C3C7744EA9A971649FC7A9616305")), new BigInteger("220855883097298041197912187592864814557886993776713230936715041207411783"), BigInteger.valueOf(4L));
    ECPrivateKeySpec localECPrivateKeySpec = new ECPrivateKeySpec(new BigInteger("145642755521911534651321230007534120304391871461646461466464667494947990"), localECParameterSpec);
    ECPublicKeySpec localECPublicKeySpec = new ECPublicKeySpec(localF2m.decodePoint(Hex.decode("045894609CCECF9A92533F630DE713A958E96C97CCB8F5ABB5A688A238DEED6DC2D9D0C94EBFB7D526BA6A61764175B99CB6011E2047F9F067293F57F5")), localECParameterSpec);
    Signature localSignature = Signature.getInstance(paramString, "BC");
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localECPrivateKeySpec);
    PublicKey localPublicKey = localKeyFactory.generatePublic(localECPublicKeySpec);
    byte[] arrayOfByte2 = { 97, 98, 99 };
    localSignature.initSign(localPrivateKey, localFixedSecureRandom);
    localSignature.update(arrayOfByte2);
    byte[] arrayOfByte3 = localSignature.sign();
    localSignature = Signature.getInstance(paramDERObjectIdentifier.getId(), "BC");
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte2);
    if (!localSignature.verify(arrayOfByte3)) {
      fail("239 Bit EC RIPEMD160 verification failed");
    }
  }
  
  private void testGeneration()
    throws Exception
  {
    Signature localSignature = Signature.getInstance("DSA", "BC");
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("DSA", "BC");
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
    try
    {
      localKeyPairGenerator.initialize(513, new SecureRandom());
      fail("illegal parameter 513 check failed.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      localKeyPairGenerator.initialize(510, new SecureRandom());
      fail("illegal parameter 510 check failed.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
    try
    {
      localKeyPairGenerator.initialize(1025, new SecureRandom());
      fail("illegal parameter 1025 check failed.");
    }
    catch (IllegalArgumentException localIllegalArgumentException3) {}
    localKeyPairGenerator.initialize(512, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PrivateKey localPrivateKey = localKeyPair.getPrivate();
    PublicKey localPublicKey = localKeyPair.getPublic();
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("DSA", "BC");
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("DSA verification failed");
    }
    DSAPublicKey localDSAPublicKey = (DSAPublicKey)serializeDeserialize(localPublicKey);
    checkPublic(localDSAPublicKey, localPublicKey);
    DSAPrivateKey localDSAPrivateKey = (DSAPrivateKey)serializeDeserialize(localPrivateKey);
    checkPrivateKey(localDSAPrivateKey, localPrivateKey);
    localSignature = Signature.getInstance("ECDSA", "BC");
    localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    Object localObject = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec((ECCurve)localObject, ((ECCurve)localObject).decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    localKeyPairGenerator.initialize(localECParameterSpec, new SecureRandom());
    localKeyPair = localKeyPairGenerator.generateKeyPair();
    localPrivateKey = localKeyPair.getPrivate();
    localPublicKey = localKeyPair.getPublic();
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("ECDSA", "BC");
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("ECDSA verification failed");
    }
    localSignature = Signature.getInstance("ECDSA", "BC");
    localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    localObject = new ECCurve.F2m(239, 36, new BigInteger("32010857077C5431123A46B808906756F543423E8D27877578125778AC76", 16), new BigInteger("790408F2EEDAF392B012EDEFB3392F30F4327C0CA3F31FC383C422AA8C16", 16));
    localECParameterSpec = new ECParameterSpec((ECCurve)localObject, ((ECCurve)localObject).decodePoint(Hex.decode("0457927098FA932E7C0A96D3FD5B706EF7E5F5C156E16B7E7C86038552E91D61D8EE5077C33FECF6F1A16B268DE469C3C7744EA9A971649FC7A9616305")), new BigInteger("220855883097298041197912187592864814557886993776713230936715041207411783"), BigInteger.valueOf(4L));
    localKeyPairGenerator.initialize(localECParameterSpec, new SecureRandom());
    localKeyPair = localKeyPairGenerator.generateKeyPair();
    localPrivateKey = localKeyPair.getPrivate();
    localPublicKey = localKeyPair.getPublic();
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature = Signature.getInstance("ECDSA", "BC");
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("ECDSA verification failed");
    }
  }
  
  private void testParameters()
    throws Exception
  {
    AlgorithmParameterGenerator localAlgorithmParameterGenerator = AlgorithmParameterGenerator.getInstance("DSA", "BC");
    localAlgorithmParameterGenerator.init(512, this.random);
    AlgorithmParameters localAlgorithmParameters1 = localAlgorithmParameterGenerator.generateParameters();
    byte[] arrayOfByte1 = localAlgorithmParameters1.getEncoded();
    AlgorithmParameters localAlgorithmParameters2 = AlgorithmParameters.getInstance("DSA", "BC");
    localAlgorithmParameters2.init(arrayOfByte1);
    byte[] arrayOfByte2 = localAlgorithmParameters2.getEncoded();
    if (!areEqual(arrayOfByte1, arrayOfByte2)) {
      fail("encode/decode parameters failed");
    }
    DSAParameterSpec localDSAParameterSpec = (DSAParameterSpec)localAlgorithmParameters1.getParameterSpec(DSAParameterSpec.class);
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("DSA", "BC");
    localKeyPairGenerator.initialize(localDSAParameterSpec, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PrivateKey localPrivateKey = localKeyPair.getPrivate();
    PublicKey localPublicKey = localKeyPair.getPublic();
    Signature localSignature = Signature.getInstance("DSA", "BC");
    byte[] arrayOfByte3 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
    localSignature.initSign(localPrivateKey);
    localSignature.update(arrayOfByte3);
    byte[] arrayOfByte4 = localSignature.sign();
    localSignature = Signature.getInstance("DSA", "BC");
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte3);
    if (!localSignature.verify(arrayOfByte4)) {
      fail("DSA verification failed");
    }
  }
  
  public void performTest()
    throws Exception
  {
    testCompat();
    testECDSA239bitPrime();
    testECDSA239bitBinary();
    testECDSA239bitBinary("RIPEMD160withECDSA", TeleTrusTObjectIdentifiers.ecSignWithRipemd160);
    testECDSA239bitBinary("SHA1withECDSA", TeleTrusTObjectIdentifiers.ecSignWithSha1);
    testECDSA239bitBinary("SHA224withECDSA", X9ObjectIdentifiers.ecdsa_with_SHA224);
    testECDSA239bitBinary("SHA256withECDSA", X9ObjectIdentifiers.ecdsa_with_SHA256);
    testECDSA239bitBinary("SHA384withECDSA", X9ObjectIdentifiers.ecdsa_with_SHA384);
    testECDSA239bitBinary("SHA512withECDSA", X9ObjectIdentifiers.ecdsa_with_SHA512);
    testGeneration();
    testParameters();
  }
  
  protected BigInteger[] derDecode(byte[] paramArrayOfByte)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    BigInteger[] arrayOfBigInteger = new BigInteger[2];
    arrayOfBigInteger[0] = ((DERInteger)localASN1Sequence.getObjectAt(0)).getValue();
    arrayOfBigInteger[1] = ((DERInteger)localASN1Sequence.getObjectAt(1)).getValue();
    return arrayOfBigInteger;
  }
  
  public String getName()
  {
    return "DSA/ECDSA";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new DSATest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\DSATest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */