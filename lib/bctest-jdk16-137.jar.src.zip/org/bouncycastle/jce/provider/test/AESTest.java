package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class AESTest
  extends BaseBlockCipherTest
{
  static String[] cipherTests = { "128", "000102030405060708090a0b0c0d0e0f", "00112233445566778899aabbccddeeff", "69c4e0d86a7b0430d8cdb78070b4c55a", "192", "000102030405060708090a0b0c0d0e0f1011121314151617", "00112233445566778899aabbccddeeff", "dda97ca4864cdfe06eaf70a0ec0d7191", "256", "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f", "00112233445566778899aabbccddeeff", "8ea2b7ca516745bfeafc49904b496089" };
  
  public AESTest()
  {
    super("AES");
  }
  
  private void test(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "AES");
    Cipher localCipher1 = Cipher.getInstance("AES/ECB/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("AES/ECB/NoPadding", "BC");
    try
    {
      localCipher2.init(1, localSecretKeySpec);
    }
    catch (Exception localException1)
    {
      fail("AES failed initialisation - " + localException1.toString(), localException1);
    }
    try
    {
      localCipher1.init(2, localSecretKeySpec);
    }
    catch (Exception localException2)
    {
      fail("AES failed initialisation - " + localException2.toString(), localException2);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte2[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      fail("AES failed encryption - " + localIOException.toString(), localIOException);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
      fail("AES failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte2.length];
      for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte2.length / 2, arrayOfByte.length - paramArrayOfByte2.length / 2);
    }
    catch (Exception localException3)
    {
      fail("AES failed encryption - " + localException3.toString(), localException3);
    }
    if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
      fail("AES failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  private void eaxTest()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("233952DEE4D5ED5F9B9C6D6FF80FF478");
    byte[] arrayOfByte2 = Hex.decode("62EC67F9C3A4A407FCB2A8C49031A8B3");
    byte[] arrayOfByte3 = Hex.decode("68656c6c6f20776f726c642121");
    byte[] arrayOfByte4 = Hex.decode("2f9f76cb7659c70e4be11670a3e193ae1bc6b5762a");
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(arrayOfByte1, "AES");
    Cipher localCipher1 = Cipher.getInstance("AES/EAX/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("AES/EAX/NoPadding", "BC");
    localCipher1.init(1, localSecretKeySpec, new IvParameterSpec(arrayOfByte2));
    byte[] arrayOfByte5 = localCipher1.doFinal(arrayOfByte3);
    if (!areEqual(arrayOfByte5, arrayOfByte4)) {
      fail("ciphertext doesn't match in EAX");
    }
    localCipher2.init(2, localSecretKeySpec, new IvParameterSpec(arrayOfByte2));
    byte[] arrayOfByte6 = localCipher2.doFinal(arrayOfByte4);
    if (!areEqual(arrayOfByte6, arrayOfByte3)) {
      fail("plaintext doesn't match in EAX");
    }
    try
    {
      localCipher1 = Cipher.getInstance("AES/EAX/PKCS5Padding", "BC");
      fail("bad padding missed in EAX");
    }
    catch (NoSuchPaddingException localNoSuchPaddingException) {}
  }
  
  private void ccmTest()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("404142434445464748494a4b4c4d4e4f");
    byte[] arrayOfByte2 = Hex.decode("10111213141516");
    byte[] arrayOfByte3 = Hex.decode("68656c6c6f20776f726c642121");
    byte[] arrayOfByte4 = Hex.decode("39264f148b54c456035de0a531c8344f46db12b388");
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(arrayOfByte1, "AES");
    Cipher localCipher1 = Cipher.getInstance("AES/CCM/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("AES/CCM/NoPadding", "BC");
    localCipher1.init(1, localSecretKeySpec, new IvParameterSpec(arrayOfByte2));
    byte[] arrayOfByte5 = localCipher1.doFinal(arrayOfByte3);
    if (!areEqual(arrayOfByte5, arrayOfByte4)) {
      fail("ciphertext doesn't match in CCM");
    }
    localCipher2.init(2, localSecretKeySpec, new IvParameterSpec(arrayOfByte2));
    byte[] arrayOfByte6 = localCipher2.doFinal(arrayOfByte4);
    if (!areEqual(arrayOfByte6, arrayOfByte3)) {
      fail("plaintext doesn't match in CCM");
    }
    try
    {
      localCipher1 = Cipher.getInstance("AES/CCM/PKCS5Padding", "BC");
      fail("bad padding missed in CCM");
    }
    catch (NoSuchPaddingException localNoSuchPaddingException) {}
  }
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != cipherTests.length; i += 4) {
      test(Integer.parseInt(cipherTests[i]), Hex.decode(cipherTests[(i + 1)]), Hex.decode(cipherTests[(i + 2)]), Hex.decode(cipherTests[(i + 3)]));
    }
    byte[] arrayOfByte1 = Hex.decode("000102030405060708090a0b0c0d0e0f");
    byte[] arrayOfByte2 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte3 = Hex.decode("1fa68b0a8112b447aef34bd8fb5a7b829d3e862371d2cfe5");
    wrapTest(1, "AESWrap", arrayOfByte1, arrayOfByte2, arrayOfByte3);
    String[] arrayOfString1 = { NISTObjectIdentifiers.id_aes128_ECB.getId(), NISTObjectIdentifiers.id_aes128_CBC.getId(), NISTObjectIdentifiers.id_aes128_OFB.getId(), NISTObjectIdentifiers.id_aes128_CFB.getId(), NISTObjectIdentifiers.id_aes192_ECB.getId(), NISTObjectIdentifiers.id_aes192_CBC.getId(), NISTObjectIdentifiers.id_aes192_OFB.getId(), NISTObjectIdentifiers.id_aes192_CFB.getId(), NISTObjectIdentifiers.id_aes256_ECB.getId(), NISTObjectIdentifiers.id_aes256_CBC.getId(), NISTObjectIdentifiers.id_aes256_OFB.getId(), NISTObjectIdentifiers.id_aes256_CFB.getId() };
    String[] arrayOfString2 = { "AES/ECB/PKCS7Padding", "AES/CBC/PKCS7Padding", "AES/OFB/PKCS7Padding", "AES/CFB/PKCS7Padding", "AES/ECB/PKCS7Padding", "AES/CBC/PKCS7Padding", "AES/OFB/PKCS7Padding", "AES/CFB/PKCS7Padding", "AES/ECB/PKCS7Padding", "AES/CBC/PKCS7Padding", "AES/OFB/PKCS7Padding", "AES/CFB/PKCS7Padding" };
    oidTest(arrayOfString1, arrayOfString2, 4);
    String[] arrayOfString3 = { NISTObjectIdentifiers.id_aes128_wrap.getId(), NISTObjectIdentifiers.id_aes192_wrap.getId(), NISTObjectIdentifiers.id_aes256_wrap.getId() };
    wrapOidTest(arrayOfString3, "AESWrap");
    eaxTest();
    ccmTest();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new AESTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\AESTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */