package org.bouncycastle.jce.provider.test;

import java.io.PrintStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.jce.interfaces.GOST3410PrivateKey;
import org.bouncycastle.jce.interfaces.GOST3410PublicKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.bouncycastle.jce.spec.ECPrivateKeySpec;
import org.bouncycastle.jce.spec.ECPublicKeySpec;
import org.bouncycastle.jce.spec.GOST3410ParameterSpec;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.math.ec.ECFieldElement.Fp;
import org.bouncycastle.math.ec.ECPoint.Fp;
import org.bouncycastle.util.BigIntegers;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class GOST3410Test
  implements Test
{
  Test[] tests = { new ECGOST3410Test(null), new GenerationTest(null), new ParametersTest(null) };
  
  private BigInteger[] decode(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte1 = new byte[32];
    byte[] arrayOfByte2 = new byte[32];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte2, 0, 32);
    System.arraycopy(paramArrayOfByte, 32, arrayOfByte1, 0, 32);
    BigInteger[] arrayOfBigInteger = new BigInteger[2];
    arrayOfBigInteger[0] = new BigInteger(1, arrayOfByte1);
    arrayOfBigInteger[1] = new BigInteger(1, arrayOfByte2);
    return arrayOfBigInteger;
  }
  
  public String getName()
  {
    return "GOST3410/ECGOST3410";
  }
  
  public TestResult perform()
  {
    for (int i = 0; i != this.tests.length; i++)
    {
      TestResult localTestResult = this.tests[i].perform();
      if (!localTestResult.isSuccessful()) {
        return localTestResult;
      }
    }
    return new SimpleTestResult(true, "GOST3410/ECGOST3410: Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    GOST3410Test localGOST3410Test = new GOST3410Test();
    TestResult localTestResult = localGOST3410Test.perform();
    System.out.println(localTestResult.toString());
  }
  
  private class ParametersTest
    implements Test
  {
    private ParametersTest() {}
    
    public String getName()
    {
      return "GOST3410 Parameters";
    }
    
    public TestResult perform()
    {
      try
      {
        GOST3410ParameterSpec localGOST3410ParameterSpec = new GOST3410ParameterSpec(CryptoProObjectIdentifiers.gostR3410_94_CryptoPro_B.getId());
        KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("GOST3410", "BC");
        localKeyPairGenerator.initialize(localGOST3410ParameterSpec, new SecureRandom());
        KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
        PrivateKey localPrivateKey = localKeyPair.getPrivate();
        PublicKey localPublicKey = localKeyPair.getPublic();
        Signature localSignature = Signature.getInstance("GOST3410", "BC");
        byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
        localSignature.initSign(localPrivateKey);
        localSignature.update(arrayOfByte1);
        byte[] arrayOfByte2 = localSignature.sign();
        localSignature = Signature.getInstance("GOST3410", "BC");
        localSignature.initVerify(localPublicKey);
        localSignature.update(arrayOfByte1);
        if (!localSignature.verify(arrayOfByte2)) {
          return new SimpleTestResult(false, getName() + ": GOST3410 verification failed");
        }
      }
      catch (Exception localException)
      {
        return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
  }
  
  private class GenerationTest
    implements Test
  {
    private GenerationTest() {}
    
    public String getName()
    {
      return "GOST3410/ECGOST3410 Generation";
    }
    
    public TestResult perform()
    {
      try
      {
        Signature localSignature = Signature.getInstance("GOST3410", "BC");
        KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("GOST3410", "BC");
        byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
        GOST3410ParameterSpec localGOST3410ParameterSpec = new GOST3410ParameterSpec(CryptoProObjectIdentifiers.gostR3410_94_CryptoPro_A.getId());
        localKeyPairGenerator.initialize(localGOST3410ParameterSpec, new SecureRandom());
        KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
        PrivateKey localPrivateKey = localKeyPair.getPrivate();
        PublicKey localPublicKey = localKeyPair.getPublic();
        localSignature.initSign(localPrivateKey);
        localSignature.update(arrayOfByte1);
        byte[] arrayOfByte2 = localSignature.sign();
        localSignature = Signature.getInstance("GOST3410", "BC");
        localSignature.initVerify(localPublicKey);
        localSignature.update(arrayOfByte1);
        if (!localSignature.verify(arrayOfByte2)) {
          return new SimpleTestResult(false, getName() + ": GOST3410 verification failed");
        }
        localSignature = Signature.getInstance("GOST3410", "BC");
        localKeyPairGenerator = KeyPairGenerator.getInstance("GOST3410", "BC");
        localKeyPair = localKeyPairGenerator.generateKeyPair();
        localPrivateKey = localKeyPair.getPrivate();
        localPublicKey = localKeyPair.getPublic();
        localSignature.initSign(localPrivateKey);
        localSignature.update(arrayOfByte1);
        arrayOfByte2 = localSignature.sign();
        localSignature = Signature.getInstance("GOST3410", "BC");
        localSignature.initVerify(localPublicKey);
        localSignature.update(arrayOfByte1);
        if (!localSignature.verify(arrayOfByte2)) {
          return new SimpleTestResult(false, getName() + ": GOST3410 verification failed");
        }
        KeyFactory localKeyFactory = KeyFactory.getInstance("GOST3410", "BC");
        X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(localPublicKey.getEncoded());
        GOST3410PublicKey localGOST3410PublicKey = (GOST3410PublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
        if (!localGOST3410PublicKey.getY().equals(((GOST3410PublicKey)localPublicKey).getY())) {
          return new SimpleTestResult(false, getName() + ": public number not decoded properly");
        }
        PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(localPrivateKey.getEncoded());
        GOST3410PrivateKey localGOST3410PrivateKey = (GOST3410PrivateKey)localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
        if (!localGOST3410PrivateKey.getX().equals(((GOST3410PrivateKey)localPrivateKey).getX())) {
          return new SimpleTestResult(false, getName() + ": private number not decoded properly");
        }
        localSignature = Signature.getInstance("ECGOST3410", "BC");
        localKeyPairGenerator = KeyPairGenerator.getInstance("ECGOST3410", "BC");
        BigInteger localBigInteger = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564821041");
        ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("7"), new BigInteger("43308876546767276905765904595650931995942111794451039583252968842033849580414"));
        ECParameterSpec localECParameterSpec = new ECParameterSpec(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("2")), new ECFieldElement.Fp(localBigInteger, new BigInteger("4018974056539037503335449422937059775635739389905545080690979365213431566280"))), new BigInteger("57896044618658097711785492504343953927082934583725450622380973592137631069619"));
        localKeyPairGenerator.initialize(localECParameterSpec, new SecureRandom());
        localKeyPair = localKeyPairGenerator.generateKeyPair();
        localPrivateKey = localKeyPair.getPrivate();
        localPublicKey = localKeyPair.getPublic();
        localSignature.initSign(localPrivateKey);
        localSignature.update(arrayOfByte1);
        arrayOfByte2 = localSignature.sign();
        localSignature = Signature.getInstance("ECGOST3410", "BC");
        localSignature.initVerify(localPublicKey);
        localSignature.update(arrayOfByte1);
        if (!localSignature.verify(arrayOfByte2)) {
          return new SimpleTestResult(false, getName() + ": ECGOST3410 verification failed");
        }
      }
      catch (Exception localException)
      {
        return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
  }
  
  private class ECGOST3410Test
    implements Test
  {
    BigInteger r = new BigInteger("29700980915817952874371204983938256990422752107994319651632687982059210933395");
    BigInteger s = new BigInteger("46959264877825372965922731380059061821746083849389763294914877353246631700866");
    byte[] kData = BigIntegers.asUnsignedByteArray(new BigInteger("53854137677348463731403841147996619241504003434302020712960838528893196233395"));
    SecureRandom k = new FixedSecureRandom(this.kData);
    
    private ECGOST3410Test() {}
    
    public String getName()
    {
      return "ECGOST3410 Test";
    }
    
    public TestResult perform()
    {
      try
      {
        BigInteger localBigInteger = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564821041");
        ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("7"), new BigInteger("43308876546767276905765904595650931995942111794451039583252968842033849580414"));
        ECParameterSpec localECParameterSpec = new ECParameterSpec(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("2")), new ECFieldElement.Fp(localBigInteger, new BigInteger("4018974056539037503335449422937059775635739389905545080690979365213431566280"))), new BigInteger("57896044618658097711785492504343953927082934583725450622380973592137631069619"));
        ECPrivateKeySpec localECPrivateKeySpec = new ECPrivateKeySpec(new BigInteger("55441196065363246126355624130324183196576709222340016572108097750006097525544"), localECParameterSpec);
        ECPublicKeySpec localECPublicKeySpec = new ECPublicKeySpec(new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("57520216126176808443631405023338071176630104906313632182896741342206604859403")), new ECFieldElement.Fp(localBigInteger, new BigInteger("17614944419213781543809391949654080031942662045363639260709847859438286763994"))), localECParameterSpec);
        Signature localSignature = Signature.getInstance("ECGOST3410", "BC");
        KeyFactory localKeyFactory = KeyFactory.getInstance("ECGOST3410", "BC");
        PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localECPrivateKeySpec);
        PublicKey localPublicKey = localKeyFactory.generatePublic(localECPublicKeySpec);
        localSignature.initSign(localPrivateKey, this.k);
        byte[] arrayOfByte1 = { 97, 98, 99 };
        localSignature.update(arrayOfByte1);
        byte[] arrayOfByte2 = localSignature.sign();
        localSignature.initVerify(localPublicKey);
        localSignature.update(arrayOfByte1);
        if (!localSignature.verify(arrayOfByte2)) {
          return new SimpleTestResult(false, getName() + ": ECGOST3410 verification failed");
        }
        BigInteger[] arrayOfBigInteger = GOST3410Test.this.decode(arrayOfByte2);
        if (!this.r.equals(arrayOfBigInteger[0])) {
          return new SimpleTestResult(false, getName() + ": r component wrong." + System.getProperty("line.separator") + " expecting: " + this.r + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[0]);
        }
        if (!this.s.equals(arrayOfBigInteger[1])) {
          return new SimpleTestResult(false, getName() + ": s component wrong." + System.getProperty("line.separator") + " expecting: " + this.s + System.getProperty("line.separator") + " got      : " + arrayOfBigInteger[1]);
        }
      }
      catch (Exception localException)
      {
        return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\GOST3410Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */