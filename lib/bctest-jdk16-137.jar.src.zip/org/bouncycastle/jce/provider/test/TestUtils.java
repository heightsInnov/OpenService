package org.bouncycastle.jce.provider.test;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Set;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.CRLNumber;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.x509.X509V1CertificateGenerator;
import org.bouncycastle.x509.X509V2CRLGenerator;
import org.bouncycastle.x509.X509V3CertificateGenerator;
import org.bouncycastle.x509.extension.AuthorityKeyIdentifierStructure;
import org.bouncycastle.x509.extension.SubjectKeyIdentifierStructure;

class TestUtils
{
  public static KeyPair generateRSAKeyPair()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024, new SecureRandom());
    return localKeyPairGenerator.generateKeyPair();
  }
  
  public static X509Certificate generateRootCert(KeyPair paramKeyPair)
    throws Exception
  {
    X509V1CertificateGenerator localX509V1CertificateGenerator = new X509V1CertificateGenerator();
    localX509V1CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
    localX509V1CertificateGenerator.setIssuerDN(new X509Principal("CN=Test CA Certificate"));
    localX509V1CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis() - 50000L));
    localX509V1CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 50000L));
    localX509V1CertificateGenerator.setSubjectDN(new X509Principal("CN=Test CA Certificate"));
    localX509V1CertificateGenerator.setPublicKey(paramKeyPair.getPublic());
    localX509V1CertificateGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
    return localX509V1CertificateGenerator.generateX509Certificate(paramKeyPair.getPrivate(), "BC");
  }
  
  public static X509Certificate generateIntermediateCert(PublicKey paramPublicKey, PrivateKey paramPrivateKey, X509Certificate paramX509Certificate)
    throws Exception
  {
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
    localX509V3CertificateGenerator.setIssuerDN(PrincipalUtil.getSubjectX509Principal(paramX509Certificate));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis() - 50000L));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 50000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Principal("CN=Test Intermediate Certificate"));
    localX509V3CertificateGenerator.setPublicKey(paramPublicKey);
    localX509V3CertificateGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
    localX509V3CertificateGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(paramX509Certificate));
    localX509V3CertificateGenerator.addExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(paramPublicKey));
    localX509V3CertificateGenerator.addExtension(X509Extensions.BasicConstraints, true, new BasicConstraints(0));
    localX509V3CertificateGenerator.addExtension(X509Extensions.KeyUsage, true, new KeyUsage(134));
    return localX509V3CertificateGenerator.generateX509Certificate(paramPrivateKey, "BC");
  }
  
  public static X509Certificate generateEndEntityCert(PublicKey paramPublicKey, PrivateKey paramPrivateKey, X509Certificate paramX509Certificate)
    throws Exception
  {
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
    localX509V3CertificateGenerator.setIssuerDN(PrincipalUtil.getSubjectX509Principal(paramX509Certificate));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis() - 50000L));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 50000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Principal("CN=Test End Certificate"));
    localX509V3CertificateGenerator.setPublicKey(paramPublicKey);
    localX509V3CertificateGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
    localX509V3CertificateGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(paramX509Certificate));
    localX509V3CertificateGenerator.addExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(paramPublicKey));
    localX509V3CertificateGenerator.addExtension(X509Extensions.BasicConstraints, true, new BasicConstraints(false));
    localX509V3CertificateGenerator.addExtension(X509Extensions.KeyUsage, true, new KeyUsage(160));
    return localX509V3CertificateGenerator.generateX509Certificate(paramPrivateKey, "BC");
  }
  
  public static X509CRL createCRL(X509Certificate paramX509Certificate, PrivateKey paramPrivateKey, BigInteger paramBigInteger)
    throws Exception
  {
    X509V2CRLGenerator localX509V2CRLGenerator = new X509V2CRLGenerator();
    Date localDate = new Date();
    BigInteger localBigInteger = BigInteger.valueOf(2L);
    localX509V2CRLGenerator.setIssuerDN(PrincipalUtil.getSubjectX509Principal(paramX509Certificate));
    localX509V2CRLGenerator.setThisUpdate(localDate);
    localX509V2CRLGenerator.setNextUpdate(new Date(localDate.getTime() + 100000L));
    localX509V2CRLGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
    localX509V2CRLGenerator.addCRLEntry(paramBigInteger, localDate, 9);
    localX509V2CRLGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(paramX509Certificate));
    localX509V2CRLGenerator.addExtension(X509Extensions.CRLNumber, false, new CRLNumber(BigInteger.valueOf(1L)));
    return localX509V2CRLGenerator.generateX509CRL(paramPrivateKey, "BC");
  }
  
  public static X509Certificate createExceptionCertificate(boolean paramBoolean)
  {
    return new ExceptionCertificate(paramBoolean);
  }
  
  private static class ExceptionCertificate
    extends X509Certificate
  {
    private boolean _exceptionOnEncode;
    
    public ExceptionCertificate(boolean paramBoolean)
    {
      this._exceptionOnEncode = paramBoolean;
    }
    
    public void checkValidity()
      throws CertificateExpiredException, CertificateNotYetValidException
    {
      throw new CertificateNotYetValidException();
    }
    
    public void checkValidity(Date paramDate)
      throws CertificateExpiredException, CertificateNotYetValidException
    {
      throw new CertificateExpiredException();
    }
    
    public int getVersion()
    {
      return 0;
    }
    
    public BigInteger getSerialNumber()
    {
      return null;
    }
    
    public Principal getIssuerDN()
    {
      return null;
    }
    
    public Principal getSubjectDN()
    {
      return null;
    }
    
    public Date getNotBefore()
    {
      return null;
    }
    
    public Date getNotAfter()
    {
      return null;
    }
    
    public byte[] getTBSCertificate()
      throws CertificateEncodingException
    {
      throw new CertificateEncodingException();
    }
    
    public byte[] getSignature()
    {
      return new byte[0];
    }
    
    public String getSigAlgName()
    {
      return null;
    }
    
    public String getSigAlgOID()
    {
      return null;
    }
    
    public byte[] getSigAlgParams()
    {
      return new byte[0];
    }
    
    public boolean[] getIssuerUniqueID()
    {
      return new boolean[0];
    }
    
    public boolean[] getSubjectUniqueID()
    {
      return new boolean[0];
    }
    
    public boolean[] getKeyUsage()
    {
      return new boolean[0];
    }
    
    public int getBasicConstraints()
    {
      return 0;
    }
    
    public byte[] getEncoded()
      throws CertificateEncodingException
    {
      if (this._exceptionOnEncode) {
        throw new CertificateEncodingException();
      }
      return new byte[0];
    }
    
    public void verify(PublicKey paramPublicKey)
      throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException
    {
      throw new CertificateException();
    }
    
    public void verify(PublicKey paramPublicKey, String paramString)
      throws CertificateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException
    {
      throw new CertificateException();
    }
    
    public String toString()
    {
      return null;
    }
    
    public PublicKey getPublicKey()
    {
      return null;
    }
    
    public boolean hasUnsupportedCriticalExtension()
    {
      return false;
    }
    
    public Set getCriticalExtensionOIDs()
    {
      return null;
    }
    
    public Set getNonCriticalExtensionOIDs()
    {
      return null;
    }
    
    public byte[] getExtensionValue(String paramString)
    {
      return new byte[0];
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\TestUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */