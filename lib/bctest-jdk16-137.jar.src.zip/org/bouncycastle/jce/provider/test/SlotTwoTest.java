package org.bouncycastle.jce.provider.test;

import java.security.Key;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTest;

public class SlotTwoTest
  extends SimpleTest
{
  byte[] plainData = "abcdefghijklmnopqrstuvwxyz".getBytes();
  
  public String getName()
  {
    return "SlotTwo";
  }
  
  public void performTest()
    throws Exception
  {
    Security.removeProvider("BC");
    Security.insertProviderAt(new BouncyCastleProvider(), 2);
    KeyGenerator localKeyGenerator = KeyGenerator.getInstance("DESede", "BC");
    localKeyGenerator.init(new SecureRandom());
    SecretKey localSecretKey = localKeyGenerator.generateKey();
    testDesEde(localSecretKey, "ECB", "PKCS7Padding");
    testDesEde(localSecretKey, "CBC", "PKCS7Padding");
    testDesEde(localSecretKey, "CTR", "NoPadding");
    testDesEde(localSecretKey, "CTR", "PKCS7Padding");
    testDesEde(localSecretKey, "OFB", "PKCS7Padding");
    testDesEde(localSecretKey, "CFB", "PKCS7Padding");
    Security.removeProvider("BC");
    Security.addProvider(new BouncyCastleProvider());
  }
  
  private void testDesEde(Key paramKey, String paramString1, String paramString2)
    throws Exception
  {
    Cipher localCipher1 = Cipher.getInstance("DESede/" + paramString1 + "/" + paramString2, "BC");
    Cipher localCipher2 = Cipher.getInstance("DESede/" + paramString1 + "/" + paramString2);
    if (!localCipher2.getProvider().getName().equals("BC")) {
      fail("BC provider not returned for DESede/" + paramString1 + "/" + paramString2 + " got " + localCipher2.getProvider().getName());
    }
    localCipher1.init(1, paramKey);
    byte[] arrayOfByte1 = localCipher1.doFinal(this.plainData);
    byte[] arrayOfByte2 = localCipher1.getIV();
    if (arrayOfByte2 != null)
    {
      localObject = new IvParameterSpec(arrayOfByte2);
      localCipher2.init(2, paramKey, (AlgorithmParameterSpec)localObject);
    }
    else
    {
      localCipher2.init(2, paramKey);
    }
    Object localObject = localCipher2.doFinal(arrayOfByte1, 0, arrayOfByte1.length);
    if (!areEqual(this.plainData, (byte[])localObject)) {
      fail("decryption test failed.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new SlotTwoTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\SlotTwoTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */