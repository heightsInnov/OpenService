package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class CamelliaTest
  extends BaseBlockCipherTest
{
  static String[] cipherTests = { "128", "0123456789abcdeffedcba9876543210", "0123456789abcdeffedcba9876543210", "67673138549669730857065648eabe43", "192", "0123456789abcdeffedcba98765432100011223344556677", "0123456789abcdeffedcba9876543210", "b4993401b3e996f84ee5cee7d79b09b9", "256", "0123456789abcdeffedcba987654321000112233445566778899aabbccddeeff", "0123456789abcdeffedcba9876543210", "9acc237dff16d76c20ef7c919e3a7509" };
  
  public CamelliaTest()
  {
    super("Camellia");
  }
  
  public void test(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "Camellia");
    Cipher localCipher1 = Cipher.getInstance("Camellia/ECB/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("Camellia/ECB/NoPadding", "BC");
    try
    {
      localCipher2.init(1, localSecretKeySpec);
    }
    catch (Exception localException1)
    {
      fail("Camellia failed initialisation - " + localException1.toString(), localException1);
    }
    try
    {
      localCipher1.init(2, localSecretKeySpec);
    }
    catch (Exception localException2)
    {
      fail("Camellia failed initialisation - " + localException2.toString(), localException2);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte2[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      fail("Camellia failed encryption - " + localIOException.toString(), localIOException);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
      fail("Camellia failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte2.length];
      for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte2.length / 2, arrayOfByte.length - paramArrayOfByte2.length / 2);
    }
    catch (Exception localException3)
    {
      fail("Camellia failed encryption - " + localException3.toString(), localException3);
    }
    if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
      fail("Camellia failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != cipherTests.length; i += 4) {
      test(Integer.parseInt(cipherTests[i]), Hex.decode(cipherTests[(i + 1)]), Hex.decode(cipherTests[(i + 2)]), Hex.decode(cipherTests[(i + 3)]));
    }
    byte[] arrayOfByte1 = Hex.decode("000102030405060708090a0b0c0d0e0f");
    byte[] arrayOfByte2 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte3 = Hex.decode("635d6ac46eedebd3a7f4a06421a4cbd1746b24795ba2f708");
    wrapTest(1, "CamelliaWrap", arrayOfByte1, arrayOfByte2, arrayOfByte3);
    String[] arrayOfString1 = { NTTObjectIdentifiers.id_camellia128_cbc.getId(), NTTObjectIdentifiers.id_camellia192_cbc.getId(), NTTObjectIdentifiers.id_camellia256_cbc.getId() };
    String[] arrayOfString2 = { "Camellia/CBC/PKCS7Padding", "Camellia/CBC/PKCS7Padding", "Camellia/CBC/PKCS7Padding" };
    oidTest(arrayOfString1, arrayOfString2, 1);
    String[] arrayOfString3 = { NTTObjectIdentifiers.id_camellia128_wrap.getId(), NTTObjectIdentifiers.id_camellia192_wrap.getId(), NTTObjectIdentifiers.id_camellia256_wrap.getId() };
    wrapOidTest(arrayOfString3, "CamelliaWrap");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new CamelliaTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\CamelliaTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */