package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class FIPSDESTest
  implements Test
{
  static String[] fips1Tests = { "DES/ECB/NoPadding", "3fa40e8a984d48156a271787ab8883f9893d51ec4b563b53", "DES/CBC/NoPadding", "e5c7cdde872bf27c43e934008c389c0f683788499a7c05f6", "DES/CFB/NoPadding", "f3096249c7f46e51a69e839b1a92f78403467133898ea622" };
  static String[] fips2Tests = { "DES/CFB8/NoPadding", "f31fda07011462ee187f", "DES/OFB8/NoPadding", "f34a2850c9c64985d684" };
  static byte[] input1 = Hex.decode("4e6f77206973207468652074696d6520666f7220616c6c20");
  static byte[] input2 = Hex.decode("4e6f7720697320746865");
  
  public String getName()
  {
    return "FIPSDESTest";
  }
  
  private boolean equalArray(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public TestResult test(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    IvParameterSpec localIvParameterSpec = new IvParameterSpec(Hex.decode("1234567890abcdef"));
    SecretKeySpec localSecretKeySpec;
    Cipher localCipher1;
    Cipher localCipher2;
    try
    {
      localSecretKeySpec = new SecretKeySpec(Hex.decode("0123456789abcdef"), "DES");
      localCipher1 = Cipher.getInstance(paramString, "BC");
      localCipher2 = Cipher.getInstance(paramString, "BC");
      if (paramString.startsWith("DES/ECB")) {
        localCipher2.init(1, localSecretKeySpec);
      } else {
        localCipher2.init(1, localSecretKeySpec, localIvParameterSpec);
      }
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed initialisation - " + localException1.toString(), localException1);
    }
    try
    {
      if (paramString.startsWith("DES/ECB")) {
        localCipher1.init(2, localSecretKeySpec);
      } else {
        localCipher1.init(2, localSecretKeySpec, localIvParameterSpec);
      }
    }
    catch (Exception localException2)
    {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed initialisation - " + localException2.toString(), localException2);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte1.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte1[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte1, paramArrayOfByte1.length / 2, paramArrayOfByte1.length - paramArrayOfByte1.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed encryption - " + localIOException.toString());
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!equalArray(arrayOfByte, paramArrayOfByte2)) {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed encryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte1.length];
      for (int j = 0; j != paramArrayOfByte1.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte1.length / 2, arrayOfByte.length - paramArrayOfByte1.length / 2);
    }
    catch (Exception localException3)
    {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed encryption - " + localException3.toString());
    }
    if (!equalArray(arrayOfByte, paramArrayOfByte1)) {
      return new SimpleTestResult(false, getName() + ": " + paramString + " failed decryption - expected " + new String(Hex.encode(paramArrayOfByte1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    return new SimpleTestResult(true, getName() + ": " + paramString + " Okay");
  }
  
  public TestResult perform()
  {
    TestResult localTestResult;
    for (int i = 0; i != fips1Tests.length; i += 2)
    {
      localTestResult = test(fips1Tests[i], input1, Hex.decode(fips1Tests[(i + 1)]));
      if (!localTestResult.isSuccessful()) {
        return localTestResult;
      }
    }
    for (i = 0; i != fips2Tests.length; i += 2)
    {
      localTestResult = test(fips2Tests[i], input2, Hex.decode(fips2Tests[(i + 1)]));
      if (!localTestResult.isSuccessful()) {
        return localTestResult;
      }
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
    throws KeyException, InvalidAlgorithmParameterException
  {
    Security.addProvider(new BouncyCastleProvider());
    FIPSDESTest localFIPSDESTest = new FIPSDESTest();
    TestResult localTestResult = localFIPSDESTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\FIPSDESTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */