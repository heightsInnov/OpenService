package org.bouncycastle.jce.provider.test;

import java.io.PrintStream;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class WrapTest
  implements Test
{
  public TestResult perform()
  {
    try
    {
      Cipher localCipher = Cipher.getInstance("DES/ECB/PKCS5Padding", "BC");
      KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
      localKeyPairGenerator.initialize(512, new SecureRandom());
      KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
      PrivateKey localPrivateKey = localKeyPair.getPrivate();
      PublicKey localPublicKey = localKeyPair.getPublic();
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance("DES", "BC");
      SecretKey localSecretKey = localKeyGenerator.generateKey();
      localCipher.init(3, localSecretKey);
      byte[] arrayOfByte = localCipher.wrap(localPrivateKey);
      localCipher.init(4, localSecretKey);
      Key localKey = localCipher.unwrap(arrayOfByte, "RSA", 2);
      if (!MessageDigest.isEqual(localPrivateKey.getEncoded(), localKey.getEncoded())) {
        return new SimpleTestResult(false, "Unwrapped key does not match");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException.toString());
    }
  }
  
  public String getName()
  {
    return "WrapTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    WrapTest localWrapTest = new WrapTest();
    TestResult localTestResult = localWrapTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\WrapTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */