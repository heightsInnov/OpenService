package org.bouncycastle.jce.provider.test.rsa3;

import java.io.InputStreamReader;
import java.security.Security;
import java.security.Signature;
import java.security.cert.X509Certificate;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMReader;

public class RSA3CertTest
  extends TestCase
{
  public void setUp()
  {
    if (Security.getProvider("BC") == null) {
      Security.addProvider(new BouncyCastleProvider());
    }
  }
  
  public void testA()
    throws Exception
  {
    doTest("self-testcase-A.pem");
  }
  
  public void testB()
    throws Exception
  {
    doTest("self-testcase-B.pem");
  }
  
  public void testC()
    throws Exception
  {
    doTest("self-testcase-C.pem");
  }
  
  public void testD()
    throws Exception
  {
    doTest("self-testcase-D.pem");
  }
  
  public void testE()
    throws Exception
  {
    doTest("self-testcase-E.pem");
  }
  
  public void testF()
    throws Exception
  {
    doTest("self-testcase-F.pem");
  }
  
  public void testG()
    throws Exception
  {
    doTest("self-testcase-G.pem");
  }
  
  public void testH()
    throws Exception
  {
    doTest("self-testcase-H.pem");
  }
  
  public void testI()
    throws Exception
  {
    doTest("self-testcase-I.pem");
  }
  
  public void testJ()
    throws Exception
  {
    doTest("self-testcase-J.pem");
  }
  
  public void testL()
    throws Exception
  {
    doTest("self-testcase-L.pem");
  }
  
  private void doTest(String paramString)
    throws Exception
  {
    X509Certificate localX509Certificate = loadCert(paramString);
    byte[] arrayOfByte = localX509Certificate.getTBSCertificate();
    Signature localSignature = Signature.getInstance(localX509Certificate.getSigAlgName(), "BC");
    localSignature.initVerify(localX509Certificate.getPublicKey());
    localSignature.update(arrayOfByte);
    assertFalse(localSignature.verify(localX509Certificate.getSignature()));
  }
  
  private X509Certificate loadCert(String paramString)
    throws Exception
  {
    InputStreamReader localInputStreamReader = new InputStreamReader(getClass().getResourceAsStream(paramString));
    PEMReader localPEMReader = new PEMReader(localInputStreamReader);
    return (X509Certificate)localPEMReader.readObject();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("Bleichenbacher's Forgery Attack Tests");
    localTestSuite.addTestSuite(RSA3CertTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\rsa3\RSA3CertTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */