package org.bouncycastle.jce.provider.test;

import java.math.BigInteger;
import java.security.AlgorithmParameters;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.spec.DHParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.bouncycastle.jce.spec.IEKeySpec;
import org.bouncycastle.jce.spec.IESParameterSpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class IESTest
  extends SimpleTest
{
  private BigInteger g512 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
  private BigInteger p512 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
  
  public String getName()
  {
    return "IES";
  }
  
  public void performTest()
    throws Exception
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECIES", "BC");
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    localKeyPairGenerator.initialize(localECParameterSpec, new SecureRandom());
    Cipher localCipher1 = Cipher.getInstance("ECIES", "BC");
    Cipher localCipher2 = Cipher.getInstance("ECIES", "BC");
    doTest(localKeyPairGenerator, localCipher1, localCipher2);
    localKeyPairGenerator = KeyPairGenerator.getInstance("ECIES", "BC");
    localKeyPairGenerator.initialize(192, new SecureRandom());
    doTest(localKeyPairGenerator, localCipher1, localCipher2);
    localKeyPairGenerator = KeyPairGenerator.getInstance("ECIES", "BC");
    localKeyPairGenerator.initialize(239, new SecureRandom());
    doTest(localKeyPairGenerator, localCipher1, localCipher2);
    localKeyPairGenerator = KeyPairGenerator.getInstance("ECIES", "BC");
    localKeyPairGenerator.initialize(256, new SecureRandom());
    doTest(localKeyPairGenerator, localCipher1, localCipher2);
    doDefTest(localKeyPairGenerator, localCipher1, localCipher2);
    DHParameterSpec localDHParameterSpec = new DHParameterSpec(this.p512, this.g512);
    localCipher1 = Cipher.getInstance("IES", "BC");
    localCipher2 = Cipher.getInstance("IES", "BC");
    localKeyPairGenerator = KeyPairGenerator.getInstance("DH", "BC");
    localKeyPairGenerator.initialize(localDHParameterSpec);
    doTest(localKeyPairGenerator, localCipher1, localCipher2);
    doDefTest(localKeyPairGenerator, localCipher1, localCipher2);
  }
  
  public void doTest(KeyPairGenerator paramKeyPairGenerator, Cipher paramCipher1, Cipher paramCipher2)
    throws Exception
  {
    KeyPair localKeyPair1 = paramKeyPairGenerator.generateKeyPair();
    PublicKey localPublicKey1 = localKeyPair1.getPublic();
    PrivateKey localPrivateKey1 = localKeyPair1.getPrivate();
    KeyPair localKeyPair2 = paramKeyPairGenerator.generateKeyPair();
    PublicKey localPublicKey2 = localKeyPair2.getPublic();
    PrivateKey localPrivateKey2 = localKeyPair2.getPrivate();
    IEKeySpec localIEKeySpec1 = new IEKeySpec(localPrivateKey1, localPublicKey2);
    IEKeySpec localIEKeySpec2 = new IEKeySpec(localPrivateKey2, localPublicKey1);
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
    byte[] arrayOfByte2 = { 8, 7, 6, 5, 4, 3, 2, 1 };
    IESParameterSpec localIESParameterSpec = new IESParameterSpec(arrayOfByte1, arrayOfByte2, 128);
    paramCipher1.init(1, localIEKeySpec1, localIESParameterSpec);
    paramCipher2.init(2, localIEKeySpec2, localIESParameterSpec);
    byte[] arrayOfByte3 = Hex.decode("1234567890abcdef");
    byte[] arrayOfByte4 = paramCipher1.doFinal(arrayOfByte3, 0, arrayOfByte3.length);
    byte[] arrayOfByte5 = paramCipher2.doFinal(arrayOfByte4, 0, arrayOfByte4.length);
    if (!areEqual(arrayOfByte5, arrayOfByte3)) {
      fail("stream cipher test failed");
    }
  }
  
  public void doDefTest(KeyPairGenerator paramKeyPairGenerator, Cipher paramCipher1, Cipher paramCipher2)
    throws Exception
  {
    KeyPair localKeyPair1 = paramKeyPairGenerator.generateKeyPair();
    PublicKey localPublicKey1 = localKeyPair1.getPublic();
    PrivateKey localPrivateKey1 = localKeyPair1.getPrivate();
    KeyPair localKeyPair2 = paramKeyPairGenerator.generateKeyPair();
    PublicKey localPublicKey2 = localKeyPair2.getPublic();
    PrivateKey localPrivateKey2 = localKeyPair2.getPrivate();
    IEKeySpec localIEKeySpec1 = new IEKeySpec(localPrivateKey1, localPublicKey2);
    IEKeySpec localIEKeySpec2 = new IEKeySpec(localPrivateKey2, localPublicKey1);
    paramCipher1.init(1, localIEKeySpec1);
    AlgorithmParameters localAlgorithmParameters = paramCipher1.getParameters();
    paramCipher2.init(2, localIEKeySpec2, localAlgorithmParameters);
    byte[] arrayOfByte1 = Hex.decode("1234567890abcdef");
    byte[] arrayOfByte2 = paramCipher1.doFinal(arrayOfByte1, 0, arrayOfByte1.length);
    byte[] arrayOfByte3 = paramCipher2.doFinal(arrayOfByte2, 0, arrayOfByte2.length);
    if (!areEqual(arrayOfByte3, arrayOfByte1)) {
      fail("stream cipher test failed");
    }
    int i = paramCipher1.doFinal(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte2, 0);
    if (i != arrayOfByte2.length) {
      fail("encryption length wrong");
    }
    int j = paramCipher2.doFinal(arrayOfByte2, 0, arrayOfByte2.length, arrayOfByte3, 0);
    if (j != arrayOfByte3.length) {
      fail("decryption length wrong");
    }
    if (!areEqual(arrayOfByte3, arrayOfByte1)) {
      fail("stream cipher test failed");
    }
    i = paramCipher1.update(arrayOfByte1, 0, 2, arrayOfByte2, 0);
    i += paramCipher1.doFinal(arrayOfByte1, 2, arrayOfByte1.length - 2, arrayOfByte2, i);
    if (i != arrayOfByte2.length) {
      fail("update encryption length wrong");
    }
    j = paramCipher2.update(arrayOfByte2, 0, 2, arrayOfByte3, 0);
    j += paramCipher2.doFinal(arrayOfByte2, 2, arrayOfByte2.length - 2, arrayOfByte3, j);
    if (j != arrayOfByte3.length) {
      fail("update decryption length wrong");
    }
    if (!areEqual(arrayOfByte3, arrayOfByte1)) {
      fail("update stream cipher test failed");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new IESTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\IESTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */