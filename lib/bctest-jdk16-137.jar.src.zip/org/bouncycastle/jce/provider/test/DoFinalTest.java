package org.bouncycastle.jce.provider.test;

import java.io.PrintStream;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class DoFinalTest
  implements Test
{
  private boolean equalArray(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (paramInt1 + paramArrayOfByte1.length < paramInt2) {
      return false;
    }
    if (paramArrayOfByte2.length < paramInt2) {
      return false;
    }
    for (int i = 0; i != paramInt2; i++) {
      if (paramArrayOfByte1[(paramInt1 + i)] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public TestResult checkCipher(String paramString)
  {
    String str1 = "ABCDEFGHIJKLMNOPQRSTUVWXY0123456789";
    int i = paramString.indexOf('/');
    String str2;
    if (i > 0) {
      str2 = paramString.substring(0, i);
    } else {
      str2 = paramString;
    }
    try
    {
      KeyGenerator localKeyGenerator = KeyGenerator.getInstance(str2, "BC");
      Cipher localCipher = Cipher.getInstance(paramString, "BC");
      SecretKey localSecretKey = localKeyGenerator.generateKey();
      localCipher.init(1, localSecretKey);
      byte[] arrayOfByte1 = localCipher.doFinal(str1.getBytes());
      byte[] arrayOfByte2 = localCipher.doFinal(str1.getBytes());
      if (arrayOfByte1.length != arrayOfByte2.length) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - expected length " + arrayOfByte1.length + " got " + arrayOfByte2.length);
      }
      if (!equalArray(arrayOfByte1, 0, arrayOfByte2, arrayOfByte1.length)) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - first two arrays not equal");
      }
      byte[] arrayOfByte3 = localCipher.update(str1.getBytes());
      byte[] arrayOfByte4 = localCipher.doFinal();
      if (arrayOfByte3.length + arrayOfByte4.length != arrayOfByte1.length) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - expected length " + arrayOfByte1.length + " got " + (arrayOfByte3.length + arrayOfByte4.length));
      }
      if (!equalArray(arrayOfByte1, 0, arrayOfByte3, arrayOfByte3.length)) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - enc1 array not equal");
      }
      if (!equalArray(arrayOfByte1, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length)) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - enc1 array not equal");
      }
      arrayOfByte3 = localCipher.update(str1.getBytes());
      if (!equalArray(arrayOfByte1, 0, arrayOfByte3, arrayOfByte3.length)) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - 2nd enc1 array not equal");
      }
      int j = localCipher.doFinal(arrayOfByte3, 0);
      if (arrayOfByte3.length + j != arrayOfByte1.length) {
        return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - expected length " + arrayOfByte1.length + " got " + (arrayOfByte3.length + j));
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Failed " + paramString + " - exception " + localException.toString());
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult perform()
  {
    TestResult localTestResult = checkCipher("RC4");
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    localTestResult = checkCipher("DES/CBC/PKCS5Padding");
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return checkCipher("Rijndael");
  }
  
  public String getName()
  {
    return "DoFinalTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    DoFinalTest localDoFinalTest = new DoFinalTest();
    TestResult localTestResult = localDoFinalTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\DoFinalTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */