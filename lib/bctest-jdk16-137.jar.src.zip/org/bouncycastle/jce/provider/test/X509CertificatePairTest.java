package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.security.Security;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.x509.X509CertificatePair;

public class X509CertificatePairTest
  extends SimpleTest
{
  public void performTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    X509CertificatePair localX509CertificatePair1 = new X509CertificatePair(localX509Certificate1, localX509Certificate2);
    X509CertificatePair localX509CertificatePair2 = new X509CertificatePair(localX509Certificate1, localX509Certificate2);
    X509CertificatePair localX509CertificatePair3 = new X509CertificatePair(localX509Certificate2, localX509Certificate3);
    X509CertificatePair localX509CertificatePair4 = new X509CertificatePair(localX509Certificate1, localX509Certificate3);
    X509CertificatePair localX509CertificatePair5 = new X509CertificatePair(localX509Certificate1, null);
    X509CertificatePair localX509CertificatePair6 = new X509CertificatePair(localX509Certificate1, null);
    X509CertificatePair localX509CertificatePair7 = new X509CertificatePair(null, localX509Certificate1);
    X509CertificatePair localX509CertificatePair8 = new X509CertificatePair(null, localX509Certificate1);
    if (!localX509CertificatePair1.equals(localX509CertificatePair2)) {
      fail("pair1 pair2 equality test");
    }
    if (!localX509CertificatePair5.equals(localX509CertificatePair6)) {
      fail("pair1 pair2 equality test");
    }
    if (!localX509CertificatePair7.equals(localX509CertificatePair8)) {
      fail("pair1 pair2 equality test");
    }
    if (localX509CertificatePair1.equals(null)) {
      fail("pair1 null equality test");
    }
    if (localX509CertificatePair1.hashCode() != localX509CertificatePair2.hashCode()) {
      fail("pair1 pair2 hashCode equality test");
    }
    if (localX509CertificatePair1.equals(localX509CertificatePair3)) {
      fail("pair1 pair3 inequality test");
    }
    if (localX509CertificatePair1.equals(localX509CertificatePair4)) {
      fail("pair1 pair4 inequality test");
    }
    if (localX509CertificatePair1.equals(localX509CertificatePair5)) {
      fail("pair1 pair5 inequality test");
    }
    if (localX509CertificatePair1.equals(localX509CertificatePair7)) {
      fail("pair1 pair7 inequality test");
    }
    if (localX509CertificatePair5.equals(localX509CertificatePair1)) {
      fail("pair5 pair1 inequality test");
    }
    if (localX509CertificatePair7.equals(localX509CertificatePair1)) {
      fail("pair7 pair1 inequality test");
    }
    if (localX509CertificatePair1.getForward() != localX509Certificate1) {
      fail("pair1 forward test");
    }
    if (localX509CertificatePair1.getReverse() != localX509Certificate2) {
      fail("pair1 reverse test");
    }
    if (!areEqual(localX509CertificatePair1.getEncoded(), localX509CertificatePair2.getEncoded())) {
      fail("encoding check");
    }
    localX509CertificatePair4 = new X509CertificatePair(localX509Certificate1, TestUtils.createExceptionCertificate(false));
    try
    {
      localX509CertificatePair4.getEncoded();
      fail("no exception on bad getEncoded()");
    }
    catch (CertificateEncodingException localCertificateEncodingException1) {}
    localX509CertificatePair4 = new X509CertificatePair(localX509Certificate1, TestUtils.createExceptionCertificate(true));
    try
    {
      localX509CertificatePair4.getEncoded();
      fail("no exception on exception getEncoded()");
    }
    catch (CertificateEncodingException localCertificateEncodingException2) {}
  }
  
  public String getName()
  {
    return "X509CertificatePair";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new X509CertificatePairTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\X509CertificatePairTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */