package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertPathBuilder;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXCertPathBuilderResult;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CRL;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class CertPathBuilderTest
  implements Test
{
  public TestResult baseTest()
  {
    try
    {
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
      X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
      X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
      X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
      X509CRL localX509CRL1 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.rootCrlBin));
      X509CRL localX509CRL2 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.interCrlBin));
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(localX509Certificate1);
      localArrayList.add(localX509Certificate2);
      localArrayList.add(localX509Certificate3);
      localArrayList.add(localX509CRL1);
      localArrayList.add(localX509CRL2);
      CollectionCertStoreParameters localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
      CertStore localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
      Calendar localCalendar = Calendar.getInstance();
      localCalendar.set(2002, 2, 21, 2, 21, 10);
      HashSet localHashSet = new HashSet();
      localHashSet.add(new TrustAnchor(localX509Certificate1, null));
      CertPathBuilder localCertPathBuilder = CertPathBuilder.getInstance("PKIX", "BC");
      X509CertSelector localX509CertSelector = new X509CertSelector();
      localX509CertSelector.setSubject(localX509Certificate3.getSubjectX500Principal().getEncoded());
      PKIXBuilderParameters localPKIXBuilderParameters = new PKIXBuilderParameters(localHashSet, localX509CertSelector);
      localPKIXBuilderParameters.addCertStore(localCertStore);
      localPKIXBuilderParameters.setDate(localCalendar.getTime());
      PKIXCertPathBuilderResult localPKIXCertPathBuilderResult = (PKIXCertPathBuilderResult)localCertPathBuilder.build(localPKIXBuilderParameters);
      CertPath localCertPath = localPKIXCertPathBuilderResult.getCertPath();
      if (localCertPath.getCertificates().size() != 2) {
        return new SimpleTestResult(false, getName() + ": wrong number of certs in baseTest path");
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult v0Test()
  {
    try
    {
      KeyPair localKeyPair1 = TestUtils.generateRSAKeyPair();
      KeyPair localKeyPair2 = TestUtils.generateRSAKeyPair();
      KeyPair localKeyPair3 = TestUtils.generateRSAKeyPair();
      X509Certificate localX509Certificate1 = TestUtils.generateRootCert(localKeyPair1);
      X509Certificate localX509Certificate2 = TestUtils.generateIntermediateCert(localKeyPair2.getPublic(), localKeyPair1.getPrivate(), localX509Certificate1);
      X509Certificate localX509Certificate3 = TestUtils.generateEndEntityCert(localKeyPair3.getPublic(), localKeyPair2.getPrivate(), localX509Certificate2);
      BigInteger localBigInteger = BigInteger.valueOf(2L);
      X509CRL localX509CRL1 = TestUtils.createCRL(localX509Certificate1, localKeyPair1.getPrivate(), localBigInteger);
      X509CRL localX509CRL2 = TestUtils.createCRL(localX509Certificate2, localKeyPair2.getPrivate(), localBigInteger);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(localX509Certificate1);
      localArrayList.add(localX509Certificate2);
      localArrayList.add(localX509Certificate3);
      localArrayList.add(localX509CRL1);
      localArrayList.add(localX509CRL2);
      CollectionCertStoreParameters localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
      CertStore localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters);
      CertPathBuilder localCertPathBuilder = CertPathBuilder.getInstance("PKIX", "BC");
      X509CertSelector localX509CertSelector = new X509CertSelector();
      localX509CertSelector.setSubject(localX509Certificate3.getSubjectX500Principal().getEncoded());
      PKIXBuilderParameters localPKIXBuilderParameters = new PKIXBuilderParameters(Collections.singleton(new TrustAnchor(localX509Certificate1, null)), localX509CertSelector);
      localPKIXBuilderParameters.addCertStore(localCertStore);
      localPKIXBuilderParameters.setDate(new Date());
      PKIXCertPathBuilderResult localPKIXCertPathBuilderResult = (PKIXCertPathBuilderResult)localCertPathBuilder.build(localPKIXBuilderParameters);
      CertPath localCertPath = localPKIXCertPathBuilderResult.getCertPath();
      if (localCertPath.getCertificates().size() != 2) {
        return new SimpleTestResult(false, getName() + ": wrong number of certs in v0Test path");
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException.toString(), localException);
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult perform()
  {
    TestResult localTestResult = baseTest();
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return v0Test();
  }
  
  public String getName()
  {
    return "CertPathBuilder";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    CertPathBuilderTest localCertPathBuilderTest = new CertPathBuilderTest();
    TestResult localTestResult = localCertPathBuilderTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\CertPathBuilderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */