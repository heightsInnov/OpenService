package org.bouncycastle.jce.provider.test;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import javax.crypto.Cipher;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class SigTest
  extends SimpleTest
{
  private void testBadSig(PrivateKey paramPrivateKey, PublicKey paramPublicKey)
    throws Exception
  {
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "BC");
    localCipher.init(1, paramPrivateKey);
    byte[] arrayOfByte1 = new byte[localCipher.getBlockSize()];
    localMessageDigest.update((byte)0);
    byte[] arrayOfByte2 = Hex.decode("3021300906052b0e03021a05000414");
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
    byte[] arrayOfByte3 = localMessageDigest.digest();
    System.arraycopy(arrayOfByte3, 0, arrayOfByte1, arrayOfByte2.length, arrayOfByte3.length);
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, arrayOfByte2.length + arrayOfByte3.length, arrayOfByte2.length);
    byte[] arrayOfByte4 = localCipher.doFinal(arrayOfByte1);
    Signature localSignature = Signature.getInstance("SHA1WithRSA", "BC");
    localSignature.initVerify(paramPublicKey);
    localSignature.update((byte)0);
    if (localSignature.verify(arrayOfByte4)) {
      fail("bad signature passed");
    }
  }
  
  public void performTest()
    throws Exception
  {
    Signature localSignature = Signature.getInstance("SHA1WithRSAEncryption", "BC");
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(768, new SecureRandom());
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PrivateKey localPrivateKey1 = localKeyPair.getPrivate();
    PublicKey localPublicKey1 = localKeyPair.getPublic();
    testBadSig(localPrivateKey1, localPublicKey1);
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA1 verification failed");
    }
    localSignature = Signature.getInstance("MD2WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("MD2 verification failed");
    }
    localSignature = Signature.getInstance("MD5WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("MD5 verification failed");
    }
    localSignature = Signature.getInstance("RIPEMD160WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("RIPEMD160 verification failed");
    }
    localSignature = Signature.getInstance("RIPEMD128WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("RIPEMD128 verification failed");
    }
    localSignature = Signature.getInstance("RIPEMD256WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("RIPEMD256 verification failed");
    }
    localSignature = Signature.getInstance("SHA224WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA224 verification failed");
    }
    localSignature = Signature.getInstance("SHA256WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA256 verification failed");
    }
    localSignature = Signature.getInstance("SHA384WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA384 verification failed");
    }
    localSignature = Signature.getInstance("SHA512WithRSAEncryption", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA512 verification failed");
    }
    localSignature = Signature.getInstance("MD5WithRSA/ISO9796-2", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("MD5/ISO verification failed");
    }
    localSignature = Signature.getInstance("SHA1WithRSA/ISO9796-2", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("SHA1/ISO verification failed");
    }
    localSignature = Signature.getInstance("RIPEMD160WithRSA/ISO9796-2", "BC");
    localSignature.initSign(localPrivateKey1);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey1);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("RIPEMD160/ISO verification failed");
    }
    BigInteger localBigInteger1 = new BigInteger("ffffffff78f6c55506c59785e871211ee120b0b5dd644aa796d82413a47b24573f1be5745b5cd9950f6b389b52350d4e01e90009669a8720bf265a2865994190a661dea3c7828e2e7ca1b19651adc2d5", 16);
    BigInteger localBigInteger2 = new BigInteger("03", 16);
    BigInteger localBigInteger3 = new BigInteger("2aaaaaaa942920e38120ee965168302fd0301d73a4e60c7143ceb0adf0bf30b9352f50e8b9e4ceedd65343b2179005b2f099915e4b0c37e41314bb0821ad8330d23cba7f589e0f129b04c46b67dfce9d", 16);
    KeyFactory localKeyFactory = KeyFactory.getInstance("RSA", "BC");
    PrivateKey localPrivateKey2 = localKeyFactory.generatePrivate(new RSAPrivateKeySpec(localBigInteger1, localBigInteger3));
    PublicKey localPublicKey2 = localKeyFactory.generatePublic(new RSAPublicKeySpec(localBigInteger1, localBigInteger2));
    byte[] arrayOfByte3 = Hex.decode("5cf9a01854dbacaec83aae8efc563d74538192e95466babacd361d7c86000fe42dcb4581e48e4feb862d04698da9203b1803b262105104d510b365ee9c660857ba1c001aa57abfd1c8de92e47c275cae");
    arrayOfByte1 = Hex.decode("fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210");
    localSignature = Signature.getInstance("RIPEMD160WithRSA/ISO9796-2", "BC");
    localSignature.initSign(localPrivateKey2);
    localSignature.update(arrayOfByte1);
    arrayOfByte2 = localSignature.sign();
    if (!Arrays.areEqual(arrayOfByte3, arrayOfByte2)) {
      fail("SigTest: failed ISO9796-2 generation Test");
    }
    localSignature.initVerify(localPublicKey2);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("RIPEMD160/ISO verification failed");
    }
  }
  
  public String getName()
  {
    return "SigTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new SigTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\SigTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */