package org.bouncycastle.jce.provider.test;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.crypto.KeyAgreement;
import org.bouncycastle.asn1.nist.NISTNamedCurves;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.teletrust.TeleTrusTNamedCurves;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECNamedCurveSpec;
import org.bouncycastle.util.test.SimpleTest;

public class NamedCurveTest
  extends SimpleTest
{
  private static Hashtable CURVE_NAMES = new Hashtable();
  private static Hashtable CURVE_ALIASES = new Hashtable();
  
  public void testCurve(String paramString)
    throws Exception
  {
    ECGenParameterSpec localECGenParameterSpec = new ECGenParameterSpec(paramString);
    if (localECGenParameterSpec == null) {
      fail("no curve for " + paramString + " found.");
    }
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDH", "BC");
    localKeyPairGenerator.initialize(localECGenParameterSpec, new SecureRandom());
    KeyPair localKeyPair1 = localKeyPairGenerator.generateKeyPair();
    KeyAgreement localKeyAgreement1 = KeyAgreement.getInstance("ECDHC", "BC");
    localKeyAgreement1.init(localKeyPair1.getPrivate());
    KeyPair localKeyPair2 = localKeyPairGenerator.generateKeyPair();
    KeyAgreement localKeyAgreement2 = KeyAgreement.getInstance("ECDHC", "BC");
    localKeyAgreement2.init(localKeyPair2.getPrivate());
    localKeyAgreement1.doPhase(localKeyPair2.getPublic(), true);
    localKeyAgreement2.doPhase(localKeyPair1.getPublic(), true);
    BigInteger localBigInteger1 = new BigInteger(localKeyAgreement1.generateSecret());
    BigInteger localBigInteger2 = new BigInteger(localKeyAgreement2.generateSecret());
    if (!localBigInteger1.equals(localBigInteger2)) {
      fail("2-way test failed");
    }
    byte[] arrayOfByte1 = localKeyPair1.getPublic().getEncoded();
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDH", "BC");
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte1);
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
    if (!localECPublicKey.getW().equals(((ECPublicKey)localKeyPair1.getPublic()).getW())) {
      fail("public key encoding (Q test) failed");
    }
    if (!(localECPublicKey.getParams() instanceof ECNamedCurveSpec)) {
      fail("public key encoding not named curve");
    }
    byte[] arrayOfByte2 = localKeyPair1.getPrivate().getEncoded();
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte2);
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    if (!localECPrivateKey.getS().equals(((ECPrivateKey)localKeyPair1.getPrivate()).getS())) {
      fail("private key encoding (S test) failed");
    }
    if (!(localECPrivateKey.getParams() instanceof ECNamedCurveSpec)) {
      fail("private key encoding not named curve");
    }
    ECNamedCurveSpec localECNamedCurveSpec = (ECNamedCurveSpec)localECPrivateKey.getParams();
    if ((!localECNamedCurveSpec.getName().equals(paramString)) && (!localECNamedCurveSpec.getName().equals(CURVE_NAMES.get(paramString)))) {
      fail("private key encoding wrong named curve. Expected: " + CURVE_NAMES.get(paramString) + " got " + localECNamedCurveSpec.getName());
    }
  }
  
  public void testECDSA(String paramString)
    throws Exception
  {
    ECGenParameterSpec localECGenParameterSpec = new ECGenParameterSpec(paramString);
    if (localECGenParameterSpec == null) {
      fail("no curve for " + paramString + " found.");
    }
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
    localKeyPairGenerator.initialize(localECGenParameterSpec, new SecureRandom());
    Signature localSignature = Signature.getInstance("ECDSA", "BC");
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PrivateKey localPrivateKey = localKeyPair.getPrivate();
    PublicKey localPublicKey = localKeyPair.getPublic();
    localSignature.initSign(localPrivateKey);
    byte[] arrayOfByte1 = { 97, 98, 99 };
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localPublicKey);
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail(paramString + " verification failed");
    }
    byte[] arrayOfByte3 = localPublicKey.getEncoded();
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDH", "BC");
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte3);
    ECPublicKey localECPublicKey = (ECPublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
    if (!localECPublicKey.getW().equals(((ECPublicKey)localPublicKey).getW())) {
      fail("public key encoding (Q test) failed");
    }
    if (!(localECPublicKey.getParams() instanceof ECNamedCurveSpec)) {
      fail("public key encoding not named curve");
    }
    byte[] arrayOfByte4 = localPrivateKey.getEncoded();
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte4);
    ECPrivateKey localECPrivateKey = (ECPrivateKey)localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    if (!localECPrivateKey.getS().equals(((ECPrivateKey)localPrivateKey).getS())) {
      fail("private key encoding (S test) failed");
    }
    if (!(localECPrivateKey.getParams() instanceof ECNamedCurveSpec)) {
      fail("private key encoding not named curve");
    }
    ECNamedCurveSpec localECNamedCurveSpec = (ECNamedCurveSpec)localECPrivateKey.getParams();
    if ((!localECNamedCurveSpec.getName().equalsIgnoreCase(paramString)) && (!localECNamedCurveSpec.getName().equalsIgnoreCase((String)CURVE_ALIASES.get(paramString)))) {
      fail("private key encoding wrong named curve. Expected: " + paramString + " got " + localECNamedCurveSpec.getName());
    }
  }
  
  public String getName()
  {
    return "NamedCurve";
  }
  
  public void performTest()
    throws Exception
  {
    testCurve("prime192v1");
    testCurve("sect571r1");
    testCurve("secp224r1");
    testCurve("B-409");
    testCurve("P-521");
    testCurve("brainpoolp160r1");
    Enumeration localEnumeration = X962NamedCurves.getNames();
    while (localEnumeration.hasMoreElements()) {
      testECDSA((String)localEnumeration.nextElement());
    }
    localEnumeration = SECNamedCurves.getNames();
    while (localEnumeration.hasMoreElements()) {
      testECDSA((String)localEnumeration.nextElement());
    }
    localEnumeration = TeleTrusTNamedCurves.getNames();
    while (localEnumeration.hasMoreElements()) {
      testECDSA((String)localEnumeration.nextElement());
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new NamedCurveTest());
  }
  
  static
  {
    CURVE_NAMES.put("prime192v1", "prime192v1");
    CURVE_NAMES.put("sect571r1", "sect571r1");
    CURVE_NAMES.put("secp224r1", "secp224r1");
    CURVE_NAMES.put("B-409", SECNamedCurves.getName(NISTNamedCurves.getOID("B-409")));
    CURVE_NAMES.put("P-521", SECNamedCurves.getName(NISTNamedCurves.getOID("P-521")));
    CURVE_NAMES.put("brainpoolp160r1", "brainpoolp160r1");
    CURVE_ALIASES.put("secp192r1", "prime192v1");
    CURVE_ALIASES.put("secp256r1", "prime256v1");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\NamedCurveTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */