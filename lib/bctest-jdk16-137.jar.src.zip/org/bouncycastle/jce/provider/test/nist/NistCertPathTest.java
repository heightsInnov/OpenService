package org.bouncycastle.jce.provider.test.nist;

import java.io.FileInputStream;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertPathValidator;
import java.security.cert.CertPathValidatorException;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.PKIXCertPathValidatorResult;
import java.security.cert.PKIXParameters;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.x509.extension.X509ExtensionUtil;

public class NistCertPathTest
  extends TestCase
{
  private static final String TEST_DATA_HOME = "bc.test.data.home";
  private static final String GOOD_CA_CERT = "GoodCACert";
  private static final String GOOD_CA_CRL = "GoodCACRL";
  private static final String TRUST_ANCHOR_ROOT_CRL = "TrustAnchorRootCRL";
  private static final String TRUST_ANCHOR_ROOT_CERTIFICATE = "TrustAnchorRootCertificate";
  private static final char[] PKCS12_PASSWORD = "password".toCharArray();
  private static String NIST_TEST_POLICY_1 = "2.16.840.1.101.3.2.1.48.1";
  private static String NIST_TEST_POLICY_2 = "2.16.840.1.101.3.2.1.48.2";
  private static String NIST_TEST_POLICY_3 = "2.16.840.1.101.3.2.1.48.3";
  private static Map certs = new HashMap();
  private static Map crls = new HashMap();
  private static Set noPolicies = Collections.EMPTY_SET;
  private static Set nistTestPolicy1 = Collections.singleton(NIST_TEST_POLICY_1);
  private static Set nistTestPolicy2 = Collections.singleton(NIST_TEST_POLICY_2);
  private static Set nistTestPolicy3 = Collections.singleton(NIST_TEST_POLICY_3);
  private static Set nistTestPolicy1And2 = new HashSet(Arrays.asList(new String[] { NIST_TEST_POLICY_1, NIST_TEST_POLICY_2 }));
  
  public void setUp()
  {
    if (Security.getProvider("BC") == null) {
      Security.addProvider(new BouncyCastleProvider());
    }
  }
  
  public void testValidSignaturesTest1()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "ValidCertificatePathTest1EE", "GoodCACert" }, new String[] { "GoodCACRL", "TrustAnchorRootCRL" });
  }
  
  public void testInvalidCASignatureTest2()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "ValidCertificatePathTest1EE", "BadSignedCACert" }, new String[] { "BadSignedCACRL", "TrustAnchorRootCRL" }, 1, "TrustAnchor found but certificate validation failed.");
  }
  
  public void testInvalidEESignatureTest3()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "InvalidEESignatureTest3EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" }, 0, "Could not validate certificate signature.");
  }
  
  public void testValidDSASignaturesTest4()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "DSACACert", "ValidDSASignaturesTest4EE" }, new String[] { "TrustAnchorRootCRL", "DSACACRL" });
  }
  
  public void testValidDSAParameterInheritanceTest5()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "DSACACert", "DSAParametersInheritedCACert", "ValidDSAParameterInheritanceTest5EE" }, new String[] { "TrustAnchorRootCRL", "DSACACRL", "DSAParametersInheritedCACRL" });
  }
  
  public void testInvalidDSASignaturesTest6()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "DSACACert", "InvalidDSASignatureTest6EE" }, new String[] { "TrustAnchorRootCRL", "DSACACRL" }, 0, "Could not validate certificate signature.");
  }
  
  public void testCANotBeforeDateTest1()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "BadnotBeforeDateCACert", "InvalidCAnotBeforeDateTest1EE" }, new String[] { "TrustAnchorRootCRL", "BadnotBeforeDateCACRL" }, 1, "Could not validate certificate: certificate not valid till 20470101120100GMT+00:00");
  }
  
  public void testInvalidEENotBeforeDateTest2()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "InvalidEEnotBeforeDateTest2EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" }, 0, "Could not validate certificate: certificate not valid till 20470101120100GMT+00:00");
  }
  
  public void testValidPre2000UTCNotBeforeDateTest3()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "Validpre2000UTCnotBeforeDateTest3EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" });
  }
  
  public void testValidGeneralizedTimeNotBeforeDateTest4()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "ValidGeneralizedTimenotBeforeDateTest4EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" });
  }
  
  public void testInvalidCANotAfterDateTest5()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "BadnotAfterDateCACert", "InvalidCAnotAfterDateTest5EE" }, new String[] { "TrustAnchorRootCRL", "BadnotAfterDateCACRL" }, 1, "Could not validate certificate: certificate expired on 20020101120100GMT+00:00");
  }
  
  public void testInvalidEENotAfterDateTest6()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "InvalidEEnotAfterDateTest6EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" }, 0, "Could not validate certificate: certificate expired on 20020101120100GMT+00:00");
  }
  
  public void testInvalidValidPre2000UTCNotAfterDateTest7()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "Invalidpre2000UTCEEnotAfterDateTest7EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL" }, 0, "Could not validate certificate: certificate expired on 19990101120100GMT+00:00");
  }
  
  public void testInvalidNegativeSerialNumberTest15()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "NegativeSerialNumberCACert", "InvalidNegativeSerialNumberTest15EE" }, new String[] { "TrustAnchorRootCRL", "NegativeSerialNumberCACRL" }, 0, "Certificate revocation after Fri Apr 20 00:57:20 EST 2001, reason: keyCompromise");
  }
  
  public void testAllCertificatesSamePolicyTest1()
    throws Exception
  {
    String[] arrayOfString1 = { "GoodCACert", "ValidCertificatePathTest1EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "GoodCACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, noPolicies);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1And2);
  }
  
  public void testAllCertificatesNoPoliciesTest2()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "NoPoliciesCACert", "AllCertificatesNoPoliciesTest2EE" }, new String[] { "TrustAnchorRootCRL", "NoPoliciesCACRL" });
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "NoPoliciesCACert", "AllCertificatesNoPoliciesTest2EE" }, new String[] { "TrustAnchorRootCRL", "NoPoliciesCACRL" }, noPolicies, -1, "No valid policy tree found when one expected.");
  }
  
  public void testDifferentPoliciesTest3()
    throws Exception
  {
    doTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "PoliciesP2subCACert", "DifferentPoliciesTest3EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL", "PoliciesP2subCACRL" });
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "PoliciesP2subCACert", "DifferentPoliciesTest3EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL", "PoliciesP2subCACRL" }, noPolicies, -1, "No valid policy tree found when one expected.");
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "PoliciesP2subCACert", "DifferentPoliciesTest3EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL", "PoliciesP2subCACRL" }, nistTestPolicy1And2, -1, "No valid policy tree found when one expected.");
  }
  
  public void testDifferentPoliciesTest4()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "GoodsubCACert", "DifferentPoliciesTest4EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL", "GoodsubCACRL" }, -1, "No valid policy tree found when one expected.");
  }
  
  public void testDifferentPoliciesTest5()
    throws Exception
  {
    doExceptionTest("TrustAnchorRootCertificate", new String[] { "GoodCACert", "PoliciesP2subCA2Cert", "DifferentPoliciesTest5EE" }, new String[] { "TrustAnchorRootCRL", "GoodCACRL", "PoliciesP2subCA2CRL" }, -1, "No valid policy tree found when one expected.");
  }
  
  public void testOverlappingPoliciesTest6()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP1234CACert", "PoliciesP1234subCAP123Cert", "PoliciesP1234subsubCAP123P12Cert", "OverlappingPoliciesTest6EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP1234CACRL", "PoliciesP1234subCAP123CRL", "PoliciesP1234subsubCAP123P12CRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  public void testDifferentPoliciesTest7()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP123CACert", "PoliciesP123subCAP12Cert", "PoliciesP123subsubCAP12P1Cert", "DifferentPoliciesTest7EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP123CACRL", "PoliciesP123subCAP12CRL", "PoliciesP123subsubCAP12P1CRL" };
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, -1, "No valid policy tree found when one expected.");
  }
  
  public void testDifferentPoliciesTest8()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP12CACert", "PoliciesP12subCAP1Cert", "PoliciesP12subsubCAP1P2Cert", "DifferentPoliciesTest8EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP12CACRL", "PoliciesP12subCAP1CRL", "PoliciesP12subsubCAP1P2CRL" };
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, -1, "No valid policy tree found when one expected.");
  }
  
  public void testDifferentPoliciesTest9()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP123CACert", "PoliciesP123subCAP12Cert", "PoliciesP123subsubCAP12P2Cert", "PoliciesP123subsubsubCAP12P2P1Cert", "DifferentPoliciesTest9EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP123CACRL", "PoliciesP123subCAP12CRL", "PoliciesP123subsubCAP2P2CRL", "PoliciesP123subsubsubCAP12P2P1CRL" };
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, -1, "No valid policy tree found when one expected.");
  }
  
  public void testAllCertificatesSamePoliciesTest10()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP12CACert", "AllCertificatesSamePoliciesTest10EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP12CACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2);
  }
  
  public void testAllCertificatesAnyPolicyTest11()
    throws Exception
  {
    String[] arrayOfString1 = { "anyPolicyCACert", "AllCertificatesanyPolicyTest11EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "anyPolicyCACRL" };
    PKIXCertPathValidatorResult localPKIXCertPathValidatorResult = doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    localPKIXCertPathValidatorResult = doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
  }
  
  public void testDifferentPoliciesTest12()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP3CACert", "DifferentPoliciesTest12EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP3CACRL" };
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, -1, "No valid policy tree found when one expected.");
  }
  
  public void testAllCertificatesSamePoliciesTest13()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP123CACert", "AllCertificatesSamePoliciesTest13EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP123CACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy3);
  }
  
  public void testAnyPolicyTest14()
    throws Exception
  {
    String[] arrayOfString1 = { "anyPolicyCACert", "AnyPolicyTest14EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "anyPolicyCACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  public void testUserNoticeQualifierTest15()
    throws Exception
  {
    String[] arrayOfString1 = { "UserNoticeQualifierTest15EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  public void testUserNoticeQualifierTest16()
    throws Exception
  {
    String[] arrayOfString1 = { "GoodCACert", "UserNoticeQualifierTest16EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "GoodCACRL" };
    PKIXCertPathValidatorResult localPKIXCertPathValidatorResult = doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    localPKIXCertPathValidatorResult = doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  public void testUserNoticeQualifierTest17()
    throws Exception
  {
    String[] arrayOfString1 = { "GoodCACert", "UserNoticeQualifierTest17EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "GoodCACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  public void testUserNoticeQualifierTest18()
    throws Exception
  {
    String[] arrayOfString1 = { "PoliciesP12CACert", "UserNoticeQualifierTest18EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL", "PoliciesP12CACRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2);
  }
  
  public void testUserNoticeQualifierTest19()
    throws Exception
  {
    String[] arrayOfString1 = { "UserNoticeQualifierTest19EE" };
    String[] arrayOfString2 = { "TrustAnchorRootCRL" };
    doTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy1);
    doExceptionTest("TrustAnchorRootCertificate", arrayOfString1, arrayOfString2, nistTestPolicy2, -1, "Path processing failed on policy.");
  }
  
  private void doExceptionTest(String paramString1, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt, String paramString2)
    throws Exception
  {
    try
    {
      doTest(paramString1, paramArrayOfString1, paramArrayOfString2);
      fail("path accepted when should be rejected");
    }
    catch (CertPathValidatorException localCertPathValidatorException)
    {
      assertEquals(paramInt, localCertPathValidatorException.getIndex());
      assertEquals(paramString2, localCertPathValidatorException.getMessage());
    }
  }
  
  private void doExceptionTest(String paramString1, String[] paramArrayOfString1, String[] paramArrayOfString2, Set paramSet, int paramInt, String paramString2)
    throws Exception
  {
    try
    {
      doTest(paramString1, paramArrayOfString1, paramArrayOfString2, paramSet);
      fail("path accepted when should be rejected");
    }
    catch (CertPathValidatorException localCertPathValidatorException)
    {
      assertEquals(paramInt, localCertPathValidatorException.getIndex());
      assertEquals(paramString2, localCertPathValidatorException.getMessage());
    }
  }
  
  private PKIXCertPathValidatorResult doTest(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
    throws Exception
  {
    return doTest(paramString, paramArrayOfString1, paramArrayOfString2, null);
  }
  
  private PKIXCertPathValidatorResult doTest(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, Set paramSet)
    throws Exception
  {
    Set localSet = Collections.singleton(getTrustAnchor(paramString));
    ArrayList localArrayList = new ArrayList();
    X509Certificate localX509Certificate = loadCert(paramArrayOfString1[(paramArrayOfString1.length - 1)]);
    for (int i = 0; i != paramArrayOfString1.length - 1; i++) {
      localArrayList.add(loadCert(paramArrayOfString1[i]));
    }
    localArrayList.add(localX509Certificate);
    CertPath localCertPath = CertificateFactory.getInstance("X.509", "BC").generateCertPath(localArrayList);
    for (int j = 0; j != paramArrayOfString2.length; j++) {
      localArrayList.add(loadCrl(paramArrayOfString2[j]));
    }
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CertPathValidator localCertPathValidator = CertPathValidator.getInstance("PKIX", "BC");
    PKIXParameters localPKIXParameters = new PKIXParameters(localSet);
    localPKIXParameters.addCertStore(localCertStore);
    localPKIXParameters.setRevocationEnabled(true);
    if (paramSet != null)
    {
      localPKIXParameters.setExplicitPolicyRequired(true);
      localPKIXParameters.setInitialPolicies(paramSet);
    }
    return (PKIXCertPathValidatorResult)localCertPathValidator.validate(localCertPath, localPKIXParameters);
  }
  
  private X509Certificate loadCert(String paramString)
  {
    X509Certificate localX509Certificate = (X509Certificate)certs.get(paramString);
    if (localX509Certificate != null) {
      return localX509Certificate;
    }
    try
    {
      FileInputStream localFileInputStream = new FileInputStream(getPkitsHome() + "/certs/" + paramString + ".crt");
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
      localX509Certificate = (X509Certificate)localCertificateFactory.generateCertificate(localFileInputStream);
      certs.put(paramString, localX509Certificate);
      return localX509Certificate;
    }
    catch (Exception localException)
    {
      throw new IllegalStateException("exception loading certificate " + paramString + ": " + localException);
    }
  }
  
  private X509CRL loadCrl(String paramString)
    throws Exception
  {
    X509CRL localX509CRL = (X509CRL)certs.get(paramString);
    if (localX509CRL != null) {
      return localX509CRL;
    }
    try
    {
      FileInputStream localFileInputStream = new FileInputStream(getPkitsHome() + "/crls/" + paramString + ".crl");
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
      localX509CRL = (X509CRL)localCertificateFactory.generateCRL(localFileInputStream);
      crls.put(paramString, localX509CRL);
      return localX509CRL;
    }
    catch (Exception localException)
    {
      throw new IllegalStateException("exception loading CRL: " + paramString);
    }
  }
  
  private TrustAnchor getTrustAnchor(String paramString)
    throws Exception
  {
    X509Certificate localX509Certificate = loadCert(paramString);
    byte[] arrayOfByte = localX509Certificate.getExtensionValue(X509Extensions.NameConstraints.getId());
    if (arrayOfByte != null)
    {
      ASN1Encodable localASN1Encodable = X509ExtensionUtil.fromExtensionValue(arrayOfByte);
      return new TrustAnchor(localX509Certificate, localASN1Encodable.getDEREncoded());
    }
    return new TrustAnchor(localX509Certificate, null);
  }
  
  private String getPkitsHome()
  {
    String str = System.getProperty("bc.test.data.home");
    if (str == null) {
      throw new IllegalStateException("bc.test.data.home property not set");
    }
    return str + "/PKITS";
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("NIST CertPath Tests");
    localTestSuite.addTestSuite(NistCertPathTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\nist\NistCertPathTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */