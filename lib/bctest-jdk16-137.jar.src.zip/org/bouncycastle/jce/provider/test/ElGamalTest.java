package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class ElGamalTest
  extends SimpleTest
{
  private BigInteger g512 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
  private BigInteger p512 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
  private BigInteger g768 = new BigInteger("7c240073c1316c621df461b71ebb0cdcc90a6e5527e5e126633d131f87461c4dc4afc60c2cb0f053b6758871489a69613e2a8b4c8acde23954c08c81cbd36132cfd64d69e4ed9f8e51ed6e516297206672d5c0a69135df0a5dcf010d289a9ca1", 16);
  private BigInteger p768 = new BigInteger("8c9dd223debed1b80103b8b309715be009d48860ed5ae9b9d5d8159508efd802e3ad4501a7f7e1cfec78844489148cd72da24b21eddd01aa624291c48393e277cfc529e37075eccef957f3616f962d15b44aeab4039d01b817fde9eaa12fd73f", 16);
  private BigInteger g1024 = new BigInteger("1db17639cdf96bc4eabba19454f0b7e5bd4e14862889a725c96eb61048dcd676ceb303d586e30f060dbafd8a571a39c4d823982117da5cc4e0f89c77388b7a08896362429b94a18a327604eb7ff227bffbc83459ade299e57b5f77b50fb045250934938efa145511166e3197373e1b5b1e52de713eb49792bedde722c6717abf", 16);
  private BigInteger p1024 = new BigInteger("a00e283b3c624e5b2b4d9fbc2653b5185d99499b00fd1bf244c6f0bb817b4d1c451b2958d62a0f8a38caef059fb5ecd25d75ed9af403f5b5bdab97a642902f824e3c13789fed95fa106ddfe0ff4a707c85e2eb77d49e68f2808bcea18ce128b178cd287c6bc00efa9a1ad2a673fe0dceace53166f75b81d6709d5f8af7c66bb7", 16);
  
  public String getName()
  {
    return "ElGamal";
  }
  
  private void testGP(int paramInt1, int paramInt2, BigInteger paramBigInteger1, BigInteger paramBigInteger2)
    throws Exception
  {
    DHParameterSpec localDHParameterSpec1 = new DHParameterSpec(paramBigInteger2, paramBigInteger1, paramInt2);
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ElGamal", "BC");
    byte[] arrayOfByte1 = "This is a test".getBytes();
    localKeyPairGenerator.initialize(localDHParameterSpec1);
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    SecureRandom localSecureRandom = new SecureRandom();
    checkKeySize(paramInt2, localKeyPair);
    Cipher localCipher1 = Cipher.getInstance("ElGamal", "BC");
    localCipher1.init(1, localKeyPair.getPublic(), localSecureRandom);
    if (localCipher1.getOutputSize(arrayOfByte1.length) != paramInt1 / 8 * 2) {
      fail("getOutputSize wrong on encryption");
    }
    byte[] arrayOfByte2 = localCipher1.doFinal(arrayOfByte1);
    localCipher1.init(2, localKeyPair.getPrivate());
    if (localCipher1.getOutputSize(arrayOfByte2.length) != paramInt1 / 8 - 1) {
      fail("getOutputSize wrong on decryption");
    }
    byte[] arrayOfByte3 = ((DHPublicKey)localKeyPair.getPublic()).getParams().getP().toByteArray();
    byte[] arrayOfByte4 = new byte[arrayOfByte3.length - 1];
    int tmp180_179 = 0;
    byte[] tmp180_177 = arrayOfByte4;
    tmp180_177[tmp180_179] = ((byte)(tmp180_177[tmp180_179] | 0x7F));
    localCipher1.init(1, localKeyPair.getPublic(), localSecureRandom);
    arrayOfByte2 = localCipher1.doFinal(arrayOfByte4);
    localCipher1.init(2, localKeyPair.getPrivate());
    arrayOfByte2 = localCipher1.doFinal(arrayOfByte2);
    if (!areEqual(arrayOfByte2, arrayOfByte4)) {
      fail("NoPadding test failed on decrypt expected " + new String(Hex.encode(arrayOfByte4)) + " got " + new String(Hex.encode(arrayOfByte2)));
    }
    Cipher localCipher2 = Cipher.getInstance("ElGamal", "BC");
    Cipher localCipher3 = Cipher.getInstance("ElGamal", "BC");
    localCipher2.init(1, localKeyPair.getPublic(), localSecureRandom);
    byte[] arrayOfByte5 = localCipher2.doFinal(arrayOfByte1);
    localCipher3.init(2, localKeyPair.getPrivate());
    byte[] arrayOfByte6 = localCipher3.doFinal(arrayOfByte5);
    if (!areEqual(arrayOfByte1, arrayOfByte6)) {
      fail(paramInt1 + " encrypt test failed");
    }
    int i = localCipher2.update(arrayOfByte1, 0, 2, arrayOfByte5, 0);
    i += localCipher2.doFinal(arrayOfByte1, 2, arrayOfByte1.length - 2, arrayOfByte5, i);
    i = localCipher3.update(arrayOfByte5, 0, 2, arrayOfByte6, 0);
    i += localCipher3.doFinal(arrayOfByte5, 2, arrayOfByte5.length - 2, arrayOfByte6, i);
    if (!areEqual(arrayOfByte1, arrayOfByte6)) {
      fail(paramInt1 + " encrypt with update test failed");
    }
    byte[] arrayOfByte7 = localKeyPair.getPublic().getEncoded();
    KeyFactory localKeyFactory = KeyFactory.getInstance("ElGamal", "BC");
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte7);
    DHPublicKey localDHPublicKey = (DHPublicKey)localKeyFactory.generatePublic(localX509EncodedKeySpec);
    DHParameterSpec localDHParameterSpec2 = localDHPublicKey.getParams();
    if ((!localDHParameterSpec2.getG().equals(localDHParameterSpec1.getG())) || (!localDHParameterSpec2.getP().equals(localDHParameterSpec1.getP()))) {
      fail(paramInt1 + " bit public key encoding/decoding test failed on parameters");
    }
    if (!((DHPublicKey)localKeyPair.getPublic()).getY().equals(localDHPublicKey.getY())) {
      fail(paramInt1 + " bit public key encoding/decoding test failed on y value");
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
    localObjectOutputStream.writeObject(localKeyPair.getPublic());
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
    ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
    localDHPublicKey = (DHPublicKey)localObjectInputStream.readObject();
    localDHParameterSpec2 = localDHPublicKey.getParams();
    if ((!localDHParameterSpec2.getG().equals(localDHParameterSpec1.getG())) || (!localDHParameterSpec2.getP().equals(localDHParameterSpec1.getP()))) {
      fail(paramInt1 + " bit public key serialisation test failed on parameters");
    }
    if (!((DHPublicKey)localKeyPair.getPublic()).getY().equals(localDHPublicKey.getY())) {
      fail(paramInt1 + " bit public key serialisation test failed on y value");
    }
    byte[] arrayOfByte8 = localKeyPair.getPrivate().getEncoded();
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte8);
    DHPrivateKey localDHPrivateKey = (DHPrivateKey)localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    localDHParameterSpec2 = localDHPrivateKey.getParams();
    if ((!localDHParameterSpec2.getG().equals(localDHParameterSpec1.getG())) || (!localDHParameterSpec2.getP().equals(localDHParameterSpec1.getP()))) {
      fail(paramInt1 + " bit private key encoding/decoding test failed on parameters");
    }
    if (!((DHPrivateKey)localKeyPair.getPrivate()).getX().equals(localDHPrivateKey.getX())) {
      fail(paramInt1 + " bit private key encoding/decoding test failed on y value");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
    localObjectOutputStream.writeObject(localKeyPair.getPrivate());
    localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
    localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
    localDHPrivateKey = (DHPrivateKey)localObjectInputStream.readObject();
    localDHParameterSpec2 = localDHPrivateKey.getParams();
    if ((!localDHParameterSpec2.getG().equals(localDHParameterSpec1.getG())) || (!localDHParameterSpec2.getP().equals(localDHParameterSpec1.getP()))) {
      fail(paramInt1 + " bit private key serialisation test failed on parameters");
    }
    if (!((DHPrivateKey)localKeyPair.getPrivate()).getX().equals(localDHPrivateKey.getX())) {
      fail(paramInt1 + " bit private key serialisation test failed on y value");
    }
  }
  
  private void checkKeySize(int paramInt, KeyPair paramKeyPair)
  {
    if (paramInt != 0)
    {
      DHPrivateKey localDHPrivateKey = (DHPrivateKey)paramKeyPair.getPrivate();
      if (localDHPrivateKey.getX().bitLength() != paramInt) {
        fail("limited key check failed for key size " + paramInt);
      }
    }
  }
  
  private void testRandom(int paramInt)
    throws Exception
  {
    AlgorithmParameterGenerator localAlgorithmParameterGenerator = AlgorithmParameterGenerator.getInstance("ElGamal", "BC");
    localAlgorithmParameterGenerator.init(paramInt, new SecureRandom());
    AlgorithmParameters localAlgorithmParameters1 = localAlgorithmParameterGenerator.generateParameters();
    byte[] arrayOfByte1 = localAlgorithmParameters1.getEncoded();
    AlgorithmParameters localAlgorithmParameters2 = AlgorithmParameters.getInstance("ElGamal", "BC");
    localAlgorithmParameters2.init(arrayOfByte1);
    byte[] arrayOfByte2 = localAlgorithmParameters2.getEncoded();
    if (!areEqual(arrayOfByte1, arrayOfByte2)) {
      fail(getName() + ": encode/decode parameters failed");
    }
    DHParameterSpec localDHParameterSpec = (DHParameterSpec)localAlgorithmParameters1.getParameterSpec(DHParameterSpec.class);
    testGP(paramInt, 0, localDHParameterSpec.getG(), localDHParameterSpec.getP());
  }
  
  public void performTest()
    throws Exception
  {
    testGP(512, 0, this.g512, this.p512);
    testGP(768, 0, this.g768, this.p768);
    testGP(1024, 0, this.g1024, this.p1024);
    testGP(512, 64, this.g512, this.p512);
    testGP(768, 128, this.g768, this.p768);
    testGP(1024, 256, this.g1024, this.p1024);
    testRandom(256);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new ElGamalTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\ElGamalTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */