package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECParameterSpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;
import org.bouncycastle.x509.X509V3CertificateGenerator;

public class KeyStoreTest
  implements Test
{
  static char[] passwd = { 'h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd' };
  
  public TestResult ecStoreTest(String paramString)
  {
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    ECParameterSpec localECParameterSpec = new ECParameterSpec(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    try
    {
      KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
      localKeyPairGenerator.initialize(localECParameterSpec, new SecureRandom());
      KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
      PublicKey localPublicKey = localKeyPair.getPublic();
      PrivateKey localPrivateKey = localKeyPair.getPrivate();
      Hashtable localHashtable = new Hashtable();
      Vector localVector = new Vector();
      localHashtable.put(X509Principal.C, "AU");
      localHashtable.put(X509Principal.O, "The Legion of the Bouncy Castle");
      localHashtable.put(X509Principal.L, "Melbourne");
      localHashtable.put(X509Principal.ST, "Victoria");
      localHashtable.put(X509Principal.E, "feedback-crypto@bouncycastle.org");
      localVector.addElement(X509Principal.C);
      localVector.addElement(X509Principal.O);
      localVector.addElement(X509Principal.L);
      localVector.addElement(X509Principal.ST);
      localVector.addElement(X509Principal.E);
      X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
      localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
      localX509V3CertificateGenerator.setIssuerDN(new X509Principal(localVector, localHashtable));
      localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis() - 50000L));
      localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 50000L));
      localX509V3CertificateGenerator.setSubjectDN(new X509Principal(localVector, localHashtable));
      localX509V3CertificateGenerator.setPublicKey(localPublicKey);
      localX509V3CertificateGenerator.setSignatureAlgorithm("ECDSAwithSHA1");
      Certificate[] arrayOfCertificate = new Certificate[1];
      try
      {
        X509Certificate localX509Certificate = localX509V3CertificateGenerator.generateX509Certificate(localPrivateKey);
        localX509Certificate.checkValidity(new Date());
        localX509Certificate.verify(localPublicKey);
        localObject1 = new ByteArrayInputStream(localX509Certificate.getEncoded());
        localObject2 = CertificateFactory.getInstance("X.509", "BC");
        localX509Certificate = (X509Certificate)((CertificateFactory)localObject2).generateCertificate((InputStream)localObject1);
        arrayOfCertificate[0] = localX509Certificate;
      }
      catch (Exception localException2)
      {
        return new SimpleTestResult(false, getName() + ": error generating cert - " + localException2.toString());
      }
      KeyStore localKeyStore = KeyStore.getInstance(paramString, "BC");
      localKeyStore.load(null, null);
      localKeyStore.setKeyEntry("private", localPrivateKey, passwd, arrayOfCertificate);
      Object localObject1 = new ByteArrayOutputStream();
      localKeyStore.store((OutputStream)localObject1, passwd);
      Object localObject2 = new ByteArrayInputStream(((ByteArrayOutputStream)localObject1).toByteArray());
      localKeyStore = KeyStore.getInstance(paramString, "BC");
      localKeyStore.load((InputStream)localObject2, passwd);
      localPrivateKey = (PrivateKey)localKeyStore.getKey("private", passwd);
      byte[] arrayOfByte1 = localPublicKey.getEncoded();
      KeyFactory localKeyFactory = KeyFactory.getInstance(localPublicKey.getAlgorithm(), "BC");
      X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte1);
      localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
      arrayOfByte1 = localPublicKey.getEncoded();
      localKeyFactory = KeyFactory.getInstance(localPublicKey.getAlgorithm(), "BC");
      localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte1);
      localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
      byte[] arrayOfByte2 = localPrivateKey.getEncoded();
      localKeyFactory = KeyFactory.getInstance(localPrivateKey.getAlgorithm(), "BC");
      PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte2);
      localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
      localKeyFactory = KeyFactory.getInstance(localPrivateKey.getAlgorithm(), "BC");
      localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte2);
      localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": error doing EC test - " + localException1.toString());
    }
  }
  
  public TestResult keyStoreTest(String paramString)
  {
    try
    {
      KeyStore localKeyStore = KeyStore.getInstance(paramString, "BC");
      localKeyStore.load(null, null);
      KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
      localKeyPairGenerator.initialize(1024, new SecureRandom());
      KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
      RSAPrivateKey localRSAPrivateKey = (RSAPrivateKey)localKeyPair.getPrivate();
      RSAPublicKey localRSAPublicKey = (RSAPublicKey)localKeyPair.getPublic();
      BigInteger localBigInteger1 = localRSAPrivateKey.getModulus();
      BigInteger localBigInteger2 = localRSAPrivateKey.getPrivateExponent();
      Hashtable localHashtable = new Hashtable();
      localHashtable.put(X509Principal.C, "AU");
      localHashtable.put(X509Principal.O, "The Legion of the Bouncy Castle");
      localHashtable.put(X509Principal.L, "Melbourne");
      localHashtable.put(X509Principal.ST, "Victoria");
      localHashtable.put(X509Principal.EmailAddress, "feedback-crypto@bouncycastle.org");
      X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
      localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
      localX509V3CertificateGenerator.setIssuerDN(new X509Principal(localHashtable));
      localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis() - 50000L));
      localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 50000L));
      localX509V3CertificateGenerator.setSubjectDN(new X509Principal(localHashtable));
      localX509V3CertificateGenerator.setPublicKey(localRSAPublicKey);
      localX509V3CertificateGenerator.setSignatureAlgorithm("MD5WithRSAEncryption");
      Certificate[] arrayOfCertificate = new Certificate[1];
      try
      {
        X509Certificate localX509Certificate = localX509V3CertificateGenerator.generateX509Certificate(localRSAPrivateKey);
        localX509Certificate.checkValidity(new Date());
        localX509Certificate.verify(localRSAPublicKey);
        localByteArrayInputStream = new ByteArrayInputStream(localX509Certificate.getEncoded());
        localObject = CertificateFactory.getInstance("X.509", "BC");
        localX509Certificate = (X509Certificate)((CertificateFactory)localObject).generateCertificate(localByteArrayInputStream);
        arrayOfCertificate[0] = localX509Certificate;
      }
      catch (Exception localException2)
      {
        return new SimpleTestResult(false, getName() + ": error generating cert - " + localException2.toString());
      }
      localKeyStore.setKeyEntry("private", localRSAPrivateKey, passwd, arrayOfCertificate);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localKeyStore.store(localByteArrayOutputStream, passwd);
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
      localKeyStore = KeyStore.getInstance(paramString, "BC");
      localKeyStore.load(localByteArrayInputStream, passwd);
      localRSAPrivateKey = (RSAPrivateKey)localKeyStore.getKey("private", passwd);
      if (!localRSAPrivateKey.getModulus().equals(localBigInteger1)) {
        return new SimpleTestResult(false, getName() + ": private key modulus wrong");
      }
      if (!localRSAPrivateKey.getPrivateExponent().equals(localBigInteger2)) {
        return new SimpleTestResult(false, getName() + ": private key exponent wrong");
      }
      Object localObject = localKeyStore.getCertificateChain("private")[0];
      ((Certificate)localObject).verify(localRSAPublicKey);
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": exception - " + localException1.toString());
    }
  }
  
  public String getName()
  {
    return "KeyStore";
  }
  
  public TestResult perform()
  {
    TestResult localTestResult = keyStoreTest("BKS");
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    localTestResult = keyStoreTest("UBER");
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    localTestResult = ecStoreTest("BKS");
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    KeyStoreTest localKeyStoreTest = new KeyStoreTest();
    TestResult localTestResult = localKeyStoreTest.perform();
    System.out.println(localTestResult.toString());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\KeyStoreTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */