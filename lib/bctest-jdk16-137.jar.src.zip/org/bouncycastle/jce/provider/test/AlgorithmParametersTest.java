package org.bouncycastle.jce.provider.test;

import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.Security;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.DSAParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class AlgorithmParametersTest
  extends SimpleTest
{
  private byte[] dsaParams = Base64.decode("MIGcAkEAjfKklEkidqo9JXWbsGhpy+rA2Dr7jQz3y7gyTw14guXQdi/FtyEOr8Lprawyq3qsSWk9+/g3JMLsBzbuMcgCkQIVAMdzIYxzfsjumTtPLe0w9I7azpFfAkBP3Z9K7oNeZMXEXYpqvrMUgVdFjq4lnWJoV8Rwe+TERStHTkqSO7sp0lq7EEggVMcuXtarKNsxaJ+qyYv/n1t6");
  
  private void basicTest(String paramString, Class paramClass, byte[] paramArrayOfByte)
    throws Exception
  {
    AlgorithmParameters localAlgorithmParameters = AlgorithmParameters.getInstance(paramString, "BC");
    localAlgorithmParameters.init(paramArrayOfByte);
    try
    {
      localAlgorithmParameters.init(paramArrayOfByte);
      fail("encoded re-initialization not detected");
    }
    catch (IOException localIOException1) {}
    AlgorithmParameterSpec localAlgorithmParameterSpec = localAlgorithmParameters.getParameterSpec(paramClass);
    try
    {
      localAlgorithmParameters.init(localAlgorithmParameterSpec);
      fail("spec re-initialization not detected");
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException1) {}
    try
    {
      localAlgorithmParameterSpec = localAlgorithmParameters.getParameterSpec(AlgorithmParameterSpec.class);
      fail("wrong spec not detected");
    }
    catch (InvalidParameterSpecException localInvalidParameterSpecException2) {}
    try
    {
      localAlgorithmParameterSpec = localAlgorithmParameters.getParameterSpec(null);
      fail("null spec not detected");
    }
    catch (NullPointerException localNullPointerException) {}
    localAlgorithmParameters = AlgorithmParameters.getInstance(paramString, "BC");
    localAlgorithmParameters.init(paramArrayOfByte, "ASN.1");
    localAlgorithmParameters = AlgorithmParameters.getInstance(paramString, "BC");
    localAlgorithmParameters.init(paramArrayOfByte, null);
    localAlgorithmParameters = AlgorithmParameters.getInstance(paramString, "BC");
    try
    {
      localAlgorithmParameters.init(paramArrayOfByte, "FRED");
      fail("unknown spec not detected");
    }
    catch (IOException localIOException2) {}
  }
  
  public void performTest()
    throws Exception
  {
    basicTest("DSA", DSAParameterSpec.class, this.dsaParams);
  }
  
  public String getName()
  {
    return "AlgorithmParameters";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new AlgorithmParametersTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\AlgorithmParametersTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */