package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLSelector;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.security.auth.x500.X500Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTest;

public class CertStoreTest
  extends SimpleTest
{
  public void performTest()
    throws Exception
  {
    basicTest();
    orderTest();
  }
  
  private void basicTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    X509CRL localX509CRL1 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.rootCrlBin));
    X509CRL localX509CRL2 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.interCrlBin));
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate1);
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate3);
    localArrayList.add(localX509CRL1);
    localArrayList.add(localX509CRL2);
    CollectionCertStoreParameters localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
    CertStore localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    X509CertSelector localX509CertSelector = new X509CertSelector();
    localX509CertSelector.setSubject(localX509Certificate1.getSubjectX500Principal().getName());
    Collection localCollection1 = localCertStore.getCertificates(localX509CertSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by subjectDN");
    }
    localX509CertSelector = new X509CertSelector();
    localX509CertSelector.setSubject(localX509Certificate1.getSubjectX500Principal().getEncoded());
    localCollection1 = localCertStore.getCertificates(localX509CertSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by encoded subjectDN");
    }
    localX509CertSelector = new X509CertSelector();
    localX509CertSelector.setSubjectPublicKey(localX509Certificate1.getPublicKey().getEncoded());
    localCollection1 = localCertStore.getCertificates(localX509CertSelector);
    if ((localCollection1.size() != 1) || (!localCollection1.contains(localX509Certificate1))) {
      fail("rootCert not found by encoded public key");
    }
    localX509CertSelector = new X509CertSelector();
    localX509CertSelector.setIssuer(localX509Certificate1.getSubjectX500Principal().getEncoded());
    localCollection1 = localCertStore.getCertificates(localX509CertSelector);
    if (localCollection1.size() != 2) {
      fail("did not found 2 certs");
    }
    if (!localCollection1.contains(localX509Certificate1)) {
      fail("rootCert not found");
    }
    if (!localCollection1.contains(localX509Certificate2)) {
      fail("interCert not found");
    }
    X509CRLSelector localX509CRLSelector = new X509CRLSelector();
    localX509CRLSelector.addIssuerName(localX509CRL1.getIssuerX500Principal().getEncoded());
    Collection localCollection2 = localCertStore.getCRLs(localX509CRLSelector);
    if ((localCollection2.size() != 1) || (!localCollection2.contains(localX509CRL1))) {
      fail("rootCrl not found");
    }
  }
  
  private void orderTest()
    throws Exception
  {
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    X509Certificate localX509Certificate1 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.rootCertBin));
    X509Certificate localX509Certificate2 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.interCertBin));
    X509Certificate localX509Certificate3 = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(CertPathTest.finalCertBin));
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate1);
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate3);
    CollectionCertStoreParameters localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
    CertStore localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    Iterator localIterator1 = localCertStore.getCertificates(null).iterator();
    if (!localIterator1.next().equals(localX509Certificate1)) {
      fail("root ordering wrong");
    }
    if (!localIterator1.next().equals(localX509Certificate2)) {
      fail("mid ordering wrong");
    }
    if (!localIterator1.next().equals(localX509Certificate3)) {
      fail("final ordering wrong");
    }
    localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate3);
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate1);
    localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
    localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    localIterator1 = localCertStore.getCertificates(null).iterator();
    if (!localIterator1.next().equals(localX509Certificate3)) {
      fail("reverse final ordering wrong");
    }
    if (!localIterator1.next().equals(localX509Certificate2)) {
      fail("reverse mid ordering wrong");
    }
    if (!localIterator1.next().equals(localX509Certificate1)) {
      fail("reverse root ordering wrong");
    }
    X509CRL localX509CRL1 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.rootCrlBin));
    X509CRL localX509CRL2 = (X509CRL)localCertificateFactory.generateCRL(new ByteArrayInputStream(CertPathTest.interCrlBin));
    localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate3);
    localArrayList.add(localX509CRL1);
    localArrayList.add(localX509CRL2);
    localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
    localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    Iterator localIterator2 = localCertStore.getCRLs(null).iterator();
    if (!localIterator2.next().equals(localX509CRL1)) {
      fail("root crl ordering wrong");
    }
    if (!localIterator2.next().equals(localX509CRL2)) {
      fail("mid crl ordering wrong");
    }
    localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate3);
    localArrayList.add(localX509CRL2);
    localArrayList.add(localX509CRL1);
    localCollectionCertStoreParameters = new CollectionCertStoreParameters(localArrayList);
    localCertStore = CertStore.getInstance("Collection", localCollectionCertStoreParameters, "BC");
    localIterator2 = localCertStore.getCRLs(null).iterator();
    if (!localIterator2.next().equals(localX509CRL2)) {
      fail("reverse mid crl ordering wrong");
    }
    if (!localIterator2.next().equals(localX509CRL1)) {
      fail("reverse root crl ordering wrong");
    }
  }
  
  public String getName()
  {
    return "CertStore";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new CertStoreTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\CertStoreTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */