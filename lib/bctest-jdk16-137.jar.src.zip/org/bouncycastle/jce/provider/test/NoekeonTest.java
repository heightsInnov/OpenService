package org.bouncycastle.jce.provider.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class NoekeonTest
  extends BaseBlockCipherTest
{
  static String[] cipherTests = { "128", "b1656851699e29fa24b70148503d2dfc", "2a78421b87c7d0924f26113f1d1349b2", "e2f687e07b75660ffc372233bc47532c" };
  
  public NoekeonTest()
  {
    super("Noekeon");
  }
  
  public void test(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws Exception
  {
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte1, "Noekeon");
    Cipher localCipher1 = Cipher.getInstance("Noekeon/ECB/NoPadding", "BC");
    Cipher localCipher2 = Cipher.getInstance("Noekeon/ECB/NoPadding", "BC");
    try
    {
      localCipher2.init(1, localSecretKeySpec);
    }
    catch (Exception localException1)
    {
      fail("Noekeon failed initialisation - " + localException1.toString(), localException1);
    }
    try
    {
      localCipher1.init(2, localSecretKeySpec);
    }
    catch (Exception localException2)
    {
      fail("Noekeoen failed initialisation - " + localException2.toString(), localException2);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    CipherOutputStream localCipherOutputStream = new CipherOutputStream(localByteArrayOutputStream, localCipher2);
    try
    {
      for (int i = 0; i != paramArrayOfByte2.length / 2; i++) {
        localCipherOutputStream.write(paramArrayOfByte2[i]);
      }
      localCipherOutputStream.write(paramArrayOfByte2, paramArrayOfByte2.length / 2, paramArrayOfByte2.length - paramArrayOfByte2.length / 2);
      localCipherOutputStream.close();
    }
    catch (IOException localIOException)
    {
      fail("Noekeon failed encryption - " + localIOException.toString(), localIOException);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (!areEqual(arrayOfByte, paramArrayOfByte3)) {
      fail("Noekeon failed encryption - expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
    CipherInputStream localCipherInputStream = new CipherInputStream(localByteArrayInputStream, localCipher1);
    try
    {
      DataInputStream localDataInputStream = new DataInputStream(localCipherInputStream);
      arrayOfByte = new byte[paramArrayOfByte2.length];
      for (int j = 0; j != paramArrayOfByte2.length / 2; j++) {
        arrayOfByte[j] = ((byte)localDataInputStream.read());
      }
      localDataInputStream.readFully(arrayOfByte, paramArrayOfByte2.length / 2, arrayOfByte.length - paramArrayOfByte2.length / 2);
    }
    catch (Exception localException3)
    {
      fail("Noekeon failed encryption - " + localException3.toString(), localException3);
    }
    if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
      fail("Noekeon failed decryption - expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != cipherTests.length; i += 4) {
      test(Integer.parseInt(cipherTests[i]), Hex.decode(cipherTests[(i + 1)]), Hex.decode(cipherTests[(i + 2)]), Hex.decode(cipherTests[(i + 3)]));
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new NoekeonTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\NoekeonTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */