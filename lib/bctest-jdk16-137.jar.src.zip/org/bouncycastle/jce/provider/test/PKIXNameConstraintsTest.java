package org.bouncycastle.jce.provider.test;

import java.security.cert.CertPathValidatorException;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralSubtree;
import org.bouncycastle.jce.provider.PKIXNameConstraints;
import org.bouncycastle.util.test.SimpleTest;

public class PKIXNameConstraintsTest
  extends SimpleTest
{
  private static final String testEmail = "test@abc.test.com";
  private static final String[] testEmailIsConstraint = { "test@abc.test.com", "abc.test.com", ".test.com" };
  private static final String[] testEmailIsNotConstraint = { ".abc.test.com", "www.test.com", "test1@abc.test.com", "bc.test.com" };
  private static final String[] email1 = { "test@test.com", "test@test.com", "test@test.com", "test@abc.test.com", "test@test.com", "test@test.com", ".test.com", ".test.com", ".test.com", ".test.com", "test.com", "abc.test.com", "abc.test1.com", "test.com", "test.com", ".test.com" };
  private static final String[] email2 = { "test@test.abc.com", "test@test.com", ".test.com", ".test.com", "test.com", "test1.com", "test@test.com", ".test.com", ".test1.com", "test.com", "test.com", ".test.com", ".test.com", "test1.com", ".test.com", "abc.test.com" };
  private static final String[] emailintersect = { null, "test@test.com", null, "test@abc.test.com", "test@test.com", null, null, ".test.com", null, null, "test.com", "abc.test.com", null, null, null, "abc.test.com" };
  private static final String[][] emailunion = { { "test@test.com", "test@test.abc.com" }, { "test@test.com" }, { "test@test.com", ".test.com" }, { ".test.com" }, { "test.com" }, { "test@test.com", "test1.com" }, { ".test.com", "test@test.com" }, { ".test.com" }, { ".test.com", ".test1.com" }, { ".test.com", "test.com" }, { "test.com" }, { ".test.com" }, { ".test.com", "abc.test1.com" }, { "test1.com", "test.com" }, { ".test.com", "test.com" }, { ".test.com" } };
  private static final String[] dn1 = { "O=test org, OU=test org unit, CN=John Doe" };
  private static final String[] dn2 = { "O=test org, OU=test org unit" };
  private static final String[][] dnUnion = { { "O=test org, OU=test org unit" } };
  private static final String[] dnIntersection = { "O=test org, OU=test org unit, CN=John Doe" };
  private static final String testDN = "O=test org, OU=test org unit, CN=John Doe";
  private static final String[] testDNIsConstraint = { "O=test org, OU=test org unit", "O=test org, OU=test org unit, CN=John Doe" };
  private static final String[] testDNIsNotConstraint = { "O=test org, OU=test org unit, CN=John Doe2", "O=test org, OU=test org unit2", "OU=test org unit, O=test org, CN=John Doe", "O=test org, OU=test org unit, CN=John Doe, L=USA" };
  private static final String testDNS = "abc.test.com";
  private static final String[] testDNSIsConstraint = { "test.com", "abc.test.com", "test.com" };
  private static final String[] testDNSIsNotConstraint = { "wwww.test.com", "ww.test.com", "www.test.com" };
  private static final String[] dns1 = { "www.test.de", "www.test1.de", "www.test.de" };
  private static final String[] dns2 = { "test.de", "www.test.de", "www.test.de" };
  private static final String[] dnsintersect = { "www.test.de", null, null };
  private static final String[][] dnsunion = { { "test.de" }, { "www.test1.de", "www.test.de" }, { "www.test.de" } };
  private static final String testURI = "http://karsten:password@abc.test.com:8080";
  private static final String[] testURIIsConstraint = { "abc.test.com", ".test.com" };
  private static final String[] testURIIsNotConstraint = { "xyz.test.com", ".abc.test.com" };
  private static final String[] uri1 = { "www.test.de", ".test.de", "test1.de", ".test.de" };
  private static final String[] uri2 = { "test.de", "www.test.de", "test1.de", ".test.de" };
  private static final String[] uriintersect = { null, "www.test.de", "test1.de", ".test.de" };
  private static final String[][] uriunion = { { "www.test.de", "test.de" }, { ".test.de" }, { "test1.de" }, { ".test.de" } };
  private static final byte[] testIP = { -64, -88, 1, 2 };
  private static final byte[][] testIPIsConstraint = { { -64, -88, 1, 1, -1, -1, -1, 0 }, { -64, -88, 1, 1, -1, -1, -1, 4 } };
  private static final byte[][] testIPIsNotConstraint = { { -64, -88, 3, 1, -1, -1, -1, 2 }, { -64, -88, 1, 1, -1, -1, -1, 3 } };
  private static final byte[][] ip1 = { { -64, -88, 1, 1, -1, -1, -2, -1 }, { -64, -88, 1, 1, -1, -1, -1, -1 }, { -64, -88, 1, 1, -1, -1, -1, 0 } };
  private static final byte[][] ip2 = { { -64, -88, 0, 1, -1, -1, -4, 3 }, { -64, -88, 1, 1, -1, -1, -1, -1 }, { -64, -88, 0, 1, -1, -1, -1, 0 } };
  private static final byte[][] ipintersect = { { -64, -88, 0, 1, -1, -1, -2, -1 }, { -64, -88, 1, 1, -1, -1, -1, -1 }, null };
  private static final byte[][][] ipunion = { { { -64, -88, 1, 1, -1, -1, -2, -1 }, { -64, -88, 0, 1, -1, -1, -4, 3 } }, { { -64, -88, 1, 1, -1, -1, -1, -1 } }, { { -64, -88, 1, 1, -1, -1, -1, 0 }, { -64, -88, 0, 1, -1, -1, -1, 0 } } };
  
  public String getName()
  {
    return "PKIXNameConstraintsTest";
  }
  
  public void performTest()
    throws Exception
  {
    testConstraints(1, "test@abc.test.com", testEmailIsConstraint, testEmailIsNotConstraint, email1, email2, emailunion, emailintersect);
    testConstraints(2, "abc.test.com", testDNSIsConstraint, testDNSIsNotConstraint, dns1, dns2, dnsunion, dnsintersect);
    testConstraints(4, "O=test org, OU=test org unit, CN=John Doe", testDNIsConstraint, testDNIsNotConstraint, dn1, dn2, dnUnion, dnIntersection);
    testConstraints(6, "http://karsten:password@abc.test.com:8080", testURIIsConstraint, testURIIsNotConstraint, uri1, uri2, uriunion, uriintersect);
    testConstraints(7, testIP, testIPIsConstraint, testIPIsNotConstraint, ip1, ip2, ipunion, ipintersect);
  }
  
  private void testConstraints(int paramInt, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, String[] paramArrayOfString4, String[][] paramArrayOfString, String[] paramArrayOfString5)
    throws Exception
  {
    PKIXNameConstraints localPKIXNameConstraints1;
    for (int i = 0; i < paramArrayOfString1.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString1[i])));
      localPKIXNameConstraints1.checkPermitted(new GeneralName(paramInt, paramString));
    }
    for (i = 0; i < paramArrayOfString2.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString2[i])));
      try
      {
        localPKIXNameConstraints1.checkPermitted(new GeneralName(paramInt, paramString));
        fail("not permitted name allowed: " + paramInt);
      }
      catch (CertPathValidatorException localCertPathValidatorException1) {}
    }
    for (i = 0; i < paramArrayOfString1.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString1[i])));
      try
      {
        localPKIXNameConstraints1.checkExcluded(new GeneralName(paramInt, paramString));
        fail("excluded name missed: " + paramInt);
      }
      catch (CertPathValidatorException localCertPathValidatorException2) {}
    }
    for (i = 0; i < paramArrayOfString2.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString2[i])));
      localPKIXNameConstraints1.checkExcluded(new GeneralName(paramInt, paramString));
    }
    for (i = 0; i < paramArrayOfString3.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString3[i])));
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString4[i])));
      PKIXNameConstraints localPKIXNameConstraints2 = new PKIXNameConstraints();
      for (int j = 0; j < paramArrayOfString[i].length; j++) {
        localPKIXNameConstraints2.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString[i][j])));
      }
      if (!localPKIXNameConstraints2.equals(localPKIXNameConstraints1)) {
        fail("union wrong: " + paramInt);
      }
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString3[i])));
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString4[i])));
      localPKIXNameConstraints2 = new PKIXNameConstraints();
      localPKIXNameConstraints2.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, paramArrayOfString5[i])));
      if (!localPKIXNameConstraints2.equals(localPKIXNameConstraints1)) {
        fail("intersection wrong: " + paramInt);
      }
    }
  }
  
  private void testConstraints(int paramInt, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1, byte[][] paramArrayOfByte2, byte[][] paramArrayOfByte3, byte[][] paramArrayOfByte4, byte[][][] paramArrayOfByte5, byte[][] paramArrayOfByte6)
    throws Exception
  {
    PKIXNameConstraints localPKIXNameConstraints1;
    for (int i = 0; i < paramArrayOfByte1.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte1[i]))));
      localPKIXNameConstraints1.checkPermitted(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte)));
    }
    for (i = 0; i < paramArrayOfByte2.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte2[i]))));
      try
      {
        localPKIXNameConstraints1.checkPermitted(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte)));
        fail("not permitted name allowed: " + paramInt);
      }
      catch (CertPathValidatorException localCertPathValidatorException1) {}
    }
    for (i = 0; i < paramArrayOfByte1.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte1[i]))));
      try
      {
        localPKIXNameConstraints1.checkExcluded(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte)));
        fail("excluded name missed: " + paramInt);
      }
      catch (CertPathValidatorException localCertPathValidatorException2) {}
    }
    for (i = 0; i < paramArrayOfByte2.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte2[i]))));
      localPKIXNameConstraints1.checkExcluded(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte)));
    }
    for (i = 0; i < paramArrayOfByte3.length; i++)
    {
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte3[i]))));
      localPKIXNameConstraints1.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte4[i]))));
      PKIXNameConstraints localPKIXNameConstraints2 = new PKIXNameConstraints();
      for (int j = 0; j < paramArrayOfByte5[i].length; j++) {
        localPKIXNameConstraints2.addExcludedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte5[i][j]))));
      }
      if (!localPKIXNameConstraints2.equals(localPKIXNameConstraints1)) {
        fail("union wrong: " + paramInt);
      }
      localPKIXNameConstraints1 = new PKIXNameConstraints();
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte3[i]))));
      localPKIXNameConstraints1.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte4[i]))));
      localPKIXNameConstraints2 = new PKIXNameConstraints();
      localPKIXNameConstraints2.intersectPermittedSubtree(new GeneralSubtree(new GeneralName(paramInt, new DEROctetString(paramArrayOfByte6[i]))));
      if (!localPKIXNameConstraints2.equals(localPKIXNameConstraints1)) {
        fail("intersection wrong: " + paramInt);
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PKIXNameConstraintsTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\jce\provider\test\PKIXNameConstraintsTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */