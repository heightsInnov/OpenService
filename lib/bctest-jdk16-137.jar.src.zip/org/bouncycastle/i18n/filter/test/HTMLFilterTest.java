package org.bouncycastle.i18n.filter.test;

import junit.framework.TestCase;
import org.bouncycastle.i18n.filter.Filter;
import org.bouncycastle.i18n.filter.HTMLFilter;

public class HTMLFilterTest
  extends TestCase
{
  private static final String test1 = "hello world";
  private static final String test2 = "<script></script>";
  private static final String test3 = "javascript:attack()";
  private static final String test4 = "\"hello\"";
  
  public void testDoFilter()
  {
    HTMLFilter localHTMLFilter = new HTMLFilter();
    assertEquals("No filtering", "hello world", localHTMLFilter.doFilter("hello world"));
    assertEquals("script tags", "&#60script&#62&#60/script&#62", localHTMLFilter.doFilter("<script></script>"));
    assertEquals("javascript link", "javascript:attack&#40&#41", localHTMLFilter.doFilter("javascript:attack()"));
    assertEquals("", "&#34hello&#34", localHTMLFilter.doFilter("\"hello\""));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\i18n\filter\test\HTMLFilterTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */