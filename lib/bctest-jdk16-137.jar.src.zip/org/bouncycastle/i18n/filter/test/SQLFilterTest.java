package org.bouncycastle.i18n.filter.test;

import junit.framework.TestCase;
import org.bouncycastle.i18n.filter.Filter;
import org.bouncycastle.i18n.filter.SQLFilter;

public class SQLFilterTest
  extends TestCase
{
  private static final String test1 = "'\"=-/\\;\r\n";
  
  public void testDoFilter()
  {
    SQLFilter localSQLFilter = new SQLFilter();
    assertEquals("encode special charaters", "\\'\\\"\\=\\-\\/\\\\\\;\\r\\n", localSQLFilter.doFilter("'\"=-/\\;\r\n"));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\i18n\filter\test\SQLFilterTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */