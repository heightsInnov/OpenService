package org.bouncycastle.i18n.test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.i18n.filter.test.HTMLFilterTest;
import org.bouncycastle.i18n.filter.test.SQLFilterTest;

public class AllTests
  extends TestCase
{
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
  {
    TestSuite localTestSuite = new TestSuite("i18n tests");
    localTestSuite.addTestSuite(LocalizedMessageTest.class);
    localTestSuite.addTestSuite(HTMLFilterTest.class);
    localTestSuite.addTestSuite(SQLFilterTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\i18n\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */