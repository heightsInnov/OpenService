package org.bouncycastle.i18n.test;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import junit.framework.TestCase;
import org.bouncycastle.i18n.LocaleString;
import org.bouncycastle.i18n.LocalizedMessage;
import org.bouncycastle.i18n.MissingEntryException;
import org.bouncycastle.i18n.filter.HTMLFilter;
import org.bouncycastle.i18n.filter.TrustedInput;

public class LocalizedMessageTest
  extends TestCase
{
  private static final String TEST_RESOURCE = "org.bouncycastle.i18n.test.I18nTestMessages";
  private static final String UTF8_TEST_RESOURCE = "org.bouncycastle.i18n.test.I18nUTF8TestMessages";
  private static final String timeTestId = "time";
  private static final String argsTestId = "arguments";
  private static final String localeTestId = "hello";
  private static final String missingTestId = "missing";
  private static final String filterTestId = "filter";
  private static final String utf8TestId = "utf8";
  
  public void testGetEntry()
  {
    LocalizedMessage localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "hello");
    assertEquals("Hello world.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    assertEquals("Hallo Welt.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    Object[] arrayOfObject = { "Nobody" };
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "arguments", arrayOfObject);
    assertEquals("My name is Nobody.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    assertEquals("Mein Name ist Nobody.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    Date localDate = new Date(1155820320000L);
    arrayOfObject = new Object[] { new TrustedInput(localDate) };
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "time", arrayOfObject);
    assertEquals("It's 1:12:00 PM GMT at Aug 17, 2006.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getTimeZone("GMT")));
    assertEquals("Es ist 13.12 Uhr GMT am 17.08.2006.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getTimeZone("GMT")));
    arrayOfObject = new Object[] { new TrustedInput(localDate) };
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "time", arrayOfObject);
    localLocalizedMessage.setFilter(new HTMLFilter());
    assertEquals("It's 1:12:00 PM GMT at Aug 17, 2006.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getTimeZone("GMT")));
    assertEquals("Es ist 13.12 Uhr GMT am 17.08.2006.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getTimeZone("GMT")));
    arrayOfObject = new Object[] { new TrustedInput(new Float(0.2D)) };
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "number", arrayOfObject);
    assertEquals("20%", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    String str1 = "<script>doBadThings()</script>";
    arrayOfObject = new Object[] { str1 };
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "filter", arrayOfObject);
    localLocalizedMessage.setFilter(new HTMLFilter());
    assertEquals("The following part should contain no HTML tags: &#60script&#62doBadThings&#40&#41&#60/script&#62", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "missing");
    try
    {
      String str2 = localLocalizedMessage.getEntry("text", Locale.UK, TimeZone.getDefault());
      fail();
    }
    catch (MissingEntryException localMissingEntryException1)
    {
      System.out.println(localMissingEntryException1.getDebugMsg());
    }
    try
    {
      URLClassLoader localURLClassLoader = URLClassLoader.newInstance(new URL[] { new URL("file:///nonexistent/") });
      localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "missing");
      localLocalizedMessage.setClassLoader(localURLClassLoader);
      try
      {
        String str3 = localLocalizedMessage.getEntry("text", Locale.UK, TimeZone.getDefault());
        fail();
      }
      catch (MissingEntryException localMissingEntryException2)
      {
        System.out.println(localMissingEntryException2.getDebugMsg());
      }
    }
    catch (MalformedURLException localMalformedURLException) {}
    try
    {
      localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nUTF8TestMessages", "utf8", "UTF-8");
      assertEquals("some umlauts äöüèéà", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
  }
  
  public void testLocalizedArgs()
  {
    LocaleString localLocaleString1 = new LocaleString("org.bouncycastle.i18n.test.I18nTestMessages", "name");
    Object[] arrayOfObject = { localLocaleString1 };
    LocalizedMessage localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "arguments", arrayOfObject);
    assertEquals("My name is John.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    assertEquals("Mein Name ist Hans.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    localLocalizedMessage.setFilter(new HTMLFilter());
    assertEquals("My name is John.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    assertEquals("Mein Name ist Hans.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    LocaleString localLocaleString2 = new LocaleString("org.bouncycastle.i18n.test.I18nTestMessages", "hello.text");
    localLocalizedMessage.setExtraArguments(new Object[] { " ", localLocaleString2 });
    assertEquals("My name is John. Hello world.", localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault()));
    assertEquals("Mein Name ist Hans. Hallo Welt.", localLocalizedMessage.getEntry("text", Locale.GERMAN, TimeZone.getDefault()));
    try
    {
      localLocaleString1 = new LocaleString("org.bouncycastle.i18n.test.I18nTestMessages", "noname");
      arrayOfObject = new Object[] { localLocaleString1 };
      localLocalizedMessage = new LocalizedMessage("org.bouncycastle.i18n.test.I18nTestMessages", "arguments", arrayOfObject);
      localLocalizedMessage.getEntry("text", Locale.ENGLISH, TimeZone.getDefault());
      fail();
    }
    catch (MissingEntryException localMissingEntryException)
    {
      assertEquals("Can't find entry noname in resource file org.bouncycastle.i18n.test.I18nTestMessages.", localMissingEntryException.getMessage());
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\i18n\test\LocalizedMessageTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */