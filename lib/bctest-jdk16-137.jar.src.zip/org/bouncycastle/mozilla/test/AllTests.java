package org.bouncycastle.mozilla.test;

import java.security.Security;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.SimpleTestResult;

public class AllTests
  extends TestCase
{
  public void testMozilla()
  {
    Security.addProvider(new BouncyCastleProvider());
    org.bouncycastle.util.test.Test[] arrayOfTest = { new SPKACTest() };
    for (int i = 0; i != arrayOfTest.length; i++)
    {
      SimpleTestResult localSimpleTestResult = (SimpleTestResult)arrayOfTest[i].perform();
      if (!localSimpleTestResult.isSuccessful()) {
        fail(localSimpleTestResult.toString());
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static junit.framework.Test suite()
  {
    TestSuite localTestSuite = new TestSuite("Mozilla Tests");
    localTestSuite.addTestSuite(AllTests.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mozilla\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */