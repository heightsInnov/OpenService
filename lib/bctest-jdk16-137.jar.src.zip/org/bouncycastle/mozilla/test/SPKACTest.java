package org.bouncycastle.mozilla.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.security.PublicKey;
import java.security.Security;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.mozilla.PublicKeyAndChallenge;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mozilla.SignedPublicKeyAndChallenge;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class SPKACTest
  extends SimpleTest
{
  byte[] spkac = Base64.decode("MIIBOjCBpDCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEApne7ti0ibPhV8Iht7Pws5iRckM7x4mtZYxEpeX5/IO8tDsBFdY86ewuY2f2KCca0oMWr43kdkZbPyzf4CSV+0fZm9MJyNMywygZjoOCC+rS8kr0Ef31iHChhYsyejJnjw116Jnn96syhdHY6lVD1rK0nn5ZkHjxU74gjoZu6BJMCAwEAARYAMA0GCSqGSIb3DQEBBAUAA4GBAKFLg/luv0C7gMTI8ZKfFoSyi7Q7kiSQcmSj1WJgT56ouIRJO5NdvB/1n4GNik8VOAU0NRztvGy3ZGqgbSav7lrxcNEvXH+dLbtS97s7yiaozpsOcEHqsBribpLOTRzYa8ciCwkPmIiYqcby11diKLpd+W9RFYNme2v0rrbM2CyV");
  
  public String getName()
  {
    return "SignedPubicKeyAndChallenge";
  }
  
  public void spkacTest(String paramString, byte[] paramArrayOfByte)
    throws Exception
  {
    SignedPublicKeyAndChallenge localSignedPublicKeyAndChallenge = new SignedPublicKeyAndChallenge(paramArrayOfByte);
    PublicKeyAndChallenge localPublicKeyAndChallenge = localSignedPublicKeyAndChallenge.getPublicKeyAndChallenge();
    PublicKey localPublicKey = localSignedPublicKeyAndChallenge.getPublicKey("BC");
    DERObject localDERObject = localPublicKeyAndChallenge.getDERObject();
    if (localDERObject == null) {
      fail("Error - " + paramString + " PKAC DERObject was null.");
    }
    localDERObject = localSignedPublicKeyAndChallenge.getDERObject();
    if (localDERObject == null) {
      fail("Error - " + paramString + " SPKAC DERObject was null.");
    }
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = localPublicKeyAndChallenge.getSubjectPublicKeyInfo();
    if (localSubjectPublicKeyInfo == null) {
      fail("Error - " + paramString + " SubjectPublicKeyInfo was null.");
    }
    DERIA5String localDERIA5String = localPublicKeyAndChallenge.getChallenge();
    if (localDERIA5String == null) {
      fail(":Error - " + paramString + " challenge was null.");
    }
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    localDEROutputStream.writeObject(localSignedPublicKeyAndChallenge.getDERObject());
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (arrayOfByte.length != paramArrayOfByte.length) {
      fail(paramString + " failed length test");
    }
    for (int i = 0; i != paramArrayOfByte.length; i++) {
      if (arrayOfByte[i] != paramArrayOfByte[i]) {
        fail(paramString + " failed comparison test");
      }
    }
    if (!localSignedPublicKeyAndChallenge.verify("BC")) {
      fail(paramString + " verification failed");
    }
  }
  
  public void performTest()
    throws Exception
  {
    spkacTest("spkac", this.spkac);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new SPKACTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mozilla\test\SPKACTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */