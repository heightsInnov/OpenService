package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class DSA2Test
  extends TestCase
{
  private static final String TEST_DATA_HOME = "bc.test.data.home";
  
  public void setUp()
  {
    if (Security.getProvider("BC") == null) {
      Security.addProvider(new BouncyCastleProvider());
    }
  }
  
  public void testK1024H160()
    throws Exception
  {
    doSigVerifyTest("DSA-1024-160.pub", "dsa-1024-160-sign.gpg");
  }
  
  public void testK1024H224()
    throws Exception
  {
    doSigVerifyTest("DSA-1024-160.pub", "dsa-1024-224-sign.gpg");
  }
  
  public void testK1024H256()
    throws Exception
  {
    doSigVerifyTest("DSA-1024-160.pub", "dsa-1024-256-sign.gpg");
  }
  
  public void testK1024H384()
    throws Exception
  {
    doSigVerifyTest("DSA-1024-160.pub", "dsa-1024-384-sign.gpg");
  }
  
  public void testK1024H512()
    throws Exception
  {
    doSigVerifyTest("DSA-1024-160.pub", "dsa-1024-512-sign.gpg");
  }
  
  public void testK2048H224()
    throws Exception
  {
    doSigVerifyTest("DSA-2048-224.pub", "dsa-2048-224-sign.gpg");
  }
  
  public void testK3072H256()
    throws Exception
  {
    doSigVerifyTest("DSA-3072-256.pub", "dsa-3072-256-sign.gpg");
  }
  
  public void testK7680H384()
    throws Exception
  {
    doSigVerifyTest("DSA-7680-384.pub", "dsa-7680-384-sign.gpg");
  }
  
  public void testK15360H512()
    throws Exception
  {
    doSigVerifyTest("DSA-15360-512.pub", "dsa-15360-512-sign.gpg");
  }
  
  public void testGenerateK1024H224()
    throws Exception
  {
    doSigGenerateTest("DSA-1024-160.sec", "DSA-1024-160.pub", 11);
  }
  
  public void testGenerateK1024H256()
    throws Exception
  {
    doSigGenerateTest("DSA-1024-160.sec", "DSA-1024-160.pub", 8);
  }
  
  public void testGenerateK1024H384()
    throws Exception
  {
    doSigGenerateTest("DSA-1024-160.sec", "DSA-1024-160.pub", 9);
  }
  
  public void testGenerateK1024H512()
    throws Exception
  {
    doSigGenerateTest("DSA-1024-160.sec", "DSA-1024-160.pub", 10);
  }
  
  public void testGenerateK2048H256()
    throws Exception
  {
    doSigGenerateTest("DSA-2048-224.sec", "DSA-2048-224.pub", 8);
  }
  
  public void testGenerateK2048H512()
    throws Exception
  {
    doSigGenerateTest("DSA-2048-224.sec", "DSA-2048-224.pub", 10);
  }
  
  private void doSigGenerateTest(String paramString1, String paramString2, int paramInt)
    throws Exception
  {
    PGPSecretKeyRing localPGPSecretKeyRing = loadSecretKey(paramString1);
    PGPPublicKeyRing localPGPPublicKeyRing = loadPublicKey(paramString2);
    String str = "hello world!";
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(str.getBytes());
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(17, paramInt, "BC");
    localPGPSignatureGenerator.initSign(0, localPGPSecretKeyRing.getSecretKey().extractPrivateKey("test".toCharArray(), "BC"));
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    Date localDate = new Date(System.currentTimeMillis() / 1000L * 1000L);
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localBCPGOutputStream), 'b', "_CONSOLE", str.getBytes().length, localDate);
    int i;
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localPGPLiteralDataGenerator.close();
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localByteArrayOutputStream.toByteArray());
    PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory.nextObject();
    PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    assertEquals(paramInt, localPGPOnePassSignature.getHashAlgorithm());
    assertEquals(17, localPGPOnePassSignature.getKeyAlgorithm());
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    if (!localPGPLiteralData.getModificationTime().equals(localDate)) {
      fail("Modification time not preserved");
    }
    InputStream localInputStream = localPGPLiteralData.getInputStream();
    localPGPOnePassSignature.initVerify(localPGPPublicKeyRing.getPublicKey(), "BC");
    while ((i = localInputStream.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    PGPSignature localPGPSignature = localPGPSignatureList.get(0);
    assertEquals(paramInt, localPGPSignature.getHashAlgorithm());
    assertEquals(17, localPGPSignature.getKeyAlgorithm());
    assertTrue(localPGPOnePassSignature.verify(localPGPSignature));
  }
  
  private void doSigVerifyTest(String paramString1, String paramString2)
    throws Exception
  {
    PGPPublicKeyRing localPGPPublicKeyRing = loadPublicKey(paramString1);
    PGPObjectFactory localPGPObjectFactory = loadSig(paramString2);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory.nextObject();
    localPGPObjectFactory = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory.nextObject();
    PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPLiteralData.getInputStream();
    localPGPOnePassSignature.initVerify(localPGPPublicKeyRing.getPublicKey(), "BC");
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    assertTrue(localPGPOnePassSignature.verify(localPGPSignatureList.get(0)));
  }
  
  private PGPObjectFactory loadSig(String paramString)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(getDataHome() + "/sigs/" + paramString);
    return new PGPObjectFactory(localFileInputStream);
  }
  
  private PGPPublicKeyRing loadPublicKey(String paramString)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(getDataHome() + "/keys/" + paramString);
    return new PGPPublicKeyRing(localFileInputStream);
  }
  
  private PGPSecretKeyRing loadSecretKey(String paramString)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(getDataHome() + "/keys/" + paramString);
    return new PGPSecretKeyRing(localFileInputStream);
  }
  
  private String getDataHome()
  {
    String str = System.getProperty("bc.test.data.home");
    if (str == null) {
      throw new IllegalStateException("bc.test.data.home property not set");
    }
    return str + "/openpgp/dsa";
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("GPG DSA2 tests");
    localTestSuite.addTestSuite(DSA2Test.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\DSA2Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */