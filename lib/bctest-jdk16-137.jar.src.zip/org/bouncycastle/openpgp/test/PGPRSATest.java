package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;
import javax.crypto.Cipher;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPBEEncryptedData;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPV3SignatureGenerator;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPRSATest
  extends SimpleTest
{
  byte[] testPubKey = Base64.decode("mIsEPz2nJAEEAOTVqWMvqYE693qTgzKv/TJpIj3hI8LlYPC6m1dk0z3bDLwVVk9FFAB+CWS8RdFOWt/FG3tEv2nzcoNdRvjv9WALyIGNawtae4Ml6oAT06/511yUzXHOk+9xK3wkXN5jdzUhf4cA2oGpLSV/pZlocsIDL+jCUQtumUPwFodmSHhzAAYptC9FcmljIEVjaGlkbmEgKHRlc3Qga2V5KSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPoi4BBMBAgAiBQI/PackAhsDBQkAg9YABAsHAwIDFQIDAxYCAQIeAQIXgAAKCRA1WGFG/fPzc8WMA/9BbjuB8E48QAlxoiVf9U8SfNelrz/ONJA/bMvWr/JnOGA9PPmFD5Uc+kV/q+i94dEMjsC5CQ1moUHWSP2xlQhbOzBP2+oPXw3z2fBs9XJgnTH6QWMAAvLs3ug9po0loNHLobT/D/XdXvcrb3wvwvPT2FptZqrtonH/OdzT9JdfrA==");
  byte[] testPrivKey = Base64.decode("lQH8BD89pyQBBADk1aljL6mBOvd6k4Myr/0yaSI94SPC5WDwuptXZNM92wy8FVZPRRQAfglkvEXRTlrfxRt7RL9p83KDXUb47/VgC8iBjWsLWnuDJeqAE9Ov+ddclM1xzpPvcSt8JFzeY3c1IX+HANqBqS0lf6WZaHLCAy/owlELbplD8BaHZkh4cwAGKf4DAwKbLeIOVYTEdWD5v/YgW8ERs0pDsSIfBTvsJp2qA798KeFuED6jGsHUzdi1M9906PRtplQgnoYmYQrzEc6DXAiAtBR4Kuxi4XHx0ZR2wpVlVxm2Ypgz7pbBNWcWqzvw33inl7tR4IDsRdJOY8cFlN+1tSCf16sDidtKXUVjRjZNYJytH18VfSPlGXMeYgtw3cSGNTERwKaq5E/SozT2MKTiORO0g0Mtyz+9MEB6XVXFavMun/mXURqbZN/k9BFbz+TadpkihrLD1xw3Hp+tpe4CwPQ2GdWKI9KNo5gEnbkJgLrSMGgWalPhknlNHRyYbSq6lbIMJEE3LoOwvYWwweR1+GrV9farJESdunl1mDr5/d6rKru+FFDwZM3na1IF4Ei4FpqhivZ4zG6pN5XqLy+AK85EiW4XH0yAKX1O4YlbmDU4BjxhiwTdwuVMCjLO5++jkz5BBQWdFX8CCMA4FJl36G70IbGzuFfOj07ly7QvRXJpYyBFY2hpZG5hICh0ZXN0IGtleSkgPGVyaWNAYm91bmN5Y2FzdGxlLm9yZz6IuAQTAQIAIgUCPz2nJAIbAwUJAIPWAAQLBwMCAxUCAwMWAgECHgECF4AACgkQNVhhRv3z83PFjAP/QW47gfBOPEAJcaIlX/VPEnzXpa8/zjSQP2zL1q/yZzhgPTz5hQ+VHPpFf6voveHRDI7AuQkNZqFB1kj9sZUIWzswT9vqD18N89nwbPVyYJ0x+kFjAALy7N7oPaaNJaDRy6G0/w/13V73K298L8Lz09habWaq7aJx/znc0/SXX6w=");
  byte[] testPubKeyV3 = Base64.decode("mQCNAz+zvlEAAAEEAMS22jgXbOZ/D3xWgM2kauSdzrwlU7Ms5hDW05ObqQyOFfQoKKMhfupyoa7J3x04VVBKu6Eomvr1es+VImH0esoeWFFahNOYq/I+jRRBwoOhAGZ5UB2/hRd7rFmxqp6sCXi8wmLO2tAorlTzAiNNvl7xF4cQZpc0z56Fwdi2fBUJAAURtApGSVhDSVRZX1FBiQCVAwUQP7O+UZ6Fwdi2fBUJAQFMwwQAqRnFsdg4xQnB8Y5d4cOpXkIn9AZgYS3cxtuSJB84vG2CgC39nfv4c+nlLkWP4puG+mZuJNgVoE84cuAF4I//1anKjlU7q1M6rFQnt5S4uxPyG3dFXmgyU1b4PBOnA0tIxjPzlIhJAMsPCGGA5+5M2JP0ad6RnzqzE3EENMX+GqY=");
  byte[] testPrivKeyV3 = Base64.decode("lQHfAz+zvlEAAAEEAMS22jgXbOZ/D3xWgM2kauSdzrwlU7Ms5hDW05ObqQyOFfQoKKMhfupyoa7J3x04VVBKu6Eomvr1es+VImH0esoeWFFahNOYq/I+jRRBwoOhAGZ5UB2/hRd7rFmxqp6sCXi8wmLO2tAorlTzAiNNvl7xF4cQZpc0z56Fwdi2fBUJAAURAXWwRBZQHNikA/f0ScLLjrXi4s0hgQecg+dkpDow94eu5+AR0DzZnfurpgfUJCNiDi5W/5c3Zj/xyrfMAgkbCgJ1m6FZqAQh7Mq73l7Kfu4/XIkyDF3tDgRuZNezB+JuElX10tV03xumHepp6M6CfhXqNJ15F33F99TA5hXYCPYD7SiSOpIhQkCOAgDAA63imxbpuKE2W7Y4I1BUHB7WQi8ZdkZd04njNTv+rFUuOPapQVfbWG0Vq8ld3YmJB4QWsa2mmqn+qToXbwufAgBpXkjvqK5yPiHFPx2QbFc1VqoCJB6PO5JRIqEiUZBFGdDlLxt3VSyqz7IZ/zEnxZq+tPCGGGSm/sAGiMvENcHVAfy0kTXU42TxEAYJyyNyqjXOobDJpEV1mKhFskRXt7tbMfOSYf91oX8f6xw6O2Nal+hU8dS0Bmfmk5/enHmvRLHQocO0CkZJWENJVFlfUUE=");
  byte[] sig1 = Base64.decode("owGbwMvMwMRoGpHo9vfz52LGNTJJnBmpOTn5eiUVJfb23JvAHIXy/KKcFEWuToapzKwMIGG4Bqav0SwMy3yParsEKi2LMGI9xhh65sBxb05n5++ZLcWNJ/eLFKdWbm95tHbDV7GMwj/tUctUpFUXWPYFCLdNsDiVNuXbQvZtdXV/5xzY+9w1nCnijH9JoNiJ22n2jo0zo30/TZLo+jDl2vTzIvPeLEsPM3ZUE/1Ytqs4SG2TxIQbH7xf3uzcYXq25Fw9AA==");
  byte[] sig1crc = Base64.decode("+3i0");
  byte[] subKey = Base64.decode("lQH8BD89pyQBBADk1aljL6mBOvd6k4Myr/0yaSI94SPC5WDwuptXZNM92wy8FVZPRRQAfglkvEXRTlrfxRt7RL9p83KDXUb47/VgC8iBjWsLWnuDJeqAE9Ov+ddclM1xzpPvcSt8JFzeY3c1IX+HANqBqS0lf6WZaHLCAy/owlELbplD8BaHZkh4cwAGKf4DAwKt6ZC7iqsQHGDNn2ZAuhS+ZwiFC+BToW9Vq6rwggWjgM/SThv55rfDk7keiXUTMyUcZVeYBe4Jttb4fAAm83hNztFu6Jvm9ITcm7YvnasBtVQjppaB+oYZgsTtwK99LGC3mdexnriCLxPN6tDFkGhzdOcYZfK6py4Ska8Dmq9nOZU9Qtv7Pm3qa5tuBvYwmyTxeaJYifZTu/sky3Gj+REb8WonbgAJX/sLNBPUt+vYko+lxU8uqZpVEMU//hGGRns2gIHdbSbIe1vGgIRUEd7Z0b7jfVQLUwqHDyfh5DGvAUhvtJogjUyFIXZzpU+E9ES9t7LZKdwNZSIdNUjM2eaf4g8BpuQobBVkj/GUcotKyeBjwvKxHlRefL4CCw28DO3SnLRKxd7uBSqeOGUKxqasgdekM/xIFOrJ85k7p89n6ncLQLHCPGVkzmVeRZro/T7zE91J57qBGZOUAP1vllcYLty1cs9PCc5oWnj3XbQvRXJpYyBFY2hpZG5hICh0ZXN0IGtleSkgPGVyaWNAYm91bmN5Y2FzdGxlLm9yZz6IuAQTAQIAIgUCPz2nJAIbAwUJAIPWAAQLBwMCAxUCAwMWAgECHgECF4AACgkQNVhhRv3z83PFjAP/QW47gfBOPEAJcaIlX/VPEnzXpa8/zjSQP2zL1q/yZzhgPTz5hQ+VHPpFf6voveHRDI7AuQkNZqFB1kj9sZUIWzswT9vqD18N89nwbPVyYJ0x+kFjAALy7N7oPaaNJaDRy6G0/w/13V73K298L8Lz09habWaq7aJx/znc0/SXX6y0JEVyaWMgRWNoaWRuYSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPoi4BBMBAgAiBQI/RxQNAhsDBQkAg9YABAsHAwIDFQIDAxYCAQIeAQIXgAAKCRA1WGFG/fPzc3O6A/49tXFCiiP8vg77OXvnmbnzPBA1G6jCRZNP1yIXusOjpHqyLN5K9hw6lq/o4pNiCuiq32osqGRX3lv/nDduJU1kn2Ow+I2Vci+ojMXdCGdEqPwZfv47jHLwRrIUJ22OOoWsORtgvSeRUd4Izg8jruaFM7ufr5hrjEl1cuLW1Hr8Lp0B/AQ/RxxQAQQA0J2BIdqb8JtDGKjvYxrju0urJVVzyI1CnCjAp7CtLoHQJUQU7PajnV4Jd12ukfcoK7MRraYydQEjxh2MqPpuQgJS3dgQVrxOParDQYBFrZNd2tZxOjYakhErvUmRo6yWFaxChwqMgl8XWugBNg1Dva+/YcoGQ+ly+Jg4RWZoH88ABin+AwMCldD/2v8TyT1ghK70IuFs4MZBhdm6VgyGR8DQ/Ago6IAjA4BYSol3lJb7+IIGsZaXwEuMRUvn6dWfa3r2I0p1t75vZb1Ng1YK32RZ5DNzl4Xb3L8VD+1Fiz9mHO8wiplAwDudB+RmQMlth3DNi/UsjeCTdEJAT+TTC7D40DiHDb1bR86Y2O5Y7MQ3SZs3/x0D/Ob6PStjfQ1kiqbruAMROKoavG0zVgxvspkoKN7h7BapnwJM6yf4qN/aByhAx9sFvADxu6z3SVcxiFw3IgAmabyWYb85LP8AsTYAG/HBoC6yob47Mt+GEDeyPifzzGXBWYIH4heZbSQivvA0eRwY5VZsMsBkbY5VR0FLVWgplbuO21bSrPS1T0crC+Zfj7FQBAkTfsg8RZQ8MPaHng01+gnFd243DDFvTAHygvm6a2X2fiRw5epAST4wWfY/BZNOxmfSKH6QS0oQMRscw79He6vGTB7vunLrKQYD4veInwQYAQIACQUCP0ccUAIbDAAKCRA1WGFG/fPzczmFA/wMg5HhN5NkqmjnHUFfeXNXdHzmekyw38RnuCMKmfc43AiDs+FtJ62gpQ6PEsZF4o9S5fxcjVk3VSg00XMDtQ/0BsKBc5GxhJTq7G+/SoeM433WG19uoS0+5Lf/31wNoTnpv6npOaYpcTQ7L9LCnzwAF4H0hJPE6bhmW2CMcsE/IZUB4QQ/Rwc1EQQAs5MUQlRiYOfi3fQ1OF6Z3eCwioDKu2DmOxotBICvdoG2muvs0KEBas9bbd0FJqc92FZJv8yxEgQbQtQAiFxoIFHRTFK+SPO/tQm+r83nwLRrfDeVVdRfzF79YCc+Abuh8sS/53H3u9Y7DYWr9IuMgI39nrVhY+d8yukfjo4OR+sAoKS/f7V1Xxj/Eqhb8qzf+N+zJRUlBACDd1eo/zFJZcq2YJa7a9vkViMEaxvwApqxeoU7oDpeHEMWg2DXJ7V24ZU5SbPTMY0x98cc8pcoqwsqux8xicWc0rehU3odQxWM4Se0LmEdca0nQOmNJlL9IsQ+QOJzx47qUOUAqhxnkXxQ/6B8w+M6gZyafwSdy70OumxESZipeQP+Lo9x6FcaW9L78hDX0aijJhgSEsnGODKB+bln29txX37E/a/Si+pyeLMi82kUdIL3G3I5HPWd3qSO4K94062+HfFj8bA20/1tbb/WxvxB2sKJi3IobblFOvFHo+v8GaLdVyartp0JZLue/jP1dl9ctulSrIqaJT342uLsgTjsr2z+AwMCAyAU8Vo5AhhgFkDto8vQk7yxyRKEzu5qB66dRcTlaUPIiR8kamcy5ZTtujs4KIW4j2M/LvagrpWfV5+0M0VyaWMgRWNoaWRuYSAoRFNBIFRlc3QgS2V5KSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPohZBBMRAgAZBQI/Rwc1BAsHAwIDFQIDAxYCAQIeAQIXgAAKCRDNI/XpxMo0QwJcAJ40447eezSiIMspuzkwsMyFN8YBaQCdFTuZuT30CphiUYWnsC0mQ+J15B4=");
  byte[] enc1 = Base64.decode("hIwDKwfQexPJboABA/4/7prhYYMORTiQ5avQKx0XYpCLujzGefYjnyuWZnx3Iev8Pmsguumm+OLLvtXhhkXQmkJRXbIg6Otj2ubPYWflRPgpJSgOrNOreOl5jeABOrtwbV6TJb9OTtZuB7cTQSCq2gmYiSZkluIiDjNs3R3mEanILbYzOQ3zKSggKpzlv9JQAZUqTyDyJ6/OUbJF5fI5uiv76DCsw1zyMWotUIu5/X01q+AVP5Ly3STzI7xkWg/JAPz4zUHism7kSYz2viAQaJx9/bNnH3AM6qm1Fuyikl4=");
  byte[] enc1crc = Base64.decode("lv4o");
  byte[] enc2 = Base64.decode("hIwDKwfQexPJboABBAC62jcJH8xKnKb1neDVmiovYON04+7VQ2v4BmeHwJrdag1gYa++6PeBlQ2Q9lSGBwLobVuJmQ7cOnPUJP727JeSGWlMyFtMbBSHekOaTenT5lj7Zk7oRHxMp/hByzlMacIDzOn8LPSh515RHM57eDLCOwqnAxGQwk67GRl8f5dFH9JQAa7xx8rjCqPbiIQW6t5LqCNvPZOiSCmftll6+se1XJhFEuq8WS4nXtPfTiJ3vib43soJdHzGB6AOs+BQ6aKmmNTVAxa5owhtSt1Z/6dfSSk=");
  byte[] subPubKey = Base64.decode("mIsEPz2nJAEEAOTVqWMvqYE693qTgzKv/TJpIj3hI8LlYPC6m1dk0z3bDLwVVk9FFAB+CWS8RdFOWt/FG3tEv2nzcoNdRvjv9WALyIGNawtae4Ml6oAT06/511yUzXHOk+9xK3wkXN5jdzUhf4cA2oGpLSV/pZlocsIDL+jCUQtumUPwFodmSHhzAAYptC9FcmljIEVjaGlkbmEgKHRlc3Qga2V5KSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPoi4BBMBAgAiBQI/PackAhsDBQkAg9YABAsHAwIDFQIDAxYCAQIeAQIXgAAKCRA1WGFG/fPzc8WMA/9BbjuB8E48QAlxoiVf9U8SfNelrz/ONJA/bMvWr/JnOGA9PPmFD5Uc+kV/q+i94dEMjsC5CQ1moUHWSP2xlQhbOzBP2+oPXw3z2fBs9XJgnTH6QWMAAvLs3ug9po0loNHLobT/D/XdXvcrb3wvwvPT2FptZqrtonH/OdzT9JdfrIhMBBARAgAMBQI/RxooBYMAemL8AAoJEM0j9enEyjRDiBgAn3RcLK+gq90PvnQFTw2DNqdq7KA0AKCS0EEIXCzbV1tfTdCUJ3hVh3btF7QkRXJpYyBFY2hpZG5hIDxlcmljQGJvdW5jeWNhc3RsZS5vcmc+iLgEEwECACIFAj9HFA0CGwMFCQCD1gAECwcDAgMVAgMDFgIBAh4BAheAAAoJEDVYYUb98/Nzc7oD/j21cUKKI/y+Dvs5e+eZufM8EDUbqMJFk0/XIhe6w6OkerIs3kr2HDqWr+jik2IK6KrfaiyoZFfeW/+cN24lTWSfY7D4jZVyL6iMxd0IZ0So/Bl+/juMcvBGshQnbY46haw5G2C9J5FR3gjODyOu5oUzu5+vmGuMSXVy4tbUevwuiEwEEBECAAwFAj9HGigFgwB6YvwACgkQzSP16cTKNEPwBQCdHm0AmwzaNmVmDHm3rmqI7rp2oQ0An2YbiP/H/kmBNnmTeH55kd253QOhuIsEP0ccUAEEANCdgSHam/CbQxio72Ma47tLqyVVc8iNQpwowKewrS6B0CVEFOz2o51eCXddrpH3KCuzEa2mMnUBI8YdjKj6bkICUt3YEFa8Tj2qw0GARa2TXdrWcTo2GpIRK71JkaOslhWsQocKjIJfF1roATYNQ72vv2HKBkPpcviYOEVmaB/PAAYpiJ8EGAECAAkFAj9HHFACGwwACgkQNVhhRv3z83M5hQP8DIOR4TeTZKpo5x1BX3lzV3R85npMsN/EZ7gjCpn3ONwIg7PhbSetoKUOjxLGReKPUuX8XI1ZN1UoNNFzA7UP9AbCgXORsYSU6uxvv0qHjON91htfbqEtPuS3/99cDaE56b+p6TmmKXE0Oy/Swp88ABeB9ISTxOm4ZltgjHLBPyGZAaIEP0cHNREEALOTFEJUYmDn4t30NThemd3gsIqAyrtg5jsaLQSAr3aBtprr7NChAWrPW23dBSanPdhWSb/MsRIEG0LUAIhcaCBR0UxSvkjzv7UJvq/N58C0a3w3lVXUX8xe/WAnPgG7ofLEv+dx97vWOw2Fq/SLjICN/Z61YWPnfMrpH46ODkfrAKCkv3+1dV8Y/xKoW/Ks3/jfsyUVJQQAg3dXqP8xSWXKtmCWu2vb5FYjBGsb8AKasXqFO6A6XhxDFoNg1ye1duGVOUmz0zGNMffHHPKXKKsLKrsfMYnFnNK3oVN6HUMVjOEntC5hHXGtJ0DpjSZS/SLEPkDic8eO6lDlAKocZ5F8UP+gfMPjOoGcmn8Encu9DrpsREmYqXkD/i6PcehXGlvS+/IQ19GooyYYEhLJxjgygfm5Z9vbcV9+xP2v0ovqcnizIvNpFHSC9xtyORz1nd6kjuCveNOtvh3xY/GwNtP9bW2/1sb8QdrCiYtyKG25RTrxR6Pr/Bmi3Vcmq7adCWS7nv4z9XZfXLbpUqyKmiU9+Nri7IE47K9stDNFcmljIEVjaGlkbmEgKERTQSBUZXN0IEtleSkgPGVyaWNAYm91bmN5Y2FzdGxlLm9yZz6IWQQTEQIAGQUCP0cHNQQLBwMCAxUCAwMWAgECHgECF4AACgkQzSP16cTKNEMCXACfauuibSwyG59Yrm8hHCDuCPmqwsQAni+dPl08FVuWh+wb6kOgJV4lcYae");
  byte[] subPubCrc = Base64.decode("rikt");
  byte[] pgp8Key = Base64.decode("lQIEBEBXUNMBBADScQczBibewnbCzCswc/9ut8R0fwlltBRxMW0NMdKJY2LF7k2COeLOCIU95loJGV6ulbpDCXEO2Jyq8/qGw1qD3SCZNXxKs3GS8Iyh9UwdVL07nMMYl5NiQRsFB7wOb86+94tYWgvikVA5BRP5y3+O3GItnXnpWSJyREUy6WI2QQAGKf4JAwIVmnRs4jtTX2DD05zy2mepEQ8bsqVAKIx7lEwvMVNcvg4Y8vFLh9Mf/uNciwL4Se/ehfKQ/AT0JmBZduYMqRU2zhiBmxj4cXUQ0s36ysj7fyDngGocDnM3cwPxaTF1ZRBQHSLewP7dqE7M73usFSz8vwD/0xNOHFRLKbsORqDlLA1Cg2Yd0wWPS0o7+qqk9ndqrjjSwMM8ftnzFGjShAdg4Ca7fFkcNePP/rrwIH472FuRb7RbWzwXA4+4ZBdl8D4An0dwtfvAO+jCZSrLjmSpxEOveJxYGduyR4IA4lemvAG51YHTHd4NXheuEqsIkn1yarwaaj47lFPnxNOElOREMdZbnkWQb1jfgqO24imEZgrLMkK9bJfoDnlF4k6r6hZOp5FSFvc5kJB4cVo1QJl4pwCSdoU6luwCggrlZhDnkGCSuQUUW45NE7Br22NGqn4/gHs0KCsWbAezApGjqYUCfX1bcpPzUMzUlBaD5rz2vPeO58CDtBJ0ZXN0ZXIgPHRlc3RAdGVzdD6IsgQTAQIAHAUCQFdQ0wIbAwQLBwMCAxUCAwMWAgECHgECF4AACgkQs8JyyQfH97I1QgP8Cd+35maM2cbWV9iVRO+c5456KDi3oIUSNdPf1NQrCAtJqEUhmMStQbdiaFEkPrORISI/2htXruYn0aIpkCfbUheHOu0sef7s6pHmI2kOQPzR+C/j8D9QvWsPOOso81KU2axUY8zIer64Uzqc4szMIlLw06c8vea27RfgjBpSCrywAgAA");
  char[] pgp8Pass = "2002 Buffalo Sabres".toCharArray();
  char[] pass = { 'h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd' };
  byte[] fingerprintKey = Base64.decode("mQEPA0CiJdUAAAEIAMI+znDlPd2kQoEcnxqxLcRz56Z7ttFKHpnYp0UkljZdquVcBy1jMfXGVV64xN1IvMcyenLXUE0IUeUBCQs6tHunFRAPSeCxJ3FdFe1B5MpqQG8ABnEpAds/hAUfRDZD5y/lolk1hjvFMrRh6WXckaA/QQ2t00NmTrJ1pYUpkw9tnVQbLUjWJhfZDBBcN0ADtATzgkugxMtcDxR6I5x8Ndn+IilqIm23kxGIcmMd/BHOec4cjRwJXXDb7u8tl+2knAf9cwhPHp3+Zy4uGSQPdzQnXOhBlA+4WDa0RROOevWgq8uq8/9Xp/OlTVL+OoIzjsI6mJP1Joa4qmqAnaHAmXcAEQEAAbQoQk9BM1JTS1kgPEJPQSBNb25pdG9yaW5nIEAgODg4LTI2OS01MjY2PokBFQMFEECiJdWqaoCdocCZdwEB0RsH/3HPxoUZ3G3K7T3jgOnJUckTSHWU3XspHzMVgqOxjTrcexi5IsAM5M+BulfWT2aO+Kqf5w8cKTKgW02DNpHUiPjHx0nzDE+Do95zbIErGeK+Twkc4O/aVsvU9GGO81VFI6WMvDQ4CUAUnAdk03MRrzI2nAuhn4NJ5LQS+uJrnqUJ4HmFAz6CQZQKd/kSXgq+A6i7aI1LG80YxWa9ooQgaCrb9dwY/kPQ+yC22zQ3FExtv+Fv3VtAKTilO3vnBA4Y9uTHuObHfI+1yxUS2PrlRUX0m48ZjpIX+cEN3QblGBJudI/A1QSd6P0LZeBr7F1Z1aF7ZDo0KzgiAIBvgXkeTpw=");
  byte[] fingerprintCheck = Base64.decode("CTv2");
  byte[] expiry60and30daysSig13Key = Base64.decode("mQGiBENZt/URBAC5JccXiwe4g6MuviEC8NI/x0NaVkGFAOY04d5E4jeIycBPSrpOPrjETuigqhrj8oqed2+2yUqfnK4nhTsTAjyeJ3PpWC1pGAKzJgYmJk+K9aTLq0BQWiXDdv5RG6fDmeq1umvOfcXBqGFAguLPZC+U872bSLnfe3lqGNA8jvmY7wCgjhzVQVm10NN5ST8nemPEcSjnBrED/R494gHL6+r5OgUgXnNCDejA4InoDImQCF+g7epp5E1MB6CMYSg2WSY2jHFuHpwnUb7AiOO0ZZ3UBqM9rYnKkDvxkFCxba7Ms+aFj9blRNmy3vG4FewDcTdxzCtjUk6dRfu6UoARpqlTE/q7Xo6EQP1ncwJ+UTlcHkTBvg/usI/yBACGjBqX8glb5VfNaZgNHMeS/UIiUiuVSVFojiSDOHcnCe/6y4M2gVm38zz1W9qhoLfLpiAOFeL0yj6wzXvsjjXQiKQ8nBE4Mf+oeH2qiQ/LfzQrGpI5eNcMXrzK9nigmz2htYO2GjQfupEnu1RHBTH8NjofD2AShL9IO73plRuExrQgVGVzdCBLZXkgPHRlc3RAYm91bmN5Y2FzdGxlLm9yZz6IZAQTEQIAJAIbAwYLCQgHAwIDFQIDAxYCAQIeAQIXgAUCQ1m4DgUJAE8aGQAKCRD8QP1QuU7Kqw+eAJ0dZ3ZAqr73X61VmCkbyPoszLQMAQCfdFs2YMDeUvX34Q/8Ba0KgO5f3RSwAgADuM0EQ1m39hADAIHpVGcLqS9UkmQaWBvHWP6TnN7Y1Ha0TJOuxpbFjBW+CmVh/FjcsnavFXDXpo2zc742WT+vrHBSa/0D1QEBsnCaX5SRRVp7Mqs8q+aDhjcHMIP8Sdxf7GozXDORkrRaJwADBQL9HLYm7Rr5iYWDcvs+Pi6O1zUyb1tjkxEGaV/rcozl2MMmr2mzJ6x/Bz8SuhZEJS0mbB2CvAA39aQi9jHlV7q0SV73NOkd2L/Vt2UZhzlUdvrJ37PgYDv+Wd9Ufz6gMzLSiE8EGBECAA8FAkNZt/YCGwwFCQAnjQAACgkQ/ED9ULlOyqsTqQCcDnAZ7YymCfhm1yJiuFQg3qiX6Z4An19OSEgeSKugVcH49g1sxUB0zNdIsAIAAw==");
  
  private void fingerPrintTest()
    throws Exception
  {
    PGPPublicKeyRing localPGPPublicKeyRing = new PGPPublicKeyRing(this.fingerprintKey);
    PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey();
    if (!areEqual(localPGPPublicKey.getFingerprint(), Hex.decode("4FFB9F0884266C715D1CEAC804A3BBFA"))) {
      fail("version 3 fingerprint test failed");
    }
    localPGPPublicKeyRing = new PGPPublicKeyRing(this.testPubKey);
    localPGPPublicKey = localPGPPublicKeyRing.getPublicKey();
    if (!areEqual(localPGPPublicKey.getFingerprint(), Hex.decode("3062363c1046a01a751946bb35586146fdf3f373"))) {
      fail("version 4 fingerprint test failed");
    }
  }
  
  private void mixedTest(PGPPrivateKey paramPGPPrivateKey, PGPPublicKey paramPGPPublicKey)
    throws Exception
  {
    byte[] arrayOfByte1 = { 104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33, 10 };
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream1 = localPGPLiteralDataGenerator.open(localByteArrayOutputStream1, 'b', "_CONSOLE", arrayOfByte1.length, new Date());
    localOutputStream1.write(arrayOfByte1);
    localPGPLiteralDataGenerator.close();
    byte[] arrayOfByte2 = localByteArrayOutputStream1.toByteArray();
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(arrayOfByte2);
    checkLiteralData((PGPLiteralData)localPGPObjectFactory1.nextObject(), arrayOfByte1);
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(7, true, new SecureRandom(), "BC");
    localPGPEncryptedDataGenerator.addMethod(paramPGPPublicKey);
    localPGPEncryptedDataGenerator.addMethod("password".toCharArray());
    OutputStream localOutputStream2 = localPGPEncryptedDataGenerator.open(localByteArrayOutputStream2, arrayOfByte2.length);
    localOutputStream2.write(arrayOfByte2);
    localOutputStream2.close();
    byte[] arrayOfByte3 = localByteArrayOutputStream2.toByteArray();
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(arrayOfByte3);
    PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
    InputStream localInputStream = localPGPPublicKeyEncryptedData.getDataStream(paramPGPPrivateKey, "BC");
    PGPObjectFactory localPGPObjectFactory3 = new PGPObjectFactory(localInputStream);
    checkLiteralData((PGPLiteralData)localPGPObjectFactory3.nextObject(), arrayOfByte1);
    localPGPObjectFactory2 = new PGPObjectFactory(arrayOfByte3);
    localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(1);
    localInputStream = localPGPPBEEncryptedData.getDataStream("password".toCharArray(), "BC");
    localPGPObjectFactory2 = new PGPObjectFactory(localInputStream);
    checkLiteralData((PGPLiteralData)localPGPObjectFactory2.nextObject(), arrayOfByte1);
  }
  
  private void checkLiteralData(PGPLiteralData paramPGPLiteralData, byte[] paramArrayOfByte)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    if (!paramPGPLiteralData.getFileName().equals("_CONSOLE")) {
      throw new RuntimeException("wrong filename in packet");
    }
    InputStream localInputStream = paramPGPLiteralData.getDataStream();
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    if (!areEqual(localByteArrayOutputStream.toByteArray(), paramArrayOfByte)) {
      fail("wrong plain text in decrypted packet");
    }
  }
  
  public void performTest()
    throws Exception
  {
    PublicKey localPublicKey1 = null;
    PGPPublicKeyRing localPGPPublicKeyRing1 = new PGPPublicKeyRing(this.testPubKey);
    localPublicKey1 = localPGPPublicKeyRing1.getPublicKey().getKey("BC");
    Iterator localIterator1 = localPGPPublicKeyRing1.getPublicKey().getUserIDs();
    String str1 = (String)localIterator1.next();
    localIterator1 = localPGPPublicKeyRing1.getPublicKey().getSignaturesForID(str1);
    PGPSignature localPGPSignature = (PGPSignature)localIterator1.next();
    localPGPSignature.initVerify(localPGPPublicKeyRing1.getPublicKey(), "BC");
    if (!localPGPSignature.verifyCertification(str1, localPGPPublicKeyRing1.getPublicKey())) {
      fail("failed to verify certification");
    }
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream1 = new BCPGOutputStream(localByteArrayOutputStream1);
    localPGPPublicKeyRing1.encode(localBCPGOutputStream1);
    if (!areEqual(localByteArrayOutputStream1.toByteArray(), this.testPubKey)) {
      fail("public key rewrite failed");
    }
    PGPPublicKeyRing localPGPPublicKeyRing2 = new PGPPublicKeyRing(this.testPubKeyV3);
    PublicKey localPublicKey2 = localPGPPublicKeyRing1.getPublicKey().getKey("BC");
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localBCPGOutputStream1 = new BCPGOutputStream(localByteArrayOutputStream1);
    localPGPPublicKeyRing2.encode(localBCPGOutputStream1);
    char[] arrayOfChar1 = "FIXCITY_QA".toCharArray();
    PGPSecretKeyRing localPGPSecretKeyRing = new PGPSecretKeyRing(this.testPrivKeyV3);
    PGPPrivateKey localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey().extractPrivateKey(arrayOfChar1, "BC");
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localBCPGOutputStream1 = new BCPGOutputStream(localByteArrayOutputStream1);
    localPGPSecretKeyRing.encode(localBCPGOutputStream1);
    if (!areEqual(localByteArrayOutputStream1.toByteArray(), this.testPrivKeyV3)) {
      fail("private key V3 rewrite failed");
    }
    localPGPSecretKeyRing = new PGPSecretKeyRing(this.testPrivKey);
    localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey().extractPrivateKey(this.pass, "BC");
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localBCPGOutputStream1 = new BCPGOutputStream(localByteArrayOutputStream1);
    localPGPSecretKeyRing.encode(localBCPGOutputStream1);
    if (!areEqual(localByteArrayOutputStream1.toByteArray(), this.testPrivKey)) {
      fail("private key rewrite failed");
    }
    Cipher localCipher = Cipher.getInstance("RSA", "BC");
    localCipher.init(1, localPublicKey1);
    byte[] arrayOfByte1 = "hello world".getBytes();
    byte[] arrayOfByte2 = localCipher.doFinal(arrayOfByte1);
    localCipher.init(2, localPGPPrivateKey1.getKey());
    arrayOfByte2 = localCipher.doFinal(arrayOfByte2);
    if (!areEqual(arrayOfByte1, arrayOfByte2)) {
      fail("decryption failed.");
    }
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(this.sig1);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
    localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory1.nextObject();
    PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    PGPLiteralData localPGPLiteralData1 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
    InputStream localInputStream1 = localPGPLiteralData1.getInputStream();
    localPGPOnePassSignature.initVerify(localPGPPublicKeyRing1.getPublicKey(localPGPOnePassSignature.getKeyID()), "BC");
    int i;
    while ((i = localInputStream1.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory1.nextObject();
    if (!localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
      fail("Failed signature check");
    }
    localPGPSecretKeyRing = new PGPSecretKeyRing(this.subKey);
    byte[] arrayOfByte3 = { 104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33, 10 };
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(this.enc1);
    PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
    localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey(localPGPPublicKeyEncryptedData.getKeyID()).extractPrivateKey(this.pass, "BC");
    InputStream localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
    localPGPObjectFactory1 = new PGPObjectFactory(localInputStream2);
    localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
    localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPLiteralData localPGPLiteralData2 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    if (!localPGPLiteralData2.getFileName().equals("test.txt")) {
      throw new RuntimeException("wrong filename in packet");
    }
    InputStream localInputStream3 = localPGPLiteralData2.getDataStream();
    while ((i = localInputStream3.read()) >= 0) {
      localByteArrayOutputStream1.write(i);
    }
    if (!areEqual(localByteArrayOutputStream1.toByteArray(), arrayOfByte3)) {
      fail("wrong plain text in decrypted packet");
    }
    byte[] arrayOfByte4 = { 104, 101, 108, 108, 111 };
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, new SecureRandom(), "BC");
    PGPPublicKey localPGPPublicKey1 = localPGPSecretKeyRing.getSecretKey(localPGPPublicKeyEncryptedData.getKeyID()).getPublicKey();
    localPGPEncryptedDataGenerator.addMethod(localPGPPublicKey1);
    OutputStream localOutputStream1 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), arrayOfByte4.length);
    localOutputStream1.write(arrayOfByte4);
    localOutputStream1.close();
    localPGPObjectFactory2 = new PGPObjectFactory(localByteArrayOutputStream2.toByteArray());
    localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
    localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
    localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey(localPGPPublicKeyEncryptedData.getKeyID()).extractPrivateKey(this.pass, "BC");
    localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
    localByteArrayOutputStream1.reset();
    while ((i = localInputStream2.read()) >= 0) {
      localByteArrayOutputStream1.write(i);
    }
    arrayOfByte2 = localByteArrayOutputStream1.toByteArray();
    if (!areEqual(arrayOfByte2, arrayOfByte4)) {
      fail("wrong plain text in generated short text packet");
    }
    localByteArrayOutputStream2 = new ByteArrayOutputStream();
    localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, new SecureRandom(), "BC");
    localPGPPublicKey1 = localPGPSecretKeyRing.getSecretKey(localPGPPublicKeyEncryptedData.getKeyID()).getPublicKey();
    localPGPEncryptedDataGenerator.addMethod(localPGPPublicKey1);
    localOutputStream1 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), arrayOfByte3.length);
    localOutputStream1.write(arrayOfByte3);
    localOutputStream1.close();
    localPGPObjectFactory2 = new PGPObjectFactory(localByteArrayOutputStream2.toByteArray());
    localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
    localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
    localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey(localPGPPublicKeyEncryptedData.getKeyID()).extractPrivateKey(this.pass, "BC");
    localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
    localByteArrayOutputStream1.reset();
    while ((i = localInputStream2.read()) >= 0) {
      localByteArrayOutputStream1.write(i);
    }
    arrayOfByte2 = localByteArrayOutputStream1.toByteArray();
    if (!areEqual(arrayOfByte2, arrayOfByte3)) {
      fail("wrong plain text in generated packet");
    }
    localPGPObjectFactory2 = new PGPObjectFactory(this.subPubKey);
    Object localObject;
    while ((localObject = localPGPObjectFactory1.nextObject()) != null) {}
    char[] arrayOfChar2 = "hello".toCharArray();
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024);
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    PGPSecretKey localPGPSecretKey = new PGPSecretKey(16, 1, localKeyPair.getPublic(), localKeyPair.getPrivate(), new Date(), "fred", 3, arrayOfChar2, null, null, new SecureRandom(), "BC");
    PGPPublicKey localPGPPublicKey2 = localPGPSecretKey.getPublicKey();
    localIterator1 = localPGPPublicKey2.getUserIDs();
    str1 = (String)localIterator1.next();
    localIterator1 = localPGPPublicKey2.getSignaturesForID(str1);
    localPGPSignature = (PGPSignature)localIterator1.next();
    localPGPSignature.initVerify(localPGPPublicKey2, "BC");
    if (!localPGPSignature.verifyCertification(str1, localPGPPublicKey2)) {
      fail("failed to verify certification");
    }
    localPGPPrivateKey1 = localPGPSecretKey.extractPrivateKey(arrayOfChar2, "BC");
    localPGPPublicKey2 = PGPPublicKey.removeCertification(localPGPPublicKey2, str1, localPGPSignature);
    if (localPGPPublicKey2 == null) {
      fail("failed certification removal");
    }
    byte[] arrayOfByte5 = localPGPPublicKey2.getEncoded();
    localPGPPublicKey2 = PGPPublicKey.addCertification(localPGPPublicKey2, str1, localPGPSignature);
    arrayOfByte5 = localPGPPublicKey2.getEncoded();
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(1, 2, "BC");
    localPGPSignatureGenerator.initSign(32, localPGPSecretKey.extractPrivateKey(arrayOfChar2, "BC"));
    localPGPSignature = localPGPSignatureGenerator.generateCertification(localPGPPublicKey2);
    localPGPPublicKey2 = PGPPublicKey.addCertification(localPGPPublicKey2, localPGPSignature);
    arrayOfByte5 = localPGPPublicKey2.getEncoded();
    PGPPublicKeyRing localPGPPublicKeyRing3 = new PGPPublicKeyRing(arrayOfByte5);
    localPGPPublicKey2 = localPGPPublicKeyRing3.getPublicKey();
    Iterator localIterator2 = localPGPPublicKey2.getSignaturesOfType(32);
    localPGPSignature = (PGPSignature)localIterator2.next();
    localPGPSignature.initVerify(localPGPPublicKey2, "BC");
    if (!localPGPSignature.verifyCertification(localPGPPublicKey2)) {
      fail("failed to verify revocation certification");
    }
    PGPKeyPair localPGPKeyPair = new PGPKeyPair(1, localKeyPair.getPublic(), localKeyPair.getPrivate(), new Date(), "BC");
    PGPPublicKey localPGPPublicKey3 = localPGPKeyPair.getPublicKey();
    PGPPrivateKey localPGPPrivateKey2 = localPGPKeyPair.getPrivateKey();
    localPGPPublicKey3.getEncoded();
    mixedTest(localPGPPrivateKey2, localPGPPublicKey3);
    localKeyPair = localKeyPairGenerator.generateKeyPair();
    localPGPSecretKey = new PGPSecretKey(16, 1, localKeyPair.getPublic(), localKeyPair.getPrivate(), new Date(), "fred", 9, arrayOfChar2, null, null, new SecureRandom(), "BC");
    localPGPSecretKey.extractPrivateKey(arrayOfChar2, "BC");
    localPGPSecretKey.encode(new ByteArrayOutputStream());
    String str2 = "newPass";
    localPGPSecretKey = PGPSecretKey.copyWithNewPassword(localPGPSecretKey, arrayOfChar2, str2.toCharArray(), localPGPSecretKey.getKeyEncryptionAlgorithm(), new SecureRandom(), "BC");
    localPGPSecretKey.extractPrivateKey(str2.toCharArray(), "BC");
    localPGPSecretKey.encode(new ByteArrayOutputStream());
    localPGPPublicKey2 = localPGPSecretKey.getPublicKey();
    localPGPPublicKey2.encode(new ByteArrayOutputStream());
    localIterator1 = localPGPPublicKey2.getUserIDs();
    str1 = (String)localIterator1.next();
    localIterator1 = localPGPPublicKey2.getSignaturesForID(str1);
    localPGPSignature = (PGPSignature)localIterator1.next();
    localPGPSignature.initVerify(localPGPPublicKey2, "BC");
    if (!localPGPSignature.verifyCertification(str1, localPGPPublicKey2)) {
      fail("failed to verify certification");
    }
    localPGPPrivateKey1 = localPGPSecretKey.extractPrivateKey(str2.toCharArray(), "BC");
    String str3 = "hello world!";
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(str3.getBytes());
    localPGPSignatureGenerator = new PGPSignatureGenerator(1, 2, "BC");
    localPGPSignatureGenerator.initSign(0, localPGPPrivateKey1);
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    BCPGOutputStream localBCPGOutputStream2 = new BCPGOutputStream(localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream1)));
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream2);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    Date localDate = new Date(System.currentTimeMillis() / 1000L * 1000L);
    OutputStream localOutputStream2 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localBCPGOutputStream2), 'b', "_CONSOLE", str3.getBytes().length, localDate);
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream2.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localOutputStream2.close();
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream2);
    localBCPGOutputStream2.close();
    localPGPObjectFactory1 = new PGPObjectFactory(localByteArrayOutputStream1.toByteArray());
    localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
    localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory1.nextObject();
    localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    localPGPLiteralData1 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
    if (!localPGPLiteralData1.getModificationTime().equals(localDate)) {
      fail("Modification time not preserved: " + localPGPLiteralData1.getModificationTime() + " " + localDate);
    }
    localInputStream1 = localPGPLiteralData1.getInputStream();
    localPGPOnePassSignature.initVerify(localPGPSecretKey.getPublicKey(), "BC");
    while ((i = localInputStream1.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory1.nextObject();
    if (!localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
      fail("Failed generated signature check");
    }
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localByteArrayInputStream = new ByteArrayInputStream(str3.getBytes());
    PGPV3SignatureGenerator localPGPV3SignatureGenerator = new PGPV3SignatureGenerator(1, 2, "BC");
    localPGPSignatureGenerator.initSign(0, localPGPPrivateKey1);
    localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    localBCPGOutputStream2 = new BCPGOutputStream(localPGPCompressedDataGenerator.open(localByteArrayOutputStream1));
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream2);
    localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    localOutputStream2 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localBCPGOutputStream2), 'b', "_CONSOLE", str3.getBytes().length, localDate);
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream2.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream2);
    localOutputStream2.close();
    localBCPGOutputStream2.close();
    localPGPObjectFactory1 = new PGPObjectFactory(localByteArrayOutputStream1.toByteArray());
    localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
    localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory1.nextObject();
    localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    localPGPLiteralData1 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
    if (!localPGPLiteralData1.getModificationTime().equals(localDate)) {
      fail("Modification time not preserved");
    }
    localInputStream1 = localPGPLiteralData1.getInputStream();
    localPGPOnePassSignature.initVerify(localPGPSecretKey.getPublicKey(), "BC");
    while ((i = localInputStream1.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory1.nextObject();
    if (!localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
      fail("Failed v3 generated signature check");
    }
    localPGPSecretKeyRing = new PGPSecretKeyRing(this.pgp8Key);
    localPGPSecretKey = localPGPSecretKeyRing.getSecretKey();
    localPGPPrivateKey1 = localPGPSecretKey.extractPrivateKey(this.pgp8Pass, "BC");
    testExpiry(this.expiry60and30daysSig13Key, 60, 30);
    fingerPrintTest();
  }
  
  private void testExpiry(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws Exception
  {
    PGPPublicKeyRing localPGPPublicKeyRing = new PGPPublicKeyRing(paramArrayOfByte);
    PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey();
    if (localPGPPublicKey.getValidDays() != paramInt1) {
      fail("mismatch on master valid days.");
    }
    Iterator localIterator = localPGPPublicKeyRing.getPublicKeys();
    localIterator.next();
    localPGPPublicKey = (PGPPublicKey)localIterator.next();
    if (localPGPPublicKey.getValidDays() != paramInt2) {
      fail("mismatch on subkey valid days.");
    }
  }
  
  public String getName()
  {
    return "PGPRSATest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPRSATest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPRSATest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */