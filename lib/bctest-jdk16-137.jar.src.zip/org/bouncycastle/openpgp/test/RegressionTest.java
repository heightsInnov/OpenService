package org.bouncycastle.openpgp.test;

import java.io.PrintStream;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class RegressionTest
{
  public static Test[] tests = { new PGPKeyRingTest(), new PGPRSATest(), new PGPDSATest(), new PGPDSAElGamalTest(), new PGPPBETest(), new PGPMarkerTest(), new PGPPacketTest(), new PGPArmoredTest(), new PGPSignatureTest(), new PGPClearSignedSignatureTest(), new PGPCompressionTest() };
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    for (int i = 0; i != tests.length; i++)
    {
      TestResult localTestResult = tests[i].perform();
      System.out.println(localTestResult);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\RegressionTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */