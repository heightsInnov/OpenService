package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SignatureException;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredInputStream;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class PGPClearSignedSignatureTest
  extends SimpleTest
{
  byte[] publicKey = Base64.decode("mQELBEQh2+wBCAD26kte0hO6flr7Y2aetpPYutHY4qsmDPy+GwmmqVeCDkX+r1g7DuFbMhVeu0NkKDnVl7GsJ9VarYsFYyqu0NzLa9XS2qlTIkmJV+2/xKa1tzjn18fT/cnAWL88ZLCOWUr241aPVhLuIc6vpHnySpEMkCh4rvMaimnTrKwO42kgeDGd5cXfs4J4ovRcTbc4hmU2BRVsRjiYMZWWx0kkyL2zDVyaJSs4yVX7Jm4/LSR1uC/wDT0IJJuZT/gQPCMJNMEsVCziRgYkAxQK3OWojPSuv4rXpyd4Gvo6IbvyTgIskfpSkCnQtORNLIudQSuK7pW+LkL62N+ohuKdMvdxauOnAAYptBNnZ2dnZ2dnZyA8Z2dnQGdnZ2c+iQE2BBMBAgAgBQJEIdvsAhsDBgsJCAcDAgQVAggDBBYCAwECHgECF4AACgkQ4M/Ier3f9xagdAf/fbKWBjLQM8xR7JkRP4ri8YKOQPhK+VrddGUD59/wzVnvaGyl9MZE7TXFUeniQq5iXKnm22EQbYchv2Jcxyt2H9yptpzyh4tP6tEHl1C887p2J4qe7F2ATua9CzVGwXQSUbKtj2fgUZP5SsNp25guhPiZdtkf2sHMeiotmykFErzqGMrvOAUThrO63GiYsRk4hF6rcQ01d+EUVpY/sBcCxgNyOiB7a84sDtrxnX5BTEZDTEj8LvuEyEV3TMUuAjx17Eyd+9JtKzwV4v3hlTaWOvGro9nPS7YaPuG+RtufzXCUJPbPfTjTvtGOqvEzoztls8tuWA0OGHba9XfX9rfgorACAAM=");
  byte[] secretKey = Base64.decode("lQOWBEQh2+wBCAD26kte0hO6flr7Y2aetpPYutHY4qsmDPy+GwmmqVeCDkX+r1g7DuFbMhVeu0NkKDnVl7GsJ9VarYsFYyqu0NzLa9XS2qlTIkmJV+2/xKa1tzjn18fT/cnAWL88ZLCOWUr241aPVhLuIc6vpHnySpEMkCh4rvMaimnTrKwO42kgeDGd5cXfs4J4ovRcTbc4hmU2BRVsRjiYMZWWx0kkyL2zDVyaJSs4yVX7Jm4/LSR1uC/wDT0IJJuZT/gQPCMJNMEsVCziRgYkAxQK3OWojPSuv4rXpyd4Gvo6IbvyTgIskfpSkCnQtORNLIudQSuK7pW+LkL62N+ohuKdMvdxauOnAAYpAAf+JCJJeAXEcrTVHotsrRR5idzmg6RK/1MSQUijwPmP7ZGy1BmpAmYUfbxnB56GvXyFV3Pbj9PgyJZGS7cY+l0BF4ZqN9USiQtC9OEpCVT5LVMCFXC/lahC/O3EkjQy0CYK+GwyIXa+Flxcr460L/Hvw2ZEXJZ6/aPdiR+DU1l5h99Zw8V1Y625MpfwN6ufJfqE0HLoqIjlqCfi1iwcKAK2oVx2SwnT1W0NwUUXjagGhD2sVzJVpLqhlwmS0A+RE9Niqrf80/zwE7QNDF2DtHxmMHJ3RY/pfu5u1rrFg9YElmS60mzOe31CaD8Li0k5YCJBPnmvM9mN3/DWWprSZZKtmQQA96C2/VJF5EWm+/Yxi5J06dG6Bkz311Ui4p2zHm9/4GvTPCIKNpGx9Zn47YFD3tIg3fIBVPOEktG38pEPx++dSSFF9Ep5UgmYFNOKNUVq3yGpatBtCQBXb1LQLAMBJCJ5TQmk68hMOEaqjMHSOa18cS63INgA6okb/ueAKIHxYQcEAP9DaXu5n9dZQw7pshbNNu/T5IP0/D/wqM+W5r+j4P1N7PgiAnfKA4JjKrUgl8PGnI2qM/Qu+g3qK++cF1ESHasnJPjvNvY+cfti06xnJVtCB/EBOA2UZkAr//Tqa76xEwYAWRBnO2Y+KIVOT+nMiBFkjPTrNAD6fSr1O4aOueBhBAC6aA35IfjC2h5MYk8+Z+S4io2omRxUZ/dUuS+kITvWph2e4DT28Xpycpl2n1Pa5dCDO1lRqe/5JnaDYDKqxfmF5tTG8GR4d4nVawwLlifXH5Ll7t5NcukGNMCsGuQAHMy0QHuAaOvMdLs5kGHn8VxfKEVKhVrXsvJSwyXXSBtMtUcRtBNnZ2dnZ2dnZyA8Z2dnQGdnZ2c+iQE2BBMBAgAgBQJEIdvsAhsDBgsJCAcDAgQVAggDBBYCAwECHgECF4AACgkQ4M/Ier3f9xagdAf/fbKWBjLQM8xR7JkRP4ri8YKOQPhK+VrddGUD59/wzVnvaGyl9MZE7TXFUeniQq5iXKnm22EQbYchv2Jcxyt2H9yptpzyh4tP6tEHl1C887p2J4qe7F2ATua9CzVGwXQSUbKtj2fgUZP5SsNp25guhPiZdtkf2sHMeiotmykFErzqGMrvOAUThrO63GiYsRk4hF6rcQ01d+EUVpY/sBcCxgNyOiB7a84sDtrxnX5BTEZDTEj8LvuEyEV3TMUuAjx17Eyd+9JtKzwV4v3hlTaWOvGro9nPS7YaPuG+RtufzXCUJPbPfTjTvtGOqvEzoztls8tuWA0OGHba9XfX9rfgorACAAA=");
  String crOnlyMessage = "\r hello world!\r\r- dash\r";
  String nlOnlyMessage = "\n hello world!\n\n- dash\n";
  String crNlMessage = "\r\n hello world!\r\n\r\n- dash\r\n";
  String crOnlySignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\rHash: SHA256\r\r\r hello world!\r\r- - dash\r-----BEGIN PGP SIGNATURE-----\rVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\riQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\rWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\rFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\rhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\rdMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r=84Nd\r-----END PGP SIGNATURE-----\r";
  String nlOnlySignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\nHash: SHA256\n\n\n hello world!\n\n- - dash\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\n\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\n=84Nd\n-----END PGP SIGNATURE-----\n";
  String crNlSignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA256\r\n\r\n\r\n hello world!\r\n\r\n- - dash\r\n-----BEGIN PGP SIGNATURE-----\r\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\n\r\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\r\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\r\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\r\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\r\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r\n=84Nd\r-----END PGP SIGNATURE-----\r\n";
  String crNlSignedMessageTrailingWhiteSpace = "-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA256\r\n\r\n\r\n hello world! \t\r\n\r\n- - dash\r\n-----BEGIN PGP SIGNATURE-----\r\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\n\r\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\r\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\r\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\r\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\r\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r\n=84Nd\r-----END PGP SIGNATURE-----\r\n";
  
  public String getName()
  {
    return "PGPClearSignedSignature";
  }
  
  private void messageTest(String paramString1, String paramString2)
    throws Exception
  {
    ArmoredInputStream localArmoredInputStream = new ArmoredInputStream(new ByteArrayInputStream(paramString1.getBytes()));
    String[] arrayOfString = localArmoredInputStream.getArmorHeaders();
    if ((arrayOfString == null) || (arrayOfString.length != 1)) {
      fail("wrong number of headers found");
    }
    if (!"Hash: SHA256".equals(arrayOfString[0])) {
      fail("header value wrong: " + arrayOfString[0]);
    }
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    int i;
    while (((i = localArmoredInputStream.read()) >= 0) && (localArmoredInputStream.isClearText())) {
      localByteArrayOutputStream1.write((byte)i);
    }
    PGPPublicKeyRingCollection localPGPPublicKeyRingCollection = new PGPPublicKeyRingCollection(this.publicKey);
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localArmoredInputStream);
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    PGPSignature localPGPSignature = localPGPSignatureList.get(0);
    localPGPSignature.initVerify(localPGPPublicKeyRingCollection.getPublicKey(localPGPSignature.getKeyID()), "BC");
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream1.toByteArray());
    int j = readInputLine(localByteArrayOutputStream2, localByteArrayInputStream);
    processLine(localPGPSignature, localByteArrayOutputStream2.toByteArray());
    if (j != -1) {
      do
      {
        j = readInputLine(localByteArrayOutputStream2, j, localByteArrayInputStream);
        localPGPSignature.update((byte)13);
        localPGPSignature.update((byte)10);
        processLine(localPGPSignature, localByteArrayOutputStream2.toByteArray());
      } while (j != -1);
    }
    if (!localPGPSignature.verify()) {
      fail("signature failed to verify in " + paramString2);
    }
  }
  
  private PGPSecretKey readSecretKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection = new PGPSecretKeyRingCollection(paramInputStream);
    Object localObject = null;
    Iterator localIterator1 = localPGPSecretKeyRingCollection.getKeyRings();
    while ((localObject == null) && (localIterator1.hasNext()))
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPSecretKeyRing.getSecretKeys();
      while ((localObject == null) && (localIterator2.hasNext()))
      {
        PGPSecretKey localPGPSecretKey = (PGPSecretKey)localIterator2.next();
        if (localPGPSecretKey.isSigningKey()) {
          localObject = localPGPSecretKey;
        }
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("Can't find signing key in key ring.");
    }
    return (PGPSecretKey)localObject;
  }
  
  private void generateTest(String paramString1, String paramString2)
    throws Exception
  {
    PGPSecretKey localPGPSecretKey = readSecretKey(new ByteArrayInputStream(this.secretKey));
    PGPPrivateKey localPGPPrivateKey = localPGPSecretKey.extractPrivateKey("".toCharArray(), "BC");
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(localPGPSecretKey.getPublicKey().getAlgorithm(), 8, "BC");
    PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator = new PGPSignatureSubpacketGenerator();
    localPGPSignatureGenerator.initSign(1, localPGPPrivateKey);
    Iterator localIterator = localPGPSecretKey.getPublicKey().getUserIDs();
    if (localIterator.hasNext())
    {
      localPGPSignatureSubpacketGenerator.setSignerUserID(false, (String)localIterator.next());
      localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketGenerator.generate());
    }
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream1);
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes());
    localArmoredOutputStream.beginClearText(8);
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    int i = readInputLine(localByteArrayOutputStream2, localByteArrayInputStream);
    processLine(localArmoredOutputStream, localPGPSignatureGenerator, localByteArrayOutputStream2.toByteArray());
    if (i != -1) {
      do
      {
        i = readInputLine(localByteArrayOutputStream2, i, localByteArrayInputStream);
        localPGPSignatureGenerator.update((byte)13);
        localPGPSignatureGenerator.update((byte)10);
        processLine(localArmoredOutputStream, localPGPSignatureGenerator, localByteArrayOutputStream2.toByteArray());
      } while (i != -1);
    }
    localArmoredOutputStream.endClearText();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localArmoredOutputStream);
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
    localArmoredOutputStream.close();
    messageTest(new String(localByteArrayOutputStream1.toByteArray()), paramString2);
  }
  
  private static int readInputLine(ByteArrayOutputStream paramByteArrayOutputStream, InputStream paramInputStream)
    throws IOException
  {
    paramByteArrayOutputStream.reset();
    int i = -1;
    int j;
    while ((j = paramInputStream.read()) >= 0)
    {
      paramByteArrayOutputStream.write(j);
      if ((j == 13) || (j == 10)) {
        i = readPassedEOL(paramByteArrayOutputStream, j, paramInputStream);
      }
    }
    return i;
  }
  
  private static int readInputLine(ByteArrayOutputStream paramByteArrayOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    paramByteArrayOutputStream.reset();
    int i = paramInt;
    do
    {
      paramByteArrayOutputStream.write(i);
      if ((i == 13) || (i == 10))
      {
        paramInt = readPassedEOL(paramByteArrayOutputStream, i, paramInputStream);
        break;
      }
    } while ((i = paramInputStream.read()) >= 0);
    return paramInt;
  }
  
  private static int readPassedEOL(ByteArrayOutputStream paramByteArrayOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    int i = paramInputStream.read();
    if ((paramInt == 13) && (i == 10))
    {
      paramByteArrayOutputStream.write(i);
      i = paramInputStream.read();
    }
    return i;
  }
  
  private static void processLine(PGPSignature paramPGPSignature, byte[] paramArrayOfByte)
    throws SignatureException, IOException
  {
    int i = getLengthWithoutWhiteSpace(paramArrayOfByte);
    if (i > 0) {
      paramPGPSignature.update(paramArrayOfByte, 0, i);
    }
  }
  
  private static void processLine(OutputStream paramOutputStream, PGPSignatureGenerator paramPGPSignatureGenerator, byte[] paramArrayOfByte)
    throws SignatureException, IOException
  {
    int i = getLengthWithoutWhiteSpace(paramArrayOfByte);
    if (i > 0) {
      paramPGPSignatureGenerator.update(paramArrayOfByte, 0, i);
    }
    paramOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  private static int getLengthWithoutWhiteSpace(byte[] paramArrayOfByte)
  {
    for (int i = paramArrayOfByte.length - 1; (i >= 0) && (isWhiteSpace(paramArrayOfByte[i])); i--) {}
    return i + 1;
  }
  
  private static boolean isWhiteSpace(byte paramByte)
  {
    return (paramByte == 13) || (paramByte == 10) || (paramByte == 9) || (paramByte == 32);
  }
  
  public void performTest()
    throws Exception
  {
    messageTest(this.crOnlySignedMessage, "\\r");
    messageTest(this.nlOnlySignedMessage, "\\n");
    messageTest(this.crNlSignedMessage, "\\r\\n");
    messageTest(this.crNlSignedMessageTrailingWhiteSpace, "\\r\\n");
    generateTest(this.nlOnlyMessage, "\\r");
    generateTest(this.crOnlyMessage, "\\n");
    generateTest(this.crNlMessage, "\\r\\n");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PGPClearSignedSignatureTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPClearSignedSignatureTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */