package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.DHParameterSpec;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPDSAElGamalTest
  extends SimpleTest
{
  byte[] testPubKeyRing = Base64.decode("mQGiBEAR8jYRBADNifuSopd20JOQ5x30ljIaY0M6927+vo09NeNxS3KqItbanz9o5e2aqdT0W1xgdHYZmdElOHTTsugZxdXTEhghyxoo3KhVcNnTABQyrrvXqouvmP2fEDEw0Vpyk+90BpyY9YlgeX/dEA8OfooRLCJde/iDTl7r9FT+mts8g3azjwCgx+pOLD9LPBF5E4FhUOdXISJ0f4EEAKXSOi9nZzajpdhe8W2ZL9gcBpzZi6AcrRZBHOEMqd69gtUxA4eD8xycUQ42yH89imEcwLz8XdJ98uHUxGJiqp6hq4oakmw8GQfiL7yQIFgaM0dOAI9Afe3m84cEYZsoAFYpB4/s9pVMpPRHNsVspU0qd3NHnSZ0QXs8L8DXGO1uBACjDUj+8GsfDCIP2QF3JC+nPUNa0Y5twKPKl+T8hX/0FBD7fnNeC6c9j5Ir/Fp/QtdaDAOoBKiyNLh1JaB1NY6US5zcqFks2seZPjXEiE6OIDXYra494mjNKGUobA4hqT2peKWXt/uBcuL1mjKOy8QfJxgEd0MOcGJO+1PFFZWGzLQ3RXJpYyBILiBFY2hpZG5hICh0ZXN0IGtleSBvbmx5KSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPohZBBMRAgAZBQJAEfI2BAsHAwIDFQIDAxYCAQIeAQIXgAAKCRAOtk6iUOgnkDdnAKC/CfLWikSBdbngY6OK5UN3+o7q1ACcDRqjT3yjBU3WmRUNlxBg3tSuljmwAgAAuQENBEAR8jgQBAC2kr57iuOaV7Ga1xcU14MNbKcA0PVembRCjcVjei/3yVfT/fuCVtGHOmYLEBqHbn5aaJ0P/6vMbLCHKuN61NZlts+LEctfwoya43RtcubqMc7eKw4k0JnnoYgBocLXOtloCb7jfubOsnfORvrUkK0+Ne6anRhFBYfaBmGU75cQgwADBQP/XxR2qGHiwn+0YiMioRDRiIAxp6UiC/JQIri2AKSqAi0zeAMdrRsBN7kyzYVVpWwN5u13gPdQ2HnJ7d4wLWAuizUdKIQxBG8VoCxkbipnwh2RR4xCXFDhJrJFQUm+4nKx9JvAmZTBIlI5Wsi5qxst/9p5MgP3flXsNi1tRbTmRhqIRgQYEQIABgUCQBHyOAAKCRAOtk6iUOgnkBStAJoCZBVM61B1LG2xip294MZecMtCwQCbBbskJVCXP0/Szm05GB+WN+MOCT2wAgAA");
  byte[] testPrivKeyRing = Base64.decode("lQHhBEAR8jYRBADNifuSopd20JOQ5x30ljIaY0M6927+vo09NeNxS3KqItbanz9o5e2aqdT0W1xgdHYZmdElOHTTsugZxdXTEhghyxoo3KhVcNnTABQyrrvXqouvmP2fEDEw0Vpyk+90BpyY9YlgeX/dEA8OfooRLCJde/iDTl7r9FT+mts8g3azjwCgx+pOLD9LPBF5E4FhUOdXISJ0f4EEAKXSOi9nZzajpdhe8W2ZL9gcBpzZi6AcrRZBHOEMqd69gtUxA4eD8xycUQ42yH89imEcwLz8XdJ98uHUxGJiqp6hq4oakmw8GQfiL7yQIFgaM0dOAI9Afe3m84cEYZsoAFYpB4/s9pVMpPRHNsVspU0qd3NHnSZ0QXs8L8DXGO1uBACjDUj+8GsfDCIP2QF3JC+nPUNa0Y5twKPKl+T8hX/0FBD7fnNeC6c9j5Ir/Fp/QtdaDAOoBKiyNLh1JaB1NY6US5zcqFks2seZPjXEiE6OIDXYra494mjNKGUobA4hqT2peKWXt/uBcuL1mjKOy8QfJxgEd0MOcGJO+1PFFZWGzP4DAwLeUcsVxIC2s2Bb9ab2XD860TQ2BI2rMD/r7/psx9WQ+Vz/aFAT3rXkEJ97nFeqEACgKmUCAEk9939EwLQ3RXJpYyBILiBFY2hpZG5hICh0ZXN0IGtleSBvbmx5KSA8ZXJpY0Bib3VuY3ljYXN0bGUub3JnPohZBBMRAgAZBQJAEfI2BAsHAwIDFQIDAxYCAQIeAQIXgAAKCRAOtk6iUOgnkDdnAJ9Ala3OcwEV1DbK906CheYWo4zIQwCfUqUOLMp/zj6QAk02bbJAhV1rsAewAgAAnQFYBEAR8jgQBAC2kr57iuOaV7Ga1xcU14MNbKcA0PVembRCjcVjei/3yVfT/fuCVtGHOmYLEBqHbn5aaJ0P/6vMbLCHKuN61NZlts+LEctfwoya43RtcubqMc7eKw4k0JnnoYgBocLXOtloCb7jfubOsnfORvrUkK0+Ne6anRhFBYfaBmGU75cQgwADBQP/XxR2qGHiwn+0YiMioRDRiIAxp6UiC/JQIri2AKSqAi0zeAMdrRsBN7kyzYVVpWwN5u13gPdQ2HnJ7d4wLWAuizUdKIQxBG8VoCxkbipnwh2RR4xCXFDhJrJFQUm+4nKx9JvAmZTBIlI5Wsi5qxst/9p5MgP3flXsNi1tRbTmRhr+AwMC3lHLFcSAtrNg/EiWFLAnKNXH27zjwuhje8u2r+9iMTYsGjbRxaxRY0GKRhttCwqe2BC0lHhzifdlEcc9yjIjuKfepG2fnnSIRgQYEQIABgUCQBHyOAAKCRAOtk6iUOgnkBStAJ9HFejVtVJ/A9LM/mDPe0ExhEXt/QCgm/KM7hJ/JrfnLQl7IaZsdg1F6vCwAgAA");
  byte[] encMessage = Base64.decode("hQEOAynbo4lhNjcHEAP/dgCkMtPB6mIgjFvNiotjaoh4sAXf4vFNkSeehQ2cr+IMt9CgIYodJI3FoJXxOuTcwesqTp5hRzgUBJS0adLDJwcNubFMy0M2tp5oKTWpXulIiqyO6f5jI/oEDHPzFoYgBmR4x72l/YpMy8UoYGtNxNvR7LVOfqJvuDY/71KMtPQEAIadOWpf1P5Td+61Zqn2VH2UV7H8eI6hGa6Lsy4sb9iZNE7fc+spGJlgkiOt8TrQoq3iOK9UN9nHZLiCSIEGCzsEn3uNuorD++Qs065ij+Oy36TKeuJ+38CfT7u47dEshHCPqWhBKEYrxZWHUJU/izw2Q1Yxd2XRxN+nafTLX1fQ0lABQUASa18s0BkkEERIdcKQXVLEswWcGqWNv1ZghC7xO2VDBX4HrPjpdrjL63p2UHzJ7/4gPWGGtnqq1Xita/1mrImn7pzLThDWiT55vjw6Hw==");
  byte[] signedAndEncMessage = Base64.decode("hQEOAynbo4lhNjcHEAP+K20MVhzdX57hf/cU8TH0prP0VePr9mmeBedzqqMnfp2p8Zb68zmcMlI/WiL5XMNLYRmCgEcXyWbKdP/XV9m9LDBe1CMAGrkCeGByje69IQQ5LS9vDPyEMF4iAAv/EqACjqHkizdY/a/FRx/t2ioXYdEC2jA6kS9CMcpsNz16DE8EAIk3uKn4bGo/+15TXkyFYzW5Cf71SfRoHNmU2zAI93zhjN+TB7mGJwWXzsMkIO6FkMU5TCSrwZS3DBWCIaJ6SYoaawE/C/2j9D7bX1Jv8kum4cq+eZM7z6JYs6xend+WAwittpUxbEiyC2AJb3fBSXPAbLqWd6J6xbZZ7GDKr2Ca0pwBxwGhbMDyi2zpHLzw95H7Ah2wMcGU6kMLB+hzBSZ6mSTGFehqFQE32BnAj7MtnbghiefogacJ891jj8Y2ggJeKDuRz8j2iICaTOy+Y2rXnnJwfYzmBMWcd2h1C5+UeBJ9CrrLniCCI8s5u8z36Rno3sfhBnXdRmWSxExXtocbg1HtdyiThf6TK3W29Yy/T6x45Ws5zOasaJdsFKM=");
  char[] pass = { 'h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd' };
  
  public void performTest()
    throws Exception
  {
    try
    {
      PGPPublicKey localPGPPublicKey1 = null;
      PGPUtil.setDefaultProvider("BC");
      PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(this.testPubKeyRing);
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localPGPObjectFactory1.nextObject();
      localPGPPublicKey1 = localPGPPublicKeyRing.getPublicKey();
      if (localPGPPublicKey1.getBitStrength() != 1024) {
        fail("failed - key strength reported incorrectly.");
      }
      PGPSecretKeyRing localPGPSecretKeyRing = new PGPSecretKeyRing(this.testPrivKeyRing);
      PGPPrivateKey localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey().extractPrivateKey(this.pass, "BC");
      String str = "hello world!";
      ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(str.getBytes());
      PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(17, 2, "BC");
      localPGPSignatureGenerator.initSign(0, localPGPPrivateKey1);
      PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream1)));
      localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream);
      PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
      Date localDate = new Date(System.currentTimeMillis() / 1000L * 1000L);
      OutputStream localOutputStream1 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localBCPGOutputStream), 'b', "_CONSOLE", str.getBytes().length, localDate);
      int i;
      while ((i = localByteArrayInputStream.read()) >= 0)
      {
        localOutputStream1.write(i);
        localPGPSignatureGenerator.update((byte)i);
      }
      localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
      localPGPLiteralDataGenerator.close();
      localPGPCompressedDataGenerator.close();
      localPGPObjectFactory1 = new PGPObjectFactory(localByteArrayOutputStream1.toByteArray());
      PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
      localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
      PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory1.nextObject();
      PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
      PGPLiteralData localPGPLiteralData1 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
      if (!localPGPLiteralData1.getModificationTime().equals(localDate)) {
        fail("Modification time not preserved");
      }
      InputStream localInputStream1 = localPGPLiteralData1.getInputStream();
      localPGPOnePassSignature.initVerify(localPGPPublicKey1, "BC");
      while ((i = localInputStream1.read()) >= 0) {
        localPGPOnePassSignature.update((byte)i);
      }
      PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory1.nextObject();
      if (!localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
        fail("Failed generated signature check");
      }
      long l = 0L;
      PublicKey localPublicKey = null;
      Iterator localIterator = localPGPPublicKeyRing.getPublicKeys();
      while (localIterator.hasNext())
      {
        localObject = (PGPPublicKey)localIterator.next();
        if ((((PGPPublicKey)localObject).getAlgorithm() == 16) || (((PGPPublicKey)localObject).getAlgorithm() == 20))
        {
          localPublicKey = ((PGPPublicKey)localObject).getKey("BC");
          l = ((PGPPublicKey)localObject).getKeyID();
          if (((PGPPublicKey)localObject).getBitStrength() != 1024) {
            fail("failed - key strength reported incorrectly.");
          }
        }
      }
      Object localObject = Cipher.getInstance("ElGamal/None/PKCS1Padding", "BC");
      ((Cipher)localObject).init(1, localPublicKey);
      byte[] arrayOfByte1 = "hello world".getBytes();
      byte[] arrayOfByte2 = ((Cipher)localObject).doFinal(arrayOfByte1);
      localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey(l).extractPrivateKey(this.pass, "BC");
      ((Cipher)localObject).init(2, localPGPPrivateKey1.getKey());
      arrayOfByte2 = ((Cipher)localObject).doFinal(arrayOfByte2);
      if (!areEqual(arrayOfByte1, arrayOfByte2)) {
        fail("decryption failed.");
      }
      byte[] arrayOfByte3 = { 104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33, 10 };
      PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(this.encMessage);
      PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
      PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
      InputStream localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
      localPGPObjectFactory1 = new PGPObjectFactory(localInputStream2);
      localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
      localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
      PGPLiteralData localPGPLiteralData2 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
      localByteArrayOutputStream1 = new ByteArrayOutputStream();
      if (!localPGPLiteralData2.getFileName().equals("test.txt")) {
        throw new RuntimeException("wrong filename in packet");
      }
      InputStream localInputStream3 = localPGPLiteralData2.getDataStream();
      while ((i = localInputStream3.read()) >= 0) {
        localByteArrayOutputStream1.write(i);
      }
      if (!areEqual(localByteArrayOutputStream1.toByteArray(), arrayOfByte3)) {
        fail("wrong plain text in decrypted packet");
      }
      localPGPObjectFactory2 = new PGPObjectFactory(this.signedAndEncMessage);
      localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
      localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
      localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
      localPGPObjectFactory1 = new PGPObjectFactory(localInputStream2);
      localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory1.nextObject();
      localPGPObjectFactory1 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
      localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory1.nextObject();
      localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
      localPGPLiteralData2 = (PGPLiteralData)localPGPObjectFactory1.nextObject();
      localByteArrayOutputStream1 = new ByteArrayOutputStream();
      if (!localPGPLiteralData2.getFileName().equals("test.txt")) {
        throw new RuntimeException("wrong filename in packet");
      }
      localInputStream3 = localPGPLiteralData2.getDataStream();
      localPGPOnePassSignature.initVerify(localPGPPublicKeyRing.getPublicKey(), "BC");
      while ((i = localInputStream3.read()) >= 0)
      {
        localPGPOnePassSignature.update((byte)i);
        localByteArrayOutputStream1.write(i);
      }
      localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory1.nextObject();
      if (!localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
        fail("Failed signature check");
      }
      if (!areEqual(localByteArrayOutputStream1.toByteArray(), arrayOfByte3)) {
        fail("wrong plain text in decrypted packet");
      }
      ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
      PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(2, new SecureRandom(), "BC");
      PGPPublicKey localPGPPublicKey2 = localPGPSecretKeyRing.getSecretKey(l).getPublicKey();
      localPGPEncryptedDataGenerator.addMethod(localPGPPublicKey2);
      OutputStream localOutputStream2 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), localByteArrayOutputStream1.toByteArray().length);
      localOutputStream2.write(arrayOfByte3);
      localOutputStream2.close();
      localPGPObjectFactory2 = new PGPObjectFactory(localByteArrayOutputStream2.toByteArray());
      localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
      localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
      localPGPPrivateKey1 = localPGPSecretKeyRing.getSecretKey(l).extractPrivateKey(this.pass, "BC");
      localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
      localByteArrayOutputStream1.reset();
      while ((i = localInputStream2.read()) >= 0) {
        localByteArrayOutputStream1.write(i);
      }
      arrayOfByte2 = localByteArrayOutputStream1.toByteArray();
      if (!areEqual(arrayOfByte2, arrayOfByte3)) {
        fail("wrong plain text in generated packet");
      }
      BigInteger localBigInteger1 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
      BigInteger localBigInteger2 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
      KeyPairGenerator localKeyPairGenerator1 = KeyPairGenerator.getInstance("ElGamal", "BC");
      ElGamalParameterSpec localElGamalParameterSpec = new ElGamalParameterSpec(localBigInteger2, localBigInteger1);
      localKeyPairGenerator1.initialize(localElGamalParameterSpec);
      KeyPair localKeyPair = localKeyPairGenerator1.generateKeyPair();
      PGPKeyPair localPGPKeyPair1 = new PGPKeyPair(20, localKeyPair.getPublic(), localKeyPair.getPrivate(), new Date(), "BC");
      PGPPublicKey localPGPPublicKey3 = localPGPKeyPair1.getPublicKey();
      PGPPrivateKey localPGPPrivateKey2 = localPGPKeyPair1.getPrivateKey();
      SecureRandom localSecureRandom = new SecureRandom();
      for (int j = 257; j < 264; j++)
      {
        AlgorithmParameterGenerator localAlgorithmParameterGenerator = AlgorithmParameterGenerator.getInstance("ElGamal", "BC");
        localAlgorithmParameterGenerator.init(j, new SecureRandom());
        AlgorithmParameters localAlgorithmParameters = localAlgorithmParameterGenerator.generateParameters();
        DHParameterSpec localDHParameterSpec = (DHParameterSpec)localAlgorithmParameters.getParameterSpec(DHParameterSpec.class);
        KeyPairGenerator localKeyPairGenerator2 = KeyPairGenerator.getInstance("ElGamal", "BC");
        localKeyPairGenerator2.initialize(localDHParameterSpec);
        localKeyPair = localKeyPairGenerator2.generateKeyPair();
        PGPKeyPair localPGPKeyPair2 = new PGPKeyPair(20, localKeyPair, new Date(), "BC");
        localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, localSecureRandom, "BC");
        localPGPPublicKey2 = localPGPKeyPair2.getPublicKey();
        localPGPEncryptedDataGenerator.addMethod(localPGPPublicKey2);
        localByteArrayOutputStream2 = new ByteArrayOutputStream();
        localOutputStream2 = localPGPEncryptedDataGenerator.open(localByteArrayOutputStream2, arrayOfByte3.length);
        localOutputStream2.write(arrayOfByte3);
        localOutputStream2.close();
        localPGPObjectFactory2 = new PGPObjectFactory(localByteArrayOutputStream2.toByteArray());
        localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory2.nextObject();
        localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localPGPEncryptedDataList.get(0);
        localPGPPrivateKey1 = localPGPKeyPair2.getPrivateKey();
        localInputStream2 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey1, "BC");
        ByteArrayOutputStream localByteArrayOutputStream3 = new ByteArrayOutputStream();
        int k;
        while ((k = localInputStream2.read()) >= 0) {
          localByteArrayOutputStream3.write(k);
        }
        byte[] arrayOfByte4 = localByteArrayOutputStream3.toByteArray();
        if (!areEqual(arrayOfByte3, arrayOfByte4)) {
          fail("decrypted message incorrect");
        }
      }
    }
    catch (PGPException localPGPException)
    {
      fail("exception: " + localPGPException.getMessage(), localPGPException.getUnderlyingException());
    }
  }
  
  public String getName()
  {
    return "PGPDSAElGamalTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPDSAElGamalTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPDSAElGamalTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */