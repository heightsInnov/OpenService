package org.bouncycastle.openpgp.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.util.Date;
import java.util.Random;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPPacketTest
  extends SimpleTest
{
  private static int MAX = 32000;
  
  private void readBackTest(PGPLiteralDataGenerator paramPGPLiteralDataGenerator)
    throws IOException
  {
    Random localRandom = new Random();
    byte[] arrayOfByte = new byte[MAX];
    localRandom.nextBytes(arrayOfByte);
    for (int i = 1; i <= 200; i++) {
      bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, i);
    }
    bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, 8382);
    bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, 8383);
    bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, 8384);
    bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, 8385);
    for (i = 200; i < MAX; i += 100) {
      bufferTest(paramPGPLiteralDataGenerator, arrayOfByte, i);
    }
  }
  
  private void bufferTest(PGPLiteralDataGenerator paramPGPLiteralDataGenerator, byte[] paramArrayOfByte, int paramInt)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = paramPGPLiteralDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), 'b', "_CONSOLE", paramInt, new Date());
    localOutputStream.write(paramArrayOfByte, 0, paramInt);
    paramPGPLiteralDataGenerator.close();
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localByteArrayOutputStream.toByteArray());
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPLiteralData.getInputStream();
    for (int i = 0; i != paramInt; i++) {
      if (localInputStream.read() != (paramArrayOfByte[i] & 0xFF)) {
        fail("failed readback test - length = " + paramInt);
      }
    }
  }
  
  public void performTest()
    throws IOException
  {
    PGPLiteralDataGenerator localPGPLiteralDataGenerator1 = new PGPLiteralDataGenerator(true);
    readBackTest(localPGPLiteralDataGenerator1);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator2 = new PGPLiteralDataGenerator(false);
    readBackTest(localPGPLiteralDataGenerator2);
  }
  
  public String getName()
  {
    return "PGPPacketTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPPacketTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPPacketTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */