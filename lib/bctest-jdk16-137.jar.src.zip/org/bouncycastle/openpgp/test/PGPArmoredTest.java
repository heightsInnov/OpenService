package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.bouncycastle.bcpg.ArmoredInputStream;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class PGPArmoredTest
  extends SimpleTest
{
  byte[] sample = Base64.decode("mQGiBEA83v0RBADzKVLVCnpWQxX0LCsevw/3OLs0H7MOcLBQ4wMO9sYmzGYnxpVj+4e4PiCP7QBayWyy4lugL6Lnw7tESvq3A4v3fefcxaCTkJrryiKn4+Cgy5rIBbrSKNtCEhVi7xjtdnDjP5kFKgHYjVOeIKn4Cz/yzPG3qz75kDknldLfyHxp2wCgwW1vAE5EnZU4/UmY7l8kTNkMltMEAJP4/uY4zcRwLI9Q2raPqAOJTYLd7h+3k/BxI0gIw96niQ3KmUZDlobbWBI+VHM6H99vcttKU3BgevNf8M9Gx/AbtW3SS4De64wNSU3189XDG8vXf0vuyW/K6Pcrb8exJWY0E1zZQ1WXT0gZW0kH3g5ro//Tusuil9q2lVLF2ovJA/0W+57bPzi318dWeNs0tTq6Njbc/GTGFUAVJ8Ss5v2u6h7gyJ1DB334ExF/UdqZGldp0ugkEXaSwBa2R7d3HBgaYcoPCk1TrovZzEY8gm7JNVy7GW6mdOZuDOHTxyADEEP2JPxh6eRcZbzhGuJuYIifIIeLOTI5Dc4XKeV32a+bWrQidGVzdCAoVGVzdCBrZXkpIDx0ZXN0QHViaWNhbGwuY29tPohkBBMRAgAkBQJAPN79AhsDBQkB4TOABgsJCAcDAgMVAgMDFgIBAh4BAheAAAoJEJh8Njfhe8KmGDcAoJWr8xgPr75y/Cp1kKn12oCCOb8zAJ4pxSvk4K6tB2jYbdeSrmoWBZLdMLACAAC5AQ0EQDzfARAEAJeUAPvUzJJbKcc55Iyb13+Gfb8xBWE3HinQzhGr1v6A1aIZbRj47UPAD/tQxwz8VAwJySx82ggNLxCk4jW9YtTL3uZqfczsJngV25GoIN10f4/j2BVqZAaX3q79a3eMiql1T0oEAGmD7tO1LkTvWfm3VvA0+t8/6ZeRLEiIqAOHAAQNBACD0mVMlAUgd7REYy/1mL99Zlu9XU0uKyUex99sJNrcx1aj8rIiZtWaHz6CN1XptdwpDeSYEOFZ0PSuqH9ByM3OfjU/ya0//xdvhwYXupn6P1Kep85efMBA9jUv/DeBOzRWMFG6sC6yk8NGG7Swea7EHKeQI40G3jgO/+xANtMyTIhPBBgRAgAPBQJAPN8BAhsMBQkB4TOAAAoJEJh8Njfhe8KmG7kAn00mTPGJCWqmskmzgdzeky5fWd7rAKCNCp3uZJhfg0htdgAfIy8ppm05vLACAAA=");
  byte[] marker = Hex.decode("2d2d2d2d2d454e4420504750205055424c4943204b455920424c4f434b2d2d2d2d2d");
  
  private int markerCount(byte[] paramArrayOfByte)
  {
    int i = 0;
    int j = 0;
    while (i < paramArrayOfByte.length) {
      if (paramArrayOfByte[i] == 45)
      {
        for (int k = 0; (k < this.marker.length) && (paramArrayOfByte[(i + k)] == this.marker[k]); k++) {}
        if (k == this.marker.length) {
          j++;
        }
        i += k;
      }
      else
      {
        i++;
      }
    }
    return j;
  }
  
  public void performTest()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.close();
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    if (arrayOfByte.length != 0) {
      fail("No data should have been written");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.close();
    localArmoredOutputStream.close();
    int i = markerCount(localByteArrayOutputStream.toByteArray());
    if (i < 1) {
      fail("No end marker found");
    }
    if (i > 1) {
      fail("More than one end marker found");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.close();
    ArmoredInputStream localArmoredInputStream = new ArmoredInputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localArmoredInputStream);
    for (int j = 0; localPGPObjectFactory.nextObject() != null; j++) {}
    if (j != 1) {
      fail("wrong number of objects found: " + j);
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.close();
    localArmoredInputStream = new ArmoredInputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
    localPGPObjectFactory = new PGPObjectFactory(localArmoredInputStream);
    for (j = 0; localPGPObjectFactory.nextObject() != null; j++) {}
    if (j != 2) {
      fail("wrong number of objects found: " + j);
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.close();
    localArmoredOutputStream = new ArmoredOutputStream(localByteArrayOutputStream);
    localArmoredOutputStream.write(this.sample);
    localArmoredOutputStream.close();
    localArmoredInputStream = new ArmoredInputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
    j = 0;
    int k;
    do
    {
      k = 0;
      localPGPObjectFactory = new PGPObjectFactory(localArmoredInputStream);
      while (localPGPObjectFactory.nextObject() != null)
      {
        k = 1;
        j++;
      }
    } while (k != 0);
    if (j != 2) {
      fail("wrong number of objects found: " + j);
    }
  }
  
  public String getName()
  {
    return "PGPArmoredTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PGPArmoredTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPArmoredTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */