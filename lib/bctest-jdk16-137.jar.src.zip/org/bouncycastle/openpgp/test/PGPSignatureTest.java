package org.bouncycastle.openpgp.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import org.bouncycastle.openpgp.PGPV3SignatureGenerator;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPSignatureTest
  extends SimpleTest
{
  private static final int[] NO_PREFERENCES = null;
  private static final int[] PREFERRED_SYMMETRIC_ALGORITHMS = { 7, 2 };
  private static final int[] PREFERRED_HASH_ALGORITHMS = { 2, 8 };
  private static final int[] PREFERRED_COMPRESSION_ALGORITHMS = { 2 };
  private static final int TEST_EXPIRATION_TIME = 10000;
  private static final String TEST_USER_ID = "test user id";
  private static final byte[] TEST_DATA = "hello world!\nhello world!\n".getBytes();
  private static final byte[] TEST_DATA_WITH_CRLF = "hello world!\r\nhello world!\r\n".getBytes();
  byte[] dsaKeyRing = Base64.decode("lQHhBD9HBzURBACzkxRCVGJg5+Ld9DU4Xpnd4LCKgMq7YOY7Gi0EgK92gbaa6+zQoQFqz1tt3QUmpz3YVkm/zLESBBtC1ACIXGggUdFMUr5I87+1Cb6vzefAtGt8N5VV1F/MXv1gJz4Bu6HyxL/ncfe71jsNhav0i4yAjf2etWFj53zK6R+Ojg5H6wCgpL9/tXVfGP8SqFvyrN/437MlFSUEAIN3V6j/MUllyrZglrtr2+RWIwRrG/ACmrF6hTugOl4cQxaDYNcntXbhlTlJs9MxjTH3xxzylyirCyq7HzGJxZzSt6FTeh1DFYzhJ7QuYR1xrSdA6Y0mUv0ixD5A4nPHjupQ5QCqHGeRfFD/oHzD4zqBnJp/BJ3LvQ66bERJmKl5A/4uj3HoVxpb0vvyENfRqKMmGBISycY4MoH5uWfb23FffsT9r9KL6nJ4syLzaRR0gvcbcjkc9Z3epI7gr3jTrb4d8WPxsDbT/W1tv9bG/EHawomLcihtuUU68Uej6/wZot1XJqu2nQlku57+M/V2X1y26VKsipolPfja4uyBOOyvbP4DAwIDIBTxWjkCGGAWQO2jy9CTvLHJEoTO7moHrp1FxOVpQ8iJHyRqZzLllO26OzgohbiPYz8u9qCulZ9Xn7QzRXJpYyBFY2hpZG5hIChEU0EgVGVzdCBLZXkpIDxlcmljQGJvdW5jeWNhc3RsZS5vcmc+iFkEExECABkFAj9HBzUECwcDAgMVAgMDFgIBAh4BAheAAAoJEM0j9enEyjRDAlwAnjTjjt57NKIgyym7OTCwzIU3xgFpAJ0VO5m5PfQKmGJRhaewLSZD4nXkHg==");
  char[] dsaPass = "hello world".toCharArray();
  byte[] rsaKeyRing = Base64.decode("lQIEBEBXUNMBBADScQczBibewnbCzCswc/9ut8R0fwlltBRxMW0NMdKJY2LF7k2COeLOCIU95loJGV6ulbpDCXEO2Jyq8/qGw1qD3SCZNXxKs3GS8Iyh9UwdVL07nMMYl5NiQRsFB7wOb86+94tYWgvikVA5BRP5y3+O3GItnXnpWSJyREUy6WI2QQAGKf4JAwIVmnRs4jtTX2DD05zy2mepEQ8bsqVAKIx7lEwvMVNcvg4Y8vFLh9Mf/uNciwL4Se/ehfKQ/AT0JmBZduYMqRU2zhiBmxj4cXUQ0s36ysj7fyDngGocDnM3cwPxaTF1ZRBQHSLewP7dqE7M73usFSz8vwD/0xNOHFRLKbsORqDlLA1Cg2Yd0wWPS0o7+qqk9ndqrjjSwMM8ftnzFGjShAdg4Ca7fFkcNePP/rrwIH472FuRb7RbWzwXA4+4ZBdl8D4An0dwtfvAO+jCZSrLjmSpxEOveJxYGduyR4IA4lemvAG51YHTHd4NXheuEqsIkn1yarwaaj47lFPnxNOElOREMdZbnkWQb1jfgqO24imEZgrLMkK9bJfoDnlF4k6r6hZOp5FSFvc5kJB4cVo1QJl4pwCSdoU6luwCggrlZhDnkGCSuQUUW45NE7Br22NGqn4/gHs0KCsWbAezApGjqYUCfX1bcpPzUMzUlBaD5rz2vPeO58CDtBJ0ZXN0ZXIgPHRlc3RAdGVzdD6IsgQTAQIAHAUCQFdQ0wIbAwQLBwMCAxUCAwMWAgECHgECF4AACgkQs8JyyQfH97I1QgP8Cd+35maM2cbWV9iVRO+c5456KDi3oIUSNdPf1NQrCAtJqEUhmMStQbdiaFEkPrORISI/2htXruYn0aIpkCfbUheHOu0sef7s6pHmI2kOQPzR+C/j8D9QvWsPOOso81KU2axUY8zIer64Uzqc4szMIlLw06c8vea27RfgjBpSCrywAgAA");
  char[] rsaPass = "2002 Buffalo Sabres".toCharArray();
  byte[] nullPacketsSubKeyBinding = Base64.decode("iDYEGBECAAAAACp9AJ9PlJCrFpi+INwG7z61eku2Wg1HaQCgl33X5Egj+Kf7F9CXIWj2iFCvQDo=");
  
  public void performTest()
    throws Exception
  {
    PGPSecretKeyRing localPGPSecretKeyRing1 = new PGPSecretKeyRing(this.rsaKeyRing);
    PGPSecretKey localPGPSecretKey1 = localPGPSecretKeyRing1.getSecretKey();
    PGPPrivateKey localPGPPrivateKey1 = localPGPSecretKey1.extractPrivateKey(this.rsaPass, "BC");
    try
    {
      testSig(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
      fail("RSA wrong key test failed.");
    }
    catch (PGPException localPGPException1) {}
    try
    {
      testSigV3(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
      fail("RSA V3 wrong key test failed.");
    }
    catch (PGPException localPGPException2) {}
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(1, 2, "BC");
    localPGPSignatureGenerator.initSign(32, localPGPPrivateKey1);
    PGPSignature localPGPSignature = localPGPSignatureGenerator.generateCertification(localPGPSecretKey1.getPublicKey());
    localPGPSignature.initVerify(localPGPSecretKey1.getPublicKey(), "BC");
    if (!localPGPSignature.verifyCertification(localPGPSecretKey1.getPublicKey())) {
      fail("revocation verification failed.");
    }
    PGPSecretKeyRing localPGPSecretKeyRing2 = new PGPSecretKeyRing(this.dsaKeyRing);
    PGPSecretKey localPGPSecretKey2 = localPGPSecretKeyRing2.getSecretKey();
    PGPPrivateKey localPGPPrivateKey2 = localPGPSecretKey2.extractPrivateKey(this.dsaPass, "BC");
    localPGPSignatureGenerator = new PGPSignatureGenerator(17, 2, "BC");
    localPGPSignatureGenerator.initSign(24, localPGPPrivateKey2);
    PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator1 = new PGPSignatureSubpacketGenerator();
    PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator2 = new PGPSignatureSubpacketGenerator();
    localPGPSignatureSubpacketGenerator2.setSignatureExpirationTime(false, 10000L);
    localPGPSignatureSubpacketGenerator2.setSignerUserID(true, "test user id");
    localPGPSignatureSubpacketGenerator2.setPreferredCompressionAlgorithms(false, PREFERRED_COMPRESSION_ALGORITHMS);
    localPGPSignatureSubpacketGenerator2.setPreferredHashAlgorithms(false, PREFERRED_HASH_ALGORITHMS);
    localPGPSignatureSubpacketGenerator2.setPreferredSymmetricAlgorithms(false, PREFERRED_SYMMETRIC_ALGORITHMS);
    localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketGenerator2.generate());
    localPGPSignatureGenerator.setUnhashedSubpackets(localPGPSignatureSubpacketGenerator1.generate());
    localPGPSignature = localPGPSignatureGenerator.generateCertification(localPGPSecretKey2.getPublicKey(), localPGPSecretKey1.getPublicKey());
    byte[] arrayOfByte = localPGPSignature.getEncoded();
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(arrayOfByte);
    localPGPSignature = ((PGPSignatureList)localPGPObjectFactory.nextObject()).get(0);
    localPGPSignature.initVerify(localPGPSecretKey2.getPublicKey(), "BC");
    if (!localPGPSignature.verifyCertification(localPGPSecretKey2.getPublicKey(), localPGPSecretKey1.getPublicKey())) {
      fail("subkey binding verification failed.");
    }
    PGPSignatureSubpacketVector localPGPSignatureSubpacketVector1 = localPGPSignature.getHashedSubPackets();
    PGPSignatureSubpacketVector localPGPSignatureSubpacketVector2 = localPGPSignature.getUnhashedSubPackets();
    if (localPGPSignatureSubpacketVector1.size() != 6) {
      fail("wrong number of hashed packets found.");
    }
    if (localPGPSignatureSubpacketVector2.size() != 1) {
      fail("wrong number of unhashed packets found.");
    }
    if (!localPGPSignatureSubpacketVector1.getSignerUserID().equals("test user id")) {
      fail("test userid not matching");
    }
    if (localPGPSignatureSubpacketVector1.getSignatureExpirationTime() != 10000L) {
      fail("test signature expiration time not matching");
    }
    if (localPGPSignatureSubpacketVector2.getIssuerKeyID() != localPGPSecretKey2.getKeyID()) {
      fail("wrong issuer key ID found in certification");
    }
    int[] arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredCompressionAlgorithms();
    preferredAlgorithmCheck("compression", PREFERRED_COMPRESSION_ALGORITHMS, arrayOfInt1);
    arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredHashAlgorithms();
    preferredAlgorithmCheck("hash", PREFERRED_HASH_ALGORITHMS, arrayOfInt1);
    arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredSymmetricAlgorithms();
    preferredAlgorithmCheck("symmetric", PREFERRED_SYMMETRIC_ALGORITHMS, arrayOfInt1);
    int[] arrayOfInt2 = localPGPSignatureSubpacketVector1.getCriticalTags();
    if (arrayOfInt2.length != 1) {
      fail("wrong number of critical packets found.");
    }
    if (arrayOfInt2[0] != 28) {
      fail("wrong critical packet found in tag list.");
    }
    localPGPSignatureGenerator = new PGPSignatureGenerator(17, 2, "BC");
    localPGPSignatureGenerator.initSign(24, localPGPPrivateKey2);
    localPGPSignatureGenerator.setHashedSubpackets(null);
    localPGPSignatureGenerator.setUnhashedSubpackets(null);
    localPGPSignature = localPGPSignatureGenerator.generateCertification("test user id", localPGPSecretKey1.getPublicKey());
    localPGPSignature.initVerify(localPGPSecretKey2.getPublicKey(), "BC");
    if (!localPGPSignature.verifyCertification("test user id", localPGPSecretKey1.getPublicKey())) {
      fail("subkey binding verification failed.");
    }
    localPGPSignatureSubpacketVector1 = localPGPSignature.getHashedSubPackets();
    if (localPGPSignatureSubpacketVector1.size() != 1) {
      fail("found wrong number of hashed packets");
    }
    localPGPSignatureSubpacketVector2 = localPGPSignature.getUnhashedSubPackets();
    if (localPGPSignatureSubpacketVector2.size() != 1) {
      fail("found wrong number of unhashed packets");
    }
    try
    {
      localPGPSignature.verifyCertification(localPGPSecretKey1.getPublicKey());
      fail("failed to detect non-key signature.");
    }
    catch (IllegalStateException localIllegalStateException) {}
    localPGPSignatureGenerator = new PGPSignatureGenerator(17, 2, "BC");
    localPGPSignatureGenerator.initSign(24, localPGPPrivateKey2);
    localPGPSignatureSubpacketGenerator2 = new PGPSignatureSubpacketGenerator();
    localPGPSignatureSubpacketGenerator2.setSignatureCreationTime(false, new Date(0L));
    localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketGenerator2.generate());
    localPGPSignatureGenerator.setUnhashedSubpackets(null);
    localPGPSignature = localPGPSignatureGenerator.generateCertification("test user id", localPGPSecretKey1.getPublicKey());
    localPGPSignature.initVerify(localPGPSecretKey2.getPublicKey(), "BC");
    if (!localPGPSignature.verifyCertification("test user id", localPGPSecretKey1.getPublicKey())) {
      fail("subkey binding verification failed.");
    }
    localPGPSignatureSubpacketVector1 = localPGPSignature.getHashedSubPackets();
    if (localPGPSignatureSubpacketVector1.size() != 1) {
      fail("found wrong number of hashed packets in override test");
    }
    if (!localPGPSignatureSubpacketVector1.getSignatureCreationTime().equals(new Date(0L))) {
      fail("creation of overriden date failed.");
    }
    arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredCompressionAlgorithms();
    preferredAlgorithmCheck("compression", NO_PREFERENCES, arrayOfInt1);
    arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredHashAlgorithms();
    preferredAlgorithmCheck("hash", NO_PREFERENCES, arrayOfInt1);
    arrayOfInt1 = localPGPSignatureSubpacketVector1.getPreferredSymmetricAlgorithms();
    preferredAlgorithmCheck("symmetric", NO_PREFERENCES, arrayOfInt1);
    if (localPGPSignatureSubpacketVector1.getKeyExpirationTime() != 0L) {
      fail("unexpected key expiration time found");
    }
    if (localPGPSignatureSubpacketVector1.getSignatureExpirationTime() != 0L) {
      fail("unexpected signature expiration time found");
    }
    if (localPGPSignatureSubpacketVector1.getSignerUserID() != null) {
      fail("unexpected signer user ID found");
    }
    arrayOfInt2 = localPGPSignatureSubpacketVector1.getCriticalTags();
    if (arrayOfInt2.length != 0) {
      fail("critical packets found when none expected");
    }
    localPGPSignatureSubpacketVector2 = localPGPSignature.getUnhashedSubPackets();
    if (localPGPSignatureSubpacketVector2.size() != 1) {
      fail("found wrong number of unhashed packets in override test");
    }
    testSig(1, 8, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testSig(1, 9, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testSig(1, 10, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testSigV3(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testTextSig(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA_WITH_CRLF, TEST_DATA_WITH_CRLF);
    testTextSig(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA, TEST_DATA_WITH_CRLF);
    testTextSigV3(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA_WITH_CRLF, TEST_DATA_WITH_CRLF);
    testTextSigV3(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA, TEST_DATA_WITH_CRLF);
    localPGPSecretKeyRing1 = new PGPSecretKeyRing(this.dsaKeyRing);
    localPGPSecretKey1 = localPGPSecretKeyRing1.getSecretKey();
    localPGPPrivateKey1 = localPGPSecretKey1.extractPrivateKey(this.dsaPass, "BC");
    try
    {
      testSig(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
      fail("DSA wrong key test failed.");
    }
    catch (PGPException localPGPException3) {}
    try
    {
      testSigV3(1, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
      fail("DSA V3 wrong key test failed.");
    }
    catch (PGPException localPGPException4) {}
    testSig(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testSigV3(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1);
    testTextSig(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA_WITH_CRLF, TEST_DATA_WITH_CRLF);
    testTextSig(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA, TEST_DATA_WITH_CRLF);
    testTextSigV3(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA_WITH_CRLF, TEST_DATA_WITH_CRLF);
    testTextSigV3(17, 2, localPGPSecretKey1.getPublicKey(), localPGPPrivateKey1, TEST_DATA, TEST_DATA_WITH_CRLF);
    testMissingSubpackets(this.nullPacketsSubKeyBinding);
    testMissingSubpackets(generateV3BinarySig(localPGPPrivateKey1, 17, 2));
  }
  
  private void testMissingSubpackets(byte[] paramArrayOfByte)
    throws IOException
  {
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramArrayOfByte);
    Object localObject1 = localPGPObjectFactory.nextObject();
    while (!(localObject1 instanceof PGPSignatureList))
    {
      localObject1 = localPGPObjectFactory.nextObject();
      if ((localObject1 instanceof PGPLiteralData))
      {
        localObject2 = ((PGPLiteralData)localObject1).getDataStream();
        while (((InputStream)localObject2).read() >= 0) {}
      }
    }
    Object localObject2 = ((PGPSignatureList)localObject1).get(0);
    if (((PGPSignature)localObject2).getVersion() > 3)
    {
      PGPSignatureSubpacketVector localPGPSignatureSubpacketVector = ((PGPSignature)localObject2).getHashedSubPackets();
      if (localPGPSignatureSubpacketVector.getKeyExpirationTime() != 0L) {
        fail("key expiration time not zero for missing subpackets");
      }
    }
    else
    {
      if (((PGPSignature)localObject2).getHashedSubPackets() != null) {
        fail("hashed sub packets found when none expected");
      }
      if (((PGPSignature)localObject2).getUnhashedSubPackets() != null) {
        fail("unhashed sub packets found when none expected");
      }
    }
  }
  
  private void preferredAlgorithmCheck(String paramString, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (paramArrayOfInt1 == null)
    {
      if (paramArrayOfInt2 != null) {
        fail("preferences for " + paramString + " found when none expected");
      }
    }
    else
    {
      if (paramArrayOfInt2.length != paramArrayOfInt1.length) {
        fail("wrong number of preferred " + paramString + " algorithms found");
      }
      for (int i = 0; i != paramArrayOfInt1.length; i++) {
        if (paramArrayOfInt1[i] != paramArrayOfInt2[i]) {
          fail("wrong algorithm found for " + paramString + ": expected " + paramArrayOfInt1[i] + " got " + paramArrayOfInt2);
        }
      }
    }
  }
  
  private void testSig(int paramInt1, int paramInt2, PGPPublicKey paramPGPPublicKey, PGPPrivateKey paramPGPPrivateKey)
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(TEST_DATA);
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(paramInt1, paramInt2, "BC");
    localPGPSignatureGenerator.initSign(0, paramPGPPrivateKey);
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localByteArrayOutputStream);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), 'b', "_CONSOLE", TEST_DATA.length * 2, new Date());
    int i;
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localOutputStream.write(TEST_DATA);
    localPGPSignatureGenerator.update(TEST_DATA);
    localPGPLiteralDataGenerator.close();
    localPGPSignatureGenerator.generate().encode(localByteArrayOutputStream);
    verifySignature(localByteArrayOutputStream.toByteArray(), paramInt2, paramPGPPublicKey, TEST_DATA);
  }
  
  private void testTextSig(int paramInt1, int paramInt2, PGPPublicKey paramPGPPublicKey, PGPPrivateKey paramPGPPrivateKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(paramInt1, 2, "BC");
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte1);
    Date localDate = new Date();
    localPGPSignatureGenerator.initSign(1, paramPGPPrivateKey);
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localByteArrayOutputStream);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), 't', "_CONSOLE", paramArrayOfByte1.length * 2, localDate);
    int i;
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localOutputStream.write(paramArrayOfByte1);
    localPGPSignatureGenerator.update(paramArrayOfByte1);
    localPGPLiteralDataGenerator.close();
    localPGPSignatureGenerator.generate().encode(localByteArrayOutputStream);
    verifySignature(localByteArrayOutputStream.toByteArray(), paramInt2, paramPGPPublicKey, paramArrayOfByte2);
  }
  
  private void testSigV3(int paramInt1, int paramInt2, PGPPublicKey paramPGPPublicKey, PGPPrivateKey paramPGPPrivateKey)
    throws Exception
  {
    byte[] arrayOfByte = generateV3BinarySig(paramPGPPrivateKey, paramInt1, paramInt2);
    verifySignature(arrayOfByte, paramInt2, paramPGPPublicKey, TEST_DATA);
  }
  
  private byte[] generateV3BinarySig(PGPPrivateKey paramPGPPrivateKey, int paramInt1, int paramInt2)
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(TEST_DATA);
    PGPV3SignatureGenerator localPGPV3SignatureGenerator = new PGPV3SignatureGenerator(paramInt1, paramInt2, "BC");
    localPGPV3SignatureGenerator.initSign(0, paramPGPPrivateKey);
    localPGPV3SignatureGenerator.generateOnePassVersion(false).encode(localByteArrayOutputStream);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), 'b', "_CONSOLE", TEST_DATA.length * 2, new Date());
    int i;
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPV3SignatureGenerator.update((byte)i);
    }
    localOutputStream.write(TEST_DATA);
    localPGPV3SignatureGenerator.update(TEST_DATA);
    localPGPLiteralDataGenerator.close();
    localPGPV3SignatureGenerator.generate().encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  private void testTextSigV3(int paramInt1, int paramInt2, PGPPublicKey paramPGPPublicKey, PGPPrivateKey paramPGPPrivateKey, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    PGPV3SignatureGenerator localPGPV3SignatureGenerator = new PGPV3SignatureGenerator(paramInt1, 2, "BC");
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte1);
    localPGPV3SignatureGenerator.initSign(1, paramPGPPrivateKey);
    localPGPV3SignatureGenerator.generateOnePassVersion(false).encode(localByteArrayOutputStream);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), 't', "_CONSOLE", paramArrayOfByte1.length * 2, new Date());
    int i;
    while ((i = localByteArrayInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPV3SignatureGenerator.update((byte)i);
    }
    localOutputStream.write(paramArrayOfByte1);
    localPGPV3SignatureGenerator.update(paramArrayOfByte1);
    localPGPLiteralDataGenerator.close();
    localPGPV3SignatureGenerator.generate().encode(localByteArrayOutputStream);
    verifySignature(localByteArrayOutputStream.toByteArray(), paramInt2, paramPGPPublicKey, paramArrayOfByte2);
  }
  
  private void verifySignature(byte[] paramArrayOfByte1, int paramInt, PGPPublicKey paramPGPPublicKey, byte[] paramArrayOfByte2)
    throws IOException, PGPException, NoSuchProviderException, SignatureException
  {
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramArrayOfByte1);
    PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory.nextObject();
    PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPLiteralData.getInputStream();
    localPGPOnePassSignature.initVerify(paramPGPPublicKey, "BC");
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localPGPOnePassSignature.update((byte)i);
    }
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    PGPSignature localPGPSignature = localPGPSignatureList.get(0);
    Date localDate1 = localPGPSignature.getCreationTime();
    Date localDate2 = new Date();
    if ((localDate1.after(localDate2)) || (localDate1.before(new Date(localDate2.getTime() - 600000L)))) {
      fail("bad creation time in signature: " + localDate1);
    }
    if (localPGPSignature.getKeyID() != paramPGPPublicKey.getKeyID()) {
      fail("key id mismatch in signature");
    }
    if (!localPGPOnePassSignature.verify(localPGPSignature)) {
      fail("Failed generated signature check - " + paramInt);
    }
    localPGPSignature.initVerify(paramPGPPublicKey, "BC");
    for (int j = 0; j != paramArrayOfByte2.length; j++) {
      localPGPSignature.update(paramArrayOfByte2[j]);
    }
    localPGPSignature.update(paramArrayOfByte2);
    if (!localPGPSignature.verify()) {
      fail("Failed generated signature check against original data");
    }
  }
  
  public String getName()
  {
    return "PGPSignatureTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPSignatureTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPSignatureTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */