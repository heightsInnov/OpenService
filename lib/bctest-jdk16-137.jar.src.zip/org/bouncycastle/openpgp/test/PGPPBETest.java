package org.bouncycastle.openpgp.test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPBEEncryptedData;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPPBETest
  extends SimpleTest
{
  private static final Date TEST_DATE = new Date(1062200111000L);
  byte[] enc1 = Base64.decode("jA0EAwMC5M5wWBP2HBZgySvUwWFAmMRLn7dWiZN6AkQMvpE3b6qwN3SSun7zInw2hxxdgFzVGfbjuB8w");
  byte[] enc1crc = Base64.decode("H66L");
  char[] pass = { 'h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd' };
  byte[] testPBEAsym = Base64.decode("hQIOA/ZlQEFWB5vuEAf/covEUaBve7NlWWdiO5NZubdtTHGElEXzG9hyBycp9At8nZGi27xOZtEGFQo7pfz4JySRc3O0s6w7PpjJSonFJyNSxuze2LuqRwFWBYYcbS8/7YcjB6PqutrT939OWsozfNqivI9/QyZCjBvFU89pp7dtUngiZ6MVv81ds2I+vcvkGlIFcxcE1XoCIB3EvbqWNaoOotgEPT60unnB2BeDV1KD3lDRouMIYHfZ3SzBwOOI6aK39sWnY5sAK7JjFvnDAMBdueOiI0Fy+gxbFD/zFDt4cWAVSAGTC4w371iqppmT25TM7zAtCgpiq5IsELPlUZZnXKmnYQ7OCeysF0eeVwf+OFB9fyvCEv/zVQocJCg8fWxfCBlIVFNeNQpeGygn/ZmRaILvB7IXDWP0oOw7/F2Ym66IdYYIp2HeEZv+jFwal41w5W4BH/gtbwGjFQ6CvF/m+lfUv6ZZdzsMIeEOwhP5g7rXBxrbcnGBaU+PXbhogjDqaYzAWGlrmAd6aPSj51AGeYXkb2T1T/yoJ++M3GvhH4C4hvitamDkksh/qRnMM/s8Nku6z1+RXO3M6p5QC1nlAVqieU8esT43945eSoC77K8WyujDNbysDyUCUTztp/aoQwe/HgkeOTJNelKR9y2W3xinZLFzep0SqpNI/e468yB/2/LGsykIyQa7JX6rBYwuBAIDAkOKfv5rK8v0YDfnN+eFqwhTcrfBj5rDH7hER6nW3lNWcMataUiHEaMgo6Q0OO1vptIGxW8jClTD4N1sCNwNu9vKny8dKYDDHbCjE06DNTv7XYVW3+JqTL5EBnidvGgOmA==");
  
  private byte[] decryptMessage(byte[] paramArrayOfByte, Date paramDate)
    throws Exception
  {
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(paramArrayOfByte);
    PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory1.nextObject();
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(0);
    InputStream localInputStream1 = localPGPPBEEncryptedData.getDataStream(this.pass, "BC");
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(localInputStream1);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory2.nextObject();
    localPGPObjectFactory2 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory2.nextObject();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    if ((!localPGPLiteralData.getFileName().equals("test.txt")) && (!localPGPLiteralData.getFileName().equals("_CONSOLE"))) {
      fail("wrong filename in packet");
    }
    if (!localPGPLiteralData.getModificationTime().equals(paramDate)) {
      fail("wrong modification time in packet: " + localPGPLiteralData.getModificationTime().getTime() + " " + paramDate.getTime());
    }
    InputStream localInputStream2 = localPGPLiteralData.getInputStream();
    int i;
    while ((i = localInputStream2.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    if ((localPGPPBEEncryptedData.isIntegrityProtected()) && (!localPGPPBEEncryptedData.verify())) {
      fail("integrity check failed");
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  private byte[] decryptMessageBuffered(byte[] paramArrayOfByte, Date paramDate)
    throws Exception
  {
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(paramArrayOfByte);
    PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory1.nextObject();
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(0);
    InputStream localInputStream1 = localPGPPBEEncryptedData.getDataStream(this.pass, "BC");
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(localInputStream1);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory2.nextObject();
    localPGPObjectFactory2 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory2.nextObject();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    if ((!localPGPLiteralData.getFileName().equals("test.txt")) && (!localPGPLiteralData.getFileName().equals("_CONSOLE"))) {
      fail("wrong filename in packet");
    }
    if (!localPGPLiteralData.getModificationTime().equals(paramDate)) {
      fail("wrong modification time in packet: " + localPGPLiteralData.getModificationTime().getTime() + " " + paramDate.getTime());
    }
    InputStream localInputStream2 = localPGPLiteralData.getInputStream();
    byte[] arrayOfByte = new byte['Ѐ'];
    int i;
    while ((i = localInputStream2.read(arrayOfByte)) >= 0) {
      localByteArrayOutputStream.write(arrayOfByte, 0, i);
    }
    if ((localPGPPBEEncryptedData.isIntegrityProtected()) && (!localPGPPBEEncryptedData.verify())) {
      fail("integrity check failed");
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void performTest()
    throws Exception
  {
    byte[] arrayOfByte1 = decryptMessage(this.enc1, TEST_DATE);
    if ((arrayOfByte1[0] != 104) || (arrayOfByte1[1] != 101) || (arrayOfByte1[2] != 108)) {
      fail("wrong plain text in packet");
    }
    byte[] arrayOfByte2 = { 104, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33, 10 };
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    Date localDate = new Date(System.currentTimeMillis() / 1000L * 1000L);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream1 = localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream1));
    OutputStream localOutputStream2 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localOutputStream1), 'b', "_CONSOLE", arrayOfByte2.length, localDate);
    localOutputStream2.write(arrayOfByte2);
    localOutputStream2.close();
    localOutputStream1.close();
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, new SecureRandom(), "BC");
    localPGPEncryptedDataGenerator.addMethod(this.pass);
    OutputStream localOutputStream3 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), localByteArrayOutputStream1.toByteArray().length);
    localOutputStream3.write(localByteArrayOutputStream1.toByteArray());
    localOutputStream3.close();
    arrayOfByte1 = decryptMessage(localByteArrayOutputStream2.toByteArray(), localDate);
    if (!areEqual(arrayOfByte1, arrayOfByte2)) {
      fail("wrong plain text in generated packet");
    }
    localByteArrayOutputStream2 = new ByteArrayOutputStream();
    localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, new SecureRandom(), "BC");
    localPGPEncryptedDataGenerator.addMethod(this.pass);
    localOutputStream3 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), localByteArrayOutputStream1.toByteArray().length);
    localOutputStream3.write(localByteArrayOutputStream1.toByteArray());
    localPGPEncryptedDataGenerator.close();
    arrayOfByte1 = decryptMessage(localByteArrayOutputStream2.toByteArray(), localDate);
    if (!areEqual(arrayOfByte1, arrayOfByte2)) {
      fail("wrong plain text in generated packet");
    }
    SecureRandom localSecureRandom = new SecureRandom();
    byte[] arrayOfByte3 = new byte['ӑ'];
    localSecureRandom.nextBytes(arrayOfByte3);
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    localOutputStream1 = localPGPCompressedDataGenerator.open(localByteArrayOutputStream1);
    localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    localOutputStream2 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localOutputStream1), 'b', "_CONSOLE", TEST_DATE, new byte[16]);
    localOutputStream2.write(arrayOfByte3);
    localOutputStream2.close();
    localOutputStream1.close();
    localByteArrayOutputStream2 = new ByteArrayOutputStream();
    localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, localSecureRandom, "BC");
    localPGPEncryptedDataGenerator.addMethod(this.pass);
    localOutputStream3 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), new byte[16]);
    localOutputStream3.write(localByteArrayOutputStream1.toByteArray());
    localOutputStream3.close();
    arrayOfByte1 = decryptMessage(localByteArrayOutputStream2.toByteArray(), TEST_DATE);
    if (!areEqual(arrayOfByte1, arrayOfByte3)) {
      fail("wrong plain text in generated packet");
    }
    localByteArrayOutputStream2 = new ByteArrayOutputStream();
    localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, true, localSecureRandom, "BC");
    localPGPEncryptedDataGenerator.addMethod(this.pass);
    localOutputStream3 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), new byte[16]);
    localOutputStream3.write(localByteArrayOutputStream1.toByteArray());
    localOutputStream3.close();
    arrayOfByte1 = decryptMessage(localByteArrayOutputStream2.toByteArray(), TEST_DATE);
    if (!areEqual(arrayOfByte1, arrayOfByte3)) {
      fail("wrong plain text in generated packet");
    }
    arrayOfByte1 = decryptMessageBuffered(localByteArrayOutputStream2.toByteArray(), TEST_DATE);
    if (!areEqual(arrayOfByte1, arrayOfByte3)) {
      fail("wrong plain text in buffer generated packet");
    }
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(this.testPBEAsym);
    PGPEncryptedDataList localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory.nextObject();
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(1);
    InputStream localInputStream1 = localPGPPBEEncryptedData.getDataStream("password".toCharArray(), "BC");
    localPGPObjectFactory = new PGPObjectFactory(localInputStream1);
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    InputStream localInputStream2 = localPGPLiteralData.getInputStream();
    int i;
    while ((i = localInputStream2.read()) >= 0) {
      localByteArrayOutputStream1.write(i);
    }
    if (!areEqual(localByteArrayOutputStream1.toByteArray(), Hex.decode("5361742031302e30322e30370d0a"))) {
      fail("data mismatch on combined PBE");
    }
    byte[] arrayOfByte4 = new byte[1];
    localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    localOutputStream1 = localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream1));
    localOutputStream2 = localPGPLiteralDataGenerator.open(new UncloseableOutputStream(localOutputStream1), 'b', "_CONSOLE", arrayOfByte4.length, localDate);
    localOutputStream2.write(arrayOfByte4);
    localOutputStream2.close();
    localOutputStream1.close();
    localByteArrayOutputStream2 = new ByteArrayOutputStream();
    localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, true, localSecureRandom, "BC");
    localPGPEncryptedDataGenerator.addMethod(this.pass);
    localOutputStream3 = localPGPEncryptedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream2), new byte[16]);
    localOutputStream3.write(localByteArrayOutputStream1.toByteArray());
    localOutputStream3.close();
    arrayOfByte1 = decryptMessage(localByteArrayOutputStream2.toByteArray(), localDate);
    if (!areEqual(arrayOfByte1, arrayOfByte4)) {
      fail("wrong plain text in generated packet");
    }
    arrayOfByte1 = decryptMessageBuffered(localByteArrayOutputStream2.toByteArray(), localDate);
    if (!areEqual(arrayOfByte1, arrayOfByte4)) {
      fail("wrong plain text in buffer generated packet");
    }
  }
  
  public String getName()
  {
    return "PGPPBETest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPPBETest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPPBETest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */