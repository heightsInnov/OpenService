package org.bouncycastle.openpgp.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.util.test.SimpleTest;
import org.bouncycastle.util.test.UncloseableOutputStream;

public class PGPCompressionTest
  extends SimpleTest
{
  public void performTest()
    throws Exception
  {
    testCompression(0);
    testCompression(1);
    testCompression(2);
    testCompression(3);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    OutputStream localOutputStream = localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), new byte[4]);
    localOutputStream.write("hello world! !dlrow olleh".getBytes());
    localOutputStream.close();
    validateData(localByteArrayOutputStream.toByteArray());
    try
    {
      localOutputStream.close();
      localPGPCompressedDataGenerator.close();
    }
    catch (Exception localException1)
    {
      fail("Redundant close() should be ignored");
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    localOutputStream = localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream), new byte[4]);
    localOutputStream.write("hello world! !dlrow olleh".getBytes());
    localPGPCompressedDataGenerator.close();
    validateData(localByteArrayOutputStream.toByteArray());
    try
    {
      localOutputStream.close();
      localPGPCompressedDataGenerator.close();
    }
    catch (Exception localException2)
    {
      fail("Redundant close() should be ignored");
    }
  }
  
  private void validateData(byte[] paramArrayOfByte)
    throws IOException, PGPException
  {
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramArrayOfByte);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPCompressedData.getDataStream();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    if (!areEqual(localByteArrayOutputStream.toByteArray(), "hello world! !dlrow olleh".getBytes())) {
      fail("compression test failed");
    }
  }
  
  private void testCompression(int paramInt)
    throws IOException, PGPException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(paramInt);
    OutputStream localOutputStream = localPGPCompressedDataGenerator.open(new UncloseableOutputStream(localByteArrayOutputStream));
    localOutputStream.write("hello world!".getBytes());
    localOutputStream.close();
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localByteArrayOutputStream.toByteArray());
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPCompressedData.getDataStream();
    localByteArrayOutputStream.reset();
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    if (!areEqual(localByteArrayOutputStream.toByteArray(), "hello world!".getBytes())) {
      fail("compression test failed");
    }
  }
  
  public String getName()
  {
    return "PGPCompressionTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new PGPCompressionTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\test\PGPCompressionTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */