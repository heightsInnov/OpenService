package org.bouncycastle.openpgp.examples.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.openpgp.examples.ClearSignedFileProcessor;
import org.bouncycastle.openpgp.examples.DSAElGamalKeyRingGenerator;
import org.bouncycastle.openpgp.examples.KeyBasedFileProcessor;
import org.bouncycastle.openpgp.examples.KeyBasedLargeFileProcessor;
import org.bouncycastle.openpgp.examples.PBEFileProcessor;
import org.bouncycastle.openpgp.examples.RSAKeyPairGenerator;
import org.bouncycastle.openpgp.examples.SignedFileProcessor;
import org.bouncycastle.util.encoders.Base64;

public class AllTests
  extends TestCase
{
  byte[] clearSignedPublicKey = Base64.decode("mQELBEQh2+wBCAD26kte0hO6flr7Y2aetpPYutHY4qsmDPy+GwmmqVeCDkX+r1g7DuFbMhVeu0NkKDnVl7GsJ9VarYsFYyqu0NzLa9XS2qlTIkmJV+2/xKa1tzjn18fT/cnAWL88ZLCOWUr241aPVhLuIc6vpHnySpEMkCh4rvMaimnTrKwO42kgeDGd5cXfs4J4ovRcTbc4hmU2BRVsRjiYMZWWx0kkyL2zDVyaJSs4yVX7Jm4/LSR1uC/wDT0IJJuZT/gQPCMJNMEsVCziRgYkAxQK3OWojPSuv4rXpyd4Gvo6IbvyTgIskfpSkCnQtORNLIudQSuK7pW+LkL62N+ohuKdMvdxauOnAAYptBNnZ2dnZ2dnZyA8Z2dnQGdnZ2c+iQE2BBMBAgAgBQJEIdvsAhsDBgsJCAcDAgQVAggDBBYCAwECHgECF4AACgkQ4M/Ier3f9xagdAf/fbKWBjLQM8xR7JkRP4ri8YKOQPhK+VrddGUD59/wzVnvaGyl9MZE7TXFUeniQq5iXKnm22EQbYchv2Jcxyt2H9yptpzyh4tP6tEHl1C887p2J4qe7F2ATua9CzVGwXQSUbKtj2fgUZP5SsNp25guhPiZdtkf2sHMeiotmykFErzqGMrvOAUThrO63GiYsRk4hF6rcQ01d+EUVpY/sBcCxgNyOiB7a84sDtrxnX5BTEZDTEj8LvuEyEV3TMUuAjx17Eyd+9JtKzwV4v3hlTaWOvGro9nPS7YaPuG+RtufzXCUJPbPfTjTvtGOqvEzoztls8tuWA0OGHba9XfX9rfgorACAAM=");
  String crOnlyMessage = "\r hello world!\r\r- dash\r";
  String nlOnlyMessage = "\n hello world!\n\n- dash\n";
  String crNlMessage = "\r\n hello world!\r\n\r\n- dash\r\n";
  String crNlMessageTrailingWhiteSpace = "\r\n hello world! \t\r\n\r\n\r\n";
  String crOnlySignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\rHash: SHA256\r\r\r hello world!\r\r- - dash\r-----BEGIN PGP SIGNATURE-----\rVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\riQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\rWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\rFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\rhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\rdMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r=84Nd\r-----END PGP SIGNATURE-----\r";
  String nlOnlySignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\nHash: SHA256\n\n\n hello world!\n\n- - dash\n-----BEGIN PGP SIGNATURE-----\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\n\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\n=84Nd\n-----END PGP SIGNATURE-----\n";
  String crNlSignedMessage = "-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA256\r\n\r\n\r\n hello world!\r\n\r\n- - dash\r\n-----BEGIN PGP SIGNATURE-----\r\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\n\r\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\r\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\r\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\r\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\r\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r\n=84Nd\r-----END PGP SIGNATURE-----\r\n";
  String crNlSignedMessageTrailingWhiteSpace = "-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA256\r\n\r\n\r\n hello world! \t\r\n\r\n- - dash\r\n-----BEGIN PGP SIGNATURE-----\r\nVersion: GnuPG v1.4.2.1 (GNU/Linux)\r\n\r\niQEVAwUBRCNS8+DPyHq93/cWAQi6SwgAj3ItmSLr/sd/ixAQLW7/12jzEjfNmFDt\r\nWOZpJFmXj0fnMzTrOILVnbxHv2Ru+U8Y1K6nhzFSR7d28n31/XGgFtdohDEaFJpx\r\nFl+KvASKIonnpEDjFJsPIvT1/G/eCPalwO9IuxaIthmKj0z44SO1VQtmNKxdLAfK\r\n+xTnXGawXS1WUE4CQGPM45mIGSqXcYrLtJkAg3jtRa8YRUn2d7b2BtmWH+jVaVuC\r\nhNrXYv7iHFOu25yRWhUQJisvdC13D/gKIPRvARXPgPhAC2kovIy6VS8tDoyG6Hm5\r\ndMgLEGhmqsgaetVq1ZIuBZj5S4j2apBJCDpF6GBfpBOfwIZs0Tpmlw==\r\n=84Nd\r-----END PGP SIGNATURE-----\r\n";
  private PrintStream _oldOut;
  private PrintStream _oldErr;
  private ByteArrayOutputStream _currentOut;
  private ByteArrayOutputStream _currentErr;
  
  public void setUp()
    throws Exception
  {
    this._oldOut = System.out;
    this._oldErr = System.err;
    this._currentOut = new ByteArrayOutputStream();
    this._currentErr = new ByteArrayOutputStream();
    System.setOut(new PrintStream(this._currentOut));
    System.setErr(new PrintStream(this._currentErr));
  }
  
  public void tearDown()
  {
    System.setOut(this._oldOut);
    System.setErr(this._oldErr);
  }
  
  public void testRSAKeyGeneration()
    throws Exception
  {
    RSAKeyPairGenerator.main(new String[] { "test", "password" });
    createSmallTestInput();
    createLargeTestInput();
    checkSigning("bpg");
    checkKeyBasedEncryption("bpg");
    checkLargeKeyBasedEncryption("bpg");
    RSAKeyPairGenerator.main(new String[] { "-a", "test", "password" });
    checkSigning("asc");
    checkKeyBasedEncryption("asc");
    checkLargeKeyBasedEncryption("asc");
  }
  
  public void testDSAElGamaleKeyGeneration()
    throws Exception
  {
    DSAElGamalKeyRingGenerator.main(new String[] { "test", "password" });
    createSmallTestInput();
    createLargeTestInput();
    checkSigning("bpg");
    checkKeyBasedEncryption("bpg");
    checkLargeKeyBasedEncryption("bpg");
    DSAElGamalKeyRingGenerator.main(new String[] { "-a", "test", "password" });
    checkSigning("asc");
    checkKeyBasedEncryption("asc");
    checkLargeKeyBasedEncryption("asc");
  }
  
  public void testPBEEncryption()
    throws Exception
  {
    this._currentErr.reset();
    PBEFileProcessor.main(new String[] { "-e", "test.txt", "password" });
    PBEFileProcessor.main(new String[] { "-d", "test.txt.bpg", "password" });
    assertEquals("no message integrity check", getLine(this._currentErr));
    PBEFileProcessor.main(new String[] { "-e", "-i", "test.txt", "password" });
    PBEFileProcessor.main(new String[] { "-d", "test.txt.bpg", "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
    PBEFileProcessor.main(new String[] { "-e", "-ai", "test.txt", "password" });
    PBEFileProcessor.main(new String[] { "-d", "test.txt.asc", "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
  }
  
  public void testClearSigned()
    throws Exception
  {
    createTestKey(this.clearSignedPublicKey, "pub.bpg");
    checkClearSignedVerify(this.nlOnlySignedMessage);
    checkClearSignedVerify(this.crOnlySignedMessage);
    checkClearSignedVerify(this.crNlSignedMessage);
    checkClearSignedVerify(this.crNlSignedMessageTrailingWhiteSpace);
    ClearSignedFileProcessor.main(new String[] { "-v", "test.txt.asc", "pub.bpg" });
    RSAKeyPairGenerator.main(new String[] { "test", "password" });
    checkClearSigned(this.crOnlyMessage);
    checkClearSigned(this.nlOnlyMessage);
    checkClearSigned(this.crNlMessage);
    checkClearSigned(this.crNlMessageTrailingWhiteSpace);
  }
  
  private void checkClearSignedVerify(String paramString)
    throws Exception
  {
    createTestData(paramString, "test.txt.asc");
    ClearSignedFileProcessor.main(new String[] { "-v", "test.txt.asc", "pub.bpg" });
  }
  
  private void checkClearSigned(String paramString)
    throws Exception
  {
    createTestData(paramString, "test.txt");
    ClearSignedFileProcessor.main(new String[] { "-s", "test.txt", "secret.bpg", "password" });
    ClearSignedFileProcessor.main(new String[] { "-v", "test.txt.asc", "pub.bpg" });
  }
  
  private void checkSigning(String paramString)
    throws Exception
  {
    this._currentOut.reset();
    SignedFileProcessor.main(new String[] { "-s", "test.txt", "secret." + paramString, "password" });
    SignedFileProcessor.main(new String[] { "-v", "test.txt.bpg", "pub." + paramString });
    assertEquals("signature verified.", getLine(this._currentOut));
    SignedFileProcessor.main(new String[] { "-s", "-a", "test.txt", "secret." + paramString, "password" });
    SignedFileProcessor.main(new String[] { "-v", "test.txt.asc", "pub." + paramString });
    assertEquals("signature verified.", getLine(this._currentOut));
  }
  
  private void checkKeyBasedEncryption(String paramString)
    throws Exception
  {
    this._currentErr.reset();
    KeyBasedFileProcessor.main(new String[] { "-e", "test.txt", "pub." + paramString });
    KeyBasedFileProcessor.main(new String[] { "-d", "test.txt.bpg", "secret." + paramString, "password" });
    assertEquals("no message integrity check", getLine(this._currentErr));
    KeyBasedFileProcessor.main(new String[] { "-e", "-i", "test.txt", "pub." + paramString });
    KeyBasedFileProcessor.main(new String[] { "-d", "test.txt.bpg", "secret." + paramString, "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
    KeyBasedFileProcessor.main(new String[] { "-e", "-ai", "test.txt", "pub." + paramString });
    KeyBasedFileProcessor.main(new String[] { "-d", "test.txt.asc", "secret." + paramString, "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
  }
  
  private void checkLargeKeyBasedEncryption(String paramString)
    throws Exception
  {
    this._currentErr.reset();
    KeyBasedLargeFileProcessor.main(new String[] { "-e", "large.txt", "pub." + paramString });
    KeyBasedLargeFileProcessor.main(new String[] { "-d", "large.txt.bpg", "secret." + paramString, "password" });
    assertEquals("no message integrity check", getLine(this._currentErr));
    KeyBasedLargeFileProcessor.main(new String[] { "-e", "-i", "large.txt", "pub." + paramString });
    KeyBasedLargeFileProcessor.main(new String[] { "-d", "large.txt.bpg", "secret." + paramString, "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
    KeyBasedLargeFileProcessor.main(new String[] { "-e", "-ai", "large.txt", "pub." + paramString });
    KeyBasedLargeFileProcessor.main(new String[] { "-d", "large.txt.asc", "secret." + paramString, "password" });
    assertEquals("message integrity check passed", getLine(this._currentErr));
  }
  
  private void createSmallTestInput()
    throws IOException
  {
    BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter("test.txt"));
    localBufferedWriter.write("hello world!");
    localBufferedWriter.newLine();
    localBufferedWriter.close();
  }
  
  private void createLargeTestInput()
    throws IOException
  {
    BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter("large.txt"));
    for (int i = 0; i != 2000; i++)
    {
      localBufferedWriter.write("hello world!");
      localBufferedWriter.newLine();
    }
    localBufferedWriter.close();
  }
  
  private void createTestData(String paramString1, String paramString2)
    throws IOException
  {
    BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(paramString2));
    localBufferedWriter.write(paramString1);
    localBufferedWriter.close();
  }
  
  private void createTestKey(byte[] paramArrayOfByte, String paramString)
    throws IOException
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramString);
    localFileOutputStream.write(paramArrayOfByte);
    localFileOutputStream.close();
  }
  
  private String getLine(ByteArrayOutputStream paramByteArrayOutputStream)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(paramByteArrayOutputStream.toByteArray())));
    paramByteArrayOutputStream.reset();
    return localBufferedReader.readLine();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
  {
    TestSuite localTestSuite = new TestSuite("OpenPGP Example Tests");
    localTestSuite.addTestSuite(AllTests.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openpgp\examples\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */