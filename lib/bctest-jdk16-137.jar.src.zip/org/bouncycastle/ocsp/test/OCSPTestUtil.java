package org.bouncycastle.ocsp.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;
import javax.crypto.KeyGenerator;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.x509.X509V3CertificateGenerator;

public class OCSPTestUtil
{
  public static SecureRandom rand;
  public static KeyPairGenerator kpg;
  public static KeyPairGenerator eckpg;
  public static KeyGenerator desede128kg;
  public static KeyGenerator desede192kg;
  public static KeyGenerator rc240kg;
  public static KeyGenerator rc264kg;
  public static KeyGenerator rc2128kg;
  public static BigInteger serialNumber;
  public static final boolean DEBUG = true;
  
  public static KeyPair makeKeyPair()
  {
    return kpg.generateKeyPair();
  }
  
  public static KeyPair makeECKeyPair()
  {
    return eckpg.generateKeyPair();
  }
  
  public static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, false);
  }
  
  public static X509Certificate makeECDSACertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    return makeECDSACertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, false);
  }
  
  public static X509Certificate makeCACertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, true);
  }
  
  public static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2, boolean paramBoolean)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, "MD5withRSA", paramBoolean);
  }
  
  public static X509Certificate makeECDSACertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2, boolean paramBoolean)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, "SHA1WithECDSA", paramBoolean);
  }
  
  public static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2, String paramString3, boolean paramBoolean)
    throws GeneralSecurityException, IOException
  {
    PublicKey localPublicKey1 = paramKeyPair1.getPublic();
    PrivateKey localPrivateKey = paramKeyPair2.getPrivate();
    PublicKey localPublicKey2 = paramKeyPair2.getPublic();
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.reset();
    localX509V3CertificateGenerator.setSerialNumber(allocateSerialNumber());
    localX509V3CertificateGenerator.setIssuerDN(new X509Name(paramString2));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis()));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 8640000000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Name(paramString1));
    localX509V3CertificateGenerator.setPublicKey(localPublicKey1);
    localX509V3CertificateGenerator.setSignatureAlgorithm(paramString3);
    localX509V3CertificateGenerator.addExtension(X509Extensions.SubjectKeyIdentifier, false, createSubjectKeyId(localPublicKey1));
    localX509V3CertificateGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, createAuthorityKeyId(localPublicKey2));
    localX509V3CertificateGenerator.addExtension(X509Extensions.BasicConstraints, false, new BasicConstraints(paramBoolean));
    X509Certificate localX509Certificate = localX509V3CertificateGenerator.generateX509Certificate(localPrivateKey);
    localX509Certificate.checkValidity(new Date());
    localX509Certificate.verify(localPublicKey2);
    return localX509Certificate;
  }
  
  private static AuthorityKeyIdentifier createAuthorityKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new AuthorityKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  private static SubjectKeyIdentifier createSubjectKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new SubjectKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  private static BigInteger allocateSerialNumber()
  {
    BigInteger localBigInteger = serialNumber;
    serialNumber = serialNumber.add(BigInteger.ONE);
    return localBigInteger;
  }
  
  static
  {
    try
    {
      rand = new SecureRandom();
      kpg = KeyPairGenerator.getInstance("RSA", "BC");
      kpg.initialize(1024, rand);
      serialNumber = new BigInteger("1");
      eckpg = KeyPairGenerator.getInstance("ECDSA", "BC");
      eckpg.initialize(192, rand);
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException.toString());
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\ocsp\test\OCSPTestUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */