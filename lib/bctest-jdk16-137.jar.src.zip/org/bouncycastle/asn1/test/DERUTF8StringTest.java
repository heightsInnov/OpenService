package org.bouncycastle.asn1.test;

import java.io.PrintStream;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class DERUTF8StringTest
  implements Test
{
  private static final char[] glyph1_utf16 = { 55297, 56320 };
  private static final byte[] glyph1_utf8 = { -16, -112, -112, Byte.MIN_VALUE };
  private static final char[] glyph2_utf16 = { '東' };
  private static final byte[] glyph2_utf8 = { -26, -99, -79 };
  private static final char[] glyph3_utf16 = { 'ß' };
  private static final byte[] glyph3_utf8 = { -61, -97 };
  private static final char[] glyph4_utf16 = { 'A' };
  private static final byte[] glyph4_utf8 = { 65 };
  private static final byte[][] glyphs_utf8 = { glyph1_utf8, glyph2_utf8, glyph3_utf8, glyph4_utf8 };
  private static final char[][] glyphs_utf16 = { glyph1_utf16, glyph2_utf16, glyph3_utf16, glyph4_utf16 };
  
  public TestResult perform()
  {
    try
    {
      for (int i = 0; i < glyphs_utf16.length; i++)
      {
        String str = new String(glyphs_utf16[i]);
        byte[] arrayOfByte1 = new DERUTF8String(str).getEncoded();
        byte[] arrayOfByte2 = new byte[arrayOfByte1.length - 2];
        System.arraycopy(arrayOfByte1, 2, arrayOfByte2, 0, arrayOfByte1.length - 2);
        byte[] arrayOfByte3 = DERUTF8String.getInstance(new DEROctetString(arrayOfByte2)).getEncoded();
        if (!Arrays.areEqual(arrayOfByte1, arrayOfByte3)) {
          return new SimpleTestResult(false, getName() + ": failed UTF-8 encoding and decoding");
        }
        if (!Arrays.areEqual(arrayOfByte2, glyphs_utf8[i])) {
          return new SimpleTestResult(false, getName() + ": failed UTF-8 encoding and decoding");
        }
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": failed with Exception " + localException.getMessage());
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "DERUTF8String";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    DERUTF8StringTest localDERUTF8StringTest = new DERUTF8StringTest();
    TestResult localTestResult = localDERUTF8StringTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\DERUTF8StringTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */