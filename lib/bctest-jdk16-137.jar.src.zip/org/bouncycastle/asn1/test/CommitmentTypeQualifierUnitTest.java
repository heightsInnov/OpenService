package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.esf.CommitmentTypeIdentifier;
import org.bouncycastle.asn1.esf.CommitmentTypeQualifier;
import org.bouncycastle.util.test.SimpleTest;

public class CommitmentTypeQualifierUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "CommitmentTypeQualifier";
  }
  
  public void performTest()
    throws Exception
  {
    CommitmentTypeQualifier localCommitmentTypeQualifier = new CommitmentTypeQualifier(CommitmentTypeIdentifier.proofOfOrigin);
    checkConstruction(localCommitmentTypeQualifier, CommitmentTypeIdentifier.proofOfOrigin, null);
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier("1.2");
    localCommitmentTypeQualifier = new CommitmentTypeQualifier(CommitmentTypeIdentifier.proofOfOrigin, localDERObjectIdentifier);
    checkConstruction(localCommitmentTypeQualifier, CommitmentTypeIdentifier.proofOfOrigin, localDERObjectIdentifier);
    localCommitmentTypeQualifier = CommitmentTypeQualifier.getInstance(null);
    if (localCommitmentTypeQualifier != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      CommitmentTypeQualifier.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(CommitmentTypeQualifier paramCommitmentTypeQualifier, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
    throws IOException
  {
    checkStatement(paramCommitmentTypeQualifier, paramDERObjectIdentifier, paramASN1Encodable);
    paramCommitmentTypeQualifier = CommitmentTypeQualifier.getInstance(paramCommitmentTypeQualifier);
    checkStatement(paramCommitmentTypeQualifier, paramDERObjectIdentifier, paramASN1Encodable);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramCommitmentTypeQualifier.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramCommitmentTypeQualifier = CommitmentTypeQualifier.getInstance(localASN1Sequence);
    checkStatement(paramCommitmentTypeQualifier, paramDERObjectIdentifier, paramASN1Encodable);
  }
  
  private void checkStatement(CommitmentTypeQualifier paramCommitmentTypeQualifier, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
  {
    if (!paramCommitmentTypeQualifier.getCommitmentTypeIdentifier().equals(paramDERObjectIdentifier)) {
      fail("commitmentTypeIds don't match.");
    }
    if (paramASN1Encodable != null)
    {
      if (!paramCommitmentTypeQualifier.getQualifier().equals(paramASN1Encodable)) {
        fail("qualifiers don't match.");
      }
    }
    else if (paramCommitmentTypeQualifier.getQualifier() != null) {
      fail("qualifier found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CommitmentTypeQualifierUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\CommitmentTypeQualifierUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */