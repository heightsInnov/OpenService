package org.bouncycastle.asn1.test;

import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.x509.qualified.Iso4217CurrencyCode;
import org.bouncycastle.util.test.SimpleTest;

public class Iso4217CurrencyCodeUnitTest
  extends SimpleTest
{
  private static final String ALPHABETIC_CURRENCY_CODE = "AUD";
  private static final int NUMERIC_CURRENCY_CODE = 1;
  
  public String getName()
  {
    return "Iso4217CurrencyCode";
  }
  
  public void performTest()
    throws Exception
  {
    Iso4217CurrencyCode localIso4217CurrencyCode = new Iso4217CurrencyCode("AUD");
    checkNumeric(localIso4217CurrencyCode, "AUD");
    localIso4217CurrencyCode = Iso4217CurrencyCode.getInstance(localIso4217CurrencyCode);
    checkNumeric(localIso4217CurrencyCode, "AUD");
    DERObject localDERObject = localIso4217CurrencyCode.toASN1Object();
    localIso4217CurrencyCode = Iso4217CurrencyCode.getInstance(localDERObject);
    checkNumeric(localIso4217CurrencyCode, "AUD");
    localIso4217CurrencyCode = new Iso4217CurrencyCode(1);
    checkNumeric(localIso4217CurrencyCode, 1);
    localIso4217CurrencyCode = Iso4217CurrencyCode.getInstance(localIso4217CurrencyCode);
    checkNumeric(localIso4217CurrencyCode, 1);
    localDERObject = localIso4217CurrencyCode.toASN1Object();
    localIso4217CurrencyCode = Iso4217CurrencyCode.getInstance(localDERObject);
    checkNumeric(localIso4217CurrencyCode, 1);
    localIso4217CurrencyCode = Iso4217CurrencyCode.getInstance(null);
    if (localIso4217CurrencyCode != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      Iso4217CurrencyCode.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      new Iso4217CurrencyCode("ABCD");
      fail("constructor failed to detect out of range currencycode.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
    try
    {
      new Iso4217CurrencyCode(0);
      fail("constructor failed to detect out of range small numeric code.");
    }
    catch (IllegalArgumentException localIllegalArgumentException3) {}
    try
    {
      new Iso4217CurrencyCode(1000);
      fail("constructor failed to detect out of range large numeric code.");
    }
    catch (IllegalArgumentException localIllegalArgumentException4) {}
  }
  
  private void checkNumeric(Iso4217CurrencyCode paramIso4217CurrencyCode, String paramString)
  {
    if (!paramIso4217CurrencyCode.isAlphabetic()) {
      fail("non-alphabetic code found when one expected.");
    }
    if (!paramIso4217CurrencyCode.getAlphabetic().equals(paramString)) {
      fail("string codes don't match.");
    }
  }
  
  private void checkNumeric(Iso4217CurrencyCode paramIso4217CurrencyCode, int paramInt)
  {
    if (paramIso4217CurrencyCode.isAlphabetic()) {
      fail("alphabetic code found when one not expected.");
    }
    if (paramIso4217CurrencyCode.getNumeric() != paramInt) {
      fail("numeric codes don't match.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new Iso4217CurrencyCodeUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\Iso4217CurrencyCodeUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */