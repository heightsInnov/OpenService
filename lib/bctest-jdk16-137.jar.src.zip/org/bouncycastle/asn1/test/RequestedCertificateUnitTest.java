package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.isismtt.ocsp.RequestedCertificate;
import org.bouncycastle.asn1.x509.X509CertificateStructure;
import org.bouncycastle.util.encoders.Base64;

public class RequestedCertificateUnitTest
  extends ASN1UnitTest
{
  byte[] certBytes = Base64.decode("MIIBWzCCAQYCARgwDQYJKoZIhvcNAQEEBQAwODELMAkGA1UEBhMCQVUxDDAKBgNVBAgTA1FMRDEbMBkGA1UEAxMSU1NMZWF5L3JzYSB0ZXN0IENBMB4XDTk1MDYxOTIzMzMxMloXDTk1MDcxNzIzMzMxMlowOjELMAkGA1UEBhMCQVUxDDAKBgNVBAgTA1FMRDEdMBsGA1UEAxMUU1NMZWF5L3JzYSB0ZXN0IGNlcnQwXDANBgkqhkiG9w0BAQEFAANLADBIAkEAqtt6qS5GTxVxGZYWa0/4u+IwHf7p2LNZbcPBp9/OfIcYAXBQn8hO/Re1uwLKXdCjIoaGs4DLdG88rkzfyK5dPQIDAQABMAwGCCqGSIb3DQIFBQADQQAEWc7EcF8po2/ZO6kNCwK/ICH6DobgLekA5lSLr5EvuioZniZp5lFzAw4+YzPQ7XKJzl9HYIMxATFyqSiD9jsx");
  
  public String getName()
  {
    return "RequestedCertificate";
  }
  
  public void performTest()
    throws Exception
  {
    int i = 1;
    byte[] arrayOfByte = new byte[20];
    X509CertificateStructure localX509CertificateStructure = new X509CertificateStructure((ASN1Sequence)new ASN1InputStream(this.certBytes).readObject());
    RequestedCertificate localRequestedCertificate = new RequestedCertificate(i, arrayOfByte);
    checkConstruction(localRequestedCertificate, i, arrayOfByte, null);
    localRequestedCertificate = new RequestedCertificate(localX509CertificateStructure);
    checkConstruction(localRequestedCertificate, -1, null, localX509CertificateStructure);
    localRequestedCertificate = RequestedCertificate.getInstance(null);
    if (localRequestedCertificate != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      RequestedCertificate.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(RequestedCertificate paramRequestedCertificate, int paramInt, byte[] paramArrayOfByte, X509CertificateStructure paramX509CertificateStructure)
    throws IOException
  {
    checkValues(paramRequestedCertificate, paramInt, paramArrayOfByte, paramX509CertificateStructure);
    paramRequestedCertificate = RequestedCertificate.getInstance(paramRequestedCertificate);
    checkValues(paramRequestedCertificate, paramInt, paramArrayOfByte, paramX509CertificateStructure);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramRequestedCertificate.toASN1Object().getEncoded());
    DERObject localDERObject = localASN1InputStream.readObject();
    paramRequestedCertificate = RequestedCertificate.getInstance(localDERObject);
    checkValues(paramRequestedCertificate, paramInt, paramArrayOfByte, paramX509CertificateStructure);
  }
  
  private void checkValues(RequestedCertificate paramRequestedCertificate, int paramInt, byte[] paramArrayOfByte, X509CertificateStructure paramX509CertificateStructure)
    throws IOException
  {
    checkMandatoryField("certType", paramInt, paramRequestedCertificate.getType());
    if (paramRequestedCertificate.getType() == -1) {
      checkMandatoryField("certificate", paramX509CertificateStructure.getEncoded(), paramRequestedCertificate.getCertificateBytes());
    } else {
      checkMandatoryField("certificateOctets", paramArrayOfByte, paramRequestedCertificate.getCertificateBytes());
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new RequestedCertificateUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\RequestedCertificateUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */