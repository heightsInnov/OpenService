package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.esf.CommitmentTypeIdentifier;
import org.bouncycastle.asn1.esf.CommitmentTypeIndication;
import org.bouncycastle.util.test.SimpleTest;

public class CommitmentTypeIndicationUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "CommitmentTypeIndication";
  }
  
  public void performTest()
    throws Exception
  {
    CommitmentTypeIndication localCommitmentTypeIndication = new CommitmentTypeIndication(CommitmentTypeIdentifier.proofOfOrigin);
    checkConstruction(localCommitmentTypeIndication, CommitmentTypeIdentifier.proofOfOrigin, null);
    DERSequence localDERSequence = new DERSequence(new DERObjectIdentifier("1.2"));
    localCommitmentTypeIndication = new CommitmentTypeIndication(CommitmentTypeIdentifier.proofOfOrigin, localDERSequence);
    checkConstruction(localCommitmentTypeIndication, CommitmentTypeIdentifier.proofOfOrigin, localDERSequence);
    localCommitmentTypeIndication = CommitmentTypeIndication.getInstance(null);
    if (localCommitmentTypeIndication != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      CommitmentTypeIndication.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(CommitmentTypeIndication paramCommitmentTypeIndication, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
    throws IOException
  {
    checkStatement(paramCommitmentTypeIndication, paramDERObjectIdentifier, paramASN1Encodable);
    paramCommitmentTypeIndication = CommitmentTypeIndication.getInstance(paramCommitmentTypeIndication);
    checkStatement(paramCommitmentTypeIndication, paramDERObjectIdentifier, paramASN1Encodable);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramCommitmentTypeIndication.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramCommitmentTypeIndication = CommitmentTypeIndication.getInstance(localASN1Sequence);
    checkStatement(paramCommitmentTypeIndication, paramDERObjectIdentifier, paramASN1Encodable);
  }
  
  private void checkStatement(CommitmentTypeIndication paramCommitmentTypeIndication, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
  {
    if (!paramCommitmentTypeIndication.getCommitmentTypeId().equals(paramDERObjectIdentifier)) {
      fail("commitmentTypeIds don't match.");
    }
    if (paramASN1Encodable != null)
    {
      if (!paramCommitmentTypeIndication.getCommitmentTypeQualifier().equals(paramASN1Encodable)) {
        fail("qualifiers don't match.");
      }
    }
    else if (paramCommitmentTypeIndication.getCommitmentTypeQualifier() != null) {
      fail("qualifier found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CommitmentTypeIndicationUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\CommitmentTypeIndicationUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */