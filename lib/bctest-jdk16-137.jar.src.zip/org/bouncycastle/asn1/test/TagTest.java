package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERApplicationSpecific;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class TagTest
  extends SimpleTest
{
  byte[] longTagged = Base64.decode("ZSRzIp8gEEZFRENCQTk4NzY1NDMyMTCfIQwyMDA2MDQwMTEyMzSUCCAFERVzA4kCAHEXGBkalAggBRcYGRqUCCAFZS6QAkRFkQlURUNITklLRVKSBQECAwQFkxAREhMUFRYXGBkalAggBREVcwOJAgBxFxgZGpQIIAUXGBkalAggBWUukAJERZEJVEVDSE5JS0VSkgUBAgMEBZMQERITFBUWFxgZGpQIIAURFXMDiQIAcRcYGRqUCCAFFxgZGpQIIAVlLpACREWRCVRFQ0hOSUtFUpIFAQIDBAWTEBESExQVFhcYGRqUCCAFERVzA4kCAHEXGBkalAggBRcYGRqUCCAFFxgZGpQIIAUXGBkalAg=");
  byte[] longAppSpecificTag = Hex.decode("5F610101");
  
  public String getName()
  {
    return "Tag";
  }
  
  public void performTest()
    throws IOException
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(this.longTagged);
    DERApplicationSpecific localDERApplicationSpecific = (DERApplicationSpecific)localASN1InputStream.readObject();
    localASN1InputStream = new ASN1InputStream(localDERApplicationSpecific.getContents());
    localDERApplicationSpecific = (DERApplicationSpecific)localASN1InputStream.readObject();
    localASN1InputStream = new ASN1InputStream(localDERApplicationSpecific.getContents());
    ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localASN1InputStream.readObject();
    if (localASN1TaggedObject.getTagNo() != 32) {
      fail("unexpected tag value found - not 32");
    }
    localASN1TaggedObject = (ASN1TaggedObject)localASN1InputStream.readObject();
    if (localASN1TaggedObject.getTagNo() != 33) {
      fail("unexpected tag value found - not 32");
    }
    localASN1InputStream = new ASN1InputStream(this.longAppSpecificTag);
    localDERApplicationSpecific = (DERApplicationSpecific)localASN1InputStream.readObject();
    if (localDERApplicationSpecific.getApplicationTag() != 97) {
      fail("incorrect tag number read");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new TagTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\TagTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */