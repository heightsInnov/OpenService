package org.bouncycastle.asn1.test;

import java.io.IOException;
import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.x500.DirectoryString;
import org.bouncycastle.asn1.x509.sigi.NameOrPseudonym;
import org.bouncycastle.asn1.x509.sigi.PersonalData;

public class PersonalDataUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "PersonalData";
  }
  
  public void performTest()
    throws Exception
  {
    NameOrPseudonym localNameOrPseudonym = new NameOrPseudonym("pseudonym");
    BigInteger localBigInteger = BigInteger.valueOf(10L);
    DERGeneralizedTime localDERGeneralizedTime = new DERGeneralizedTime("20070315173729Z");
    DirectoryString localDirectoryString1 = new DirectoryString("placeOfBirth");
    String str = "M";
    DirectoryString localDirectoryString2 = new DirectoryString("address");
    PersonalData localPersonalData = new PersonalData(localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, str, localDirectoryString2);
    checkConstruction(localPersonalData, localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, str, localDirectoryString2);
    localPersonalData = new PersonalData(localNameOrPseudonym, null, localDERGeneralizedTime, localDirectoryString1, str, localDirectoryString2);
    checkConstruction(localPersonalData, localNameOrPseudonym, null, localDERGeneralizedTime, localDirectoryString1, str, localDirectoryString2);
    localPersonalData = new PersonalData(localNameOrPseudonym, localBigInteger, null, localDirectoryString1, str, localDirectoryString2);
    checkConstruction(localPersonalData, localNameOrPseudonym, localBigInteger, null, localDirectoryString1, str, localDirectoryString2);
    localPersonalData = new PersonalData(localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, null, str, localDirectoryString2);
    checkConstruction(localPersonalData, localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, null, str, localDirectoryString2);
    localPersonalData = new PersonalData(localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, null, localDirectoryString2);
    checkConstruction(localPersonalData, localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, null, localDirectoryString2);
    localPersonalData = new PersonalData(localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, str, null);
    checkConstruction(localPersonalData, localNameOrPseudonym, localBigInteger, localDERGeneralizedTime, localDirectoryString1, str, null);
    localPersonalData = PersonalData.getInstance(null);
    if (localPersonalData != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      PersonalData.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(PersonalData paramPersonalData, NameOrPseudonym paramNameOrPseudonym, BigInteger paramBigInteger, DERGeneralizedTime paramDERGeneralizedTime, DirectoryString paramDirectoryString1, String paramString, DirectoryString paramDirectoryString2)
    throws IOException
  {
    checkValues(paramPersonalData, paramNameOrPseudonym, paramBigInteger, paramDERGeneralizedTime, paramDirectoryString1, paramString, paramDirectoryString2);
    paramPersonalData = PersonalData.getInstance(paramPersonalData);
    checkValues(paramPersonalData, paramNameOrPseudonym, paramBigInteger, paramDERGeneralizedTime, paramDirectoryString1, paramString, paramDirectoryString2);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramPersonalData.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramPersonalData = PersonalData.getInstance(localASN1Sequence);
    checkValues(paramPersonalData, paramNameOrPseudonym, paramBigInteger, paramDERGeneralizedTime, paramDirectoryString1, paramString, paramDirectoryString2);
  }
  
  private void checkValues(PersonalData paramPersonalData, NameOrPseudonym paramNameOrPseudonym, BigInteger paramBigInteger, DERGeneralizedTime paramDERGeneralizedTime, DirectoryString paramDirectoryString1, String paramString, DirectoryString paramDirectoryString2)
  {
    checkMandatoryField("nameOrPseudonym", paramNameOrPseudonym, paramPersonalData.getNameOrPseudonym());
    checkOptionalField("nameDistinguisher", paramBigInteger, paramPersonalData.getNameDistinguisher());
    checkOptionalField("dateOfBirth", paramDERGeneralizedTime, paramPersonalData.getDateOfBirth());
    checkOptionalField("placeOfBirth", paramDirectoryString1, paramPersonalData.getPlaceOfBirth());
    checkOptionalField("gender", paramString, paramPersonalData.getGender());
    checkOptionalField("postalAddress", paramDirectoryString2, paramPersonalData.getPostalAddress());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PersonalDataUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\PersonalDataUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */