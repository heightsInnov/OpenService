package org.bouncycastle.asn1.test;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509ExtensionsGenerator;
import org.bouncycastle.util.test.SimpleTest;

public class X509ExtensionsTest
  extends SimpleTest
{
  private static final DERObjectIdentifier OID_2 = new DERObjectIdentifier("1.2.2");
  private static final DERObjectIdentifier OID_3 = new DERObjectIdentifier("1.2.3");
  private static final DERObjectIdentifier OID_1 = new DERObjectIdentifier("1.2.1");
  
  public String getName()
  {
    return "X509Extensions";
  }
  
  public void performTest()
    throws Exception
  {
    X509ExtensionsGenerator localX509ExtensionsGenerator = new X509ExtensionsGenerator();
    localX509ExtensionsGenerator.addExtension(OID_1, true, new byte[20]);
    localX509ExtensionsGenerator.addExtension(OID_2, true, new byte[20]);
    X509Extensions localX509Extensions1 = localX509ExtensionsGenerator.generate();
    X509Extensions localX509Extensions2 = localX509ExtensionsGenerator.generate();
    if (!localX509Extensions1.equals(localX509Extensions2)) {
      fail("equals test failed");
    }
    localX509ExtensionsGenerator.reset();
    localX509ExtensionsGenerator.addExtension(OID_2, true, new byte[20]);
    localX509ExtensionsGenerator.addExtension(OID_1, true, new byte[20]);
    localX509Extensions2 = localX509ExtensionsGenerator.generate();
    if (localX509Extensions1.equals(localX509Extensions2)) {
      fail("inequality test failed");
    }
    if (!localX509Extensions1.equivalent(localX509Extensions2)) {
      fail("equivalence true failed");
    }
    localX509ExtensionsGenerator.reset();
    localX509ExtensionsGenerator.addExtension(OID_1, true, new byte[22]);
    localX509ExtensionsGenerator.addExtension(OID_2, true, new byte[20]);
    localX509Extensions2 = localX509ExtensionsGenerator.generate();
    if (localX509Extensions1.equals(localX509Extensions2)) {
      fail("inequality 1 failed");
    }
    if (localX509Extensions1.equivalent(localX509Extensions2)) {
      fail("non-equivalence 1 failed");
    }
    localX509ExtensionsGenerator.reset();
    localX509ExtensionsGenerator.addExtension(OID_3, true, new byte[20]);
    localX509ExtensionsGenerator.addExtension(OID_2, true, new byte[20]);
    localX509Extensions2 = localX509ExtensionsGenerator.generate();
    if (localX509Extensions1.equals(localX509Extensions2)) {
      fail("inequality 2 failed");
    }
    if (localX509Extensions1.equivalent(localX509Extensions2)) {
      fail("non-equivalence 2 failed");
    }
    try
    {
      localX509ExtensionsGenerator.addExtension(OID_2, true, new byte[20]);
      fail("repeated oid");
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      if (!localIllegalArgumentException.getMessage().equals("extension 1.2.2 already added")) {
        fail("wrong exception on repeated oid: " + localIllegalArgumentException.getMessage());
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new X509ExtensionsTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\X509ExtensionsTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */