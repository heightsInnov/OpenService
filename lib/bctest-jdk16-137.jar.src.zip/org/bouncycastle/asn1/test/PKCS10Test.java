package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.pkcs.CertificationRequest;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class PKCS10Test
  implements Test
{
  byte[] req1 = Base64.decode("MIHoMIGTAgEAMC4xDjAMBgNVBAMTBVRlc3QyMQ8wDQYDVQQKEwZBbmFUb20xCzAJBgNVBAYTAlNFMFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALlEt31Tzt2MlcOljvacJgzQVhmlMoqAOgqJ9Pgd3GuxZ7/WcIlgW4QCB7WZT21O1YoghwBhPDMcNGrHei9kHQkCAwEAAaAAMA0GCSqGSIb3DQEBBQUAA0EANDEI4ecNtJ3uHwGGlitNFq9WxcoZ0djbQJ5hABMotav6gtqlrwKXY2evaIrsNwkJtNdwwH18aQDUKCjOuBL38Q==");
  byte[] req2 = Base64.decode("MIIB6TCCAVICAQAwgagxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRQwEgYDVQQHEwtTYW50YSBDbGFyYTEMMAoGA1UEChMDQUJCMVEwTwYDVQQLHEhQAAAAAAAAAG8AAAAAAAAAdwAAAAAAAABlAAAAAAAAAHIAAAAAAAAAIAAAAAAAAABUAAAAAAAAABxIAAAAAAAARAAAAAAAAAAxDTALBgNVBAMTBGJsdWUwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBANETRZ+6occCOrFxNhfKIp4CmMkxwhBNb7TnnahpbM9O0r4hrBPcfYuL7u9YX/jN0YNUP+/CiT39HhSe/bikaBPDEyNsl988I8vXpiEdgxYq/+LTgGHbjRsRYCkPtmzwBbuBldNF8bV7pu0v4UScSsExmGqqDlX1TbPU8KkPU1iTAgMBAAGgADANBgkqhkiG9w0BAQQFAAOBgQAFbrs9qUwh93CtETk7DeUD5HcdCnxauo1bck44snSV6MZVOCIGaYu1501kmhEvAtVVRr6SEHwimfQDDIjnrWwYsEr/DT6tkTZAbfRd3qUu3iKjT0H0vlUZp0hJ66mINtBM84uZFBfoXiWY8M3FuAnGmvy6ah/dYtJorTxLKiGkew==");
  
  public String getName()
  {
    return "PKCS10";
  }
  
  public TestResult pkcs10Test(String paramString, byte[] paramArrayOfByte)
  {
    try
    {
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
      CertificationRequest localCertificationRequest = new CertificationRequest((ASN1Sequence)localASN1InputStream.readObject());
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
      localDEROutputStream.writeObject(localCertificationRequest.getDERObject());
      byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
      if (arrayOfByte.length != paramArrayOfByte.length) {
        return new SimpleTestResult(false, getName() + ": " + paramString + " failed length test");
      }
      for (int i = 0; i != paramArrayOfByte.length; i++) {
        if (arrayOfByte[i] != paramArrayOfByte[i]) {
          return new SimpleTestResult(false, getName() + ": " + paramString + " failed comparison test");
        }
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Exception - " + paramString + " " + localException.toString());
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult perform()
  {
    TestResult localTestResult = pkcs10Test("basic CR", this.req1);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return pkcs10Test("Universal CR", this.req2);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    PKCS10Test localPKCS10Test = new PKCS10Test();
    TestResult localTestResult = localPKCS10Test.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\PKCS10Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */