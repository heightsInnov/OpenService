package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.isismtt.x509.AdditionalInformationSyntax;
import org.bouncycastle.asn1.x500.DirectoryString;

public class AdditionalInformationSyntaxUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "AdditionalInformationSyntax";
  }
  
  public void performTest()
    throws Exception
  {
    AdditionalInformationSyntax localAdditionalInformationSyntax = new AdditionalInformationSyntax("hello world");
    checkConstruction(localAdditionalInformationSyntax, new DirectoryString("hello world"));
    localAdditionalInformationSyntax = AdditionalInformationSyntax.getInstance(null);
    if (localAdditionalInformationSyntax != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      AdditionalInformationSyntax.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(AdditionalInformationSyntax paramAdditionalInformationSyntax, DirectoryString paramDirectoryString)
    throws IOException
  {
    checkValues(paramAdditionalInformationSyntax, paramDirectoryString);
    paramAdditionalInformationSyntax = AdditionalInformationSyntax.getInstance(paramAdditionalInformationSyntax);
    checkValues(paramAdditionalInformationSyntax, paramDirectoryString);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramAdditionalInformationSyntax.toASN1Object().getEncoded());
    DERString localDERString = (DERString)localASN1InputStream.readObject();
    paramAdditionalInformationSyntax = AdditionalInformationSyntax.getInstance(localDERString);
    checkValues(paramAdditionalInformationSyntax, paramDirectoryString);
  }
  
  private void checkValues(AdditionalInformationSyntax paramAdditionalInformationSyntax, DirectoryString paramDirectoryString)
  {
    checkMandatoryField("information", paramDirectoryString, paramAdditionalInformationSyntax.getInformation());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new AdditionalInformationSyntaxUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\AdditionalInformationSyntaxUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */