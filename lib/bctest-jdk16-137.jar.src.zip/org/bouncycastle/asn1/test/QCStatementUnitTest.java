package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.qualified.QCStatement;
import org.bouncycastle.asn1.x509.qualified.RFC3739QCObjectIdentifiers;
import org.bouncycastle.asn1.x509.qualified.SemanticsInformation;
import org.bouncycastle.util.test.SimpleTest;

public class QCStatementUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "QCStatement";
  }
  
  public void performTest()
    throws Exception
  {
    QCStatement localQCStatement = new QCStatement(RFC3739QCObjectIdentifiers.id_qcs_pkixQCSyntax_v1);
    checkConstruction(localQCStatement, RFC3739QCObjectIdentifiers.id_qcs_pkixQCSyntax_v1, null);
    SemanticsInformation localSemanticsInformation = new SemanticsInformation(new DERObjectIdentifier("1.2"));
    localQCStatement = new QCStatement(RFC3739QCObjectIdentifiers.id_qcs_pkixQCSyntax_v1, localSemanticsInformation);
    checkConstruction(localQCStatement, RFC3739QCObjectIdentifiers.id_qcs_pkixQCSyntax_v1, localSemanticsInformation);
    localQCStatement = QCStatement.getInstance(null);
    if (localQCStatement != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      QCStatement.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(QCStatement paramQCStatement, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
    throws IOException
  {
    checkStatement(paramQCStatement, paramDERObjectIdentifier, paramASN1Encodable);
    paramQCStatement = QCStatement.getInstance(paramQCStatement);
    checkStatement(paramQCStatement, paramDERObjectIdentifier, paramASN1Encodable);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramQCStatement.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramQCStatement = QCStatement.getInstance(localASN1Sequence);
    checkStatement(paramQCStatement, paramDERObjectIdentifier, paramASN1Encodable);
  }
  
  private void checkStatement(QCStatement paramQCStatement, DERObjectIdentifier paramDERObjectIdentifier, ASN1Encodable paramASN1Encodable)
    throws IOException
  {
    if (!paramQCStatement.getStatementId().equals(paramDERObjectIdentifier)) {
      fail("statementIds don't match.");
    }
    if (paramASN1Encodable != null)
    {
      if (!paramQCStatement.getStatementInfo().equals(paramASN1Encodable)) {
        fail("statementInfos don't match.");
      }
    }
    else if (paramQCStatement.getStatementInfo() != null) {
      fail("statementInfo found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new QCStatementUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\QCStatementUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */