package org.bouncycastle.asn1.test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.ASN1OctetStringParser;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1StreamParser;
import org.bouncycastle.asn1.BEROctetStringGenerator;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequenceGenerator;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.CompressedDataParser;
import org.bouncycastle.asn1.cms.ContentInfoParser;

public class OctetStringTest
  extends TestCase
{
  public void testReadingWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BEROctetStringGenerator localBEROctetStringGenerator = new BEROctetStringGenerator(localByteArrayOutputStream);
    OutputStream localOutputStream = localBEROctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte[4]);
    localOutputStream.close();
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(localByteArrayOutputStream.toByteArray());
    ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localASN1StreamParser.readObject();
    InputStream localInputStream = localASN1OctetStringParser.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(8, i);
  }
  
  public void testReadingWritingZeroInLength()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BEROctetStringGenerator localBEROctetStringGenerator = new BEROctetStringGenerator(localByteArrayOutputStream);
    OutputStream localOutputStream = localBEROctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte['Ȁ']);
    localOutputStream.close();
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(localByteArrayOutputStream.toByteArray());
    ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localASN1StreamParser.readObject();
    InputStream localInputStream = localASN1OctetStringParser.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(516, i);
  }
  
  public void testReadingWritingNested()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(localByteArrayOutputStream);
    BEROctetStringGenerator localBEROctetStringGenerator1 = new BEROctetStringGenerator(localBERSequenceGenerator1.getRawOutputStream());
    OutputStream localOutputStream1 = localBEROctetStringGenerator1.getOctetOutputStream();
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localOutputStream1);
    BEROctetStringGenerator localBEROctetStringGenerator2 = new BEROctetStringGenerator(localBERSequenceGenerator2.getRawOutputStream());
    OutputStream localOutputStream2 = localBEROctetStringGenerator2.getOctetOutputStream();
    localOutputStream2.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream2.write(new byte[10]);
    localOutputStream2.close();
    localBERSequenceGenerator2.close();
    localOutputStream1.close();
    localBERSequenceGenerator1.close();
    ASN1StreamParser localASN1StreamParser1 = new ASN1StreamParser(localByteArrayOutputStream.toByteArray());
    ASN1SequenceParser localASN1SequenceParser1 = (ASN1SequenceParser)localASN1StreamParser1.readObject();
    ASN1OctetStringParser localASN1OctetStringParser1 = (ASN1OctetStringParser)localASN1SequenceParser1.readObject();
    ASN1StreamParser localASN1StreamParser2 = new ASN1StreamParser(localASN1OctetStringParser1.getOctetStream());
    ASN1SequenceParser localASN1SequenceParser2 = (ASN1SequenceParser)localASN1StreamParser2.readObject();
    ASN1OctetStringParser localASN1OctetStringParser2 = (ASN1OctetStringParser)localASN1SequenceParser2.readObject();
    InputStream localInputStream = localASN1OctetStringParser2.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(14, i);
  }
  
  public void testNestedStructure()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(localByteArrayOutputStream);
    localBERSequenceGenerator1.addObject(new DERObjectIdentifier(CMSObjectIdentifiers.compressedData.getId()));
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream(), 0, true);
    localBERSequenceGenerator2.addObject(new DERInteger(0));
    DERSequenceGenerator localDERSequenceGenerator = new DERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    localDERSequenceGenerator.addObject(new DERObjectIdentifier("1.2"));
    localDERSequenceGenerator.close();
    BERSequenceGenerator localBERSequenceGenerator3 = new BERSequenceGenerator(localBERSequenceGenerator2.getRawOutputStream());
    localBERSequenceGenerator3.addObject(new DERObjectIdentifier("1.1"));
    BEROctetStringGenerator localBEROctetStringGenerator = new BEROctetStringGenerator(localBERSequenceGenerator3.getRawOutputStream(), 0, true);
    OutputStream localOutputStream = localBEROctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte[4]);
    localOutputStream.write(new byte[20]);
    localOutputStream.close();
    localBERSequenceGenerator3.close();
    localBERSequenceGenerator2.close();
    localBERSequenceGenerator1.close();
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(localByteArrayOutputStream.toByteArray());
    ContentInfoParser localContentInfoParser1 = new ContentInfoParser((ASN1SequenceParser)localASN1StreamParser.readObject());
    CompressedDataParser localCompressedDataParser = new CompressedDataParser((ASN1SequenceParser)localContentInfoParser1.getContent(16));
    ContentInfoParser localContentInfoParser2 = localCompressedDataParser.getEncapContentInfo();
    ASN1OctetStringParser localASN1OctetStringParser = (ASN1OctetStringParser)localContentInfoParser2.getContent(4);
    InputStream localInputStream = localASN1OctetStringParser.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(28, i);
  }
  
  public static Test suite()
  {
    return new TestSuite(OctetStringTest.class);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\OctetStringTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */