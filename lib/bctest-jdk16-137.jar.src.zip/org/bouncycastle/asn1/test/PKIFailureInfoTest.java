package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.cmp.PKIFailureInfo;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class PKIFailureInfoTest
  extends SimpleTest
{
  private static final byte[] CORRECT_FAILURE_INFO = Base64.decode("AwIANQ==");
  
  public String getName()
  {
    return "PKIFailureInfo";
  }
  
  private void testEncoding()
    throws IOException
  {
    DERBitString localDERBitString = (DERBitString)new ASN1InputStream(CORRECT_FAILURE_INFO).readObject();
    PKIFailureInfo localPKIFailureInfo1 = new PKIFailureInfo(localDERBitString);
    PKIFailureInfo localPKIFailureInfo2 = new PKIFailureInfo(53);
    if (!areEqual(localPKIFailureInfo1.getDEREncoded(), localPKIFailureInfo2.getDEREncoded())) {
      fail("encoding doesn't match");
    }
  }
  
  public void performTest()
    throws IOException
  {
    BitStringConstantTester.testFlagValueCorrect(0, 128);
    BitStringConstantTester.testFlagValueCorrect(1, 64);
    BitStringConstantTester.testFlagValueCorrect(2, 32);
    BitStringConstantTester.testFlagValueCorrect(3, 16);
    BitStringConstantTester.testFlagValueCorrect(4, 8);
    BitStringConstantTester.testFlagValueCorrect(5, 4);
    BitStringConstantTester.testFlagValueCorrect(6, 2);
    BitStringConstantTester.testFlagValueCorrect(7, 1);
    BitStringConstantTester.testFlagValueCorrect(8, 32768);
    BitStringConstantTester.testFlagValueCorrect(9, 16384);
    BitStringConstantTester.testFlagValueCorrect(14, 512);
    BitStringConstantTester.testFlagValueCorrect(15, 256);
    BitStringConstantTester.testFlagValueCorrect(16, 8388608);
    BitStringConstantTester.testFlagValueCorrect(17, 4194304);
    BitStringConstantTester.testFlagValueCorrect(25, 1073741824);
    testEncoding();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PKIFailureInfoTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\PKIFailureInfoTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */