package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.RecipientKeyIdentifier;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.asn1.smime.SMIMEEncryptionKeyPreferenceAttribute;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SMIMETest
  implements Test
{
  byte[] attrBytes = Base64.decode("MDQGCSqGSIb3DQEJDzEnMCUwCgYIKoZIhvcNAwcwDgYIKoZIhvcNAwICAgCAMAcGBSsOAwIH");
  byte[] prefBytes = Base64.decode("MCwGCyqGSIb3DQEJEAILMR2hGwQIAAAAAAAAAAAYDzIwMDcwMzE1MTczNzI5Wg==");
  
  private boolean isSameAs(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public TestResult perform()
  {
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    SMIMECapabilitiesAttribute localSMIMECapabilitiesAttribute = new SMIMECapabilitiesAttribute(localSMIMECapabilityVector);
    SMIMEEncryptionKeyPreferenceAttribute localSMIMEEncryptionKeyPreferenceAttribute = new SMIMEEncryptionKeyPreferenceAttribute(new RecipientKeyIdentifier(new DEROctetString(new byte[8]), new DERGeneralizedTime("20070315173729Z"), null));
    try
    {
      if (!isSameAs(localSMIMECapabilitiesAttribute.getEncoded(), this.attrBytes)) {
        return new SimpleTestResult(false, getName() + ": Failed attr data check");
      }
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(this.attrBytes);
      ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
      DERObject localDERObject = localASN1InputStream.readObject();
      if (!localSMIMECapabilitiesAttribute.equals(localDERObject)) {
        return new SimpleTestResult(false, getName() + ": Failed equality test for attr");
      }
      if (!isSameAs(localSMIMEEncryptionKeyPreferenceAttribute.getEncoded(), this.prefBytes)) {
        return new SimpleTestResult(false, getName() + ": Failed attr data check");
      }
      localByteArrayInputStream = new ByteArrayInputStream(this.prefBytes);
      localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
      localDERObject = localASN1InputStream.readObject();
      if (!localSMIMEEncryptionKeyPreferenceAttribute.equals(localDERObject)) {
        return new SimpleTestResult(false, getName() + ": Failed equality test for pref");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Failed - exception " + localException.toString(), localException);
    }
  }
  
  public String getName()
  {
    return "SMIME";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SMIMETest localSMIMETest = new SMIMETest();
    TestResult localTestResult = localSMIMETest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\SMIMETest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */