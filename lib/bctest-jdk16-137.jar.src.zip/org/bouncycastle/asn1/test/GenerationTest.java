package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.oiw.ElGamalParameter;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.IssuingDistributionPoint;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.asn1.x509.RSAPublicKeyStructure;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.TBSCertList;
import org.bouncycastle.asn1.x509.TBSCertificateStructure;
import org.bouncycastle.asn1.x509.Time;
import org.bouncycastle.asn1.x509.V1TBSCertificateGenerator;
import org.bouncycastle.asn1.x509.V2TBSCertListGenerator;
import org.bouncycastle.asn1.x509.V3TBSCertificateGenerator;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class GenerationTest
  extends SimpleTest
{
  private byte[] v1Cert = Base64.decode("MIGtAgEBMA0GCSqGSIb3DQEBBAUAMCUxCzAJBgNVBAMMAkFVMRYwFAYDVQQKDA1Cb3VuY3kgQ2FzdGxlMB4XDTcwMDEwMTAwMDAwMVoXDTcwMDEwMTAwMDAxMlowNjELMAkGA1UEAwwCQVUxFjAUBgNVBAoMDUJvdW5jeSBDYXN0bGUxDzANBgNVBAsMBlRlc3QgMTAaMA0GCSqGSIb3DQEBAQUAAwkAMAYCAQECAQI=");
  private byte[] v3Cert = Base64.decode("MIIBSKADAgECAgECMA0GCSqGSIb3DQEBBAUAMCUxCzAJBgNVBAMMAkFVMRYwFAYDVQQKDA1Cb3VuY3kgQ2FzdGxlMB4XDTcwMDEwMTAwMDAwMVoXDTcwMDEwMTAwMDAwMlowNjELMAkGA1UEAwwCQVUxFjAUBgNVBAoMDUJvdW5jeSBDYXN0bGUxDzANBgNVBAsMBlRlc3QgMjAYMBAGBisOBwIBATAGAgEBAgECAwQAAgEDo4GVMIGSMGEGA1UdIwEB/wRXMFWAFDZPdpHPzKi7o8EJokkQU2uqCHRRoTqkODA2MQswCQYDVQQDDAJBVTEWMBQGA1UECgwNQm91bmN5IENhc3RsZTEPMA0GA1UECwwGVGVzdCAyggECMCAGA1UdDgEB/wQWBBQ2T3aRz8you6PBCaJJEFNrqgh0UTALBgNVHQ8EBAMCBBA=");
  private byte[] v3CertNullSubject = Base64.decode("MIHGoAMCAQICAQIwDQYJKoZIhvcNAQEEBQAwJTELMAkGA1UEAwwCQVUxFjAUBgNVBAoMDUJvdW5jeSBDYXN0bGUwHhcNNzAwMTAxMDAwMDAxWhcNNzAwMTAxMDAwMDAyWjAAMBgwEAYGKw4HAgEBMAYCAQECAQIDBAACAQOjSjBIMEYGA1UdEQEB/wQ8MDqkODA2MQswCQYDVQQDDAJBVTEWMBQGA1UECgwNQm91bmN5IENhc3RsZTEPMA0GA1UECwwGVGVzdCAy");
  private byte[] v2CertList = Base64.decode("MIIBRQIBATANBgkqhkiG9w0BAQUFADAlMQswCQYDVQQDDAJBVTEWMBQGA1UECgwNQm91bmN5IENhc3RsZRcNNzAwMTAxMDAwMDAwWhcNNzAwMTAxMDAwMDAyWjAkMCICAQEXDTcwMDEwMTAwMDAwMVowDjAMBgNVHRUEBQoDAIAAoIHFMIHCMGEGA1UdIwEB/wRXMFWAFDZPdpHPzKi7o8EJokkQU2uqCHRRoTqkODA2MQswCQYDVQQDDAJBVTEWMBQGA1UECgwNQm91bmN5IENhc3RsZTEPMA0GA1UECwwGVGVzdCAyggECMEMGA1UdEgQ8MDqkODA2MQswCQYDVQQDDAJBVTEWMBQGA1UECgwNQm91bmN5IENhc3RsZTEPMA0GA1UECwwGVGVzdCAzMAoGA1UdFAQDAgEBMAwGA1UdHAEB/wQCMAA=");
  
  private void tbsV1CertGen()
    throws IOException
  {
    V1TBSCertificateGenerator localV1TBSCertificateGenerator = new V1TBSCertificateGenerator();
    Date localDate1 = new Date(1000L);
    Date localDate2 = new Date(12000L);
    localV1TBSCertificateGenerator.setSerialNumber(new DERInteger(1));
    localV1TBSCertificateGenerator.setStartDate(new Time(localDate1));
    localV1TBSCertificateGenerator.setEndDate(new Time(localDate2));
    localV1TBSCertificateGenerator.setIssuer(new X509Name("CN=AU,O=Bouncy Castle"));
    localV1TBSCertificateGenerator.setSubject(new X509Name("CN=AU,O=Bouncy Castle,OU=Test 1"));
    localV1TBSCertificateGenerator.setSignature(new AlgorithmIdentifier(PKCSObjectIdentifiers.md5WithRSAEncryption, new DERNull()));
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(PKCSObjectIdentifiers.rsaEncryption, new DERNull()), new RSAPublicKeyStructure(BigInteger.valueOf(1L), BigInteger.valueOf(2L)));
    localV1TBSCertificateGenerator.setSubjectPublicKeyInfo(localSubjectPublicKeyInfo);
    TBSCertificateStructure localTBSCertificateStructure = localV1TBSCertificateGenerator.generateTBSCertificate();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localTBSCertificateStructure);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v1Cert)) {
      fail("failed v1 cert generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.v1Cert));
    DERObject localDERObject = localASN1InputStream.readObject();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localDERObject);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v1Cert)) {
      fail("failed v1 cert read back test");
    }
  }
  
  private AuthorityKeyIdentifier createAuthorityKeyId(SubjectPublicKeyInfo paramSubjectPublicKeyInfo, X509Name paramX509Name, int paramInt)
  {
    GeneralName localGeneralName = new GeneralName(paramX509Name);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(localGeneralName);
    return new AuthorityKeyIdentifier(paramSubjectPublicKeyInfo, new GeneralNames(new DERSequence(localASN1EncodableVector)), BigInteger.valueOf(paramInt));
  }
  
  private void tbsV3CertGen()
    throws IOException
  {
    V3TBSCertificateGenerator localV3TBSCertificateGenerator = new V3TBSCertificateGenerator();
    Date localDate1 = new Date(1000L);
    Date localDate2 = new Date(2000L);
    localV3TBSCertificateGenerator.setSerialNumber(new DERInteger(2));
    localV3TBSCertificateGenerator.setStartDate(new Time(localDate1));
    localV3TBSCertificateGenerator.setEndDate(new Time(localDate2));
    localV3TBSCertificateGenerator.setIssuer(new X509Name("CN=AU,O=Bouncy Castle"));
    localV3TBSCertificateGenerator.setSubject(new X509Name("CN=AU,O=Bouncy Castle,OU=Test 2"));
    localV3TBSCertificateGenerator.setSignature(new AlgorithmIdentifier(PKCSObjectIdentifiers.md5WithRSAEncryption, new DERNull()));
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(OIWObjectIdentifiers.elGamalAlgorithm, new ElGamalParameter(BigInteger.valueOf(1L), BigInteger.valueOf(2L))), new DERInteger(3));
    localV3TBSCertificateGenerator.setSubjectPublicKeyInfo(localSubjectPublicKeyInfo);
    Vector localVector = new Vector();
    Hashtable localHashtable = new Hashtable();
    localVector.addElement(X509Extensions.AuthorityKeyIdentifier);
    localVector.addElement(X509Extensions.SubjectKeyIdentifier);
    localVector.addElement(X509Extensions.KeyUsage);
    localHashtable.put(X509Extensions.AuthorityKeyIdentifier, new X509Extension(true, new DEROctetString(createAuthorityKeyId(localSubjectPublicKeyInfo, new X509Name("CN=AU,O=Bouncy Castle,OU=Test 2"), 2))));
    localHashtable.put(X509Extensions.SubjectKeyIdentifier, new X509Extension(true, new DEROctetString(new SubjectKeyIdentifier(localSubjectPublicKeyInfo))));
    localHashtable.put(X509Extensions.KeyUsage, new X509Extension(false, new DEROctetString(new KeyUsage(16))));
    X509Extensions localX509Extensions = new X509Extensions(localVector, localHashtable);
    localV3TBSCertificateGenerator.setExtensions(localX509Extensions);
    TBSCertificateStructure localTBSCertificateStructure = localV3TBSCertificateGenerator.generateTBSCertificate();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localTBSCertificateStructure);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v3Cert)) {
      fail("failed v3 cert generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.v3Cert));
    DERObject localDERObject = localASN1InputStream.readObject();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localDERObject);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v3Cert)) {
      fail("failed v3 cert read back test");
    }
  }
  
  private void tbsV3CertGenWithNullSubject()
    throws IOException
  {
    V3TBSCertificateGenerator localV3TBSCertificateGenerator = new V3TBSCertificateGenerator();
    Date localDate1 = new Date(1000L);
    Date localDate2 = new Date(2000L);
    localV3TBSCertificateGenerator.setSerialNumber(new DERInteger(2));
    localV3TBSCertificateGenerator.setStartDate(new Time(localDate1));
    localV3TBSCertificateGenerator.setEndDate(new Time(localDate2));
    localV3TBSCertificateGenerator.setIssuer(new X509Name("CN=AU,O=Bouncy Castle"));
    localV3TBSCertificateGenerator.setSignature(new AlgorithmIdentifier(PKCSObjectIdentifiers.md5WithRSAEncryption, new DERNull()));
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(OIWObjectIdentifiers.elGamalAlgorithm, new ElGamalParameter(BigInteger.valueOf(1L), BigInteger.valueOf(2L))), new DERInteger(3));
    localV3TBSCertificateGenerator.setSubjectPublicKeyInfo(localSubjectPublicKeyInfo);
    try
    {
      localV3TBSCertificateGenerator.generateTBSCertificate();
      fail("null subject not caught!");
    }
    catch (IllegalStateException localIllegalStateException)
    {
      if (!localIllegalStateException.getMessage().equals("not all mandatory fields set in V3 TBScertificate generator")) {
        fail("unexpected exception", localIllegalStateException);
      }
    }
    Vector localVector = new Vector();
    Hashtable localHashtable = new Hashtable();
    localVector.addElement(X509Extensions.SubjectAlternativeName);
    localHashtable.put(X509Extensions.SubjectAlternativeName, new X509Extension(true, new DEROctetString(new GeneralNames(new GeneralName(new X509Name("CN=AU,O=Bouncy Castle,OU=Test 2"))))));
    X509Extensions localX509Extensions = new X509Extensions(localVector, localHashtable);
    localV3TBSCertificateGenerator.setExtensions(localX509Extensions);
    TBSCertificateStructure localTBSCertificateStructure = localV3TBSCertificateGenerator.generateTBSCertificate();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localTBSCertificateStructure);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v3CertNullSubject)) {
      fail("failed v3 null sub cert generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.v3CertNullSubject));
    DERObject localDERObject = localASN1InputStream.readObject();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localDERObject);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v3CertNullSubject)) {
      fail("failed v3 null sub cert read back test");
    }
  }
  
  private void tbsV2CertListGen()
    throws IOException
  {
    V2TBSCertListGenerator localV2TBSCertListGenerator = new V2TBSCertListGenerator();
    localV2TBSCertListGenerator.setIssuer(new X509Name("CN=AU,O=Bouncy Castle"));
    localV2TBSCertListGenerator.addCRLEntry(new DERInteger(1), new Time(new Date(1000L)), 32768);
    localV2TBSCertListGenerator.setNextUpdate(new Time(new Date(2000L)));
    localV2TBSCertListGenerator.setThisUpdate(new Time(new Date(500L)));
    localV2TBSCertListGenerator.setSignature(new AlgorithmIdentifier(PKCSObjectIdentifiers.sha1WithRSAEncryption, new DERNull()));
    Vector localVector = new Vector();
    Hashtable localHashtable = new Hashtable();
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(OIWObjectIdentifiers.elGamalAlgorithm, new ElGamalParameter(BigInteger.valueOf(1L), BigInteger.valueOf(2L))), new DERInteger(3));
    localVector.addElement(X509Extensions.AuthorityKeyIdentifier);
    localVector.addElement(X509Extensions.IssuerAlternativeName);
    localVector.addElement(X509Extensions.CRLNumber);
    localVector.addElement(X509Extensions.IssuingDistributionPoint);
    localHashtable.put(X509Extensions.AuthorityKeyIdentifier, new X509Extension(true, new DEROctetString(createAuthorityKeyId(localSubjectPublicKeyInfo, new X509Name("CN=AU,O=Bouncy Castle,OU=Test 2"), 2))));
    localHashtable.put(X509Extensions.IssuerAlternativeName, new X509Extension(false, new DEROctetString(new GeneralNames(new DERSequence(new GeneralName(new X509Name("CN=AU,O=Bouncy Castle,OU=Test 3")))))));
    localHashtable.put(X509Extensions.CRLNumber, new X509Extension(false, new DEROctetString(new DERInteger(1))));
    localHashtable.put(X509Extensions.IssuingDistributionPoint, new X509Extension(true, new DEROctetString(new IssuingDistributionPoint(new DERSequence()))));
    X509Extensions localX509Extensions = new X509Extensions(localVector, localHashtable);
    localV2TBSCertListGenerator.setExtensions(localX509Extensions);
    TBSCertList localTBSCertList = localV2TBSCertListGenerator.generateTBSCertList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localTBSCertList);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v2CertList)) {
      fail("failed v2 cert list generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.v2CertList));
    DERObject localDERObject = localASN1InputStream.readObject();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localDERObject);
    if (!Arrays.areEqual(localByteArrayOutputStream.toByteArray(), this.v2CertList)) {
      fail("failed v2 cert list read back test");
    }
  }
  
  public void performTest()
    throws Exception
  {
    tbsV1CertGen();
    tbsV3CertGen();
    tbsV3CertGenWithNullSubject();
    tbsV2CertListGen();
  }
  
  public String getName()
  {
    return "Generation";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new GenerationTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\GenerationTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */