package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.x500.DirectoryString;
import org.bouncycastle.asn1.x509.sigi.NameOrPseudonym;

public class NameOrPseudonymUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "NameOrPseudonym";
  }
  
  public void performTest()
    throws Exception
  {
    String str = "pseudonym";
    DirectoryString localDirectoryString = new DirectoryString("surname");
    DERSequence localDERSequence = new DERSequence(new DirectoryString("givenName"));
    NameOrPseudonym localNameOrPseudonym = new NameOrPseudonym(str);
    checkConstruction(localNameOrPseudonym, str, null, null);
    localNameOrPseudonym = new NameOrPseudonym(localDirectoryString, localDERSequence);
    checkConstruction(localNameOrPseudonym, null, localDirectoryString, localDERSequence);
    localNameOrPseudonym = NameOrPseudonym.getInstance(null);
    if (localNameOrPseudonym != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      NameOrPseudonym.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(NameOrPseudonym paramNameOrPseudonym, String paramString, DirectoryString paramDirectoryString, ASN1Sequence paramASN1Sequence)
    throws IOException
  {
    checkValues(paramNameOrPseudonym, paramString, paramDirectoryString, paramASN1Sequence);
    paramNameOrPseudonym = NameOrPseudonym.getInstance(paramNameOrPseudonym);
    checkValues(paramNameOrPseudonym, paramString, paramDirectoryString, paramASN1Sequence);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramNameOrPseudonym.toASN1Object().getEncoded());
    Object localObject;
    if (paramDirectoryString != null)
    {
      localObject = (ASN1Sequence)localASN1InputStream.readObject();
      paramNameOrPseudonym = NameOrPseudonym.getInstance(localObject);
    }
    else
    {
      localObject = (DERString)localASN1InputStream.readObject();
      paramNameOrPseudonym = NameOrPseudonym.getInstance(localObject);
    }
    checkValues(paramNameOrPseudonym, paramString, paramDirectoryString, paramASN1Sequence);
  }
  
  private void checkValues(NameOrPseudonym paramNameOrPseudonym, String paramString, DirectoryString paramDirectoryString, ASN1Sequence paramASN1Sequence)
  {
    if (paramDirectoryString != null)
    {
      checkMandatoryField("surname", paramDirectoryString, paramNameOrPseudonym.getSurname());
      checkMandatoryField("givenName", paramASN1Sequence, new DERSequence(paramNameOrPseudonym.getGivenName()[0]));
    }
    else
    {
      checkOptionalField("pseudonym", new DirectoryString(paramString), paramNameOrPseudonym.getPseudonym());
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new NameOrPseudonymUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\NameOrPseudonymUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */