package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.util.test.SimpleTest;

public class InputStreamTest
  extends SimpleTest
{
  private static final byte[] outOfBoundsLength = { 48, -1, -1, -1, -1, -1 };
  private static final byte[] negativeLength = { 48, -124, -1, -1, -1, -1 };
  private static final byte[] outsideLimitLength = { 48, -125, 15, -1, -1 };
  
  public String getName()
  {
    return "InputStream";
  }
  
  public void performTest()
    throws Exception
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(outOfBoundsLength);
    try
    {
      localASN1InputStream.readObject();
      fail("out of bounds length not detected.");
    }
    catch (IOException localIOException1)
    {
      if (!localIOException1.getMessage().equals("DER length more than 4 bytes")) {
        fail("wrong exception: " + localIOException1.getMessage());
      }
    }
    localASN1InputStream = new ASN1InputStream(negativeLength);
    try
    {
      localASN1InputStream.readObject();
      fail("negative length not detected.");
    }
    catch (IOException localIOException2)
    {
      if (!localIOException2.getMessage().equals("corrupted steam - negative length found")) {
        fail("wrong exception: " + localIOException2.getMessage());
      }
    }
    localASN1InputStream = new ASN1InputStream(outsideLimitLength);
    try
    {
      localASN1InputStream.readObject();
      fail("outside limit length not detected.");
    }
    catch (IOException localIOException3)
    {
      if (!localIOException3.getMessage().equals("corrupted steam - out of bounds length found")) {
        fail("wrong exception: " + localIOException3.getMessage());
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new InputStreamTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\InputStreamTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */