package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERT61String;
import org.bouncycastle.asn1.DERUniversalString;
import org.bouncycastle.util.test.SimpleTest;

public class StringTest
  extends SimpleTest
{
  public String getName()
  {
    return "String";
  }
  
  public void performTest()
    throws IOException
  {
    DERBitString localDERBitString = new DERBitString(new byte[] { 1, 35, 69, 103, -119, -85, -51, -17 });
    if (!localDERBitString.getString().equals("#0309000123456789ABCDEF")) {
      fail("DERBitString.getString() result incorrect");
    }
    if (!localDERBitString.toString().equals("#0309000123456789ABCDEF")) {
      fail("DERBitString.toString() result incorrect");
    }
    localDERBitString = new DERBitString(new byte[] { -2, -36, -70, -104, 118, 84, 50, 16 });
    if (!localDERBitString.getString().equals("#030900FEDCBA9876543210")) {
      fail("DERBitString.getString() result incorrect");
    }
    if (!localDERBitString.toString().equals("#030900FEDCBA9876543210")) {
      fail("DERBitString.toString() result incorrect");
    }
    DERUniversalString localDERUniversalString = new DERUniversalString(new byte[] { 1, 35, 69, 103, -119, -85, -51, -17 });
    if (!localDERUniversalString.getString().equals("#1C080123456789ABCDEF")) {
      fail("DERUniversalString.getString() result incorrect");
    }
    if (!localDERUniversalString.toString().equals("#1C080123456789ABCDEF")) {
      fail("DERUniversalString.toString() result incorrect");
    }
    localDERUniversalString = new DERUniversalString(new byte[] { -2, -36, -70, -104, 118, 84, 50, 16 });
    if (!localDERUniversalString.getString().equals("#1C08FEDCBA9876543210")) {
      fail("DERUniversalString.getString() result incorrect");
    }
    if (!localDERUniversalString.toString().equals("#1C08FEDCBA9876543210")) {
      fail("DERUniversalString.toString() result incorrect");
    }
    byte[] arrayOfByte = { -1, -2, -3, -4, -5, -6, -7, -8 };
    String str = new String(arrayOfByte, "iso-8859-1");
    DERT61String localDERT61String = new DERT61String(arrayOfByte);
    if (!localDERT61String.getString().equals(str)) {
      fail("DERT61String.getString() result incorrect");
    }
    if (!localDERT61String.toString().equals(str)) {
      fail("DERT61String.toString() result incorrect");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new StringTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\StringTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */