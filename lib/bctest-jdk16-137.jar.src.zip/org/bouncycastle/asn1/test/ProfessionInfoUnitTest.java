package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.isismtt.x509.NamingAuthority;
import org.bouncycastle.asn1.isismtt.x509.ProcurationSyntax;
import org.bouncycastle.asn1.isismtt.x509.ProfessionInfo;
import org.bouncycastle.asn1.x500.DirectoryString;

public class ProfessionInfoUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "ProfessionInfo";
  }
  
  public void performTest()
    throws Exception
  {
    NamingAuthority localNamingAuthority = new NamingAuthority(new DERObjectIdentifier("1.2.3"), "url", new DirectoryString("fred"));
    DirectoryString[] arrayOfDirectoryString = { new DirectoryString("substitution") };
    DERObjectIdentifier[] arrayOfDERObjectIdentifier = { new DERObjectIdentifier("1.2.3") };
    String str = "12345";
    DEROctetString localDEROctetString = new DEROctetString(new byte[20]);
    ProfessionInfo localProfessionInfo = new ProfessionInfo(localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, localDEROctetString);
    checkConstruction(localProfessionInfo, localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, localDEROctetString);
    localProfessionInfo = new ProfessionInfo(null, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, localDEROctetString);
    checkConstruction(localProfessionInfo, null, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, localDEROctetString);
    localProfessionInfo = new ProfessionInfo(localNamingAuthority, arrayOfDirectoryString, null, str, localDEROctetString);
    checkConstruction(localProfessionInfo, localNamingAuthority, arrayOfDirectoryString, null, str, localDEROctetString);
    localProfessionInfo = new ProfessionInfo(localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, null, localDEROctetString);
    checkConstruction(localProfessionInfo, localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, null, localDEROctetString);
    localProfessionInfo = new ProfessionInfo(localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, null);
    checkConstruction(localProfessionInfo, localNamingAuthority, arrayOfDirectoryString, arrayOfDERObjectIdentifier, str, null);
    localProfessionInfo = ProfessionInfo.getInstance(null);
    if (localProfessionInfo != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      ProcurationSyntax.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(ProfessionInfo paramProfessionInfo, NamingAuthority paramNamingAuthority, DirectoryString[] paramArrayOfDirectoryString, DERObjectIdentifier[] paramArrayOfDERObjectIdentifier, String paramString, DEROctetString paramDEROctetString)
    throws IOException
  {
    checkValues(paramProfessionInfo, paramNamingAuthority, paramArrayOfDirectoryString, paramArrayOfDERObjectIdentifier, paramString, paramDEROctetString);
    paramProfessionInfo = ProfessionInfo.getInstance(paramProfessionInfo);
    checkValues(paramProfessionInfo, paramNamingAuthority, paramArrayOfDirectoryString, paramArrayOfDERObjectIdentifier, paramString, paramDEROctetString);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramProfessionInfo.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramProfessionInfo = ProfessionInfo.getInstance(localASN1Sequence);
    checkValues(paramProfessionInfo, paramNamingAuthority, paramArrayOfDirectoryString, paramArrayOfDERObjectIdentifier, paramString, paramDEROctetString);
  }
  
  private void checkValues(ProfessionInfo paramProfessionInfo, NamingAuthority paramNamingAuthority, DirectoryString[] paramArrayOfDirectoryString, DERObjectIdentifier[] paramArrayOfDERObjectIdentifier, String paramString, DEROctetString paramDEROctetString)
  {
    checkOptionalField("auth", paramNamingAuthority, paramProfessionInfo.getNamingAuthority());
    checkMandatoryField("professionItems", paramArrayOfDirectoryString[0], paramProfessionInfo.getProfessionItems()[0]);
    if (paramArrayOfDERObjectIdentifier != null) {
      checkOptionalField("professionOids", paramArrayOfDERObjectIdentifier[0], paramProfessionInfo.getProfessionOIDs()[0]);
    }
    checkOptionalField("registrationNumber", paramString, paramProfessionInfo.getRegistrationNumber());
    checkOptionalField("addProfessionInfo", paramDEROctetString, paramProfessionInfo.getAddProfessionInfo());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ProfessionInfoUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\ProfessionInfoUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */