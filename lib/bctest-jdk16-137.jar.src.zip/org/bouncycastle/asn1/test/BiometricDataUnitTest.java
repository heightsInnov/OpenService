package org.bouncycastle.asn1.test;

import java.util.Random;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.qualified.BiometricData;
import org.bouncycastle.asn1.x509.qualified.TypeOfBiometricData;
import org.bouncycastle.util.test.SimpleTest;

public class BiometricDataUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "BiometricData";
  }
  
  private byte[] generateHash()
  {
    Random localRandom = new Random();
    byte[] arrayOfByte = new byte[20];
    localRandom.nextBytes(arrayOfByte);
    return arrayOfByte;
  }
  
  public void performTest()
    throws Exception
  {
    TypeOfBiometricData localTypeOfBiometricData = new TypeOfBiometricData(1);
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1, new DERNull());
    DEROctetString localDEROctetString = new DEROctetString(generateHash());
    BiometricData localBiometricData = new BiometricData(localTypeOfBiometricData, localAlgorithmIdentifier, localDEROctetString);
    checkConstruction(localBiometricData, localTypeOfBiometricData, localAlgorithmIdentifier, localDEROctetString, null);
    DERIA5String localDERIA5String = new DERIA5String("http://test");
    localBiometricData = new BiometricData(localTypeOfBiometricData, localAlgorithmIdentifier, localDEROctetString, localDERIA5String);
    checkConstruction(localBiometricData, localTypeOfBiometricData, localAlgorithmIdentifier, localDEROctetString, localDERIA5String);
    localBiometricData = BiometricData.getInstance(null);
    if (localBiometricData != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      BiometricData.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(BiometricData paramBiometricData, TypeOfBiometricData paramTypeOfBiometricData, AlgorithmIdentifier paramAlgorithmIdentifier, ASN1OctetString paramASN1OctetString, DERIA5String paramDERIA5String)
    throws Exception
  {
    checkValues(paramBiometricData, paramTypeOfBiometricData, paramAlgorithmIdentifier, paramASN1OctetString, paramDERIA5String);
    paramBiometricData = BiometricData.getInstance(paramBiometricData);
    checkValues(paramBiometricData, paramTypeOfBiometricData, paramAlgorithmIdentifier, paramASN1OctetString, paramDERIA5String);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramBiometricData.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramBiometricData = BiometricData.getInstance(localASN1Sequence);
    checkValues(paramBiometricData, paramTypeOfBiometricData, paramAlgorithmIdentifier, paramASN1OctetString, paramDERIA5String);
  }
  
  private void checkValues(BiometricData paramBiometricData, TypeOfBiometricData paramTypeOfBiometricData, AlgorithmIdentifier paramAlgorithmIdentifier, ASN1OctetString paramASN1OctetString, DERIA5String paramDERIA5String)
  {
    if (!paramBiometricData.getTypeOfBiometricData().equals(paramTypeOfBiometricData)) {
      fail("types don't match.");
    }
    if (!paramBiometricData.getHashAlgorithm().equals(paramAlgorithmIdentifier)) {
      fail("hash algorithms don't match.");
    }
    if (!paramBiometricData.getBiometricDataHash().equals(paramASN1OctetString)) {
      fail("hash algorithms don't match.");
    }
    if (paramDERIA5String != null)
    {
      if (!paramBiometricData.getSourceDataUri().equals(paramDERIA5String)) {
        fail("data uris don't match.");
      }
    }
    else if (paramBiometricData.getSourceDataUri() != null) {
      fail("data uri found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new BiometricDataUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\BiometricDataUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */