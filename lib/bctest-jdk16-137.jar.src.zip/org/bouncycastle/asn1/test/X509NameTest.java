package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DEREncodableVector;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.x509.X509DefaultEntryConverter;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class X509NameTest
  extends SimpleTest
{
  String[] subjects = { "C=AU,ST=Victoria,L=South Melbourne,O=Connect 4 Pty Ltd,OU=Webserver Team,CN=www2.connect4.com.au,E=webmaster@connect4.com.au", "C=AU,ST=Victoria,L=South Melbourne,O=Connect 4 Pty Ltd,OU=Certificate Authority,CN=Connect 4 CA,E=webmaster@connect4.com.au", "C=AU,ST=QLD,CN=SSLeay/rsa test cert", "C=US,O=National Aeronautics and Space Administration,SERIALNUMBER=16+CN=Steve Schoch", "E=cooke@issl.atl.hp.com,C=US,OU=Hewlett Packard Company (ISSL),CN=Paul A. Cooke", "O=Sun Microsystems Inc,CN=store.sun.com", "unstructuredAddress=192.168.1.33,unstructuredName=pixfirewall.ciscopix.com,CN=pixfirewall.ciscopix.com" };
  
  public String getName()
  {
    return "X509Name";
  }
  
  private static X509Name fromBytes(byte[] paramArrayOfByte)
    throws IOException
  {
    return X509Name.getInstance(new ASN1InputStream(new ByteArrayInputStream(paramArrayOfByte)).readObject());
  }
  
  private DEREncodable createEntryValue(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(paramDERObjectIdentifier, paramString);
    X509Name localX509Name = new X509Name(localHashtable);
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localX509Name.getDERObject();
    ASN1Set localASN1Set = (ASN1Set)localASN1Sequence.getObjectAt(0);
    localASN1Sequence = (ASN1Sequence)localASN1Set.getObjectAt(0);
    return localASN1Sequence.getObjectAt(1);
  }
  
  private DEREncodable createEntryValueFromString(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(paramDERObjectIdentifier, paramString);
    X509Name localX509Name = new X509Name(new X509Name(localHashtable).toString());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localX509Name.getDERObject();
    ASN1Set localASN1Set = (ASN1Set)localASN1Sequence.getObjectAt(0);
    localASN1Sequence = (ASN1Sequence)localASN1Set.getObjectAt(0);
    return localASN1Sequence.getObjectAt(1);
  }
  
  private void testEncodingPrintableString(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    DEREncodable localDEREncodable = createEntryValue(paramDERObjectIdentifier, paramString);
    if (!(localDEREncodable instanceof DERPrintableString)) {
      fail("encoding for " + paramDERObjectIdentifier + " not printable string");
    }
  }
  
  private void testEncodingIA5String(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    DEREncodable localDEREncodable = createEntryValue(paramDERObjectIdentifier, paramString);
    if (!(localDEREncodable instanceof DERIA5String)) {
      fail("encoding for " + paramDERObjectIdentifier + " not IA5String");
    }
  }
  
  private void testEncodingGeneralizedTime(DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    DEREncodable localDEREncodable = createEntryValue(paramDERObjectIdentifier, paramString);
    if (!(localDEREncodable instanceof DERGeneralizedTime)) {
      fail("encoding for " + paramDERObjectIdentifier + " not GeneralizedTime");
    }
    localDEREncodable = createEntryValueFromString(paramDERObjectIdentifier, paramString);
    if (!(localDEREncodable instanceof DERGeneralizedTime)) {
      fail("encoding for " + paramDERObjectIdentifier + " not GeneralizedTime");
    }
  }
  
  public void performTest()
    throws Exception
  {
    testEncodingPrintableString(X509Name.C, "AU");
    testEncodingPrintableString(X509Name.SERIALNUMBER, "123456");
    testEncodingPrintableString(X509Name.DN_QUALIFIER, "123456");
    testEncodingIA5String(X509Name.EmailAddress, "test@test.com");
    testEncodingIA5String(X509Name.DC, "test");
    testEncodingGeneralizedTime(X509Name.DATE_OF_BIRTH, "#180F32303032303132323132323232305A");
    testEncodingGeneralizedTime(X509Name.DATE_OF_BIRTH, "20020122122220Z");
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(X509Name.C, "AU");
    localHashtable.put(X509Name.O, "The Legion of the Bouncy Castle");
    localHashtable.put(X509Name.L, "Melbourne");
    localHashtable.put(X509Name.ST, "Victoria");
    localHashtable.put(X509Name.E, "feedback-crypto@bouncycastle.org");
    X509Name localX509Name1 = new X509Name(localHashtable);
    if (!localX509Name1.equals(localX509Name1)) {
      fail("Failed same object test");
    }
    if (!localX509Name1.equals(localX509Name1, true)) {
      fail("Failed same object test - in Order");
    }
    X509Name localX509Name2 = new X509Name(localHashtable);
    if (!localX509Name1.equals(localX509Name2)) {
      fail("Failed same name test");
    }
    if (!localX509Name1.equals(localX509Name2, true)) {
      fail("Failed same name test - in Order");
    }
    if (localX509Name1.hashCode() != localX509Name2.hashCode()) {
      fail("Failed same name test - in Order");
    }
    Vector localVector1 = new Vector();
    localVector1.addElement(X509Name.C);
    localVector1.addElement(X509Name.O);
    localVector1.addElement(X509Name.L);
    localVector1.addElement(X509Name.ST);
    localVector1.addElement(X509Name.E);
    Vector localVector2 = new Vector();
    localVector2.addElement(X509Name.E);
    localVector2.addElement(X509Name.ST);
    localVector2.addElement(X509Name.L);
    localVector2.addElement(X509Name.O);
    localVector2.addElement(X509Name.C);
    localX509Name1 = new X509Name(localVector1, localHashtable);
    localX509Name2 = new X509Name(localVector2, localHashtable);
    if (!localX509Name1.equals(localX509Name2)) {
      fail("Failed reverse name test");
    }
    if (localX509Name1.equals(localX509Name2, true)) {
      fail("Failed reverse name test - in Order");
    }
    if (!localX509Name1.equals(localX509Name2, false)) {
      fail("Failed reverse name test - in Order false");
    }
    Vector localVector3 = localX509Name1.getOIDs();
    if (!compareVectors(localVector3, localVector1)) {
      fail("oid comparison test");
    }
    Vector localVector4 = new Vector();
    localVector4.addElement("AU");
    localVector4.addElement("The Legion of the Bouncy Castle");
    localVector4.addElement("Melbourne");
    localVector4.addElement("Victoria");
    localVector4.addElement("feedback-crypto@bouncycastle.org");
    localX509Name1 = new X509Name(localVector1, localVector4);
    Vector localVector5 = localX509Name1.getValues();
    if (!compareVectors(localVector5, localVector4)) {
      fail("value comparison test");
    }
    localVector2 = new Vector();
    localVector2.addElement(X509Name.ST);
    localVector2.addElement(X509Name.ST);
    localVector2.addElement(X509Name.L);
    localVector2.addElement(X509Name.O);
    localVector2.addElement(X509Name.C);
    localX509Name1 = new X509Name(localVector1, localHashtable);
    localX509Name2 = new X509Name(localVector2, localHashtable);
    if (localX509Name1.equals(localX509Name2)) {
      fail("Failed different name test");
    }
    localVector2 = new Vector();
    localVector2.addElement(X509Name.ST);
    localVector2.addElement(X509Name.L);
    localVector2.addElement(X509Name.O);
    localVector2.addElement(X509Name.C);
    localX509Name1 = new X509Name(localVector1, localHashtable);
    localX509Name2 = new X509Name(localVector2, localHashtable);
    if (localX509Name1.equals(localX509Name2)) {
      fail("Failed subset name test");
    }
    compositeTest();
    Vector localVector6 = localX509Name1.getValues(X509Name.O);
    if ((localVector6.size() != 1) || (!localVector6.elementAt(0).equals("The Legion of the Bouncy Castle"))) {
      fail("O test failed");
    }
    Vector localVector7 = localX509Name1.getValues(X509Name.L);
    if ((localVector7.size() != 1) || (!localVector7.elementAt(0).equals("Melbourne"))) {
      fail("L test failed");
    }
    for (int i = 0; i != this.subjects.length; i++)
    {
      localObject = new X509Name(this.subjects[i]);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
      localASN1OutputStream.writeObject(localObject);
      ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray()));
      localObject = X509Name.getInstance(localASN1InputStream.readObject());
      if (!((X509Name)localObject).toString().equals(this.subjects[i])) {
        fail("failed regeneration test " + i);
      }
    }
    X509Name localX509Name3 = new X509Name("SERIALNUMBER=BBB + CN=AA");
    if (!fromBytes(localX509Name3.getEncoded()).toString().equals("CN=AA+SERIALNUMBER=BBB")) {
      fail("failed sort test 1");
    }
    localX509Name3 = new X509Name("CN=AA + SERIALNUMBER=BBB");
    if (!fromBytes(localX509Name3.getEncoded()).toString().equals("CN=AA+SERIALNUMBER=BBB")) {
      fail("failed sort test 2");
    }
    localX509Name3 = new X509Name("SERIALNUMBER=B + CN=AA");
    if (!fromBytes(localX509Name3.getEncoded()).toString().equals("SERIALNUMBER=B+CN=AA")) {
      fail("failed sort test 3");
    }
    localX509Name3 = new X509Name("CN=AA + SERIALNUMBER=B");
    if (!fromBytes(localX509Name3.getEncoded()).toString().equals("SERIALNUMBER=B+CN=AA")) {
      fail("failed sort test 4");
    }
    equalityTest(new X509Name("CN=The     Legion"), new X509Name("CN=The Legion"));
    equalityTest(new X509Name("CN=   The Legion"), new X509Name("CN=The Legion"));
    equalityTest(new X509Name("CN=The Legion   "), new X509Name("CN=The Legion"));
    equalityTest(new X509Name("CN=  The     Legion "), new X509Name("CN=The Legion"));
    equalityTest(new X509Name("CN=  the     legion "), new X509Name("CN=The Legion"));
    localX509Name1 = new X509Name("CN=The Legion");
    if (localX509Name1.equals(new DERSequence())) {
      fail("inequality test with sequence");
    }
    if (localX509Name1.equals(new DERSequence(new DERSet()))) {
      fail("inequality test with sequence and set");
    }
    Object localObject = new ASN1EncodableVector();
    ((ASN1EncodableVector)localObject).add(new DERObjectIdentifier("1.1"));
    ((ASN1EncodableVector)localObject).add(new DERObjectIdentifier("1.1"));
    if (localX509Name1.equals(new DERSequence(new DERSet(new DERSet((DEREncodableVector)localObject))))) {
      fail("inequality test with sequence and bad set");
    }
    if (localX509Name1.equals(new DERSequence(new DERSet(new DERSet((DEREncodableVector)localObject))), true)) {
      fail("inequality test with sequence and bad set");
    }
    if (localX509Name1.equals(new DERSequence(new DERSet(new DERSequence())))) {
      fail("inequality test with sequence and short sequence");
    }
    if (localX509Name1.equals(new DERSequence(new DERSet(new DERSequence())), true)) {
      fail("inequality test with sequence and short sequence");
    }
    localObject = new ASN1EncodableVector();
    ((ASN1EncodableVector)localObject).add(new DERObjectIdentifier("1.1"));
    ((ASN1EncodableVector)localObject).add(new DERSequence());
    if (localX509Name1.equals(new DERSequence(new DERSet(new DERSequence((DEREncodableVector)localObject))))) {
      fail("inequality test with sequence and bad sequence");
    }
    if (localX509Name1.equals(null)) {
      fail("inequality test with null");
    }
    if (localX509Name1.equals(null, true)) {
      fail("inequality test with null");
    }
    localX509Name3 = new X509Name("CN=AA + CN=AA + CN=AA");
    DERUTF8String localDERUTF8String1 = new DERUTF8String("The Legion of the Bouncy Castle");
    byte[] arrayOfByte1 = localDERUTF8String1.getEncoded();
    byte[] arrayOfByte2 = Hex.encode(arrayOfByte1);
    String str = "#" + new String(arrayOfByte2);
    DERUTF8String localDERUTF8String2 = (DERUTF8String)new X509DefaultEntryConverter().getConvertedValue(X509Name.L, str);
    if (!localDERUTF8String2.equals(localDERUTF8String1)) {
      fail("failed X509DefaultEntryConverter test");
    }
  }
  
  private boolean compareVectors(Vector paramVector1, Vector paramVector2)
  {
    if (paramVector1.size() != paramVector2.size()) {
      return false;
    }
    for (int i = 0; i != paramVector1.size(); i++) {
      if (!paramVector1.elementAt(i).equals(paramVector2.elementAt(i))) {
        return false;
      }
    }
    return true;
  }
  
  private void compositeTest()
    throws IOException
  {
    byte[] arrayOfByte1 = Hex.decode("305e310b300906035504061302415531283026060355040a0c1f546865204c6567696f6e206f662074686520426f756e637920436173746c653125301006035504070c094d656c626f75726e653011060355040b0c0a4173636f742056616c65");
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(arrayOfByte1));
    X509Name localX509Name = X509Name.getInstance(localASN1InputStream.readObject());
    if (!localX509Name.toString().equals("C=AU,O=The Legion of the Bouncy Castle,L=Melbourne+OU=Ascot Vale")) {
      fail("Failed composite to string test got: " + localX509Name.toString());
    }
    if (!localX509Name.toString(true, X509Name.DefaultSymbols).equals("L=Melbourne+OU=Ascot Vale,O=The Legion of the Bouncy Castle,C=AU")) {
      fail("Failed composite to string test got: " + localX509Name.toString(true, X509Name.DefaultSymbols));
    }
    localX509Name = new X509Name(true, "L=Melbourne+OU=Ascot Vale,O=The Legion of the Bouncy Castle,C=AU");
    if (!localX509Name.toString().equals("C=AU,O=The Legion of the Bouncy Castle,L=Melbourne+OU=Ascot Vale")) {
      fail("Failed composite to string reversal test got: " + localX509Name.toString());
    }
    localX509Name = new X509Name("C=AU, O=The Legion of the Bouncy Castle, L=Melbourne + OU=Ascot Vale");
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    localASN1OutputStream.writeObject(localX509Name);
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    if (!Arrays.areEqual(arrayOfByte1, arrayOfByte2)) {
      fail("Failed composite string to encoding test");
    }
  }
  
  private void equalityTest(X509Name paramX509Name1, X509Name paramX509Name2)
  {
    if (!paramX509Name1.equals(paramX509Name2)) {
      fail("equality test failed for " + paramX509Name1 + " : " + paramX509Name2);
    }
    if (!paramX509Name1.equals(paramX509Name2, true)) {
      fail("equality test failed for " + paramX509Name1 + " : " + paramX509Name2);
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new X509NameTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\X509NameTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */