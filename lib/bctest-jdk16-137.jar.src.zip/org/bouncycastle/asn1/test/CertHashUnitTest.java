package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.isismtt.ocsp.CertHash;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class CertHashUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "CertHash";
  }
  
  public void performTest()
    throws Exception
  {
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(new DERObjectIdentifier("1.2.2.3"));
    byte[] arrayOfByte = new byte[20];
    CertHash localCertHash = new CertHash(localAlgorithmIdentifier, arrayOfByte);
    checkConstruction(localCertHash, localAlgorithmIdentifier, arrayOfByte);
    localCertHash = CertHash.getInstance(null);
    if (localCertHash != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      CertHash.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(CertHash paramCertHash, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
    throws IOException
  {
    checkValues(paramCertHash, paramAlgorithmIdentifier, paramArrayOfByte);
    paramCertHash = CertHash.getInstance(paramCertHash);
    checkValues(paramCertHash, paramAlgorithmIdentifier, paramArrayOfByte);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramCertHash.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramCertHash = CertHash.getInstance(localASN1Sequence);
    checkValues(paramCertHash, paramAlgorithmIdentifier, paramArrayOfByte);
  }
  
  private void checkValues(CertHash paramCertHash, AlgorithmIdentifier paramAlgorithmIdentifier, byte[] paramArrayOfByte)
  {
    checkMandatoryField("algorithmHash", paramAlgorithmIdentifier, paramCertHash.getHashAlgorithm());
    checkMandatoryField("certificateHash", paramArrayOfByte, paramCertHash.getCertificateHash());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CertHashUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\CertHashUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */