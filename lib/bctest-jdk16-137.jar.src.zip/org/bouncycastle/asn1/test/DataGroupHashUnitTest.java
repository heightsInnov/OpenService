package org.bouncycastle.asn1.test;

import java.io.IOException;
import java.util.Random;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.icao.DataGroupHash;
import org.bouncycastle.util.test.SimpleTest;

public class DataGroupHashUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "DataGroupHash";
  }
  
  private byte[] generateHash()
  {
    Random localRandom = new Random();
    byte[] arrayOfByte = new byte[20];
    for (int i = 0; i != arrayOfByte.length; i++) {
      arrayOfByte[i] = ((byte)localRandom.nextInt());
    }
    return arrayOfByte;
  }
  
  public void performTest()
    throws Exception
  {
    int i = 1;
    DEROctetString localDEROctetString = new DEROctetString(generateHash());
    DataGroupHash localDataGroupHash = new DataGroupHash(i, localDEROctetString);
    checkConstruction(localDataGroupHash, i, localDEROctetString);
    localDataGroupHash = DataGroupHash.getInstance(null);
    if (localDataGroupHash != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      DataGroupHash.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(DataGroupHash paramDataGroupHash, int paramInt, ASN1OctetString paramASN1OctetString)
    throws IOException
  {
    checkValues(paramDataGroupHash, paramInt, paramASN1OctetString);
    paramDataGroupHash = DataGroupHash.getInstance(paramDataGroupHash);
    checkValues(paramDataGroupHash, paramInt, paramASN1OctetString);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramDataGroupHash.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramDataGroupHash = DataGroupHash.getInstance(localASN1Sequence);
    checkValues(paramDataGroupHash, paramInt, paramASN1OctetString);
  }
  
  private void checkValues(DataGroupHash paramDataGroupHash, int paramInt, ASN1OctetString paramASN1OctetString)
  {
    if (paramDataGroupHash.getDataGroupNumber() != paramInt) {
      fail("group number don't match.");
    }
    if (!paramDataGroupHash.getDataGroupHashValue().equals(paramASN1OctetString)) {
      fail("hash value don't match.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new DataGroupHashUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\DataGroupHashUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */