package org.bouncycastle.asn1.test;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.x509.qualified.Iso4217CurrencyCode;
import org.bouncycastle.asn1.x509.qualified.MonetaryValue;
import org.bouncycastle.util.test.SimpleTest;

public class MonetaryValueUnitTest
  extends SimpleTest
{
  private static final int TEST_AMOUNT = 100;
  private static final int ZERO_EXPONENT = 0;
  private static final String CURRENCY_CODE = "AUD";
  
  public String getName()
  {
    return "MonetaryValue";
  }
  
  public void performTest()
    throws Exception
  {
    MonetaryValue localMonetaryValue = new MonetaryValue(new Iso4217CurrencyCode("AUD"), 100, 0);
    checkValues(localMonetaryValue, 100, 0);
    localMonetaryValue = MonetaryValue.getInstance(localMonetaryValue);
    checkValues(localMonetaryValue, 100, 0);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localMonetaryValue.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    localMonetaryValue = MonetaryValue.getInstance(localASN1Sequence);
    checkValues(localMonetaryValue, 100, 0);
    localMonetaryValue = MonetaryValue.getInstance(null);
    if (localMonetaryValue != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      MonetaryValue.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkValues(MonetaryValue paramMonetaryValue, int paramInt1, int paramInt2)
  {
    if (paramMonetaryValue.getAmount().intValue() != paramInt1) {
      fail("amounts don't match.");
    }
    if (paramMonetaryValue.getExponent().intValue() != paramInt2) {
      fail("exponents don't match.");
    }
    Iso4217CurrencyCode localIso4217CurrencyCode = paramMonetaryValue.getCurrency();
    if (!localIso4217CurrencyCode.getAlphabetic().equals("AUD")) {
      fail("currency code wrong");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new MonetaryValueUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\MonetaryValueUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */