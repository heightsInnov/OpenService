package org.bouncycastle.asn1.test;

import org.bouncycastle.asn1.DERApplicationSpecific;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class DERApplicationSpecificTest
  extends SimpleTest
{
  byte[] impData = Hex.decode("430109");
  
  public String getName()
  {
    return "DERApplicationSpecific";
  }
  
  public void performTest()
    throws Exception
  {
    DERInteger localDERInteger1 = new DERInteger(9);
    DERApplicationSpecific localDERApplicationSpecific = new DERApplicationSpecific(false, 3, localDERInteger1);
    if (!areEqual(this.impData, localDERApplicationSpecific.getEncoded())) {
      fail("implicit encoding failed");
    }
    DERInteger localDERInteger2 = (DERInteger)localDERApplicationSpecific.getObject(2);
    if (!localDERInteger1.equals(localDERInteger2)) {
      fail("implicit read back failed");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new DERApplicationSpecificTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\DERApplicationSpecificTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */