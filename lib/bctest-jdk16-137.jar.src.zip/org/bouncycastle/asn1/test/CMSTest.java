package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.CompressedData;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.cms.EnvelopedData;
import org.bouncycastle.asn1.cms.KEKRecipientInfo;
import org.bouncycastle.asn1.cms.KeyTransRecipientInfo;
import org.bouncycastle.asn1.cms.RecipientInfo;
import org.bouncycastle.asn1.cms.SignedData;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class CMSTest
  implements Test
{
  byte[] compData = Base64.decode("MIAGCyqGSIb3DQEJEAEJoIAwgAIBADANBgsqhkiG9w0BCRADCDCABgkqhkiG9w0BBwGggCSABIICHnic7ZRdb9owFIbvK/k/5PqVYPFXGK12YYyboVFASSp1vQtZGiLRACZE49/XHoUW7S/0tXP8EfuxfU5ivWnasml72XFb3gb5druui7ytN803M570nii7C5r8tfwR281hy/p/KSM3+jzH5s3+pbQ90xSbP3VT3QbLusnt8WPIuN5vN/vaA2+DulnXTXkXvNTr8j8ouZmkCmGI/UW+ZS/C8zP0bz2dz0zwLt+1UEk2M8mlaxjRMByAhZTj0RGYg4TvogiRASROsZgjpVcJCb1KV6QzQeDJ1XkoQ5Jm+C5PbOHZZGRiv+ORAcshOGeCcdFJyfgFxdtCdEcmOrbinc/+BBMzRThEYpwl+jEBpciSGWQkI0TSlREmD/eOHb2DSGLuESm/iKUFt1y4XHBO2a5oq0IKJKWLS9kUZTA7vC5LSxYmgVL46SIWxIfWBQd6AdrnjLmH94UTvGxVibLqRCtIpp4g2qpdtqK1LiOeolpVK5wVQ5P7+QjZAlrh0cePYTx/gNZuB9Vhndtgujl9T/tgW9ogK+3rnmg3YWygnTuF5GDS+Q/jIVLnCcYZFc6Kk/+c80wKwZjwdZIqDYWRH68MuBQSXLgXYXj23CAaYOBNJMliTl0X7eV5DnoKIFSKYdj3cRpD/cK/JWTHJRe76MUXnfBW8m7Hd5zhQ4ri2NrVF/WL+kV1/3AGSlJ32bFPd2BsQD8uSzIx6lObkjdz95c0AAAAAAAAAAAAAAAA");
  byte[] envDataKeyTrns = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQAxgcQwgcECAQAwKjAlMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVQIBCjANBgkqhkiG9w0BAQEFAASBgC5vdGrBitQSGwifLf3KwPILjaB4WEXgT/IIO1KDzrsbItCJsMA0Smq2y0zptxT0pSRL6JRgNMxLk1ySnrIrvGiEPLMR1zjxlT8yQ6VLX+kEoK43ztd1aaLw0oBfrcXcLN7BEpZ1TIdjlBfXIOx1S88WY1MiYqJJFc3LMwRUaTEDMIAGCSqGSIb3DQEHATAdBglghkgBZQMEARYEEAfxLMWeaBOTTZQwUq0Y5FuggAQgwOJhL04rjSZCBCSOv5i5XpFfGsOdYSHSqwntGpFqCx4AAAAAAAAAAAAA");
  byte[] envDataKEK = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxUqJQAgEEMAcEBQECAwQFMBAGCyqGSIb3DQEJEAMHAgE6BDC7G/HyUPilIrin2Yeajqmj795VoLWETRnZAAFcAiQdoQWyz+oCh6WY/HjHHi+0y+cwgAYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAiY3eDBBbF6naCABBiNdzJb/v6+UZB3XXKipxFDUpz9GyjzB+gAAAAAAAAAAAAA");
  byte[] signedData = Base64.decode("MIAGCSqGSIb3DQEHAqCAMIACAQExCzAJBgUrDgMCGgUAMIAGCSqGSIb3DQEHAaCAJIAEDEhlbGxvIFdvcmxkIQAAAAAAAKCCBGIwggINMIIBdqADAgECAgEBMA0GCSqGSIb3DQEBBAUAMCUxFjAUBgNVBAoTDUJvdW5jeSBDYXN0bGUxCzAJBgNVBAYTAkFVMB4XDTA0MTAyNDA0MzA1OFoXDTA1MDIwMTA0MzA1OFowJTEWMBQGA1UEChMNQm91bmN5IENhc3RsZTELMAkGA1UEBhMCQVUwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAJj3OAshAOgDmPcYZ1jdNSuhOHRH9VhC/PG17FdiInVGc2ulJhEifEQga/uqZCpSd1nHsJUZKm9k1bVneWzC0941i9Znfxgb2jnXXsa5kwB2KEVESrOWsRjSRtnYiLgqBG0rzpaMn5A5ntu7N0406EesBhe19cjZAageEHGZDbufAgMBAAGjTTBLMB0GA1UdDgQWBBR/iHNKOo6f4ByWFFywRNZ65XSr1jAfBgNVHSMEGDAWgBR/iHNKOo6f4ByWFFywRNZ65XSr1jAJBgNVHRMEAjAAMA0GCSqGSIb3DQEBBAUAA4GBAFMJJ7QOpHo30bnlQ4Ny3PCnK+Se+Gw3TpaYGp84+a8fGD9Dme78G6NEsgvpFGTyoLxvJ4CB84Kzys+1p2HdXzoZiyXAer5S4IwptE3TxxFwKyj28cRrM6dK47DDyXUkV0qwBAMNluwnk/no4K7ilzN2MZk5l7wXyNa9yJ6CHW6dMIICTTCCAbagAwIBAgIBAjANBgkqhkiG9w0BAQQFADAlMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVTAeFw0wNDEwMjQwNDMwNTlaFw0wNTAyMDEwNDMwNTlaMGUxGDAWBgNVBAMTD0VyaWMgSC4gRWNoaWRuYTEkMCIGCSqGSIb3DQEJARYVZXJpY0Bib3VuY3ljYXN0bGUub3JnMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAm+5CnGU6W45iUpCsaGkn5gDruZv3j/o7N6agmRZhikaLG2JF6ECaX13iioVJfmzBsPKxAACWwuTXCoSSXG8viK/qpSHwJpfQHYEhtcC0CxIqlnltv3KQAGwh/PdwpSPvSNnkQBGvtFq++9gnXDBbynfP8b2L2Eis0X9U2y6gFiMCAwEAAaNNMEswHQYDVR0OBBYEFEAmOksnF66FoQm6IQBVN66vJo1TMB8GA1UdIwQYMBaAFH+Ic0o6jp/gHJYUXLBE1nrldKvWMAkGA1UdEwQCMAAwDQYJKoZIhvcNAQEEBQADgYEAEeIjvNkKMPU/ZYCu1TqjGZPEqi+glntg2hC/CF0oGyHFpMuGtMepF3puW+uzKM1s61ar3ahidp3XFhr/GEU/XxK24AolI3yFgxP8PRgUWmQizTQXpWUmhlsBe1uIKVEfNAzCgtYfJQ8HJIKsUCcdWeCKVKs4jRionsek1rozkPExggEvMIIBKwIBATAqMCUxFjAUBgNVBAoTDUJvdW5jeSBDYXN0bGUxCzAJBgNVBAYTAkFVAgECMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wNDEwMjQwNDMwNTlaMCMGCSqGSIb3DQEJBDEWBBQu973mCM5UBOl9XwQvlfifHCMocTANBgkqhkiG9w0BAQEFAASBgGHbe3/jcZu6b/erRhc3PEjiMUO8mEIRiNYBr5/vFNhkry8TrGfOpI45m7gu1MS0/vdas7ykvidl/sNZfO0GphEIUaIjMRT3U6yuTWF4aLpatJbbRsIepJO/B2kdIAbV5SCbZgVDJIPOR2qnruHN2wLFa+fEv4J8wQ8Xwvk0C8iMAAAAAAAA");
  
  private boolean isSameAs(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  private TestResult compressionTest()
  {
    try
    {
      ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.compData));
      ContentInfo localContentInfo = ContentInfo.getInstance(localASN1InputStream.readObject());
      CompressedData localCompressedData = CompressedData.getInstance(localContentInfo.getContent());
      localCompressedData = new CompressedData(localCompressedData.getCompressionAlgorithmIdentifier(), localCompressedData.getEncapContentInfo());
      localContentInfo = new ContentInfo(CMSObjectIdentifiers.compressedData, localCompressedData);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
      localASN1OutputStream.writeObject(localContentInfo);
      if (!isSameAs(localByteArrayOutputStream.toByteArray(), this.compData)) {
        return new SimpleTestResult(false, getName() + ": CMS compression failed to re-encode");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": CMS compression failed - " + localException.toString(), localException);
    }
  }
  
  private TestResult envelopedTest()
  {
    try
    {
      ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.envDataKeyTrns));
      ContentInfo localContentInfo = ContentInfo.getInstance(localASN1InputStream.readObject());
      EnvelopedData localEnvelopedData = EnvelopedData.getInstance(localContentInfo.getContent());
      Object localObject1 = localEnvelopedData.getRecipientInfos();
      if (((ASN1Set)localObject1).size() != 1) {
        return new SimpleTestResult(false, getName() + ": CMS KeyTrans enveloped, wrong number of recipients");
      }
      RecipientInfo localRecipientInfo = RecipientInfo.getInstance(((ASN1Set)localObject1).getObjectAt(0));
      if ((localRecipientInfo.getInfo() instanceof KeyTransRecipientInfo))
      {
        localObject2 = KeyTransRecipientInfo.getInstance(localRecipientInfo.getInfo());
        localObject2 = new KeyTransRecipientInfo(((KeyTransRecipientInfo)localObject2).getRecipientIdentifier(), ((KeyTransRecipientInfo)localObject2).getKeyEncryptionAlgorithm(), ((KeyTransRecipientInfo)localObject2).getEncryptedKey());
        localObject1 = new DERSet(new RecipientInfo((KeyTransRecipientInfo)localObject2));
      }
      else
      {
        return new SimpleTestResult(false, getName() + ": CMS KeyTrans enveloped, wrong recipient type");
      }
      Object localObject2 = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream((OutputStream)localObject2);
      localEnvelopedData = new EnvelopedData(localEnvelopedData.getOriginatorInfo(), (ASN1Set)localObject1, localEnvelopedData.getEncryptedContentInfo(), localEnvelopedData.getUnprotectedAttrs());
      localContentInfo = new ContentInfo(CMSObjectIdentifiers.envelopedData, localEnvelopedData);
      localASN1OutputStream.writeObject(localContentInfo);
      if (!isSameAs(((ByteArrayOutputStream)localObject2).toByteArray(), this.envDataKeyTrns)) {
        return new SimpleTestResult(false, getName() + ": CMS KeyTrans enveloped failed to re-encode");
      }
      localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.envDataKEK));
      localContentInfo = ContentInfo.getInstance(localASN1InputStream.readObject());
      localEnvelopedData = EnvelopedData.getInstance(localContentInfo.getContent());
      localObject1 = localEnvelopedData.getRecipientInfos();
      if (((ASN1Set)localObject1).size() != 1) {
        return new SimpleTestResult(false, getName() + ": CMS KEK enveloped, wrong number of recipients");
      }
      localRecipientInfo = RecipientInfo.getInstance(((ASN1Set)localObject1).getObjectAt(0));
      if ((localRecipientInfo.getInfo() instanceof KEKRecipientInfo))
      {
        KEKRecipientInfo localKEKRecipientInfo = KEKRecipientInfo.getInstance(localRecipientInfo.getInfo());
        localKEKRecipientInfo = new KEKRecipientInfo(localKEKRecipientInfo.getKekid(), localKEKRecipientInfo.getKeyEncryptionAlgorithm(), localKEKRecipientInfo.getEncryptedKey());
        localObject1 = new DERSet(new RecipientInfo(localKEKRecipientInfo));
      }
      else
      {
        return new SimpleTestResult(false, getName() + ": CMS KEK enveloped, wrong recipient type");
      }
      localObject2 = new ByteArrayOutputStream();
      localASN1OutputStream = new ASN1OutputStream((OutputStream)localObject2);
      localEnvelopedData = new EnvelopedData(localEnvelopedData.getOriginatorInfo(), (ASN1Set)localObject1, localEnvelopedData.getEncryptedContentInfo(), localEnvelopedData.getUnprotectedAttrs());
      localContentInfo = new ContentInfo(CMSObjectIdentifiers.envelopedData, localEnvelopedData);
      localASN1OutputStream.writeObject(localContentInfo);
      if (!isSameAs(((ByteArrayOutputStream)localObject2).toByteArray(), this.envDataKEK))
      {
        System.out.println(new String(Base64.encode(((ByteArrayOutputStream)localObject2).toByteArray())));
        return new SimpleTestResult(false, getName() + ": CMS KEK enveloped failed to re-encode");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": CMS enveloped failed - " + localException.toString(), localException);
    }
  }
  
  private TestResult signedTest()
  {
    try
    {
      ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.signedData));
      ContentInfo localContentInfo = ContentInfo.getInstance(localASN1InputStream.readObject());
      SignedData localSignedData = SignedData.getInstance(localContentInfo.getContent());
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
      localSignedData = new SignedData(localSignedData.getDigestAlgorithms(), localSignedData.getEncapContentInfo(), localSignedData.getCertificates(), localSignedData.getCRLs(), localSignedData.getSignerInfos());
      localContentInfo = new ContentInfo(CMSObjectIdentifiers.signedData, localSignedData);
      localASN1OutputStream.writeObject(localContentInfo);
      if (!isSameAs(localByteArrayOutputStream.toByteArray(), this.signedData)) {
        return new SimpleTestResult(false, getName() + ": CMS signed failed to re-encode");
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": CMS signed failed - " + localException.toString(), localException);
    }
  }
  
  public TestResult perform()
  {
    TestResult localTestResult = compressionTest();
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    localTestResult = envelopedTest();
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return signedTest();
  }
  
  public String getName()
  {
    return "CMS";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    CMSTest localCMSTest = new CMSTest();
    TestResult localTestResult = localCMSTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\CMSTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */