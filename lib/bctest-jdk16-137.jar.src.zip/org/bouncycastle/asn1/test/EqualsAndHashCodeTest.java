package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DERApplicationSpecific;
import org.bouncycastle.asn1.DERBMPString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.DERGeneralString;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERNumericString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERT61String;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTCTime;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.DERUniversalString;
import org.bouncycastle.asn1.DERUnknownTag;
import org.bouncycastle.asn1.DERVisibleString;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class EqualsAndHashCodeTest
  implements Test
{
  public TestResult perform()
  {
    byte[] arrayOfByte = { 0, 1, 0, 1, 0, 0, 1 };
    DERObject[] arrayOfDERObject1 = { new BERConstructedOctetString(arrayOfByte), new BERSequence(new DERPrintableString("hello world")), new BERSet(new DERPrintableString("hello world")), new BERTaggedObject(0, new DERPrintableString("hello world")), new DERApplicationSpecific(0, arrayOfByte), new DERBitString(arrayOfByte), new DERBMPString("hello world"), new DERBoolean(true), new DERBoolean(false), new DEREnumerated(100), new DERGeneralizedTime("20070315173729Z"), new DERGeneralString("hello world"), new DERIA5String("hello"), new DERInteger(1000), new DERNull(), new DERNumericString("123456"), new DERObjectIdentifier("1.1.1.10000.1"), new DEROctetString(arrayOfByte), new DERPrintableString("hello world"), new DERSequence(new DERPrintableString("hello world")), new DERSet(new DERPrintableString("hello world")), new DERT61String("hello world"), new DERTaggedObject(0, new DERPrintableString("hello world")), new DERUniversalString(arrayOfByte), new DERUnknownTag(63, arrayOfByte), new DERUTCTime(new Date()), new DERUTF8String("hello world"), new DERVisibleString("hello world") };
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
      for (int i = 0; i != arrayOfDERObject1.length; i++) {
        localASN1OutputStream.writeObject(arrayOfDERObject1[i]);
      }
      DERObject[] arrayOfDERObject2 = new DERObject[arrayOfDERObject1.length];
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
      ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
      for (int j = 0; j != arrayOfDERObject1.length; j++)
      {
        DERObject localDERObject = localASN1InputStream.readObject();
        if (!localDERObject.equals(arrayOfDERObject1[j])) {
          return new SimpleTestResult(false, getName() + ": Failed equality test for " + localDERObject);
        }
        if (localDERObject.hashCode() != arrayOfDERObject1[j].hashCode()) {
          return new SimpleTestResult(false, getName() + ": Failed hashCode test for " + localDERObject);
        }
      }
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Failed - exception " + localException.toString(), localException);
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "EqualsAndHashCode";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    EqualsAndHashCodeTest localEqualsAndHashCodeTest = new EqualsAndHashCodeTest();
    TestResult localTestResult = localEqualsAndHashCodeTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\EqualsAndHashCodeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */