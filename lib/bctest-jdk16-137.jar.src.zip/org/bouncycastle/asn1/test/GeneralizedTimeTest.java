package org.bouncycastle.asn1.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.util.test.SimpleTest;

public class GeneralizedTimeTest
  extends SimpleTest
{
  String[] input = { "20020122122220", "20020122122220Z", "20020122122220-1000", "20020122122220+00", "20020122122220.1", "20020122122220.1Z", "20020122122220.1-1000", "20020122122220.1+00", "20020122122220.01", "20020122122220.01Z", "20020122122220.01-1000", "20020122122220.01+00", "20020122122220.001", "20020122122220.001Z", "20020122122220.001-1000", "20020122122220.001+00", "20020122122220.0001", "20020122122220.0001Z", "20020122122220.0001-1000", "20020122122220.0001+00", "20020122122220.0001+1000" };
  String[] output = { "20020122122220", "20020122122220GMT+00:00", "20020122122220GMT-10:00", "20020122122220GMT+00:00", "20020122122220.1", "20020122122220.1GMT+00:00", "20020122122220.1GMT-10:00", "20020122122220.1GMT+00:00", "20020122122220.01", "20020122122220.01GMT+00:00", "20020122122220.01GMT-10:00", "20020122122220.01GMT+00:00", "20020122122220.001", "20020122122220.001GMT+00:00", "20020122122220.001GMT-10:00", "20020122122220.001GMT+00:00", "20020122122220.0001", "20020122122220.0001GMT+00:00", "20020122122220.0001GMT-10:00", "20020122122220.0001GMT+00:00", "20020122122220.0001GMT+10:00" };
  String[] zOutput = { "20020122122220Z", "20020122122220Z", "20020122222220Z", "20020122122220Z", "20020122122220Z", "20020122122220Z", "20020122222220Z", "20020122122220Z", "20020122122220Z", "20020122122220Z", "20020122222220Z", "20020122122220Z", "20020122122220Z", "20020122122220Z", "20020122222220Z", "20020122122220Z", "20020122122220Z", "20020122122220Z", "20020122222220Z", "20020122122220Z", "20020122022220Z" };
  
  public String getName()
  {
    return "GeneralizedTime";
  }
  
  public void performTest()
    throws Exception
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
    localSimpleDateFormat.setTimeZone(new SimpleTimeZone(0, "Z"));
    for (int i = 0; i != this.input.length; i++)
    {
      DERGeneralizedTime localDERGeneralizedTime = new DERGeneralizedTime(this.input[i]);
      if (this.output[i].indexOf('G') > 0)
      {
        if (!localDERGeneralizedTime.getTime().equals(this.output[i])) {
          fail("failed conversion test");
        }
        if (!localSimpleDateFormat.format(localDERGeneralizedTime.getDate()).equals(this.zOutput[i])) {
          fail("failed date conversion test");
        }
      }
      else
      {
        String str = calculateGMTOffset(localDERGeneralizedTime.getDate());
        if (!localDERGeneralizedTime.getTime().equals(this.output[i] + str)) {
          fail("failed conversion test");
        }
      }
    }
  }
  
  private String calculateGMTOffset(Date paramDate)
  {
    String str = "+";
    TimeZone localTimeZone = TimeZone.getDefault();
    int i = localTimeZone.getRawOffset();
    if (i < 0)
    {
      str = "-";
      i = -i;
    }
    int j = i / 3600000;
    int k = (i - j * 60 * 60 * 1000) / 60000;
    if ((localTimeZone.useDaylightTime()) && (localTimeZone.inDaylightTime(paramDate))) {
      j += (str.equals("+") ? 1 : -1);
    }
    return "GMT" + str + convert(j) + ":" + convert(k);
  }
  
  private String convert(int paramInt)
  {
    if (paramInt < 10) {
      return "0" + paramInt;
    }
    return Integer.toString(paramInt);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new GeneralizedTimeTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\GeneralizedTimeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */