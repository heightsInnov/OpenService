package org.bouncycastle.asn1.test;

import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SetTest
  implements Test
{
  public String getName()
  {
    return "Set";
  }
  
  public TestResult perform()
  {
    try
    {
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      byte[] arrayOfByte = new byte[10];
      localASN1EncodableVector.add(new DEROctetString(arrayOfByte));
      localASN1EncodableVector.add(new DERBitString(arrayOfByte));
      localASN1EncodableVector.add(new DERInteger(100));
      localASN1EncodableVector.add(new DERBoolean(true));
      Object localObject = new DERSet(localASN1EncodableVector);
      if (!(((ASN1Set)localObject).getObjectAt(0) instanceof DERBoolean)) {
        return new SimpleTestResult(false, getName() + ": sorting failed.");
      }
      localObject = new BERSet(localASN1EncodableVector);
      if (!(((ASN1Set)localObject).getObjectAt(0) instanceof DEROctetString)) {
        return new SimpleTestResult(false, getName() + ": BER set sort order changed.");
      }
      DERTaggedObject localDERTaggedObject = new DERTaggedObject(false, 1, new DERSequence(localASN1EncodableVector));
      localObject = ASN1Set.getInstance(localDERTaggedObject, false);
      if ((((ASN1Set)localObject).getObjectAt(0) instanceof DERBoolean)) {
        return new SimpleTestResult(false, getName() + ": sorted when shouldn't be.");
      }
      localASN1EncodableVector = new ASN1EncodableVector();
      localASN1EncodableVector.add(new DERBoolean(true));
      localASN1EncodableVector.add(new DERBoolean(true));
      localASN1EncodableVector.add(new DERBoolean(true));
      localObject = new DERSet(localASN1EncodableVector);
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Exception - " + localException.toString(), localException);
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SetTest localSetTest = new SetTest();
    TestResult localTestResult = localSetTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\SetTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */