package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.esf.SignerLocation;
import org.bouncycastle.util.test.SimpleTest;

public class SignerLocationUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "SignerLocation";
  }
  
  public void performTest()
    throws Exception
  {
    DERUTF8String localDERUTF8String1 = new DERUTF8String("Australia");
    SignerLocation localSignerLocation = new SignerLocation(localDERUTF8String1, null, null);
    checkConstruction(localSignerLocation, localDERUTF8String1, null, null);
    DERUTF8String localDERUTF8String2 = new DERUTF8String("Melbourne");
    localSignerLocation = new SignerLocation(null, localDERUTF8String2, null);
    checkConstruction(localSignerLocation, null, localDERUTF8String2, null);
    localSignerLocation = new SignerLocation(localDERUTF8String1, localDERUTF8String2, null);
    checkConstruction(localSignerLocation, localDERUTF8String1, localDERUTF8String2, null);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERUTF8String("line 1"));
    localASN1EncodableVector.add(new DERUTF8String("line 2"));
    DERSequence localDERSequence = new DERSequence(localASN1EncodableVector);
    localSignerLocation = new SignerLocation(null, null, localDERSequence);
    checkConstruction(localSignerLocation, null, null, localDERSequence);
    localSignerLocation = new SignerLocation(localDERUTF8String1, null, localDERSequence);
    checkConstruction(localSignerLocation, localDERUTF8String1, null, localDERSequence);
    localSignerLocation = new SignerLocation(localDERUTF8String1, localDERUTF8String2, localDERSequence);
    checkConstruction(localSignerLocation, localDERUTF8String1, localDERUTF8String2, localDERSequence);
    localSignerLocation = SignerLocation.getInstance(null);
    if (localSignerLocation != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      SignerLocation.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERUTF8String("line 1"));
    localASN1EncodableVector.add(new DERUTF8String("line 2"));
    localASN1EncodableVector.add(new DERUTF8String("line 3"));
    localASN1EncodableVector.add(new DERUTF8String("line 4"));
    localASN1EncodableVector.add(new DERUTF8String("line 5"));
    localASN1EncodableVector.add(new DERUTF8String("line 6"));
    localASN1EncodableVector.add(new DERUTF8String("line 7"));
    localDERSequence = new DERSequence(localASN1EncodableVector);
    try
    {
      new SignerLocation(null, null, localDERSequence);
      fail("constructor failed to detect bad postalAddress.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
    try
    {
      new SignerLocation(new DERSequence(new DERTaggedObject(2, localDERSequence)));
      fail("sequence constructor failed to detect bad postalAddress.");
    }
    catch (IllegalArgumentException localIllegalArgumentException3) {}
    try
    {
      new SignerLocation(new DERSequence(new DERTaggedObject(5, localDERSequence)));
      fail("sequence constructor failed to detect bad tag.");
    }
    catch (IllegalArgumentException localIllegalArgumentException4) {}
  }
  
  private void checkConstruction(SignerLocation paramSignerLocation, DERUTF8String paramDERUTF8String1, DERUTF8String paramDERUTF8String2, ASN1Sequence paramASN1Sequence)
    throws IOException
  {
    checkValues(paramSignerLocation, paramDERUTF8String1, paramDERUTF8String2, paramASN1Sequence);
    paramSignerLocation = SignerLocation.getInstance(paramSignerLocation);
    checkValues(paramSignerLocation, paramDERUTF8String1, paramDERUTF8String2, paramASN1Sequence);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramSignerLocation.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramSignerLocation = SignerLocation.getInstance(localASN1Sequence);
    checkValues(paramSignerLocation, paramDERUTF8String1, paramDERUTF8String2, paramASN1Sequence);
  }
  
  private void checkValues(SignerLocation paramSignerLocation, DERUTF8String paramDERUTF8String1, DERUTF8String paramDERUTF8String2, ASN1Sequence paramASN1Sequence)
  {
    if (paramDERUTF8String1 != null)
    {
      if (!paramDERUTF8String1.equals(paramSignerLocation.getCountryName())) {
        fail("countryNames don't match.");
      }
    }
    else if (paramSignerLocation.getCountryName() != null) {
      fail("countryName found when none expected.");
    }
    if (paramDERUTF8String2 != null)
    {
      if (!paramDERUTF8String2.equals(paramSignerLocation.getLocalityName())) {
        fail("localityNames don't match.");
      }
    }
    else if (paramSignerLocation.getLocalityName() != null) {
      fail("localityName found when none expected.");
    }
    if (paramASN1Sequence != null)
    {
      if (!paramASN1Sequence.equals(paramSignerLocation.getPostalAddress())) {
        fail("postalAddresses don't match.");
      }
    }
    else if (paramSignerLocation.getPostalAddress() != null) {
      fail("postalAddress found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new SignerLocationUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\SignerLocationUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */