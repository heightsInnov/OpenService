package org.bouncycastle.asn1.test;

import java.io.IOException;
import java.util.Random;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.icao.DataGroupHash;
import org.bouncycastle.asn1.icao.LDSSecurityObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.util.test.SimpleTest;

public class LDSSecurityObjectUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "LDSSecurityObject";
  }
  
  private byte[] generateHash()
  {
    Random localRandom = new Random();
    byte[] arrayOfByte = new byte[20];
    for (int i = 0; i != arrayOfByte.length; i++) {
      arrayOfByte[i] = ((byte)localRandom.nextInt());
    }
    return arrayOfByte;
  }
  
  public void performTest()
    throws Exception
  {
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier("1.3.14.3.2.26");
    DataGroupHash[] arrayOfDataGroupHash = new DataGroupHash[2];
    arrayOfDataGroupHash[0] = new DataGroupHash(1, new DEROctetString(generateHash()));
    arrayOfDataGroupHash[1] = new DataGroupHash(2, new DEROctetString(generateHash()));
    LDSSecurityObject localLDSSecurityObject = new LDSSecurityObject(localAlgorithmIdentifier, arrayOfDataGroupHash);
    checkConstruction(localLDSSecurityObject, localAlgorithmIdentifier, arrayOfDataGroupHash);
    localLDSSecurityObject = LDSSecurityObject.getInstance(null);
    if (localLDSSecurityObject != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      LDSSecurityObject.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      new LDSSecurityObject(new DERSequence(localASN1EncodableVector));
      fail("constructor failed to detect empty sequence.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
    try
    {
      new LDSSecurityObject(localAlgorithmIdentifier, new DataGroupHash[1]);
      fail("constructor failed to detect small DataGroupHash array.");
    }
    catch (IllegalArgumentException localIllegalArgumentException3) {}
    try
    {
      new LDSSecurityObject(localAlgorithmIdentifier, new DataGroupHash[17]);
      fail("constructor failed to out of bounds DataGroupHash array.");
    }
    catch (IllegalArgumentException localIllegalArgumentException4) {}
  }
  
  private void checkConstruction(LDSSecurityObject paramLDSSecurityObject, AlgorithmIdentifier paramAlgorithmIdentifier, DataGroupHash[] paramArrayOfDataGroupHash)
    throws IOException
  {
    checkStatement(paramLDSSecurityObject, paramAlgorithmIdentifier, paramArrayOfDataGroupHash);
    paramLDSSecurityObject = LDSSecurityObject.getInstance(paramLDSSecurityObject);
    checkStatement(paramLDSSecurityObject, paramAlgorithmIdentifier, paramArrayOfDataGroupHash);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramLDSSecurityObject.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramLDSSecurityObject = LDSSecurityObject.getInstance(localASN1Sequence);
    checkStatement(paramLDSSecurityObject, paramAlgorithmIdentifier, paramArrayOfDataGroupHash);
  }
  
  private void checkStatement(LDSSecurityObject paramLDSSecurityObject, AlgorithmIdentifier paramAlgorithmIdentifier, DataGroupHash[] paramArrayOfDataGroupHash)
  {
    if (paramAlgorithmIdentifier != null)
    {
      if (!paramLDSSecurityObject.getDigestAlgorithmIdentifier().equals(paramAlgorithmIdentifier)) {
        fail("ids don't match.");
      }
    }
    else if (paramLDSSecurityObject.getDigestAlgorithmIdentifier() != null) {
      fail("digest algorithm Id found when none expected.");
    }
    if (paramArrayOfDataGroupHash != null)
    {
      DataGroupHash[] arrayOfDataGroupHash = paramLDSSecurityObject.getDatagroupHash();
      for (int i = 0; i != arrayOfDataGroupHash.length; i++) {
        if (!paramArrayOfDataGroupHash[i].equals(arrayOfDataGroupHash[i])) {
          fail("name registration authorities don't match.");
        }
      }
    }
    else if (paramLDSSecurityObject.getDatagroupHash() != null)
    {
      fail("data hash groups found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new LDSSecurityObjectUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\LDSSecurityObjectUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */