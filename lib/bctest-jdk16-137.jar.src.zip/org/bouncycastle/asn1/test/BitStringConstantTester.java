package org.bouncycastle.asn1.test;

public class BitStringConstantTester
{
  private static final int[] bits = { 128, 64, 32, 16, 8, 4, 2, 1, 32768, 16384, 8192, 4096, 2048, 1024, 512, 256, 8388608, 4194304, 2097152, 1048576, 524288, 262144, 131072, 65536, Integer.MIN_VALUE, 1073741824, 536870912, 268435456, 134217728, 67108864, 33554432, 16777216 };
  
  public static void testFlagValueCorrect(int paramInt1, int paramInt2)
  {
    if (bits[paramInt1] != paramInt2) {
      throw new IllegalArgumentException("bit value " + paramInt1 + " wrong");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\BitStringConstantTester.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */