package org.bouncycastle.asn1.test;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Arrays;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.ASN1SequenceParser;
import org.bouncycastle.asn1.ASN1StreamParser;
import org.bouncycastle.asn1.BERSequenceGenerator;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequenceGenerator;
import org.bouncycastle.util.encoders.Hex;

public class ASN1SequenceParserTest
  extends TestCase
{
  private static final byte[] seqData = Hex.decode("3006020100060129");
  private static final byte[] nestedSeqData = Hex.decode("300b0201000601293003020101");
  private static final byte[] expTagSeqData = Hex.decode("a1083006020100060129");
  private static final byte[] implTagSeqData = Hex.decode("a106020100060129");
  private static final byte[] nestedSeqExpTagData = Hex.decode("300d020100060129a1053003020101");
  private static final byte[] nestedSeqImpTagData = Hex.decode("300b020100060129a103020101");
  private static final byte[] berSeqData = Hex.decode("30800201000601290000");
  private static final byte[] berDERNestedSeqData = Hex.decode("308002010006012930030201010000");
  private static final byte[] berNestedSeqData = Hex.decode("3080020100060129308002010100000000");
  private static final byte[] berExpTagSeqData = Hex.decode("a180308002010006012900000000");
  
  public void testDERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator = new DERSequenceGenerator(localByteArrayOutputStream);
    localDERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    localDERSequenceGenerator.close();
    assertTrue("basic DER writing test failed.", Arrays.equals(seqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedDERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator1 = new DERSequenceGenerator(localByteArrayOutputStream);
    localDERSequenceGenerator1.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator1.addObject(new DERObjectIdentifier("1.1"));
    DERSequenceGenerator localDERSequenceGenerator2 = new DERSequenceGenerator(localDERSequenceGenerator1.getRawOutputStream());
    localDERSequenceGenerator2.addObject(new DERInteger(BigInteger.valueOf(1L)));
    localDERSequenceGenerator2.close();
    localDERSequenceGenerator1.close();
    assertTrue("nested DER writing test failed.", Arrays.equals(nestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDERExplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator = new DERSequenceGenerator(localByteArrayOutputStream, 1, true);
    localDERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    localDERSequenceGenerator.close();
    assertTrue("explicit tag writing test failed.", Arrays.equals(expTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDERImplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator = new DERSequenceGenerator(localByteArrayOutputStream, 1, false);
    localDERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    localDERSequenceGenerator.close();
    assertTrue("implicit tag writing test failed.", Arrays.equals(implTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedExplicitTagDERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator1 = new DERSequenceGenerator(localByteArrayOutputStream);
    localDERSequenceGenerator1.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator1.addObject(new DERObjectIdentifier("1.1"));
    DERSequenceGenerator localDERSequenceGenerator2 = new DERSequenceGenerator(localDERSequenceGenerator1.getRawOutputStream(), 1, true);
    localDERSequenceGenerator2.addObject(new DERInteger(BigInteger.valueOf(1L)));
    localDERSequenceGenerator2.close();
    localDERSequenceGenerator1.close();
    assertTrue("nested explicit tagged DER writing test failed.", Arrays.equals(nestedSeqExpTagData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedImplicitTagDERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DERSequenceGenerator localDERSequenceGenerator1 = new DERSequenceGenerator(localByteArrayOutputStream);
    localDERSequenceGenerator1.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localDERSequenceGenerator1.addObject(new DERObjectIdentifier("1.1"));
    DERSequenceGenerator localDERSequenceGenerator2 = new DERSequenceGenerator(localDERSequenceGenerator1.getRawOutputStream(), 1, false);
    localDERSequenceGenerator2.addObject(new DERInteger(BigInteger.valueOf(1L)));
    localDERSequenceGenerator2.close();
    localDERSequenceGenerator1.close();
    assertTrue("nested implicit tagged DER writing test failed.", Arrays.equals(nestedSeqImpTagData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testBERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator = new BERSequenceGenerator(localByteArrayOutputStream);
    localBERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localBERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    localBERSequenceGenerator.close();
    assertTrue("basic BER writing test failed.", Arrays.equals(berSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedBERDERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator = new BERSequenceGenerator(localByteArrayOutputStream);
    localBERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localBERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    DERSequenceGenerator localDERSequenceGenerator = new DERSequenceGenerator(localBERSequenceGenerator.getRawOutputStream());
    localDERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(1L)));
    localDERSequenceGenerator.close();
    localBERSequenceGenerator.close();
    assertTrue("nested BER/DER writing test failed.", Arrays.equals(berDERNestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedBERWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator1 = new BERSequenceGenerator(localByteArrayOutputStream);
    localBERSequenceGenerator1.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localBERSequenceGenerator1.addObject(new DERObjectIdentifier("1.1"));
    BERSequenceGenerator localBERSequenceGenerator2 = new BERSequenceGenerator(localBERSequenceGenerator1.getRawOutputStream());
    localBERSequenceGenerator2.addObject(new DERInteger(BigInteger.valueOf(1L)));
    localBERSequenceGenerator2.close();
    localBERSequenceGenerator1.close();
    assertTrue("nested BER writing test failed.", Arrays.equals(berNestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDERReading()
    throws Exception
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(seqData);
    ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)localASN1StreamParser.readObject();
    int i = 0;
    assertNotNull("null sequence returned", localASN1SequenceParser);
    DEREncodable localDEREncodable;
    while ((localDEREncodable = localASN1SequenceParser.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localDEREncodable instanceof DERInteger);
        break;
      case 1: 
        assertTrue(localDEREncodable instanceof DERObjectIdentifier);
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 2, i);
  }
  
  public void testNestedReading(byte[] paramArrayOfByte)
    throws Exception
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramArrayOfByte);
    ASN1SequenceParser localASN1SequenceParser1 = (ASN1SequenceParser)localASN1StreamParser.readObject();
    int i = 0;
    assertNotNull("null sequence returned", localASN1SequenceParser1);
    DEREncodable localDEREncodable;
    while ((localDEREncodable = localASN1SequenceParser1.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localDEREncodable instanceof DERInteger);
        break;
      case 1: 
        assertTrue(localDEREncodable instanceof DERObjectIdentifier);
        break;
      case 2: 
        assertTrue(localDEREncodable instanceof ASN1SequenceParser);
        ASN1SequenceParser localASN1SequenceParser2 = (ASN1SequenceParser)localDEREncodable;
        localASN1SequenceParser2.readObject();
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 3, i);
  }
  
  public void testNestedDERReading()
    throws Exception
  {
    testNestedReading(nestedSeqData);
  }
  
  public void testBERReading()
    throws Exception
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(berSeqData);
    ASN1SequenceParser localASN1SequenceParser = (ASN1SequenceParser)localASN1StreamParser.readObject();
    int i = 0;
    assertNotNull("null sequence returned", localASN1SequenceParser);
    DEREncodable localDEREncodable;
    while ((localDEREncodable = localASN1SequenceParser.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localDEREncodable instanceof DERInteger);
        break;
      case 1: 
        assertTrue(localDEREncodable instanceof DERObjectIdentifier);
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 2, i);
  }
  
  public void testNestedBERDERReading()
    throws Exception
  {
    testNestedReading(berDERNestedSeqData);
  }
  
  public void testNestedBERReading()
    throws Exception
  {
    testNestedReading(berNestedSeqData);
  }
  
  public void testBERExplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BERSequenceGenerator localBERSequenceGenerator = new BERSequenceGenerator(localByteArrayOutputStream, 1, true);
    localBERSequenceGenerator.addObject(new DERInteger(BigInteger.valueOf(0L)));
    localBERSequenceGenerator.addObject(new DERObjectIdentifier("1.1"));
    localBERSequenceGenerator.close();
    assertTrue("explicit BER tag writing test failed.", Arrays.equals(berExpTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public static Test suite()
  {
    return new TestSuite(ASN1SequenceParserTest.class);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\ASN1SequenceParserTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */