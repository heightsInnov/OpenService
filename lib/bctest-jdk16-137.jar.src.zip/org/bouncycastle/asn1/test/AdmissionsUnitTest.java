package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.isismtt.x509.Admissions;
import org.bouncycastle.asn1.isismtt.x509.NamingAuthority;
import org.bouncycastle.asn1.isismtt.x509.ProfessionInfo;
import org.bouncycastle.asn1.x500.DirectoryString;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.X509Name;

public class AdmissionsUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "Admissions";
  }
  
  public void performTest()
    throws Exception
  {
    GeneralName localGeneralName = new GeneralName(new X509Name("CN=hello world"));
    NamingAuthority localNamingAuthority = new NamingAuthority(new DERObjectIdentifier("1.2.3"), "url", new DirectoryString("fred"));
    Admissions localAdmissions = new Admissions(localGeneralName, localNamingAuthority, new ProfessionInfo[0]);
    checkConstruction(localAdmissions, localGeneralName, localNamingAuthority);
    localAdmissions = Admissions.getInstance(null);
    if (localAdmissions != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      Admissions.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(Admissions paramAdmissions, GeneralName paramGeneralName, NamingAuthority paramNamingAuthority)
    throws IOException
  {
    checkValues(paramAdmissions, paramGeneralName, paramNamingAuthority);
    paramAdmissions = Admissions.getInstance(paramAdmissions);
    checkValues(paramAdmissions, paramGeneralName, paramNamingAuthority);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramAdmissions.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramAdmissions = Admissions.getInstance(localASN1Sequence);
    checkValues(paramAdmissions, paramGeneralName, paramNamingAuthority);
  }
  
  private void checkValues(Admissions paramAdmissions, GeneralName paramGeneralName, NamingAuthority paramNamingAuthority)
  {
    checkMandatoryField("admissionAuthority", paramGeneralName, paramAdmissions.getAdmissionAuthority());
    checkMandatoryField("namingAuthority", paramNamingAuthority, paramAdmissions.getNamingAuthority());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new AdmissionsUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\AdmissionsUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */