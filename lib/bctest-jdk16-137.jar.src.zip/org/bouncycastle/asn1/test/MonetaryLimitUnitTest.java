package org.bouncycastle.asn1.test;

import java.io.IOException;
import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.isismtt.x509.MonetaryLimit;

public class MonetaryLimitUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "MonetaryLimit";
  }
  
  public void performTest()
    throws Exception
  {
    String str = "AUD";
    int i = 1;
    int j = 2;
    MonetaryLimit localMonetaryLimit = new MonetaryLimit(str, i, j);
    checkConstruction(localMonetaryLimit, str, i, j);
    localMonetaryLimit = MonetaryLimit.getInstance(null);
    if (localMonetaryLimit != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      MonetaryLimit.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(MonetaryLimit paramMonetaryLimit, String paramString, int paramInt1, int paramInt2)
    throws IOException
  {
    checkValues(paramMonetaryLimit, paramString, paramInt1, paramInt2);
    paramMonetaryLimit = MonetaryLimit.getInstance(paramMonetaryLimit);
    checkValues(paramMonetaryLimit, paramString, paramInt1, paramInt2);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramMonetaryLimit.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramMonetaryLimit = MonetaryLimit.getInstance(localASN1Sequence);
    checkValues(paramMonetaryLimit, paramString, paramInt1, paramInt2);
  }
  
  private void checkValues(MonetaryLimit paramMonetaryLimit, String paramString, int paramInt1, int paramInt2)
  {
    checkMandatoryField("currency", paramString, paramMonetaryLimit.getCurrency());
    checkMandatoryField("amount", paramInt1, paramMonetaryLimit.getAmount().intValue());
    checkMandatoryField("exponent", paramInt2, paramMonetaryLimit.getExponent().intValue());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new MonetaryLimitUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\MonetaryLimitUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */