package org.bouncycastle.asn1.test;

import java.util.Hashtable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.util.test.SimpleTest;

public class AttributeTableUnitTest
  extends SimpleTest
{
  private static final DERObjectIdentifier type1 = new DERObjectIdentifier("1.1.1");
  private static final DERObjectIdentifier type2 = new DERObjectIdentifier("1.1.2");
  private static final DERObjectIdentifier type3 = new DERObjectIdentifier("1.1.3");
  
  public String getName()
  {
    return "AttributeTable";
  }
  
  public void performTest()
    throws Exception
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    localASN1EncodableVector1.add(new Attribute(type1, new DERSet(type1)));
    localASN1EncodableVector1.add(new Attribute(type2, new DERSet(type2)));
    AttributeTable localAttributeTable = new AttributeTable(localASN1EncodableVector1);
    Attribute localAttribute = localAttributeTable.get(type1);
    if (localAttribute == null) {
      fail("type1 attribute not found.");
    }
    if (!localAttribute.getAttrValues().equals(new DERSet(type1))) {
      fail("wrong value retrieved for type1!");
    }
    localAttribute = localAttributeTable.get(type2);
    if (localAttribute == null) {
      fail("type2 attribute not found.");
    }
    if (!localAttribute.getAttrValues().equals(new DERSet(type2))) {
      fail("wrong value retrieved for type2!");
    }
    localAttribute = localAttributeTable.get(type3);
    if (localAttribute != null) {
      fail("type3 attribute found when none expected.");
    }
    ASN1EncodableVector localASN1EncodableVector2 = localAttributeTable.getAll(type1);
    if (localASN1EncodableVector2.size() != 1) {
      fail("wrong vector size for type1.");
    }
    localASN1EncodableVector2 = localAttributeTable.getAll(type3);
    if (localASN1EncodableVector2.size() != 0) {
      fail("wrong vector size for type3.");
    }
    localASN1EncodableVector2 = localAttributeTable.toASN1EncodableVector();
    if (localASN1EncodableVector2.size() != 2) {
      fail("wrong vector size for single.");
    }
    Hashtable localHashtable = localAttributeTable.toHashtable();
    if (localHashtable.size() != 2) {
      fail("hashtable wrong size.");
    }
    localASN1EncodableVector1 = new ASN1EncodableVector();
    localASN1EncodableVector1.add(new Attribute(type1, new DERSet(type1)));
    localASN1EncodableVector1.add(new Attribute(type1, new DERSet(type2)));
    localASN1EncodableVector1.add(new Attribute(type1, new DERSet(type3)));
    localASN1EncodableVector1.add(new Attribute(type2, new DERSet(type2)));
    localAttributeTable = new AttributeTable(localASN1EncodableVector1);
    localAttribute = localAttributeTable.get(type1);
    if (!localAttribute.getAttrValues().equals(new DERSet(type1))) {
      fail("wrong value retrieved for type1 multi get!");
    }
    localASN1EncodableVector2 = localAttributeTable.getAll(type1);
    if (localASN1EncodableVector2.size() != 3) {
      fail("wrong vector size for multiple type1.");
    }
    localAttribute = (Attribute)localASN1EncodableVector2.get(0);
    if (!localAttribute.getAttrValues().equals(new DERSet(type1))) {
      fail("wrong value retrieved for type1(0)!");
    }
    localAttribute = (Attribute)localASN1EncodableVector2.get(1);
    if (!localAttribute.getAttrValues().equals(new DERSet(type2))) {
      fail("wrong value retrieved for type1(1)!");
    }
    localAttribute = (Attribute)localASN1EncodableVector2.get(2);
    if (!localAttribute.getAttrValues().equals(new DERSet(type3))) {
      fail("wrong value retrieved for type1(2)!");
    }
    localASN1EncodableVector2 = localAttributeTable.getAll(type2);
    if (localASN1EncodableVector2.size() != 1) {
      fail("wrong vector size for multiple type2.");
    }
    localASN1EncodableVector2 = localAttributeTable.toASN1EncodableVector();
    if (localASN1EncodableVector2.size() != 4) {
      fail("wrong vector size for multiple.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new AttributeTableUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\AttributeTableUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */