package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.isismtt.x509.ProcurationSyntax;
import org.bouncycastle.asn1.x500.DirectoryString;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.IssuerSerial;
import org.bouncycastle.asn1.x509.X509Name;

public class ProcurationSyntaxUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "ProcurationSyntax";
  }
  
  public void performTest()
    throws Exception
  {
    String str = "AU";
    DirectoryString localDirectoryString = new DirectoryString("substitution");
    GeneralName localGeneralName = new GeneralName(new X509Name("CN=thirdPerson"));
    IssuerSerial localIssuerSerial = new IssuerSerial(new GeneralNames(new GeneralName(new X509Name("CN=test"))), new DERInteger(1));
    ProcurationSyntax localProcurationSyntax = new ProcurationSyntax(str, localDirectoryString, localGeneralName);
    checkConstruction(localProcurationSyntax, str, localDirectoryString, localGeneralName, null);
    localProcurationSyntax = new ProcurationSyntax(str, localDirectoryString, localIssuerSerial);
    checkConstruction(localProcurationSyntax, str, localDirectoryString, null, localIssuerSerial);
    localProcurationSyntax = new ProcurationSyntax(null, localDirectoryString, localIssuerSerial);
    checkConstruction(localProcurationSyntax, null, localDirectoryString, null, localIssuerSerial);
    localProcurationSyntax = new ProcurationSyntax(str, null, localIssuerSerial);
    checkConstruction(localProcurationSyntax, str, null, null, localIssuerSerial);
    localProcurationSyntax = ProcurationSyntax.getInstance(null);
    if (localProcurationSyntax != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      ProcurationSyntax.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(ProcurationSyntax paramProcurationSyntax, String paramString, DirectoryString paramDirectoryString, GeneralName paramGeneralName, IssuerSerial paramIssuerSerial)
    throws IOException
  {
    checkValues(paramProcurationSyntax, paramString, paramDirectoryString, paramGeneralName, paramIssuerSerial);
    paramProcurationSyntax = ProcurationSyntax.getInstance(paramProcurationSyntax);
    checkValues(paramProcurationSyntax, paramString, paramDirectoryString, paramGeneralName, paramIssuerSerial);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramProcurationSyntax.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramProcurationSyntax = ProcurationSyntax.getInstance(localASN1Sequence);
    checkValues(paramProcurationSyntax, paramString, paramDirectoryString, paramGeneralName, paramIssuerSerial);
  }
  
  private void checkValues(ProcurationSyntax paramProcurationSyntax, String paramString, DirectoryString paramDirectoryString, GeneralName paramGeneralName, IssuerSerial paramIssuerSerial)
  {
    checkOptionalField("country", paramString, paramProcurationSyntax.getCountry());
    checkOptionalField("typeOfSubstitution", paramDirectoryString, paramProcurationSyntax.getTypeOfSubstitution());
    checkOptionalField("thirdPerson", paramGeneralName, paramProcurationSyntax.getThirdPerson());
    checkOptionalField("certRef", paramIssuerSerial, paramProcurationSyntax.getCertRef());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ProcurationSyntaxUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\ProcurationSyntaxUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */