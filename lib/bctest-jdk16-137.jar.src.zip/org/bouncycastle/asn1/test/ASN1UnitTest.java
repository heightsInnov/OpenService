package org.bouncycastle.asn1.test;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.util.test.SimpleTest;

public abstract class ASN1UnitTest
  extends SimpleTest
{
  protected void checkMandatoryField(String paramString, ASN1Encodable paramASN1Encodable1, ASN1Encodable paramASN1Encodable2)
  {
    if (!paramASN1Encodable1.equals(paramASN1Encodable2)) {
      fail(paramString + " field doesn't match.");
    }
  }
  
  protected void checkMandatoryField(String paramString1, String paramString2, String paramString3)
  {
    if (!paramString2.equals(paramString3)) {
      fail(paramString1 + " field doesn't match.");
    }
  }
  
  protected void checkMandatoryField(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (!areEqual(paramArrayOfByte1, paramArrayOfByte2)) {
      fail(paramString + " field doesn't match.");
    }
  }
  
  protected void checkMandatoryField(String paramString, int paramInt1, int paramInt2)
  {
    if (paramInt1 != paramInt2) {
      fail(paramString + " field doesn't match.");
    }
  }
  
  protected void checkOptionalField(String paramString, ASN1Encodable paramASN1Encodable1, ASN1Encodable paramASN1Encodable2)
  {
    if (paramASN1Encodable1 != null)
    {
      if (!paramASN1Encodable1.equals(paramASN1Encodable2)) {
        fail(paramString + " field doesn't match.");
      }
    }
    else if (paramASN1Encodable2 != null) {
      fail(paramString + " field found when none expected.");
    }
  }
  
  protected void checkOptionalField(String paramString1, String paramString2, String paramString3)
  {
    if (paramString2 != null)
    {
      if (!paramString2.equals(paramString3)) {
        fail(paramString1 + " field doesn't match.");
      }
    }
    else if (paramString3 != null) {
      fail(paramString1 + " field found when none expected.");
    }
  }
  
  protected void checkOptionalField(String paramString, BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    if (paramBigInteger1 != null)
    {
      if (!paramBigInteger1.equals(paramBigInteger2)) {
        fail(paramString + " field doesn't match.");
      }
    }
    else if (paramBigInteger2 != null) {
      fail(paramString + " field found when none expected.");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\ASN1UnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */