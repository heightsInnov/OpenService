package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.misc.CAST5CBCParameters;
import org.bouncycastle.asn1.misc.IDEACBCPar;
import org.bouncycastle.asn1.misc.NetscapeCertType;
import org.bouncycastle.asn1.misc.NetscapeRevocationURL;
import org.bouncycastle.asn1.misc.VerisignCzagExtension;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class MiscTest
  implements Test
{
  private boolean isSameAs(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    if (paramArrayOfByte1.length != paramArrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public TestResult perform()
  {
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
    ASN1Encodable[] arrayOfASN1Encodable = { new CAST5CBCParameters(arrayOfByte1, 128), new NetscapeCertType(32), new VerisignCzagExtension(new DERIA5String("hello")), new IDEACBCPar(arrayOfByte1), new NetscapeRevocationURL(new DERIA5String("http://test")) };
    byte[] arrayOfByte2 = Base64.decode("MA4ECAECAwQFBgcIAgIAgAMCBSAWBWhlbGxvMAoECAECAwQFBgcIFgtodHRwOi8vdGVzdA==");
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
      for (int i = 0; i != arrayOfASN1Encodable.length; i++) {
        localASN1OutputStream.writeObject(arrayOfASN1Encodable[i]);
      }
      DERObject[] arrayOfDERObject = new DERObject[arrayOfASN1Encodable.length];
      if (!isSameAs(localByteArrayOutputStream.toByteArray(), arrayOfByte2)) {
        return new SimpleTestResult(false, getName() + ": Failed data check");
      }
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream.toByteArray());
      ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
      for (int j = 0; j != arrayOfASN1Encodable.length; j++)
      {
        DERObject localDERObject = localASN1InputStream.readObject();
        if (!arrayOfASN1Encodable[j].equals(localDERObject)) {
          return new SimpleTestResult(false, getName() + ": Failed equality test for " + localDERObject);
        }
        if (localDERObject.hashCode() != arrayOfASN1Encodable[j].hashCode()) {
          return new SimpleTestResult(false, getName() + ": Failed hashCode test for " + localDERObject);
        }
      }
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException)
    {
      return new SimpleTestResult(false, getName() + ": Failed - exception " + localException.toString(), localException);
    }
  }
  
  public String getName()
  {
    return "Misc";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    MiscTest localMiscTest = new MiscTest();
    TestResult localTestResult = localMiscTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\MiscTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */