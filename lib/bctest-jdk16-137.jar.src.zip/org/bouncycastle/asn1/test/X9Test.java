package org.bouncycastle.asn1.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.sec.ECPrivateKeyStructure;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.asn1.x9.X962Parameters;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.asn1.x9.X9ECPoint;
import org.bouncycastle.asn1.x9.X9IntegerConverter;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECFieldElement.Fp;
import org.bouncycastle.math.ec.ECPoint.Fp;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.test.SimpleTest;

public class X9Test
  extends SimpleTest
{
  private byte[] namedPub = Base64.decode("MBowEwYHKoZIzj0CAQYIKoZIzj0DAQEDAwADAQ==");
  private byte[] expPub = Base64.decode("MIHcMIHUBgcqhkjOPQIBMIHIAgEBMCkGByqGSM49AQECHn///////////////3///////4AAAAAAAH///////zBXBB5///////////////9///////+AAAAAAAB///////wEHiVXBfoqMGZUsfTLA9anUKMMJQEC1JiHF9m6FattPgMVAH1zdBaP/jRxtgqFdoahlHXTv6L/BB8DZ2iujhi7ks/PAFyUmqLG2UhT0OZgu/hUsclQX+laAh5///////////////9///+XXetBs6YFfDxDIUZSZVEDAwADAQ==");
  private byte[] namedPriv = Base64.decode("MCICAQAwEwYHKoZIzj0CAQYIKoZIzj0DAQEECDAGAgEBBAEK");
  private byte[] expPriv = Base64.decode("MIHkAgEAMIHUBgcqhkjOPQIBMIHIAgEBMCkGByqGSM49AQECHn///////////////3///////4AAAAAAAH///////zBXBB5///////////////9///////+AAAAAAAB///////wEHiVXBfoqMGZUsfTLA9anUKMMJQEC1JiHF9m6FattPgMVAH1zdBaP/jRxtgqFdoahlHXTv6L/BB8DZ2iujhi7ks/PAFyUmqLG2UhT0OZgu/hUsclQX+laAh5///////////////9///+XXetBs6YFfDxDIUZSZVEECDAGAgEBBAEU");
  
  private void encodePublicKey()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    X9ECParameters localX9ECParameters = X962NamedCurves.getByOID(X9ObjectIdentifiers.prime239v3);
    X9IntegerConverter localX9IntegerConverter = new X9IntegerConverter();
    if (localX9IntegerConverter.getByteLength(localX9ECParameters.getCurve()) != 30) {
      fail("wrong byte length reported for curve");
    }
    if (localX9ECParameters.getCurve().getFieldSize() != 239) {
      fail("wrong field size reported for curve");
    }
    X962Parameters localX962Parameters = new X962Parameters(X9ObjectIdentifiers.prime192v1);
    ASN1OctetString localASN1OctetString = (ASN1OctetString)new X9ECPoint(new ECPoint.Fp(localX9ECParameters.getCurve(), new ECFieldElement.Fp(BigInteger.valueOf(2L), BigInteger.valueOf(1L)), new ECFieldElement.Fp(BigInteger.valueOf(4L), BigInteger.valueOf(3L)), true)).getDERObject();
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(X9ObjectIdentifiers.id_ecPublicKey, localX962Parameters), localASN1OctetString.getOctets());
    if (!areEqual(localSubjectPublicKeyInfo.getEncoded(), this.namedPub)) {
      fail("failed public named generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.namedPub));
    DERObject localDERObject = localASN1InputStream.readObject();
    if (!localSubjectPublicKeyInfo.equals(localDERObject)) {
      fail("failed public named equality");
    }
    localX962Parameters = new X962Parameters(localX9ECParameters);
    localSubjectPublicKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(X9ObjectIdentifiers.id_ecPublicKey, localX962Parameters), localASN1OctetString.getOctets());
    if (!areEqual(localSubjectPublicKeyInfo.getEncoded(), this.expPub)) {
      fail("failed public explicit generation");
    }
    localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.expPub));
    localDERObject = localASN1InputStream.readObject();
    if (!localSubjectPublicKeyInfo.equals(localDERObject)) {
      fail("failed public explicit equality");
    }
  }
  
  private void encodePrivateKey()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    X9ECParameters localX9ECParameters = X962NamedCurves.getByOID(X9ObjectIdentifiers.prime239v3);
    X962Parameters localX962Parameters = new X962Parameters(X9ObjectIdentifiers.prime192v1);
    ASN1OctetString localASN1OctetString = (ASN1OctetString)new X9ECPoint(new ECPoint.Fp(localX9ECParameters.getCurve(), new ECFieldElement.Fp(BigInteger.valueOf(2L), BigInteger.valueOf(1L)), new ECFieldElement.Fp(BigInteger.valueOf(4L), BigInteger.valueOf(3L)), true)).getDERObject();
    PrivateKeyInfo localPrivateKeyInfo = new PrivateKeyInfo(new AlgorithmIdentifier(X9ObjectIdentifiers.id_ecPublicKey, localX962Parameters), new ECPrivateKeyStructure(BigInteger.valueOf(10L)).getDERObject());
    if (!areEqual(localPrivateKeyInfo.getEncoded(), this.namedPriv)) {
      fail("failed private named generation");
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.namedPriv));
    DERObject localDERObject = localASN1InputStream.readObject();
    if (!localPrivateKeyInfo.equals(localDERObject)) {
      fail("failed private named equality");
    }
    localX962Parameters = new X962Parameters(localX9ECParameters);
    localPrivateKeyInfo = new PrivateKeyInfo(new AlgorithmIdentifier(X9ObjectIdentifiers.id_ecPublicKey, localX962Parameters), new ECPrivateKeyStructure(BigInteger.valueOf(20L)).toASN1Object());
    if (!areEqual(localPrivateKeyInfo.getEncoded(), this.expPriv)) {
      fail("failed private explicit generation");
    }
    localASN1InputStream = new ASN1InputStream(new ByteArrayInputStream(this.expPriv));
    localDERObject = localASN1InputStream.readObject();
    if (!localPrivateKeyInfo.equals(localDERObject)) {
      fail("failed private explicit equality");
    }
  }
  
  public void performTest()
    throws Exception
  {
    encodePublicKey();
    encodePrivateKey();
  }
  
  public String getName()
  {
    return "X9";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new X9Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\X9Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */