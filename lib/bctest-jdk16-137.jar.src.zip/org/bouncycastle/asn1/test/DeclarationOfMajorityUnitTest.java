package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.isismtt.x509.DeclarationOfMajority;

public class DeclarationOfMajorityUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "DeclarationOfMajority";
  }
  
  public void performTest()
    throws Exception
  {
    DERGeneralizedTime localDERGeneralizedTime = new DERGeneralizedTime("20070315173729Z");
    DeclarationOfMajority localDeclarationOfMajority = new DeclarationOfMajority(localDERGeneralizedTime);
    checkConstruction(localDeclarationOfMajority, 2, localDERGeneralizedTime, -1);
    localDeclarationOfMajority = new DeclarationOfMajority(6);
    checkConstruction(localDeclarationOfMajority, 0, null, 6);
    localDeclarationOfMajority = DeclarationOfMajority.getInstance(null);
    if (localDeclarationOfMajority != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      DeclarationOfMajority.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(DeclarationOfMajority paramDeclarationOfMajority, int paramInt1, DERGeneralizedTime paramDERGeneralizedTime, int paramInt2)
    throws IOException
  {
    checkValues(paramDeclarationOfMajority, paramInt1, paramDERGeneralizedTime, paramInt2);
    paramDeclarationOfMajority = DeclarationOfMajority.getInstance(paramDeclarationOfMajority);
    checkValues(paramDeclarationOfMajority, paramInt1, paramDERGeneralizedTime, paramInt2);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramDeclarationOfMajority.toASN1Object().getEncoded());
    DERTaggedObject localDERTaggedObject = (DERTaggedObject)localASN1InputStream.readObject();
    paramDeclarationOfMajority = DeclarationOfMajority.getInstance(localDERTaggedObject);
    checkValues(paramDeclarationOfMajority, paramInt1, paramDERGeneralizedTime, paramInt2);
  }
  
  private void checkValues(DeclarationOfMajority paramDeclarationOfMajority, int paramInt1, DERGeneralizedTime paramDERGeneralizedTime, int paramInt2)
  {
    checkMandatoryField("type", paramInt1, paramDeclarationOfMajority.getType());
    checkOptionalField("dateOfBirth", paramDERGeneralizedTime, paramDeclarationOfMajority.getDateOfBirth());
    if ((paramInt2 != -1) && (paramInt2 != paramDeclarationOfMajority.notYoungerThan())) {
      fail("notYoungerThan mismatch");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new DeclarationOfMajorityUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\DeclarationOfMajorityUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */