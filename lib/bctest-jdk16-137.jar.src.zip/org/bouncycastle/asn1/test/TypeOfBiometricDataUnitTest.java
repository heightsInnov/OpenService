package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.qualified.TypeOfBiometricData;
import org.bouncycastle.util.test.SimpleTest;

public class TypeOfBiometricDataUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "TypeOfBiometricData";
  }
  
  public void performTest()
    throws Exception
  {
    checkPredefinedType(0);
    checkPredefinedType(1);
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier("1.1");
    TypeOfBiometricData localTypeOfBiometricData = new TypeOfBiometricData(localDERObjectIdentifier);
    checkNonPredefined(localTypeOfBiometricData, localDERObjectIdentifier);
    localTypeOfBiometricData = TypeOfBiometricData.getInstance(localTypeOfBiometricData);
    checkNonPredefined(localTypeOfBiometricData, localDERObjectIdentifier);
    DERObject localDERObject = localTypeOfBiometricData.toASN1Object();
    localTypeOfBiometricData = TypeOfBiometricData.getInstance(localDERObject);
    checkNonPredefined(localTypeOfBiometricData, localDERObjectIdentifier);
    localTypeOfBiometricData = TypeOfBiometricData.getInstance(null);
    if (localTypeOfBiometricData != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      TypeOfBiometricData.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      new TypeOfBiometricData(100);
      fail("constructor failed to detect bad predefined type.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
  }
  
  private void checkPredefinedType(int paramInt)
    throws IOException
  {
    TypeOfBiometricData localTypeOfBiometricData = new TypeOfBiometricData(paramInt);
    checkPredefined(localTypeOfBiometricData, paramInt);
    localTypeOfBiometricData = TypeOfBiometricData.getInstance(localTypeOfBiometricData);
    checkPredefined(localTypeOfBiometricData, paramInt);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localTypeOfBiometricData.toASN1Object().getEncoded());
    DERObject localDERObject = localASN1InputStream.readObject();
    localTypeOfBiometricData = TypeOfBiometricData.getInstance(localDERObject);
    checkPredefined(localTypeOfBiometricData, paramInt);
  }
  
  private void checkPredefined(TypeOfBiometricData paramTypeOfBiometricData, int paramInt)
  {
    if (!paramTypeOfBiometricData.isPredefined()) {
      fail("predefined type expected but not found.");
    }
    if (paramTypeOfBiometricData.getPredefinedBiometricType() != paramInt) {
      fail("predefined type does not match.");
    }
  }
  
  private void checkNonPredefined(TypeOfBiometricData paramTypeOfBiometricData, DERObjectIdentifier paramDERObjectIdentifier)
  {
    if (paramTypeOfBiometricData.isPredefined()) {
      fail("predefined type found when not expected.");
    }
    if (!paramTypeOfBiometricData.getBiometricDataOid().equals(paramDERObjectIdentifier)) {
      fail("data oid does not match.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new TypeOfBiometricDataUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\TypeOfBiometricDataUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */