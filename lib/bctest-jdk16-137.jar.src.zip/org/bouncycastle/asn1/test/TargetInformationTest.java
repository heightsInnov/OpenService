package org.bouncycastle.asn1.test;

import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.Target;
import org.bouncycastle.asn1.x509.TargetInformation;
import org.bouncycastle.asn1.x509.Targets;
import org.bouncycastle.util.test.SimpleTest;

public class TargetInformationTest
  extends SimpleTest
{
  public String getName()
  {
    return "TargetInformation";
  }
  
  public void performTest()
    throws Exception
  {
    Target[] arrayOfTarget = new Target[2];
    Target localTarget1 = new Target(0, new GeneralName(2, "www.test.com"));
    Target localTarget2 = new Target(1, new GeneralName(4, "o=Test, ou=Test"));
    arrayOfTarget[0] = localTarget1;
    arrayOfTarget[1] = localTarget2;
    Targets localTargets = new Targets(arrayOfTarget);
    TargetInformation localTargetInformation1 = new TargetInformation(localTargets);
    TargetInformation localTargetInformation2 = new TargetInformation(arrayOfTarget);
    if (!localTargetInformation1.equals(localTargetInformation2)) {
      fail("targetInformation1 and targetInformation2 should have the same encoding.");
    }
    TargetInformation localTargetInformation3 = TargetInformation.getInstance(localTargetInformation1.getDERObject());
    TargetInformation localTargetInformation4 = TargetInformation.getInstance(localTargetInformation2.getDERObject());
    if (!localTargetInformation3.equals(localTargetInformation4)) {
      fail("targetInformation3 and targetInformation4 should have the same encoding.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new TargetInformationTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\TargetInformationTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */