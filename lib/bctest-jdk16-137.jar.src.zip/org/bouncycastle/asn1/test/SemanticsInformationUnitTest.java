package org.bouncycastle.asn1.test;

import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.asn1.x509.qualified.SemanticsInformation;
import org.bouncycastle.util.test.SimpleTest;

public class SemanticsInformationUnitTest
  extends SimpleTest
{
  public String getName()
  {
    return "SemanticsInformation";
  }
  
  public void performTest()
    throws Exception
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier("1.1");
    SemanticsInformation localSemanticsInformation = new SemanticsInformation(localDERObjectIdentifier);
    checkConstruction(localSemanticsInformation, localDERObjectIdentifier, null);
    GeneralName[] arrayOfGeneralName = new GeneralName[2];
    arrayOfGeneralName[0] = new GeneralName(1, "test@test.org");
    arrayOfGeneralName[1] = new GeneralName(new X509Name("cn=test"));
    localSemanticsInformation = new SemanticsInformation(localDERObjectIdentifier, arrayOfGeneralName);
    checkConstruction(localSemanticsInformation, localDERObjectIdentifier, arrayOfGeneralName);
    localSemanticsInformation = new SemanticsInformation(arrayOfGeneralName);
    checkConstruction(localSemanticsInformation, null, arrayOfGeneralName);
    localSemanticsInformation = SemanticsInformation.getInstance(null);
    if (localSemanticsInformation != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      SemanticsInformation.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      new SemanticsInformation(new DERSequence(localASN1EncodableVector));
      fail("constructor failed to detect empty sequence.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
  }
  
  private void checkConstruction(SemanticsInformation paramSemanticsInformation, DERObjectIdentifier paramDERObjectIdentifier, GeneralName[] paramArrayOfGeneralName)
    throws Exception
  {
    checkStatement(paramSemanticsInformation, paramDERObjectIdentifier, paramArrayOfGeneralName);
    paramSemanticsInformation = SemanticsInformation.getInstance(paramSemanticsInformation);
    checkStatement(paramSemanticsInformation, paramDERObjectIdentifier, paramArrayOfGeneralName);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramSemanticsInformation.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramSemanticsInformation = SemanticsInformation.getInstance(localASN1Sequence);
    checkStatement(paramSemanticsInformation, paramDERObjectIdentifier, paramArrayOfGeneralName);
  }
  
  private void checkStatement(SemanticsInformation paramSemanticsInformation, DERObjectIdentifier paramDERObjectIdentifier, GeneralName[] paramArrayOfGeneralName)
  {
    if (paramDERObjectIdentifier != null)
    {
      if (!paramSemanticsInformation.getSemanticsIdentifier().equals(paramDERObjectIdentifier)) {
        fail("ids don't match.");
      }
    }
    else if (paramSemanticsInformation.getSemanticsIdentifier() != null) {
      fail("statementId found when none expected.");
    }
    if (paramArrayOfGeneralName != null)
    {
      GeneralName[] arrayOfGeneralName = paramSemanticsInformation.getNameRegistrationAuthorities();
      for (int i = 0; i != arrayOfGeneralName.length; i++) {
        if (!paramArrayOfGeneralName[i].equals(arrayOfGeneralName[i])) {
          fail("name registration authorities don't match.");
        }
      }
    }
    else if (paramSemanticsInformation.getNameRegistrationAuthorities() != null)
    {
      fail("name registration authorities found when none expected.");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new SemanticsInformationUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\SemanticsInformationUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */