package org.bouncycastle.asn1.test;

import java.io.PrintStream;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class BitStringTest
  implements Test
{
  public TestResult perform()
  {
    KeyUsage localKeyUsage = new KeyUsage(128);
    if ((localKeyUsage.getBytes()[0] != Byte.MIN_VALUE) || (localKeyUsage.getPadBits() != 7)) {
      return new SimpleTestResult(false, getName() + ": failed digitalSignature");
    }
    localKeyUsage = new KeyUsage(64);
    if ((localKeyUsage.getBytes()[0] != 64) || (localKeyUsage.getPadBits() != 6)) {
      return new SimpleTestResult(false, getName() + ": failed nonRepudiation");
    }
    localKeyUsage = new KeyUsage(32);
    if ((localKeyUsage.getBytes()[0] != 32) || (localKeyUsage.getPadBits() != 5)) {
      return new SimpleTestResult(false, getName() + ": failed keyEncipherment");
    }
    localKeyUsage = new KeyUsage(2);
    if ((localKeyUsage.getBytes()[0] != 2) || (localKeyUsage.getPadBits() != 1)) {
      return new SimpleTestResult(false, getName() + ": failed cRLSign");
    }
    localKeyUsage = new KeyUsage(32768);
    if ((localKeyUsage.getBytes()[1] != Byte.MIN_VALUE) || (localKeyUsage.getPadBits() != 7)) {
      return new SimpleTestResult(false, getName() + ": failed decipherOnly");
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "BitString";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    BitStringTest localBitStringTest = new BitStringTest();
    TestResult localTestResult = localBitStringTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\BitStringTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */