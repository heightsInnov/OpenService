package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.ess.ContentHints;

public class ContentHintsUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "ContentHints";
  }
  
  public void performTest()
    throws Exception
  {
    DERUTF8String localDERUTF8String = new DERUTF8String("Description");
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier("1.2.2.3");
    ContentHints localContentHints = new ContentHints(localDERObjectIdentifier);
    checkConstruction(localContentHints, localDERObjectIdentifier, null);
    localContentHints = new ContentHints(localDERObjectIdentifier, localDERUTF8String);
    checkConstruction(localContentHints, localDERObjectIdentifier, localDERUTF8String);
    localContentHints = ContentHints.getInstance(null);
    if (localContentHints != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      ContentHints.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(ContentHints paramContentHints, DERObjectIdentifier paramDERObjectIdentifier, DERUTF8String paramDERUTF8String)
    throws IOException
  {
    checkValues(paramContentHints, paramDERObjectIdentifier, paramDERUTF8String);
    paramContentHints = ContentHints.getInstance(paramContentHints);
    checkValues(paramContentHints, paramDERObjectIdentifier, paramDERUTF8String);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramContentHints.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramContentHints = ContentHints.getInstance(localASN1Sequence);
    checkValues(paramContentHints, paramDERObjectIdentifier, paramDERUTF8String);
  }
  
  private void checkValues(ContentHints paramContentHints, DERObjectIdentifier paramDERObjectIdentifier, DERUTF8String paramDERUTF8String)
  {
    checkMandatoryField("contentType", paramDERObjectIdentifier, paramContentHints.getContentType());
    checkOptionalField("description", paramDERUTF8String, paramContentHints.getContentDescription());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ContentHintsUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\ContentHintsUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */