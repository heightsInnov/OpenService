package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.isismtt.x509.NamingAuthority;
import org.bouncycastle.asn1.x500.DirectoryString;

public class NamingAuthorityUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "NamingAuthority";
  }
  
  public void performTest()
    throws Exception
  {
    DERObjectIdentifier localDERObjectIdentifier = new DERObjectIdentifier("1.2.3");
    String str = "url";
    DirectoryString localDirectoryString = new DirectoryString("text");
    NamingAuthority localNamingAuthority = new NamingAuthority(localDERObjectIdentifier, str, localDirectoryString);
    checkConstruction(localNamingAuthority, localDERObjectIdentifier, str, localDirectoryString);
    localNamingAuthority = new NamingAuthority(null, str, localDirectoryString);
    checkConstruction(localNamingAuthority, null, str, localDirectoryString);
    localNamingAuthority = new NamingAuthority(localDERObjectIdentifier, null, localDirectoryString);
    checkConstruction(localNamingAuthority, localDERObjectIdentifier, null, localDirectoryString);
    localNamingAuthority = new NamingAuthority(localDERObjectIdentifier, str, null);
    checkConstruction(localNamingAuthority, localDERObjectIdentifier, str, null);
    localNamingAuthority = NamingAuthority.getInstance(null);
    if (localNamingAuthority != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      NamingAuthority.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(NamingAuthority paramNamingAuthority, DERObjectIdentifier paramDERObjectIdentifier, String paramString, DirectoryString paramDirectoryString)
    throws IOException
  {
    checkValues(paramNamingAuthority, paramDERObjectIdentifier, paramString, paramDirectoryString);
    paramNamingAuthority = NamingAuthority.getInstance(paramNamingAuthority);
    checkValues(paramNamingAuthority, paramDERObjectIdentifier, paramString, paramDirectoryString);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramNamingAuthority.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramNamingAuthority = NamingAuthority.getInstance(localASN1Sequence);
    checkValues(paramNamingAuthority, paramDERObjectIdentifier, paramString, paramDirectoryString);
  }
  
  private void checkValues(NamingAuthority paramNamingAuthority, DERObjectIdentifier paramDERObjectIdentifier, String paramString, DirectoryString paramDirectoryString)
  {
    checkOptionalField("namingAuthorityId", paramDERObjectIdentifier, paramNamingAuthority.getNamingAuthorityId());
    checkOptionalField("namingAuthorityURL", paramString, paramNamingAuthority.getNamingAuthorityUrl());
    checkOptionalField("namingAuthorityText", paramDirectoryString, paramNamingAuthority.getNamingAuthorityText());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new NamingAuthorityUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\NamingAuthorityUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */