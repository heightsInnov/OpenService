package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.ess.OtherCertID;
import org.bouncycastle.asn1.ess.OtherSigningCertificate;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class OtherSigningCertificateUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "OtherSigningCertificate";
  }
  
  public void performTest()
    throws Exception
  {
    AlgorithmIdentifier localAlgorithmIdentifier = new AlgorithmIdentifier(new DERObjectIdentifier("1.2.2.3"));
    byte[] arrayOfByte = new byte[20];
    OtherCertID localOtherCertID = new OtherCertID(localAlgorithmIdentifier, arrayOfByte);
    OtherSigningCertificate localOtherSigningCertificate = new OtherSigningCertificate(localOtherCertID);
    checkConstruction(localOtherSigningCertificate, localOtherCertID);
    localOtherSigningCertificate = OtherSigningCertificate.getInstance(null);
    if (localOtherSigningCertificate != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      OtherCertID.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(OtherSigningCertificate paramOtherSigningCertificate, OtherCertID paramOtherCertID)
    throws IOException
  {
    checkValues(paramOtherSigningCertificate, paramOtherCertID);
    paramOtherSigningCertificate = OtherSigningCertificate.getInstance(paramOtherSigningCertificate);
    checkValues(paramOtherSigningCertificate, paramOtherCertID);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramOtherSigningCertificate.toASN1Object().getEncoded());
    ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
    paramOtherSigningCertificate = OtherSigningCertificate.getInstance(localASN1Sequence);
    checkValues(paramOtherSigningCertificate, paramOtherCertID);
  }
  
  private void checkValues(OtherSigningCertificate paramOtherSigningCertificate, OtherCertID paramOtherCertID)
  {
    if (paramOtherSigningCertificate.getCerts().length != 1) {
      fail("getCerts() length wrong");
    }
    checkMandatoryField("getCerts()[0]", paramOtherCertID, paramOtherSigningCertificate.getCerts()[0]);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new OtherSigningCertificateUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\OtherSigningCertificateUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */