package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.util.test.SimpleTest;

public class KeyUsageTest
  extends SimpleTest
{
  public String getName()
  {
    return "KeyUsage";
  }
  
  public void performTest()
    throws IOException
  {
    BitStringConstantTester.testFlagValueCorrect(0, 128);
    BitStringConstantTester.testFlagValueCorrect(1, 64);
    BitStringConstantTester.testFlagValueCorrect(2, 32);
    BitStringConstantTester.testFlagValueCorrect(3, 16);
    BitStringConstantTester.testFlagValueCorrect(4, 8);
    BitStringConstantTester.testFlagValueCorrect(5, 4);
    BitStringConstantTester.testFlagValueCorrect(6, 2);
    BitStringConstantTester.testFlagValueCorrect(7, 1);
    BitStringConstantTester.testFlagValueCorrect(8, 32768);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new KeyUsageTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\KeyUsageTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */