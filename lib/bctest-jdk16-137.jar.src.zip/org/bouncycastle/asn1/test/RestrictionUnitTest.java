package org.bouncycastle.asn1.test;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.isismtt.x509.Restriction;
import org.bouncycastle.asn1.x500.DirectoryString;

public class RestrictionUnitTest
  extends ASN1UnitTest
{
  public String getName()
  {
    return "Restriction";
  }
  
  public void performTest()
    throws Exception
  {
    DirectoryString localDirectoryString = new DirectoryString("test");
    Restriction localRestriction = new Restriction(localDirectoryString.getString());
    checkConstruction(localRestriction, localDirectoryString);
    localRestriction = Restriction.getInstance(null);
    if (localRestriction != null) {
      fail("null getInstance() failed.");
    }
    try
    {
      Restriction.getInstance(new Object());
      fail("getInstance() failed to detect bad object.");
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
  }
  
  private void checkConstruction(Restriction paramRestriction, DirectoryString paramDirectoryString)
    throws IOException
  {
    checkValues(paramRestriction, paramDirectoryString);
    paramRestriction = Restriction.getInstance(paramRestriction);
    checkValues(paramRestriction, paramDirectoryString);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramRestriction.toASN1Object().getEncoded());
    DERString localDERString = (DERString)localASN1InputStream.readObject();
    paramRestriction = Restriction.getInstance(localDERString);
    checkValues(paramRestriction, paramDirectoryString);
  }
  
  private void checkValues(Restriction paramRestriction, DirectoryString paramDirectoryString)
  {
    checkMandatoryField("restriction", paramDirectoryString, paramRestriction.getRestriction());
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new RestrictionUnitTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\RestrictionUnitTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */