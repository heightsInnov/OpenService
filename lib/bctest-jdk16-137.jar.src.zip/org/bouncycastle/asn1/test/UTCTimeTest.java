package org.bouncycastle.asn1.test;

import java.text.SimpleDateFormat;
import java.util.SimpleTimeZone;
import org.bouncycastle.asn1.DERUTCTime;
import org.bouncycastle.util.test.SimpleTest;

public class UTCTimeTest
  extends SimpleTest
{
  String[] input = { "020122122220Z", "020122122220-1000", "020122122220+1000", "020122122220+00", "0201221222Z", "0201221222-1000", "0201221222+1000", "0201221222+00", "550122122220Z", "5501221222Z" };
  String[] output = { "20020122122220GMT+00:00", "20020122122220GMT-10:00", "20020122122220GMT+10:00", "20020122122220GMT+00:00", "20020122122200GMT+00:00", "20020122122200GMT-10:00", "20020122122200GMT+10:00", "20020122122200GMT+00:00", "19550122122220GMT+00:00", "19550122122200GMT+00:00" };
  String[] zOutput1 = { "20020122122220Z", "20020122222220Z", "20020122022220Z", "20020122122220Z", "20020122122200Z", "20020122222200Z", "20020122022200Z", "20020122122200Z", "19550122122220Z", "19550122122200Z" };
  String[] zOutput2 = { "20020122122220Z", "20020122222220Z", "20020122022220Z", "20020122122220Z", "20020122122200Z", "20020122222200Z", "20020122022200Z", "20020122122200Z", "19550122122220Z", "19550122122200Z" };
  
  public String getName()
  {
    return "UTCTime";
  }
  
  public void performTest()
    throws Exception
  {
    SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
    SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyyMMddHHmmss'Z'");
    localSimpleDateFormat1.setTimeZone(new SimpleTimeZone(0, "Z"));
    localSimpleDateFormat2.setTimeZone(new SimpleTimeZone(0, "Z"));
    for (int i = 0; i != this.input.length; i++)
    {
      DERUTCTime localDERUTCTime = new DERUTCTime(this.input[i]);
      if (!localDERUTCTime.getAdjustedTime().equals(this.output[i])) {
        fail("failed conversion test " + i);
      }
      if (!localSimpleDateFormat1.format(localDERUTCTime.getAdjustedDate()).equals(this.zOutput1[i])) {
        fail("failed date conversion test " + i);
      }
      if (!localSimpleDateFormat2.format(localDERUTCTime.getDate()).equals(this.zOutput2[i])) {
        fail("failed date shortened conversion test " + i);
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new UTCTimeTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\asn1\test\UTCTimeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */