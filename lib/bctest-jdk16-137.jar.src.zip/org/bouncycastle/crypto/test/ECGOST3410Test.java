package org.bouncycastle.crypto.test;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.digests.GOST3411Digest;
import org.bouncycastle.crypto.generators.ECKeyPairGenerator;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECKeyGenerationParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.signers.ECGOST3410Signer;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.math.ec.ECFieldElement.Fp;
import org.bouncycastle.math.ec.ECPoint.Fp;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTest;

public class ECGOST3410Test
  extends SimpleTest
{
  byte[] hashmessage = Hex.decode("3042453136414534424341374533364339313734453431443642453241453435");
  BigInteger r = new BigInteger("29700980915817952874371204983938256990422752107994319651632687982059210933395");
  BigInteger s = new BigInteger("574973400270084654178925310019147038455227042649098563933718999175515839552");
  byte[] kData = new BigInteger("53854137677348463731403841147996619241504003434302020712960838528893196233395").toByteArray();
  SecureRandom k = new FixedSecureRandom(this.kData);
  
  private void ecGOST3410_TEST()
  {
    BigInteger localBigInteger = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564821041");
    ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("7"), new BigInteger("43308876546767276905765904595650931995942111794451039583252968842033849580414"));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("2")), new ECFieldElement.Fp(localBigInteger, new BigInteger("4018974056539037503335449422937059775635739389905545080690979365213431566280"))), new BigInteger("57896044618658097711785492504343953927082934583725450622380973592137631069619"));
    ECPrivateKeyParameters localECPrivateKeyParameters = new ECPrivateKeyParameters(new BigInteger("55441196065363246126355624130324183196576709222340016572108097750006097525544"), localECDomainParameters);
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localECPrivateKeyParameters, this.k);
    ECGOST3410Signer localECGOST3410Signer = new ECGOST3410Signer();
    localECGOST3410Signer.init(true, localParametersWithRandom);
    byte[] arrayOfByte1 = new BigInteger("20798893674476452017134061561508270130637142515379653289952617252661468872421").toByteArray();
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    for (int i = 0; i != arrayOfByte1.length; i++) {
      arrayOfByte2[i] = arrayOfByte1[(arrayOfByte1.length - 1 - i)];
    }
    BigInteger[] arrayOfBigInteger = localECGOST3410Signer.generateSignature(arrayOfByte2);
    if (!this.r.equals(arrayOfBigInteger[0])) {
      fail("r component wrong.", this.r, arrayOfBigInteger[0]);
    }
    if (!this.s.equals(arrayOfBigInteger[1])) {
      fail("s component wrong.", this.s, arrayOfBigInteger[1]);
    }
    ECPublicKeyParameters localECPublicKeyParameters = new ECPublicKeyParameters(new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("57520216126176808443631405023338071176630104906313632182896741342206604859403")), new ECFieldElement.Fp(localBigInteger, new BigInteger("17614944419213781543809391949654080031942662045363639260709847859438286763994"))), localECDomainParameters);
    localECGOST3410Signer.init(false, localECPublicKeyParameters);
    if (!localECGOST3410Signer.verifySignature(arrayOfByte2, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("verification fails");
    }
  }
  
  private void ecGOST3410_TestParam()
  {
    SecureRandom localSecureRandom = new SecureRandom();
    BigInteger localBigInteger = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564821041");
    ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("7"), new BigInteger("43308876546767276905765904595650931995942111794451039583252968842033849580414"));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("2")), new ECFieldElement.Fp(localBigInteger, new BigInteger("4018974056539037503335449422937059775635739389905545080690979365213431566280"))), new BigInteger("57896044618658097711785492504343953927082934583725450622380973592137631069619"));
    ECKeyPairGenerator localECKeyPairGenerator = new ECKeyPairGenerator();
    ECKeyGenerationParameters localECKeyGenerationParameters = new ECKeyGenerationParameters(localECDomainParameters, localSecureRandom);
    localECKeyPairGenerator.init(localECKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localECKeyPairGenerator.generateKeyPair();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localAsymmetricCipherKeyPair.getPrivate(), localSecureRandom);
    ECGOST3410Signer localECGOST3410Signer = new ECGOST3410Signer();
    localECGOST3410Signer.init(true, localParametersWithRandom);
    byte[] arrayOfByte1 = "Message for sign".getBytes();
    GOST3411Digest localGOST3411Digest = new GOST3411Digest();
    localGOST3411Digest.update(arrayOfByte1, 0, arrayOfByte1.length);
    byte[] arrayOfByte2 = new byte[localGOST3411Digest.getDigestSize()];
    localGOST3411Digest.doFinal(arrayOfByte2, 0);
    BigInteger[] arrayOfBigInteger = localECGOST3410Signer.generateSignature(arrayOfByte2);
    localECGOST3410Signer.init(false, localAsymmetricCipherKeyPair.getPublic());
    if (!localECGOST3410Signer.verifySignature(arrayOfByte2, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("signature fails");
    }
  }
  
  public void ecGOST3410_AParam()
  {
    SecureRandom localSecureRandom = new SecureRandom();
    BigInteger localBigInteger = new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639319");
    ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639316"), new BigInteger("166"));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("1")), new ECFieldElement.Fp(localBigInteger, new BigInteger("64033881142927202683649881450433473985931760268884941288852745803908878638612"))), new BigInteger("115792089237316195423570985008687907853073762908499243225378155805079068850323"));
    ECKeyPairGenerator localECKeyPairGenerator = new ECKeyPairGenerator();
    ECKeyGenerationParameters localECKeyGenerationParameters = new ECKeyGenerationParameters(localECDomainParameters, localSecureRandom);
    localECKeyPairGenerator.init(localECKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localECKeyPairGenerator.generateKeyPair();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localAsymmetricCipherKeyPair.getPrivate(), localSecureRandom);
    ECGOST3410Signer localECGOST3410Signer = new ECGOST3410Signer();
    localECGOST3410Signer.init(true, localParametersWithRandom);
    BigInteger[] arrayOfBigInteger = localECGOST3410Signer.generateSignature(this.hashmessage);
    localECGOST3410Signer.init(false, localAsymmetricCipherKeyPair.getPublic());
    if (!localECGOST3410Signer.verifySignature(this.hashmessage, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("signature fails");
    }
  }
  
  private void ecGOST3410_BParam()
  {
    SecureRandom localSecureRandom = new SecureRandom();
    BigInteger localBigInteger = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823193");
    ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823190"), new BigInteger("28091019353058090096996979000309560759124368558014865957655842872397301267595"));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("1")), new ECFieldElement.Fp(localBigInteger, new BigInteger("28792665814854611296992347458380284135028636778229113005756334730996303888124"))), new BigInteger("57896044618658097711785492504343953927102133160255826820068844496087732066703"));
    ECKeyPairGenerator localECKeyPairGenerator = new ECKeyPairGenerator();
    ECKeyGenerationParameters localECKeyGenerationParameters = new ECKeyGenerationParameters(localECDomainParameters, localSecureRandom);
    localECKeyPairGenerator.init(localECKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localECKeyPairGenerator.generateKeyPair();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localAsymmetricCipherKeyPair.getPrivate(), localSecureRandom);
    ECGOST3410Signer localECGOST3410Signer = new ECGOST3410Signer();
    localECGOST3410Signer.init(true, localParametersWithRandom);
    BigInteger[] arrayOfBigInteger = localECGOST3410Signer.generateSignature(this.hashmessage);
    localECGOST3410Signer.init(false, localAsymmetricCipherKeyPair.getPublic());
    if (!localECGOST3410Signer.verifySignature(this.hashmessage, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("signature fails");
    }
  }
  
  private void ecGOST3410_CParam()
  {
    SecureRandom localSecureRandom = new SecureRandom();
    BigInteger localBigInteger = new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502619");
    ECCurve.Fp localFp = new ECCurve.Fp(localBigInteger, new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502616"), new BigInteger("32858"));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, new ECPoint.Fp(localFp, new ECFieldElement.Fp(localBigInteger, new BigInteger("0")), new ECFieldElement.Fp(localBigInteger, new BigInteger("29818893917731240733471273240314769927240550812383695689146495261604565990247"))), new BigInteger("70390085352083305199547718019018437840920882647164081035322601458352298396601"));
    ECKeyPairGenerator localECKeyPairGenerator = new ECKeyPairGenerator();
    ECKeyGenerationParameters localECKeyGenerationParameters = new ECKeyGenerationParameters(localECDomainParameters, localSecureRandom);
    localECKeyPairGenerator.init(localECKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localECKeyPairGenerator.generateKeyPair();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localAsymmetricCipherKeyPair.getPrivate(), localSecureRandom);
    ECGOST3410Signer localECGOST3410Signer = new ECGOST3410Signer();
    localECGOST3410Signer.init(true, localParametersWithRandom);
    BigInteger[] arrayOfBigInteger = localECGOST3410Signer.generateSignature(this.hashmessage);
    localECGOST3410Signer.init(false, localAsymmetricCipherKeyPair.getPublic());
    if (!localECGOST3410Signer.verifySignature(this.hashmessage, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("signature fails");
    }
  }
  
  public String getName()
  {
    return "ECGOST3410";
  }
  
  public void performTest()
  {
    ecGOST3410_TEST();
    ecGOST3410_TestParam();
    ecGOST3410_AParam();
    ecGOST3410_BParam();
    ecGOST3410_CParam();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ECGOST3410Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ECGOST3410Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */