package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.params.DHKeyParameters;
import org.bouncycastle.crypto.params.DHParameters;

class DHTestKeyParameters
  extends DHKeyParameters
{
  protected DHTestKeyParameters(boolean paramBoolean, DHParameters paramDHParameters)
  {
    super(paramBoolean, paramDHParameters);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\DHTestKeyParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */