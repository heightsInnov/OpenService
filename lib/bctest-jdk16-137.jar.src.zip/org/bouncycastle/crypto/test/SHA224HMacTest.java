package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.digests.SHA224Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SHA224HMacTest
  implements Test
{
  static final String[] keys = { "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b", "4a656665", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0102030405060708090a0b0c0d0e0f10111213141516171819", "0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" };
  static final String[] digests = { "896fb1128abbdf196832107cd49df33f47b4b1169912ba4f53684b22", "a30e01098bc6dbbf45690f3a7e9e6d0f8bbea2a39e6148008fd05e44", "7fb3cb3588c6c1f6ffa9694d7d6ad2649365b0c1f65d69d1ec8333ea", "6c11506874013cac6a2abc1bb382627cec6a90d86efc012de7afec5a", "0e2aea68a90c8d37c988bcdb9fca6fa8099cd857c7ec4a1815cac54c", "95e9a0db962095adaebe9b2d6f0dbce2d499f112f2d2b7273fa6870e", "3a854166ac5d9f023f54d517d0b39dbd946770db9c2b95c9f6f565d1" };
  static final String[] messages = { "Hi There", "what do ya want for nothing?", "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "0xcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd", "Test With Truncation", "Test Using Larger Than Block-Size Key - Hash Key First", "This is a test using a larger than block-size key and a larger than block-size data. The key needs to be hashed before being used by the HMAC algorithm." };
  
  public String getName()
  {
    return "SHA224HMac";
  }
  
  public TestResult perform()
  {
    HMac localHMac = new HMac(new SHA224Digest());
    byte[] arrayOfByte1 = new byte[localHMac.getMacSize()];
    for (int i = 0; i < messages.length; i++)
    {
      arrayOfByte2 = messages[i].getBytes();
      if (messages[i].startsWith("0x")) {
        arrayOfByte2 = Hex.decode(messages[i].substring(2));
      }
      localHMac.init(new KeyParameter(Hex.decode(keys[i])));
      localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
      localHMac.doFinal(arrayOfByte1, 0);
      if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
        return new SimpleTestResult(false, getName() + ": Vector " + i + " failed got -" + new String(Hex.encode(arrayOfByte1)));
      }
    }
    i = 0;
    byte[] arrayOfByte2 = messages[i].getBytes();
    if (messages[i].startsWith("0x")) {
      arrayOfByte2 = Hex.decode(messages[i].substring(2));
    }
    localHMac.init(new KeyParameter(Hex.decode(keys[i])));
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    localHMac.reset();
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
      return new SimpleTestResult(false, getName() + "Reset with vector " + i + " failed");
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SHA224HMacTest localSHA224HMacTest = new SHA224HMacTest();
    TestResult localTestResult = localSHA224HMacTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\SHA224HMacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */