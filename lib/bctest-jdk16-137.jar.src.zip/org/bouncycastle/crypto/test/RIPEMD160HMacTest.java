package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.digests.RIPEMD160Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class RIPEMD160HMacTest
  implements Test
{
  static final String[] keys = { "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b", "4a656665", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0102030405060708090a0b0c0d0e0f10111213141516171819", "0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" };
  static final String[] digests = { "24cb4bd67d20fc1a5d2ed7732dcc39377f0a5668", "dda6c0213a485a9e24f4742064a7f033b43c4069", "b0b105360de759960ab4f35298e116e295d8e7c1", "d5ca862f4d21d5e610e18b4cf1beb97a4365ecf4", "7619693978f91d90539ae786500ff3d8e0518e39", "6466ca07ac5eac29e1bd523e5ada7605b791fd8b", "69ea60798d71616cce5fd0871e23754cd75d5a0a" };
  static final String[] messages = { "Hi There", "what do ya want for nothing?", "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "0xcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd", "Test With Truncation", "Test Using Larger Than Block-Size Key - Hash Key First", "Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data" };
  
  public String getName()
  {
    return "RIPEMD160HMac";
  }
  
  public TestResult perform()
  {
    HMac localHMac = new HMac(new RIPEMD160Digest());
    byte[] arrayOfByte1 = new byte[localHMac.getMacSize()];
    for (int i = 0; i < messages.length; i++)
    {
      byte[] arrayOfByte2 = messages[i].getBytes();
      if (messages[i].startsWith("0x")) {
        arrayOfByte2 = Hex.decode(messages[i].substring(2));
      }
      localHMac.init(new KeyParameter(Hex.decode(keys[i])));
      localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
      localHMac.doFinal(arrayOfByte1, 0);
      if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
        return new SimpleTestResult(false, getName() + ": Vector " + i + " failed");
      }
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    RIPEMD160HMacTest localRIPEMD160HMacTest = new RIPEMD160HMacTest();
    TestResult localTestResult = localRIPEMD160HMacTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\RIPEMD160HMacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */