package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.ExtendedDigest;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.digests.SHA512Digest;
import org.bouncycastle.crypto.digests.ShortenedDigest;
import org.bouncycastle.util.test.SimpleTest;

public class ShortenedDigestTest
  extends SimpleTest
{
  public void performTest()
  {
    Object localObject = new SHA1Digest();
    ShortenedDigest localShortenedDigest = new ShortenedDigest(new SHA1Digest(), 10);
    if (localShortenedDigest.getDigestSize() != 10) {
      fail("size check wrong for SHA-1");
    }
    if (localShortenedDigest.getByteLength() != ((ExtendedDigest)localObject).getByteLength()) {
      fail("byte length check wrong for SHA-1");
    }
    localShortenedDigest.doFinal(new byte[10], 0);
    localObject = new SHA512Digest();
    localShortenedDigest = new ShortenedDigest(new SHA512Digest(), 20);
    if (localShortenedDigest.getDigestSize() != 20) {
      fail("size check wrong for SHA-512");
    }
    if (localShortenedDigest.getByteLength() != ((ExtendedDigest)localObject).getByteLength()) {
      fail("byte length check wrong for SHA-512");
    }
    localShortenedDigest.doFinal(new byte[20], 0);
    try
    {
      new ShortenedDigest(null, 20);
      fail("null parameter not caught");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      new ShortenedDigest(new SHA1Digest(), 50);
      fail("short digest not caught");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
  }
  
  public String getName()
  {
    return "ShortenedDigest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ShortenedDigestTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ShortenedDigestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */