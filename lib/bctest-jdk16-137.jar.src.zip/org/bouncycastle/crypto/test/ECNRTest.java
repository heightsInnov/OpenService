package org.bouncycastle.crypto.test;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.signers.ECNRSigner;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.util.BigIntegers;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTest;

public class ECNRTest
  extends SimpleTest
{
  BigInteger r = new BigInteger("308636143175167811492623515537541734843573549327605293463169625072911693");
  BigInteger s = new BigInteger("852401710738814635664888632022555967400445256405412579597015412971797143");
  byte[] kData = BigIntegers.asUnsignedByteArray(new BigInteger("700000017569056646655505781757157107570501575775705779575555657156756655"));
  SecureRandom k = new FixedSecureRandom(true, this.kData);
  
  private void ecNR239bitPrime()
  {
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("883423532389192164791648750360308885314476597252960362792450860609699839"), new BigInteger("7fffffffffffffffffffffff7fffffffffff8000000000007ffffffffffc", 16), new BigInteger("6b016c3bdcf18941d0d654921475ca71a9db2fb27d1d37796185c2942c0a", 16));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, localFp.decodePoint(Hex.decode("020ffa963cdca8816ccc33b8642bedf905c3d358573d3f27fbbd3b3cb9aaaf")), new BigInteger("883423532389192164791648750360308884807550341691627752275345424702807307"));
    ECPrivateKeyParameters localECPrivateKeyParameters = new ECPrivateKeyParameters(new BigInteger("876300101507107567501066130761671078357010671067781776716671676178726717"), localECDomainParameters);
    ECNRSigner localECNRSigner = new ECNRSigner();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localECPrivateKeyParameters, this.k);
    localECNRSigner.init(true, localParametersWithRandom);
    byte[] arrayOfByte = new BigInteger("968236873715988614170569073515315707566766479517").toByteArray();
    BigInteger[] arrayOfBigInteger = localECNRSigner.generateSignature(arrayOfByte);
    if (!this.r.equals(arrayOfBigInteger[0])) {
      fail("r component wrong.", this.r, arrayOfBigInteger[0]);
    }
    if (!this.s.equals(arrayOfBigInteger[1])) {
      fail("s component wrong.", this.s, arrayOfBigInteger[1]);
    }
    ECPublicKeyParameters localECPublicKeyParameters = new ECPublicKeyParameters(localFp.decodePoint(Hex.decode("025b6dc53bc61a2548ffb0f671472de6c9521a9d2d2534e65abfcbd5fe0c70")), localECDomainParameters);
    localECNRSigner.init(false, localECPublicKeyParameters);
    if (!localECNRSigner.verifySignature(arrayOfByte, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("signature fails");
    }
  }
  
  public String getName()
  {
    return "ECNR";
  }
  
  public void performTest()
  {
    ecNR239bitPrime();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ECNRTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ECNRTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */