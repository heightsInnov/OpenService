package org.bouncycastle.crypto.test;

import java.security.SecureRandom;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.generators.DESKeyGenerator;
import org.bouncycastle.util.test.SimpleTest;

class KeyGenTest
  extends SimpleTest
{
  public String getName()
  {
    return "KeyGenTest";
  }
  
  public void performTest()
  {
    DESKeyGenerator localDESKeyGenerator = new DESKeyGenerator();
    localDESKeyGenerator.init(new KeyGenerationParameters(new SecureRandom(), 56));
    byte[] arrayOfByte = localDESKeyGenerator.generateKey();
    if (arrayOfByte.length != 8) {
      fail("DES bit key wrong length.");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\KeyGenTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */