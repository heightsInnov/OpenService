package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.engines.CAST5Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class CAST5Test
  extends CipherTest
{
  static SimpleTest[] tests = { new BlockCipherVectorTest(0, new CAST5Engine(), new KeyParameter(Hex.decode("0123456712345678234567893456789A")), "0123456789ABCDEF", "238B4FE5847E44B2"), new BlockCipherVectorTest(0, new CAST5Engine(), new KeyParameter(Hex.decode("01234567123456782345")), "0123456789ABCDEF", "EB6A711A2C02271B"), new BlockCipherVectorTest(0, new CAST5Engine(), new KeyParameter(Hex.decode("0123456712")), "0123456789ABCDEF", "7Ac816d16E9B302E") };
  
  CAST5Test()
  {
    super(tests, new CAST5Engine(), new KeyParameter(new byte[16]));
  }
  
  public String getName()
  {
    return "CAST5";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CAST5Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\CAST5Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */