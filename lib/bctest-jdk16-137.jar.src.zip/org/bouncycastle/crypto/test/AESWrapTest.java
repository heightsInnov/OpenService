package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Wrapper;
import org.bouncycastle.crypto.engines.AESWrapEngine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class AESWrapTest
  implements Test
{
  public String getName()
  {
    return "AESWrap";
  }
  
  private TestResult wrapTest(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    AESWrapEngine localAESWrapEngine = new AESWrapEngine();
    localAESWrapEngine.init(true, new KeyParameter(paramArrayOfByte1));
    try
    {
      byte[] arrayOfByte1 = localAESWrapEngine.wrap(paramArrayOfByte2, 0, paramArrayOfByte2.length);
      if (!Arrays.areEqual(arrayOfByte1, paramArrayOfByte3)) {
        return new SimpleTestResult(false, getName() + ": failed wrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte1)));
      }
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": failed wrap test exception " + localException1.toString());
    }
    localAESWrapEngine.init(false, new KeyParameter(paramArrayOfByte1));
    try
    {
      byte[] arrayOfByte2 = localAESWrapEngine.unwrap(paramArrayOfByte3, 0, paramArrayOfByte3.length);
      if (!Arrays.areEqual(arrayOfByte2, paramArrayOfByte2)) {
        return new SimpleTestResult(false, getName() + ": failed unwrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte2)));
      }
    }
    catch (Exception localException2)
    {
      return new SimpleTestResult(false, getName() + ": failed unwrap test exception.", localException2);
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult perform()
  {
    byte[] arrayOfByte1 = Hex.decode("000102030405060708090a0b0c0d0e0f");
    byte[] arrayOfByte2 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte3 = Hex.decode("1fa68b0a8112b447aef34bd8fb5a7b829d3e862371d2cfe5");
    TestResult localTestResult = wrapTest(1, arrayOfByte1, arrayOfByte2, arrayOfByte3);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    byte[] arrayOfByte4 = Hex.decode("000102030405060708090a0b0c0d0e0f1011121314151617");
    byte[] arrayOfByte5 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte6 = Hex.decode("96778b25ae6ca435f92b5b97c050aed2468ab8a17ad84e5d");
    localTestResult = wrapTest(2, arrayOfByte4, arrayOfByte5, arrayOfByte6);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    byte[] arrayOfByte7 = Hex.decode("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
    byte[] arrayOfByte8 = Hex.decode("00112233445566778899aabbccddeeff");
    byte[] arrayOfByte9 = Hex.decode("64e8c3f9ce0f5ba263e9777905818a2a93c8191e7d6e8ae7");
    localTestResult = wrapTest(3, arrayOfByte7, arrayOfByte8, arrayOfByte9);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    byte[] arrayOfByte10 = Hex.decode("000102030405060708090a0b0c0d0e0f1011121314151617");
    byte[] arrayOfByte11 = Hex.decode("00112233445566778899aabbccddeeff0001020304050607");
    byte[] arrayOfByte12 = Hex.decode("031d33264e15d33268f24ec260743edce1c6c7ddee725a936ba814915c6762d2");
    localTestResult = wrapTest(4, arrayOfByte10, arrayOfByte11, arrayOfByte12);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    byte[] arrayOfByte13 = Hex.decode("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
    byte[] arrayOfByte14 = Hex.decode("00112233445566778899aabbccddeeff0001020304050607");
    byte[] arrayOfByte15 = Hex.decode("a8f9bc1612c68b3ff6e6f4fbe30e71e4769c8b80a32cb8958cd5d17d6b254da1");
    localTestResult = wrapTest(5, arrayOfByte13, arrayOfByte14, arrayOfByte15);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    byte[] arrayOfByte16 = Hex.decode("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
    byte[] arrayOfByte17 = Hex.decode("00112233445566778899aabbccddeeff000102030405060708090a0b0c0d0e0f");
    byte[] arrayOfByte18 = Hex.decode("28c9f404c4b810f4cbccb35cfb87f8263f5786e2d80ed326cbc7f0e71a99f43bfb988b9b7a02dd21");
    localTestResult = wrapTest(6, arrayOfByte16, arrayOfByte17, arrayOfByte18);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    AESWrapEngine localAESWrapEngine = new AESWrapEngine();
    KeyParameter localKeyParameter = new KeyParameter(new byte[16]);
    byte[] arrayOfByte19 = new byte[16];
    try
    {
      localAESWrapEngine.init(true, localKeyParameter);
      localAESWrapEngine.unwrap(arrayOfByte19, 0, arrayOfByte19.length);
      return new SimpleTestResult(false, getName() + ": failed unwrap state test.");
    }
    catch (IllegalStateException localIllegalStateException1) {}catch (InvalidCipherTextException localInvalidCipherTextException1)
    {
      return new SimpleTestResult(false, getName() + ": unexpected exception: " + localInvalidCipherTextException1, localInvalidCipherTextException1);
    }
    try
    {
      localAESWrapEngine.init(false, localKeyParameter);
      localAESWrapEngine.wrap(arrayOfByte19, 0, arrayOfByte19.length);
      return new SimpleTestResult(false, getName() + ": failed unwrap state test.");
    }
    catch (IllegalStateException localIllegalStateException2)
    {
      try
      {
        localAESWrapEngine.init(false, localKeyParameter);
        localAESWrapEngine.unwrap(arrayOfByte19, 0, arrayOfByte19.length / 2);
        return new SimpleTestResult(false, getName() + ": failed unwrap short test.");
      }
      catch (InvalidCipherTextException localInvalidCipherTextException2)
      {
        try
        {
          localAESWrapEngine.init(true, localKeyParameter);
          localAESWrapEngine.wrap(arrayOfByte19, 0, 15);
          return new SimpleTestResult(false, getName() + ": failed wrap length test.");
        }
        catch (DataLengthException localDataLengthException) {}
      }
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    AESWrapTest localAESWrapTest = new AESWrapTest();
    TestResult localTestResult = localAESWrapTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\AESWrapTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */