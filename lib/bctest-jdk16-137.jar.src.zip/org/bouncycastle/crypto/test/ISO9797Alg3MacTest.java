package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.macs.ISO9797Alg3Mac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class ISO9797Alg3MacTest
  extends SimpleTest
{
  static byte[] keyBytes = Hex.decode("7CA110454A1A6E570131D9619DC1376E");
  static byte[] ivBytes = Hex.decode("0000000000000000");
  static byte[] input1 = "Hello World !!!!".getBytes();
  static byte[] output1 = Hex.decode("F09B856213BAB83B");
  
  public void performTest()
  {
    KeyParameter localKeyParameter = new KeyParameter(keyBytes);
    DESEngine localDESEngine = new DESEngine();
    ISO9797Alg3Mac localISO9797Alg3Mac = new ISO9797Alg3Mac(localDESEngine);
    localISO9797Alg3Mac.init(localKeyParameter);
    localISO9797Alg3Mac.update(input1, 0, input1.length);
    byte[] arrayOfByte = new byte[8];
    localISO9797Alg3Mac.doFinal(arrayOfByte, 0);
    if (!areEqual(arrayOfByte, output1)) {
      fail("Failed - expected " + new String(Hex.encode(output1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localISO9797Alg3Mac.reset();
    localISO9797Alg3Mac.init(localKeyParameter);
    for (int i = 0; i != input1.length / 2; i++) {
      localISO9797Alg3Mac.update(input1[i]);
    }
    localISO9797Alg3Mac.update(input1, input1.length / 2, input1.length - input1.length / 2);
    localISO9797Alg3Mac.doFinal(arrayOfByte, 0);
    if (!areEqual(arrayOfByte, output1)) {
      fail("Reset failed - expected " + new String(Hex.encode(output1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public String getName()
  {
    return "ISO9797Alg3Mac";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ISO9797Alg3MacTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ISO9797Alg3MacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */