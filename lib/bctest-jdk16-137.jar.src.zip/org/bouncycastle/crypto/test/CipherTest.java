package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.test.SimpleTest;

public abstract class CipherTest
  extends SimpleTest
{
  private SimpleTest[] _tests;
  private BlockCipher _engine;
  private KeyParameter _validKey;
  
  protected CipherTest(SimpleTest[] paramArrayOfSimpleTest, BlockCipher paramBlockCipher, KeyParameter paramKeyParameter)
  {
    this._tests = paramArrayOfSimpleTest;
    this._engine = paramBlockCipher;
    this._validKey = paramKeyParameter;
  }
  
  public abstract String getName();
  
  public void performTest()
    throws Exception
  {
    for (int i = 0; i != this._tests.length; i++) {
      this._tests[i].performTest();
    }
    if (this._engine != null)
    {
      byte[] arrayOfByte = new byte[16];
      try
      {
        this._engine.processBlock(arrayOfByte, 0, arrayOfByte, 0);
        fail("failed initialisation check");
      }
      catch (IllegalStateException localIllegalStateException) {}
      bufferSizeCheck(this._engine);
    }
  }
  
  private void bufferSizeCheck(BlockCipher paramBlockCipher)
  {
    byte[] arrayOfByte1 = new byte[paramBlockCipher.getBlockSize()];
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length / 2];
    paramBlockCipher.init(true, this._validKey);
    try
    {
      paramBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte1, 0);
      fail("failed short input check");
    }
    catch (DataLengthException localDataLengthException1) {}
    try
    {
      paramBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
      fail("failed short output check");
    }
    catch (DataLengthException localDataLengthException2) {}
    paramBlockCipher.init(false, this._validKey);
    try
    {
      paramBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte1, 0);
      fail("failed short input check");
    }
    catch (DataLengthException localDataLengthException3) {}
    try
    {
      paramBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
      fail("failed short output check");
    }
    catch (DataLengthException localDataLengthException4) {}
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\CipherTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */