package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class BlockCipherMonteCarloTest
  extends SimpleTest
{
  int id;
  int iterations;
  BlockCipher engine;
  CipherParameters param;
  byte[] input;
  byte[] output;
  
  public BlockCipherMonteCarloTest(int paramInt1, int paramInt2, BlockCipher paramBlockCipher, CipherParameters paramCipherParameters, String paramString1, String paramString2)
  {
    this.id = paramInt1;
    this.iterations = paramInt2;
    this.engine = paramBlockCipher;
    this.param = paramCipherParameters;
    this.input = Hex.decode(paramString1);
    this.output = Hex.decode(paramString2);
  }
  
  public String getName()
  {
    return this.engine.getAlgorithmName() + " Monte Carlo Test " + this.id;
  }
  
  public void performTest()
    throws Exception
  {
    BufferedBlockCipher localBufferedBlockCipher = new BufferedBlockCipher(this.engine);
    localBufferedBlockCipher.init(true, this.param);
    byte[] arrayOfByte = new byte[this.input.length];
    System.arraycopy(this.input, 0, arrayOfByte, 0, arrayOfByte.length);
    int j;
    for (int i = 0; i != this.iterations; i++)
    {
      j = localBufferedBlockCipher.processBytes(arrayOfByte, 0, arrayOfByte.length, arrayOfByte, 0);
      localBufferedBlockCipher.doFinal(arrayOfByte, j);
    }
    if (!areEqual(arrayOfByte, this.output)) {
      fail("failed - expected " + new String(Hex.encode(this.output)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localBufferedBlockCipher.init(false, this.param);
    for (i = 0; i != this.iterations; i++)
    {
      j = localBufferedBlockCipher.processBytes(arrayOfByte, 0, arrayOfByte.length, arrayOfByte, 0);
      localBufferedBlockCipher.doFinal(arrayOfByte, j);
    }
    if (!areEqual(this.input, arrayOfByte)) {
      fail("failed reversal");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\BlockCipherMonteCarloTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */