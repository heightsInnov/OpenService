package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import java.security.SecureRandom;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Wrapper;
import org.bouncycastle.crypto.engines.RC2WrapEngine;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.params.RC2Parameters;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class RC2WrapTest
  implements Test
{
  private TestResult wrapTest(int paramInt, CipherParameters paramCipherParameters1, CipherParameters paramCipherParameters2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    RC2WrapEngine localRC2WrapEngine = new RC2WrapEngine();
    localRC2WrapEngine.init(true, paramCipherParameters1);
    try
    {
      byte[] arrayOfByte1 = localRC2WrapEngine.wrap(paramArrayOfByte1, 0, paramArrayOfByte1.length);
      if (!Arrays.areEqual(arrayOfByte1, paramArrayOfByte2)) {
        return new SimpleTestResult(false, getName() + ": failed wrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte1)));
      }
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": failed wrap test exception " + localException1.toString(), localException1);
    }
    localRC2WrapEngine.init(false, paramCipherParameters2);
    try
    {
      byte[] arrayOfByte2 = localRC2WrapEngine.unwrap(paramArrayOfByte2, 0, paramArrayOfByte2.length);
      if (!Arrays.areEqual(arrayOfByte2, paramArrayOfByte1)) {
        return new SimpleTestResult(false, getName() + ": failed unwrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte1)) + " got " + new String(Hex.encode(arrayOfByte2)));
      }
    }
    catch (Exception localException2)
    {
      return new SimpleTestResult(false, getName() + ": failed unwrap test exception " + localException2.toString(), localException2);
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public TestResult perform()
  {
    byte[] arrayOfByte1 = Hex.decode("fd04fd08060707fb0003fefffd02fe05");
    byte[] arrayOfByte2 = Hex.decode("c7d90059b29e97f7");
    byte[] arrayOfByte3 = Hex.decode("b70a25fbc9d86a86050ce0d711ead4d9");
    byte[] arrayOfByte4 = Hex.decode("70e699fb5701f7833330fb71e87c85a420bdc99af05d22af5a0e48d35f3138986cbaafb4b28d4f35");
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(new ParametersWithIV(new RC2Parameters(arrayOfByte1, 40), arrayOfByte2), new RFCRandom(null));
    RC2Parameters localRC2Parameters = new RC2Parameters(arrayOfByte1, 40);
    TestResult localTestResult = wrapTest(1, localParametersWithRandom, localRC2Parameters, arrayOfByte3, arrayOfByte4);
    if (!localTestResult.isSuccessful()) {
      return localTestResult;
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "RC2Wrap";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    RC2WrapTest localRC2WrapTest = new RC2WrapTest();
    TestResult localTestResult = localRC2WrapTest.perform();
    System.out.println(localTestResult);
  }
  
  private class RFCRandom
    extends SecureRandom
  {
    private RFCRandom() {}
    
    public void nextBytes(byte[] paramArrayOfByte)
    {
      System.arraycopy(Hex.decode("4845cce7fd1250"), 0, paramArrayOfByte, 0, paramArrayOfByte.length);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\RC2WrapTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */