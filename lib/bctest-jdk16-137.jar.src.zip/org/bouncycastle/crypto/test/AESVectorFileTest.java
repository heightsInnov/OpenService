package org.bouncycastle.crypto.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.engines.AESFastEngine;
import org.bouncycastle.crypto.engines.AESLightEngine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class AESVectorFileTest
  implements Test
{
  private int countOfTests = 0;
  private int testNum = 0;
  private static final String[] zipFileNames = { "rijn.tv.ecbnk.zip", "rijn.tv.ecbnt.zip", "rijn.tv.ecbvk.zip", "rijn.tv.ecbvt.zip" };
  
  protected BlockCipher createNewEngineForTest()
  {
    return new AESEngine();
  }
  
  private Test[] readTestVectors(InputStream paramInputStream)
  {
    ArrayList localArrayList = new ArrayList();
    String str1 = null;
    String str2 = null;
    String str3 = null;
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    try
    {
      for (String str4 = localBufferedReader.readLine(); str4 != null; str4 = localBufferedReader.readLine())
      {
        str4 = str4.trim().toLowerCase();
        int i;
        if (str4.startsWith("blocksize="))
        {
          i = 0;
          try
          {
            i = Integer.parseInt(str4.substring(10).trim());
          }
          catch (Exception localException1) {}
          if (i != 128) {
            return null;
          }
        }
        else if (str4.startsWith("keysize="))
        {
          i = 0;
          try
          {
            i = Integer.parseInt(str4.substring(10).trim());
          }
          catch (Exception localException2) {}
          if ((i != 128) && (i != 192) && (i != 256)) {
            return null;
          }
        }
        else if (str4.startsWith("key="))
        {
          str1 = str4.substring(4).trim();
        }
        else if (str4.startsWith("pt="))
        {
          str2 = str4.substring(3).trim();
        }
        else if (str4.startsWith("ct="))
        {
          str3 = str4.substring(3).trim();
        }
        else if ((str4.startsWith("test=")) && (str1 != null) && (str2 != null) && (str3 != null))
        {
          localArrayList.add(new BlockCipherVectorTest(this.testNum++, createNewEngineForTest(), new KeyParameter(Hex.decode(str1)), str2, str3));
        }
      }
      try
      {
        localBufferedReader.close();
      }
      catch (IOException localIOException2) {}
    }
    catch (IOException localIOException1) {}
    if ((str1 != null) && (str2 != null) && (str3 != null)) {
      localArrayList.add(new BlockCipherVectorTest(this.testNum++, createNewEngineForTest(), new KeyParameter(Hex.decode(str1)), str2, str3));
    }
    return (Test[])localArrayList.toArray(new Test[localArrayList.size()]);
  }
  
  public String getName()
  {
    return "AES";
  }
  
  private TestResult performTestsFromZipFile(File paramFile)
  {
    try
    {
      ZipFile localZipFile = new ZipFile(paramFile);
      Enumeration localEnumeration = localZipFile.entries();
      while (localEnumeration.hasMoreElements())
      {
        Test[] arrayOfTest = null;
        try
        {
          arrayOfTest = readTestVectors(localZipFile.getInputStream((ZipEntry)localEnumeration.nextElement()));
        }
        catch (Exception localException2)
        {
          return new SimpleTestResult(false, getName() + ": threw " + localException2);
        }
        if (arrayOfTest != null) {
          for (int i = 0; i != arrayOfTest.length; i++)
          {
            TestResult localTestResult = arrayOfTest[i].perform();
            this.countOfTests += 1;
            if (!localTestResult.isSuccessful()) {
              return localTestResult;
            }
          }
        }
      }
      localZipFile.close();
      return new SimpleTestResult(true, getName() + ": Okay");
    }
    catch (Exception localException1)
    {
      return new SimpleTestResult(false, getName() + ": threw " + localException1);
    }
  }
  
  public TestResult perform()
  {
    this.countOfTests = 0;
    for (int i = 0; i < zipFileNames.length; i++)
    {
      File localFile = new File(zipFileNames[i]);
      TestResult localTestResult = performTestsFromZipFile(localFile);
      if (!localTestResult.isSuccessful()) {
        return localTestResult;
      }
    }
    return new SimpleTestResult(true, getName() + ": " + this.countOfTests + " performed Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Object localObject = new AESVectorFileTest();
    TestResult localTestResult = ((AESVectorFileTest)localObject).perform();
    System.out.println(localTestResult);
    localObject = new AESLightVectorFileTest(null);
    localTestResult = ((AESVectorFileTest)localObject).perform();
    System.out.println(localTestResult);
    localObject = new AESFastVectorFileTest(null);
    localTestResult = ((AESVectorFileTest)localObject).perform();
    System.out.println(localTestResult);
  }
  
  private static class AESFastVectorFileTest
    extends AESVectorFileTest
  {
    protected BlockCipher createNewEngineForTest()
    {
      return new AESFastEngine();
    }
    
    public String getName()
    {
      return "AESFast";
    }
  }
  
  private static class AESLightVectorFileTest
    extends AESVectorFileTest
  {
    protected BlockCipher createNewEngineForTest()
    {
      return new AESLightEngine();
    }
    
    public String getName()
    {
      return "AESLight";
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\AESVectorFileTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */