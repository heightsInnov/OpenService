package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.digests.MD5Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class MD5HMacTest
  extends SimpleTest
{
  static final String[] keys = { "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b", "4a656665", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0102030405060708090a0b0c0d0e0f10111213141516171819", "0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" };
  static final String[] digests = { "9294727a3638bb1c13f48ef8158bfc9d", "750c783e6ab0b503eaa86e310a5db738", "56be34521d144c88dbb8c733f0e8b3f6", "697eaf0aca3a3aea3a75164746ffaa79", "56461ef2342edc00f9bab995690efd4c", "6b1ab7fe4bd7bf8f0b62e6ce61b9d0cd", "6f630fad67cda0ee1fb1f562db3aa53e" };
  static final String[] messages = { "Hi There", "what do ya want for nothing?", "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "0xcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd", "Test With Truncation", "Test Using Larger Than Block-Size Key - Hash Key First", "Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data" };
  
  public String getName()
  {
    return "MD5HMac";
  }
  
  public void performTest()
  {
    HMac localHMac = new HMac(new MD5Digest());
    byte[] arrayOfByte1 = new byte[localHMac.getMacSize()];
    for (int i = 0; i < messages.length; i++)
    {
      arrayOfByte2 = messages[i].getBytes();
      if (messages[i].startsWith("0x")) {
        arrayOfByte2 = Hex.decode(messages[i].substring(2));
      }
      localHMac.init(new KeyParameter(Hex.decode(keys[i])));
      localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
      localHMac.doFinal(arrayOfByte1, 0);
      if (!areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
        fail("Vector " + i + " failed");
      }
    }
    i = 0;
    byte[] arrayOfByte2 = messages[i].getBytes();
    if (messages[i].startsWith("0x")) {
      arrayOfByte2 = Hex.decode(messages[i].substring(2));
    }
    localHMac.init(new KeyParameter(Hex.decode(keys[i])));
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    localHMac.reset();
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    if (!areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
      fail("Reset with vector " + i + " failed");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new MD5HMacTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\MD5HMacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */