package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.MD4Digest;

public class MD4DigestTest
  extends DigestTest
{
  private static String[] messages = { "", "a", "abc", "12345678901234567890123456789012345678901234567890123456789012345678901234567890" };
  private static String[] digests = { "31d6cfe0d16ae931b73c59d7e0c089c0", "bde52cb31de33e46245e05fbdbd6fb24", "a448017aaf21d8525fc10ae87aa6729d", "e33b4ddc9c38f2199c3e7b164fcc0536" };
  
  MD4DigestTest()
  {
    super(new MD4Digest(), messages, digests);
  }
  
  protected Digest cloneDigest(Digest paramDigest)
  {
    return new MD4Digest((MD4Digest)paramDigest);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new MD4DigestTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\MD4DigestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */