package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.engines.GOST28147Engine;
import org.bouncycastle.crypto.macs.GOST28147Mac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithSBox;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class GOST28147MacTest
  implements Test
{
  static byte[] gkeyBytes1 = Hex.decode("6d145dc993f4019e104280df6fcd8cd8e01e101e4c113d7ec4f469ce6dcd9e49");
  static byte[] gkeyBytes2 = Hex.decode("6d145dc993f4019e104280df6fcd8cd8e01e101e4c113d7ec4f469ce6dcd9e49");
  static byte[] input3 = Hex.decode("7768617420646f2079612077616e7420666f72206e6f7468696e673f");
  static byte[] input4 = Hex.decode("7768617420646f2079612077616e7420666f72206e6f7468696e673f");
  static byte[] output7 = Hex.decode("93468a46");
  static byte[] output8 = Hex.decode("93468a46");
  
  public TestResult perform()
  {
    GOST28147Mac localGOST28147Mac = new GOST28147Mac();
    KeyParameter localKeyParameter = new KeyParameter(gkeyBytes1);
    localGOST28147Mac.init(localKeyParameter);
    localGOST28147Mac.update(input3, 0, input3.length);
    byte[] arrayOfByte = new byte[4];
    localGOST28147Mac.doFinal(arrayOfByte, 0);
    if (!Arrays.areEqual(arrayOfByte, output7)) {
      return new SimpleTestResult(false, getName() + ": Failed test 1 - expected " + new String(Hex.encode(output7)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localKeyParameter = new KeyParameter(gkeyBytes2);
    ParametersWithSBox localParametersWithSBox = new ParametersWithSBox(localKeyParameter, GOST28147Engine.getSBox("E-A"));
    localGOST28147Mac.init(localParametersWithSBox);
    localGOST28147Mac.update(input4, 0, input4.length);
    arrayOfByte = new byte[4];
    localGOST28147Mac.doFinal(arrayOfByte, 0);
    if (!Arrays.areEqual(arrayOfByte, output8)) {
      return new SimpleTestResult(false, getName() + ": Failed test 2 - expected " + new String(Hex.encode(output8)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "GOST28147Mac";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    GOST28147MacTest localGOST28147MacTest = new GOST28147MacTest();
    TestResult localTestResult = localGOST28147MacTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\GOST28147MacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */