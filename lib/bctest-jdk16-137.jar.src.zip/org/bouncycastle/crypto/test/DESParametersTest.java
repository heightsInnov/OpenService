package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.params.DESParameters;
import org.bouncycastle.util.test.SimpleTest;

class DESParametersTest
  extends SimpleTest
{
  private static byte[] weakKeys = { 1, 1, 1, 1, 1, 1, 1, 1, 31, 31, 31, 31, 14, 14, 14, 14, -32, -32, -32, -32, -15, -15, -15, -15, -2, -2, -2, -2, -2, -2, -2, -2, 1, -2, 1, -2, 1, -2, 1, -2, 31, -32, 31, -32, 14, -15, 14, -15, 1, -32, 1, -32, 1, -15, 1, -15, 31, -2, 31, -2, 14, -2, 14, -2, 1, 31, 1, 31, 1, 14, 1, 14, -32, -2, -32, -2, -15, -2, -15, -2, -2, 1, -2, 1, -2, 1, -2, 1, -32, 31, -32, 31, -15, 14, -15, 14, -32, 1, -32, 1, -15, 1, -15, 1, -2, 31, -2, 31, -2, 14, -2, 14, 31, 1, 31, 1, 14, 1, 14, 1, -2, -32, -2, -32, -2, -15, -2, -15 };
  
  public String getName()
  {
    return "DESParameters";
  }
  
  public void performTest()
    throws Exception
  {
    try
    {
      DESParameters.isWeakKey(new byte[4], 0);
      fail("no exception on small key");
    }
    catch (IllegalArgumentException localIllegalArgumentException1)
    {
      if (!localIllegalArgumentException1.getMessage().equals("key material too short.")) {
        fail("wrong exception");
      }
    }
    try
    {
      new DESParameters(weakKeys);
      fail("no exception on weak key");
    }
    catch (IllegalArgumentException localIllegalArgumentException2)
    {
      if (!localIllegalArgumentException2.getMessage().equals("attempt to create weak DES key")) {
        fail("wrong exception");
      }
    }
    for (int i = 0; i != weakKeys.length; i += 8) {
      if (!DESParameters.isWeakKey(weakKeys, i)) {
        fail("weakKey test failed");
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\DESParametersTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */