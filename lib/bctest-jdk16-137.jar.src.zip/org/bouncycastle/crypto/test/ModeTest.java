package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.modes.CFBBlockCipher;
import org.bouncycastle.crypto.modes.OFBBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class ModeTest
  implements Test
{
  private boolean isEqualTo(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    for (int i = 0; i != paramArrayOfByte1.length; i++) {
      if (paramArrayOfByte1[i] != paramArrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  public TestResult perform()
  {
    KeyParameter localKeyParameter = new KeyParameter(Hex.decode("0011223344556677"));
    byte[] arrayOfByte1 = Hex.decode("4e6f7720");
    byte[] arrayOfByte2 = new byte[4];
    byte[] arrayOfByte3 = new byte[4];
    OFBBlockCipher localOFBBlockCipher = new OFBBlockCipher(new DESEngine(), 32);
    localOFBBlockCipher.init(true, new ParametersWithIV(localKeyParameter, Hex.decode("1122334455667788")));
    localOFBBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
    localOFBBlockCipher.init(false, new ParametersWithIV(localKeyParameter, Hex.decode("1122334455667788")));
    localOFBBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte3, 0);
    if (!isEqualTo(arrayOfByte3, arrayOfByte1)) {
      return new SimpleTestResult(false, getName() + ": test 1 - in != out");
    }
    localOFBBlockCipher.init(true, new ParametersWithIV(localKeyParameter, Hex.decode("11223344")));
    localOFBBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
    localOFBBlockCipher.init(false, new ParametersWithIV(localKeyParameter, Hex.decode("0000000011223344")));
    localOFBBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte3, 0);
    if (!isEqualTo(arrayOfByte3, arrayOfByte1)) {
      return new SimpleTestResult(false, getName() + ": test 2 - in != out");
    }
    CFBBlockCipher localCFBBlockCipher = new CFBBlockCipher(new DESEngine(), 32);
    localCFBBlockCipher.init(true, new ParametersWithIV(localKeyParameter, Hex.decode("1122334455667788")));
    localCFBBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
    localCFBBlockCipher.init(false, new ParametersWithIV(localKeyParameter, Hex.decode("1122334455667788")));
    localCFBBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte3, 0);
    if (!isEqualTo(arrayOfByte3, arrayOfByte1)) {
      return new SimpleTestResult(false, getName() + ": test 3 - in != out");
    }
    localCFBBlockCipher.init(true, new ParametersWithIV(localKeyParameter, Hex.decode("11223344")));
    localCFBBlockCipher.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
    localCFBBlockCipher.init(false, new ParametersWithIV(localKeyParameter, Hex.decode("0000000011223344")));
    localCFBBlockCipher.processBlock(arrayOfByte2, 0, arrayOfByte3, 0);
    if (!isEqualTo(arrayOfByte3, arrayOfByte1)) {
      return new SimpleTestResult(false, getName() + ": test 4 - in != out");
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public String getName()
  {
    return "ModeTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    ModeTest localModeTest = new ModeTest();
    TestResult localTestResult = localModeTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ModeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */