package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.engines.SkipjackEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.modes.CTSBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class CTSTest
  extends SimpleTest
{
  static byte[] in1 = Hex.decode("4e6f7720697320746865207420");
  static byte[] in2 = Hex.decode("000102030405060708090a0b0c0d0e0fff0102030405060708090a0b0c0d0e0f0aaa");
  static byte[] out1 = Hex.decode("9952f131588465033fa40e8a98");
  static byte[] out2 = Hex.decode("358f84d01eb42988dc34efb994");
  static byte[] out3 = Hex.decode("170171cfad3f04530c509b0c1f0be0aefbd45a8e3755a873bff5ea198504b71683c6");
  
  private void testCTS(int paramInt, BlockCipher paramBlockCipher, CipherParameters paramCipherParameters, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception
  {
    byte[] arrayOfByte = new byte[paramArrayOfByte1.length];
    CTSBlockCipher localCTSBlockCipher = new CTSBlockCipher(paramBlockCipher);
    localCTSBlockCipher.init(true, paramCipherParameters);
    int i = localCTSBlockCipher.processBytes(paramArrayOfByte1, 0, paramArrayOfByte1.length, arrayOfByte, 0);
    localCTSBlockCipher.doFinal(arrayOfByte, i);
    if (!areEqual(paramArrayOfByte2, arrayOfByte)) {
      fail("failed encryption expected " + new String(Hex.encode(paramArrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localCTSBlockCipher.init(false, paramCipherParameters);
    i = localCTSBlockCipher.processBytes(paramArrayOfByte2, 0, paramArrayOfByte2.length, arrayOfByte, 0);
    localCTSBlockCipher.doFinal(arrayOfByte, i);
    if (!areEqual(paramArrayOfByte1, arrayOfByte)) {
      fail("failed encryption expected " + new String(Hex.encode(paramArrayOfByte1)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
  }
  
  public String getName()
  {
    return "CTS";
  }
  
  public void performTest()
    throws Exception
  {
    byte[] arrayOfByte1 = { 1, 35, 69, 103, -119, -85, -51, -17 };
    byte[] arrayOfByte2 = { 1, 35, 69, 103, -119, -85, -51, -17, -18, -1 };
    byte[] arrayOfByte3 = { 1, 2, 3, 4, 5, 6, 7, 8 };
    testCTS(1, new DESEngine(), new KeyParameter(arrayOfByte1), in1, out1);
    testCTS(2, new CBCBlockCipher(new DESEngine()), new ParametersWithIV(new KeyParameter(arrayOfByte1), arrayOfByte3), in1, out2);
    testCTS(3, new CBCBlockCipher(new SkipjackEngine()), new ParametersWithIV(new KeyParameter(arrayOfByte2), arrayOfByte3), in2, out3);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CTSTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\CTSTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */