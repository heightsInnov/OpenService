package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.digests.SHA384Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SHA384HMacTest
  implements Test
{
  static final String[] keys = { "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b", "4a656665", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0102030405060708090a0b0c0d0e0f10111213141516171819", "0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" };
  static final String[] digests = { "afd03944d84895626b0825f4ab46907f15f9dadbe4101ec682aa034c7cebc59cfaea9ea9076ede7f4af152e8b2fa9cb6", "af45d2e376484031617f78d2b58a6b1b9c7ef464f5a01b47e42ec3736322445e8e2240ca5e69e2c78b3239ecfab21649", "88062608d3e6ad8a0aa2ace014c8a86f0aa635d947ac9febe83ef4e55966144b2a5ab39dc13814b94e3ab6e101a34f27", "3e8a69b7783c25851933ab6290af6ca77a9981480850009cc5577c6e1f573b4e6801dd23c4a7d679ccf8a386c674cffb", "3abf34c3503b2a23a46efc619baef897f4c8e42c934ce55ccbae9740fcbc1af4ca62269e2a37cd88ba926341efe4aeea", "4ece084485813e9088d2c63a041bc5b44f9ef1012a2b588f3cd11f05033ac4c60c2ef6ab4030fe8296248df163f44952", "6617178e941f020d351e2f254e8fd32c602420feb0b8fb9adccebb82461e99c5a678cc31e799176d3860e6110c46523e" };
  static final String[] messages = { "Hi There", "what do ya want for nothing?", "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "0xcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd", "Test With Truncation", "Test Using Larger Than Block-Size Key - Hash Key First", "This is a test using a larger than block-size key and a larger than block-size data. The key needs to be hashed before being used by the HMAC algorithm." };
  
  public String getName()
  {
    return "SHA384HMac";
  }
  
  public TestResult perform()
  {
    HMac localHMac = new HMac(new SHA384Digest());
    byte[] arrayOfByte1 = new byte[localHMac.getMacSize()];
    for (int i = 0; i < messages.length; i++)
    {
      arrayOfByte2 = messages[i].getBytes();
      if (messages[i].startsWith("0x")) {
        arrayOfByte2 = Hex.decode(messages[i].substring(2));
      }
      localHMac.init(new KeyParameter(Hex.decode(keys[i])));
      localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
      localHMac.doFinal(arrayOfByte1, 0);
      if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
        return new SimpleTestResult(false, getName() + ": Vector " + i + " failed got -" + new String(Hex.encode(arrayOfByte1)));
      }
    }
    i = 0;
    byte[] arrayOfByte2 = messages[i].getBytes();
    if (messages[i].startsWith("0x")) {
      arrayOfByte2 = Hex.decode(messages[i].substring(2));
    }
    localHMac.init(new KeyParameter(Hex.decode(keys[i])));
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    localHMac.reset();
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
      return new SimpleTestResult(false, getName() + "Reset with vector " + i + " failed");
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SHA384HMacTest localSHA384HMacTest = new SHA384HMacTest();
    TestResult localTestResult = localSHA384HMacTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\SHA384HMacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */