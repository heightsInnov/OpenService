package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.GOST3411Digest;

public class GOST3411DigestTest
  extends DigestTest
{
  private static final String[] messages = { "", "This is message, length=32 bytes", "Suppose the original message has length = 50 bytes", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789" };
  private static final String[] digests = { "981e5f3ca30c841487830f84fb433e13ac1101569b9c13584ac483234cd656c0", "2cefc2f7b7bdc514e18ea57fa74ff357e7fa17d652c75f69cb1be7893ede48eb", "c3730c5cbccacf915ac292676f21e8bd4ef75331d9405e5f1a61dc3130a65011", "73b70a39497de53a6e08c67b6d4db853540f03e9389299d9b0156ef7e85d0f61" };
  private static String million_a_digest = "8693287aa62f9478f7cb312ec0866b6c4e4a0f11160441e8f4ffcd2715dd554f";
  
  GOST3411DigestTest()
  {
    super(new GOST3411Digest(), messages, digests);
  }
  
  public void performTest()
  {
    super.performTest();
    millionATest(million_a_digest);
  }
  
  protected Digest cloneDigest(Digest paramDigest)
  {
    return new GOST3411Digest((GOST3411Digest)paramDigest);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new GOST3411DigestTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\GOST3411DigestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */