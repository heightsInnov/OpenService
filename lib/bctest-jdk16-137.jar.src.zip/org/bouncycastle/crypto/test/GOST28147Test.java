package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.digests.GOST3411Digest;
import org.bouncycastle.crypto.engines.GOST28147Engine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.modes.CFBBlockCipher;
import org.bouncycastle.crypto.modes.GOFBBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.crypto.params.ParametersWithSBox;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class GOST28147Test
  extends CipherTest
{
  static String input1 = "0000000000000000";
  static String output1 = "1b0bbc32cebcab42";
  static String input2 = "bc350e71aac5f5c2";
  static String output2 = "d35ab653493b49f5";
  static String input3 = "bc350e71aa11345709acde";
  static String output3 = "8824c124c4fd14301fb1e8";
  static String input4 = "000102030405060708090a0b0c0d0e0fff0102030405060708090a0b0c0d0e0f";
  static String output4 = "29b7083e0a6d955ca0ec5b04fdb4ea41949f1dd2efdf17baffc1780b031f3934";
  static byte[] TestSBox = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
  static SimpleTest[] tests = { new BlockCipherVectorTest(1, new GOST28147Engine(), new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), input1, output1), new BlockCipherVectorTest(2, new CBCBlockCipher(new GOST28147Engine()), new ParametersWithIV(new KeyParameter(Hex.decode("00112233445566778899AABBCCDDEEFF00112233445566778899AABBCCDDEEFF")), Hex.decode("1234567890abcdef")), input2, output2), new BlockCipherVectorTest(3, new GOFBBlockCipher(new GOST28147Engine()), new ParametersWithIV(new KeyParameter(Hex.decode("0011223344556677889900112233445566778899001122334455667788990011")), Hex.decode("1234567890abcdef")), input3, output3), new BlockCipherVectorTest(4, new CFBBlockCipher(new GOST28147Engine(), 64), new ParametersWithIV(new KeyParameter(Hex.decode("aafd12f659cae63489b479e5076ddec2f06cb58faafd12f659cae63489b479e5")), Hex.decode("aafd12f659cae634")), input4, output4), new BlockCipherVectorTest(5, new GOST28147Engine(), new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), input1, output1), new BlockCipherVectorTest(6, new CFBBlockCipher(new GOST28147Engine(), 64), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("D-Test")), Hex.decode("1234567890abcdef")), "0000000000000000", "b587f7a0814c911d"), new BlockCipherVectorTest(7, new CFBBlockCipher(new GOST28147Engine(), 64), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("E-Test")), Hex.decode("1234567890abcdef")), "0000000000000000", "e8287f53f991d52b"), new BlockCipherVectorTest(8, new CFBBlockCipher(new GOST28147Engine(), 64), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("E-A")), Hex.decode("1234567890abcdef")), "0000000000000000", "c41009dba22ebe35"), new BlockCipherVectorTest(9, new CFBBlockCipher(new GOST28147Engine(), 8), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("E-B")), Hex.decode("1234567890abcdef")), "0000000000000000", "80d8723fcd3aba28"), new BlockCipherVectorTest(10, new CFBBlockCipher(new GOST28147Engine(), 8), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("E-C")), Hex.decode("1234567890abcdef")), "0000000000000000", "739f6f95068499b5"), new BlockCipherVectorTest(11, new CFBBlockCipher(new GOST28147Engine(), 8), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("E-D")), Hex.decode("1234567890abcdef")), "0000000000000000", "4663f720f4340f57"), new BlockCipherVectorTest(12, new CFBBlockCipher(new GOST28147Engine(), 8), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), GOST28147Engine.getSBox("D-A")), Hex.decode("1234567890abcdef")), "0000000000000000", "5bb0a31d218ed564"), new BlockCipherVectorTest(13, new CFBBlockCipher(new GOST28147Engine(), 8), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("546d203368656c326973652073736e62206167796967747473656865202c3d73")), TestSBox), Hex.decode("1234567890abcdef")), "0000000000000000", "c3af96ef788667c5"), new BlockCipherVectorTest(14, new GOFBBlockCipher(new GOST28147Engine()), new ParametersWithIV(new ParametersWithSBox(new KeyParameter(Hex.decode("4ef72b778f0b0bebeef4f077551cb74a927b470ad7d7f2513454569a247e989d")), GOST28147Engine.getSBox("E-A")), Hex.decode("1234567890abcdef")), "bc350e71aa11345709acde", "1bcc2282707c676fb656dc") };
  private static final int GOST28147_KEY_LENGTH = 32;
  
  private byte[] generateKey(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[32];
    GOST3411Digest localGOST3411Digest = new GOST3411Digest();
    localGOST3411Digest.update(paramArrayOfByte, 0, paramArrayOfByte.length);
    localGOST3411Digest.doFinal(arrayOfByte, 0);
    return arrayOfByte;
  }
  
  GOST28147Test()
  {
    super(tests, new GOST28147Engine(), new KeyParameter(new byte[32]));
  }
  
  public void performTest()
    throws Exception
  {
    super.performTest();
    byte[] arrayOfByte1 = Hex.decode("4e6f77206973207468652074696d6520666f7220616c6c20");
    byte[] arrayOfByte2 = Hex.decode("8ad3c8f56b27ff1fbd46409359bdc796bc350e71aac5f5c0");
    byte[] arrayOfByte3 = new byte[arrayOfByte1.length];
    byte[] arrayOfByte4 = generateKey(Hex.decode("0123456789abcdef"));
    Object localObject = new ParametersWithSBox(new KeyParameter(arrayOfByte4), GOST28147Engine.getSBox("E-A"));
    BufferedBlockCipher localBufferedBlockCipher = new BufferedBlockCipher(new GOST28147Engine());
    localBufferedBlockCipher.init(true, (CipherParameters)localObject);
    int i = localBufferedBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte3, 0);
    try
    {
      localBufferedBlockCipher.doFinal(arrayOfByte3, i);
    }
    catch (CryptoException localCryptoException1)
    {
      fail("failed - exception " + localCryptoException1.toString(), localCryptoException1);
    }
    if (arrayOfByte3.length != arrayOfByte2.length) {
      fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
    }
    for (int j = 0; j != arrayOfByte3.length; j++) {
      if (arrayOfByte3[j] != arrayOfByte2[j]) {
        fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
      }
    }
    arrayOfByte1 = Hex.decode("bc350e71aac5f5c2");
    arrayOfByte2 = Hex.decode("0ebbbafcf38f14a5");
    arrayOfByte3 = new byte[arrayOfByte1.length];
    arrayOfByte4 = generateKey(Hex.decode("0123456789abcdef"));
    localObject = new ParametersWithIV(new ParametersWithSBox(new KeyParameter(arrayOfByte4), GOST28147Engine.getSBox("E-A")), Hex.decode("1234567890abcdef"));
    localBufferedBlockCipher = new BufferedBlockCipher(new CFBBlockCipher(new GOST28147Engine(), 64));
    localBufferedBlockCipher.init(true, (CipherParameters)localObject);
    i = localBufferedBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte3, 0);
    try
    {
      localBufferedBlockCipher.doFinal(arrayOfByte3, i);
    }
    catch (CryptoException localCryptoException2)
    {
      fail("failed - exception " + localCryptoException2.toString(), localCryptoException2);
    }
    if (arrayOfByte3.length != arrayOfByte2.length) {
      fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
    }
    for (int k = 0; k != arrayOfByte3.length; k++) {
      if (arrayOfByte3[k] != arrayOfByte2[k]) {
        fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
      }
    }
    arrayOfByte1 = Hex.decode("000102030405060708090a0b0c0d0e0fff0102030405060708090a0b0c0d0e0f");
    arrayOfByte2 = Hex.decode("64988982819f0a1655e226e19ecad79d10cc73bac95c5d7da034786c12294225");
    arrayOfByte3 = new byte[arrayOfByte1.length];
    arrayOfByte4 = generateKey(Hex.decode("aafd12f659cae63489b479e5076ddec2f06cb58faafd12f659cae63489b479e5"));
    localObject = new ParametersWithIV(new ParametersWithSBox(new KeyParameter(arrayOfByte4), GOST28147Engine.getSBox("E-A")), Hex.decode("aafd12f659cae634"));
    localBufferedBlockCipher = new BufferedBlockCipher(new CFBBlockCipher(new GOST28147Engine(), 64));
    localBufferedBlockCipher.init(true, (CipherParameters)localObject);
    i = localBufferedBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte3, 0);
    localBufferedBlockCipher.doFinal(arrayOfByte3, i);
    if (arrayOfByte3.length != arrayOfByte2.length) {
      fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
    }
    for (k = 0; k != arrayOfByte3.length; k++) {
      if (arrayOfByte3[k] != arrayOfByte2[k]) {
        fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
      }
    }
    arrayOfByte1 = Hex.decode("bc350e71aa11345709acde");
    arrayOfByte2 = Hex.decode("1bcc2282707c676fb656dc");
    arrayOfByte3 = new byte[arrayOfByte1.length];
    arrayOfByte4 = generateKey(Hex.decode("0123456789abcdef"));
    localObject = new ParametersWithIV(new ParametersWithSBox(new KeyParameter(arrayOfByte4), GOST28147Engine.getSBox("E-A")), Hex.decode("1234567890abcdef"));
    localBufferedBlockCipher = new BufferedBlockCipher(new GOFBBlockCipher(new GOST28147Engine()));
    localBufferedBlockCipher.init(true, (CipherParameters)localObject);
    i = localBufferedBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte3, 0);
    localBufferedBlockCipher.doFinal(arrayOfByte3, i);
    if (arrayOfByte3.length != arrayOfByte2.length) {
      fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
    }
    for (k = 0; k != arrayOfByte3.length; k++) {
      if (arrayOfByte3[k] != arrayOfByte2[k]) {
        fail("failed - expected " + new String(Hex.encode(arrayOfByte2)) + " got " + new String(Hex.encode(arrayOfByte3)));
      }
    }
  }
  
  public String getName()
  {
    return "GOST28147";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new GOST28147Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\GOST28147Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */