package org.bouncycastle.crypto.test;

import java.security.SecureRandom;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.paddings.BlockCipherPadding;
import org.bouncycastle.crypto.paddings.ISO10126d2Padding;
import org.bouncycastle.crypto.paddings.ISO7816d4Padding;
import org.bouncycastle.crypto.paddings.PKCS7Padding;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.paddings.TBCPadding;
import org.bouncycastle.crypto.paddings.X923Padding;
import org.bouncycastle.crypto.paddings.ZeroBytePadding;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class PaddingTest
  extends SimpleTest
{
  private void blockCheck(PaddedBufferedBlockCipher paramPaddedBufferedBlockCipher, BlockCipherPadding paramBlockCipherPadding, KeyParameter paramKeyParameter, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte1 = new byte[paramArrayOfByte.length + 8];
    byte[] arrayOfByte2 = new byte[paramArrayOfByte.length];
    try
    {
      paramPaddedBufferedBlockCipher.init(true, paramKeyParameter);
      int i = paramPaddedBufferedBlockCipher.processBytes(paramArrayOfByte, 0, paramArrayOfByte.length, arrayOfByte1, 0);
      i += paramPaddedBufferedBlockCipher.doFinal(arrayOfByte1, i);
      paramPaddedBufferedBlockCipher.init(false, paramKeyParameter);
      int j = paramPaddedBufferedBlockCipher.processBytes(arrayOfByte1, 0, i, arrayOfByte2, 0);
      j += paramPaddedBufferedBlockCipher.doFinal(arrayOfByte2, j);
      if (!areEqual(paramArrayOfByte, arrayOfByte2)) {
        fail("failed to decrypt - i = " + paramArrayOfByte.length + ", padding = " + paramBlockCipherPadding.getPaddingName());
      }
    }
    catch (Exception localException)
    {
      fail("Exception - " + localException.toString(), localException);
    }
  }
  
  public void testPadding(BlockCipherPadding paramBlockCipherPadding, SecureRandom paramSecureRandom, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    PaddedBufferedBlockCipher localPaddedBufferedBlockCipher = new PaddedBufferedBlockCipher(new DESEngine(), paramBlockCipherPadding);
    KeyParameter localKeyParameter = new KeyParameter(Hex.decode("0011223344556677"));
    byte[] arrayOfByte = { -1, -1, -1, 0, 0, 0, 0, 0 };
    if (paramArrayOfByte1 != null)
    {
      paramBlockCipherPadding.addPadding(arrayOfByte, 3);
      if (!areEqual(arrayOfByte, paramArrayOfByte1)) {
        fail("failed ff test for " + paramBlockCipherPadding.getPaddingName());
      }
    }
    if (paramArrayOfByte2 != null)
    {
      arrayOfByte = new byte[8];
      paramBlockCipherPadding.addPadding(arrayOfByte, 4);
      if (!areEqual(arrayOfByte, paramArrayOfByte2)) {
        fail("failed zero test for " + paramBlockCipherPadding.getPaddingName());
      }
    }
    for (int i = 1; i != 200; i++)
    {
      arrayOfByte = new byte[i];
      paramSecureRandom.nextBytes(arrayOfByte);
      blockCheck(localPaddedBufferedBlockCipher, paramBlockCipherPadding, localKeyParameter, arrayOfByte);
    }
  }
  
  public void performTest()
  {
    SecureRandom localSecureRandom = new SecureRandom(new byte[20]);
    localSecureRandom.setSeed(System.currentTimeMillis());
    testPadding(new PKCS7Padding(), localSecureRandom, Hex.decode("ffffff0505050505"), Hex.decode("0000000004040404"));
    testPadding(new ISO10126d2Padding(), localSecureRandom, null, null);
    testPadding(new X923Padding(), localSecureRandom, null, null);
    testPadding(new TBCPadding(), localSecureRandom, Hex.decode("ffffff0000000000"), Hex.decode("00000000ffffffff"));
    testPadding(new ZeroBytePadding(), localSecureRandom, Hex.decode("ffffff0000000000"), null);
    testPadding(new ISO7816d4Padding(), localSecureRandom, Hex.decode("ffffff8000000000"), Hex.decode("0000000080000000"));
  }
  
  public String getName()
  {
    return "PaddingTest";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new PaddingTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\PaddingTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */