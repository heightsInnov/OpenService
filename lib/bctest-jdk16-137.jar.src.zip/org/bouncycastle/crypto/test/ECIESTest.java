package org.bouncycastle.crypto.test;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.agreement.ECDHBasicAgreement;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.engines.IESEngine;
import org.bouncycastle.crypto.engines.TwofishEngine;
import org.bouncycastle.crypto.generators.KDF2BytesGenerator;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.params.IESParameters;
import org.bouncycastle.crypto.params.IESWithCipherParameters;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class ECIESTest
  extends SimpleTest
{
  public String getName()
  {
    return "ECIES";
  }
  
  public void performTest()
    throws Exception
  {
    ECCurve.Fp localFp = new ECCurve.Fp(new BigInteger("6277101735386680763835789423207666416083908700390324961279"), new BigInteger("fffffffffffffffffffffffffffffffefffffffffffffffc", 16), new BigInteger("64210519e59c80e70fa7e9ab72243049feb8deecc146b9b1", 16));
    ECDomainParameters localECDomainParameters = new ECDomainParameters(localFp, localFp.decodePoint(Hex.decode("03188da80eb03090f67cbf20eb43a18800f4ff0afd82ff1012")), new BigInteger("6277101735386680763835789423176059013767194773182842284081"));
    ECPrivateKeyParameters localECPrivateKeyParameters = new ECPrivateKeyParameters(new BigInteger("651056770906015076056810763456358567190100156695615665659"), localECDomainParameters);
    ECPublicKeyParameters localECPublicKeyParameters = new ECPublicKeyParameters(localFp.decodePoint(Hex.decode("0262b12d60690cdcf330babab6e69763b471f994dd702d16a5")), localECDomainParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair1 = new AsymmetricCipherKeyPair(localECPublicKeyParameters, localECPrivateKeyParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair2 = new AsymmetricCipherKeyPair(localECPublicKeyParameters, localECPrivateKeyParameters);
    IESEngine localIESEngine1 = new IESEngine(new ECDHBasicAgreement(), new KDF2BytesGenerator(new SHA1Digest()), new HMac(new SHA1Digest()));
    IESEngine localIESEngine2 = new IESEngine(new ECDHBasicAgreement(), new KDF2BytesGenerator(new SHA1Digest()), new HMac(new SHA1Digest()));
    byte[] arrayOfByte1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
    byte[] arrayOfByte2 = { 8, 7, 6, 5, 4, 3, 2, 1 };
    Object localObject = new IESParameters(arrayOfByte1, arrayOfByte2, 64);
    localIESEngine1.init(true, localAsymmetricCipherKeyPair1.getPrivate(), localAsymmetricCipherKeyPair2.getPublic(), (CipherParameters)localObject);
    localIESEngine2.init(false, localAsymmetricCipherKeyPair2.getPrivate(), localAsymmetricCipherKeyPair1.getPublic(), (CipherParameters)localObject);
    byte[] arrayOfByte3 = Hex.decode("1234567890abcdef");
    byte[] arrayOfByte4 = localIESEngine1.processBlock(arrayOfByte3, 0, arrayOfByte3.length);
    if (!areEqual(arrayOfByte4, Hex.decode("2442ae1fbf90dd9c06b0dcc3b27e69bd11c9aee4ad4cfc9e50eceb44"))) {
      fail("stream cipher test failed on enc");
    }
    byte[] arrayOfByte5 = localIESEngine2.processBlock(arrayOfByte4, 0, arrayOfByte4.length);
    if (!areEqual(arrayOfByte5, arrayOfByte3)) {
      fail("stream cipher test failed");
    }
    PaddedBufferedBlockCipher localPaddedBufferedBlockCipher1 = new PaddedBufferedBlockCipher(new CBCBlockCipher(new TwofishEngine()));
    PaddedBufferedBlockCipher localPaddedBufferedBlockCipher2 = new PaddedBufferedBlockCipher(new CBCBlockCipher(new TwofishEngine()));
    localIESEngine1 = new IESEngine(new ECDHBasicAgreement(), new KDF2BytesGenerator(new SHA1Digest()), new HMac(new SHA1Digest()), localPaddedBufferedBlockCipher1);
    localIESEngine2 = new IESEngine(new ECDHBasicAgreement(), new KDF2BytesGenerator(new SHA1Digest()), new HMac(new SHA1Digest()), localPaddedBufferedBlockCipher2);
    arrayOfByte1 = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
    arrayOfByte2 = new byte[] { 8, 7, 6, 5, 4, 3, 2, 1 };
    localObject = new IESWithCipherParameters(arrayOfByte1, arrayOfByte2, 64, 128);
    localIESEngine1.init(true, localAsymmetricCipherKeyPair1.getPrivate(), localAsymmetricCipherKeyPair2.getPublic(), (CipherParameters)localObject);
    localIESEngine2.init(false, localAsymmetricCipherKeyPair2.getPrivate(), localAsymmetricCipherKeyPair1.getPublic(), (CipherParameters)localObject);
    arrayOfByte3 = Hex.decode("1234567890abcdef");
    arrayOfByte4 = localIESEngine1.processBlock(arrayOfByte3, 0, arrayOfByte3.length);
    if (!areEqual(arrayOfByte4, Hex.decode("2ea288651e21576215f2424bbb3f68816e282e3931b44bd1c429ebdb5f1b290cf1b13309"))) {
      fail("twofish cipher test failed on enc");
    }
    arrayOfByte5 = localIESEngine2.processBlock(arrayOfByte4, 0, arrayOfByte4.length);
    if (!areEqual(arrayOfByte5, arrayOfByte3)) {
      fail("twofish cipher test failed");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new ECIESTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\ECIESTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */