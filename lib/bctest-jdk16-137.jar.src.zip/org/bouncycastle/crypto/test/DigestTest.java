package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public abstract class DigestTest
  extends SimpleTest
{
  private Digest digest;
  private String[] input;
  private String[] results;
  
  DigestTest(Digest paramDigest, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    this.digest = paramDigest;
    this.input = paramArrayOfString1;
    this.results = paramArrayOfString2;
  }
  
  public String getName()
  {
    return this.digest.getAlgorithmName();
  }
  
  public void performTest()
  {
    byte[] arrayOfByte1 = new byte[this.digest.getDigestSize()];
    for (int i = 0; i < this.input.length - 1; i++)
    {
      arrayOfByte3 = toByteArray(this.input[i]);
      vectorTest(this.digest, i, arrayOfByte1, arrayOfByte3, Hex.decode(this.results[i]));
    }
    byte[] arrayOfByte2 = toByteArray(this.input[(this.input.length - 1)]);
    byte[] arrayOfByte3 = Hex.decode(this.results[(this.input.length - 1)]);
    vectorTest(this.digest, this.input.length - 1, arrayOfByte1, arrayOfByte2, Hex.decode(this.results[(this.input.length - 1)]));
    this.digest.update(arrayOfByte2, 0, arrayOfByte2.length / 2);
    Digest localDigest = cloneDigest(this.digest);
    this.digest.update(arrayOfByte2, arrayOfByte2.length / 2, arrayOfByte2.length - arrayOfByte2.length / 2);
    this.digest.doFinal(arrayOfByte1, 0);
    if (!areEqual(arrayOfByte3, arrayOfByte1)) {
      fail("failing clone vector test", this.results[(this.results.length - 1)], new String(Hex.encode(arrayOfByte1)));
    }
    localDigest.update(arrayOfByte2, arrayOfByte2.length / 2, arrayOfByte2.length - arrayOfByte2.length / 2);
    localDigest.doFinal(arrayOfByte1, 0);
    if (!areEqual(arrayOfByte3, arrayOfByte1)) {
      fail("failing second clone vector test", this.results[(this.results.length - 1)], new String(Hex.encode(arrayOfByte1)));
    }
  }
  
  private byte[] toByteArray(String paramString)
  {
    byte[] arrayOfByte = new byte[paramString.length()];
    for (int i = 0; i != arrayOfByte.length; i++) {
      arrayOfByte[i] = ((byte)paramString.charAt(i));
    }
    return arrayOfByte;
  }
  
  private void vectorTest(Digest paramDigest, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    paramDigest.update(paramArrayOfByte2, 0, paramArrayOfByte2.length);
    paramDigest.doFinal(paramArrayOfByte1, 0);
    if (!areEqual(paramArrayOfByte1, paramArrayOfByte3))
    {
      System.out.println(new String(Hex.decode(paramArrayOfByte2)));
      fail("Vector " + paramInt + " failed got " + new String(Hex.encode(paramArrayOfByte1)));
    }
  }
  
  protected abstract Digest cloneDigest(Digest paramDigest);
  
  protected void millionATest(String paramString)
  {
    byte[] arrayOfByte = new byte[this.digest.getDigestSize()];
    for (int i = 0; i < 1000000; i++) {
      this.digest.update((byte)97);
    }
    this.digest.doFinal(arrayOfByte, 0);
    if (!areEqual(arrayOfByte, Hex.decode(paramString))) {
      fail("Million a's failed");
    }
  }
  
  protected void sixtyFourKTest(String paramString)
  {
    byte[] arrayOfByte = new byte[this.digest.getDigestSize()];
    for (int i = 0; i < 65536; i++) {
      this.digest.update((byte)(i & 0xFF));
    }
    this.digest.doFinal(arrayOfByte, 0);
    if (!areEqual(arrayOfByte, Hex.decode(paramString))) {
      fail("64k test failed");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\DigestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */