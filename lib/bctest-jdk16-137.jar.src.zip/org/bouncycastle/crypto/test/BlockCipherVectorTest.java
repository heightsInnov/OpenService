package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class BlockCipherVectorTest
  extends SimpleTest
{
  int id;
  BlockCipher engine;
  CipherParameters param;
  byte[] input;
  byte[] output;
  
  public BlockCipherVectorTest(int paramInt, BlockCipher paramBlockCipher, CipherParameters paramCipherParameters, String paramString1, String paramString2)
  {
    this.id = paramInt;
    this.engine = paramBlockCipher;
    this.param = paramCipherParameters;
    this.input = Hex.decode(paramString1);
    this.output = Hex.decode(paramString2);
  }
  
  public String getName()
  {
    return this.engine.getAlgorithmName() + " Vector Test " + this.id;
  }
  
  public void performTest()
    throws Exception
  {
    BufferedBlockCipher localBufferedBlockCipher = new BufferedBlockCipher(this.engine);
    localBufferedBlockCipher.init(true, this.param);
    byte[] arrayOfByte = new byte[this.input.length];
    int i = localBufferedBlockCipher.processBytes(this.input, 0, this.input.length, arrayOfByte, 0);
    localBufferedBlockCipher.doFinal(arrayOfByte, i);
    if (!areEqual(arrayOfByte, this.output)) {
      fail("failed - expected " + new String(Hex.encode(this.output)) + " got " + new String(Hex.encode(arrayOfByte)));
    }
    localBufferedBlockCipher.init(false, this.param);
    int j = localBufferedBlockCipher.processBytes(this.output, 0, this.output.length, arrayOfByte, 0);
    localBufferedBlockCipher.doFinal(arrayOfByte, j);
    if (!areEqual(this.input, arrayOfByte)) {
      fail("failed reversal got " + new String(Hex.encode(arrayOfByte)));
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\BlockCipherVectorTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */