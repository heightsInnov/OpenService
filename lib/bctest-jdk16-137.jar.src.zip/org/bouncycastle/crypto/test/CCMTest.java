package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.modes.CCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.CCMParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.Strings;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class CCMTest
  extends SimpleTest
{
  private byte[] K1 = Hex.decode("404142434445464748494a4b4c4d4e4f");
  private byte[] N1 = Hex.decode("10111213141516");
  private byte[] A1 = Hex.decode("0001020304050607");
  private byte[] P1 = Hex.decode("20212223");
  private byte[] C1 = Hex.decode("7162015b4dac255d");
  private byte[] T1 = Hex.decode("6084341b");
  private byte[] K2 = Hex.decode("404142434445464748494a4b4c4d4e4f");
  private byte[] N2 = Hex.decode("1011121314151617");
  private byte[] A2 = Hex.decode("000102030405060708090a0b0c0d0e0f");
  private byte[] P2 = Hex.decode("202122232425262728292a2b2c2d2e2f");
  private byte[] C2 = Hex.decode("d2a1f0e051ea5f62081a7792073d593d1fc64fbfaccd");
  private byte[] T2 = Hex.decode("7f479ffca464");
  private byte[] K3 = Hex.decode("404142434445464748494a4b4c4d4e4f");
  private byte[] N3 = Hex.decode("101112131415161718191a1b");
  private byte[] A3 = Hex.decode("000102030405060708090a0b0c0d0e0f10111213");
  private byte[] P3 = Hex.decode("202122232425262728292a2b2c2d2e2f3031323334353637");
  private byte[] C3 = Hex.decode("e3b201a9f5b71a7a9b1ceaeccd97e70b6176aad9a4428aa5484392fbc1b09951");
  private byte[] T3 = Hex.decode("67c99240c7d51048");
  private byte[] K4 = Hex.decode("404142434445464748494a4b4c4d4e4f");
  private byte[] N4 = Hex.decode("101112131415161718191a1b1c");
  private byte[] A4 = Hex.decode("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff");
  private byte[] P4 = Hex.decode("202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f");
  private byte[] C4 = Hex.decode("69915dad1e84c6376a68c2967e4dab615ae0fd1faec44cc484828529463ccf72b4ac6bec93e8598e7f0dadbcea5b");
  private byte[] T4 = Hex.decode("f4dd5d0ee404617225ffe34fce91");
  private byte[] C5 = Hex.decode("49b17d8d3ea4e6174a48e2b65e6d8b417ac0dd3f8ee46ce4a4a2a509661cef52528c1cd9805333a5cfd482fa3f095a3c2fdd1cc47771c5e55fddd60b5c8d6d3fa5c8dd79d08b16242b6642106e7c0c28bd1064b31e6d7c9800c8397dbc3fa8071e6a38278b386c18d65d39c6ad1ef9501a5c8f68d38eb6474799f3cc898b4b9b97e87f9c95ce5c51bc9d758f17119586663a5684e0a0daf6520ec572b87473eb141d10471e4799ded9e607655402eca5176bbf792ef39dd135ac8d710da8e9e854fd3b95c681023f36b5ebe2fb213d0b62dd6e9e3cfe190b792ccb20c53423b2dca128f861a61d306910e1af418839467e466f0ec361d2539eedd99d4724f1b51c07beb40e875a87491ec8b27cd1");
  private byte[] T5 = Hex.decode("5c768856796b627b13ec8641581b");
  
  public void performTest()
    throws Exception
  {
    CCMBlockCipher localCCMBlockCipher = new CCMBlockCipher(new AESEngine());
    checkVectors(0, localCCMBlockCipher, this.K1, 32, this.N1, this.A1, this.P1, this.T1, this.C1);
    checkVectors(1, localCCMBlockCipher, this.K2, 48, this.N2, this.A2, this.P2, this.T2, this.C2);
    checkVectors(2, localCCMBlockCipher, this.K3, 64, this.N3, this.A3, this.P3, this.T3, this.C3);
    ivParamTest(0, localCCMBlockCipher, this.K1, this.N1);
    byte[] arrayOfByte = new byte[65536];
    int i = 0;
    while (i < arrayOfByte.length)
    {
      System.arraycopy(this.A4, 0, arrayOfByte, i, this.A4.length);
      i += this.A4.length;
    }
    checkVectors(3, localCCMBlockCipher, this.K4, 112, this.N4, arrayOfByte, this.P4, this.T4, this.C4);
    checkVectors(4, localCCMBlockCipher, this.K4, 112, this.N4, this.A4, this.A4, this.T5, this.C5);
    try
    {
      localCCMBlockCipher.init(false, new CCMParameters(new KeyParameter(this.K1), 32, this.N2, this.A2));
      localCCMBlockCipher.processPacket(this.C2, 0, this.C2.length);
      fail("invalid cipher text not picked up");
    }
    catch (InvalidCipherTextException localInvalidCipherTextException) {}
    try
    {
      localCCMBlockCipher = new CCMBlockCipher(new DESEngine());
      fail("incorrect block size not picked up");
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      localCCMBlockCipher.init(false, new KeyParameter(this.K1));
      fail("illegal argument not picked up");
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
  }
  
  private void checkVectors(int paramInt1, CCMBlockCipher paramCCMBlockCipher, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[] paramArrayOfByte5, byte[] paramArrayOfByte6)
    throws InvalidCipherTextException
  {
    paramCCMBlockCipher.init(true, new AEADParameters(new KeyParameter(paramArrayOfByte1), paramInt2, paramArrayOfByte2, paramArrayOfByte3));
    byte[] arrayOfByte1 = new byte[paramArrayOfByte6.length];
    int i = paramCCMBlockCipher.processBytes(paramArrayOfByte4, 0, paramArrayOfByte4.length, arrayOfByte1, 0);
    i += paramCCMBlockCipher.doFinal(arrayOfByte1, i);
    if (!areEqual(paramArrayOfByte6, arrayOfByte1)) {
      fail("encrypted stream fails to match in test " + paramInt1);
    }
    paramCCMBlockCipher.init(false, new AEADParameters(new KeyParameter(paramArrayOfByte1), paramInt2, paramArrayOfByte2, paramArrayOfByte3));
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    i = paramCCMBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte2, 0);
    i += paramCCMBlockCipher.doFinal(arrayOfByte2, i);
    byte[] arrayOfByte3 = new byte[i];
    System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, i);
    if (!areEqual(paramArrayOfByte4, arrayOfByte3)) {
      fail("decrypted stream fails to match in test " + paramInt1);
    }
    if (!areEqual(paramArrayOfByte5, paramCCMBlockCipher.getMac())) {
      fail("MAC fails to match in test " + paramInt1);
    }
  }
  
  private void ivParamTest(int paramInt, CCMBlockCipher paramCCMBlockCipher, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = Strings.toByteArray("hello world!!");
    paramCCMBlockCipher.init(true, new ParametersWithIV(new KeyParameter(paramArrayOfByte1), paramArrayOfByte2));
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length + 8];
    int i = paramCCMBlockCipher.processBytes(arrayOfByte1, 0, arrayOfByte1.length, arrayOfByte2, 0);
    i += paramCCMBlockCipher.doFinal(arrayOfByte2, i);
    paramCCMBlockCipher.init(false, new ParametersWithIV(new KeyParameter(paramArrayOfByte1), paramArrayOfByte2));
    byte[] arrayOfByte3 = new byte[arrayOfByte2.length];
    i = paramCCMBlockCipher.processBytes(arrayOfByte2, 0, arrayOfByte2.length, arrayOfByte3, 0);
    i += paramCCMBlockCipher.doFinal(arrayOfByte3, i);
    byte[] arrayOfByte4 = new byte[i];
    System.arraycopy(arrayOfByte3, 0, arrayOfByte4, 0, i);
    if (!areEqual(arrayOfByte1, arrayOfByte4)) {
      fail("decrypted stream fails to match in test " + paramInt);
    }
  }
  
  public String getName()
  {
    return "CCM";
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new CCMTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\CCMTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */