package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTestResult;
import org.bouncycastle.util.test.Test;
import org.bouncycastle.util.test.TestResult;

public class SHA1HMacTest
  implements Test
{
  static final String[] keys = { "0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b", "4a656665", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0102030405060708090a0b0c0d0e0f10111213141516171819", "0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" };
  static final String[] digests = { "b617318655057264e28bc0b6fb378c8ef146be00", "effcdf6ae5eb2fa2d27416d5f184df9c259a7c79", "125d7342b9ac11cd91a39af48aa17b4f63f175d3", "4c9007f4026250c6bc8414f9bf50c86c2d7235da", "4c1a03424b55e07fe7f27be1d58bb9324a9a5a04", "aa4ae5e15272d00e95705637ce8a3b55ed402112", "e8e99d0f45237d786d6bbaa7965c7808bbff1a91", "4c1a03424b55e07fe7f27be1d58bb9324a9a5a04", "aa4ae5e15272d00e95705637ce8a3b55ed402112", "e8e99d0f45237d786d6bbaa7965c7808bbff1a91" };
  static final String[] messages = { "Hi There", "what do ya want for nothing?", "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "0xcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcd", "Test With Truncation", "Test Using Larger Than Block-Size Key - Hash Key First", "Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data" };
  
  public String getName()
  {
    return "SHA1HMac";
  }
  
  public TestResult perform()
  {
    HMac localHMac = new HMac(new SHA1Digest());
    byte[] arrayOfByte1 = new byte[localHMac.getMacSize()];
    for (int i = 0; i < messages.length; i++)
    {
      arrayOfByte2 = messages[i].getBytes();
      if (messages[i].startsWith("0x")) {
        arrayOfByte2 = Hex.decode(messages[i].substring(2));
      }
      localHMac.init(new KeyParameter(Hex.decode(keys[i])));
      localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
      localHMac.doFinal(arrayOfByte1, 0);
      if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
        return new SimpleTestResult(false, getName() + ": Vector " + i + " failed");
      }
    }
    i = 0;
    byte[] arrayOfByte2 = messages[i].getBytes();
    if (messages[i].startsWith("0x")) {
      arrayOfByte2 = Hex.decode(messages[i].substring(2));
    }
    localHMac.init(new KeyParameter(Hex.decode(keys[i])));
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    localHMac.reset();
    localHMac.update(arrayOfByte2, 0, arrayOfByte2.length);
    localHMac.doFinal(arrayOfByte1, 0);
    if (!Arrays.areEqual(arrayOfByte1, Hex.decode(digests[i]))) {
      return new SimpleTestResult(false, getName() + "Reset with vector " + i + " failed");
    }
    return new SimpleTestResult(true, getName() + ": Okay");
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SHA1HMacTest localSHA1HMacTest = new SHA1HMacTest();
    TestResult localTestResult = localSHA1HMacTest.perform();
    System.out.println(localTestResult);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\SHA1HMacTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */