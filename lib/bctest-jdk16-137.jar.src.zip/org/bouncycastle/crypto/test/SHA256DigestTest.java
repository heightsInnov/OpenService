package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA256Digest;

public class SHA256DigestTest
  extends DigestTest
{
  private static String[] messages = { "", "a", "abc", "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq" };
  private static String[] digests = { "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1" };
  private static String million_a_digest = "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0";
  
  SHA256DigestTest()
  {
    super(new SHA256Digest(), messages, digests);
  }
  
  public void performTest()
  {
    super.performTest();
    millionATest(million_a_digest);
  }
  
  protected Digest cloneDigest(Digest paramDigest)
  {
    return new SHA256Digest((SHA256Digest)paramDigest);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new SHA256DigestTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\SHA256DigestTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */