package org.bouncycastle.crypto.test;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.generators.DHKeyPairGenerator;
import org.bouncycastle.crypto.generators.ElGamalKeyPairGenerator;
import org.bouncycastle.crypto.params.DHKeyGenerationParameters;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.crypto.params.DHPrivateKeyParameters;
import org.bouncycastle.crypto.params.DHPublicKeyParameters;
import org.bouncycastle.crypto.params.DHValidationParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAValidationParameters;
import org.bouncycastle.crypto.params.ElGamalKeyGenerationParameters;
import org.bouncycastle.crypto.params.ElGamalParameters;
import org.bouncycastle.crypto.params.ElGamalPrivateKeyParameters;
import org.bouncycastle.crypto.params.ElGamalPublicKeyParameters;
import org.bouncycastle.crypto.params.GOST3410Parameters;
import org.bouncycastle.crypto.params.GOST3410ValidationParameters;
import org.bouncycastle.util.test.SimpleTest;

public class EqualsHashCodeTest
  extends SimpleTest
{
  private static Object OTHER = new Object();
  
  public String getName()
  {
    return "EqualsHashCode";
  }
  
  private void doTest(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if (paramObject1.equals(null)) {
      fail("a equaled null");
    }
    if ((!paramObject1.equals(paramObject2)) || (!paramObject2.equals(paramObject1))) {
      fail("equality failed");
    }
    if (paramObject1.equals(OTHER)) {
      fail("other inequality failed");
    }
    if ((paramObject1.equals(paramObject3)) || (paramObject3.equals(paramObject1))) {
      fail("inequality failed");
    }
    if (paramObject1.hashCode() != paramObject2.hashCode()) {
      fail("hashCode equality failed");
    }
  }
  
  private void dhTest()
  {
    BigInteger localBigInteger1 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
    BigInteger localBigInteger2 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
    DHParameters localDHParameters1 = new DHParameters(localBigInteger2, localBigInteger1);
    DHKeyGenerationParameters localDHKeyGenerationParameters = new DHKeyGenerationParameters(new SecureRandom(), localDHParameters1);
    DHKeyPairGenerator localDHKeyPairGenerator = new DHKeyPairGenerator();
    localDHKeyPairGenerator.init(localDHKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localDHKeyPairGenerator.generateKeyPair();
    DHPublicKeyParameters localDHPublicKeyParameters1 = (DHPublicKeyParameters)localAsymmetricCipherKeyPair.getPublic();
    DHPrivateKeyParameters localDHPrivateKeyParameters1 = (DHPrivateKeyParameters)localAsymmetricCipherKeyPair.getPrivate();
    DHPublicKeyParameters localDHPublicKeyParameters2 = new DHPublicKeyParameters(localDHPublicKeyParameters1.getY(), localDHPublicKeyParameters1.getParameters());
    DHPrivateKeyParameters localDHPrivateKeyParameters2 = new DHPrivateKeyParameters(localDHPrivateKeyParameters1.getX(), localDHPrivateKeyParameters1.getParameters());
    DHPublicKeyParameters localDHPublicKeyParameters3 = new DHPublicKeyParameters(localDHPrivateKeyParameters1.getX(), localDHPublicKeyParameters1.getParameters());
    DHPrivateKeyParameters localDHPrivateKeyParameters3 = new DHPrivateKeyParameters(localDHPublicKeyParameters1.getY(), localDHPublicKeyParameters1.getParameters());
    doTest(localDHPublicKeyParameters1, localDHPublicKeyParameters2, localDHPublicKeyParameters3);
    doTest(localDHPrivateKeyParameters1, localDHPrivateKeyParameters2, localDHPrivateKeyParameters3);
    DHParameters localDHParameters2 = localDHPublicKeyParameters1.getParameters();
    DHParameters localDHParameters3 = new DHParameters(localDHParameters2.getP(), localDHParameters2.getG(), localDHParameters2.getQ(), localDHParameters2.getJ(), localDHParameters2.getValidationParameters());
    DHParameters localDHParameters4 = new DHParameters(localDHParameters2.getG(), localDHParameters2.getP(), localDHParameters2.getQ(), localDHParameters2.getJ(), localDHParameters2.getValidationParameters());
    doTest(localDHParameters2, localDHParameters3, localDHParameters4);
    localDHParameters4 = new DHParameters(localDHParameters2.getG(), localDHParameters2.getP(), null, localDHParameters2.getJ(), localDHParameters2.getValidationParameters());
    doTest(localDHParameters2, localDHParameters3, localDHParameters4);
    localDHPublicKeyParameters2 = new DHPublicKeyParameters(localDHPublicKeyParameters1.getY(), localDHParameters3);
    localDHPrivateKeyParameters2 = new DHPrivateKeyParameters(localDHPrivateKeyParameters1.getX(), localDHParameters3);
    doTest(localDHPublicKeyParameters1, localDHPublicKeyParameters2, localDHPublicKeyParameters3);
    doTest(localDHPrivateKeyParameters1, localDHPrivateKeyParameters2, localDHPrivateKeyParameters3);
    DHValidationParameters localDHValidationParameters1 = new DHValidationParameters(new byte[20], 1024);
    DHValidationParameters localDHValidationParameters2 = new DHValidationParameters(new byte[20], 1024);
    DHValidationParameters localDHValidationParameters3 = new DHValidationParameters(new byte[24], 1024);
    doTest(localDHValidationParameters1, localDHValidationParameters1, localDHValidationParameters3);
    doTest(localDHValidationParameters1, localDHValidationParameters2, localDHValidationParameters3);
    byte[] arrayOfByte = new byte[20];
    arrayOfByte[0] = 1;
    localDHValidationParameters3 = new DHValidationParameters(arrayOfByte, 1024);
    doTest(localDHValidationParameters1, localDHValidationParameters2, localDHValidationParameters3);
    localDHValidationParameters3 = new DHValidationParameters(new byte[20], 2048);
    doTest(localDHValidationParameters1, localDHValidationParameters2, localDHValidationParameters3);
    DHTestKeyParameters localDHTestKeyParameters1 = new DHTestKeyParameters(false, null);
    DHTestKeyParameters localDHTestKeyParameters2 = new DHTestKeyParameters(false, null);
    DHTestKeyParameters localDHTestKeyParameters3 = new DHTestKeyParameters(false, localDHPublicKeyParameters1.getParameters());
    doTest(localDHTestKeyParameters1, localDHTestKeyParameters2, localDHTestKeyParameters3);
  }
  
  private void elGamalTest()
  {
    BigInteger localBigInteger1 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
    BigInteger localBigInteger2 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
    ElGamalParameters localElGamalParameters1 = new ElGamalParameters(localBigInteger2, localBigInteger1);
    ElGamalKeyGenerationParameters localElGamalKeyGenerationParameters = new ElGamalKeyGenerationParameters(new SecureRandom(), localElGamalParameters1);
    ElGamalKeyPairGenerator localElGamalKeyPairGenerator = new ElGamalKeyPairGenerator();
    localElGamalKeyPairGenerator.init(localElGamalKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localElGamalKeyPairGenerator.generateKeyPair();
    ElGamalPublicKeyParameters localElGamalPublicKeyParameters1 = (ElGamalPublicKeyParameters)localAsymmetricCipherKeyPair.getPublic();
    ElGamalPrivateKeyParameters localElGamalPrivateKeyParameters1 = (ElGamalPrivateKeyParameters)localAsymmetricCipherKeyPair.getPrivate();
    ElGamalPublicKeyParameters localElGamalPublicKeyParameters2 = new ElGamalPublicKeyParameters(localElGamalPublicKeyParameters1.getY(), localElGamalPublicKeyParameters1.getParameters());
    ElGamalPrivateKeyParameters localElGamalPrivateKeyParameters2 = new ElGamalPrivateKeyParameters(localElGamalPrivateKeyParameters1.getX(), localElGamalPrivateKeyParameters1.getParameters());
    ElGamalPublicKeyParameters localElGamalPublicKeyParameters3 = new ElGamalPublicKeyParameters(localElGamalPrivateKeyParameters1.getX(), localElGamalPublicKeyParameters1.getParameters());
    ElGamalPrivateKeyParameters localElGamalPrivateKeyParameters3 = new ElGamalPrivateKeyParameters(localElGamalPublicKeyParameters1.getY(), localElGamalPublicKeyParameters1.getParameters());
    doTest(localElGamalPublicKeyParameters1, localElGamalPublicKeyParameters2, localElGamalPublicKeyParameters3);
    doTest(localElGamalPrivateKeyParameters1, localElGamalPrivateKeyParameters2, localElGamalPrivateKeyParameters3);
    ElGamalParameters localElGamalParameters2 = localElGamalPublicKeyParameters1.getParameters();
    ElGamalParameters localElGamalParameters3 = new ElGamalParameters(localElGamalParameters2.getP(), localElGamalParameters2.getG());
    ElGamalParameters localElGamalParameters4 = new ElGamalParameters(localElGamalParameters2.getG(), localElGamalParameters2.getP());
    doTest(localElGamalParameters2, localElGamalParameters3, localElGamalParameters4);
    localElGamalPublicKeyParameters2 = new ElGamalPublicKeyParameters(localElGamalPublicKeyParameters1.getY(), localElGamalParameters3);
    localElGamalPrivateKeyParameters2 = new ElGamalPrivateKeyParameters(localElGamalPrivateKeyParameters1.getX(), localElGamalParameters3);
    doTest(localElGamalPublicKeyParameters1, localElGamalPublicKeyParameters2, localElGamalPublicKeyParameters3);
    doTest(localElGamalPrivateKeyParameters1, localElGamalPrivateKeyParameters2, localElGamalPrivateKeyParameters3);
    ElGamalTestKeyParameters localElGamalTestKeyParameters1 = new ElGamalTestKeyParameters(false, null);
    ElGamalTestKeyParameters localElGamalTestKeyParameters2 = new ElGamalTestKeyParameters(false, null);
    ElGamalTestKeyParameters localElGamalTestKeyParameters3 = new ElGamalTestKeyParameters(false, localElGamalPublicKeyParameters1.getParameters());
    doTest(localElGamalTestKeyParameters1, localElGamalTestKeyParameters2, localElGamalTestKeyParameters3);
  }
  
  private void dsaTest()
  {
    BigInteger localBigInteger1 = BigInteger.valueOf(1L);
    BigInteger localBigInteger2 = BigInteger.valueOf(2L);
    BigInteger localBigInteger3 = BigInteger.valueOf(3L);
    DSAParameters localDSAParameters1 = new DSAParameters(localBigInteger1, localBigInteger2, localBigInteger3);
    DSAParameters localDSAParameters2 = new DSAParameters(localBigInteger1, localBigInteger2, localBigInteger3);
    DSAParameters localDSAParameters3 = new DSAParameters(localBigInteger2, localBigInteger3, localBigInteger1);
    doTest(localDSAParameters1, localDSAParameters2, localDSAParameters3);
    DSAValidationParameters localDSAValidationParameters1 = new DSAValidationParameters(new byte[20], 1024);
    DSAValidationParameters localDSAValidationParameters2 = new DSAValidationParameters(new byte[20], 1024);
    DSAValidationParameters localDSAValidationParameters3 = new DSAValidationParameters(new byte[24], 1024);
    doTest(localDSAValidationParameters1, localDSAValidationParameters1, localDSAValidationParameters3);
    doTest(localDSAValidationParameters1, localDSAValidationParameters2, localDSAValidationParameters3);
    byte[] arrayOfByte = new byte[20];
    arrayOfByte[0] = 1;
    localDSAValidationParameters3 = new DSAValidationParameters(arrayOfByte, 1024);
    doTest(localDSAValidationParameters1, localDSAValidationParameters2, localDSAValidationParameters3);
    localDSAValidationParameters3 = new DSAValidationParameters(new byte[20], 2048);
    doTest(localDSAValidationParameters1, localDSAValidationParameters2, localDSAValidationParameters3);
  }
  
  private void gost3410Test()
  {
    BigInteger localBigInteger1 = BigInteger.valueOf(1L);
    BigInteger localBigInteger2 = BigInteger.valueOf(2L);
    BigInteger localBigInteger3 = BigInteger.valueOf(3L);
    GOST3410Parameters localGOST3410Parameters1 = new GOST3410Parameters(localBigInteger1, localBigInteger2, localBigInteger3);
    GOST3410Parameters localGOST3410Parameters2 = new GOST3410Parameters(localBigInteger1, localBigInteger2, localBigInteger3);
    GOST3410Parameters localGOST3410Parameters3 = new GOST3410Parameters(localBigInteger1, localBigInteger3, localBigInteger3);
    doTest(localGOST3410Parameters1, localGOST3410Parameters2, localGOST3410Parameters3);
    GOST3410ValidationParameters localGOST3410ValidationParameters1 = new GOST3410ValidationParameters(100, 1);
    GOST3410ValidationParameters localGOST3410ValidationParameters2 = new GOST3410ValidationParameters(100, 1);
    GOST3410ValidationParameters localGOST3410ValidationParameters3 = new GOST3410ValidationParameters(101, 1);
    doTest(localGOST3410ValidationParameters1, localGOST3410ValidationParameters2, localGOST3410ValidationParameters3);
    localGOST3410ValidationParameters3 = new GOST3410ValidationParameters(100, 2);
    doTest(localGOST3410ValidationParameters1, localGOST3410ValidationParameters2, localGOST3410ValidationParameters3);
    localGOST3410ValidationParameters1 = new GOST3410ValidationParameters(100L, 1L);
    localGOST3410ValidationParameters2 = new GOST3410ValidationParameters(100L, 1L);
    localGOST3410ValidationParameters3 = new GOST3410ValidationParameters(101L, 1L);
    doTest(localGOST3410ValidationParameters1, localGOST3410ValidationParameters2, localGOST3410ValidationParameters3);
    localGOST3410ValidationParameters3 = new GOST3410ValidationParameters(100L, 2L);
    doTest(localGOST3410ValidationParameters1, localGOST3410ValidationParameters2, localGOST3410ValidationParameters3);
  }
  
  public void performTest()
    throws Exception
  {
    dhTest();
    elGamalTest();
    gost3410Test();
    dsaTest();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new EqualsHashCodeTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\EqualsHashCodeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */