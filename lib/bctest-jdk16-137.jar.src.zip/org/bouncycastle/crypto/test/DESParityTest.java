package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.params.DESParameters;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

class DESParityTest
  extends SimpleTest
{
  public String getName()
  {
    return "DESParityTest";
  }
  
  public void performTest()
  {
    byte[] arrayOfByte1 = { -1, -1, -1, -1, -1, -1, -1, -1 };
    byte[] arrayOfByte2 = { -2, -2, -2, -2, -2, -2, -2, -2 };
    byte[] arrayOfByte3 = { -17, -53, -38, 79, -86, -103, Byte.MAX_VALUE, 99 };
    byte[] arrayOfByte4 = { -17, -53, -38, 79, -85, -104, Byte.MAX_VALUE, 98 };
    DESParameters.setOddParity(arrayOfByte1);
    for (int i = 0; i != arrayOfByte1.length; i++) {
      if (arrayOfByte1[i] != arrayOfByte2[i]) {
        fail("Failed got " + new String(Hex.encode(arrayOfByte1)) + " expected " + new String(Hex.encode(arrayOfByte2)));
      }
    }
    DESParameters.setOddParity(arrayOfByte3);
    for (i = 0; i != arrayOfByte3.length; i++) {
      if (arrayOfByte3[i] != arrayOfByte4[i]) {
        fail("Failed got " + new String(Hex.encode(arrayOfByte3)) + " expected " + new String(Hex.encode(arrayOfByte4)));
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\DESParityTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */