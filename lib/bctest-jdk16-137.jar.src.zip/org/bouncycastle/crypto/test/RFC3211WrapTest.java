package org.bouncycastle.crypto.test;

import java.security.SecureRandom;
import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Wrapper;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.engines.DESedeEngine;
import org.bouncycastle.crypto.engines.RFC3211WrapEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class RFC3211WrapTest
  extends SimpleTest
{
  SecureRandom r1 = new SecureRandom()
  {
    int[] ints = { 196, 54, 245, 65 };
    int count = 0;
    
    public int nextInt()
    {
      return this.ints[(this.count++)];
    }
  };
  SecureRandom r2 = new SecureRandom()
  {
    int[] ints = { 250, 6, 10, 69 };
    int count = 0;
    
    public int nextInt()
    {
      return this.ints[(this.count++)];
    }
  };
  
  public String getName()
  {
    return "RFC3211Wrap";
  }
  
  private void wrapTest(int paramInt, BlockCipher paramBlockCipher, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, SecureRandom paramSecureRandom, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
    throws Exception
  {
    RFC3211WrapEngine localRFC3211WrapEngine = new RFC3211WrapEngine(paramBlockCipher);
    localRFC3211WrapEngine.init(true, new ParametersWithRandom(new ParametersWithIV(new KeyParameter(paramArrayOfByte1), paramArrayOfByte2), paramSecureRandom));
    byte[] arrayOfByte1 = localRFC3211WrapEngine.wrap(paramArrayOfByte3, 0, paramArrayOfByte3.length);
    if (!Arrays.areEqual(arrayOfByte1, paramArrayOfByte4)) {
      fail("failed wrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte4)) + " got " + new String(Hex.encode(arrayOfByte1)));
    }
    localRFC3211WrapEngine.init(false, new ParametersWithIV(new KeyParameter(paramArrayOfByte1), paramArrayOfByte2));
    byte[] arrayOfByte2 = localRFC3211WrapEngine.unwrap(paramArrayOfByte4, 0, paramArrayOfByte4.length);
    if (!Arrays.areEqual(arrayOfByte2, paramArrayOfByte3)) {
      fail("rfailed unwrap test " + paramInt + " expected " + new String(Hex.encode(paramArrayOfByte3)) + " got " + new String(Hex.encode(arrayOfByte2)));
    }
  }
  
  private void testCorruption()
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = Hex.decode("D1DAA78615F287E6");
    byte[] arrayOfByte2 = Hex.decode("EFE598EF21B33D6D");
    RFC3211WrapEngine localRFC3211WrapEngine = new RFC3211WrapEngine(new DESEngine());
    localRFC3211WrapEngine.init(false, new ParametersWithIV(new KeyParameter(arrayOfByte1), arrayOfByte2));
    byte[] arrayOfByte3 = Hex.decode("ff739D838C627C897323A2F8C436F541");
    encryptBlock(arrayOfByte1, arrayOfByte2, arrayOfByte3);
    try
    {
      localRFC3211WrapEngine.unwrap(arrayOfByte3, 0, arrayOfByte3.length);
      fail("bad length not detected");
    }
    catch (InvalidCipherTextException localInvalidCipherTextException)
    {
      if (!localInvalidCipherTextException.getMessage().equals("wrapped key corrupted")) {
        fail("wrong exception on length");
      }
    }
    arrayOfByte3 = Hex.decode("08639D838C627C897323A2F8C436F541");
    testChecksum(arrayOfByte1, arrayOfByte2, arrayOfByte3, localRFC3211WrapEngine);
    arrayOfByte3 = Hex.decode("08736D838C627C897323A2F8C436F541");
    testChecksum(arrayOfByte1, arrayOfByte2, arrayOfByte3, localRFC3211WrapEngine);
    arrayOfByte3 = Hex.decode("08739D638C627C897323A2F8C436F541");
    testChecksum(arrayOfByte1, arrayOfByte2, arrayOfByte3, localRFC3211WrapEngine);
  }
  
  private void testChecksum(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, Wrapper paramWrapper)
  {
    encryptBlock(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    try
    {
      paramWrapper.unwrap(paramArrayOfByte3, 0, paramArrayOfByte3.length);
      fail("bad checksum not detected");
    }
    catch (InvalidCipherTextException localInvalidCipherTextException)
    {
      if (!localInvalidCipherTextException.getMessage().equals("wrapped key fails checksum")) {
        fail("wrong exception");
      }
    }
  }
  
  private void encryptBlock(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    CBCBlockCipher localCBCBlockCipher = new CBCBlockCipher(new DESEngine());
    localCBCBlockCipher.init(true, new ParametersWithIV(new KeyParameter(paramArrayOfByte1), paramArrayOfByte2));
    for (int i = 0; i < paramArrayOfByte3.length; i += 8) {
      localCBCBlockCipher.processBlock(paramArrayOfByte3, i, paramArrayOfByte3, i);
    }
    for (i = 0; i < paramArrayOfByte3.length; i += 8) {
      localCBCBlockCipher.processBlock(paramArrayOfByte3, i, paramArrayOfByte3, i);
    }
  }
  
  public void performTest()
    throws Exception
  {
    wrapTest(1, new DESEngine(), Hex.decode("D1DAA78615F287E6"), Hex.decode("EFE598EF21B33D6D"), this.r1, Hex.decode("8C627C897323A2F8"), Hex.decode("B81B2565EE373CA6DEDCA26A178B0C10"));
    wrapTest(2, new DESedeEngine(), Hex.decode("6A8970BF68C92CAEA84A8DF28510858607126380CC47AB2D"), Hex.decode("BAF1CA7931213C4E"), this.r2, Hex.decode("8C637D887223A2F965B566EB014B0FA5D52300A3F7EA40FFFC577203C71BAF3B"), Hex.decode("C03C514ABDB9E2C5AAC038572B5E24553876B377AAFB82ECA5A9D73F8AB143D9EC74E6CAD7DB260C"));
    testCorruption();
    RFC3211WrapEngine localRFC3211WrapEngine = new RFC3211WrapEngine(new DESEngine());
    ParametersWithIV localParametersWithIV = new ParametersWithIV(new KeyParameter(new byte[16]), new byte[16]);
    byte[] arrayOfByte = new byte[16];
    try
    {
      localRFC3211WrapEngine.init(true, localParametersWithIV);
      localRFC3211WrapEngine.unwrap(arrayOfByte, 0, arrayOfByte.length);
      fail("failed unwrap state test.");
    }
    catch (IllegalStateException localIllegalStateException1) {}catch (InvalidCipherTextException localInvalidCipherTextException1)
    {
      fail("unexpected exception: " + localInvalidCipherTextException1, localInvalidCipherTextException1);
    }
    try
    {
      localRFC3211WrapEngine.init(false, localParametersWithIV);
      localRFC3211WrapEngine.wrap(arrayOfByte, 0, arrayOfByte.length);
      fail("failed unwrap state test.");
    }
    catch (IllegalStateException localIllegalStateException2) {}
    try
    {
      localRFC3211WrapEngine.init(false, localParametersWithIV);
      localRFC3211WrapEngine.unwrap(arrayOfByte, 0, arrayOfByte.length / 2);
      fail("failed unwrap short test.");
    }
    catch (InvalidCipherTextException localInvalidCipherTextException2) {}
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new RFC3211WrapTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\RFC3211WrapTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */