package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.engines.NullEngine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class NullTest
  extends CipherTest
{
  static SimpleTest[] tests = { new BlockCipherVectorTest(0, new NullEngine(), new KeyParameter(Hex.decode("00")), "00", "00") };
  
  NullTest()
  {
    super(tests, new NullEngine(), new KeyParameter(new byte[2]));
  }
  
  public String getName()
  {
    return "Null";
  }
  
  public void performTest()
    throws Exception
  {
    super.performTest();
    NullEngine localNullEngine = new NullEngine();
    localNullEngine.init(true, null);
    byte[] arrayOfByte1 = new byte[1];
    localNullEngine.processBlock(arrayOfByte1, 0, arrayOfByte1, 0);
    if (arrayOfByte1[0] != 0) {
      fail("NullCipher changed data!");
    }
    byte[] arrayOfByte2 = new byte[0];
    try
    {
      localNullEngine.processBlock(arrayOfByte2, 0, arrayOfByte1, 0);
      fail("failed short input check");
    }
    catch (DataLengthException localDataLengthException1) {}
    try
    {
      localNullEngine.processBlock(arrayOfByte1, 0, arrayOfByte2, 0);
      fail("failed short output check");
    }
    catch (DataLengthException localDataLengthException2) {}
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new NullTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\NullTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */