package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class StreamCipherVectorTest
  extends SimpleTest
{
  int id;
  StreamCipher cipher;
  CipherParameters param;
  byte[] input;
  byte[] output;
  
  public StreamCipherVectorTest(int paramInt, StreamCipher paramStreamCipher, CipherParameters paramCipherParameters, String paramString1, String paramString2)
  {
    this.id = paramInt;
    this.cipher = paramStreamCipher;
    this.param = paramCipherParameters;
    this.input = Hex.decode(paramString1);
    this.output = Hex.decode(paramString2);
  }
  
  public String getName()
  {
    return this.cipher.getAlgorithmName() + " Vector Test " + this.id;
  }
  
  public void performTest()
  {
    this.cipher.init(true, this.param);
    byte[] arrayOfByte = new byte[this.input.length];
    this.cipher.processBytes(this.input, 0, this.input.length, arrayOfByte, 0);
    if (!areEqual(arrayOfByte, this.output)) {
      fail("failed.", new String(Hex.encode(this.output)), new String(Hex.encode(arrayOfByte)));
    }
    this.cipher.init(false, this.param);
    this.cipher.processBytes(this.output, 0, this.output.length, arrayOfByte, 0);
    if (!areEqual(this.input, arrayOfByte)) {
      fail("failed reversal");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\StreamCipherVectorTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */