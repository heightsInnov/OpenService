package org.bouncycastle.crypto.test;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.generators.DSAKeyPairGenerator;
import org.bouncycastle.crypto.generators.DSAParametersGenerator;
import org.bouncycastle.crypto.params.DSAKeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAValidationParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.signers.DSASigner;
import org.bouncycastle.util.BigIntegers;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.FixedSecureRandom;
import org.bouncycastle.util.test.SimpleTest;

public class DSATest
  extends SimpleTest
{
  byte[] k1 = Hex.decode("d5014e4b60ef2ba8b6211b4062ba3224e0427dd3");
  byte[] k2 = Hex.decode("345e8d05c075c3a508df729a1685690e68fcfb8c8117847e89063bca1f85d968fd281540b6e13bd1af989a1fbf17e06462bf511f9d0b140fb48ac1b1baa5bded");
  SecureRandom random = new FixedSecureRandom(new byte[][] { this.k1, this.k2 });
  byte[] keyData = Hex.decode("b5014e4b60ef2ba8b6211b4062ba3224e0427dd3");
  SecureRandom keyRandom = new FixedSecureRandom(new byte[][] { this.keyData, this.keyData });
  BigInteger pValue = new BigInteger("8df2a494492276aa3d25759bb06869cbeac0d83afb8d0cf7cbb8324f0d7882e5d0762fc5b7210eafc2e9adac32ab7aac49693dfbf83724c2ec0736ee31c80291", 16);
  BigInteger qValue = new BigInteger("c773218c737ec8ee993b4f2ded30f48edace915f", 16);
  
  public String getName()
  {
    return "DSA";
  }
  
  public void performTest()
  {
    BigInteger localBigInteger1 = new BigInteger("68076202252361894315274692543577577550894681403");
    BigInteger localBigInteger2 = new BigInteger("1089214853334067536215539335472893651470583479365");
    DSAParametersGenerator localDSAParametersGenerator = new DSAParametersGenerator();
    localDSAParametersGenerator.init(512, 80, this.random);
    DSAParameters localDSAParameters = localDSAParametersGenerator.generateParameters();
    DSAValidationParameters localDSAValidationParameters = localDSAParameters.getValidationParameters();
    if (localDSAValidationParameters.getCounter() != 105) {
      fail("Counter wrong");
    }
    if ((!this.pValue.equals(localDSAParameters.getP())) || (!this.qValue.equals(localDSAParameters.getQ()))) {
      fail("p or q wrong");
    }
    DSAKeyPairGenerator localDSAKeyPairGenerator = new DSAKeyPairGenerator();
    DSAKeyGenerationParameters localDSAKeyGenerationParameters = new DSAKeyGenerationParameters(this.keyRandom, localDSAParameters);
    localDSAKeyPairGenerator.init(localDSAKeyGenerationParameters);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = localDSAKeyPairGenerator.generateKeyPair();
    ParametersWithRandom localParametersWithRandom = new ParametersWithRandom(localAsymmetricCipherKeyPair.getPrivate(), this.keyRandom);
    DSASigner localDSASigner = new DSASigner();
    localDSASigner.init(true, localParametersWithRandom);
    byte[] arrayOfByte = BigIntegers.asUnsignedByteArray(new BigInteger("968236873715988614170569073515315707566766479517"));
    BigInteger[] arrayOfBigInteger = localDSASigner.generateSignature(arrayOfByte);
    if (!localBigInteger1.equals(arrayOfBigInteger[0])) {
      fail("r component wrong.", localBigInteger1, arrayOfBigInteger[0]);
    }
    if (!localBigInteger2.equals(arrayOfBigInteger[1])) {
      fail("s component wrong.", localBigInteger2, arrayOfBigInteger[1]);
    }
    localDSASigner.init(false, localAsymmetricCipherKeyPair.getPublic());
    if (!localDSASigner.verifySignature(arrayOfByte, arrayOfBigInteger[0], arrayOfBigInteger[1])) {
      fail("verification fails");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new DSATest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\DSATest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */