package org.bouncycastle.crypto.test;

import java.io.PrintStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Vector;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.NaccacheSternEngine;
import org.bouncycastle.crypto.generators.NaccacheSternKeyPairGenerator;
import org.bouncycastle.crypto.params.NaccacheSternKeyGenerationParameters;
import org.bouncycastle.crypto.params.NaccacheSternKeyParameters;
import org.bouncycastle.crypto.params.NaccacheSternPrivateKeyParameters;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class NaccacheSternTest
  extends SimpleTest
{
  static final boolean debug = false;
  static final NaccacheSternEngine cryptEng = new NaccacheSternEngine();
  static final NaccacheSternEngine decryptEng = new NaccacheSternEngine();
  static final BigInteger a = BigInteger.valueOf(101L);
  static final BigInteger u1 = BigInteger.valueOf(3L);
  static final BigInteger u2 = BigInteger.valueOf(5L);
  static final BigInteger u3 = BigInteger.valueOf(7L);
  static final BigInteger b = BigInteger.valueOf(191L);
  static final BigInteger v1 = BigInteger.valueOf(11L);
  static final BigInteger v2 = BigInteger.valueOf(13L);
  static final BigInteger v3 = BigInteger.valueOf(17L);
  static final BigInteger ONE = BigInteger.valueOf(1L);
  static final BigInteger TWO = BigInteger.valueOf(2L);
  static final BigInteger sigma = u1.multiply(u2).multiply(u3).multiply(v1).multiply(v2).multiply(v3);
  static final BigInteger p = TWO.multiply(a).multiply(u1).multiply(u2).multiply(u3).add(ONE);
  static final BigInteger q = TWO.multiply(b).multiply(v1).multiply(v2).multiply(v3).add(ONE);
  static final BigInteger n = p.multiply(q);
  static final BigInteger phi_n = p.subtract(ONE).multiply(q.subtract(ONE));
  static final BigInteger g = BigInteger.valueOf(131L);
  static final Vector smallPrimes = new Vector();
  static final String input = "4e6f77206973207468652074696d6520666f7220616c6c20676f6f64206d656e";
  static final BigInteger paperTest = BigInteger.valueOf(202L);
  static final String edgeInput = "ff6f77206973207468652074696d6520666f7220616c6c20676f6f64206d656e";
  
  public String getName()
  {
    return "NaccacheStern";
  }
  
  public void performTest()
  {
    smallPrimes.addElement(u1);
    smallPrimes.addElement(u2);
    smallPrimes.addElement(u3);
    smallPrimes.addElement(v1);
    smallPrimes.addElement(v2);
    smallPrimes.addElement(v3);
    NaccacheSternKeyParameters localNaccacheSternKeyParameters = new NaccacheSternKeyParameters(false, g, n, sigma.bitLength());
    NaccacheSternPrivateKeyParameters localNaccacheSternPrivateKeyParameters = new NaccacheSternPrivateKeyParameters(g, n, sigma.bitLength(), smallPrimes, phi_n);
    AsymmetricCipherKeyPair localAsymmetricCipherKeyPair = new AsymmetricCipherKeyPair(localNaccacheSternKeyParameters, localNaccacheSternPrivateKeyParameters);
    cryptEng.init(true, localAsymmetricCipherKeyPair.getPublic());
    decryptEng.init(false, localAsymmetricCipherKeyPair.getPrivate());
    byte[] arrayOfByte = paperTest.toByteArray();
    if (!new BigInteger(arrayOfByte).equals(new BigInteger(enDeCrypt(arrayOfByte)))) {
      fail("failed NaccacheStern paper test");
    }
    NaccacheSternKeyGenerationParameters localNaccacheSternKeyGenerationParameters = new NaccacheSternKeyGenerationParameters(new SecureRandom(), 768, 8, 30, false);
    NaccacheSternKeyPairGenerator localNaccacheSternKeyPairGenerator = new NaccacheSternKeyPairGenerator();
    localNaccacheSternKeyPairGenerator.init(localNaccacheSternKeyGenerationParameters);
    localAsymmetricCipherKeyPair = localNaccacheSternKeyPairGenerator.generateKeyPair();
    if (((NaccacheSternKeyParameters)localAsymmetricCipherKeyPair.getPublic()).getModulus().bitLength() < 768)
    {
      System.out.println("FAILED: key size is <786 bit, exactly " + ((NaccacheSternKeyParameters)localAsymmetricCipherKeyPair.getPublic()).getModulus().bitLength() + " bit");
      fail("failed key generation (768) length test");
    }
    cryptEng.init(true, localAsymmetricCipherKeyPair.getPublic());
    decryptEng.init(false, localAsymmetricCipherKeyPair.getPrivate());
    arrayOfByte = Hex.decode("4e6f77206973207468652074696d6520666f7220616c6c20676f6f64206d656e");
    if (!new BigInteger(1, arrayOfByte).equals(new BigInteger(1, enDeCrypt(arrayOfByte)))) {
      fail("failed encryption decryption (" + localNaccacheSternKeyGenerationParameters.getStrength() + ") basic test");
    }
    arrayOfByte = Hex.decode("ff6f77206973207468652074696d6520666f7220616c6c20676f6f64206d656e");
    if (!new BigInteger(1, arrayOfByte).equals(new BigInteger(1, enDeCrypt(arrayOfByte)))) {
      fail("failed encryption decryption (" + localNaccacheSternKeyGenerationParameters.getStrength() + ") edgeInput test");
    }
    try
    {
      new NaccacheSternEngine().processBlock(new byte[] { 1 }, 0, 1);
      fail("failed initialisation check");
    }
    catch (IllegalStateException localIllegalStateException) {}catch (InvalidCipherTextException localInvalidCipherTextException)
    {
      fail("failed initialisation check");
    }
  }
  
  private byte[] enDeCrypt(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, arrayOfByte.length);
    try
    {
      arrayOfByte = cryptEng.processData(arrayOfByte);
    }
    catch (InvalidCipherTextException localInvalidCipherTextException1)
    {
      fail("failed - exception " + localInvalidCipherTextException1.toString() + "\n" + localInvalidCipherTextException1.getMessage());
    }
    try
    {
      arrayOfByte = decryptEng.processData(arrayOfByte);
    }
    catch (InvalidCipherTextException localInvalidCipherTextException2)
    {
      fail("failed - exception " + localInvalidCipherTextException2.toString() + "\n" + localInvalidCipherTextException2.getMessage());
    }
    return arrayOfByte;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new NaccacheSternTest());
  }
  
  static
  {
    cryptEng.setDebug(false);
    decryptEng.setDebug(false);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\NaccacheSternTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */