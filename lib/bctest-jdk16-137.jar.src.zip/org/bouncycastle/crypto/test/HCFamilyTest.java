package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.engines.HC128Engine;
import org.bouncycastle.crypto.engines.HC256Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class HCFamilyTest
  extends SimpleTest
{
  private static final byte[] MSG = new byte[64];
  private static final byte[] K256A = new byte[32];
  private static final byte[] K256B = Hex.decode("5500000000000000000000000000000000000000000000000000000000000000");
  private static final byte[] IVA = new byte[32];
  private static final byte[] IVB = { 1 };
  private static final byte[] HC256A = Hex.decode("8589075b0df3f6d82fc0c5425179b6a63465f053f2891f808b24744e18480b72ec2792cdbf4dcfeb7769bf8dfa14aee47b4c50e8eaf3a9c8f506016c81697e32");
  private static final byte[] HC256B = Hex.decode("bfa2e2afe9ce174f8b05c2feb18bb1d1ee42c05f01312b71c61f50dd502a080bedfec706633d9241a6dac448af8561ff5e04135a9448c4342de7e9f337520bdf");
  private static final byte[] HC256C = Hex.decode("fe4a401ced5fe24fd19a8f956fc036ae3c5aa68823e2abc02f90b3aea8d30e4259f03a6c6e39eb448f7579fb70137a5e6d10b7d8add0f7cd723423daf575dde6");
  private static final byte[] HC256D = Hex.decode("c6b6fb99f2ae1440a7d4ca342011694e6f36b4be420db05d4745fd907c6306955f1d7bda13ae7e36aebc5399733b7f3795f34066b601d21f2d8cf830a9c08937");
  private static final byte[] K128A = new byte[16];
  private static final byte[] K128B = Hex.decode("55000000000000000000000000000000");
  private static final byte[] HC128A = Hex.decode("731500823bfd03a0fb2fd77faa63af0ede122fc6a7dc29b662a685278b75ec689036db1e8189600500ade078491fbf9a1cdc30136c3d6e2490f664b29cd57102");
  private static final byte[] HC128B = Hex.decode("c01893d5b7dbe9588f65ec986417660436fc6724c82c6eec1b1c38a7c9b42a95323ef1230a6a908bce757b689f14f7bbe4cde011aeb5173f89608c94b5cf46ca");
  private static final byte[] HC128C = Hex.decode("518251a404b4930ab02af9310639f032bcb4a47a5722480b2bf99f72cdc0e566310f0c56d3cc83e8663db8ef62dfe07f593e1790c5ceaa9cab03806fc9a6e5a0");
  private static final byte[] HC128D = Hex.decode("a4eac0267e4911266a2a384f5c4e1329da407fa155e6b1ae05c6fdf3bbdc8a867a699aa01a4dc11763658cccd3e624749cf8236f0131be21c3a51de9d12290de");
  
  public String getName()
  {
    return "HC-128 and HC-256";
  }
  
  public void performTest()
  {
    Object localObject = new HC256Engine();
    HCTest((StreamCipher)localObject, "HC-256 - A", K256A, IVA, HC256A);
    HCTest((StreamCipher)localObject, "HC-256 - B", K256A, IVB, HC256B);
    HCTest((StreamCipher)localObject, "HC-256 - C", K256B, IVA, HC256C);
    HCTest2((StreamCipher)localObject, "HC-256 - D", K256A, IVA, HC256D, 65536);
    localObject = new HC128Engine();
    HCTest((StreamCipher)localObject, "HC-128 - A", K128A, IVA, HC128A);
    HCTest((StreamCipher)localObject, "HC-128 - B", K128A, IVB, HC128B);
    HCTest((StreamCipher)localObject, "HC-128 - C", K128B, IVA, HC128C);
    HCTest2((StreamCipher)localObject, "HC-128 - D", K128A, IVA, HC128D, 1048576);
  }
  
  private void HCTest(StreamCipher paramStreamCipher, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    KeyParameter localKeyParameter = new KeyParameter(paramArrayOfByte1);
    ParametersWithIV localParametersWithIV = new ParametersWithIV(localKeyParameter, paramArrayOfByte2);
    paramStreamCipher.init(true, localParametersWithIV);
    for (int i = 0; i < 64; i++) {
      if (paramStreamCipher.returnByte(MSG[i]) != paramArrayOfByte3[i]) {
        fail(paramString + " failure");
      }
    }
  }
  
  private void HCTest2(StreamCipher paramStreamCipher, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt)
  {
    KeyParameter localKeyParameter = new KeyParameter(paramArrayOfByte1);
    ParametersWithIV localParametersWithIV = new ParametersWithIV(localKeyParameter, paramArrayOfByte2);
    paramStreamCipher.init(true, localParametersWithIV);
    byte[] arrayOfByte = new byte[64];
    for (int i = 0; i < paramInt; i++) {
      for (int j = 0; j < 64; j++) {
        arrayOfByte[j] = paramStreamCipher.returnByte(arrayOfByte[j]);
      }
    }
    for (i = 0; i < 64; i++) {
      if (arrayOfByte[i] != paramArrayOfByte3[i]) {
        fail(paramString + " failure at byte " + i);
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new HCFamilyTest());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\HCFamilyTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */