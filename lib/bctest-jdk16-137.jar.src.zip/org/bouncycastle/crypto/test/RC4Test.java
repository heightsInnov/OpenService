package org.bouncycastle.crypto.test;

import org.bouncycastle.crypto.engines.RC4Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.test.SimpleTest;

public class RC4Test
  extends SimpleTest
{
  StreamCipherVectorTest[] tests = { new StreamCipherVectorTest(0, new RC4Engine(), new KeyParameter(Hex.decode("0123456789ABCDEF")), "4e6f772069732074", "3afbb5c77938280d"), new StreamCipherVectorTest(0, new RC4Engine(), new KeyParameter(Hex.decode("0123456789ABCDEF")), "68652074696d6520", "1cf1e29379266d59"), new StreamCipherVectorTest(0, new RC4Engine(), new KeyParameter(Hex.decode("0123456789ABCDEF")), "666f7220616c6c20", "12fbb0c771276459") };
  
  public String getName()
  {
    return "RC4";
  }
  
  public void performTest()
  {
    for (int i = 0; i != this.tests.length; i++) {
      this.tests[i].performTest();
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    runTest(new RC4Test());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\test\RC4Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */