package org.bouncycastle.crypto.tls.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.KeyStore;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

public class HTTPSServerThread
  extends Thread
{
  private static final int PORT_NO = 8003;
  private static final char[] SERVER_PASSWORD = "serverPassword".toCharArray();
  private static final char[] TRUST_STORE_PASSWORD = "trustPassword".toCharArray();
  
  private void readRequest(InputStream paramInputStream)
    throws IOException
  {
    int i = 0;
    int j = 0;
    while (((i = paramInputStream.read()) >= 0) && (i != 10) && (j != 10)) {
      if (i != 13) {
        j = i;
      }
    }
  }
  
  private void sendResponse(OutputStream paramOutputStream)
  {
    PrintWriter localPrintWriter = new PrintWriter(new OutputStreamWriter(paramOutputStream));
    localPrintWriter.print("HTTP/1.1 200 OK\r\n");
    localPrintWriter.print("Content-Type: text/html\r\n");
    localPrintWriter.print("\r\n");
    localPrintWriter.print("<html>\r\n");
    localPrintWriter.print("<body>\r\n");
    localPrintWriter.print("Hello World!\r\n");
    localPrintWriter.print("</body>\r\n");
    localPrintWriter.print("</html>\r\n");
    localPrintWriter.flush();
  }
  
  SSLContext createSSLContext()
    throws Exception
  {
    KeyManagerFactory localKeyManagerFactory = KeyManagerFactory.getInstance("SunX509");
    KeyStore localKeyStore1 = KeyStore.getInstance("JKS");
    localKeyStore1.load(new ByteArrayInputStream(KeyStores.server), SERVER_PASSWORD);
    localKeyManagerFactory.init(localKeyStore1, SERVER_PASSWORD);
    TrustManagerFactory localTrustManagerFactory = TrustManagerFactory.getInstance("SunX509");
    KeyStore localKeyStore2 = KeyStore.getInstance("JKS");
    localKeyStore2.load(new ByteArrayInputStream(KeyStores.trustStore), TRUST_STORE_PASSWORD);
    localTrustManagerFactory.init(localKeyStore2);
    SSLContext localSSLContext = SSLContext.getInstance("TLS");
    localSSLContext.init(localKeyManagerFactory.getKeyManagers(), localTrustManagerFactory.getTrustManagers(), null);
    return localSSLContext;
  }
  
  public void run()
  {
    try
    {
      SSLContext localSSLContext = createSSLContext();
      SSLServerSocketFactory localSSLServerSocketFactory = localSSLContext.getServerSocketFactory();
      SSLServerSocket localSSLServerSocket = (SSLServerSocket)localSSLServerSocketFactory.createServerSocket(8003);
      SSLSocket localSSLSocket = (SSLSocket)localSSLServerSocket.accept();
      localSSLSocket.startHandshake();
      readRequest(localSSLSocket.getInputStream());
      SSLSession localSSLSession = localSSLSocket.getSession();
      sendResponse(localSSLSocket.getOutputStream());
      localSSLSocket.close();
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\tls\test\HTTPSServerThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */