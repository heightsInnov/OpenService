package org.bouncycastle.crypto.tls.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.crypto.tls.AlwaysValidVerifyer;
import org.bouncycastle.crypto.tls.TlsInputStream;
import org.bouncycastle.crypto.tls.TlsOuputStream;
import org.bouncycastle.crypto.tls.TlsProtocolHandler;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Hex;

public class BasicTlsTest
  extends TestCase
{
  private static final int PORT_NO = 8003;
  private static final String CLIENT = "client";
  private static final char[] CLIENT_PASSWORD = "clientPassword".toCharArray();
  private static final char[] SERVER_PASSWORD = "serverPassword".toCharArray();
  private static final char[] TRUST_STORE_PASSWORD = "trustPassword".toCharArray();
  
  public void testConnection()
    throws Exception
  {
    HTTPSServerThread localHTTPSServerThread = new HTTPSServerThread();
    localHTTPSServerThread.start();
    Thread.yield();
    AlwaysValidVerifyer localAlwaysValidVerifyer = new AlwaysValidVerifyer();
    Socket localSocket = null;
    for (int i = 0; (localSocket == null) && (i != 3); i++)
    {
      Thread.sleep(1000L);
      try
      {
        localSocket = new Socket("localhost", 8003);
      }
      catch (IOException localIOException) {}
    }
    if (localSocket == null) {
      throw new IOException("unable to connect");
    }
    long l = System.currentTimeMillis();
    TlsProtocolHandler localTlsProtocolHandler = new TlsProtocolHandler(localSocket.getInputStream(), localSocket.getOutputStream());
    localTlsProtocolHandler.connect(localAlwaysValidVerifyer);
    TlsInputStream localTlsInputStream = localTlsProtocolHandler.getTlsInputStream();
    TlsOuputStream localTlsOuputStream = localTlsProtocolHandler.getTlsOuputStream();
    localTlsOuputStream.write("GET / HTTP/1.1\r\n\r\n".getBytes());
    l = System.currentTimeMillis();
    byte[] arrayOfByte1 = new byte['က'];
    int j = 0;
    int k = 0;
    while ((j = localTlsInputStream.read(arrayOfByte1, k, arrayOfByte1.length - k)) > 0) {
      k += j;
    }
    localTlsInputStream.close();
    byte[] arrayOfByte2 = Hex.decode("485454502f312e3120323030204f4b0d0a436f6e74656e742d547970653a20746578742f68746d6c0d0a0d0a3c68746d6c3e0d0a3c626f64793e0d0a48656c6c6f20576f726c64210d0a3c2f626f64793e0d0a3c2f68746d6c3e0d0a");
    assertEquals(k, arrayOfByte2.length);
    byte[] arrayOfByte3 = new byte[arrayOfByte2.length];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, k);
    assertTrue(Arrays.areEqual(arrayOfByte2, arrayOfByte3));
  }
  
  public static TestSuite suite()
  {
    return new TestSuite(BasicTlsTest.class);
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\crypto\tls\test\BasicTlsTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */