package org.bouncycastle.math.ec.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECFieldElement.F2m;
import org.bouncycastle.math.ec.ECPoint.F2m;

public class F2mProofer
{
  private static final int NUM_SAMPLES = 1000;
  private static final String PATH = "crypto/test/src/org/bouncycastle/math/ec/test/samples/";
  private static final String INPUT_FILE_NAME_PREFIX = "Input_";
  private static final String RESULT_FILE_NAME_PREFIX = "Output_";
  public static final String[] CURVES = { "sect163r2", "sect233r1", "sect283r1", "sect409r1", "sect571r1" };
  
  private String pointToString(ECPoint.F2m paramF2m)
  {
    ECFieldElement.F2m localF2m1 = (ECFieldElement.F2m)paramF2m.getX();
    ECFieldElement.F2m localF2m2 = (ECFieldElement.F2m)paramF2m.getY();
    int i = localF2m1.getM();
    int j = i / 2 + 5;
    StringBuffer localStringBuffer = new StringBuffer(j);
    localStringBuffer.append('(');
    localStringBuffer.append(localF2m1.toBigInteger().toString(16));
    localStringBuffer.append(", ");
    localStringBuffer.append(localF2m2.toBigInteger().toString(16));
    localStringBuffer.append(')');
    return localStringBuffer.toString();
  }
  
  private void generateRandomInput(X9ECParameters paramX9ECParameters)
    throws NoSuchAlgorithmException, IOException
  {
    ECPoint.F2m localF2m = (ECPoint.F2m)paramX9ECParameters.getG();
    int i = ((ECFieldElement.F2m)localF2m.getX()).getM();
    SecureRandom localSecureRandom = SecureRandom.getInstance("SHA1PRNG");
    Properties localProperties = new Properties();
    for (int j = 0; j < 1000; j++)
    {
      localObject = new BigInteger(i, localSecureRandom);
      localProperties.put(Integer.toString(j), ((BigInteger)localObject).toString(16));
    }
    String str = Integer.toString(i);
    Object localObject = new FileOutputStream("crypto/test/src/org/bouncycastle/math/ec/test/samples/Input_" + str + ".properties");
    localProperties.store((OutputStream)localObject, "Input Samples of length" + str);
  }
  
  private void multiplyPoints(X9ECParameters paramX9ECParameters, String paramString)
    throws IOException
  {
    ECPoint.F2m localF2m1 = (ECPoint.F2m)paramX9ECParameters.getG();
    int i = ((ECFieldElement.F2m)localF2m1.getX()).getM();
    String str1 = "crypto/test/src/org/bouncycastle/math/ec/test/samples/Input_" + i + ".properties";
    Properties localProperties1 = new Properties();
    localProperties1.load(new FileInputStream(str1));
    Properties localProperties2 = new Properties();
    for (int j = 0; j < 1000; j++)
    {
      localObject = new BigInteger(localProperties1.getProperty(Integer.toString(j)), 16);
      ECPoint.F2m localF2m2 = (ECPoint.F2m)localF2m1.multiply((BigInteger)localObject);
      String str3 = pointToString(localF2m2);
      localProperties2.setProperty(Integer.toString(j), str3);
    }
    String str2 = "crypto/test/src/org/bouncycastle/math/ec/test/samples/Output_" + paramString + "_" + i + ".properties";
    Object localObject = new FileOutputStream(str2);
    localProperties2.store((OutputStream)localObject, "Output Samples of length" + i);
  }
  
  private Properties loadResults(String paramString, int paramInt)
    throws IOException
  {
    FileInputStream localFileInputStream = new FileInputStream("crypto/test/src/org/bouncycastle/math/ec/test/samples/Output_" + paramString + "_" + paramInt + ".properties");
    Properties localProperties = new Properties();
    localProperties.load(localFileInputStream);
    return localProperties;
  }
  
  private void compareResult(X9ECParameters paramX9ECParameters, String paramString1, String paramString2)
    throws IOException
  {
    ECPoint.F2m localF2m = (ECPoint.F2m)paramX9ECParameters.getG();
    int i = ((ECFieldElement.F2m)localF2m.getX()).getM();
    Properties localProperties1 = loadResults(paramString1, i);
    Properties localProperties2 = loadResults(paramString2, i);
    Set localSet = localProperties1.keySet();
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2 = localProperties1.getProperty(str1);
      String str3 = localProperties2.getProperty(str1);
      if (!str2.equals(str3)) {
        System.err.println("Difference found: m = " + i + ", " + str2 + " does not equal " + str3);
      }
    }
  }
  
  private static void usage()
  {
    System.err.println("Usage: F2mProofer [-init | -multiply <className> | -compare <className1> <className2>]");
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    if (paramArrayOfString.length == 0)
    {
      usage();
      return;
    }
    F2mProofer localF2mProofer = new F2mProofer();
    Object localObject;
    if (paramArrayOfString[0].equals("-init"))
    {
      System.out.println("Generating random input...");
      for (int i = 0; i < CURVES.length; i++)
      {
        localObject = SECNamedCurves.getByName(CURVES[i]);
        localF2mProofer.generateRandomInput((X9ECParameters)localObject);
      }
      System.out.println("Successfully generated random input in crypto/test/src/org/bouncycastle/math/ec/test/samples/");
    }
    else
    {
      String str;
      if (paramArrayOfString[0].equals("-compare"))
      {
        if (paramArrayOfString.length < 3)
        {
          usage();
          return;
        }
        str = paramArrayOfString[1];
        localObject = paramArrayOfString[2];
        System.out.println("Comparing results...");
        for (int k = 0; k < CURVES.length; k++)
        {
          X9ECParameters localX9ECParameters2 = SECNamedCurves.getByName(CURVES[k]);
          localF2mProofer.compareResult(localX9ECParameters2, str, (String)localObject);
        }
        System.out.println("Successfully compared results in crypto/test/src/org/bouncycastle/math/ec/test/samples/");
      }
      else if (paramArrayOfString[0].equals("-multiply"))
      {
        if (paramArrayOfString.length < 2)
        {
          usage();
          return;
        }
        str = paramArrayOfString[1];
        System.out.println("Multiplying points...");
        for (int j = 0; j < CURVES.length; j++)
        {
          X9ECParameters localX9ECParameters1 = SECNamedCurves.getByName(CURVES[j]);
          localF2mProofer.multiplyPoints(localX9ECParameters1, str);
        }
        System.out.println("Successfully generated multiplied points in crypto/test/src/org/bouncycastle/math/ec/test/samples/");
      }
      else
      {
        usage();
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\math\ec\test\F2mProofer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */