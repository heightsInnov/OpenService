package org.bouncycastle.math.ec.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class AllTests
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("EC Math tests");
    localTestSuite.addTest(ECPointTest.suite());
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\math\ec\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */