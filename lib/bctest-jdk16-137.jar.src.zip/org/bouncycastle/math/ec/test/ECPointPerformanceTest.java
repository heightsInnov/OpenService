package org.bouncycastle.math.ec.test;

import java.io.PrintStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import junit.framework.TestCase;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECPoint;

public class ECPointPerformanceTest
  extends TestCase
{
  public static final int NUM_ROUNDS = 100;
  
  private void randMult(String paramString)
    throws Exception
  {
    X9ECParameters localX9ECParameters = SECNamedCurves.getByName(paramString);
    BigInteger localBigInteger1 = localX9ECParameters.getN();
    ECPoint localECPoint1 = localX9ECParameters.getG();
    SecureRandom localSecureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
    BigInteger localBigInteger2 = new BigInteger(localBigInteger1.bitLength() - 1, localSecureRandom);
    ECPoint localECPoint2 = null;
    long l1 = System.currentTimeMillis();
    for (int i = 0; i < 100; i++) {
      localECPoint2 = localECPoint1.multiply(localBigInteger2);
    }
    long l2 = System.currentTimeMillis();
    double d = (l2 - l1) / 100.0D;
    System.out.println(paramString);
    System.out.print("Millis   : ");
    System.out.println(d);
    System.out.println();
  }
  
  public void testMultiply()
    throws Exception
  {
    randMult("sect163r2");
    randMult("sect233r1");
    randMult("sect283r1");
    randMult("sect409r1");
    randMult("sect571r1");
    randMult("secp224r1");
    randMult("secp256r1");
    randMult("secp521r1");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\math\ec\test\ECPointPerformanceTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */