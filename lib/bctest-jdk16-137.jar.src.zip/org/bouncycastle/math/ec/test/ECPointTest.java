package org.bouncycastle.math.ec.test;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Enumeration;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.F2m;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.math.ec.ECFieldElement.F2m;
import org.bouncycastle.math.ec.ECFieldElement.Fp;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.math.ec.ECPoint.F2m;
import org.bouncycastle.math.ec.ECPoint.Fp;

public class ECPointTest
  extends TestCase
{
  private SecureRandom secRand = new SecureRandom();
  private Fp fp = null;
  private F2m f2m = null;
  
  public void setUp()
  {
    this.fp = new Fp();
    this.fp.createPoints();
    this.f2m = new F2m();
    this.f2m.createPoints();
  }
  
  public void testPointCreationConsistency()
  {
    try
    {
      ECPoint.Fp localFp1 = new ECPoint.Fp(this.fp.curve, new ECFieldElement.Fp(this.fp.q, new BigInteger("12")), null);
      fail();
    }
    catch (IllegalArgumentException localIllegalArgumentException1) {}
    try
    {
      ECPoint.Fp localFp2 = new ECPoint.Fp(this.fp.curve, null, new ECFieldElement.Fp(this.fp.q, new BigInteger("12")));
      fail();
    }
    catch (IllegalArgumentException localIllegalArgumentException2) {}
    try
    {
      ECPoint.F2m localF2m1 = new ECPoint.F2m(this.f2m.curve, new ECFieldElement.F2m(4, 1, new BigInteger("1011")), null);
      fail();
    }
    catch (IllegalArgumentException localIllegalArgumentException3) {}
    try
    {
      ECPoint.F2m localF2m2 = new ECPoint.F2m(this.f2m.curve, null, new ECFieldElement.F2m(4, 1, new BigInteger("1011")));
      fail();
    }
    catch (IllegalArgumentException localIllegalArgumentException4) {}
  }
  
  private void implTestAdd(ECPoint[] paramArrayOfECPoint, ECPoint paramECPoint)
  {
    assertEquals("p0 plus p1 does not equal p2", paramArrayOfECPoint[2], paramArrayOfECPoint[0].add(paramArrayOfECPoint[1]));
    assertEquals("p1 plus p0 does not equal p2", paramArrayOfECPoint[2], paramArrayOfECPoint[1].add(paramArrayOfECPoint[0]));
    for (int i = 0; i < paramArrayOfECPoint.length; i++)
    {
      assertEquals("Adding infinity failed", paramArrayOfECPoint[i], paramArrayOfECPoint[i].add(paramECPoint));
      assertEquals("Adding to infinity failed", paramArrayOfECPoint[i], paramECPoint.add(paramArrayOfECPoint[i]));
    }
  }
  
  public void testAdd()
  {
    implTestAdd(this.fp.p, this.fp.infinity);
    implTestAdd(this.f2m.p, this.f2m.infinity);
  }
  
  private void implTestTwice(ECPoint[] paramArrayOfECPoint)
  {
    assertEquals("Twice incorrect", paramArrayOfECPoint[3], paramArrayOfECPoint[0].twice());
    assertEquals("Add same point incorrect", paramArrayOfECPoint[3], paramArrayOfECPoint[0].add(paramArrayOfECPoint[0]));
  }
  
  public void testTwice()
  {
    implTestTwice(this.fp.p);
    implTestTwice(this.f2m.p);
  }
  
  private void implTestAllPoints(ECPoint paramECPoint1, ECPoint paramECPoint2)
  {
    ECPoint localECPoint1 = paramECPoint2;
    ECPoint localECPoint2 = paramECPoint2;
    int i = 1;
    do
    {
      localECPoint1 = localECPoint1.add(paramECPoint1);
      localECPoint2 = paramECPoint1.multiply(new BigInteger(Integer.toString(i)));
      assertEquals("Results of add() and multiply() are inconsistent " + i, localECPoint1, localECPoint2);
      i++;
    } while (!localECPoint1.equals(paramECPoint2));
  }
  
  public void testAllPoints()
  {
    for (int i = 0; i < this.fp.p.length; i++) {
      implTestAllPoints(this.fp.p[0], this.fp.infinity);
    }
    for (i = 0; i < this.f2m.p.length; i++) {
      implTestAllPoints(this.f2m.p[0], this.f2m.infinity);
    }
  }
  
  private ECPoint multiply(ECPoint paramECPoint, BigInteger paramBigInteger)
  {
    ECPoint localECPoint = paramECPoint.getCurve().getInfinity();
    int i = paramBigInteger.bitLength();
    for (int j = 0; j < i; j++)
    {
      if (paramBigInteger.testBit(j)) {
        localECPoint = localECPoint.add(paramECPoint);
      }
      paramECPoint = paramECPoint.twice();
    }
    return localECPoint;
  }
  
  private void implTestMultiply(ECPoint paramECPoint, int paramInt)
  {
    BigInteger localBigInteger = new BigInteger(paramInt, this.secRand);
    ECPoint localECPoint1 = multiply(paramECPoint, localBigInteger);
    ECPoint localECPoint2 = paramECPoint.multiply(localBigInteger);
    assertEquals("ECPoint.multiply is incorrect", localECPoint1, localECPoint2);
  }
  
  private void implTestMultiplyAll(ECPoint paramECPoint, int paramInt)
  {
    BigInteger localBigInteger1 = BigInteger.valueOf(2L).pow(paramInt);
    BigInteger localBigInteger2 = BigInteger.ZERO;
    do
    {
      ECPoint localECPoint1 = multiply(paramECPoint, localBigInteger2);
      ECPoint localECPoint2 = paramECPoint.multiply(localBigInteger2);
      assertEquals("ECPoint.multiply is incorrect", localECPoint1, localECPoint2);
      localBigInteger2 = localBigInteger2.add(BigInteger.ONE);
    } while (localBigInteger2.compareTo(localBigInteger1) < 0);
  }
  
  private void implTestAddSubtract(ECPoint paramECPoint1, ECPoint paramECPoint2)
  {
    assertEquals("Twice and Add inconsistent", paramECPoint1.twice(), paramECPoint1.add(paramECPoint1));
    assertEquals("Twice p - p is not p", paramECPoint1, paramECPoint1.twice().subtract(paramECPoint1));
    assertEquals("p - p is not infinity", paramECPoint2, paramECPoint1.subtract(paramECPoint1));
    assertEquals("p plus infinity is not p", paramECPoint1, paramECPoint1.add(paramECPoint2));
    assertEquals("infinity plus p is not p", paramECPoint1, paramECPoint2.add(paramECPoint1));
    assertEquals("infinity plus infinity is not infinity ", paramECPoint2, paramECPoint2.add(paramECPoint2));
  }
  
  public void testAddSubtractMultiplySimple()
  {
    for (int i = 0; i < this.fp.pointSource.length / 2; i++)
    {
      implTestAddSubtract(this.fp.p[i], this.fp.infinity);
      implTestMultiplyAll(this.fp.p[i], 6);
      implTestMultiplyAll(this.fp.infinity, 6);
    }
    for (i = 0; i < this.f2m.pointSource.length / 2; i++)
    {
      implTestAddSubtract(this.f2m.p[i], this.f2m.infinity);
      implTestMultiplyAll(this.f2m.p[i], 6);
      implTestMultiplyAll(this.f2m.infinity, 6);
    }
  }
  
  private void implTestEncoding(ECPoint paramECPoint)
  {
    Object localObject1;
    Object localObject2;
    if ((paramECPoint instanceof ECPoint.Fp))
    {
      localObject1 = new ECPoint.Fp(paramECPoint.getCurve(), paramECPoint.getX(), paramECPoint.getY(), false);
      localObject2 = new ECPoint.Fp(paramECPoint.getCurve(), paramECPoint.getX(), paramECPoint.getY(), true);
    }
    else
    {
      localObject1 = new ECPoint.F2m(paramECPoint.getCurve(), paramECPoint.getX(), paramECPoint.getY(), false);
      localObject2 = new ECPoint.F2m(paramECPoint.getCurve(), paramECPoint.getX(), paramECPoint.getY(), true);
    }
    byte[] arrayOfByte1 = ((ECPoint)localObject1).getEncoded();
    ECPoint localECPoint1 = paramECPoint.getCurve().decodePoint(arrayOfByte1);
    assertEquals("Error decoding uncompressed point", paramECPoint, localECPoint1);
    byte[] arrayOfByte2 = ((ECPoint)localObject2).getEncoded();
    ECPoint localECPoint2 = paramECPoint.getCurve().decodePoint(arrayOfByte2);
    assertEquals("Error decoding compressed point", paramECPoint, localECPoint2);
  }
  
  public void testAddSubtractMultiplyTwiceEncoding()
  {
    Enumeration localEnumeration = SECNamedCurves.getNames();
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      X9ECParameters localX9ECParameters = SECNamedCurves.getByName(str);
      BigInteger localBigInteger1 = localX9ECParameters.getN();
      BigInteger localBigInteger2 = new BigInteger(localBigInteger1.bitLength(), this.secRand);
      ECPoint localECPoint1 = localX9ECParameters.getG();
      ECPoint localECPoint2 = localECPoint1.multiply(localBigInteger2);
      ECPoint localECPoint3 = localX9ECParameters.getCurve().getInfinity();
      implTestAddSubtract(localECPoint2, localECPoint3);
      implTestMultiply(localECPoint2, localBigInteger1.bitLength());
      implTestMultiply(localECPoint3, localBigInteger1.bitLength());
      implTestEncoding(localECPoint2);
    }
  }
  
  public static Test suite()
  {
    return new TestSuite(ECPointTest.class);
  }
  
  public static class F2m
  {
    private final int m = 4;
    private final int k1 = 1;
    private final ECFieldElement.F2m aTpb = new ECFieldElement.F2m(4, 1, new BigInteger("1000", 2));
    private final ECFieldElement.F2m bTpb = new ECFieldElement.F2m(4, 1, new BigInteger("1001", 2));
    private final ECCurve.F2m curve = new ECCurve.F2m(4, 1, this.aTpb.toBigInteger(), this.bTpb.toBigInteger());
    private final ECPoint.F2m infinity = (ECPoint.F2m)this.curve.getInfinity();
    private final String[] pointSource = { "0010", "1111", "1100", "1100", "0001", "0001", "1011", "0010" };
    private ECPoint.F2m[] p = new ECPoint.F2m[this.pointSource.length / 2];
    
    private void createPoints()
    {
      for (int i = 0; i < this.pointSource.length / 2; i++)
      {
        ECFieldElement.F2m localF2m1 = new ECFieldElement.F2m(4, 1, new BigInteger(this.pointSource[(2 * i)], 2));
        ECFieldElement.F2m localF2m2 = new ECFieldElement.F2m(4, 1, new BigInteger(this.pointSource[(2 * i + 1)], 2));
        this.p[i] = new ECPoint.F2m(this.curve, localF2m1, localF2m2);
      }
    }
  }
  
  public static class Fp
  {
    private final BigInteger q = new BigInteger("29");
    private final BigInteger a = new BigInteger("4");
    private final BigInteger b = new BigInteger("20");
    private final ECCurve.Fp curve = new ECCurve.Fp(this.q, this.a, this.b);
    private final ECPoint.Fp infinity = (ECPoint.Fp)this.curve.getInfinity();
    private final int[] pointSource = { 5, 22, 16, 27, 13, 6, 14, 6 };
    private ECPoint.Fp[] p = new ECPoint.Fp[this.pointSource.length / 2];
    
    private void createPoints()
    {
      for (int i = 0; i < this.pointSource.length / 2; i++)
      {
        ECFieldElement.Fp localFp1 = new ECFieldElement.Fp(this.q, new BigInteger(Integer.toString(this.pointSource[(2 * i)])));
        ECFieldElement.Fp localFp2 = new ECFieldElement.Fp(this.q, new BigInteger(Integer.toString(this.pointSource[(2 * i + 1)])));
        this.p[i] = new ECPoint.Fp(this.curve, localFp1, localFp2);
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\math\ec\test\ECPointTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */