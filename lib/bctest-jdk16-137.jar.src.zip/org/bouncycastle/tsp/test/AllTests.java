package org.bouncycastle.tsp.test;

import java.security.Security;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AllTests
  extends TestCase
{
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
  {
    Security.addProvider(new BouncyCastleProvider());
    TestSuite localTestSuite = new TestSuite("TSP Tests");
    localTestSuite.addTestSuite(ParseTest.class);
    localTestSuite.addTestSuite(TSPTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\tsp\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */