package org.bouncycastle.tsp.test;

import java.math.BigInteger;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import junit.framework.TestCase;
import org.bouncycastle.asn1.cmp.PKIFailureInfo;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.tsp.GenTimeAccuracy;
import org.bouncycastle.tsp.TSPAlgorithms;
import org.bouncycastle.tsp.TSPValidationException;
import org.bouncycastle.tsp.TimeStampRequest;
import org.bouncycastle.tsp.TimeStampRequestGenerator;
import org.bouncycastle.tsp.TimeStampResponse;
import org.bouncycastle.tsp.TimeStampResponseGenerator;
import org.bouncycastle.tsp.TimeStampToken;
import org.bouncycastle.tsp.TimeStampTokenGenerator;
import org.bouncycastle.tsp.TimeStampTokenInfo;
import org.bouncycastle.util.Arrays;

public class TSPTest
  extends TestCase
{
  public void testGeneral()
    throws Exception
  {
    String str1 = "O=Bouncy Castle, C=AU";
    KeyPair localKeyPair1 = TSPTestUtil.makeKeyPair();
    X509Certificate localX509Certificate1 = TSPTestUtil.makeCACertificate(localKeyPair1, str1, localKeyPair1, str1);
    String str2 = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
    KeyPair localKeyPair2 = TSPTestUtil.makeKeyPair();
    X509Certificate localX509Certificate2 = TSPTestUtil.makeCertificate(localKeyPair2, str2, localKeyPair1, str1);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localX509Certificate2);
    localArrayList.add(localX509Certificate1);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    basicTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    responseValidationTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    incorrectHashTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    badAlgorithmTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    badPolicyTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    tokenEncodingTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    certReqTest(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    testAccuracyZeroCerts(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    testAccuracyWithCertsAndOrdering(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
    testNoNonse(localKeyPair2.getPrivate(), localX509Certificate2, localCertStore);
  }
  
  private void basicTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.SHA1, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    localTimeStampToken.validate(paramX509Certificate, "BC");
    AttributeTable localAttributeTable = localTimeStampToken.getSignedAttributes();
    assertNotNull("no signingCertificate attribute found", localAttributeTable.get(PKCSObjectIdentifiers.id_aa_signingCertificate));
  }
  
  private void responseValidationTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.MD5, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    localTimeStampToken.validate(paramX509Certificate, "BC");
    localTimeStampResponse.validate(localTimeStampRequest);
    try
    {
      localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(101L));
      localTimeStampResponse.validate(localTimeStampRequest);
      fail("response validation failed on invalid nonce.");
    }
    catch (TSPValidationException localTSPValidationException1) {}
    try
    {
      localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[22], BigInteger.valueOf(100L));
      localTimeStampResponse.validate(localTimeStampRequest);
      fail("response validation failed on wrong digest.");
    }
    catch (TSPValidationException localTSPValidationException2) {}
    try
    {
      localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.MD5, new byte[20], BigInteger.valueOf(100L));
      localTimeStampResponse.validate(localTimeStampRequest);
      fail("response validation failed on wrong digest.");
    }
    catch (TSPValidationException localTSPValidationException3) {}
  }
  
  private void incorrectHashTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.SHA1, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[16]);
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    if (localTimeStampToken != null) {
      fail("incorrectHash - token not null.");
    }
    PKIFailureInfo localPKIFailureInfo = localTimeStampResponse.getFailInfo();
    if (localPKIFailureInfo == null) {
      fail("incorrectHash - failInfo set to null.");
    }
    if (localPKIFailureInfo.intValue() != 4) {
      fail("incorrectHash - wrong failure info returned.");
    }
  }
  
  private void badAlgorithmTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.SHA1, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate("1.2.3.4.5", new byte[20]);
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    if (localTimeStampToken != null) {
      fail("badAlgorithm - token not null.");
    }
    PKIFailureInfo localPKIFailureInfo = localTimeStampResponse.getFailInfo();
    if (localPKIFailureInfo == null) {
      fail("badAlgorithm - failInfo set to null.");
    }
    if (localPKIFailureInfo.intValue() != 128) {
      fail("badAlgorithm - wrong failure info returned.");
    }
  }
  
  private void badPolicyTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.SHA1, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    localTimeStampRequestGenerator.setReqPolicy("1.1");
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20]);
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED, new HashSet());
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    if (localTimeStampToken != null) {
      fail("badPolicy - token not null.");
    }
    PKIFailureInfo localPKIFailureInfo = localTimeStampResponse.getFailInfo();
    if (localPKIFailureInfo == null) {
      fail("badPolicy - failInfo set to null.");
    }
    if (localPKIFailureInfo.intValue() != 256) {
      fail("badPolicy - wrong failure info returned.");
    }
  }
  
  private void certReqTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.MD5, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    localTimeStampRequestGenerator.setCertReq(false);
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    assertNull(localTimeStampToken.getTimeStampInfo().getGenTimeAccuracy());
    assertEquals("1.2", localTimeStampToken.getTimeStampInfo().getPolicy());
    try
    {
      localTimeStampToken.validate(paramX509Certificate, "BC");
    }
    catch (TSPValidationException localTSPValidationException)
    {
      fail("certReq(false) verification of token failed.");
    }
    CertStore localCertStore = localTimeStampToken.getCertificatesAndCRLs("Collection", "BC");
    Collection localCollection = localCertStore.getCertificates(null);
    if (!localCollection.isEmpty()) {
      fail("certReq(false) found certificates in response.");
    }
  }
  
  private void tokenEncodingTest(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.SHA1, "1.2.3.4.5.6");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse1 = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse1 = new TimeStampResponse(localTimeStampResponse1.getEncoded());
    TimeStampResponse localTimeStampResponse2 = new TimeStampResponse(localTimeStampResponse1.getEncoded());
    if ((!Arrays.areEqual(localTimeStampResponse2.getEncoded(), localTimeStampResponse1.getEncoded())) || (!Arrays.areEqual(localTimeStampResponse2.getTimeStampToken().getEncoded(), localTimeStampResponse1.getTimeStampToken().getEncoded()))) {
      fail();
    }
  }
  
  private void testAccuracyZeroCerts(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.MD5, "1.2");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    localTimeStampTokenGenerator.setAccuracySeconds(1);
    localTimeStampTokenGenerator.setAccuracyMillis(2);
    localTimeStampTokenGenerator.setAccuracyMicros(3);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    localTimeStampToken.validate(paramX509Certificate, "BC");
    localTimeStampResponse.validate(localTimeStampRequest);
    TimeStampTokenInfo localTimeStampTokenInfo = localTimeStampToken.getTimeStampInfo();
    GenTimeAccuracy localGenTimeAccuracy = localTimeStampTokenInfo.getGenTimeAccuracy();
    assertEquals(1, localGenTimeAccuracy.getSeconds());
    assertEquals(2, localGenTimeAccuracy.getMillis());
    assertEquals(3, localGenTimeAccuracy.getMicros());
    assertEquals(new BigInteger("23"), localTimeStampTokenInfo.getSerialNumber());
    assertEquals("1.2", localTimeStampTokenInfo.getPolicy());
    CertStore localCertStore = localTimeStampToken.getCertificatesAndCRLs("Collection", "BC");
    Collection localCollection = localCertStore.getCertificates(null);
    assertEquals(0, localCollection.size());
  }
  
  private void testAccuracyWithCertsAndOrdering(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.MD5, "1.2.3");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    localTimeStampTokenGenerator.setAccuracySeconds(3);
    localTimeStampTokenGenerator.setAccuracyMillis(1);
    localTimeStampTokenGenerator.setAccuracyMicros(2);
    localTimeStampTokenGenerator.setOrdering(true);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    localTimeStampRequestGenerator.setCertReq(true);
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20], BigInteger.valueOf(100L));
    assertTrue(localTimeStampRequest.getCertReq());
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("23"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    localTimeStampToken.validate(paramX509Certificate, "BC");
    localTimeStampResponse.validate(localTimeStampRequest);
    TimeStampTokenInfo localTimeStampTokenInfo = localTimeStampToken.getTimeStampInfo();
    GenTimeAccuracy localGenTimeAccuracy = localTimeStampTokenInfo.getGenTimeAccuracy();
    assertEquals(3, localGenTimeAccuracy.getSeconds());
    assertEquals(1, localGenTimeAccuracy.getMillis());
    assertEquals(2, localGenTimeAccuracy.getMicros());
    assertEquals(new BigInteger("23"), localTimeStampTokenInfo.getSerialNumber());
    assertEquals("1.2.3", localTimeStampTokenInfo.getPolicy());
    assertEquals(true, localTimeStampTokenInfo.isOrdered());
    assertEquals(localTimeStampTokenInfo.getNonce(), BigInteger.valueOf(100L));
    CertStore localCertStore = localTimeStampToken.getCertificatesAndCRLs("Collection", "BC");
    Collection localCollection = localCertStore.getCertificates(null);
    assertEquals(2, localCollection.size());
  }
  
  private void testNoNonse(PrivateKey paramPrivateKey, X509Certificate paramX509Certificate, CertStore paramCertStore)
    throws Exception
  {
    TimeStampTokenGenerator localTimeStampTokenGenerator = new TimeStampTokenGenerator(paramPrivateKey, paramX509Certificate, TSPAlgorithms.MD5, "1.2.3");
    localTimeStampTokenGenerator.setCertificatesAndCRLs(paramCertStore);
    TimeStampRequestGenerator localTimeStampRequestGenerator = new TimeStampRequestGenerator();
    TimeStampRequest localTimeStampRequest = localTimeStampRequestGenerator.generate(TSPAlgorithms.SHA1, new byte[20]);
    assertFalse(localTimeStampRequest.getCertReq());
    TimeStampResponseGenerator localTimeStampResponseGenerator = new TimeStampResponseGenerator(localTimeStampTokenGenerator, TSPAlgorithms.ALLOWED);
    TimeStampResponse localTimeStampResponse = localTimeStampResponseGenerator.generate(localTimeStampRequest, new BigInteger("24"), new Date(), "BC");
    localTimeStampResponse = new TimeStampResponse(localTimeStampResponse.getEncoded());
    TimeStampToken localTimeStampToken = localTimeStampResponse.getTimeStampToken();
    localTimeStampToken.validate(paramX509Certificate, "BC");
    localTimeStampResponse.validate(localTimeStampRequest);
    TimeStampTokenInfo localTimeStampTokenInfo = localTimeStampToken.getTimeStampInfo();
    GenTimeAccuracy localGenTimeAccuracy = localTimeStampTokenInfo.getGenTimeAccuracy();
    assertNull(localGenTimeAccuracy);
    assertEquals(new BigInteger("24"), localTimeStampTokenInfo.getSerialNumber());
    assertEquals("1.2.3", localTimeStampTokenInfo.getPolicy());
    assertEquals(false, localTimeStampTokenInfo.isOrdered());
    assertNull(localTimeStampTokenInfo.getNonce());
    CertStore localCertStore = localTimeStampToken.getCertificatesAndCRLs("Collection", "BC");
    Collection localCollection = localCertStore.getCertificates(null);
    assertEquals(0, localCollection.size());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\tsp\test\TSPTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */