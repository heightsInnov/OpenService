package org.bouncycastle.cms.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.DSAParameterSpec;
import java.util.Date;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.jce.ECGOST3410NamedCurveTable;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.GOST3410ParameterSpec;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509StreamParser;
import org.bouncycastle.x509.X509V2CRLGenerator;
import org.bouncycastle.x509.X509V3CertificateGenerator;
import org.bouncycastle.x509.extension.AuthorityKeyIdentifierStructure;

public class CMSTestUtil
{
  public static SecureRandom rand;
  public static KeyPairGenerator kpg;
  public static KeyPairGenerator gostKpg;
  public static KeyPairGenerator dsaKpg;
  public static KeyPairGenerator ecGostKpg;
  public static KeyPairGenerator ecDsaKpg;
  public static KeyGenerator aes192kg;
  public static KeyGenerator desede128kg;
  public static KeyGenerator desede192kg;
  public static KeyGenerator rc240kg;
  public static KeyGenerator rc264kg;
  public static KeyGenerator rc2128kg;
  public static KeyGenerator aesKg;
  public static KeyGenerator seedKg;
  public static KeyGenerator camelliaKg;
  public static BigInteger serialNumber;
  public static final boolean DEBUG = true;
  private static byte[] attrCert = Base64.decode("MIIHQDCCBqkCAQEwgZChgY2kgYowgYcxHDAaBgkqhkiG9w0BCQEWDW1sb3JjaEB2dC5lZHUxHjAcBgNVBAMTFU1hcmt1cyBMb3JjaCAobWxvcmNoKTEbMBkGA1UECxMSVmlyZ2luaWEgVGVjaCBVc2VyMRAwDgYDVQQLEwdDbGFzcyAyMQswCQYDVQQKEwJ2dDELMAkGA1UEBhMCVVMwgYmkgYYwgYMxGzAZBgkqhkiG9w0BCQEWDHNzaGFoQHZ0LmVkdTEbMBkGA1UEAxMSU3VtaXQgU2hhaCAoc3NoYWgpMRswGQYDVQQLExJWaXJnaW5pYSBUZWNoIFVzZXIxEDAOBgNVBAsTB0NsYXNzIDExCzAJBgNVBAoTAnZ0MQswCQYDVQQGEwJVUzANBgkqhkiG9w0BAQQFAAIBBTAiGA8yMDAzMDcxODE2MDgwMloYDzIwMDMwNzI1MTYwODAyWjCCBU0wggVJBgorBgEEAbRoCAEBMYIFORaCBTU8UnVsZSBSdWxlSWQ9IkZpbGUtUHJpdmlsZWdlLVJ1bGUiIEVmZmVjdD0iUGVybWl0Ij4KIDxUYXJnZXQ+CiAgPFN1YmplY3RzPgogICA8U3ViamVjdD4KICAgIDxTdWJqZWN0TWF0Y2ggTWF0Y2hJZD0idXJuOm9hc2lzOm5hbWVzOnRjOnhhY21sOjEuMDpmdW5jdGlvbjpzdHJpbmctZXF1YWwiPgogICAgIDxBdHRyaWJ1dGVWYWx1ZSBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjc3RyaW5nIj4KICAgICAgIENOPU1hcmt1cyBMb3JjaDwvQXR0cmlidXRlVmFsdWU+CiAgICAgPFN1YmplY3RBdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOnN1YmplY3Q6c3ViamVjdC1pZCIgRGF0YVR5cGU9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hI3N0cmluZyIgLz4gCiAgICA8L1N1YmplY3RNYXRjaD4KICAgPC9TdWJqZWN0PgogIDwvU3ViamVjdHM+CiAgPFJlc291cmNlcz4KICAgPFJlc291cmNlPgogICAgPFJlc291cmNlTWF0Y2ggTWF0Y2hJZD0idXJuOm9hc2lzOm5hbWVzOnRjOnhhY21sOjEuMDpmdW5jdGlvbjpzdHJpbmctZXF1YWwiPgogICAgIDxBdHRyaWJ1dGVWYWx1ZSBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjYW55VVJJIj4KICAgICAgaHR0cDovL3p1bmkuY3MudnQuZWR1PC9BdHRyaWJ1dGVWYWx1ZT4KICAgICA8UmVzb3VyY2VBdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOnJlc291cmNlOnJlc291cmNlLWlkIiBEYXRhVHlwZT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEjYW55VVJJIiAvPiAKICAgIDwvUmVzb3VyY2VNYXRjaD4KICAgPC9SZXNvdXJjZT4KICA8L1Jlc291cmNlcz4KICA8QWN0aW9ucz4KICAgPEFjdGlvbj4KICAgIDxBY3Rpb25NYXRjaCBNYXRjaElkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOmZ1bmN0aW9uOnN0cmluZy1lcXVhbCI+CiAgICAgPEF0dHJpYnV0ZVZhbHVlIERhdGFUeXBlPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSNzdHJpbmciPgpEZWxlZ2F0ZSBBY2Nlc3MgICAgIDwvQXR0cmlidXRlVmFsdWU+CgkgIDxBY3Rpb25BdHRyaWJ1dGVEZXNpZ25hdG9yIEF0dHJpYnV0ZUlkPSJ1cm46b2FzaXM6bmFtZXM6dGM6eGFjbWw6MS4wOmFjdGlvbjphY3Rpb24taWQiIERhdGFUeXBlPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSNzdHJpbmciIC8+IAogICAgPC9BY3Rpb25NYXRjaD4KICAgPC9BY3Rpb24+CiAgPC9BY3Rpb25zPgogPC9UYXJnZXQ+CjwvUnVsZT4KMA0GCSqGSIb3DQEBBAUAA4GBAGiJSM48XsY90HlYxGmGVSmNR6ZW2As+bot3KAfiCIkUIOAqhcphBS23egTr6asYwy151HshbPNYz+Cgeqs45KkVzh7bL/0e1r8sDVIaaGIkjHK3CqBABnfSayr3Rd1yBoDdEv8Qb+3eEPH6ab9021AsLEnJ6LWTmybbOpMNZ3tv");
  
  public static String dumpBase64(byte[] paramArrayOfByte)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    paramArrayOfByte = Base64.encode(paramArrayOfByte);
    for (int i = 0; i < paramArrayOfByte.length; i += 64)
    {
      if (i + 64 < paramArrayOfByte.length) {
        localStringBuffer.append(new String(paramArrayOfByte, i, 64));
      } else {
        localStringBuffer.append(new String(paramArrayOfByte, i, paramArrayOfByte.length - i));
      }
      localStringBuffer.append('\n');
    }
    return localStringBuffer.toString();
  }
  
  public static X509AttributeCertificate getAttributeCertificate()
    throws Exception
  {
    X509StreamParser localX509StreamParser = X509StreamParser.getInstance("AttributeCertificate", "BC");
    localX509StreamParser.init(attrCert);
    return (X509AttributeCertificate)localX509StreamParser.read();
  }
  
  public static KeyPair makeKeyPair()
  {
    return kpg.generateKeyPair();
  }
  
  public static KeyPair makeGostKeyPair()
  {
    return gostKpg.generateKeyPair();
  }
  
  public static KeyPair makeDsaKeyPair()
  {
    return dsaKpg.generateKeyPair();
  }
  
  public static KeyPair makeEcDsaKeyPair()
  {
    return ecDsaKpg.generateKeyPair();
  }
  
  public static KeyPair makeEcGostKeyPair()
  {
    return ecGostKpg.generateKeyPair();
  }
  
  public static SecretKey makeDesede128Key()
  {
    return desede128kg.generateKey();
  }
  
  public static SecretKey makeAES192Key()
  {
    return aes192kg.generateKey();
  }
  
  public static SecretKey makeDesede192Key()
  {
    return desede192kg.generateKey();
  }
  
  public static SecretKey makeRC240Key()
  {
    return rc240kg.generateKey();
  }
  
  public static SecretKey makeRC264Key()
  {
    return rc264kg.generateKey();
  }
  
  public static SecretKey makeRC2128Key()
  {
    return rc2128kg.generateKey();
  }
  
  public static SecretKey makeSEEDKey()
  {
    return seedKg.generateKey();
  }
  
  public static SecretKey makeAESKey(int paramInt)
  {
    aesKg.init(paramInt);
    return aesKg.generateKey();
  }
  
  public static SecretKey makeCamelliaKey(int paramInt)
  {
    camelliaKg.init(paramInt);
    return camelliaKg.generateKey();
  }
  
  public static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, false);
  }
  
  public static X509Certificate makeCACertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    return makeCertificate(paramKeyPair1, paramString1, paramKeyPair2, paramString2, true);
  }
  
  public static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2, boolean paramBoolean)
    throws GeneralSecurityException, IOException
  {
    PublicKey localPublicKey1 = paramKeyPair1.getPublic();
    PrivateKey localPrivateKey = paramKeyPair2.getPrivate();
    PublicKey localPublicKey2 = paramKeyPair2.getPublic();
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.reset();
    localX509V3CertificateGenerator.setSerialNumber(allocateSerialNumber());
    localX509V3CertificateGenerator.setIssuerDN(new X509Name(paramString2));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis()));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 8640000000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Name(paramString1));
    localX509V3CertificateGenerator.setPublicKey(localPublicKey1);
    if ((localPublicKey2 instanceof RSAPublicKey)) {
      localX509V3CertificateGenerator.setSignatureAlgorithm("SHA1WithRSA");
    } else if (localPublicKey2.getAlgorithm().equals("DSA")) {
      localX509V3CertificateGenerator.setSignatureAlgorithm("SHA1withDSA");
    } else if (localPublicKey2.getAlgorithm().equals("ECDSA")) {
      localX509V3CertificateGenerator.setSignatureAlgorithm("SHA1withECDSA");
    } else if (localPublicKey2.getAlgorithm().equals("ECGOST3410")) {
      localX509V3CertificateGenerator.setSignatureAlgorithm("GOST3411withECGOST3410");
    } else {
      localX509V3CertificateGenerator.setSignatureAlgorithm("GOST3411WithGOST3410");
    }
    localX509V3CertificateGenerator.addExtension(X509Extensions.SubjectKeyIdentifier, false, createSubjectKeyId(localPublicKey1));
    localX509V3CertificateGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, createAuthorityKeyId(localPublicKey2));
    localX509V3CertificateGenerator.addExtension(X509Extensions.BasicConstraints, false, new BasicConstraints(paramBoolean));
    X509Certificate localX509Certificate = localX509V3CertificateGenerator.generate(localPrivateKey);
    localX509Certificate.checkValidity(new Date());
    localX509Certificate.verify(localPublicKey2);
    return localX509Certificate;
  }
  
  public static X509CRL makeCrl(KeyPair paramKeyPair)
    throws Exception
  {
    X509V2CRLGenerator localX509V2CRLGenerator = new X509V2CRLGenerator();
    Date localDate = new Date();
    localX509V2CRLGenerator.setIssuerDN(new X509Principal("CN=Test CA"));
    localX509V2CRLGenerator.setThisUpdate(localDate);
    localX509V2CRLGenerator.setNextUpdate(new Date(localDate.getTime() + 100000L));
    localX509V2CRLGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
    localX509V2CRLGenerator.addCRLEntry(BigInteger.ONE, localDate, 9);
    localX509V2CRLGenerator.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(paramKeyPair.getPublic()));
    return localX509V2CRLGenerator.generate(paramKeyPair.getPrivate(), "BC");
  }
  
  private static AuthorityKeyIdentifier createAuthorityKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new AuthorityKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  private static SubjectKeyIdentifier createSubjectKeyId(PublicKey paramPublicKey)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramPublicKey.getEncoded());
    SubjectPublicKeyInfo localSubjectPublicKeyInfo = new SubjectPublicKeyInfo((ASN1Sequence)new ASN1InputStream(localByteArrayInputStream).readObject());
    return new SubjectKeyIdentifier(localSubjectPublicKeyInfo);
  }
  
  private static BigInteger allocateSerialNumber()
  {
    BigInteger localBigInteger = serialNumber;
    serialNumber = serialNumber.add(BigInteger.ONE);
    return localBigInteger;
  }
  
  public static byte[] streamToByteArray(InputStream paramInputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = paramInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  static
  {
    try
    {
      Security.addProvider(new BouncyCastleProvider());
      rand = new SecureRandom();
      kpg = KeyPairGenerator.getInstance("RSA", "BC");
      kpg.initialize(1024, rand);
      gostKpg = KeyPairGenerator.getInstance("GOST3410", "BC");
      GOST3410ParameterSpec localGOST3410ParameterSpec = new GOST3410ParameterSpec(CryptoProObjectIdentifiers.gostR3410_94_CryptoPro_A.getId());
      gostKpg.initialize(localGOST3410ParameterSpec, new SecureRandom());
      dsaKpg = KeyPairGenerator.getInstance("DSA", "BC");
      DSAParameterSpec localDSAParameterSpec = new DSAParameterSpec(new BigInteger("7434410770759874867539421675728577177024889699586189000788950934679315164676852047058354758883833299702695428196962057871264685291775577130504050839126673"), new BigInteger("1138656671590261728308283492178581223478058193247"), new BigInteger("4182906737723181805517018315469082619513954319976782448649747742951189003482834321192692620856488639629011570381138542789803819092529658402611668375788410"));
      dsaKpg.initialize(localDSAParameterSpec, new SecureRandom());
      ecGostKpg = KeyPairGenerator.getInstance("ECGOST3410", "BC");
      ecGostKpg.initialize(ECGOST3410NamedCurveTable.getParameterSpec("GostR3410-2001-CryptoPro-A"), new SecureRandom());
      ecDsaKpg = KeyPairGenerator.getInstance("ECDSA", "BC");
      ecDsaKpg.initialize(239, new SecureRandom());
      aes192kg = KeyGenerator.getInstance("AES", "BC");
      aes192kg.init(192, rand);
      desede128kg = KeyGenerator.getInstance("DESEDE", "BC");
      desede128kg.init(112, rand);
      desede192kg = KeyGenerator.getInstance("DESEDE", "BC");
      desede192kg.init(168, rand);
      rc240kg = KeyGenerator.getInstance("RC2", "BC");
      rc240kg.init(40, rand);
      rc264kg = KeyGenerator.getInstance("RC2", "BC");
      rc264kg.init(64, rand);
      rc2128kg = KeyGenerator.getInstance("RC2", "BC");
      rc2128kg.init(128, rand);
      aesKg = KeyGenerator.getInstance("AES", "BC");
      seedKg = KeyGenerator.getInstance("SEED", "BC");
      camelliaKg = KeyGenerator.getInstance("Camellia", "BC");
      serialNumber = new BigInteger("1");
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException.toString());
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\CMSTestUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */