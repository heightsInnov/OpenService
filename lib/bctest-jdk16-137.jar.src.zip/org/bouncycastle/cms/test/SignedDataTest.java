package org.bouncycastle.cms.test;

import java.io.ByteArrayInputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.CMSSignedDataParser;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.cms.SignerId;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509CollectionStoreParameters;
import org.bouncycastle.x509.X509Store;

public class SignedDataTest
  extends TestCase
{
  boolean DEBUG = true;
  private static String _origDN;
  private static KeyPair _origKP;
  private static X509Certificate _origCert;
  private static String _signDN;
  private static KeyPair _signKP;
  private static X509Certificate _signCert;
  private static KeyPair _signGostKP;
  private static X509Certificate _signGostCert;
  private static KeyPair _signEcDsaKP;
  private static X509Certificate _signEcDsaCert;
  private static KeyPair _signEcGostKP;
  private static X509Certificate _signEcGostCert;
  private static KeyPair _signDsaKP;
  private static X509Certificate _signDsaCert;
  private static String _reciDN;
  private static KeyPair _reciKP;
  private static X509Certificate _reciCert;
  private static X509CRL _signCrl;
  private static boolean _initialised = false;
  private byte[] disorderedMessage = Base64.decode("SU9fc3RkaW5fdXNlZABfX2xpYmNfc3RhcnRfbWFpbgBnZXRob3N0aWQAX19nbW9uX3M=");
  private byte[] disorderedSet = Base64.decode("MIIYXQYJKoZIhvcNAQcCoIIYTjCCGEoCAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHAaCCFqswggJUMIIBwKADAgECAgMMg6wwCgYGKyQDAwECBQAwbzELMAkGA1UEBhMCREUxPTA7BgNVBAoUNFJlZ3VsaWVydW5nc2JlaMhvcmRlIGbIdXIgVGVsZWtvbW11bmlrYXRpb24gdW5kIFBvc3QxITAMBgcCggYBCgcUEwExMBEGA1UEAxQKNFItQ0EgMTpQTjAiGA8yMDAwMDMyMjA5NDM1MFoYDzIwMDQwMTIxMTYwNDUzWjBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAo1Ui1DQSAxOlBOMIGhMA0GCSqGSIb3DQEBAQUAA4GPADCBiwKBgQCKHkFTJx8GmoqFTxEOxpK9XkC3NZ5dBEKiUv0Ife3QMqeGMoCUnyJxwW0k2/53duHxtv2yHSZpFKjrjvE/uGwdOMqBMTjMzkFg19e9JPv061wyADOucOIaNAgha/zFt9XUyrHF21knKCvDNExv2MYIAagkTKajLMAw0bu1J0FadQIFAMAAAAEwCgYGKyQDAwECBQADgYEAgFauXpoTLh3Z3pT/3bhgrxO/2gKGZopWGSWSJPNwq/U3x2EuctOJurj+y2inTcJjespThflpN+7QnvsUhXU+jL2MtPlObU0GmLvWbi47cBShJ7KElcZAaxgWMBzdRGqTOdtMv+ev2t4igGF/q71xf6J2c3pTLWr6P8s6tzLfOCMwggJDMIIBr6ADAgECAgQAuzyuMAoGBiskAwMBAgUAMG8xCzAJBgNVBAYTAkRFMT0wOwYDVQQKFDRSZWd1bGllcnVuZ3NiZWjIb3JkZSBmyHVyIFRlbGVrb21tdW5pa2F0aW9uIHVuZCBQb3N0MSEwDAYHAoIGAQoHFBMBMTARBgNVBAMUCjVSLUNBIDE6UE4wIhgPMjAwMTA4MjAwODA4MjBaGA8yMDA1MDgyMDA4MDgyMFowSzELMAkGA1UEBhMCREUxEjAQBgNVBAoUCVNpZ250cnVzdDEoMAwGBwKCBgEKBxQTATEwGAYDVQQDFBFDQSBTSUdOVFJVU1QgMTpQTjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAhV12N2WhlR6f+3CXP57GrBM9la5Vnsu2b92zv5MZqQOPeEsYbZqDCFkYg1bSwsDEXsGVQqXdQNAGUaapr/EUVVN+hNZ07GcmC1sPeQECgUkxDYjGi4ihbvzxlahjL4nX+UTzJVBfJwXoIvJ+lMHOSpnOLIuEL3SRhBItvRECxN0CAwEAAaMSMBAwDgYDVR0PAQH/BAQDAgEGMAoGBiskAwMBAgUAA4GBACDc9Pc6X8sK1cerphiVLfFv4kpZb9ev4WPy/C6987Qw1SOTElhZAmxaJQBqmDHWlQ63wj1DEqswk7hGLrvQk/iX6KXIn8e64uit7kx6DHGRKNvNGofPjr1WelGeGW/T2ZJKgmPDjCkfsIKt2c3gwa2pDn4mmCz/DStUIqcPDbqLMIICVTCCAcGgAwIBAgIEAJ16STAKBgYrJAMDAQIFADBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAo1Ui1DQSAxOlBOMCIYDzIwMDEwMjAxMTM0NDI1WhgPMjAwNTAzMjIwODU1NTFaMG8xCzAJBgNVBAYTAkRFMT0wOwYDVQQKFDRSZWd1bGllcnVuZ3NiZWjIb3JkZSBmyHVyIFRlbGVrb21tdW5pa2F0aW9uIHVuZCBQb3N0MSEwDAYHAoIGAQoHFBMBMTARBgNVBAMUCjZSLUNhIDE6UE4wgaEwDQYJKoZIhvcNAQEBBQADgY8AMIGLAoGBAIOiqxUkzVyqnvthihnltsE5m1Xn5TZKeR/2MQPStc5hJ+V4yptEtIx+Fn5rOoqT5VEVWhcE35wdbPvgJyQFn5msmhPQT/6XSGOlrWRoFummXN9lQzAjCj1sgTcmoLCVQ5s5WpCAOXFwVWu16qndz3sPItn3jJ0F3Kh3w79NglvPAgUAwAAAATAKBgYrJAMDAQIFAAOBgQBpSRdnDb6AcNVaXSmGo6+kVPIBhot1LzJOGaPyDNpGXxd7LV4tMBF1U7gr4k1g9BO6YiMWvw9uiTZmn0CfV8+k4fWEuG/nmafRoGIuay2f+ILuT+C0rnp14FgMsEhuVNJJAmb12QV0PZII+UneyhAneZuQQzVUkTcVgYxogxdSOzCCAlUwggHBoAMCAQICBACdekowCgYGKyQDAwECBQAwbzELMAkGA1UEBhMCREUxPTA7BgNVBAoUNFJlZ3VsaWVydW5nc2JlaMhvcmRlIGbIdXIgVGVsZWtvbW11bmlrYXRpb24gdW5kIFBvc3QxITAMBgcCggYBCgcUEwExMBEGA1UEAxQKNlItQ2EgMTpQTjAiGA8yMDAxMDIwMTEzNDcwN1oYDzIwMDUwMzIyMDg1NTUxWjBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAo1Ui1DQSAxOlBOMIGhMA0GCSqGSIb3DQEBAQUAA4GPADCBiwKBgQCKHkFTJx8GmoqFTxEOxpK9XkC3NZ5dBEKiUv0Ife3QMqeGMoCUnyJxwW0k2/53duHxtv2yHSZpFKjrjvE/uGwdOMqBMTjMzkFg19e9JPv061wyADOucOIaNAgha/zFt9XUyrHF21knKCvDNExv2MYIAagkTKajLMAw0bu1J0FadQIFAMAAAAEwCgYGKyQDAwECBQADgYEAV1yTi+2gyB7sUhn4PXmi/tmBxAfe5oBjDW8mgxtfudxKGZ6l/FUPNcrSc5oqBYxKWtLmf3XX87LcblYsch617jtNTkMzhx9eqxiD02ufcrxz2EVt0Akdqiz8mdVeqp3oLcNU/IttpSrcA91CAnoUXtDZYwb/gdQ4FI9l3+qo/0UwggJVMIIBwaADAgECAgQAxIymMAoGBiskAwMBAgUAMG8xCzAJBgNVBAYTAkRFMT0wOwYDVQQKFDRSZWd1bGllcnVuZ3NiZWjIb3JkZSBmyHVyIFRlbGVrb21tdW5pa2F0aW9uIHVuZCBQb3N0MSEwDAYHAoIGAQoHFBMBMTARBgNVBAMUCjZSLUNhIDE6UE4wIhgPMjAwMTEwMTUxMzMxNThaGA8yMDA1MDYwMTA5NTIxN1owbzELMAkGA1UEBhMCREUxPTA7BgNVBAoUNFJlZ3VsaWVydW5nc2JlaMhvcmRlIGbIdXIgVGVsZWtvbW11bmlrYXRpb24gdW5kIFBvc3QxITAMBgcCggYBCgcUEwExMBEGA1UEAxQKN1ItQ0EgMTpQTjCBoTANBgkqhkiG9w0BAQEFAAOBjwAwgYsCgYEAiokD/j6lEP4FexF356OpU5teUpGGfUKjIrFXBHc79G0TUzgVxqMoN1PWnWktQvKo8ETaugxLkP9/zfX3aAQzDW4Zki6x6GDqfy09Agk+RJvhfbbIzRkV4sBBco0n73x7TfG/9NTgVr/96U+I+z/1j30aboM69OkLEhjxAr0/GbsCBQDAAAABMAoGBiskAwMBAgUAA4GBAHWRqRixt+EuqHhRK1kIxKGZL2vZuakYV0R24Gv/0ZR52FE4ECr+I49o8FP1qiGSwnXB0SwjuH2SiGiSJi+iH/MeY85IHwW1P5e+bOMvEOFhZhQXQixOD7totIoFtdyaj1XGYRef0f2cPOjNJorXHGV8wuBk+/j++sxbd/Net3FtMIICVTCCAcGgAwIBAgIEAMSMpzAKBgYrJAMDAQIFADBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAo3Ui1DQSAxOlBOMCIYDzIwMDExMDE1MTMzNDE0WhgPMjAwNTA2MDEwOTUyMTdaMG8xCzAJBgNVBAYTAkRFMT0wOwYDVQQKFDRSZWd1bGllcnVuZ3NiZWjIb3JkZSBmyHVyIFRlbGVrb21tdW5pa2F0aW9uIHVuZCBQb3N0MSEwDAYHAoIGAQoHFBMBMTARBgNVBAMUCjZSLUNhIDE6UE4wgaEwDQYJKoZIhvcNAQEBBQADgY8AMIGLAoGBAIOiqxUkzVyqnvthihnltsE5m1Xn5TZKeR/2MQPStc5hJ+V4yptEtIx+Fn5rOoqT5VEVWhcE35wdbPvgJyQFn5msmhPQT/6XSGOlrWRoFummXN9lQzAjCj1sgTcmoLCVQ5s5WpCAOXFwVWu16qndz3sPItn3jJ0F3Kh3w79NglvPAgUAwAAAATAKBgYrJAMDAQIFAAOBgQBi5W96UVDoNIRkCncqr1LLG9vF9SGBIkvFpLDIIbcvp+CXhlvsdCJl0pt2QEPSDl4cmpOet+CxJTdTuMeBNXxhb7Dvualog69w/+K2JbPhZYxuVFZsZh5BkPn2FnbNu3YbJhE60aIkikr72J4XZsI5DxpZCGh6xyV/YPRdKSljFjCCAlQwggHAoAMCAQICAwyDqzAKBgYrJAMDAQIFADBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAo1Ui1DQSAxOlBOMCIYDzIwMDAwMzIyMDk0MTI3WhgPMjAwNDAxMjExNjA0NTNaMG8xCzAJBgNVBAYTAkRFMT0wOwYDVQQKFDRSZWd1bGllcnVuZ3NiZWjIb3JkZSBmyHVyIFRlbGVrb21tdW5pa2F0aW9uIHVuZCBQb3N0MSEwDAYHAoIGAQoHFBMBMTARBgNVBAMUCjRSLUNBIDE6UE4wgaEwDQYJKoZIhvcNAQEBBQADgY8AMIGLAoGBAI8x26tmrFJanlm100B7KGlRemCD1R93PwdnG7svRyf5ZxOsdGrDszNgxg6ouO8ZHQMT3NC2dH8TvO65Js+8bIyTm51azF6clEg0qeWNMKiiXbBXa+phhTkGbXiLYvACZ6/MTJMJ1lcrjpRF7BXtYeYMcEF6znD4pxOqrtbf9z5hAgUAwAAAATAKBgYrJAMDAQIFAAOBgQB99BjSKlGPbMLQAgXlvA9jUsDNhpnVm3a1YkfxSqS/dbQlYkbOKvCxkPGA9NBxisBM8l1zFynVjJoy++aysRmcnLY/sHaz23BF2iU7WERy18H3lMBfYB6sXkfYiZtvQZcWaO48m73ZBySuiV3iXpb2wgs/Cs20iqroAWxwq/W/9jCCAlMwggG/oAMCAQICBDsFZ9UwCgYGKyQDAwECBQAwbzELMAkGA1UEBhMCREUxITAMBgcCggYBCgcUEwExMBEGA1UEAxQKNFItQ0EgMTpQTjE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDAiGA8xOTk5MDEyMTE3MzUzNFoYDzIwMDQwMTIxMTYwMDAyWjBvMQswCQYDVQQGEwJERTE9MDsGA1UEChQ0UmVndWxpZXJ1bmdzYmVoyG9yZGUgZsh1ciBUZWxla29tbXVuaWthdGlvbiB1bmQgUG9zdDEhMAwGBwKCBgEKBxQTATEwEQYDVQQDFAozUi1DQSAxOlBOMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgI4B557mbKQg/AqWBXNJhaT/6lwV93HUl4U8u35udLq2+u9phns1WZkdM3gDfEpL002PeLfHr1ID/96dDYf04lAXQfombilsof1C1k32xOvxjlcrDOuPEMxz9/HDAQZA5MjmmYHAIulGI8Qg4Tc7ERRtg/hd0QX0/zoOeXoDSEOBAgTAAAABMAoGBiskAwMBAgUAA4GBAIyzwfT3keHI/n2PLrarRJv96mCohmDZNpUQdZTVjGu5VQjVJwk3hpagU0o/t/FkdzAjOdfEw8Ql3WXhfIbNLv1YafMm2eWSdeYbLcbB5yJ1od+SYyf9+tm7cwfDAcr22jNRBqx8wkWKtKDjWKkevaSdy99sAI8jebHtWz7jzydKMIID9TCCA16gAwIBAgICbMcwDQYJKoZIhvcNAQEFBQAwSzELMAkGA1UEBhMCREUxEjAQBgNVBAoUCVNpZ250cnVzdDEoMAwGBwKCBgEKBxQTATEwGAYDVQQDFBFDQSBTSUdOVFJVU1QgMTpQTjAeFw0wNDA3MzAxMzAyNDZaFw0wNzA3MzAxMzAyNDZaMDwxETAPBgNVBAMMCFlhY29tOlBOMQ4wDAYDVQRBDAVZYWNvbTELMAkGA1UEBhMCREUxCjAIBgNVBAUTATEwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAIWzLlYLQApocXIppgCCpkkOUVLgcLYKeOd6/bXAnI2dTHQqT2bv7qzfUnYvOqiNgYdF13pOYtKgXwXMTNFL4ZOI6GoBdNs9TQiZ7KEWnqnr2945HYx7UpgTBclbOK/wGHuCdcwOx7juZs1ZQPFG0Lv8RoiV9s6HP7POqh1sO0P/AgMBAAGjggH1MIIB8TCBnAYDVR0jBIGUMIGRgBQcZzNghfnXoXRm8h1+VITC5caNRqFzpHEwbzELMAkGA1UEBhMCREUxPTA7BgNVBAoUNFJlZ3VsaWVydW5nc2JlaMhvcmRlIGbIdXIgVGVsZWtvbW11bmlrYXRpb24gdW5kIFBvc3QxITAMBgcCggYBCgcUEwExMBEGA1UEAxQKNVItQ0EgMTpQToIEALs8rjAdBgNVHQ4EFgQU2e5KAzkVuKaM9I5heXkzbcAIuR8wDgYDVR0PAQH/BAQDAgZAMBIGA1UdIAQLMAkwBwYFKyQIAQEwfwYDVR0fBHgwdjB0oCygKoYobGRhcDovL2Rpci5zaWdudHJ1c3QuZGUvbz1TaWdudHJ1c3QsYz1kZaJEpEIwQDEdMBsGA1UEAxMUQ1JMU2lnblNpZ250cnVzdDE6UE4xEjAQBgNVBAoTCVNpZ250cnVzdDELMAkGA1UEBhMCREUwYgYIKwYBBQUHAQEEVjBUMFIGCCsGAQUFBzABhkZodHRwOi8vZGlyLnNpZ250cnVzdC5kZS9TaWdudHJ1c3QvT0NTUC9zZXJ2bGV0L2h0dHBHYXRld2F5LlBvc3RIYW5kbGVyMBgGCCsGAQUFBwEDBAwwCjAIBgYEAI5GAQEwDgYHAoIGAQoMAAQDAQH/MA0GCSqGSIb3DQEBBQUAA4GBAHn1m3GcoyD5GBkKUY/OdtD6Sj38LYqYCF+qDbJR6pqUBjY2wsvXepUppEler+stH8mwpDDSJXrJyuzf7xroDs4dkLl+Rs2x+2tgBjU+ABkBDMsym2WpwgA8LCdymmXmjdv9tULxY+ec2pjSEzql6nEZNEfrU8ntZCSCavgqW4TtMYIBejCCAXYCAQEwUTBLMQswCQYDVQQGEwJERTESMBAGA1UEChQJU2lnbnRydXN0MSgwDAYHAoIGAQoHFBMBMTAYBgNVBAMUEUNBIFNJR05UUlVTVCAxOlBOAgJsxzAJBgUrDgMCGgUAoIGAMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwIwYJKoZIhvcNAQkEMRYEFIYfhPoyfGzkLWWSSLjaHb4HQmaKMBwGCSqGSIb3DQEJBTEPFw0wNTAzMjQwNzM4MzVaMCEGBSskCAYFMRgWFi92YXIvZmlsZXMvdG1wXzEvdGVzdDEwDQYJKoZIhvcNAQEFBQAEgYA2IvA8lhVzVD5e/itUxbFboKxeKnqJ5n/KuO/uBCl1N14+7Z2vtw1sfkIG+bJdp3OY2CmnmrQcwsN99Vjal4cXVj8t+DJzFG9tK9dSLvD3q9zT/GQ0kJXfimLVwCa4NaSfQsu4xtG0Rav6bCcnzabAkKuNNvKtH8amSRzk870DBg==");
  
  public SignedDataTest(String paramString)
  {
    super(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(SignedDataTest.class);
  }
  
  public static Test suite()
    throws Exception
  {
    init();
    return new CMSTestSetup(new TestSuite(SignedDataTest.class));
  }
  
  private static void init()
    throws Exception
  {
    if (!_initialised)
    {
      _initialised = true;
      _origDN = "O=Bouncy Castle, C=AU";
      _origKP = CMSTestUtil.makeKeyPair();
      _origCert = CMSTestUtil.makeCertificate(_origKP, _origDN, _origKP, _origDN);
      _signDN = "CN=Bob, OU=Sales, O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _signCert = CMSTestUtil.makeCertificate(_signKP, _signDN, _origKP, _origDN);
      _signGostKP = CMSTestUtil.makeGostKeyPair();
      _signGostCert = CMSTestUtil.makeCertificate(_signGostKP, _signDN, _origKP, _origDN);
      _signDsaKP = CMSTestUtil.makeDsaKeyPair();
      _signDsaCert = CMSTestUtil.makeCertificate(_signDsaKP, _signDN, _origKP, _origDN);
      _signEcDsaKP = CMSTestUtil.makeEcDsaKeyPair();
      _signEcDsaCert = CMSTestUtil.makeCertificate(_signEcDsaKP, _signDN, _origKP, _origDN);
      _signEcGostKP = CMSTestUtil.makeEcGostKeyPair();
      _signEcGostCert = CMSTestUtil.makeCertificate(_signEcGostKP, _signDN, _origKP, _origDN);
      _reciDN = "CN=Doug, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP = CMSTestUtil.makeKeyPair();
      _reciCert = CMSTestUtil.makeCertificate(_reciKP, _reciDN, _signKP, _signDN);
      _signCrl = CMSTestUtil.makeCrl(_signKP);
    }
  }
  
  private void verifySignatures(CMSSignedData paramCMSSignedData, byte[] paramArrayOfByte)
    throws Exception
  {
    CertStore localCertStore = paramCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = paramCMSSignedData.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      localObject = (SignerInformation)localIterator1.next();
      localCollection2 = localCertStore.getCertificates(((SignerInformation)localObject).getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, ((SignerInformation)localObject).verify(localX509Certificate, "BC"));
      if (paramArrayOfByte != null) {
        assertTrue(MessageDigest.isEqual(paramArrayOfByte, ((SignerInformation)localObject).getContentDigest()));
      }
    }
    Object localObject = localCertStore.getCertificates(null);
    Collection localCollection2 = localCertStore.getCRLs(null);
    assertEquals(((Collection)localObject).size(), paramCMSSignedData.getCertificates("Collection", "BC").getMatches(null).size());
    assertEquals(localCollection2.size(), paramCMSSignedData.getCRLs("Collection", "BC").getMatches(null).size());
  }
  
  private void verifySignatures(CMSSignedData paramCMSSignedData)
    throws Exception
  {
    verifySignatures(paramCMSSignedData, null);
  }
  
  public void testSHA1AndMD5WithRSAEncapsulatedRepeated()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_MD5);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = localCMSSignedData.getSignerInfos();
    assertEquals(2, localSignerInformationStore.size());
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    SignerId localSignerId = null;
    SignerInformation localSignerInformation;
    Collection localCollection2;
    Iterator localIterator2;
    X509Certificate localX509Certificate;
    while (localIterator1.hasNext())
    {
      localSignerInformation = (SignerInformation)localIterator1.next();
      localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      localIterator2 = localCollection2.iterator();
      localX509Certificate = (X509Certificate)localIterator2.next();
      localSignerId = localSignerInformation.getSID();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
      byte[] arrayOfByte = (byte[])localCMSSignedDataGenerator.getGeneratedDigests().get(localSignerInformation.getDigestAlgOID());
      AttributeTable localAttributeTable = localSignerInformation.getSignedAttributes();
      Attribute localAttribute = localAttributeTable.get(CMSAttributes.messageDigest);
      assertTrue(MessageDigest.isEqual(arrayOfByte, ((ASN1OctetString)localAttribute.getAttrValues().getObjectAt(0)).getOctets()));
    }
    localCollection1 = localSignerInformationStore.getSigners(localSignerId);
    assertEquals(2, localCollection1.size());
    localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigners(localCMSSignedData.getSignerInfos());
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCMSSignedData.getCertificatesAndCRLs("Collection", "BC"));
    localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    localSignerInformationStore = localCMSSignedData.getSignerInfos();
    localCollection1 = localSignerInformationStore.getSigners();
    localIterator1 = localCollection1.iterator();
    assertEquals(2, localCollection1.size());
    while (localIterator1.hasNext())
    {
      localSignerInformation = (SignerInformation)localIterator1.next();
      localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      localIterator2 = localCollection2.iterator();
      localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
    checkSignerStoreReplacement(localCMSSignedData, localSignerInformationStore);
  }
  
  public void testSHA1WithRSANoAttributes()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello world!".getBytes());
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(CMSSignedDataGenerator.DATA, localCMSProcessableByteArray, false, "BC", false);
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    verifySignatures(localCMSSignedData, localMessageDigest.digest("Hello world!".getBytes()));
  }
  
  public void testSHA1WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_SHA1);
  }
  
  public void testSHA224WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_SHA224);
  }
  
  public void testSHA256WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_SHA256);
  }
  
  public void testRIPEMD128WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_RIPEMD128);
  }
  
  public void testRIPEMD160WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_RIPEMD160);
  }
  
  public void testRIPEMD256WithRSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signKP, _signCert, CMSSignedDataGenerator.DIGEST_RIPEMD256);
  }
  
  public void testECDSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcDsaKP, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA1);
  }
  
  public void testECDSASHA224Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcDsaKP, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA224);
  }
  
  public void testECDSASHA256Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcDsaKP, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA256);
  }
  
  public void testECDSASHA384Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcDsaKP, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA384);
  }
  
  public void testECDSASHA512Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcDsaKP, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA512);
  }
  
  public void testECDSASHA512EncapsulatedWithKeyFactoryAsEC()
    throws Exception
  {
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(_signEcDsaKP.getPublic().getEncoded());
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(_signEcDsaKP.getPrivate().getEncoded());
    KeyFactory localKeyFactory = KeyFactory.getInstance("EC", "BC");
    KeyPair localKeyPair = new KeyPair(localKeyFactory.generatePublic(localX509EncodedKeySpec), localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec));
    encapsulatedTest(localKeyPair, _signEcDsaCert, CMSSignedDataGenerator.DIGEST_SHA512);
  }
  
  public void testDSAEncapsulated()
    throws Exception
  {
    encapsulatedTest(_signDsaKP, _signDsaCert, CMSSignedDataGenerator.DIGEST_SHA1);
  }
  
  public void testGOST3411WithGOST3410Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signGostKP, _signGostCert, CMSSignedDataGenerator.DIGEST_GOST3411);
  }
  
  public void testGOST3411WithECGOST3410Encapsulated()
    throws Exception
  {
    encapsulatedTest(_signEcGostKP, _signEcGostCert, CMSSignedDataGenerator.DIGEST_GOST3411);
  }
  
  private void encapsulatedTest(KeyPair paramKeyPair, X509Certificate paramX509Certificate, String paramString)
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(paramX509Certificate);
    localArrayList.add(_origCert);
    localArrayList.add(_signCrl);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(paramKeyPair.getPrivate(), paramX509Certificate, paramString);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = localCMSSignedData.getSignerInfos();
    Collection localCollection = localSignerInformationStore.getSigners();
    Iterator localIterator = localCollection.iterator();
    Object localObject2;
    Object localObject3;
    Object localObject4;
    while (localIterator.hasNext())
    {
      localObject1 = (SignerInformation)localIterator.next();
      localObject2 = localCertStore.getCertificates(((SignerInformation)localObject1).getSID());
      localObject3 = ((Collection)localObject2).iterator();
      localObject4 = (X509Certificate)((Iterator)localObject3).next();
      assertEquals(true, ((SignerInformation)localObject1).verify((X509Certificate)localObject4, "BC"));
    }
    Object localObject1 = localCertStore.getCRLs(null);
    assertEquals(1, ((Collection)localObject1).size());
    assertTrue(((Collection)localObject1).contains(_signCrl));
    localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigners(localCMSSignedData.getSignerInfos());
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCMSSignedData.getCertificatesAndCRLs("Collection", "BC"));
    localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    localSignerInformationStore = localCMSSignedData.getSignerInfos();
    localCollection = localSignerInformationStore.getSigners();
    localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      localObject2 = (SignerInformation)localIterator.next();
      localObject3 = localCertStore.getCertificates(((SignerInformation)localObject2).getSID());
      localObject4 = ((Collection)localObject3).iterator();
      X509Certificate localX509Certificate = (X509Certificate)((Iterator)localObject4).next();
      assertEquals(true, ((SignerInformation)localObject2).verify(localX509Certificate, "BC"));
    }
    checkSignerStoreReplacement(localCMSSignedData, localSignerInformationStore);
  }
  
  private void checkSignerStoreReplacement(CMSSignedData paramCMSSignedData, SignerInformationStore paramSignerInformationStore)
    throws Exception
  {
    CMSSignedData localCMSSignedData = CMSSignedData.replaceSigners(paramCMSSignedData, paramSignerInformationStore);
    CertStore localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    paramSignerInformationStore = localCMSSignedData.getSignerInfos();
    Collection localCollection1 = paramSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
  
  public void testUnsortedAttributes()
    throws Exception
  {
    CMSSignedData localCMSSignedData = new CMSSignedData(new CMSProcessableByteArray(this.disorderedMessage), this.disorderedSet);
    CertStore localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = localCMSSignedData.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
  
  public void testNullContentWithSigner()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(null, false, "BC");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    verifySignatures(localCMSSignedData);
  }
  
  public void testWithAttributeCertificate()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_signDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    X509AttributeCertificate localX509AttributeCertificate = CMSTestUtil.getAttributeCertificate();
    X509Store localX509Store = X509Store.getInstance("AttributeCertificate/Collection", new X509CollectionStoreParameters(Collections.singleton(localX509AttributeCertificate)), "BC");
    localCMSSignedDataGenerator.addAttributeCertificates(localX509Store);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, "BC");
    assertEquals(4, localCMSSignedData.getVersion());
    localX509Store = localCMSSignedData.getAttributeCertificates("Collection", "BC");
    Collection localCollection = localX509Store.getMatches(null);
    assertEquals(1, localCollection.size());
    assertTrue(localCollection.contains(localX509AttributeCertificate));
    localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    localCMSSignedData = CMSSignedData.replaceCertificatesAndCRLs(localCMSSignedData, localCertStore);
    verifySignatures(localCMSSignedData);
  }
  
  public void testCertStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_signDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, "BC");
    localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    localCMSSignedData = CMSSignedData.replaceCertificatesAndCRLs(localCMSSignedData, localCertStore);
    verifySignatures(localCMSSignedData);
  }
  
  public void testEncapsulatedCertStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_signDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    localCMSSignedData = CMSSignedData.replaceCertificatesAndCRLs(localCMSSignedData, localCertStore);
    verifySignatures(localCMSSignedData);
  }
  
  public void testCertOrdering1()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localArrayList.add(_signDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    Iterator localIterator = localCertStore.getCertificates(null).iterator();
    assertEquals(_origCert, localIterator.next());
    assertEquals(_signCert, localIterator.next());
    assertEquals(_signDsaCert, localIterator.next());
  }
  
  public void testCertOrdering2()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_signCert);
    localArrayList.add(_signDsaCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "BC");
    Iterator localIterator = localCertStore.getCertificates(null).iterator();
    assertEquals(_signCert, localIterator.next());
    assertEquals(_signDsaCert, localIterator.next());
    assertEquals(_origCert, localIterator.next());
  }
  
  public void testSignerStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData1 = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA224);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData2 = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "BC");
    CMSSignedData localCMSSignedData3 = CMSSignedData.replaceSigners(localCMSSignedData1, localCMSSignedData2.getSignerInfos());
    SignerInformation localSignerInformation = (SignerInformation)localCMSSignedData3.getSignerInfos().getSigners().iterator().next();
    assertEquals(CMSSignedDataGenerator.DIGEST_SHA224, localSignerInformation.getDigestAlgOID());
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localCMSSignedData3.getEncoded());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  private void verifySignatures(CMSSignedDataParser paramCMSSignedDataParser)
    throws Exception
  {
    CertStore localCertStore = paramCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = paramCMSSignedDataParser.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\SignedDataTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */