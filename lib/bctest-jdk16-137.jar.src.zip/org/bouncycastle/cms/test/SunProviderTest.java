package org.bouncycastle.cms.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.CMSSignedDataParser;
import org.bouncycastle.cms.CMSSignedDataStreamGenerator;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.x509.X509V3CertificateGenerator;

public class SunProviderTest
  extends TestCase
{
  static KeyPair keyPair;
  static X509Certificate keyCert;
  private static final String TEST_MESSAGE = "Hello World!";
  
  public void testSHA1WithRSAEncapsulated()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(keyCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "SUN");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(keyPair.getPrivate(), keyCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(localCMSProcessableByteArray, true, "SunRsaSign");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localCMSSignedData.getEncoded());
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayInputStream);
    localCMSSignedData = new CMSSignedData(ContentInfo.getInstance(localASN1InputStream.readObject()));
    localCertStore = localCMSSignedData.getCertificatesAndCRLs("Collection", "SUN");
    SignerInformationStore localSignerInformationStore = localCMSSignedData.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "SunRsaSign"));
    }
  }
  
  public void testSHA1WithRSAStream()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(keyCert);
    CertStore localCertStore1 = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "SUN");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(keyPair.getPrivate(), keyCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "SunRsaSign");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore1);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream("Hello World!".getBytes())), localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "SUN");
    byte[] arrayOfByte = localMessageDigest.digest("Hello World!".getBytes());
    CertStore localCertStore2 = localCMSSignedDataParser.getCertificatesAndCRLs("Collection", "SUN");
    SignerInformationStore localSignerInformationStore = localCMSSignedDataParser.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore2.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "SunRsaSign"));
      if (arrayOfByte != null) {
        assertTrue(MessageDigest.isEqual(arrayOfByte, localSignerInformation.getContentDigest()));
      }
    }
  }
  
  public void testKeyTransDES()
    throws Exception
  {
    testKeyTrans(CMSEnvelopedDataGenerator.DES_EDE3_CBC);
  }
  
  public void testKeyTransAES128()
    throws Exception
  {
    testKeyTrans(CMSEnvelopedDataGenerator.AES128_CBC);
  }
  
  public void testKeyTransAES192()
    throws Exception
  {
    testKeyTrans(CMSEnvelopedDataGenerator.AES192_CBC);
  }
  
  public void testKeyTransAES256()
    throws Exception
  {
    testKeyTrans(CMSEnvelopedDataGenerator.AES256_CBC);
  }
  
  private void testKeyTrans(String paramString)
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(keyCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), paramString, "SunJCE");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), paramString);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    assertEquals(1, localCollection.size());
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(keyPair.getPrivate(), "SunJCE");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
  }
  
  private static KeyPair generateKeyPair()
    throws NoSuchProviderException, NoSuchAlgorithmException
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "SunRsaSign");
    localKeyPairGenerator.initialize(512, new SecureRandom());
    return localKeyPairGenerator.generateKeyPair();
  }
  
  private static X509Certificate makeCertificate(KeyPair paramKeyPair1, String paramString1, KeyPair paramKeyPair2, String paramString2)
    throws GeneralSecurityException, IOException
  {
    PublicKey localPublicKey1 = paramKeyPair1.getPublic();
    PrivateKey localPrivateKey = paramKeyPair2.getPrivate();
    PublicKey localPublicKey2 = paramKeyPair2.getPublic();
    X509V3CertificateGenerator localX509V3CertificateGenerator = new X509V3CertificateGenerator();
    localX509V3CertificateGenerator.reset();
    localX509V3CertificateGenerator.setSerialNumber(BigInteger.valueOf(1L));
    localX509V3CertificateGenerator.setIssuerDN(new X509Name(paramString2));
    localX509V3CertificateGenerator.setNotBefore(new Date(System.currentTimeMillis()));
    localX509V3CertificateGenerator.setNotAfter(new Date(System.currentTimeMillis() + 8640000000L));
    localX509V3CertificateGenerator.setSubjectDN(new X509Name(paramString1));
    localX509V3CertificateGenerator.setPublicKey(localPublicKey1);
    localX509V3CertificateGenerator.setSignatureAlgorithm("SHA1WithRSA");
    X509Certificate localX509Certificate = localX509V3CertificateGenerator.generate(localPrivateKey, "SunRsaSign");
    localX509Certificate.checkValidity(new Date());
    localX509Certificate.verify(localPublicKey2);
    return localX509Certificate;
  }
  
  public static Test suite()
    throws Exception
  {
    return new TestSuite(SunProviderTest.class);
  }
  
  static
  {
    try
    {
      keyPair = generateKeyPair();
      String str = "O=Bouncy Castle, C=AU";
      keyCert = makeCertificate(keyPair, str, keyPair, str);
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\SunProviderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */