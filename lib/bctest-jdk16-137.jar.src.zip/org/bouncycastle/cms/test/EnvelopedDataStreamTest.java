package org.bouncycastle.cms.test;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import javax.crypto.SecretKey;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSEnvelopedDataParser;
import org.bouncycastle.cms.CMSEnvelopedDataStreamGenerator;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.cms.RecipientId;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;

public class EnvelopedDataStreamTest
  extends TestCase
{
  private static final int BUFFER_SIZE = 4000;
  private static String _signDN;
  private static KeyPair _signKP;
  private static X509Certificate _signCert;
  private static String _origDN;
  private static KeyPair _origKP;
  private static X509Certificate _origCert;
  private static String _reciDN;
  private static KeyPair _reciKP;
  private static X509Certificate _reciCert;
  private static KeyPair _origEcKP;
  private static KeyPair _reciEcKP;
  private static X509Certificate _reciEcCert;
  private static boolean _initialised = false;
  
  private static void init()
    throws Exception
  {
    if (!_initialised)
    {
      _initialised = true;
      _signDN = "O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _signCert = CMSTestUtil.makeCertificate(_signKP, _signDN, _signKP, _signDN);
      _origDN = "CN=Bob, OU=Sales, O=Bouncy Castle, C=AU";
      _origKP = CMSTestUtil.makeKeyPair();
      _origCert = CMSTestUtil.makeCertificate(_origKP, _origDN, _signKP, _signDN);
      _reciDN = "CN=Doug, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP = CMSTestUtil.makeKeyPair();
      _reciCert = CMSTestUtil.makeCertificate(_reciKP, _reciDN, _signKP, _signDN);
      _origEcKP = CMSTestUtil.makeEcDsaKeyPair();
      _reciEcKP = CMSTestUtil.makeEcDsaKeyPair();
      _reciEcCert = CMSTestUtil.makeCertificate(_reciEcKP, _reciDN, _signKP, _signDN);
    }
  }
  
  public void setUp()
    throws Exception
  {}
  
  public void testWorkingData()
    throws Exception
  {
    byte[] arrayOfByte1 = Base64.decode("MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKrAz/SQKrcQnj9IxHIfKDbuXsMqUpI06s2gps6fp7RDNvtUDDMOciWGFhD45YSy8GO0mPx3Nkc7vKBqX4TLcqLUz7kXGOHGOwiPZoNF+9jBMPNROe/B0My0PkWg9tuq+nxN64oD47+JvDwrpNOS5wsYavXeAW8Anv9ZzHLU7KwZAgMBAAECgYA/fqdVt+5KWKGfwr1Z+oAHvSf7xtchiw/tGtosZ24DOCNP3fcTXUHQ9kVqVkNyzt9ZFCT3bJUAdBQ2SpfuV4DusVeQZVzcROKeA09nPkxBpTefWbSDQGhb+eZq9L8JDRSWHyYqs+MBoUpLw7GKtZiJkZyY6CsYkAnQ+uYVWq/TIQJBAP5zafO4HUV/w4KDVJi+ua+GYF1Sg1t/dYL1kXO9GP1p75YAmtm6LdnOCas7wj70/G1YlPGkOP0VGFzeG5KAmAUCQQCryvKU9nwWA+kypcQT9Yr1P4vGS0APYoBThnZq7jEPc5CmZI82yseSxSeea0+8KQbZ5mvh1p3qImDLEH/iNSQFAkAghS+tboKPN10NeSt+uiGRRWNbiggv0YJ7Uldcq3ZeLQPp7/naiekCRUsHD4Qr97OrZf7jQ1HlRqTueZScjMLhAkBNUMZCQnhwFAyEzdPkQ7LpU1MdyEopYmRssuxijZao5JLqQAGwYCzXokGFa7hz72b09F4DQurJL/WuDlvvu4jdAkEAxwT9lylvfSfEQw4/qQgZMFB26gqB6Gqs1pHIZCzdliKx5BO3VDeUGfXMI8yOkbXoWbYx5xPid/+N8R//+sxLBw==");
    byte[] arrayOfByte2 = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQAxgcQwgcECAQAwKjAlMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVQIBHjANBgkqhkiG9w0BAQEFAASBgDmnaDZ0vDJNlaUSYyEXsgbaUH+itNTjCOgv77QTX2ImXj+kTctM19PQF2I10/NL0fjakvCgBTHKmk13a7jqB6cX3bysenHNrglHsgNGgeXQ7ggAq5fV/JQQT7rSxEtuwpbuHQnoVUZahOHVKy/a0uLr9iIh1A3y+yZTZaG505ZJMIAGCSqGSIb3DQEHATAdBglghkgBZQMEAQIEENmkYNbDXiZxJWtq82qIRZKggAQgkOGr1JcTsADStez1eY4+rO4DtyBIyUYQ3pilnbirfPkAAAAAAAAAAAAA");
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(arrayOfByte2);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte1);
    KeyFactory localKeyFactory = KeyFactory.getInstance("RSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    byte[] arrayOfByte3 = Hex.decode("57616c6c6157616c6c6157617368696e67746f6e");
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(localPrivateKey, "BC");
      assertEquals(true, Arrays.equals(arrayOfByte3, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    }
  }
  
  private void verifyData(ByteArrayOutputStream paramByteArrayOutputStream, String paramString, byte[] paramArrayOfByte)
    throws Exception
  {
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(paramByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), paramString);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(paramArrayOfByte, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    }
  }
  
  public void testKeyTransAES128BufferedStream()
    throws Exception
  {
    byte[] arrayOfByte = new byte['ߐ'];
    for (int i = 0; i != 2000; i++) {
      arrayOfByte[i] = ((byte)(i & 0xFF));
    }
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    for (int j = 0; j != 2000; j++) {
      localOutputStream.write(arrayOfByte[j]);
    }
    localOutputStream.close();
    verifyData(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, arrayOfByte);
    j = localByteArrayOutputStream.toByteArray().length;
    localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(localOutputStream, 300);
    for (int k = 0; k != 2000; k++) {
      localBufferedOutputStream.write(arrayOfByte[k]);
    }
    localBufferedOutputStream.close();
    verifyData(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, arrayOfByte);
    assertTrue(localByteArrayOutputStream.toByteArray().length < j);
  }
  
  public void testKeyTransAES128Buffered()
    throws Exception
  {
    byte[] arrayOfByte = new byte['ߐ'];
    for (int i = 0; i != 2000; i++) {
      arrayOfByte[i] = ((byte)(i & 0xFF));
    }
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    for (int j = 0; j != 2000; j++) {
      localOutputStream.write(arrayOfByte[j]);
    }
    localOutputStream.close();
    verifyData(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, arrayOfByte);
    j = localByteArrayOutputStream.toByteArray().length;
    localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.setBufferSize(300);
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    for (int k = 0; k != 2000; k++) {
      localOutputStream.write(arrayOfByte[k]);
    }
    localOutputStream.close();
    verifyData(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, arrayOfByte);
    assertTrue(localByteArrayOutputStream.toByteArray().length < j);
  }
  
  public void testKeyTransAES128Der()
    throws Exception
  {
    byte[] arrayOfByte = new byte['ߐ'];
    for (int i = 0; i != 2000; i++) {
      arrayOfByte[i] = ((byte)(i & 0xFF));
    }
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    for (int j = 0; j != 2000; j++) {
      localOutputStream.write(arrayOfByte[j]);
    }
    localOutputStream.close();
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localByteArrayOutputStream.toByteArray());
    localByteArrayOutputStream.reset();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    localDEROutputStream.writeObject(localASN1InputStream.readObject());
    verifyData(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, arrayOfByte);
  }
  
  public void testKeyTransAES128Throughput()
    throws Exception
  {
    byte[] arrayOfByte1 = new byte[40001];
    for (int i = 0; i != arrayOfByte1.length; i++) {
      arrayOfByte1[i] = ((byte)(i & 0xFF));
    }
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.setBufferSize(4000);
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream1, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    for (int j = 0; j != arrayOfByte1.length; j++) {
      localOutputStream.write(arrayOfByte1[j]);
    }
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream1.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(_reciKP.getPrivate(), "BC");
      InputStream localInputStream = localCMSTypedStream.getContentStream();
      ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
      byte[] arrayOfByte2 = new byte['ྠ'];
      for (int m = 0; (m != 10) && ((k = localInputStream.read(arrayOfByte2)) > 0); m++)
      {
        assertEquals(arrayOfByte2.length, k);
        localByteArrayOutputStream2.write(arrayOfByte2);
      }
      int k = localInputStream.read(arrayOfByte2);
      localByteArrayOutputStream2.write(arrayOfByte2, 0, k);
      assertEquals(true, Arrays.equals(arrayOfByte1, localByteArrayOutputStream2.toByteArray()));
    }
    else
    {
      fail("recipient not found.");
    }
  }
  
  public void testKeyTransAES128()
    throws Exception
  {
    byte[] arrayOfByte = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    }
    localCMSEnvelopedDataParser.close();
  }
  
  public void testKeyTransCAST5SunJCE()
    throws Exception
  {
    if (Security.getProvider("SunJCE") == null) {
      return;
    }
    String str = System.getProperty("java.version");
    if ((str.startsWith("1.4")) || (str.startsWith("1.3"))) {
      return;
    }
    byte[] arrayOfByte = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyTransRecipient(_reciCert);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, "1.2.840.113533.7.66.10", "SunJCE");
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), "1.2.840.113533.7.66.10");
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(_reciKP.getPrivate(), "SunJCE");
      assertEquals(true, Arrays.equals(arrayOfByte, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    }
    localCMSEnvelopedDataParser.close();
  }
  
  public void testAESKEK()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    SecretKey localSecretKey = CMSTestUtil.makeAES192Key();
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    byte[] arrayOfByte2 = { 1, 2, 3, 4, 5 };
    localCMSEnvelopedDataStreamGenerator.addKEKRecipient(localSecretKey, arrayOfByte2);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.DES_EDE3_CBC, "BC");
    localOutputStream.write(arrayOfByte1);
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.DES_EDE3_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), "2.16.840.1.101.3.4.1.25");
      CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(localSecretKey, "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    }
    localCMSEnvelopedDataParser.close();
  }
  
  public void testTwoAESKEK()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    SecretKey localSecretKey1 = CMSTestUtil.makeAES192Key();
    SecretKey localSecretKey2 = CMSTestUtil.makeAES192Key();
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    byte[] arrayOfByte2 = { 1, 2, 3, 4, 5 };
    byte[] arrayOfByte3 = { 5, 4, 3, 2, 1 };
    localCMSEnvelopedDataStreamGenerator.addKEKRecipient(localSecretKey1, arrayOfByte2);
    localCMSEnvelopedDataStreamGenerator.addKEKRecipient(localSecretKey2, arrayOfByte3);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.DES_EDE3_CBC, "BC");
    localOutputStream.write(arrayOfByte1);
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.DES_EDE3_CBC);
    RecipientId localRecipientId = new RecipientId();
    localRecipientId.setKeyIdentifier(arrayOfByte3);
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), "2.16.840.1.101.3.4.1.25");
    CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(localSecretKey2, "BC");
    assertEquals(true, Arrays.equals(arrayOfByte1, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    localCMSEnvelopedDataParser.close();
  }
  
  public void testECKeyAgree()
    throws Exception
  {
    byte[] arrayOfByte = Hex.decode("504b492d4320434d5320456e76656c6f706564446174612053616d706c65");
    CMSEnvelopedDataStreamGenerator localCMSEnvelopedDataStreamGenerator = new CMSEnvelopedDataStreamGenerator();
    localCMSEnvelopedDataStreamGenerator.addKeyAgreementRecipient(CMSEnvelopedDataGenerator.ECDH_SHA1KDF, _origEcKP.getPrivate(), _origEcKP.getPublic(), _reciEcCert, CMSEnvelopedDataGenerator.AES128_WRAP, "BC");
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSEnvelopedDataStreamGenerator.open(localByteArrayOutputStream, CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(localByteArrayOutputStream.toByteArray());
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(localCMSEnvelopedDataParser.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    RecipientId localRecipientId = new RecipientId();
    localRecipientId.setIssuer(PrincipalUtil.getIssuerX509Principal(_reciEcCert).getEncoded());
    localRecipientId.setSerialNumber(_reciEcCert.getSerialNumber());
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    CMSTypedStream localCMSTypedStream = localRecipientInformation.getContentStream(_reciEcKP.getPrivate(), "BC");
    assertEquals(true, Arrays.equals(arrayOfByte, CMSTestUtil.streamToByteArray(localCMSTypedStream.getContentStream())));
    localCMSEnvelopedDataParser.close();
  }
  
  public void testOriginatorInfo()
    throws Exception
  {
    CMSEnvelopedDataParser localCMSEnvelopedDataParser = new CMSEnvelopedDataParser(CMSSampleMessages.originatorMessage);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedDataParser.getRecipientInfos();
    assertEquals(CMSEnvelopedDataGenerator.DES_EDE3_CBC, localCMSEnvelopedDataParser.getEncryptionAlgOID());
  }
  
  public static Test suite()
    throws Exception
  {
    return new CMSTestSetup(new TestSuite(EnvelopedDataStreamTest.class));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\EnvelopedDataStreamTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */