package org.bouncycastle.cms.test;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.cms.CMSAttributeTableGenerator;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.CMSSignedDataParser;
import org.bouncycastle.cms.CMSSignedDataStreamGenerator;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.cms.DefaultSignedAttributeTableGenerator;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509CollectionStoreParameters;
import org.bouncycastle.x509.X509Store;

public class SignedDataStreamTest
  extends TestCase
{
  private static final String TEST_MESSAGE = "Hello World!";
  private static String _signDN;
  private static KeyPair _signKP;
  private static X509Certificate _signCert;
  private static String _origDN;
  private static KeyPair _origKP;
  private static X509Certificate _origCert;
  private static String _reciDN;
  private static KeyPair _reciKP;
  private static X509Certificate _reciCert;
  private static KeyPair _origDsaKP;
  private static X509Certificate _origDsaCert;
  private static X509CRL _signCrl;
  private static X509CRL _origCrl;
  private static boolean _initialised = false;
  
  public SignedDataStreamTest(String paramString)
  {
    super(paramString);
  }
  
  private static void init()
    throws Exception
  {
    if (!_initialised)
    {
      _initialised = true;
      _signDN = "O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _signCert = CMSTestUtil.makeCertificate(_signKP, _signDN, _signKP, _signDN);
      _origDN = "CN=Bob, OU=Sales, O=Bouncy Castle, C=AU";
      _origKP = CMSTestUtil.makeKeyPair();
      _origCert = CMSTestUtil.makeCertificate(_origKP, _origDN, _signKP, _signDN);
      _origDsaKP = CMSTestUtil.makeDsaKeyPair();
      _origDsaCert = CMSTestUtil.makeCertificate(_origDsaKP, _origDN, _signKP, _signDN);
      _reciDN = "CN=Doug, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP = CMSTestUtil.makeKeyPair();
      _reciCert = CMSTestUtil.makeCertificate(_reciKP, _reciDN, _signKP, _signDN);
      _signCrl = CMSTestUtil.makeCrl(_signKP);
      _origCrl = CMSTestUtil.makeCrl(_origKP);
    }
  }
  
  private void verifySignatures(CMSSignedDataParser paramCMSSignedDataParser, byte[] paramArrayOfByte)
    throws Exception
  {
    CertStore localCertStore = paramCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = paramCMSSignedDataParser.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      localObject = (SignerInformation)localIterator1.next();
      localCollection2 = localCertStore.getCertificates(((SignerInformation)localObject).getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, ((SignerInformation)localObject).verify(localX509Certificate, "BC"));
      if (paramArrayOfByte != null) {
        assertTrue(MessageDigest.isEqual(paramArrayOfByte, ((SignerInformation)localObject).getContentDigest()));
      }
    }
    Object localObject = localCertStore.getCertificates(null);
    Collection localCollection2 = localCertStore.getCRLs(null);
    assertEquals(((Collection)localObject).size(), paramCMSSignedDataParser.getCertificates("Collection", "BC").getMatches(null).size());
    assertEquals(localCollection2.size(), paramCMSSignedDataParser.getCRLs("Collection", "BC").getMatches(null).size());
  }
  
  private void verifySignatures(CMSSignedDataParser paramCMSSignedDataParser)
    throws Exception
  {
    verifySignatures(paramCMSSignedDataParser, null);
  }
  
  private void verifyEncodedData(ByteArrayOutputStream paramByteArrayOutputStream)
    throws Exception
  {
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(paramByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
    localCMSSignedDataParser.close();
  }
  
  public void testSha1EncapsulatedSignature()
    throws Exception
  {
    byte[] arrayOfByte = Base64.decode("MIAGCSqGSIb3DQEHAqCAMIACAQExCzAJBgUrDgMCGgUAMIAGCSqGSIb3DQEHAaCAJIAEDEhlbGxvIFdvcmxkIQAAAAAAAKCCBGIwggINMIIBdqADAgECAgEFMA0GCSqGSIb3DQEBBAUAMCUxFjAUBgNVBAoTDUJvdW5jeSBDYXN0bGUxCzAJBgNVBAYTAkFVMB4XDTA1MDgwNzA2MjU1OVoXDTA1MTExNTA2MjU1OVowJTEWMBQGA1UEChMNQm91bmN5IENhc3RsZTELMAkGA1UEBhMCQVUwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAI1fZGgH9wgC3QiK6yluH6DlLDkXkxYYL+QfnVRszJVYl0LIxZdpb7WEbVpO8fwtEgFtoDsOdxyqh3dTBv+L7NVD/v46kdPtxVkSNHRbutJVY8Xn4/TC/CDngqtbpbniMO8n0GiB6vs94gBT20M34j96O2IF73feNHP+x8PkJ+dNAgMBAAGjTTBLMB0GA1UdDgQWBBQ3XUfEE6+D+t+LIJgKESSUE58eyzAfBgNVHSMEGDAWgBQ3XUfEE6+D+t+LIJgKESSUE58eyzAJBgNVHRMEAjAAMA0GCSqGSIb3DQEBBAUAA4GBAFK3r1stYOeXYJOlOyNGDTWEhZ+aOYdFeFaS6c+InjotHuFLAy+QsS8PslE48zYNFEqYygGfLhZDLlSnJ/LAUTqF01vlp+Bgn/JYiJazwi5WiiOTf7Th6eNjHFKXS3hfSGPNPIOjvicAp3ce3ehsuK0MxgLAaxievzhFfJcGSUMDMIICTTCCAbagAwIBAgIBBzANBgkqhkiG9w0BAQQFADAlMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVTAeFw0wNTA4MDcwNjI1NTlaFw0wNTExMTUwNjI1NTlaMGUxGDAWBgNVBAMTD0VyaWMgSC4gRWNoaWRuYTEkMCIGCSqGSIb3DQEJARYVZXJpY0Bib3VuY3ljYXN0bGUub3JnMRYwFAYDVQQKEw1Cb3VuY3kgQ2FzdGxlMQswCQYDVQQGEwJBVTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAgHCJyfwV6/V3kqSu2SOU2E/KI+N0XohCMUaxPLLNtNBZ3ijxwaV6JGFz7siTgZD/OGfzir/eZimkt+L1iXQnOAB+ZChivKvHtX+dFFC7Vq+E4Uy0Ftqc/wrGxE6DHb5BR0hprKH8wlDS8wSPzxovgk4nH0ffUZOoDSuUgjh3gG8CAwEAAaNNMEswHQYDVR0OBBYEFLfY/4EGmYrvJa7Cky+K9BJ7YmERMB8GA1UdIwQYMBaAFDddR8QTr4P634sgmAoRJJQTnx7LMAkGA1UdEwQCMAAwDQYJKoZIhvcNAQEEBQADgYEADIOmpMd6UHdMjkycmIE1yiwfClCsGhCK9FigTg6U1G2FmkBwJIMWBlkeH15uvepsAncsgK+Cn3ZrdZMb022mwtTJDtcaOM+SNeuCnjdowZ4i71Hf68siPm6sMlZkhz49rA0YidooWuzYOO+dggzwDsMldSsvsDo/ARyCGOulDOAxggEvMIIBKwIBATAqMCUxFjAUBgNVBAoTDUJvdW5jeSBDYXN0bGUxCzAJBgNVBAYTAkFVAgEHMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wNTA4MDcwNjI1NTlaMCMGCSqGSIb3DQEJBDEWBBQu973mCM5UBOl9XwQvlfifHCMocTANBgkqhkiG9w0BAQEFAASBgGxnBl2qozYKLgZ0ygqSFgWcRGl1LgNuE587LtO+EKkgoc3aFqEdjXlAyP8K7naRsvWnFrsB6pUpnrgI9Z8ZSKv898IlpsSSJ0jBlEb4gzzavwcBpYbr2ryOtDcF+kYmKIpScglyyoLzm+KPXOoTn7MsJMoKN3Kd2Vzh6s10PFgeAAAAAAAA");
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(arrayOfByte);
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testSHA1WithRSANoAttributes()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(CMSSignedDataGenerator.DATA, localCMSProcessableByteArray, false, "BC", false);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream("Hello World!".getBytes())), localCMSSignedData.getEncoded());
    localCMSSignedDataParser.getSignedContent().drain();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    verifySignatures(localCMSSignedDataParser, localMessageDigest.digest("Hello World!".getBytes()));
  }
  
  public void testDSANoAttributes()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    CMSProcessableByteArray localCMSProcessableByteArray = new CMSProcessableByteArray("Hello World!".getBytes());
    localArrayList.add(_origDsaCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataGenerator localCMSSignedDataGenerator = new CMSSignedDataGenerator();
    localCMSSignedDataGenerator.addSigner(_origDsaKP.getPrivate(), _origDsaCert, CMSSignedDataGenerator.DIGEST_SHA1);
    localCMSSignedDataGenerator.addCertificatesAndCRLs(localCertStore);
    CMSSignedData localCMSSignedData = localCMSSignedDataGenerator.generate(CMSSignedDataGenerator.DATA, localCMSProcessableByteArray, false, "BC", false);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream("Hello World!".getBytes())), localCMSSignedData.getEncoded());
    localCMSSignedDataParser.getSignedContent().drain();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    verifySignatures(localCMSSignedDataParser, localMessageDigest.digest("Hello World!".getBytes()));
  }
  
  public void testSHA1WithRSA()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localArrayList.add(_signCrl);
    localArrayList.add(_origCrl);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream("Hello World!".getBytes())), localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    verifySignatures(localCMSSignedDataParser, localMessageDigest.digest("Hello World!".getBytes()));
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigners(localCMSSignedDataParser.getSignerInfos());
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC"));
    localByteArrayOutputStream.reset();
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    verifyEncodedData(localByteArrayOutputStream);
    Collection localCollection = localCertStore.getCRLs(null);
    assertEquals(2, localCollection.size());
    assertTrue(localCollection.contains(_signCrl));
    assertTrue(localCollection.contains(_origCrl));
  }
  
  public void testSHA1WithRSANonData()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localArrayList.add(_signCrl);
    localArrayList.add(_origCrl);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, "1.2.3.4", true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    CMSTypedStream localCMSTypedStream = localCMSSignedDataParser.getSignedContent();
    assertEquals("1.2.3.4", localCMSTypedStream.getContentType());
    localCMSTypedStream.drain();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    verifySignatures(localCMSSignedDataParser, localMessageDigest.digest("Hello World!".getBytes()));
  }
  
  public void testSHA1AndMD5WithRSA()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_MD5, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream("Hello World!".getBytes())), localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testSHA1WithRSAEncapsulatedBufferedStream()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    for (int i = 0; i != 2000; i++) {
      localOutputStream.write(i & 0xFF);
    }
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
    int j = localByteArrayOutputStream.toByteArray().length;
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(localOutputStream, 300);
    for (int k = 0; k != 2000; k++) {
      localBufferedOutputStream.write(k & 0xFF);
    }
    localBufferedOutputStream.close();
    verifyEncodedData(localByteArrayOutputStream);
    assertTrue(localByteArrayOutputStream.toByteArray().length < j);
  }
  
  public void testSHA1WithRSAEncapsulatedBuffered()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    for (int i = 0; i != 2000; i++) {
      localOutputStream.write(i & 0xFF);
    }
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
    int j = localByteArrayOutputStream.toByteArray().length;
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.setBufferSize(300);
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    for (int k = 0; k != 2000; k++) {
      localOutputStream.write(k & 0xFF);
    }
    localOutputStream.close();
    verifyEncodedData(localByteArrayOutputStream);
    assertTrue(localByteArrayOutputStream.toByteArray().length < j);
  }
  
  public void testSHA1WithRSAEncapsulated()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
    byte[] arrayOfByte = (byte[])localCMSSignedDataStreamGenerator.getGeneratedDigests().get(SMIMESignedGenerator.DIGEST_SHA1);
    AttributeTable localAttributeTable = ((SignerInformation)localCMSSignedDataParser.getSignerInfos().getSigners().iterator().next()).getSignedAttributes();
    Attribute localAttribute = localAttributeTable.get(CMSAttributes.messageDigest);
    assertTrue(MessageDigest.isEqual(arrayOfByte, ((ASN1OctetString)localAttribute.getAttrValues().getObjectAt(0)).getOctets()));
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigners(localCMSSignedDataParser.getSignerInfos());
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC"));
    localByteArrayOutputStream.reset();
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedData localCMSSignedData = new CMSSignedData(new CMSProcessableByteArray("Hello World!".getBytes()), localByteArrayOutputStream.toByteArray());
    assertEquals(1, localCMSSignedData.getSignerInfos().getSigners().size());
    verifyEncodedData(localByteArrayOutputStream);
  }
  
  public void testAttributeGenerators()
    throws Exception
  {
    final DERObjectIdentifier localDERObjectIdentifier1 = new DERObjectIdentifier("1.2.3");
    final DERObjectIdentifier localDERObjectIdentifier2 = new DERObjectIdentifier("1.2.3.4");
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    DefaultSignedAttributeTableGenerator local1 = new DefaultSignedAttributeTableGenerator()
    {
      public AttributeTable getAttributes(Map paramAnonymousMap)
      {
        Hashtable localHashtable = createStandardAttributeTable(paramAnonymousMap);
        DEROctetString localDEROctetString = new DEROctetString((byte[])paramAnonymousMap.get("digest"));
        Attribute localAttribute = new Attribute(localDERObjectIdentifier1, new DERSet(localDEROctetString));
        localHashtable.put(localAttribute.getAttrType(), localAttribute);
        return new AttributeTable(localHashtable);
      }
    };
    CMSAttributeTableGenerator local2 = new CMSAttributeTableGenerator()
    {
      public AttributeTable getAttributes(Map paramAnonymousMap)
      {
        DEROctetString localDEROctetString = new DEROctetString((byte[])paramAnonymousMap.get("encryptedDigest"));
        Attribute localAttribute = new Attribute(localDERObjectIdentifier2, new DERSet(localDEROctetString));
        return new AttributeTable(new DERSet(localAttribute));
      }
    };
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, local1, local2, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
    SignerInformationStore localSignerInformationStore = localCMSSignedDataParser.getSignerInfos();
    Collection localCollection = localSignerInformationStore.getSigners();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator.next();
      checkAttribute(localSignerInformation.getContentDigest(), localSignerInformation.getSignedAttributes().get(localDERObjectIdentifier1));
      checkAttribute(localSignerInformation.getSignature(), localSignerInformation.getUnsignedAttributes().get(localDERObjectIdentifier2));
    }
  }
  
  private void checkAttribute(byte[] paramArrayOfByte, Attribute paramAttribute)
  {
    DEROctetString localDEROctetString = (DEROctetString)paramAttribute.getAttrValues().getObjectAt(0);
    assertEquals(new DEROctetString(paramArrayOfByte), localDEROctetString);
  }
  
  public void testWithAttributeCertificate()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    X509AttributeCertificate localX509AttributeCertificate = CMSTestUtil.getAttributeCertificate();
    X509Store localX509Store = X509Store.getInstance("AttributeCertificate/Collection", new X509CollectionStoreParameters(Collections.singleton(localX509AttributeCertificate)), "BC");
    localCMSSignedDataStreamGenerator.addAttributeCertificates(localX509Store);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    assertEquals(4, localCMSSignedDataParser.getVersion());
    localX509Store = localCMSSignedDataParser.getAttributeCertificates("Collection", "BC");
    Collection localCollection = localX509Store.getMatches(null);
    assertEquals(1, localCollection.size());
    assertTrue(localCollection.contains(localX509AttributeCertificate));
  }
  
  public void testSignerStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    byte[] arrayOfByte = "Hello World!".getBytes();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1, false);
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream1.toByteArray());
    localByteArrayOutputStream1.reset();
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA224, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1);
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    CMSSignedData localCMSSignedData = new CMSSignedData(localByteArrayOutputStream1.toByteArray());
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    CMSSignedDataParser.replaceSigners(localByteArrayInputStream, localCMSSignedData.getSignerInfos(), localByteArrayOutputStream2);
    localCMSSignedData = new CMSSignedData(new CMSProcessableByteArray(arrayOfByte), localByteArrayOutputStream2.toByteArray());
    SignerInformation localSignerInformation = (SignerInformation)localCMSSignedData.getSignerInfos().getSigners().iterator().next();
    assertEquals(localSignerInformation.getDigestAlgOID(), CMSSignedDataStreamGenerator.DIGEST_SHA224);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream(arrayOfByte)), localByteArrayOutputStream2.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testEncapsulatedSignerStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream1.toByteArray());
    localByteArrayOutputStream1.reset();
    localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA224, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedData localCMSSignedData = new CMSSignedData(localByteArrayOutputStream1.toByteArray());
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    CMSSignedDataParser.replaceSigners(localByteArrayInputStream, localCMSSignedData.getSignerInfos(), localByteArrayOutputStream2);
    localCMSSignedData = new CMSSignedData(localByteArrayOutputStream2.toByteArray());
    SignerInformation localSignerInformation = (SignerInformation)localCMSSignedData.getSignerInfos().getSigners().iterator().next();
    assertEquals(localSignerInformation.getDigestAlgOID(), CMSSignedDataStreamGenerator.DIGEST_SHA224);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream2.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testCertStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    byte[] arrayOfByte = "Hello World!".getBytes();
    localArrayList.add(_origDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1);
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream1.toByteArray());
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    CMSSignedDataParser.replaceCertificatesAndCRLs(localByteArrayInputStream, localCertStore, localByteArrayOutputStream2);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(new CMSTypedStream(new ByteArrayInputStream(arrayOfByte)), localByteArrayOutputStream2.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testEncapsulatedCertStoreReplacement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    localArrayList.add(_origDsaCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream1, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    localArrayList = new ArrayList();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream1.toByteArray());
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    CMSSignedDataParser.replaceCertificatesAndCRLs(localByteArrayInputStream, localCertStore, localByteArrayOutputStream2);
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream2.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    verifySignatures(localCMSSignedDataParser);
  }
  
  public void testCertOrdering1()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_origCert);
    localArrayList.add(_signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    localCertStore = localCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC");
    Iterator localIterator = localCertStore.getCertificates(null).iterator();
    assertEquals(_origCert, localIterator.next());
    assertEquals(_signCert, localIterator.next());
  }
  
  public void testCertOrdering2()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    CMSSignedDataStreamGenerator localCMSSignedDataStreamGenerator = new CMSSignedDataStreamGenerator();
    localCMSSignedDataStreamGenerator.addSigner(_origKP.getPrivate(), _origCert, CMSSignedDataStreamGenerator.DIGEST_SHA1, "BC");
    localCMSSignedDataStreamGenerator.addCertificatesAndCRLs(localCertStore);
    OutputStream localOutputStream = localCMSSignedDataStreamGenerator.open(localByteArrayOutputStream, true);
    localOutputStream.write("Hello World!".getBytes());
    localOutputStream.close();
    CMSSignedDataParser localCMSSignedDataParser = new CMSSignedDataParser(localByteArrayOutputStream.toByteArray());
    localCMSSignedDataParser.getSignedContent().drain();
    localCertStore = localCMSSignedDataParser.getCertificatesAndCRLs("Collection", "BC");
    Iterator localIterator = localCertStore.getCertificates(null).iterator();
    assertEquals(_signCert, localIterator.next());
    assertEquals(_origCert, localIterator.next());
  }
  
  public static Test suite()
    throws Exception
  {
    init();
    return new CMSTestSetup(new TestSuite(SignedDataStreamTest.class));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\SignedDataStreamTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */