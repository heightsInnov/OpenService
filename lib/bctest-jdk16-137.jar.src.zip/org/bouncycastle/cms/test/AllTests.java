package org.bouncycastle.cms.test;

import javax.crypto.Cipher;
import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class AllTests
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("CMS tests");
    localTestSuite.addTest(CompressedDataTest.suite());
    localTestSuite.addTest(SignedDataTest.suite());
    localTestSuite.addTest(EnvelopedDataTest.suite());
    localTestSuite.addTest(CompressedDataStreamTest.suite());
    localTestSuite.addTest(SignedDataStreamTest.suite());
    localTestSuite.addTest(EnvelopedDataStreamTest.suite());
    try
    {
      Cipher.getInstance("RSA", "SunJCE");
      localTestSuite.addTest(SunProviderTest.suite());
      localTestSuite.addTest(NullProviderTest.suite());
    }
    catch (Exception localException) {}
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */