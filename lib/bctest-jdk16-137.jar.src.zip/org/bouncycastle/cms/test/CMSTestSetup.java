package org.bouncycastle.cms.test;

import java.security.Security;
import junit.extensions.TestSetup;
import junit.framework.Test;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

class CMSTestSetup
  extends TestSetup
{
  public CMSTestSetup(Test paramTest)
  {
    super(paramTest);
  }
  
  protected void setUp()
  {
    Security.addProvider(new BouncyCastleProvider());
  }
  
  protected void tearDown()
  {
    Security.removeProvider("BC");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\CMSTestSetup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */