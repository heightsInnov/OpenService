package org.bouncycastle.cms.test;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.kisa.KISAObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.ntt.NTTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.KeyTransRecipientInformation;
import org.bouncycastle.cms.PKCS5Scheme2PBEKey;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;

public class EnvelopedDataTest
  extends TestCase
{
  private static String _signDN;
  private static KeyPair _signKP;
  private static X509Certificate _signCert;
  private static String _origDN;
  private static KeyPair _origKP;
  private static X509Certificate _origCert;
  private static String _reciDN;
  private static KeyPair _reciKP;
  private static X509Certificate _reciCert;
  private static KeyPair _origEcKP;
  private static KeyPair _reciEcKP;
  private static X509Certificate _reciEcCert;
  private static boolean _initialised = false;
  private byte[] oldKEK = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxQaI/MD0CAQQwBwQFAQIDBAUwDQYJYIZIAWUDBAEFBQAEIFi2eHTPM4bQSjP4DUeDzJZLpfemW2gF1SPq7ZPHJi1mMIAGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQImtdGyUdGGt6ggAQYk9X9z01YFBkU7IlS3wmsKpm/zpZClTceAAAAAAAAAAAAAA==");
  private byte[] ecKeyAgreeMsgAES256 = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxgcShgcECAQOgQ6FBMAsGByqGSM49AgEFAAMyAAPdXlSTpub+qqno9hUGkUDl+S3/ABhPziIB5yGU4678tgOgU5CiKG9ZkfnabIJ3nZYwGgYJK4EFEIZIPwACMA0GCWCGSAFlAwQBLQUAMFswWTAtMCgxEzARBgNVBAMTCkFkbWluLU1EU0UxETAPBgNVBAoTCDRCQ1QtMklEAgEBBCi/rJRLbFwEVW6PcLLmojjW9lI/xGD7CfZzXrqXFw8iHaf3hTRau1gYMIAGCSqGSIb3DQEHATAdBglghkgBZQMEASoEEMtCnKKPwccmyrbgeSIlA3qggAQQDLw8pNJR97bPpj6baG99bQQQwhEDsoj5Xg1oOxojHVcYzAAAAAAAAAAAAAA=");
  private byte[] ecKeyAgreeMsgAES128 = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxgbShgbECAQOgQ6FBMAsGByqGSM49AgEFAAMyAAL01JLEgKvKh5rbxI/hOxs/9WEezMIsAbUaZM4l5tn3CzXAN505nr5dLhrcurMK+tAwGgYJK4EFEIZIPwACMA0GCWCGSAFlAwQBBQUAMEswSTAtMCgxEzARBgNVBAMTCkFkbWluLU1EU0UxETAPBgNVBAoTCDRCQ1QtMklEAgEBBBhiFLjc5g6aqDT3f8LomljOwl1WTrplUT8wgAYJKoZIhvcNAQcBMB0GCWCGSAFlAwQBAgQQzXjms16Y69S/rB0EbHqRMaCABBAFmc/QdVW6LTKdEy97kaZzBBBafQuviUS03NycpojELx0bAAAAAAAAAAAAAA==");
  private byte[] ecKeyAgreeMsgDESEDE = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxgcahgcMCAQOgQ6FBMAsGByqGSM49AgEFAAMyAALIici6Nx1WN5f0ThH2A8ht9ovm0thpC5JK54t73E1RDzCifePaoQo0xd6sUqoyGaYwHAYJK4EFEIZIPwACMA8GCyqGSIb3DQEJEAMGBQAwWzBZMC0wKDETMBEGA1UEAxMKQWRtaW4tTURTRTERMA8GA1UEChMINEJDVC0ySUQCAQEEKJuqZQ1NB1vXrKPOnb4TCpYOsdm6GscWdwAAZlm2EHMp444j0s55J9wwgAYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAjwnsDMsafCrKCABBjyPvqFOVMKxxutVfTx4fQlNGJN8S2ATRgECMcTQ/dsmeViAAAAAAAAAAAAAA==");
  private byte[] ecMQVKeyAgreeMsgAES128 = Base64.decode("MIAGCSqGSIb3DQEHA6CAMIACAQIxgf2hgfoCAQOgQ6FBMAsGByqGSM49AgEFAAMyAAPDKU+0H58tsjpoYmYCInMr/FayvCCkupebgsnpaGEB7qS9vzcNVUj6mrnmiC2grpmhRwRFMEMwQTALBgcqhkjOPQIBBQADMgACZpD13z9c7DzRWx6S0xdbq3S+EJ7vWO+YcHVjTD8NcQDcZcWASW899l1PkL936zsuMBoGCSuBBRCGSD8AEDANBglghkgBZQMEAQUFADBLMEkwLTAoMRMwEQYDVQQDEwpBZG1pbi1NRFNFMREwDwYDVQQKEwg0QkNULTJJRAIBAQQYFq58L71nyMK/70w3nc6zkkRyRL7DHmpZMIAGCSqGSIb3DQEHATAdBglghkgBZQMEAQIEEDzRUpreBsZXWHBeonxOtSmggAQQ7csAZXwT1lHUqoazoy8bhAQQq+9Zjj8iGdOWgyebbfj67QAAAAAAAAAAAAA=");
  private byte[] ecKeyAgreeKey = Base64.decode("MIG2AgEAMBAGByqGSM49AgEGBSuBBAAiBIGeMIGbAgEBBDC8vp7xVTbKSgYVU5WchGkWbzaj+yUFETIWP1Dt7+WSpq3ikSPdl7PpHPqnPVZfoIWhZANiAgSYHTgxf+DdTt84dUvuSKkFy3RhjxJmjwIscK6zbEUzKhcPQG2GHzXhWK5x1kov0I74XpGhVkyaElH5K6SaOXiXAzcyNGggTOk4+ZFnz5Xl0pBje3zKxPhYu0SnCw7Pcqw=");
  private byte[] bobPrivRsaEncrypt = Base64.decode("MIIChQIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKnhZ5g/OdVf8qCTQV6meYmFyDVdmpFb+x0B2hlwJhcPvaUi0DWFbXqYZhRBXM+3twg7CcmRuBlpN235ZR572akzJKN/O7uvRgGGNjQyywcDWVL8hYsxBLjMGAgUSOZPHPtdYMTgXB9T039T2GkB8QX4enDRvoPGXzjPHCyqaqfrAgMBAAECgYBnzUhMmg2PmMIbZf8ig5xt8KYGHbztpwOIlPIcaw+LNd4Ogngwy+e6alatd8brUXlweQqg9P5F4Kmy9Bnah5jWMIR05PxZbMHGd9ypkdB8MKCixQheIXFD/A0HPfD6bRSeTmPwF1h5HEuYHD09sBvf+iU7o8AsmAX2EAnYh9sDGQJBANDDIsbeopkYdo+NvKZ11mY/1I1FUox29XLE6/BGmvE+XKpVC5va3Wtt+Pw7PAhDk7Vb/s7q/WiEI2Kv8zHCueUCQQDQUfweIrdb7bWOAcjXq/JY1PeClPNTqBlFy2bKKBlf4hAr84/sajB0+E0R9KfEILVHIdxJAfkKICnwJAiEYH2PAkA0umTJSChXdNdVUN5qSO8bKlocSHseIVnDYDubl6nA7xhmqU5iUjiEzuUJiEiUacUgFJlaV/4jbOSnI3vQgLeFAkEAni+zN5r7CwZdV+EJBqRd2ZCWBgVfJAZAcpw6iIWchw+dYhKIFmioNRobQ+g4wJhprwMKSDIETukPj3d9NDAlBwJAVxhn1grStavCunrnVNqcBU+B1O8BiR4yPWnLMcRSyFRVJQA7HCp8JlDV6abXd8vPFfXuC9WN7rOvTKF8Y0ZB9qANMAsGA1UdDzEEAwIAEA==");
  private byte[] rfc4134ex5_1 = Base64.decode("MIIBHgYJKoZIhvcNAQcDoIIBDzCCAQsCAQAxgcAwgb0CAQAwJjASMRAwDgYDVQQDEwdDYXJsUlNBAhBGNGvHgABWvBHTbi7NXXHQMA0GCSqGSIb3DQEBAQUABIGAC3EN5nGIiJi2lsGPcP2iJ97a4e8kbKQz36zg6Z2i0yx6zYC4mZ7mX7FBs3IWg+f6KgCLx3M1eCbWx8+MDFbbpXadCDgO8/nUkUNYeNxJtuzubGgzoyEd8Ch4H/dd9gdzTd+taTEgS0ipdSJuNnkVY4/M652jKKHRLFf02hosdR8wQwYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAgtaMXpRwZRNYAgDsiSf8Z9P43LrY4OxUk660cu1lXeCSFOSOpOJ7FuVyU=");
  private byte[] rfc4134ex5_2 = Base64.decode("MIIBZQYJKoZIhvcNAQcDoIIBVjCCAVICAQIxggEAMIG9AgEAMCYwEjEQMA4GA1UEAxMHQ2FybFJTQQIQRjRrx4AAVrwR024uzV1x0DANBgkqhkiG9w0BAQEFAASBgJQmQojGi7Z4IP+CVypBmNFoCDoEp87khtgyff2N4SmqD3RxPx+8hbLQt9i3YcMwcap+aiOkyqjMalT03VUC0XBOGv+HYI3HBZm/aFzxoq+YOXAWs5xlGerZwTOc9j6AYlK4qXvnztR5SQ8TBjlzytm4V7zg+TGrnGVNQBNw47Ewoj4CAQQwDQQLTWFpbExpc3RSQzIwEAYLKoZIhvcNAQkQAwcCAToEGHcUr5MSJ/g9HnJVHsQ6X56VcwYb+OfojTBJBgkqhkiG9w0BBwEwGgYIKoZIhvcNAwIwDgICAKAECJwE0hkuKlWhgCBeKNXhojuej3org9Lt7n+wWxOhnky5V50vSpoYRfRRyw==");
  
  private static void init()
    throws Exception
  {
    if (!_initialised)
    {
      _initialised = true;
      _signDN = "O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _signCert = CMSTestUtil.makeCertificate(_signKP, _signDN, _signKP, _signDN);
      _origDN = "CN=Bob, OU=Sales, O=Bouncy Castle, C=AU";
      _origKP = CMSTestUtil.makeKeyPair();
      _origCert = CMSTestUtil.makeCertificate(_origKP, _origDN, _signKP, _signDN);
      _reciDN = "CN=Doug, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP = CMSTestUtil.makeKeyPair();
      _reciCert = CMSTestUtil.makeCertificate(_reciKP, _reciDN, _signKP, _signDN);
      _origEcKP = CMSTestUtil.makeEcDsaKeyPair();
      _reciEcKP = CMSTestUtil.makeEcDsaKeyPair();
      _reciEcCert = CMSTestUtil.makeCertificate(_reciEcKP, _reciDN, _signKP, _signDN);
    }
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    init();
    return new CMSTestSetup(new TestSuite(EnvelopedDataTest.class));
  }
  
  public void testKeyTrans()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), CMSEnvelopedDataGenerator.DES_EDE3_CBC, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.DES_EDE3_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    assertEquals(1, localCollection.size());
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
  }
  
  public void testKeyTransCAST5SunJCE()
    throws Exception
  {
    if (Security.getProvider("SunJCE") == null) {
      return;
    }
    String str = System.getProperty("java.version");
    if ((str.startsWith("1.4")) || (str.startsWith("1.3"))) {
      return;
    }
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), "1.2.840.113533.7.66.10", "SunJCE");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), "1.2.840.113533.7.66.10");
    Collection localCollection = localRecipientInformationStore.getRecipients();
    assertEquals(1, localCollection.size());
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "SunJCE");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
  }
  
  public void testKeyTransRC4()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaBouncyCastle".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), "1.2.840.113549.3.4", "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), "1.2.840.113549.3.4");
    Collection localCollection = localRecipientInformationStore.getRecipients();
    assertEquals(1, localCollection.size());
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
  }
  
  public void testKeyTrans128RC4()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaBouncyCastle".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), "1.2.840.113549.3.4", 128, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), "1.2.840.113549.3.4");
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testKeyTransODES()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaBouncyCastle".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), "1.3.14.3.2.7", "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), "1.3.14.3.2.7");
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testKeyTransSmallAES()
    throws Exception
  {
    byte[] arrayOfByte1 = { 0, 1, 2, 3 };
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testKeyTransCAST5()
    throws Exception
  {
    tryKeyTrans("1.2.840.113533.7.66.10", new DERObjectIdentifier("1.2.840.113533.7.66.10"), ASN1Sequence.class);
  }
  
  public void testKeyTransAES128()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.AES128_CBC, NISTObjectIdentifiers.id_aes128_CBC, DEROctetString.class);
  }
  
  public void testKeyTransAES192()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.AES192_CBC, NISTObjectIdentifiers.id_aes192_CBC, DEROctetString.class);
  }
  
  public void testKeyTransAES256()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.AES256_CBC, NISTObjectIdentifiers.id_aes256_CBC, DEROctetString.class);
  }
  
  public void testKeyTransSEED()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.SEED_CBC, KISAObjectIdentifiers.id_seedCBC, DEROctetString.class);
  }
  
  public void testKeyTransCamellia128()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.CAMELLIA128_CBC, NTTObjectIdentifiers.id_camellia128_cbc, DEROctetString.class);
  }
  
  public void testKeyTransCamellia192()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.CAMELLIA192_CBC, NTTObjectIdentifiers.id_camellia192_cbc, DEROctetString.class);
  }
  
  public void testKeyTransCamellia256()
    throws Exception
  {
    tryKeyTrans(CMSEnvelopedDataGenerator.CAMELLIA256_CBC, NTTObjectIdentifiers.id_camellia256_cbc, DEROctetString.class);
  }
  
  private void tryKeyTrans(String paramString, DERObjectIdentifier paramDERObjectIdentifier, Class paramClass)
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyTransRecipient(_reciCert);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), paramString, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(paramDERObjectIdentifier.getId(), localCMSEnvelopedData.getEncryptionAlgOID());
    if (paramClass != null)
    {
      localObject = new ASN1InputStream(localCMSEnvelopedData.getEncryptionAlgParams());
      assertTrue(paramClass.isAssignableFrom(((ASN1InputStream)localObject).readObject().getClass()));
    }
    Object localObject = localRecipientInformationStore.getRecipients();
    assertEquals(1, ((Collection)localObject).size());
    Iterator localIterator = ((Collection)localObject).iterator();
    if (!localIterator.hasNext()) {
      fail("no recipients found");
    }
    while (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), PKCSObjectIdentifiers.rsaEncryption.getId());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
  }
  
  public void testErrorneousKEK()
    throws Exception
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 }, "AES");
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(this.oldKEK);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.DES_EDE3_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(localRecipientInformation.getKeyEncryptionAlgOID(), NISTObjectIdentifiers.id_aes128_wrap.getId());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(localSecretKeySpec, "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testDESKEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeDesede192Key(), new DERObjectIdentifier("1.2.840.113549.1.9.16.3.6"));
  }
  
  public void testRC2128KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeRC2128Key(), new DERObjectIdentifier("1.2.840.113549.1.9.16.3.7"));
  }
  
  public void testAES128KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeAESKey(128), NISTObjectIdentifiers.id_aes128_wrap);
  }
  
  public void testAES192KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeAESKey(192), NISTObjectIdentifiers.id_aes192_wrap);
  }
  
  public void testAES256KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeAESKey(256), NISTObjectIdentifiers.id_aes256_wrap);
  }
  
  public void testSEED128KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeSEEDKey(), KISAObjectIdentifiers.id_npki_app_cmsSeed_wrap);
  }
  
  public void testCamellia128KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeCamelliaKey(128), NTTObjectIdentifiers.id_camellia128_wrap);
  }
  
  public void testCamellia192KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeCamelliaKey(192), NTTObjectIdentifiers.id_camellia192_wrap);
  }
  
  public void testCamellia256KEK()
    throws Exception
  {
    tryKekAlgorithm(CMSTestUtil.makeCamelliaKey(256), NTTObjectIdentifiers.id_camellia256_wrap);
  }
  
  private void tryKekAlgorithm(SecretKey paramSecretKey, DERObjectIdentifier paramDERObjectIdentifier)
    throws NoSuchAlgorithmException, NoSuchProviderException, CMSException
  {
    byte[] arrayOfByte1 = "WallaWallaWashington".getBytes();
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    byte[] arrayOfByte2 = { 1, 2, 3, 4, 5 };
    localCMSEnvelopedDataGenerator.addKEKRecipient(paramSecretKey, arrayOfByte2);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), CMSEnvelopedDataGenerator.DES_EDE3_CBC, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.DES_EDE3_CBC);
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals(paramDERObjectIdentifier.getId(), localRecipientInformation.getKeyEncryptionAlgOID());
      byte[] arrayOfByte3 = localRecipientInformation.getContent(paramSecretKey, "BC");
      assertTrue(Arrays.equals(arrayOfByte1, arrayOfByte3));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testECKeyAgree()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("504b492d4320434d5320456e76656c6f706564446174612053616d706c65");
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addKeyAgreementRecipient(CMSEnvelopedDataGenerator.ECDH_SHA1KDF, _origEcKP.getPrivate(), _origEcKP.getPublic(), _reciEcCert, CMSEnvelopedDataGenerator.AES128_WRAP, "BC");
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(_reciEcKP.getPrivate(), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testECKeyAgreeVectors()
    throws Exception
  {
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(this.ecKeyAgreeKey);
    KeyFactory localKeyFactory = KeyFactory.getInstance("ECDH", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
    verifyECKeyAgreeVectors(localPrivateKey, "2.16.840.1.101.3.4.1.42", this.ecKeyAgreeMsgAES256);
    verifyECKeyAgreeVectors(localPrivateKey, "2.16.840.1.101.3.4.1.2", this.ecKeyAgreeMsgAES128);
    verifyECKeyAgreeVectors(localPrivateKey, "1.2.840.113549.3.7", this.ecKeyAgreeMsgDESEDE);
  }
  
  public void testPasswordAES256()
    throws Exception
  {
    passwordTest(CMSEnvelopedDataGenerator.AES256_CBC);
  }
  
  public void testPasswordDESEDE()
    throws Exception
  {
    passwordTest(CMSEnvelopedDataGenerator.DES_EDE3_CBC);
  }
  
  public void testRFC4134ex5_1()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("5468697320697320736f6d652073616d706c6520636f6e74656e742e");
    KeyFactory localKeyFactory = KeyFactory.getInstance("RSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(new PKCS8EncodedKeySpec(this.bobPrivRsaEncrypt));
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(this.rfc4134ex5_1);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals("1.2.840.113549.3.7", localCMSEnvelopedData.getEncryptionAlgOID());
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(localPrivateKey, "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  public void testRFC4134ex5_2()
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("5468697320697320736f6d652073616d706c6520636f6e74656e742e");
    KeyFactory localKeyFactory = KeyFactory.getInstance("RSA", "BC");
    PrivateKey localPrivateKey = localKeyFactory.generatePrivate(new PKCS8EncodedKeySpec(this.bobPrivRsaEncrypt));
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(this.rfc4134ex5_2);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals("1.2.840.113549.3.2", localCMSEnvelopedData.getEncryptionAlgOID());
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext()) {
      while (localIterator.hasNext())
      {
        RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
        if ((localRecipientInformation instanceof KeyTransRecipientInformation))
        {
          byte[] arrayOfByte2 = localRecipientInformation.getContent(localPrivateKey, "BC");
          assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
        }
      }
    }
    fail("no recipient found");
  }
  
  public void testOriginatorInfo()
    throws Exception
  {
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(CMSSampleMessages.originatorMessage);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(CMSEnvelopedDataGenerator.DES_EDE3_CBC, localCMSEnvelopedData.getEncryptionAlgOID());
  }
  
  private void passwordTest(String paramString)
    throws Exception
  {
    byte[] arrayOfByte1 = Hex.decode("504b492d4320434d5320456e76656c6f706564446174612053616d706c65");
    CMSEnvelopedDataGenerator localCMSEnvelopedDataGenerator = new CMSEnvelopedDataGenerator();
    localCMSEnvelopedDataGenerator.addPasswordRecipient(new PKCS5Scheme2PBEKey("password".toCharArray(), new byte[20], 5), paramString);
    CMSEnvelopedData localCMSEnvelopedData = localCMSEnvelopedDataGenerator.generate(new CMSProcessableByteArray(arrayOfByte1), CMSEnvelopedDataGenerator.AES128_CBC, "BC");
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    assertEquals(localCMSEnvelopedData.getEncryptionAlgOID(), CMSEnvelopedDataGenerator.AES128_CBC);
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      byte[] arrayOfByte2 = localRecipientInformation.getContent(new PKCS5Scheme2PBEKey("password".toCharArray(), new byte[20], 5), "BC");
      assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  private void verifyECKeyAgreeVectors(PrivateKey paramPrivateKey, String paramString, byte[] paramArrayOfByte)
    throws CMSException, GeneralSecurityException
  {
    byte[] arrayOfByte1 = Hex.decode("504b492d4320434d5320456e76656c6f706564446174612053616d706c65");
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(paramArrayOfByte);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    assertEquals(paramString, localCMSEnvelopedData.getEncryptionAlgOID());
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals("1.3.133.16.840.63.0.2", localRecipientInformation.getKeyEncryptionAlgOID());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(paramPrivateKey, "BC");
      assertTrue(Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
  
  private void verifyECMQVKeyAgreeVectors(PrivateKey paramPrivateKey, String paramString, byte[] paramArrayOfByte)
    throws CMSException, GeneralSecurityException
  {
    byte[] arrayOfByte1 = Hex.decode("504b492d4320434d5320456e76656c6f706564446174612053616d706c65");
    CMSEnvelopedData localCMSEnvelopedData = new CMSEnvelopedData(paramArrayOfByte);
    RecipientInformationStore localRecipientInformationStore = localCMSEnvelopedData.getRecipientInfos();
    Collection localCollection = localRecipientInformationStore.getRecipients();
    Iterator localIterator = localCollection.iterator();
    assertEquals(paramString, localCMSEnvelopedData.getEncryptionAlgOID());
    if (localIterator.hasNext())
    {
      RecipientInformation localRecipientInformation = (RecipientInformation)localIterator.next();
      assertEquals("1.3.133.16.840.63.0.16", localRecipientInformation.getKeyEncryptionAlgOID());
      byte[] arrayOfByte2 = localRecipientInformation.getContent(paramPrivateKey, "BC");
      assertTrue(Arrays.equals(arrayOfByte1, arrayOfByte2));
    }
    else
    {
      fail("no recipient found");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\cms\test\EnvelopedDataTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */