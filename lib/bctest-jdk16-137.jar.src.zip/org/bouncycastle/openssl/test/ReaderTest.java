package org.bouncycastle.openssl.test;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.RSAPrivateKey;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
import org.bouncycastle.openssl.PEMReader;
import org.bouncycastle.openssl.PEMWriter;
import org.bouncycastle.openssl.PasswordFinder;
import org.bouncycastle.util.test.SimpleTest;

public class ReaderTest
  extends SimpleTest
{
  public String getName()
  {
    return "PEMReaderTest";
  }
  
  private PEMReader openPEMResource(String paramString, PasswordFinder paramPasswordFinder)
  {
    InputStream localInputStream = getClass().getResourceAsStream(paramString);
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localInputStream));
    return new PEMReader(localBufferedReader, paramPasswordFinder);
  }
  
  public void performTest()
    throws Exception
  {
    Password localPassword = new Password("secret".toCharArray());
    PEMReader localPEMReader = openPEMResource("test.pem", localPassword);
    Object localObject;
    while ((localObject = localPEMReader.readObject()) != null) {
      if (!(localObject instanceof KeyPair)) {}
    }
    localPEMReader = openPEMResource("pkcs7.pem", null);
    ContentInfo localContentInfo = (ContentInfo)localPEMReader.readObject();
    if (!localContentInfo.getContentType().equals(CMSObjectIdentifiers.envelopedData)) {
      fail("failed envelopedData check");
    }
    localPEMReader = openPEMResource("eckey.pem", null);
    ECNamedCurveParameterSpec localECNamedCurveParameterSpec = (ECNamedCurveParameterSpec)localPEMReader.readObject();
    KeyPair localKeyPair = (KeyPair)localPEMReader.readObject();
    Signature localSignature = Signature.getInstance("ECDSA", "BC");
    localSignature.initSign(localKeyPair.getPrivate());
    byte[] arrayOfByte1 = { 97, 98, 99 };
    localSignature.update(arrayOfByte1);
    byte[] arrayOfByte2 = localSignature.sign();
    localSignature.initVerify(localKeyPair.getPublic());
    localSignature.update(arrayOfByte1);
    if (!localSignature.verify(arrayOfByte2)) {
      fail("EC verification failed");
    }
    if (!localKeyPair.getPublic().getAlgorithm().equals("ECDSA")) {
      fail("wrong algorithm name on public");
    }
    if (!localKeyPair.getPrivate().getAlgorithm().equals("ECDSA")) {
      fail("wrong algorithm name on private");
    }
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPair = localKeyPairGenerator.generateKeyPair();
    keyPairTest("RSA", localKeyPair);
    localKeyPairGenerator = KeyPairGenerator.getInstance("DSA", "BC");
    localKeyPairGenerator.initialize(512, new SecureRandom());
    localKeyPair = localKeyPairGenerator.generateKeyPair();
    keyPairTest("DSA", localKeyPair);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PEMWriter localPEMWriter = new PEMWriter(new OutputStreamWriter(localByteArrayOutputStream));
    localPEMWriter.writeObject(localContentInfo);
    localPEMWriter.close();
    localPEMReader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray())));
    localContentInfo = (ContentInfo)localPEMReader.readObject();
    if (!localContentInfo.getContentType().equals(CMSObjectIdentifiers.envelopedData)) {
      fail("failed envelopedData recode check");
    }
    doOpenSslDsaTest("unencrypted");
    doOpenSslRsaTest("unencrypted");
    doOpenSslTests("aes128");
    doOpenSslTests("aes192");
    doOpenSslTests("aes256");
    doOpenSslTests("blowfish");
    doOpenSslTests("des1");
    doOpenSslTests("des2");
    doOpenSslTests("des3");
    doOpenSslTests("rc2_128");
    doOpenSslDsaTest("rc2_40_cbc");
    doOpenSslRsaTest("rc2_40_cbc");
    doOpenSslDsaTest("rc2_64_cbc");
    doOpenSslRsaTest("rc2_64_cbc");
  }
  
  private void keyPairTest(String paramString, KeyPair paramKeyPair)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PEMWriter localPEMWriter = new PEMWriter(new OutputStreamWriter(localByteArrayOutputStream));
    localPEMWriter.writeObject(paramKeyPair.getPublic());
    localPEMWriter.close();
    PEMReader localPEMReader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray())));
    PublicKey localPublicKey = (PublicKey)localPEMReader.readObject();
    if (!localPublicKey.equals(paramKeyPair.getPublic())) {
      fail("Failed public key read: " + paramString);
    }
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localPEMWriter = new PEMWriter(new OutputStreamWriter(localByteArrayOutputStream));
    localPEMWriter.writeObject(paramKeyPair.getPrivate());
    localPEMWriter.close();
    localPEMReader = new PEMReader(new InputStreamReader(new ByteArrayInputStream(localByteArrayOutputStream.toByteArray())));
    KeyPair localKeyPair = (KeyPair)localPEMReader.readObject();
    if (!localKeyPair.getPrivate().equals(paramKeyPair.getPrivate())) {
      fail("Failed private key read: " + paramString);
    }
    if (!localKeyPair.getPublic().equals(paramKeyPair.getPublic())) {
      fail("Failed private key public read: " + paramString);
    }
  }
  
  private void doOpenSslTests(String paramString)
    throws IOException
  {
    doOpenSslDsaModesTest(paramString);
    doOpenSslRsaModesTest(paramString);
  }
  
  private void doOpenSslDsaModesTest(String paramString)
    throws IOException
  {
    doOpenSslDsaTest(paramString + "_cbc");
    doOpenSslDsaTest(paramString + "_cfb");
    doOpenSslDsaTest(paramString + "_ecb");
    doOpenSslDsaTest(paramString + "_ofb");
  }
  
  private void doOpenSslRsaModesTest(String paramString)
    throws IOException
  {
    doOpenSslRsaTest(paramString + "_cbc");
    doOpenSslRsaTest(paramString + "_cfb");
    doOpenSslRsaTest(paramString + "_ecb");
    doOpenSslRsaTest(paramString + "_ofb");
  }
  
  private void doOpenSslDsaTest(String paramString)
    throws IOException
  {
    String str = "dsa/openssl_dsa_" + paramString + ".pem";
    doOpenSslTestFile(str, DSAPrivateKey.class);
  }
  
  private void doOpenSslRsaTest(String paramString)
    throws IOException
  {
    String str = "rsa/openssl_rsa_" + paramString + ".pem";
    doOpenSslTestFile(str, RSAPrivateKey.class);
  }
  
  private void doOpenSslTestFile(String paramString, Class paramClass)
    throws IOException
  {
    PEMReader localPEMReader = openPEMResource("data/" + paramString, new Password("changeit".toCharArray()));
    Object localObject = localPEMReader.readObject();
    if ((localObject == null) || (!(localObject instanceof KeyPair))) {
      fail("Didn't find OpenSSL key");
    }
    KeyPair localKeyPair = (KeyPair)localObject;
    PrivateKey localPrivateKey = localKeyPair.getPrivate();
    if (!paramClass.isInstance(localPrivateKey)) {
      fail("Returned key not of correct type");
    }
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    runTest(new ReaderTest());
  }
  
  private static class Password
    implements PasswordFinder
  {
    char[] password;
    
    Password(char[] paramArrayOfChar)
    {
      this.password = paramArrayOfChar;
    }
    
    public char[] getPassword()
    {
      return this.password;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\openssl\test\ReaderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */