package org.bouncycastle.sasn1.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class AllTests
{
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
  {
    TestSuite localTestSuite = new TestSuite("ASN.1 tests");
    localTestSuite.addTestSuite(Asn1SequenceTest.class);
    localTestSuite.addTestSuite(OctetStringTest.class);
    localTestSuite.addTestSuite(OIDTest.class);
    localTestSuite.addTestSuite(ParseTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\sasn1\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */