package org.bouncycastle.sasn1.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import junit.framework.TestCase;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.sasn1.Asn1InputStream;
import org.bouncycastle.sasn1.Asn1ObjectIdentifier;
import org.bouncycastle.util.encoders.Hex;

public class OIDTest
  extends TestCase
{
  byte[] req1 = Hex.decode("0603813403");
  byte[] req2 = Hex.decode("06082A36FFFFFFDD6311");
  
  private void recodeCheck(String paramString, byte[] paramArrayOfByte)
    throws IOException
  {
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(localByteArrayInputStream);
    Asn1ObjectIdentifier localAsn1ObjectIdentifier1 = new Asn1ObjectIdentifier(paramString);
    Asn1ObjectIdentifier localAsn1ObjectIdentifier2 = (Asn1ObjectIdentifier)localAsn1InputStream.readObject();
    if (!localAsn1ObjectIdentifier1.equals(localAsn1ObjectIdentifier2)) {
      fail("oid ID didn't match - got: " + localAsn1ObjectIdentifier1 + " expected " + localAsn1ObjectIdentifier2);
    }
    byte[] arrayOfByte = localAsn1ObjectIdentifier1.getEncoded();
    if (arrayOfByte.length != paramArrayOfByte.length) {
      fail("failed length test");
    }
    for (int i = 0; i != paramArrayOfByte.length; i++) {
      if (arrayOfByte[i] != paramArrayOfByte[i]) {
        fail("failed comparison test - got: " + new String(Hex.encode(paramArrayOfByte)) + " expected " + new String(Hex.encode(arrayOfByte)));
      }
    }
  }
  
  private void valueCheck(String paramString)
    throws IOException
  {
    Asn1ObjectIdentifier localAsn1ObjectIdentifier = new Asn1ObjectIdentifier(paramString);
    ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localAsn1ObjectIdentifier.getEncoded());
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(localByteArrayInputStream);
    localAsn1ObjectIdentifier = (Asn1ObjectIdentifier)localAsn1InputStream.readObject();
    if (!localAsn1ObjectIdentifier.toString().equals(paramString)) {
      fail("failed oid check for " + paramString);
    }
  }
  
  public void testRecode()
    throws IOException
  {
    recodeCheck("2.100.3", this.req1);
    recodeCheck("1.2.54.34359733987.17", this.req2);
  }
  
  public void testValue()
    throws IOException
  {
    valueCheck(PKCSObjectIdentifiers.pkcs_9_at_contentType.getId());
    valueCheck("1.1.127.32512.8323072.2130706432.545460846592.139637976727552.35747322042253312.9151314442816847872");
    valueCheck("1.2.123.12345678901.1.1.1");
    valueCheck("2.25.196556539987194312349856245628873852187.1");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\sasn1\test\OIDTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */