package org.bouncycastle.sasn1.test;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Arrays;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.sasn1.Asn1InputStream;
import org.bouncycastle.sasn1.Asn1Integer;
import org.bouncycastle.sasn1.Asn1Object;
import org.bouncycastle.sasn1.Asn1ObjectIdentifier;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.BerSequenceGenerator;
import org.bouncycastle.sasn1.DerSequenceGenerator;
import org.bouncycastle.util.encoders.Hex;

public class Asn1SequenceTest
  extends TestCase
{
  private static final byte[] seqData = Hex.decode("3006020100060129");
  private static final byte[] nestedSeqData = Hex.decode("300b0201000601293003020101");
  private static final byte[] expTagSeqData = Hex.decode("a1083006020100060129");
  private static final byte[] implTagSeqData = Hex.decode("a106020100060129");
  private static final byte[] nestedSeqExpTagData = Hex.decode("300d020100060129a1053003020101");
  private static final byte[] nestedSeqImpTagData = Hex.decode("300b020100060129a103020101");
  private static final byte[] berSeqData = Hex.decode("30800201000601290000");
  private static final byte[] berDerNestedSeqData = Hex.decode("308002010006012930030201010000");
  private static final byte[] berNestedSeqData = Hex.decode("3080020100060129308002010100000000");
  private static final byte[] berExpTagSeqData = Hex.decode("a180308002010006012900000000");
  
  public void testDerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator = new DerSequenceGenerator(localByteArrayOutputStream);
    localDerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    localDerSequenceGenerator.close();
    assertTrue("basic DER writing test failed.", Arrays.equals(seqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedDerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator1 = new DerSequenceGenerator(localByteArrayOutputStream);
    localDerSequenceGenerator1.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator1.addObject(new Asn1ObjectIdentifier("1.1"));
    DerSequenceGenerator localDerSequenceGenerator2 = new DerSequenceGenerator(localDerSequenceGenerator1.getRawOutputStream());
    localDerSequenceGenerator2.addObject(new Asn1Integer(BigInteger.valueOf(1L)));
    localDerSequenceGenerator2.close();
    localDerSequenceGenerator1.close();
    assertTrue("nested DER writing test failed.", Arrays.equals(nestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDerExplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator = new DerSequenceGenerator(localByteArrayOutputStream, 1, true);
    localDerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    localDerSequenceGenerator.close();
    assertTrue("explicit tag writing test failed.", Arrays.equals(expTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDerImplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator = new DerSequenceGenerator(localByteArrayOutputStream, 1, false);
    localDerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    localDerSequenceGenerator.close();
    assertTrue("implicit tag writing test failed.", Arrays.equals(implTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedExplicitTagDerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator1 = new DerSequenceGenerator(localByteArrayOutputStream);
    localDerSequenceGenerator1.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator1.addObject(new Asn1ObjectIdentifier("1.1"));
    DerSequenceGenerator localDerSequenceGenerator2 = new DerSequenceGenerator(localDerSequenceGenerator1.getRawOutputStream(), 1, true);
    localDerSequenceGenerator2.addObject(new Asn1Integer(BigInteger.valueOf(1L)));
    localDerSequenceGenerator2.close();
    localDerSequenceGenerator1.close();
    assertTrue("nested explicit tagged DER writing test failed.", Arrays.equals(nestedSeqExpTagData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedImplicitTagDerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DerSequenceGenerator localDerSequenceGenerator1 = new DerSequenceGenerator(localByteArrayOutputStream);
    localDerSequenceGenerator1.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localDerSequenceGenerator1.addObject(new Asn1ObjectIdentifier("1.1"));
    DerSequenceGenerator localDerSequenceGenerator2 = new DerSequenceGenerator(localDerSequenceGenerator1.getRawOutputStream(), 1, false);
    localDerSequenceGenerator2.addObject(new Asn1Integer(BigInteger.valueOf(1L)));
    localDerSequenceGenerator2.close();
    localDerSequenceGenerator1.close();
    assertTrue("nested implicit tagged DER writing test failed.", Arrays.equals(nestedSeqImpTagData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testBerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator = new BerSequenceGenerator(localByteArrayOutputStream);
    localBerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localBerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    localBerSequenceGenerator.close();
    assertTrue("basic BER writing test failed.", Arrays.equals(berSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedBerDerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator = new BerSequenceGenerator(localByteArrayOutputStream);
    localBerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localBerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    DerSequenceGenerator localDerSequenceGenerator = new DerSequenceGenerator(localBerSequenceGenerator.getRawOutputStream());
    localDerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(1L)));
    localDerSequenceGenerator.close();
    localBerSequenceGenerator.close();
    assertTrue("nested BER/DER writing test failed.", Arrays.equals(berDerNestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testNestedBerWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator1 = new BerSequenceGenerator(localByteArrayOutputStream);
    localBerSequenceGenerator1.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localBerSequenceGenerator1.addObject(new Asn1ObjectIdentifier("1.1"));
    BerSequenceGenerator localBerSequenceGenerator2 = new BerSequenceGenerator(localBerSequenceGenerator1.getRawOutputStream());
    localBerSequenceGenerator2.addObject(new Asn1Integer(BigInteger.valueOf(1L)));
    localBerSequenceGenerator2.close();
    localBerSequenceGenerator1.close();
    assertTrue("nested BER writing test failed.", Arrays.equals(berNestedSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public void testDerReading()
    throws Exception
  {
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(seqData);
    Asn1Sequence localAsn1Sequence = (Asn1Sequence)localAsn1InputStream.readObject();
    Asn1Object localAsn1Object = null;
    int i = 0;
    assertNotNull("null sequence returned", localAsn1Sequence);
    while ((localAsn1Object = localAsn1Sequence.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localAsn1Object instanceof Asn1Integer);
        break;
      case 1: 
        assertTrue(localAsn1Object instanceof Asn1ObjectIdentifier);
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 2, i);
  }
  
  public void testNestedReading(byte[] paramArrayOfByte)
    throws Exception
  {
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(paramArrayOfByte);
    Asn1Sequence localAsn1Sequence1 = (Asn1Sequence)localAsn1InputStream.readObject();
    Asn1Object localAsn1Object = null;
    int i = 0;
    assertNotNull("null sequence returned", localAsn1Sequence1);
    while ((localAsn1Object = localAsn1Sequence1.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localAsn1Object instanceof Asn1Integer);
        break;
      case 1: 
        assertTrue(localAsn1Object instanceof Asn1ObjectIdentifier);
        break;
      case 2: 
        assertTrue(localAsn1Object instanceof Asn1Sequence);
        Asn1Sequence localAsn1Sequence2 = (Asn1Sequence)localAsn1Object;
        localAsn1Sequence2.readObject();
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 3, i);
  }
  
  public void testNestedDerReading()
    throws Exception
  {
    testNestedReading(nestedSeqData);
  }
  
  public void testBerReading()
    throws Exception
  {
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(berSeqData);
    Asn1Sequence localAsn1Sequence = (Asn1Sequence)localAsn1InputStream.readObject();
    Asn1Object localAsn1Object = null;
    int i = 0;
    assertNotNull("null sequence returned", localAsn1Sequence);
    while ((localAsn1Object = localAsn1Sequence.readObject()) != null)
    {
      switch (i)
      {
      case 0: 
        assertTrue(localAsn1Object instanceof Asn1Integer);
        break;
      case 1: 
        assertTrue(localAsn1Object instanceof Asn1ObjectIdentifier);
      }
      i++;
    }
    assertEquals("wrong number of objects in sequence", 2, i);
  }
  
  public void testNestedBerDerReading()
    throws Exception
  {
    testNestedReading(berDerNestedSeqData);
  }
  
  public void testNestedBerReading()
    throws Exception
  {
    testNestedReading(berNestedSeqData);
  }
  
  public void testBerExplicitTaggedSequenceWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator = new BerSequenceGenerator(localByteArrayOutputStream, 1, true);
    localBerSequenceGenerator.addObject(new Asn1Integer(BigInteger.valueOf(0L)));
    localBerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.1"));
    localBerSequenceGenerator.close();
    assertTrue("explicit BER tag writing test failed.", Arrays.equals(berExpTagSeqData, localByteArrayOutputStream.toByteArray()));
  }
  
  public static Test suite()
  {
    return new TestSuite(Asn1SequenceTest.class);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\sasn1\test\Asn1SequenceTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */