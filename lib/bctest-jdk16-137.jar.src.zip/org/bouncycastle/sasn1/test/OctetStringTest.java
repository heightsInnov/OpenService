package org.bouncycastle.sasn1.test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.cms.CMSObjectIdentifiers;
import org.bouncycastle.sasn1.Asn1InputStream;
import org.bouncycastle.sasn1.Asn1Integer;
import org.bouncycastle.sasn1.Asn1ObjectIdentifier;
import org.bouncycastle.sasn1.Asn1OctetString;
import org.bouncycastle.sasn1.Asn1Sequence;
import org.bouncycastle.sasn1.BerOctetString;
import org.bouncycastle.sasn1.BerOctetStringGenerator;
import org.bouncycastle.sasn1.BerSequence;
import org.bouncycastle.sasn1.BerSequenceGenerator;
import org.bouncycastle.sasn1.DerSequenceGenerator;
import org.bouncycastle.sasn1.cms.CompressedDataParser;
import org.bouncycastle.sasn1.cms.ContentInfoParser;

public class OctetStringTest
  extends TestCase
{
  public void testReadingWriting()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerOctetStringGenerator localBerOctetStringGenerator = new BerOctetStringGenerator(localByteArrayOutputStream);
    OutputStream localOutputStream = localBerOctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte[4]);
    localOutputStream.close();
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(localByteArrayOutputStream.toByteArray());
    BerOctetString localBerOctetString = (BerOctetString)localAsn1InputStream.readObject();
    InputStream localInputStream = localBerOctetString.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(8, i);
  }
  
  public void testReadingWritingZeroInLength()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerOctetStringGenerator localBerOctetStringGenerator = new BerOctetStringGenerator(localByteArrayOutputStream);
    OutputStream localOutputStream = localBerOctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte['Ȁ']);
    localOutputStream.close();
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(localByteArrayOutputStream.toByteArray());
    BerOctetString localBerOctetString = (BerOctetString)localAsn1InputStream.readObject();
    InputStream localInputStream = localBerOctetString.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(516, i);
  }
  
  public void testReadingWritingNested()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator1 = new BerSequenceGenerator(localByteArrayOutputStream);
    BerOctetStringGenerator localBerOctetStringGenerator1 = new BerOctetStringGenerator(localBerSequenceGenerator1.getRawOutputStream());
    OutputStream localOutputStream1 = localBerOctetStringGenerator1.getOctetOutputStream();
    BerSequenceGenerator localBerSequenceGenerator2 = new BerSequenceGenerator(localOutputStream1);
    BerOctetStringGenerator localBerOctetStringGenerator2 = new BerOctetStringGenerator(localBerSequenceGenerator2.getRawOutputStream());
    OutputStream localOutputStream2 = localBerOctetStringGenerator2.getOctetOutputStream();
    localOutputStream2.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream2.write(new byte[10]);
    localOutputStream2.close();
    localBerSequenceGenerator2.close();
    localOutputStream1.close();
    localBerSequenceGenerator1.close();
    Asn1InputStream localAsn1InputStream1 = new Asn1InputStream(localByteArrayOutputStream.toByteArray());
    BerSequence localBerSequence1 = (BerSequence)localAsn1InputStream1.readObject();
    BerOctetString localBerOctetString1 = (BerOctetString)localBerSequence1.readObject();
    Asn1InputStream localAsn1InputStream2 = new Asn1InputStream(localBerOctetString1.getOctetStream());
    BerSequence localBerSequence2 = (BerSequence)localAsn1InputStream2.readObject();
    BerOctetString localBerOctetString2 = (BerOctetString)localBerSequence2.readObject();
    InputStream localInputStream = localBerOctetString2.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(14, i);
  }
  
  public void testNestedStructure()
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BerSequenceGenerator localBerSequenceGenerator1 = new BerSequenceGenerator(localByteArrayOutputStream);
    localBerSequenceGenerator1.addObject(new Asn1ObjectIdentifier(CMSObjectIdentifiers.compressedData.getId()));
    BerSequenceGenerator localBerSequenceGenerator2 = new BerSequenceGenerator(localBerSequenceGenerator1.getRawOutputStream(), 0, true);
    localBerSequenceGenerator2.addObject(new Asn1Integer(0L));
    DerSequenceGenerator localDerSequenceGenerator = new DerSequenceGenerator(localBerSequenceGenerator2.getRawOutputStream());
    localDerSequenceGenerator.addObject(new Asn1ObjectIdentifier("1.2"));
    localDerSequenceGenerator.close();
    BerSequenceGenerator localBerSequenceGenerator3 = new BerSequenceGenerator(localBerSequenceGenerator2.getRawOutputStream());
    localBerSequenceGenerator3.addObject(new Asn1ObjectIdentifier("1.1"));
    BerOctetStringGenerator localBerOctetStringGenerator = new BerOctetStringGenerator(localBerSequenceGenerator3.getRawOutputStream(), 0, true);
    OutputStream localOutputStream = localBerOctetStringGenerator.getOctetOutputStream();
    localOutputStream.write(new byte[] { 1, 2, 3, 4 });
    localOutputStream.write(new byte[4]);
    localOutputStream.write(new byte[20]);
    localOutputStream.close();
    localBerSequenceGenerator3.close();
    localBerSequenceGenerator2.close();
    localBerSequenceGenerator1.close();
    Asn1InputStream localAsn1InputStream = new Asn1InputStream(localByteArrayOutputStream.toByteArray());
    ContentInfoParser localContentInfoParser1 = new ContentInfoParser((Asn1Sequence)localAsn1InputStream.readObject());
    CompressedDataParser localCompressedDataParser = new CompressedDataParser((Asn1Sequence)localContentInfoParser1.getContent(16));
    ContentInfoParser localContentInfoParser2 = localCompressedDataParser.getEncapContentInfo();
    Asn1OctetString localAsn1OctetString = (Asn1OctetString)localContentInfoParser2.getContent(4);
    InputStream localInputStream = localAsn1OctetString.getOctetStream();
    for (int i = 0; localInputStream.read() >= 0; i++) {}
    assertEquals(28, i);
  }
  
  public static Test suite()
  {
    return new TestSuite(OctetStringTest.class);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\sasn1\test\OctetStringTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */