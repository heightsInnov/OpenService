package org.bouncycastle.mail.smime.test;

import org.bouncycastle.x509.PKIXCertPathReviewer;

public class DummyCertPathReviewer
  extends PKIXCertPathReviewer
{}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\DummyCertPathReviewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */