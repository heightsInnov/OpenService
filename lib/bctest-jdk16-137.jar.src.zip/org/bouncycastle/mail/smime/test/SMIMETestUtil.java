package org.bouncycastle.mail.smime.test;

import java.security.Security;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class SMIMETestUtil
{
  public static final boolean DEBUG = true;
  
  public static MimeBodyPart makeMimeBodyPart(String paramString)
    throws MessagingException
  {
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    localMimeBodyPart.setText(paramString);
    return localMimeBodyPart;
  }
  
  public static MimeBodyPart makeMimeBodyPart(MimeMultipart paramMimeMultipart)
    throws MessagingException
  {
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    localMimeBodyPart.setContent(paramMimeMultipart, paramMimeMultipart.getContentType());
    return localMimeBodyPart;
  }
  
  public static MimeMultipart makeMimeMultipart(String paramString1, String paramString2)
    throws MessagingException
  {
    MimeMultipart localMimeMultipart = new MimeMultipart();
    localMimeMultipart.addBodyPart(makeMimeBodyPart(paramString1));
    localMimeMultipart.addBodyPart(makeMimeBodyPart(paramString2));
    return localMimeMultipart;
  }
  
  static
  {
    Security.addProvider(new BouncyCastleProvider());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMETestUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */