package org.bouncycastle.mail.smime.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.cms.CMSAttributes;
import org.bouncycastle.asn1.cms.Time;
import org.bouncycastle.asn1.cryptopro.CryptoProObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.asn1.teletrust.TeleTrusTObjectIdentifiers;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.test.CMSTestUtil;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.mail.smime.SMIMESignedParser;
import org.bouncycastle.mail.smime.util.CRLFOutputStream;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;
import org.bouncycastle.x509.X509AttributeCertificate;
import org.bouncycastle.x509.X509CollectionStoreParameters;
import org.bouncycastle.x509.X509Store;

public class SMIMESignedTest
  extends TestCase
{
  static MimeBodyPart msg;
  static MimeBodyPart msgR;
  static MimeBodyPart msgRN;
  static String _origDN;
  static KeyPair _origKP;
  static X509Certificate _origCert;
  static String _signDN;
  static KeyPair _signKP;
  static X509Certificate _signCert;
  static String reciDN;
  static KeyPair reciKP;
  static X509Certificate reciCert;
  private static KeyPair _signGostKP;
  private static X509Certificate _signGostCert;
  private static KeyPair _signEcDsaKP;
  private static X509Certificate _signEcDsaCert;
  private static KeyPair _signEcGostKP;
  private static X509Certificate _signEcGostCert;
  KeyPair dsaSignKP;
  X509Certificate dsaSignCert;
  KeyPair dsaOrigKP;
  X509Certificate dsaOrigCert;
  
  public SMIMESignedTest(String paramString)
  {
    super(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(SMIMESignedTest.class);
  }
  
  public static Test suite()
  {
    return new SMIMETestSetup(new TestSuite(SMIMESignedTest.class));
  }
  
  public void testHeaders()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, msg);
    BodyPart localBodyPart = localMimeMultipart.getBodyPart(1);
    assertEquals("application/pkcs7-signature; name=smime.p7s; smime-type=signed-data", localBodyPart.getHeader("Content-Type")[0]);
    assertEquals("attachment; filename=\"smime.p7s\"", localBodyPart.getHeader("Content-Disposition")[0]);
    assertEquals("S/MIME Cryptographic Signature", localBodyPart.getHeader("Content-Description")[0]);
  }
  
  public void testHeadersEncapsulated()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeBodyPart localMimeBodyPart = localSMIMESignedGenerator.generateEncapsulated(msg, "BC");
    assertEquals("application/pkcs7-mime; name=smime.p7m; smime-type=signed-data", localMimeBodyPart.getHeader("Content-Type")[0]);
    assertEquals("attachment; filename=\"smime.p7m\"", localMimeBodyPart.getHeader("Content-Disposition")[0]);
    assertEquals("S/MIME Cryptographic Signed Data", localMimeBodyPart.getHeader("Content-Description")[0]);
  }
  
  public void testMultipartTextText()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = createTemplate("text/html", "7bit");
    MimeBodyPart localMimeBodyPart2 = createTemplate("text/xml", "7bit");
    multipartMixedTest(localMimeBodyPart1, localMimeBodyPart2);
  }
  
  public void testMultipartTextBinary()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = createTemplate("text/html", "7bit");
    MimeBodyPart localMimeBodyPart2 = createTemplate("text/xml", "binary");
    multipartMixedTest(localMimeBodyPart1, localMimeBodyPart2);
  }
  
  public void testMultipartBinaryText()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = createTemplate("text/xml", "binary");
    MimeBodyPart localMimeBodyPart2 = createTemplate("text/html", "7bit");
    multipartMixedTest(localMimeBodyPart1, localMimeBodyPart2);
  }
  
  public void testMultipartBinaryBinary()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = createTemplate("text/xml", "binary");
    MimeBodyPart localMimeBodyPart2 = createTemplate("text/html", "binary");
    multipartMixedTest(localMimeBodyPart1, localMimeBodyPart2);
  }
  
  public void multipartMixedTest(MimeBodyPart paramMimeBodyPart1, MimeBodyPart paramMimeBodyPart2)
    throws Exception
  {
    MimeMultipart localMimeMultipart1 = new MimeMultipart();
    localMimeMultipart1.addBodyPart(paramMimeBodyPart1);
    localMimeMultipart1.addBodyPart(paramMimeBodyPart2);
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    localMimeBodyPart.setContent(localMimeMultipart1);
    MimeMultipart localMimeMultipart2 = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, localMimeBodyPart);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart2);
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
    AttributeTable localAttributeTable = ((SignerInformation)localSMIMESigned.getSignerInfos().getSigners().iterator().next()).getSignedAttributes();
    Attribute localAttribute = localAttributeTable.get(CMSAttributes.messageDigest);
    byte[] arrayOfByte = ASN1OctetString.getInstance(localAttribute.getAttrValues().getObjectAt(0)).getOctets();
    localMimeMultipart1 = (MimeMultipart)localMimeBodyPart.getContent();
    ContentType localContentType = new ContentType(localMimeMultipart1.getContentType());
    String str = "--" + localContentType.getParameter("boundary");
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    LineOutputStream localLineOutputStream = new LineOutputStream(localByteArrayOutputStream);
    Enumeration localEnumeration = localMimeBodyPart.getAllHeaderLines();
    while (localEnumeration.hasMoreElements()) {
      localLineOutputStream.writeln((String)localEnumeration.nextElement());
    }
    localLineOutputStream.writeln();
    localLineOutputStream.writeln(str);
    writePart(localMimeMultipart1.getBodyPart(0), localByteArrayOutputStream);
    localLineOutputStream.writeln();
    localLineOutputStream.writeln(str);
    writePart(localMimeMultipart1.getBodyPart(1), localByteArrayOutputStream);
    localLineOutputStream.writeln();
    localLineOutputStream.writeln(str + "--");
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    assertTrue(Arrays.equals(arrayOfByte, localMessageDigest.digest(localByteArrayOutputStream.toByteArray())));
  }
  
  private void writePart(BodyPart paramBodyPart, ByteArrayOutputStream paramByteArrayOutputStream)
    throws MessagingException, IOException
  {
    if (paramBodyPart.getHeader("Content-Transfer-Encoding")[0].equals("binary")) {
      paramBodyPart.writeTo(paramByteArrayOutputStream);
    } else {
      paramBodyPart.writeTo(new CRLFOutputStream(paramByteArrayOutputStream));
    }
  }
  
  public void testSHA1WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA1WithRSACanonicalization()
    throws Exception
  {
    Date localDate = new Date();
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, msg, localDate);
    byte[] arrayOfByte1 = getEncodedStream(localMimeMultipart);
    localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, msgR, localDate);
    byte[] arrayOfByte2 = getEncodedStream(localMimeMultipart);
    assertTrue(Arrays.equals(arrayOfByte1, arrayOfByte2));
    localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA1, msgRN, localDate);
    byte[] arrayOfByte3 = getEncodedStream(localMimeMultipart);
    assertTrue(Arrays.equals(arrayOfByte1, arrayOfByte3));
  }
  
  private byte[] getEncodedStream(MimeMultipart paramMimeMultipart)
    throws IOException, MessagingException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    paramMimeMultipart.getBodyPart(1).writeTo(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void testSHA1WithRSAEncapsulated()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = generateEncapsulatedRsa(SMIMESignedGenerator.DIGEST_SHA1, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeBodyPart);
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA1WithRSAEncapsulatedParser()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = generateEncapsulatedRsa(SMIMESignedGenerator.DIGEST_SHA1, msg);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeBodyPart);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = (FileBackedMimeBodyPart)localSMIMESignedParser.getContent();
    verifyMessageBytes(msg, localFileBackedMimeBodyPart);
    localFileBackedMimeBodyPart.dispose();
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
    localSMIMESignedParser.close();
  }
  
  public void testSHA1WithRSAEncapsulatedParserAndFile()
    throws Exception
  {
    File localFile = File.createTempFile("bcTest", ".mime");
    MimeBodyPart localMimeBodyPart = generateEncapsulatedRsa(SMIMESignedGenerator.DIGEST_SHA1, msg);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeBodyPart, localFile);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = (FileBackedMimeBodyPart)localSMIMESignedParser.getContent();
    verifyMessageBytes(msg, localSMIMESignedParser.getContent());
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
    assertTrue(localFile.exists());
    localSMIMESignedParser.close();
    localFileBackedMimeBodyPart.dispose();
    assertFalse(localFile.exists());
  }
  
  public void testMD5WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_MD5, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("md5", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), PKCSObjectIdentifiers.md5.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA224WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA224, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("sha224", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), NISTObjectIdentifiers.id_sha224.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA256WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA256, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("sha256", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), NISTObjectIdentifiers.id_sha256.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA384WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA384, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("sha384", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), NISTObjectIdentifiers.id_sha384.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA512WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA512, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("sha512", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), NISTObjectIdentifiers.id_sha512.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testRIPEMD160WithRSA()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_RIPEMD160, msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("unknown", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), TeleTrusTObjectIdentifiers.ripemd160.toString());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testGOST3411WithGOST3410()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartGost(msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("gostr3411-94", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), CryptoProObjectIdentifiers.gostR3411.getId());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testGOST3411WithECGOST3410()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartECGost(msg);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    assertEquals("gostr3411-94", getMicAlg(localMimeMultipart));
    assertEquals(getDigestOid(localSMIMESigned.getSignerInfos()), CryptoProObjectIdentifiers.gostR3411.getId());
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA224WithRSAParser()
    throws Exception
  {
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA224, msg);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeMultipart);
    CertStore localCertStore = localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC");
    assertEquals(getDigestOid(localSMIMESignedParser.getSignerInfos()), NISTObjectIdentifiers.id_sha224.toString());
    verifyMessageBytes(msg, localSMIMESignedParser.getContent());
    verifySigners(localCertStore, localSMIMESignedParser.getSignerInfos());
  }
  
  public void testSHA224WithRSAParserEncryptedWithDES()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA224, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(msg, "BC");
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeMultipart);
    localCertStore = localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC");
    assertEquals(getDigestOid(localSMIMESignedParser.getSignerInfos()), NISTObjectIdentifiers.id_sha224.toString());
    verifyMessageBytes(msg, localSMIMESignedParser.getContent());
    verifySigners(localCertStore, localSMIMESignedParser.getSignerInfos());
  }
  
  public void testSHA1withDSA()
    throws Exception
  {
    this.dsaSignKP = CMSTestUtil.makeDsaKeyPair();
    this.dsaSignCert = CMSTestUtil.makeCertificate(this.dsaSignKP, _origDN, this.dsaSignKP, _origDN);
    this.dsaOrigKP = CMSTestUtil.makeDsaKeyPair();
    this.dsaOrigCert = CMSTestUtil.makeCertificate(this.dsaOrigKP, _signDN, this.dsaSignKP, _origDN);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(this.dsaOrigCert);
    localArrayList.add(this.dsaSignCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(this.dsaOrigKP.getPrivate(), this.dsaOrigCert, SMIMESignedGenerator.DIGEST_SHA1);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(msg, "BC");
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA256WithRSABinary()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = generateBinaryPart();
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA256, localMimeBodyPart);
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    verifyMessageBytes(localMimeBodyPart, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA256WithRSABinaryWithParser()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = generateBinaryPart();
    MimeMultipart localMimeMultipart = generateMultiPartRsa(SMIMESignedGenerator.DIGEST_SHA256, localMimeBodyPart);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeMultipart);
    verifyMessageBytes(localMimeBodyPart, localSMIMESignedParser.getContent());
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
  }
  
  public void testWithAttributeCertificate()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA256, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    X509AttributeCertificate localX509AttributeCertificate = CMSTestUtil.getAttributeCertificate();
    X509Store localX509Store1 = X509Store.getInstance("AttributeCertificate/Collection", new X509CollectionStoreParameters(Collections.singleton(localX509AttributeCertificate)), "BC");
    localSMIMESignedGenerator.addAttributeCertificates(localX509Store1);
    SMIMESigned localSMIMESigned = new SMIMESigned(localSMIMESignedGenerator.generateEncapsulated(msg, "BC"));
    verifyMessageBytes(msg, localSMIMESigned.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
    X509Store localX509Store2 = localSMIMESigned.getAttributeCertificates("Collection", "BC");
    assertTrue(localX509Store2.getMatches(null).contains(localX509AttributeCertificate));
  }
  
  private MimeBodyPart generateBinaryPart()
    throws MessagingException
  {
    byte[] arrayOfByte = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 13, 14, 10, 10, 15, 16 };
    InternetHeaders localInternetHeaders = new InternetHeaders();
    localInternetHeaders.setHeader("Content-Transfer-Encoding", "binary");
    return new MimeBodyPart(localInternetHeaders, arrayOfByte);
  }
  
  private MimeMultipart generateMultiPartRsa(String paramString, MimeBodyPart paramMimeBodyPart, Date paramDate)
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    if (paramDate != null) {
      localASN1EncodableVector.add(new Attribute(CMSAttributes.signingTime, new DERSet(new Time(paramDate))));
    }
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, paramString, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    return localSMIMESignedGenerator.generate(paramMimeBodyPart, "BC");
  }
  
  private MimeMultipart generateMultiPartGost(MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_signGostCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signGostKP.getPrivate(), _signGostCert, SMIMESignedGenerator.DIGEST_GOST3411);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    return localSMIMESignedGenerator.generate(paramMimeBodyPart, "BC");
  }
  
  private MimeMultipart generateMultiPartECGost(MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_signEcGostCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signEcGostKP.getPrivate(), _signEcGostCert, SMIMESignedGenerator.DIGEST_GOST3411);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    return localSMIMESignedGenerator.generate(paramMimeBodyPart, "BC");
  }
  
  private MimeMultipart generateMultiPartRsa(String paramString, MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    return generateMultiPartRsa(paramString, paramMimeBodyPart, null);
  }
  
  private MimeBodyPart generateEncapsulatedRsa(String paramString, MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, paramString, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    return localSMIMESignedGenerator.generateEncapsulated(paramMimeBodyPart, "BC");
  }
  
  public void testCertificateManagement()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeBodyPart localMimeBodyPart = localSMIMESignedGenerator.generateCertificateManagement("BC");
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeBodyPart);
    localCertStore = localSMIMESigned.getCertificatesAndCRLs("Collection", "BC");
    assertEquals(2, localCertStore.getCertificates(null).size());
  }
  
  public void testMimeMultipart()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = createMultipartMessage();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator("binary");
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart);
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
    byte[] arrayOfByte = (byte[])localSMIMESignedGenerator.getGeneratedDigests().get(SMIMESignedGenerator.DIGEST_SHA1);
    AttributeTable localAttributeTable = ((SignerInformation)localSMIMESigned.getSignerInfos().getSigners().iterator().next()).getSignedAttributes();
    Attribute localAttribute = localAttributeTable.get(CMSAttributes.messageDigest);
    assertTrue(MessageDigest.isEqual(arrayOfByte, ((ASN1OctetString)localAttribute.getAttrValues().getObjectAt(0)).getOctets()));
  }
  
  public void testMimeMultipartBinaryReader()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = createMultipartMessage();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator("binary");
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart, "binary");
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testMimeMultipartBinaryParser()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = createMultipartMessage();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(_signCert);
    localArrayList.add(_origCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator("binary");
    localSMIMESignedGenerator.addSigner(_signKP.getPrivate(), _signCert, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser(localMimeMultipart, "binary");
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
  }
  
  private MimeBodyPart createMultipartMessage()
    throws MessagingException
  {
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setText("Hello part 1!\n");
    MimeBodyPart localMimeBodyPart2 = new MimeBodyPart();
    localMimeBodyPart2.setText("Hello part 2!\n");
    MimeMultipart localMimeMultipart = new MimeMultipart();
    localMimeMultipart.addBodyPart(localMimeBodyPart1);
    localMimeMultipart.addBodyPart(localMimeBodyPart2);
    MimeBodyPart localMimeBodyPart3 = new MimeBodyPart();
    localMimeBodyPart3.setContent(localMimeMultipart);
    return localMimeBodyPart3;
  }
  
  public void testQuotable()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("quotable.message");
    SMIMESigned localSMIMESigned = new SMIMESigned((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testQuotableParser()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("quotable.message");
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
  }
  
  public void testEmbeddedMulti()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("embeddedmulti.message");
    SMIMESigned localSMIMESigned = new SMIMESigned((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testEmbeddedMultiParser()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("embeddedmulti.message");
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
  }
  
  public void testBasicAS2()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("basicAS2.message");
    SMIMESigned localSMIMESigned = new SMIMESigned((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESigned.getCertificatesAndCRLs("Collection", "BC"), localSMIMESigned.getSignerInfos());
  }
  
  public void testBasicAS2Parser()
    throws Exception
  {
    MimeMessage localMimeMessage = loadMessage("basicAS2.message");
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
    verifySigners(localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC"), localSMIMESignedParser.getSignerInfos());
  }
  
  private String getDigestOid(SignerInformationStore paramSignerInformationStore)
  {
    return ((SignerInformation)paramSignerInformationStore.getSigners().iterator().next()).getDigestAlgOID();
  }
  
  private void verifySigners(CertStore paramCertStore, SignerInformationStore paramSignerInformationStore)
    throws Exception
  {
    Collection localCollection1 = paramSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = paramCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
  
  private void verifyMessageBytes(MimeBodyPart paramMimeBodyPart1, MimeBodyPart paramMimeBodyPart2)
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    paramMimeBodyPart1.writeTo(localByteArrayOutputStream1);
    localByteArrayOutputStream1.close();
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    paramMimeBodyPart2.writeTo(localByteArrayOutputStream2);
    localByteArrayOutputStream2.close();
    assertEquals(true, Arrays.equals(localByteArrayOutputStream1.toByteArray(), localByteArrayOutputStream2.toByteArray()));
  }
  
  private ASN1EncodableVector generateSignedAttributes()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
    return localASN1EncodableVector;
  }
  
  private MimeMessage loadMessage(String paramString)
    throws MessagingException, FileNotFoundException
  {
    Session localSession = Session.getDefaultInstance(System.getProperties(), null);
    return new MimeMessage(localSession, getClass().getResourceAsStream(paramString));
  }
  
  private MimeBodyPart createTemplate(String paramString1, String paramString2)
    throws UnsupportedEncodingException, MessagingException
  {
    byte[] arrayOfByte = "<?xml version=\"1.0\"?>\n<INVOICE_CENTER>\n  <CONTENT_FRAME>\n</CONTENT_FRAME>\n</INVOICE_CENTER>\n".getBytes("US-ASCII");
    InternetHeaders localInternetHeaders = new InternetHeaders();
    localInternetHeaders.setHeader("Content-Type", paramString1);
    localInternetHeaders.setHeader("Content-Transfer-Encoding", paramString2);
    return new MimeBodyPart(localInternetHeaders, arrayOfByte);
  }
  
  private String getMicAlg(MimeMultipart paramMimeMultipart)
  {
    String str1 = paramMimeMultipart.getContentType();
    String str2 = str1.substring(str1.indexOf("micalg=") + 7);
    return str2.substring(0, str2.indexOf(';'));
  }
  
  static
  {
    try
    {
      msg = SMIMETestUtil.makeMimeBodyPart("Hello world!\n");
      msgR = SMIMETestUtil.makeMimeBodyPart("Hello world!\r");
      msgRN = SMIMETestUtil.makeMimeBodyPart("Hello world!\r\n");
      _origDN = "O=Bouncy Castle, C=AU";
      _origKP = CMSTestUtil.makeKeyPair();
      _origCert = CMSTestUtil.makeCertificate(_origKP, _origDN, _origKP, _origDN);
      _signDN = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _signCert = CMSTestUtil.makeCertificate(_signKP, _signDN, _origKP, _origDN);
      _signGostKP = CMSTestUtil.makeGostKeyPair();
      _signGostCert = CMSTestUtil.makeCertificate(_signGostKP, _signDN, _origKP, _origDN);
      _signEcDsaKP = CMSTestUtil.makeEcDsaKeyPair();
      _signEcDsaCert = CMSTestUtil.makeCertificate(_signEcDsaKP, _signDN, _origKP, _origDN);
      _signEcGostKP = CMSTestUtil.makeEcGostKeyPair();
      _signEcGostCert = CMSTestUtil.makeCertificate(_signEcGostKP, _signDN, _origKP, _origDN);
    }
    catch (Exception localException)
    {
      throw new RuntimeException("problem setting up signed test class: " + localException);
    }
  }
  
  private static class LineOutputStream
    extends FilterOutputStream
  {
    private static byte[] newline = new byte[2];
    
    public LineOutputStream(OutputStream paramOutputStream)
    {
      super();
    }
    
    public void writeln(String paramString)
      throws MessagingException
    {
      try
      {
        byte[] arrayOfByte = getBytes(paramString);
        this.out.write(arrayOfByte);
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }
    
    public void writeln()
      throws MessagingException
    {
      try
      {
        this.out.write(newline);
      }
      catch (Exception localException)
      {
        throw new MessagingException("IOException", localException);
      }
    }
    
    private static byte[] getBytes(String paramString)
    {
      char[] arrayOfChar = paramString.toCharArray();
      int i = arrayOfChar.length;
      byte[] arrayOfByte = new byte[i];
      int j = 0;
      while (j < i) {
        arrayOfByte[j] = ((byte)arrayOfChar[(j++)]);
      }
      return arrayOfByte;
    }
    
    static
    {
      newline[0] = 13;
      newline[1] = 10;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMESignedTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */