package org.bouncycastle.mail.smime.test;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.KeyPair;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.cms.CMSTypedStream;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.test.CMSTestUtil;
import org.bouncycastle.mail.smime.SMIMECompressed;
import org.bouncycastle.mail.smime.SMIMECompressedGenerator;
import org.bouncycastle.mail.smime.SMIMECompressedParser;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.util.Arrays;

public class SMIMECompressedTest
  extends TestCase
{
  private static final String COMPRESSED_CONTENT_TYPE = "application/pkcs7-mime; name=\"smime.p7z\"; smime-type=compressed-data";
  boolean DEBUG = true;
  MimeBodyPart msg = SMIMETestUtil.makeMimeBodyPart("Hello world!");
  String signDN = "O=Bouncy Castle, C=AU";
  KeyPair signKP = CMSTestUtil.makeKeyPair();
  X509Certificate signCert = CMSTestUtil.makeCertificate(this.signKP, this.signDN, this.signKP, this.signDN);
  String origDN = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
  KeyPair origKP = CMSTestUtil.makeKeyPair();
  X509Certificate origCert = CMSTestUtil.makeCertificate(this.origKP, this.origDN, this.signKP, this.signDN);
  String reciDN;
  KeyPair reciKP;
  X509Certificate reciCert;
  KeyPair dsaSignKP;
  X509Certificate dsaSignCert;
  KeyPair dsaOrigKP;
  X509Certificate dsaOrigCert;
  
  public SMIMECompressedTest(String paramString)
    throws Exception
  {
    super(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(SMIMECompressedTest.class);
  }
  
  public static Test suite()
  {
    return new SMIMETestSetup(new TestSuite(SMIMECompressedTest.class));
  }
  
  public void testHeaders()
    throws Exception
  {
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(this.msg, "1.2.840.113549.1.9.16.3.8");
    assertEquals("application/pkcs7-mime; name=\"smime.p7z\"; smime-type=compressed-data", localMimeBodyPart.getHeader("Content-Type")[0]);
    assertEquals("attachment; filename=\"smime.p7z\"", localMimeBodyPart.getHeader("Content-Disposition")[0]);
    assertEquals("S/MIME Compressed Message", localMimeBodyPart.getHeader("Content-Description")[0]);
  }
  
  public void testBasic()
    throws Exception
  {
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(this.msg, "1.2.840.113549.1.9.16.3.8");
    SMIMECompressed localSMIMECompressed = new SMIMECompressed(localMimeBodyPart);
    this.msg.writeTo(localByteArrayOutputStream);
    assertTrue(Arrays.areEqual(localByteArrayOutputStream.toByteArray(), localSMIMECompressed.getContent()));
  }
  
  public void testParser()
    throws Exception
  {
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(this.msg, "1.2.840.113549.1.9.16.3.8");
    SMIMECompressedParser localSMIMECompressedParser = new SMIMECompressedParser(localMimeBodyPart);
    this.msg.writeTo(localByteArrayOutputStream1);
    InputStream localInputStream = localSMIMECompressedParser.getContent().getContentStream();
    int i;
    while ((i = localInputStream.read()) >= 0) {
      localByteArrayOutputStream2.write(i);
    }
    assertTrue(Arrays.areEqual(localByteArrayOutputStream1.toByteArray(), localByteArrayOutputStream2.toByteArray()));
  }
  
  public void testCompressedSHA1WithRSA()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(this.origCert);
    localArrayList.add(this.signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(this.origKP.getPrivate(), this.origCert, SMIMESignedGenerator.DIGEST_SHA1, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart1 = localSMIMESignedGenerator.generate(this.msg, "BC");
    MimeMessage localMimeMessage = new MimeMessage((Session)null);
    localMimeMessage.setContent(localMimeMultipart1);
    localMimeMessage.saveChanges();
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(localMimeMessage, "1.2.840.113549.1.9.16.3.8");
    SMIMECompressed localSMIMECompressed = new SMIMECompressed(localMimeBodyPart);
    MimeMultipart localMimeMultipart2 = (MimeMultipart)SMIMEUtil.toMimeBodyPart(localSMIMECompressed.getContent()).getContent();
    SMIMESigned localSMIMESigned = new SMIMESigned(localMimeMultipart2);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    this.msg.writeTo(localByteArrayOutputStream);
    localByteArrayOutputStream.close();
    byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    localSMIMESigned.getContent().writeTo(localByteArrayOutputStream);
    localByteArrayOutputStream.close();
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    assertEquals(true, Arrays.areEqual(arrayOfByte1, arrayOfByte2));
    localCertStore = localSMIMESigned.getCertificatesAndCRLs("Collection", "BC");
    SignerInformationStore localSignerInformationStore = localSMIMESigned.getSignerInfos();
    Collection localCollection1 = localSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = localCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMECompressedTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */