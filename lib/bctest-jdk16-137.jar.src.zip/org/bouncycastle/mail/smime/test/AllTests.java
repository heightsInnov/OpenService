package org.bouncycastle.mail.smime.test;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class AllTests
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("SMIME tests");
    localTestSuite.addTest(SMIMESignedTest.suite());
    localTestSuite.addTest(SignedMailValidatorTest.suite());
    localTestSuite.addTest(SMIMEEnvelopedTest.suite());
    localTestSuite.addTest(SMIMECompressedTest.suite());
    localTestSuite.addTest(SMIMEMiscTest.suite());
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\AllTests.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */