package org.bouncycastle.mail.smime.test;

import java.io.InputStream;
import java.security.Security;
import java.security.cert.CertPath;
import java.security.cert.CertStore;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.PKIXParameters;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.i18n.ErrorBundle;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.validator.SignedMailValidator;
import org.bouncycastle.mail.smime.validator.SignedMailValidator.ValidationResult;
import org.bouncycastle.x509.PKIXCertPathReviewer;
import org.bouncycastle.x509.extension.X509ExtensionUtil;

public class SignedMailValidatorTest
  extends TestCase
{
  static String TEST_TRUST_ACHOR = "validator.root.crt";
  
  public void testShortKey()
    throws Exception
  {
    String str = "validator.shortKey.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getNotifications(), "SignedMailValidator.shortSigningKey", "Warning: The signing key is only 512 bits long.");
  }
  
  public void testKeyUsage()
    throws Exception
  {
    String str = "validator.keyUsage.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertTrue(localValidationResult.getCertPathReview().isValidCertPath());
    assertFalse(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getErrors(), "SignedMailValidator.signingNotPermitted", "The key usage extension of signer certificate does not permit using the key for email signatures.");
  }
  
  public void testExtKeyUsage()
    throws Exception
  {
    String str = "validator.extKeyUsage.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertTrue(localValidationResult.getCertPathReview().isValidCertPath());
    assertFalse(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getErrors(), "SignedMailValidator.extKeyUsageNotPermitted", "The extended key usage extension of the signer certificate does not permit using the key for email signatures.");
  }
  
  public void testNoEmail()
    throws Exception
  {
    String str = "validator.noEmail.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertTrue(localValidationResult.getCertPathReview().isValidCertPath());
    assertFalse(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getErrors(), "SignedMailValidator.noEmailInCert", "The signer certificate is not usable for email signatures: it contains no email address.");
  }
  
  public void testNotYetValid()
    throws Exception
  {
    String str = "validator.notYetValid.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertFalse(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getErrors(), "SignedMailValidator.certNotYetValid", "The message was signed at Aug 28, 2006 3:04:01 PM GMT. But the certificate is not valid before Dec 28, 2006 2:19:31 PM GMT.");
    PKIXCertPathReviewer localPKIXCertPathReviewer = localValidationResult.getCertPathReview();
    assertFalse(localPKIXCertPathReviewer.isValidCertPath());
    assertContainsMessage(localPKIXCertPathReviewer.getErrors(0), "CertPathReviewer.certificateNotYetValid", "Could not validate the certificate. Certificate is not valid until Dec 28, 2006 2:19:31 PM GMT.");
  }
  
  public void testExpired()
    throws Exception
  {
    String str = "validator.expired.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertFalse(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getErrors(), "SignedMailValidator.certExpired", "The message was signed at Sep 1, 2006 9:08:35 AM GMT. But the certificate expired at Sep 1, 2006 8:39:20 AM GMT.");
    PKIXCertPathReviewer localPKIXCertPathReviewer = localValidationResult.getCertPathReview();
    assertFalse(localPKIXCertPathReviewer.isValidCertPath());
    assertContainsMessage(localPKIXCertPathReviewer.getErrors(0), "CertPathReviewer.certificateExpired", "Could not validate the certificate. Certificate expired on Sep 1, 2006 8:39:20 AM GMT.");
  }
  
  public void testRevoked()
    throws Exception
  {
    String str = "validator.revoked.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(loadCRL("validator.revoked.crl"));
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList));
    localPKIXParameters.addCertStore(localCertStore);
    localPKIXParameters.setRevocationEnabled(true);
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertFalse(localValidationResult.isValidSignature());
    PKIXCertPathReviewer localPKIXCertPathReviewer = localValidationResult.getCertPathReview();
    assertFalse(localPKIXCertPathReviewer.isValidCertPath());
    assertContainsMessage(localPKIXCertPathReviewer.getErrors(0), "CertPathReviewer.certRevoked", "The certificate was revoked at Sep 1, 2006 9:30:00 AM GMT. Reason: Key Compromise.");
  }
  
  public void testLongValidity()
    throws Exception
  {
    String str = "validator.longValidity.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertTrue(localValidationResult.isValidSignature());
    assertContainsMessage(localValidationResult.getNotifications(), "SignedMailValidator.longValidity", "Warning: The signing certificate has a very long validity period: from Sep 1, 2006 11:00:00 AM GMT until Aug 8, 2106 11:00:00 AM GMT.");
  }
  
  public void testCorrputRootStore()
    throws Exception
  {
    String str = "validator.validMail.eml";
    HashSet localHashSet = new HashSet();
    localHashSet.add(getTrustAnchor(TEST_TRUST_ACHOR));
    localHashSet.add(getTrustAnchor("validator.fakeRoot.crt"));
    PKIXParameters localPKIXParameters = new PKIXParameters(localHashSet);
    localPKIXParameters.setRevocationEnabled(false);
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertFalse(localValidationResult.isValidSignature());
    PKIXCertPathReviewer localPKIXCertPathReviewer = localValidationResult.getCertPathReview();
    assertFalse(localPKIXCertPathReviewer.isValidCertPath());
    assertContainsMessage(localPKIXCertPathReviewer.getErrors(-1), "CertPathReviewer.conflictingTrustAnchors", "Warning: corrupt trust root store: There are 2 trusted public keys for the CA \"CN=SignedMailValidatorTest Root, C=CH\" - please ensure with CA which is the correct key.");
  }
  
  public void testCircular()
    throws Exception
  {
    String str = "circular.eml";
    PKIXParameters localPKIXParameters = createDefaultParams();
    SignedMailValidator.ValidationResult localValidationResult = doTest(str, localPKIXParameters);
    assertTrue(localValidationResult.isVerifiedSignature());
    assertFalse(localValidationResult.isValidSignature());
    assertFalse(localValidationResult.getCertPathReview().isValidCertPath());
    assertTrue("cert path size", localValidationResult.getCertPathReview().getCertPathSize() > 2);
  }
  
  public void testExtendedReviewer()
    throws Exception
  {
    Session localSession;
    MimeMessage localMimeMessage;
    SignedMailValidator localSignedMailValidator;
    try
    {
      Properties localProperties1 = System.getProperties();
      localSession = Session.getDefaultInstance(localProperties1, null);
      localMimeMessage = new MimeMessage(localSession, getClass().getResourceAsStream("validator.shortKey.eml"));
      localSignedMailValidator = new SignedMailValidator(localMimeMessage, createDefaultParams(), String.class);
      fail();
    }
    catch (IllegalArgumentException localIllegalArgumentException1)
    {
      assertTrue(localIllegalArgumentException1.getMessage().startsWith("certPathReviewerClass is not a subclass of"));
    }
    try
    {
      Properties localProperties2 = System.getProperties();
      localSession = Session.getDefaultInstance(localProperties2, null);
      localMimeMessage = new MimeMessage(localSession, getClass().getResourceAsStream("validator.shortKey.eml"));
      localSignedMailValidator = new SignedMailValidator(localMimeMessage, createDefaultParams(), DummyCertPathReviewer.class);
      SignerInformation localSignerInformation = (SignerInformation)localSignedMailValidator.getSignerInformationStore().getSigners().iterator().next();
      SignedMailValidator.ValidationResult localValidationResult = localSignedMailValidator.getValidationResult(localSignerInformation);
      assertTrue(localValidationResult.isValidSignature());
      assertContainsMessage(localValidationResult.getNotifications(), "SignedMailValidator.shortSigningKey", "Warning: The signing key is only 512 bits long.");
    }
    catch (IllegalArgumentException localIllegalArgumentException2)
    {
      fail();
    }
  }
  
  public void testCreateCertPath()
    throws Exception
  {
    HashSet localHashSet = new HashSet();
    TrustAnchor localTrustAnchor = getTrustAnchor("certpath_root.crt");
    localHashSet.add(localTrustAnchor);
    X509Certificate localX509Certificate1 = localTrustAnchor.getTrustedCert();
    X509Certificate localX509Certificate2 = loadCert("certpath_inter1.crt");
    X509Certificate localX509Certificate3 = loadCert("certpath_inter2.crt");
    X509Certificate localX509Certificate4 = loadCert("certpath_end1.crt");
    X509Certificate localX509Certificate5 = loadCert("certpath_end2.crt");
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    localArrayList2.add(localX509Certificate2);
    localArrayList2.add(localX509Certificate3);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList2));
    localArrayList1.add(localCertStore);
    CertPath localCertPath = SignedMailValidator.createCertPath(localX509Certificate4, localHashSet, localArrayList1);
    assertTrue("path size is not 3", localCertPath.getCertificates().size() == 3);
    assertEquals("different end certificate", localCertPath.getCertificates().get(0), localX509Certificate4);
    assertEquals("different intermediate certificate", localCertPath.getCertificates().get(1), localX509Certificate2);
    assertEquals("different root certificate", localCertPath.getCertificates().get(2), localX509Certificate1);
    localCertPath = SignedMailValidator.createCertPath(localX509Certificate5, localHashSet, localArrayList1);
    assertTrue("path size is not 3", localCertPath.getCertificates().size() == 3);
    assertEquals("different end certificate", localCertPath.getCertificates().get(0), localX509Certificate5);
    assertEquals("different intermediate certificate", localCertPath.getCertificates().get(1), localX509Certificate3);
    assertEquals("different root certificate", localCertPath.getCertificates().get(2), localX509Certificate1);
  }
  
  private SignedMailValidator.ValidationResult doTest(String paramString, PKIXParameters paramPKIXParameters)
    throws Exception
  {
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    MimeMessage localMimeMessage = new MimeMessage(localSession, getClass().getResourceAsStream(paramString));
    SignedMailValidator localSignedMailValidator = new SignedMailValidator(localMimeMessage, paramPKIXParameters);
    SignerInformation localSignerInformation = (SignerInformation)localSignedMailValidator.getSignerInformationStore().getSigners().iterator().next();
    return localSignedMailValidator.getValidationResult(localSignerInformation);
  }
  
  private void assertContainsMessage(List paramList, String paramString1, String paramString2)
    throws Exception
  {
    Iterator localIterator = paramList.iterator();
    boolean bool = false;
    while (localIterator.hasNext())
    {
      ErrorBundle localErrorBundle = (ErrorBundle)localIterator.next();
      if (localErrorBundle.getId().equals(paramString1))
      {
        bool = true;
        assertEquals(paramString2, localErrorBundle.getText(Locale.ENGLISH, TimeZone.getTimeZone("GMT")));
        break;
      }
    }
    assertTrue("Expected message not found!", bool);
  }
  
  private PKIXParameters createDefaultParams()
    throws Exception
  {
    HashSet localHashSet = new HashSet();
    localHashSet.add(getTrustAnchor(TEST_TRUST_ACHOR));
    PKIXParameters localPKIXParameters = new PKIXParameters(localHashSet);
    localPKIXParameters.setRevocationEnabled(false);
    return localPKIXParameters;
  }
  
  private TrustAnchor getTrustAnchor(String paramString)
    throws Exception
  {
    X509Certificate localX509Certificate = loadCert(paramString);
    if (localX509Certificate != null)
    {
      byte[] arrayOfByte = localX509Certificate.getExtensionValue(X509Extensions.NameConstraints.getId());
      if (arrayOfByte != null)
      {
        ASN1Encodable localASN1Encodable = X509ExtensionUtil.fromExtensionValue(arrayOfByte);
        return new TrustAnchor(localX509Certificate, localASN1Encodable.getDEREncoded());
      }
      return new TrustAnchor(localX509Certificate, null);
    }
    return null;
  }
  
  private X509Certificate loadCert(String paramString)
    throws Exception
  {
    X509Certificate localX509Certificate = null;
    InputStream localInputStream = getClass().getResourceAsStream(paramString);
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509", "BC");
    localX509Certificate = (X509Certificate)localCertificateFactory.generateCertificate(localInputStream);
    return localX509Certificate;
  }
  
  private X509CRL loadCRL(String paramString)
    throws Exception
  {
    X509CRL localX509CRL = null;
    InputStream localInputStream = getClass().getResourceAsStream(paramString);
    CertificateFactory localCertificateFactory = CertificateFactory.getInstance("x.509", "BC");
    localX509CRL = (X509CRL)localCertificateFactory.generateCRL(localInputStream);
    return localX509CRL;
  }
  
  public void setUp()
  {
    if (Security.getProvider("BC") == null) {
      Security.addProvider(new BouncyCastleProvider());
    }
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    TestRunner.run(suite());
  }
  
  public static Test suite()
    throws Exception
  {
    TestSuite localTestSuite = new TestSuite("SignedMailValidator Tests");
    localTestSuite.addTestSuite(SignedMailValidatorTest.class);
    return localTestSuite;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SignedMailValidatorTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */