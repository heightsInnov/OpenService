package org.bouncycastle.mail.smime.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyPair;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.cms.AttributeTable;
import org.bouncycastle.asn1.smime.SMIMECapabilitiesAttribute;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.cms.test.CMSTestUtil;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMECompressedGenerator;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMESigned;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.mail.smime.SMIMESignedParser;

public class SMIMEMiscTest
  extends TestCase
{
  static MimeBodyPart msg;
  static String signDN;
  static KeyPair signKP;
  static X509Certificate signCert;
  static String origDN;
  static KeyPair origKP;
  static X509Certificate origCert;
  static String reciDN;
  static KeyPair reciKP;
  static X509Certificate reciCert;
  KeyPair dsaSignKP;
  X509Certificate dsaSignCert;
  KeyPair dsaOrigKP;
  X509Certificate dsaOrigCert;
  
  public SMIMEMiscTest(String paramString)
  {
    super(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Security.addProvider(new BouncyCastleProvider());
    TestRunner.run(SMIMEMiscTest.class);
  }
  
  public static Test suite()
  {
    return new SMIMETestSetup(new TestSuite(SMIMEMiscTest.class));
  }
  
  public void testSHA256WithRSAParserEncryptedWithAES()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(origCert);
    localArrayList.add(signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(origCert);
    MimeBodyPart localMimeBodyPart = localSMIMEEnvelopedGenerator.generate(msg, SMIMEEnvelopedGenerator.AES128_CBC, "BC");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(origKP.getPrivate(), origCert, SMIMESignedGenerator.DIGEST_SHA256, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    File localFile = File.createTempFile("bcTest", ".mime");
    MimeMessage localMimeMessage = createMimeMessage(localFile, localMimeMultipart);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
    localCertStore = localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC");
    verifyMessageBytes(localMimeBodyPart, localSMIMESignedParser.getContent());
    verifySigners(localCertStore, localSMIMESignedParser.getSignerInfos());
    localFile.delete();
  }
  
  public void testSHA256WithRSACompressed()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(origCert);
    localArrayList.add(signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(msg, "1.2.840.113549.1.9.16.3.8");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(origKP.getPrivate(), origCert, SMIMESignedGenerator.DIGEST_SHA256, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    File localFile = File.createTempFile("bcTest", ".mime");
    MimeMessage localMimeMessage = createMimeMessage(localFile, localMimeMultipart);
    SMIMESigned localSMIMESigned = new SMIMESigned((MimeMultipart)localMimeMessage.getContent());
    localCertStore = localSMIMESigned.getCertificatesAndCRLs("Collection", "BC");
    verifyMessageBytes(localMimeBodyPart, localSMIMESigned.getContent());
    verifySigners(localCertStore, localSMIMESigned.getSignerInfos());
  }
  
  public void testSHA256WithRSAParserCompressed()
    throws Exception
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(origCert);
    localArrayList.add(signCert);
    CertStore localCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(localArrayList), "BC");
    SMIMECompressedGenerator localSMIMECompressedGenerator = new SMIMECompressedGenerator();
    MimeBodyPart localMimeBodyPart = localSMIMECompressedGenerator.generate(msg, "1.2.840.113549.1.9.16.3.8");
    ASN1EncodableVector localASN1EncodableVector = generateSignedAttributes();
    SMIMESignedGenerator localSMIMESignedGenerator = new SMIMESignedGenerator();
    localSMIMESignedGenerator.addSigner(origKP.getPrivate(), origCert, SMIMESignedGenerator.DIGEST_SHA256, new AttributeTable(localASN1EncodableVector), null);
    localSMIMESignedGenerator.addCertificatesAndCRLs(localCertStore);
    MimeMultipart localMimeMultipart = localSMIMESignedGenerator.generate(localMimeBodyPart, "BC");
    File localFile = File.createTempFile("bcTest", ".mime");
    MimeMessage localMimeMessage = createMimeMessage(localFile, localMimeMultipart);
    SMIMESignedParser localSMIMESignedParser = new SMIMESignedParser((MimeMultipart)localMimeMessage.getContent());
    localCertStore = localSMIMESignedParser.getCertificatesAndCRLs("Collection", "BC");
    verifyMessageBytes(localMimeBodyPart, localSMIMESignedParser.getContent());
    verifySigners(localCertStore, localSMIMESignedParser.getSignerInfos());
  }
  
  private void verifySigners(CertStore paramCertStore, SignerInformationStore paramSignerInformationStore)
    throws Exception
  {
    Collection localCollection1 = paramSignerInformationStore.getSigners();
    Iterator localIterator1 = localCollection1.iterator();
    while (localIterator1.hasNext())
    {
      SignerInformation localSignerInformation = (SignerInformation)localIterator1.next();
      Collection localCollection2 = paramCertStore.getCertificates(localSignerInformation.getSID());
      Iterator localIterator2 = localCollection2.iterator();
      X509Certificate localX509Certificate = (X509Certificate)localIterator2.next();
      assertEquals(true, localSignerInformation.verify(localX509Certificate, "BC"));
    }
  }
  
  private void verifyMessageBytes(MimeBodyPart paramMimeBodyPart1, MimeBodyPart paramMimeBodyPart2)
    throws Exception
  {
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    paramMimeBodyPart1.writeTo(localByteArrayOutputStream1);
    localByteArrayOutputStream1.close();
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    paramMimeBodyPart2.writeTo(localByteArrayOutputStream2);
    localByteArrayOutputStream2.close();
    assertEquals(true, Arrays.equals(localByteArrayOutputStream1.toByteArray(), localByteArrayOutputStream2.toByteArray()));
  }
  
  private MimeMessage createMimeMessage(File paramFile, MimeMultipart paramMimeMultipart)
    throws Exception
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
    Properties localProperties = System.getProperties();
    Session localSession = Session.getDefaultInstance(localProperties, null);
    InternetAddress localInternetAddress1 = new InternetAddress("\"Eric H. Echidna\"<eric@bouncycastle.org>");
    InternetAddress localInternetAddress2 = new InternetAddress("example@bouncycastle.org");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    localMimeMessage.setFrom(localInternetAddress1);
    localMimeMessage.setRecipient(Message.RecipientType.TO, localInternetAddress2);
    localMimeMessage.setSubject("example signed message");
    localMimeMessage.setContent(paramMimeMultipart, paramMimeMultipart.getContentType());
    localMimeMessage.saveChanges();
    localMimeMessage.writeTo(localFileOutputStream);
    localFileOutputStream.close();
    return new MimeMessage(localSession, new FileInputStream(paramFile));
  }
  
  private ASN1EncodableVector generateSignedAttributes()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    SMIMECapabilityVector localSMIMECapabilityVector = new SMIMECapabilityVector();
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_EDE3_CBC);
    localSMIMECapabilityVector.addCapability(SMIMECapability.rC2_CBC, 128);
    localSMIMECapabilityVector.addCapability(SMIMECapability.dES_CBC);
    localASN1EncodableVector.add(new SMIMECapabilitiesAttribute(localSMIMECapabilityVector));
    return localASN1EncodableVector;
  }
  
  static
  {
    try
    {
      msg = SMIMETestUtil.makeMimeBodyPart("Hello world!\n");
      signDN = "O=Bouncy Castle, C=AU";
      signKP = CMSTestUtil.makeKeyPair();
      signCert = CMSTestUtil.makeCertificate(signKP, signDN, signKP, signDN);
      origDN = "CN=Eric H. Echidna, E=eric@bouncycastle.org, O=Bouncy Castle, C=AU";
      origKP = CMSTestUtil.makeKeyPair();
      origCert = CMSTestUtil.makeCertificate(origKP, origDN, signKP, signDN);
    }
    catch (Exception localException)
    {
      throw new RuntimeException("problem setting up signed test class: " + localException);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMEMiscTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */