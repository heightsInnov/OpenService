package org.bouncycastle.mail.smime.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.bouncycastle.cms.RecipientId;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.cms.test.CMSTestUtil;
import org.bouncycastle.jce.PrincipalUtil;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.mail.smime.SMIMEEnveloped;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMEEnvelopedParser;
import org.bouncycastle.mail.smime.SMIMEUtil;
import org.bouncycastle.mail.smime.util.FileBackedMimeBodyPart;

public class SMIMEEnvelopedTest
  extends TestCase
{
  private static String _signDN;
  private static KeyPair _signKP;
  private static String _reciDN;
  private static KeyPair _reciKP;
  private static X509Certificate _reciCert;
  private static String _reciDN2;
  private static KeyPair _reciKP2;
  private static X509Certificate _reciCert2;
  private static boolean _initialised = false;
  
  private static void init()
    throws Exception
  {
    if (!_initialised)
    {
      _initialised = true;
      _signDN = "O=Bouncy Castle, C=AU";
      _signKP = CMSTestUtil.makeKeyPair();
      _reciDN = "CN=Doug, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP = CMSTestUtil.makeKeyPair();
      _reciCert = CMSTestUtil.makeCertificate(_reciKP, _reciDN, _signKP, _signDN);
      _reciDN2 = "CN=Fred, OU=Sales, O=Bouncy Castle, C=AU";
      _reciKP2 = CMSTestUtil.makeKeyPair();
      _reciCert2 = CMSTestUtil.makeCertificate(_reciKP2, _reciDN2, _signKP, _signDN);
    }
  }
  
  public SMIMEEnvelopedTest(String paramString)
  {
    super(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    TestRunner.run(SMIMEEnvelopedTest.class);
  }
  
  public static Test suite()
    throws Exception
  {
    return new SMIMETestSetup(new TestSuite(SMIMEEnvelopedTest.class));
  }
  
  public void setUp()
    throws Exception
  {}
  
  public void testHeaders()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert);
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.DES_EDE3_CBC, "BC");
    assertEquals("application/pkcs7-mime; name=\"smime.p7m\"; smime-type=enveloped-data", localMimeBodyPart2.getHeader("Content-Type")[0]);
    assertEquals("attachment; filename=\"smime.p7m\"", localMimeBodyPart2.getHeader("Content-Disposition")[0]);
    assertEquals("S/MIME Encrypted Message", localMimeBodyPart2.getHeader("Content-Description")[0]);
  }
  
  public void testDESEDE3Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.DES_EDE3_CBC;
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testParserDESEDE3Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.DES_EDE3_CBC;
    verifyParserAlgorithm(str, localMimeBodyPart);
  }
  
  public void testIDEAEncrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = "1.3.6.1.4.1.188.7.1.1.2";
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testRC2Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.RC2_CBC;
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testCASTEncrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = "1.2.840.113533.7.66.10";
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testAES128Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.AES128_CBC;
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testAES192Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.AES192_CBC;
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testAES256Encrypted()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    String str = SMIMEEnvelopedGenerator.AES256_CBC;
    verifyAlgorithm(str, localMimeBodyPart);
  }
  
  public void testSubKeyId()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    localMessageDigest.update(_reciCert.getPublicKey().getEncoded());
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert.getPublicKey(), localMessageDigest.digest());
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.DES_EDE3_CBC, "BC");
    SMIMEEnveloped localSMIMEEnveloped = new SMIMEEnveloped(localMimeBodyPart2);
    RecipientId localRecipientId = new RecipientId();
    localMessageDigest.update(_reciCert.getPublicKey().getEncoded());
    localRecipientId.setSubjectKeyIdentifier(localMessageDigest.digest());
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnveloped.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    MimeBodyPart localMimeBodyPart3 = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContent(_reciKP.getPrivate(), "BC"));
    verifyMessageBytes(localMimeBodyPart1, localMimeBodyPart3);
  }
  
  public void testCapEncrypt()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1", "BC");
    localMessageDigest.update(_reciCert.getPublicKey().getEncoded());
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert.getPublicKey(), localMessageDigest.digest());
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.RC2_CBC, 40, "BC");
    SMIMEEnveloped localSMIMEEnveloped = new SMIMEEnveloped(localMimeBodyPart2);
    RecipientId localRecipientId = new RecipientId();
    localMessageDigest.update(_reciCert.getPublicKey().getEncoded());
    localRecipientId.setSubjectKeyIdentifier(localMessageDigest.digest());
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnveloped.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    MimeBodyPart localMimeBodyPart3 = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContent(_reciKP.getPrivate(), "BC"));
    verifyMessageBytes(localMimeBodyPart1, localMimeBodyPart3);
  }
  
  public void testTwoRecipients()
    throws Exception
  {
    MimeBodyPart localMimeBodyPart1 = SMIMETestUtil.makeMimeBodyPart("WallaWallaWashington");
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert);
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert2);
    MimeBodyPart localMimeBodyPart2 = localSMIMEEnvelopedGenerator.generate(localMimeBodyPart1, SMIMEEnvelopedGenerator.RC2_CBC, 40, "BC");
    SMIMEEnvelopedParser localSMIMEEnvelopedParser = new SMIMEEnvelopedParser(localMimeBodyPart2);
    RecipientId localRecipientId = getRecipientId(_reciCert2);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnvelopedParser.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    FileBackedMimeBodyPart localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContentStream(_reciKP2.getPrivate(), "BC"));
    verifyMessageBytes(localMimeBodyPart1, localFileBackedMimeBodyPart);
    localSMIMEEnvelopedParser = new SMIMEEnvelopedParser(localMimeBodyPart2);
    localFileBackedMimeBodyPart.dispose();
    localRecipientId = getRecipientId(_reciCert);
    localRecipientInformationStore = localSMIMEEnvelopedParser.getRecipientInfos();
    localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    localFileBackedMimeBodyPart = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContentStream(_reciKP.getPrivate(), "BC"));
    verifyMessageBytes(localMimeBodyPart1, localFileBackedMimeBodyPart);
    localFileBackedMimeBodyPart.dispose();
  }
  
  private void verifyAlgorithm(String paramString, MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert);
    MimeBodyPart localMimeBodyPart1 = localSMIMEEnvelopedGenerator.generate(paramMimeBodyPart, paramString, "BC");
    SMIMEEnveloped localSMIMEEnveloped = new SMIMEEnveloped(localMimeBodyPart1);
    RecipientId localRecipientId = getRecipientId(_reciCert);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnveloped.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    MimeBodyPart localMimeBodyPart2 = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContent(_reciKP.getPrivate(), "BC"));
    verifyMessageBytes(paramMimeBodyPart, localMimeBodyPart2);
  }
  
  private void verifyParserAlgorithm(String paramString, MimeBodyPart paramMimeBodyPart)
    throws Exception
  {
    SMIMEEnvelopedGenerator localSMIMEEnvelopedGenerator = new SMIMEEnvelopedGenerator();
    localSMIMEEnvelopedGenerator.addKeyTransRecipient(_reciCert);
    MimeBodyPart localMimeBodyPart1 = localSMIMEEnvelopedGenerator.generate(paramMimeBodyPart, paramString, "BC");
    SMIMEEnvelopedParser localSMIMEEnvelopedParser = new SMIMEEnvelopedParser(localMimeBodyPart1);
    RecipientId localRecipientId = getRecipientId(_reciCert);
    RecipientInformationStore localRecipientInformationStore = localSMIMEEnvelopedParser.getRecipientInfos();
    RecipientInformation localRecipientInformation = localRecipientInformationStore.get(localRecipientId);
    MimeBodyPart localMimeBodyPart2 = SMIMEUtil.toMimeBodyPart(localRecipientInformation.getContent(_reciKP.getPrivate(), "BC"));
    verifyMessageBytes(paramMimeBodyPart, localMimeBodyPart2);
  }
  
  private RecipientId getRecipientId(X509Certificate paramX509Certificate)
    throws IOException, CertificateEncodingException
  {
    RecipientId localRecipientId = new RecipientId();
    localRecipientId.setSerialNumber(paramX509Certificate.getSerialNumber());
    localRecipientId.setIssuer(PrincipalUtil.getIssuerX509Principal(paramX509Certificate).getEncoded());
    return localRecipientId;
  }
  
  private void verifyMessageBytes(MimeBodyPart paramMimeBodyPart1, MimeBodyPart paramMimeBodyPart2)
    throws IOException, MessagingException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    paramMimeBodyPart1.writeTo(localByteArrayOutputStream);
    localByteArrayOutputStream.close();
    byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
    localByteArrayOutputStream = new ByteArrayOutputStream();
    paramMimeBodyPart2.writeTo(localByteArrayOutputStream);
    localByteArrayOutputStream.close();
    byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
    assertEquals(true, Arrays.equals(arrayOfByte1, arrayOfByte2));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMEEnvelopedTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */