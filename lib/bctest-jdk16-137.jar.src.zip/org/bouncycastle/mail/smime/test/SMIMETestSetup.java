package org.bouncycastle.mail.smime.test;

import java.security.Security;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import junit.extensions.TestSetup;
import junit.framework.Test;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

class SMIMETestSetup
  extends TestSetup
{
  private CommandMap originalMap = null;
  
  public SMIMETestSetup(Test paramTest)
  {
    super(paramTest);
  }
  
  protected void setUp()
  {
    Security.addProvider(new BouncyCastleProvider());
    MailcapCommandMap localMailcapCommandMap = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
    localMailcapCommandMap.addMailcap("application/pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.pkcs7_mime");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-signature;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_signature");
    localMailcapCommandMap.addMailcap("application/x-pkcs7-mime;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.x_pkcs7_mime");
    localMailcapCommandMap.addMailcap("multipart/signed;; x-java-content-handler=org.bouncycastle.mail.smime.handlers.multipart_signed");
    this.originalMap = CommandMap.getDefaultCommandMap();
    CommandMap.setDefaultCommandMap(localMailcapCommandMap);
  }
  
  protected void tearDown()
  {
    CommandMap.setDefaultCommandMap(this.originalMap);
    this.originalMap = null;
    Security.removeProvider("BC");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bctest-jdk16-137.jar!\org\bouncycastle\mail\smime\test\SMIMETestSetup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */