package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.CipherParameters;

public class ParametersWithSalt
  implements CipherParameters
{
  private byte[] salt;
  private CipherParameters parameters;
  
  public ParametersWithSalt(CipherParameters paramCipherParameters, byte[] paramArrayOfByte)
  {
    this(paramCipherParameters, paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public ParametersWithSalt(CipherParameters paramCipherParameters, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.salt = new byte[paramInt2];
    this.parameters = paramCipherParameters;
    System.arraycopy(paramArrayOfByte, paramInt1, this.salt, 0, paramInt2);
  }
  
  public byte[] getSalt()
  {
    return this.salt;
  }
  
  public CipherParameters getParameters()
  {
    return this.parameters;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\ParametersWithSalt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */