package org.bouncycastle.crypto.params;

import org.bouncycastle.util.Arrays;

public class DSAValidationParameters
{
  private byte[] seed;
  private int counter;
  
  public DSAValidationParameters(byte[] paramArrayOfByte, int paramInt)
  {
    this.seed = paramArrayOfByte;
    this.counter = paramInt;
  }
  
  public int getCounter()
  {
    return this.counter;
  }
  
  public byte[] getSeed()
  {
    return this.seed;
  }
  
  public int hashCode()
  {
    return this.counter ^ Arrays.hashCode(this.seed);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DSAValidationParameters)) {
      return false;
    }
    DSAValidationParameters localDSAValidationParameters = (DSAValidationParameters)paramObject;
    if (localDSAValidationParameters.counter != this.counter) {
      return false;
    }
    return Arrays.areEqual(this.seed, localDSAValidationParameters.seed);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\DSAValidationParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */