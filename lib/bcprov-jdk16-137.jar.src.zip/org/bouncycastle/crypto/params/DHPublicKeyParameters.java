package org.bouncycastle.crypto.params;

import java.math.BigInteger;

public class DHPublicKeyParameters
  extends DHKeyParameters
{
  private BigInteger y;
  
  public DHPublicKeyParameters(BigInteger paramBigInteger, DHParameters paramDHParameters)
  {
    super(false, paramDHParameters);
    this.y = paramBigInteger;
  }
  
  public BigInteger getY()
  {
    return this.y;
  }
  
  public int hashCode()
  {
    return this.y.hashCode() ^ super.hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DHPublicKeyParameters)) {
      return false;
    }
    DHPublicKeyParameters localDHPublicKeyParameters = (DHPublicKeyParameters)paramObject;
    return (localDHPublicKeyParameters.getY().equals(this.y)) && (super.equals(paramObject));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\DHPublicKeyParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */