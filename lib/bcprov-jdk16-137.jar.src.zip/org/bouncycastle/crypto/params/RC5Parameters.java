package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.CipherParameters;

public class RC5Parameters
  implements CipherParameters
{
  private byte[] key;
  private int rounds;
  
  public RC5Parameters(byte[] paramArrayOfByte, int paramInt)
  {
    if (paramArrayOfByte.length > 255) {
      throw new IllegalArgumentException("RC5 key length can be no greater than 255");
    }
    this.key = new byte[paramArrayOfByte.length];
    this.rounds = paramInt;
    System.arraycopy(paramArrayOfByte, 0, this.key, 0, paramArrayOfByte.length);
  }
  
  public byte[] getKey()
  {
    return this.key;
  }
  
  public int getRounds()
  {
    return this.rounds;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\RC5Parameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */