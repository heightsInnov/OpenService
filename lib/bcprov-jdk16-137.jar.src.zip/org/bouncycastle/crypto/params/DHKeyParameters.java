package org.bouncycastle.crypto.params;

public class DHKeyParameters
  extends AsymmetricKeyParameter
{
  private DHParameters params;
  
  protected DHKeyParameters(boolean paramBoolean, DHParameters paramDHParameters)
  {
    super(paramBoolean);
    this.params = paramDHParameters;
  }
  
  public DHParameters getParameters()
  {
    return this.params;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DHKeyParameters)) {
      return false;
    }
    DHKeyParameters localDHKeyParameters = (DHKeyParameters)paramObject;
    if (this.params == null) {
      return localDHKeyParameters.getParameters() == null;
    }
    return this.params.equals(localDHKeyParameters.getParameters());
  }
  
  public int hashCode()
  {
    int i = isPrivate() ? 0 : 1;
    if (this.params != null) {
      i ^= this.params.hashCode();
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\DHKeyParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */