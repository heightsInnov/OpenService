package org.bouncycastle.crypto.params;

public class ElGamalKeyParameters
  extends AsymmetricKeyParameter
{
  private ElGamalParameters params;
  
  protected ElGamalKeyParameters(boolean paramBoolean, ElGamalParameters paramElGamalParameters)
  {
    super(paramBoolean);
    this.params = paramElGamalParameters;
  }
  
  public ElGamalParameters getParameters()
  {
    return this.params;
  }
  
  public int hashCode()
  {
    return this.params != null ? this.params.hashCode() : 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ElGamalKeyParameters)) {
      return false;
    }
    ElGamalKeyParameters localElGamalKeyParameters = (ElGamalKeyParameters)paramObject;
    if (this.params == null) {
      return localElGamalKeyParameters.getParameters() == null;
    }
    return this.params.equals(localElGamalKeyParameters.getParameters());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\ElGamalKeyParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */