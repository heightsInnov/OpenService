package org.bouncycastle.crypto.params;

public class DESedeParameters
  extends DESParameters
{
  public static final int DES_EDE_KEY_LENGTH = 24;
  
  public DESedeParameters(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
    if (isWeakKey(paramArrayOfByte, 0, paramArrayOfByte.length)) {
      throw new IllegalArgumentException("attempt to create weak DESede key");
    }
  }
  
  public static boolean isWeakKey(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    for (int i = paramInt1; i < paramInt2; i += 8) {
      if (DESParameters.isWeakKey(paramArrayOfByte, i)) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean isWeakKey(byte[] paramArrayOfByte, int paramInt)
  {
    return isWeakKey(paramArrayOfByte, paramInt, paramArrayOfByte.length - paramInt);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\DESedeParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */