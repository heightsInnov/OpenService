package org.bouncycastle.crypto.params;

import java.math.BigInteger;

public class RSAKeyParameters
  extends AsymmetricKeyParameter
{
  private BigInteger modulus;
  private BigInteger exponent;
  
  public RSAKeyParameters(boolean paramBoolean, BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    super(paramBoolean);
    this.modulus = paramBigInteger1;
    this.exponent = paramBigInteger2;
  }
  
  public BigInteger getModulus()
  {
    return this.modulus;
  }
  
  public BigInteger getExponent()
  {
    return this.exponent;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\RSAKeyParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */