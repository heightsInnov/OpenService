package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.DerivationParameters;

public class ISO18033KDFParameters
  implements DerivationParameters
{
  byte[] seed;
  
  public ISO18033KDFParameters(byte[] paramArrayOfByte)
  {
    this.seed = paramArrayOfByte;
  }
  
  public byte[] getSeed()
  {
    return this.seed;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\ISO18033KDFParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */