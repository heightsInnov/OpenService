package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.CipherParameters;

public class RC2Parameters
  implements CipherParameters
{
  private byte[] key;
  private int bits;
  
  public RC2Parameters(byte[] paramArrayOfByte)
  {
    this(paramArrayOfByte, paramArrayOfByte.length > 128 ? 1024 : paramArrayOfByte.length * 8);
  }
  
  public RC2Parameters(byte[] paramArrayOfByte, int paramInt)
  {
    this.key = new byte[paramArrayOfByte.length];
    this.bits = paramInt;
    System.arraycopy(paramArrayOfByte, 0, this.key, 0, paramArrayOfByte.length);
  }
  
  public byte[] getKey()
  {
    return this.key;
  }
  
  public int getEffectiveKeyBits()
  {
    return this.bits;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\RC2Parameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */