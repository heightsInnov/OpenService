package org.bouncycastle.crypto.params;

public class CCMParameters
  extends AEADParameters
{
  public CCMParameters(KeyParameter paramKeyParameter, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    super(paramKeyParameter, paramInt, paramArrayOfByte1, paramArrayOfByte2);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\CCMParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */