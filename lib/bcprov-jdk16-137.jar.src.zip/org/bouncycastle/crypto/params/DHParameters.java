package org.bouncycastle.crypto.params;

import java.math.BigInteger;
import org.bouncycastle.crypto.CipherParameters;

public class DHParameters
  implements CipherParameters
{
  private BigInteger g;
  private BigInteger p;
  private BigInteger q;
  private int j;
  private DHValidationParameters validation;
  
  public DHParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
  }
  
  public DHParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
    this.q = paramBigInteger3;
  }
  
  public DHParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, int paramInt)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
    this.q = paramBigInteger3;
    this.j = paramInt;
  }
  
  public DHParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, int paramInt, DHValidationParameters paramDHValidationParameters)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
    this.q = paramBigInteger3;
    this.j = paramInt;
    this.validation = paramDHValidationParameters;
  }
  
  public BigInteger getP()
  {
    return this.p;
  }
  
  public BigInteger getG()
  {
    return this.g;
  }
  
  public BigInteger getQ()
  {
    return this.q;
  }
  
  public int getJ()
  {
    return this.j;
  }
  
  public DHValidationParameters getValidationParameters()
  {
    return this.validation;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DHParameters)) {
      return false;
    }
    DHParameters localDHParameters = (DHParameters)paramObject;
    if (getQ() != null)
    {
      if (!getQ().equals(localDHParameters.getQ())) {
        return false;
      }
    }
    else if (localDHParameters.getQ() != null) {
      return false;
    }
    return (this.j == localDHParameters.getJ()) && (localDHParameters.getP().equals(this.p)) && (localDHParameters.getG().equals(this.g));
  }
  
  public int hashCode()
  {
    return getJ() ^ getP().hashCode() ^ getG().hashCode() ^ (getQ() != null ? getQ().hashCode() : 0);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\DHParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */