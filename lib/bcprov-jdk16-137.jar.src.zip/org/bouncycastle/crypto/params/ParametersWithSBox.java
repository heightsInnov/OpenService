package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.CipherParameters;

public class ParametersWithSBox
  implements CipherParameters
{
  private CipherParameters parameters;
  private byte[] sBox;
  
  public ParametersWithSBox(CipherParameters paramCipherParameters, byte[] paramArrayOfByte)
  {
    this.parameters = paramCipherParameters;
    this.sBox = paramArrayOfByte;
  }
  
  public byte[] getSBox()
  {
    return this.sBox;
  }
  
  public CipherParameters getParameters()
  {
    return this.parameters;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\ParametersWithSBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */