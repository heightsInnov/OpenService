package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.CipherParameters;

public class AEADParameters
  implements CipherParameters
{
  private byte[] associatedText;
  private byte[] nonce;
  private KeyParameter key;
  private int macSize;
  
  public AEADParameters(KeyParameter paramKeyParameter, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.key = paramKeyParameter;
    this.nonce = paramArrayOfByte1;
    this.macSize = paramInt;
    this.associatedText = paramArrayOfByte2;
  }
  
  public KeyParameter getKey()
  {
    return this.key;
  }
  
  public int getMacSize()
  {
    return this.macSize;
  }
  
  public byte[] getAssociatedText()
  {
    return this.associatedText;
  }
  
  public byte[] getNonce()
  {
    return this.nonce;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\AEADParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */