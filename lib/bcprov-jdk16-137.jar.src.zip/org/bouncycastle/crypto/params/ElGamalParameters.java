package org.bouncycastle.crypto.params;

import java.math.BigInteger;
import org.bouncycastle.crypto.CipherParameters;

public class ElGamalParameters
  implements CipherParameters
{
  private BigInteger g;
  private BigInteger p;
  private int l;
  
  public ElGamalParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
  }
  
  public ElGamalParameters(BigInteger paramBigInteger1, BigInteger paramBigInteger2, int paramInt)
  {
    this.g = paramBigInteger2;
    this.p = paramBigInteger1;
    this.l = paramInt;
  }
  
  public BigInteger getP()
  {
    return this.p;
  }
  
  public BigInteger getG()
  {
    return this.g;
  }
  
  public int getL()
  {
    return this.l;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ElGamalParameters)) {
      return false;
    }
    ElGamalParameters localElGamalParameters = (ElGamalParameters)paramObject;
    return (localElGamalParameters.getP().equals(this.p)) && (localElGamalParameters.getG().equals(this.g)) && (localElGamalParameters.getL() == this.l);
  }
  
  public int hashCode()
  {
    return (getP().hashCode() ^ getG().hashCode()) + this.l;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\ElGamalParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */