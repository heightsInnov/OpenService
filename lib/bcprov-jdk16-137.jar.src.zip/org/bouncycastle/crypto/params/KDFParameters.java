package org.bouncycastle.crypto.params;

import org.bouncycastle.crypto.DerivationParameters;

public class KDFParameters
  implements DerivationParameters
{
  byte[] iv;
  byte[] shared;
  
  public KDFParameters(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.shared = paramArrayOfByte1;
    this.iv = paramArrayOfByte2;
  }
  
  public byte[] getSharedSecret()
  {
    return this.shared;
  }
  
  public byte[] getIV()
  {
    return this.iv;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\params\KDFParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */