package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;

public class TEAEngine
  implements BlockCipher
{
  private static final int rounds = 32;
  private static final int block_size = 8;
  private static final int key_size = 16;
  private static final int delta = -1640531527;
  private static final int d_sum = -957401312;
  private int _a;
  private int _b;
  private int _c;
  private int _d;
  private boolean _initialised = false;
  private boolean _forEncryption;
  
  public String getAlgorithmName()
  {
    return "TEA";
  }
  
  public int getBlockSize()
  {
    return 8;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("invalid parameter passed to TEA init - " + paramCipherParameters.getClass().getName());
    }
    this._forEncryption = paramBoolean;
    this._initialised = true;
    KeyParameter localKeyParameter = (KeyParameter)paramCipherParameters;
    setKey(localKeyParameter.getKey());
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (!this._initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + 8 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 8 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    return this._forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset() {}
  
  private void setKey(byte[] paramArrayOfByte)
  {
    this._a = bytesToInt(paramArrayOfByte, 0);
    this._b = bytesToInt(paramArrayOfByte, 4);
    this._c = bytesToInt(paramArrayOfByte, 8);
    this._d = bytesToInt(paramArrayOfByte, 12);
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = bytesToInt(paramArrayOfByte1, paramInt1);
    int j = bytesToInt(paramArrayOfByte1, paramInt1 + 4);
    int k = 0;
    for (int m = 0; m != 32; m++)
    {
      k -= 1640531527;
      i += ((j << 4) + this._a ^ j + k ^ (j >>> 5) + this._b);
      j += ((i << 4) + this._c ^ i + k ^ (i >>> 5) + this._d);
    }
    unpackInt(i, paramArrayOfByte2, paramInt2);
    unpackInt(j, paramArrayOfByte2, paramInt2 + 4);
    return 8;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = bytesToInt(paramArrayOfByte1, paramInt1);
    int j = bytesToInt(paramArrayOfByte1, paramInt1 + 4);
    int k = -957401312;
    for (int m = 0; m != 32; m++)
    {
      j -= ((i << 4) + this._c ^ i + k ^ (i >>> 5) + this._d);
      i -= ((j << 4) + this._a ^ j + k ^ (j >>> 5) + this._b);
      k += 1640531527;
    }
    unpackInt(i, paramArrayOfByte2, paramInt2);
    unpackInt(j, paramArrayOfByte2, paramInt2 + 4);
    return 8;
  }
  
  private int bytesToInt(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt++)] << 24 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 16 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 8 | paramArrayOfByte[paramInt] & 0xFF;
  }
  
  private void unpackInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 24));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 16));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 8));
    paramArrayOfByte[paramInt2] = ((byte)paramInt1);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\TEAEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */