package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;

public class IDEAEngine
  implements BlockCipher
{
  protected static final int BLOCK_SIZE = 8;
  private int[] workingKey = null;
  private static final int MASK = 65535;
  private static final int BASE = 65537;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if ((paramCipherParameters instanceof KeyParameter))
    {
      this.workingKey = generateWorkingKey(paramBoolean, ((KeyParameter)paramCipherParameters).getKey());
      return;
    }
    throw new IllegalArgumentException("invalid parameter passed to IDEA init - " + paramCipherParameters.getClass().getName());
  }
  
  public String getAlgorithmName()
  {
    return "IDEA";
  }
  
  public int getBlockSize()
  {
    return 8;
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (this.workingKey == null) {
      throw new IllegalStateException("IDEA engine not initialised");
    }
    if (paramInt1 + 8 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 8 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    ideaFunc(this.workingKey, paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    return 8;
  }
  
  public void reset() {}
  
  private int bytesToWord(byte[] paramArrayOfByte, int paramInt)
  {
    return (paramArrayOfByte[paramInt] << 8 & 0xFF00) + (paramArrayOfByte[(paramInt + 1)] & 0xFF);
  }
  
  private void wordToBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[paramInt2] = ((byte)(paramInt1 >>> 8));
    paramArrayOfByte[(paramInt2 + 1)] = ((byte)paramInt1);
  }
  
  private int mul(int paramInt1, int paramInt2)
  {
    if (paramInt1 == 0)
    {
      paramInt1 = 65537 - paramInt2;
    }
    else if (paramInt2 == 0)
    {
      paramInt1 = 65537 - paramInt1;
    }
    else
    {
      int i = paramInt1 * paramInt2;
      paramInt2 = i & 0xFFFF;
      paramInt1 = i >>> 16;
      paramInt1 = paramInt2 - paramInt1 + (paramInt2 < paramInt1 ? 1 : 0);
    }
    return paramInt1 & 0xFFFF;
  }
  
  private void ideaFunc(int[] paramArrayOfInt, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i2 = 0;
    int i = bytesToWord(paramArrayOfByte1, paramInt1);
    int j = bytesToWord(paramArrayOfByte1, paramInt1 + 2);
    int k = bytesToWord(paramArrayOfByte1, paramInt1 + 4);
    int m = bytesToWord(paramArrayOfByte1, paramInt1 + 6);
    for (int i3 = 0; i3 < 8; i3++)
    {
      i = mul(i, paramArrayOfInt[(i2++)]);
      j += paramArrayOfInt[(i2++)];
      j &= 0xFFFF;
      k += paramArrayOfInt[(i2++)];
      k &= 0xFFFF;
      m = mul(m, paramArrayOfInt[(i2++)]);
      int n = j;
      int i1 = k;
      k ^= i;
      j ^= m;
      k = mul(k, paramArrayOfInt[(i2++)]);
      j += k;
      j &= 0xFFFF;
      j = mul(j, paramArrayOfInt[(i2++)]);
      k += j;
      k &= 0xFFFF;
      i ^= j;
      m ^= k;
      j ^= i1;
      k ^= n;
    }
    wordToBytes(mul(i, paramArrayOfInt[(i2++)]), paramArrayOfByte2, paramInt2);
    wordToBytes(k + paramArrayOfInt[(i2++)], paramArrayOfByte2, paramInt2 + 2);
    wordToBytes(j + paramArrayOfInt[(i2++)], paramArrayOfByte2, paramInt2 + 4);
    wordToBytes(mul(m, paramArrayOfInt[i2]), paramArrayOfByte2, paramInt2 + 6);
  }
  
  private int[] expandKey(byte[] paramArrayOfByte)
  {
    int[] arrayOfInt = new int[52];
    if (paramArrayOfByte.length < 16)
    {
      byte[] arrayOfByte = new byte[16];
      System.arraycopy(paramArrayOfByte, 0, arrayOfByte, arrayOfByte.length - paramArrayOfByte.length, paramArrayOfByte.length);
      paramArrayOfByte = arrayOfByte;
    }
    for (int i = 0; i < 8; i++) {
      arrayOfInt[i] = bytesToWord(paramArrayOfByte, i * 2);
    }
    for (i = 8; i < 52; i++) {
      if ((i & 0x7) < 6) {
        arrayOfInt[i] = (((arrayOfInt[(i - 7)] & 0x7F) << 9 | arrayOfInt[(i - 6)] >> 7) & 0xFFFF);
      } else if ((i & 0x7) == 6) {
        arrayOfInt[i] = (((arrayOfInt[(i - 7)] & 0x7F) << 9 | arrayOfInt[(i - 14)] >> 7) & 0xFFFF);
      } else {
        arrayOfInt[i] = (((arrayOfInt[(i - 15)] & 0x7F) << 9 | arrayOfInt[(i - 14)] >> 7) & 0xFFFF);
      }
    }
    return arrayOfInt;
  }
  
  private int mulInv(int paramInt)
  {
    if (paramInt < 2) {
      return paramInt;
    }
    int i = 1;
    int j = 65537 / paramInt;
    int m = 65537 % paramInt;
    while (m != 1)
    {
      int k = paramInt / m;
      paramInt %= m;
      i = i + j * k & 0xFFFF;
      if (paramInt == 1) {
        return i;
      }
      k = m / paramInt;
      m %= paramInt;
      j = j + i * k & 0xFFFF;
    }
    return 1 - j & 0xFFFF;
  }
  
  int addInv(int paramInt)
  {
    return 0 - paramInt & 0xFFFF;
  }
  
  private int[] invertKey(int[] paramArrayOfInt)
  {
    int n = 52;
    int[] arrayOfInt = new int[52];
    int i1 = 0;
    int i = mulInv(paramArrayOfInt[(i1++)]);
    int j = addInv(paramArrayOfInt[(i1++)]);
    int k = addInv(paramArrayOfInt[(i1++)]);
    int m = mulInv(paramArrayOfInt[(i1++)]);
    arrayOfInt[(--n)] = m;
    arrayOfInt[(--n)] = k;
    arrayOfInt[(--n)] = j;
    arrayOfInt[(--n)] = i;
    for (int i2 = 1; i2 < 8; i2++)
    {
      i = paramArrayOfInt[(i1++)];
      j = paramArrayOfInt[(i1++)];
      arrayOfInt[(--n)] = j;
      arrayOfInt[(--n)] = i;
      i = mulInv(paramArrayOfInt[(i1++)]);
      j = addInv(paramArrayOfInt[(i1++)]);
      k = addInv(paramArrayOfInt[(i1++)]);
      m = mulInv(paramArrayOfInt[(i1++)]);
      arrayOfInt[(--n)] = m;
      arrayOfInt[(--n)] = j;
      arrayOfInt[(--n)] = k;
      arrayOfInt[(--n)] = i;
    }
    i = paramArrayOfInt[(i1++)];
    j = paramArrayOfInt[(i1++)];
    arrayOfInt[(--n)] = j;
    arrayOfInt[(--n)] = i;
    i = mulInv(paramArrayOfInt[(i1++)]);
    j = addInv(paramArrayOfInt[(i1++)]);
    k = addInv(paramArrayOfInt[(i1++)]);
    m = mulInv(paramArrayOfInt[i1]);
    arrayOfInt[(--n)] = m;
    arrayOfInt[(--n)] = k;
    arrayOfInt[(--n)] = j;
    arrayOfInt[(--n)] = i;
    return arrayOfInt;
  }
  
  private int[] generateWorkingKey(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    if (paramBoolean) {
      return expandKey(paramArrayOfByte);
    }
    return invertKey(expandKey(paramArrayOfByte));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\IDEAEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */