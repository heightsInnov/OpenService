package org.bouncycastle.crypto.engines;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.ElGamalKeyParameters;
import org.bouncycastle.crypto.params.ElGamalParameters;
import org.bouncycastle.crypto.params.ElGamalPrivateKeyParameters;
import org.bouncycastle.crypto.params.ElGamalPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.util.BigIntegers;

public class ElGamalEngine
  implements AsymmetricBlockCipher
{
  private ElGamalKeyParameters key;
  private SecureRandom random;
  private boolean forEncryption;
  private int bitSize;
  private static final BigInteger ZERO = BigInteger.valueOf(0L);
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.key = ((ElGamalKeyParameters)localParametersWithRandom.getParameters());
      this.random = localParametersWithRandom.getRandom();
    }
    else
    {
      this.key = ((ElGamalKeyParameters)paramCipherParameters);
      this.random = new SecureRandom();
    }
    this.forEncryption = paramBoolean;
    this.bitSize = this.key.getParameters().getP().bitLength();
    if (paramBoolean)
    {
      if (!(this.key instanceof ElGamalPublicKeyParameters)) {
        throw new IllegalArgumentException("ElGamalPublicKeyParameters are required for encryption.");
      }
    }
    else if (!(this.key instanceof ElGamalPrivateKeyParameters)) {
      throw new IllegalArgumentException("ElGamalPrivateKeyParameters are required for decryption.");
    }
  }
  
  public int getInputBlockSize()
  {
    if (this.forEncryption) {
      return (this.bitSize - 1) / 8;
    }
    return 2 * ((this.bitSize + 7) / 8);
  }
  
  public int getOutputBlockSize()
  {
    if (this.forEncryption) {
      return 2 * ((this.bitSize + 7) / 8);
    }
    return (this.bitSize - 1) / 8;
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (this.key == null) {
      throw new IllegalStateException("ElGamal engine not initialised");
    }
    int i = this.forEncryption ? (this.bitSize - 1 + 7) / 8 : getInputBlockSize();
    if (paramInt2 > i) {
      throw new DataLengthException("input too large for ElGamal cipher.\n");
    }
    BigInteger localBigInteger1 = this.key.getParameters().getP();
    byte[] arrayOfByte1;
    if ((this.key instanceof ElGamalPrivateKeyParameters))
    {
      arrayOfByte1 = new byte[paramInt2 / 2];
      localObject1 = new byte[paramInt2 / 2];
      System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, arrayOfByte1.length);
      System.arraycopy(paramArrayOfByte, paramInt1 + arrayOfByte1.length, localObject1, 0, localObject1.length);
      localObject2 = new BigInteger(1, arrayOfByte1);
      BigInteger localBigInteger2 = new BigInteger(1, (byte[])localObject1);
      localObject3 = (ElGamalPrivateKeyParameters)this.key;
      localBigInteger3 = ((BigInteger)localObject2).modPow(localBigInteger1.subtract(ONE).subtract(((ElGamalPrivateKeyParameters)localObject3).getX()), localBigInteger1).multiply(localBigInteger2).mod(localBigInteger1);
      return BigIntegers.asUnsignedByteArray(localBigInteger3);
    }
    if ((paramInt1 != 0) || (paramInt2 != paramArrayOfByte.length))
    {
      arrayOfByte1 = new byte[paramInt2];
      System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, paramInt2);
    }
    else
    {
      arrayOfByte1 = paramArrayOfByte;
    }
    Object localObject1 = new BigInteger(1, arrayOfByte1);
    if (((BigInteger)localObject1).bitLength() >= localBigInteger1.bitLength()) {
      throw new DataLengthException("input too large for ElGamal cipher.\n");
    }
    Object localObject2 = (ElGamalPublicKeyParameters)this.key;
    int j = localBigInteger1.bitLength();
    for (Object localObject3 = new BigInteger(j, this.random); (((BigInteger)localObject3).equals(ZERO)) || (((BigInteger)localObject3).compareTo(localBigInteger1.subtract(TWO)) > 0); localObject3 = new BigInteger(j, this.random)) {}
    BigInteger localBigInteger3 = this.key.getParameters().getG();
    BigInteger localBigInteger4 = localBigInteger3.modPow((BigInteger)localObject3, localBigInteger1);
    BigInteger localBigInteger5 = ((BigInteger)localObject1).multiply(((ElGamalPublicKeyParameters)localObject2).getY().modPow((BigInteger)localObject3, localBigInteger1)).mod(localBigInteger1);
    byte[] arrayOfByte2 = localBigInteger4.toByteArray();
    byte[] arrayOfByte3 = localBigInteger5.toByteArray();
    byte[] arrayOfByte4 = new byte[getOutputBlockSize()];
    if (arrayOfByte2.length > arrayOfByte4.length / 2) {
      System.arraycopy(arrayOfByte2, 1, arrayOfByte4, arrayOfByte4.length / 2 - (arrayOfByte2.length - 1), arrayOfByte2.length - 1);
    } else {
      System.arraycopy(arrayOfByte2, 0, arrayOfByte4, arrayOfByte4.length / 2 - arrayOfByte2.length, arrayOfByte2.length);
    }
    if (arrayOfByte3.length > arrayOfByte4.length / 2) {
      System.arraycopy(arrayOfByte3, 1, arrayOfByte4, arrayOfByte4.length - (arrayOfByte3.length - 1), arrayOfByte3.length - 1);
    } else {
      System.arraycopy(arrayOfByte3, 0, arrayOfByte4, arrayOfByte4.length - arrayOfByte3.length, arrayOfByte3.length);
    }
    return arrayOfByte4;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\ElGamalEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */