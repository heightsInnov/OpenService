package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.params.KeyParameter;

public class ISAACEngine
  implements StreamCipher
{
  private final int sizeL = 8;
  private final int stateArraySize = 256;
  private int[] engineState = null;
  private int[] results = null;
  private int a = 0;
  private int b = 0;
  private int c = 0;
  private int index = 0;
  private byte[] keyStream = new byte['Ѐ'];
  private byte[] workingKey = null;
  private boolean initialised = false;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("invalid parameter passed to ISAAC init - " + paramCipherParameters.getClass().getName());
    }
    KeyParameter localKeyParameter = (KeyParameter)paramCipherParameters;
    setKey(localKeyParameter.getKey());
  }
  
  public byte returnByte(byte paramByte)
  {
    if (this.index == 0)
    {
      isaac();
      this.keyStream = intToByteLittle(this.results);
    }
    byte b1 = (byte)(this.keyStream[this.index] ^ paramByte);
    this.index = (this.index + 1 & 0x3FF);
    return b1;
  }
  
  public void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    if (!this.initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < paramInt2; i++)
    {
      if (this.index == 0)
      {
        isaac();
        this.keyStream = intToByteLittle(this.results);
      }
      paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.keyStream[this.index] ^ paramArrayOfByte1[(i + paramInt1)]));
      this.index = (this.index + 1 & 0x3FF);
    }
  }
  
  public String getAlgorithmName()
  {
    return "ISAAC";
  }
  
  public void reset()
  {
    setKey(this.workingKey);
  }
  
  private void setKey(byte[] paramArrayOfByte)
  {
    this.workingKey = paramArrayOfByte;
    if (this.engineState == null) {
      this.engineState = new int['Ā'];
    }
    if (this.results == null) {
      this.results = new int['Ā'];
    }
    for (int i = 0; i < 256; i++) {
      this.engineState[i] = (this.results[i] = 0);
    }
    this.a = (this.b = this.c = 0);
    this.index = 0;
    byte[] arrayOfByte = new byte[paramArrayOfByte.length + (paramArrayOfByte.length & 0x3)];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramArrayOfByte.length);
    for (i = 0; i < arrayOfByte.length; i += 4) {
      this.results[(i >> 2)] = byteToIntLittle(arrayOfByte, i);
    }
    int[] arrayOfInt = new int[8];
    for (i = 0; i < 8; i++) {
      arrayOfInt[i] = -1640531527;
    }
    for (i = 0; i < 4; i++) {
      mix(arrayOfInt);
    }
    for (i = 0; i < 2; i++) {
      for (int j = 0; j < 256; j += 8)
      {
        for (int k = 0; k < 8; k++) {
          arrayOfInt[k] += (i < 1 ? this.results[(j + k)] : this.engineState[(j + k)]);
        }
        mix(arrayOfInt);
        for (k = 0; k < 8; k++) {
          this.engineState[(j + k)] = arrayOfInt[k];
        }
      }
    }
    isaac();
    this.initialised = true;
  }
  
  private void isaac()
  {
    this.b += ++this.c;
    for (int i = 0; i < 256; i++)
    {
      int j = this.engineState[i];
      switch (i & 0x3)
      {
      case 0: 
        this.a ^= this.a << 13;
        break;
      case 1: 
        this.a ^= this.a >>> 6;
        break;
      case 2: 
        this.a ^= this.a << 2;
        break;
      case 3: 
        this.a ^= this.a >>> 16;
      }
      this.a += this.engineState[(i + 128 & 0xFF)];
      int k;
      this.engineState[i] = (k = this.engineState[(j >>> 2 & 0xFF)] + this.a + this.b);
      this.results[i] = (this.b = this.engineState[(k >>> 10 & 0xFF)] + j);
    }
  }
  
  private void mix(int[] paramArrayOfInt)
  {
    paramArrayOfInt[0] ^= paramArrayOfInt[1] << 11;
    paramArrayOfInt[3] += paramArrayOfInt[0];
    paramArrayOfInt[1] += paramArrayOfInt[2];
    paramArrayOfInt[1] ^= paramArrayOfInt[2] >>> 2;
    paramArrayOfInt[4] += paramArrayOfInt[1];
    paramArrayOfInt[2] += paramArrayOfInt[3];
    paramArrayOfInt[2] ^= paramArrayOfInt[3] << 8;
    paramArrayOfInt[5] += paramArrayOfInt[2];
    paramArrayOfInt[3] += paramArrayOfInt[4];
    paramArrayOfInt[3] ^= paramArrayOfInt[4] >>> 16;
    paramArrayOfInt[6] += paramArrayOfInt[3];
    paramArrayOfInt[4] += paramArrayOfInt[5];
    paramArrayOfInt[4] ^= paramArrayOfInt[5] << 10;
    paramArrayOfInt[7] += paramArrayOfInt[4];
    paramArrayOfInt[5] += paramArrayOfInt[6];
    paramArrayOfInt[5] ^= paramArrayOfInt[6] >>> 4;
    paramArrayOfInt[0] += paramArrayOfInt[5];
    paramArrayOfInt[6] += paramArrayOfInt[7];
    paramArrayOfInt[6] ^= paramArrayOfInt[7] << 8;
    paramArrayOfInt[1] += paramArrayOfInt[6];
    paramArrayOfInt[7] += paramArrayOfInt[0];
    paramArrayOfInt[7] ^= paramArrayOfInt[0] >>> 9;
    paramArrayOfInt[2] += paramArrayOfInt[7];
    paramArrayOfInt[0] += paramArrayOfInt[1];
  }
  
  private int byteToIntLittle(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt++)] & 0xFF | (paramArrayOfByte[(paramInt++)] & 0xFF) << 8 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 16 | paramArrayOfByte[(paramInt++)] << 24;
  }
  
  private byte[] intToByteLittle(int paramInt)
  {
    byte[] arrayOfByte = new byte[4];
    arrayOfByte[3] = ((byte)paramInt);
    arrayOfByte[2] = ((byte)(paramInt >>> 8));
    arrayOfByte[1] = ((byte)(paramInt >>> 16));
    arrayOfByte[0] = ((byte)(paramInt >>> 24));
    return arrayOfByte;
  }
  
  private byte[] intToByteLittle(int[] paramArrayOfInt)
  {
    byte[] arrayOfByte = new byte[4 * paramArrayOfInt.length];
    int i = 0;
    for (int j = 0; i < paramArrayOfInt.length; j += 4)
    {
      System.arraycopy(intToByteLittle(paramArrayOfInt[i]), 0, arrayOfByte, j, 4);
      i++;
    }
    return arrayOfByte;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\ISAACEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */