package org.bouncycastle.crypto.engines;

import java.math.BigInteger;
import org.bouncycastle.crypto.BasicAgreement;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DerivationFunction;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.params.IESParameters;
import org.bouncycastle.crypto.params.IESWithCipherParameters;
import org.bouncycastle.crypto.params.KDFParameters;
import org.bouncycastle.crypto.params.KeyParameter;

public class IESEngine
{
  BasicAgreement agree;
  DerivationFunction kdf;
  Mac mac;
  BufferedBlockCipher cipher;
  byte[] macBuf;
  boolean forEncryption;
  CipherParameters privParam;
  CipherParameters pubParam;
  IESParameters param;
  
  public IESEngine(BasicAgreement paramBasicAgreement, DerivationFunction paramDerivationFunction, Mac paramMac)
  {
    this.agree = paramBasicAgreement;
    this.kdf = paramDerivationFunction;
    this.mac = paramMac;
    this.macBuf = new byte[paramMac.getMacSize()];
    this.cipher = null;
  }
  
  public IESEngine(BasicAgreement paramBasicAgreement, DerivationFunction paramDerivationFunction, Mac paramMac, BufferedBlockCipher paramBufferedBlockCipher)
  {
    this.agree = paramBasicAgreement;
    this.kdf = paramDerivationFunction;
    this.mac = paramMac;
    this.macBuf = new byte[paramMac.getMacSize()];
    this.cipher = paramBufferedBlockCipher;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters1, CipherParameters paramCipherParameters2, CipherParameters paramCipherParameters3)
  {
    this.forEncryption = paramBoolean;
    this.privParam = paramCipherParameters1;
    this.pubParam = paramCipherParameters2;
    this.param = ((IESParameters)paramCipherParameters3);
  }
  
  private byte[] decryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = null;
    KeyParameter localKeyParameter = null;
    KDFParameters localKDFParameters = new KDFParameters(paramArrayOfByte2, this.param.getDerivationV());
    int i = this.param.getMacKeySize();
    this.kdf.init(localKDFParameters);
    paramInt2 -= this.mac.getMacSize();
    if (this.cipher == null)
    {
      byte[] arrayOfByte2 = generateKdfBytes(localKDFParameters, paramInt2 + i / 8);
      arrayOfByte1 = new byte[paramInt2];
      for (int k = 0; k != paramInt2; k++) {
        arrayOfByte1[k] = ((byte)(paramArrayOfByte1[(paramInt1 + k)] ^ arrayOfByte2[k]));
      }
      localKeyParameter = new KeyParameter(arrayOfByte2, paramInt2, i / 8);
    }
    else
    {
      int j = ((IESWithCipherParameters)this.param).getCipherKeySize();
      byte[] arrayOfByte4 = generateKdfBytes(localKDFParameters, j / 8 + i / 8);
      this.cipher.init(false, new KeyParameter(arrayOfByte4, 0, j / 8));
      byte[] arrayOfByte5 = new byte[this.cipher.getOutputSize(paramInt2)];
      int n = this.cipher.processBytes(paramArrayOfByte1, paramInt1, paramInt2, arrayOfByte5, 0);
      n += this.cipher.doFinal(arrayOfByte5, n);
      arrayOfByte1 = new byte[n];
      System.arraycopy(arrayOfByte5, 0, arrayOfByte1, 0, n);
      localKeyParameter = new KeyParameter(arrayOfByte4, j / 8, i / 8);
    }
    byte[] arrayOfByte3 = this.param.getEncodingV();
    this.mac.init(localKeyParameter);
    this.mac.update(paramArrayOfByte1, paramInt1, paramInt2);
    this.mac.update(arrayOfByte3, 0, arrayOfByte3.length);
    this.mac.doFinal(this.macBuf, 0);
    paramInt1 += paramInt2;
    for (int m = 0; m < this.macBuf.length; m++) {
      if (this.macBuf[m] != paramArrayOfByte1[(paramInt1 + m)]) {
        throw new InvalidCipherTextException("Mac codes failed to equal.");
      }
    }
    return arrayOfByte1;
  }
  
  private byte[] encryptBlock(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = null;
    KeyParameter localKeyParameter = null;
    KDFParameters localKDFParameters = new KDFParameters(paramArrayOfByte2, this.param.getDerivationV());
    int i = 0;
    int j = this.param.getMacKeySize();
    if (this.cipher == null)
    {
      byte[] arrayOfByte2 = generateKdfBytes(localKDFParameters, paramInt2 + j / 8);
      arrayOfByte1 = new byte[paramInt2 + this.mac.getMacSize()];
      i = paramInt2;
      for (int m = 0; m != paramInt2; m++) {
        arrayOfByte1[m] = ((byte)(paramArrayOfByte1[(paramInt1 + m)] ^ arrayOfByte2[m]));
      }
      localKeyParameter = new KeyParameter(arrayOfByte2, paramInt2, j / 8);
    }
    else
    {
      int k = ((IESWithCipherParameters)this.param).getCipherKeySize();
      byte[] arrayOfByte4 = generateKdfBytes(localKDFParameters, k / 8 + j / 8);
      this.cipher.init(true, new KeyParameter(arrayOfByte4, 0, k / 8));
      i = this.cipher.getOutputSize(paramInt2);
      byte[] arrayOfByte5 = new byte[i];
      int n = this.cipher.processBytes(paramArrayOfByte1, paramInt1, paramInt2, arrayOfByte1, 0);
      n += this.cipher.doFinal(arrayOfByte5, n);
      arrayOfByte1 = new byte[n + this.mac.getMacSize()];
      i = n;
      System.arraycopy(arrayOfByte5, 0, arrayOfByte1, 0, n);
      localKeyParameter = new KeyParameter(arrayOfByte4, k / 8, j / 8);
    }
    byte[] arrayOfByte3 = this.param.getEncodingV();
    this.mac.init(localKeyParameter);
    this.mac.update(arrayOfByte1, 0, i);
    this.mac.update(arrayOfByte3, 0, arrayOfByte3.length);
    this.mac.doFinal(arrayOfByte1, i);
    return arrayOfByte1;
  }
  
  private byte[] generateKdfBytes(KDFParameters paramKDFParameters, int paramInt)
  {
    byte[] arrayOfByte = new byte[paramInt];
    this.kdf.init(paramKDFParameters);
    this.kdf.generateBytes(arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    this.agree.init(this.privParam);
    BigInteger localBigInteger = this.agree.calculateAgreement(this.pubParam);
    if (this.forEncryption) {
      return encryptBlock(paramArrayOfByte, paramInt1, paramInt2, localBigInteger.toByteArray());
    }
    return decryptBlock(paramArrayOfByte, paramInt1, paramInt2, localBigInteger.toByteArray());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\IESEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */