package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.RC2Parameters;

public class RC2Engine
  implements BlockCipher
{
  private static byte[] piTable = { -39, 120, -7, -60, 25, -35, -75, -19, 40, -23, -3, 121, 74, -96, -40, -99, -58, 126, 55, -125, 43, 118, 83, -114, 98, 76, 100, -120, 68, -117, -5, -94, 23, -102, 89, -11, -121, -77, 79, 19, 97, 69, 109, -115, 9, -127, 125, 50, -67, -113, 64, -21, -122, -73, 123, 11, -16, -107, 33, 34, 92, 107, 78, -126, 84, -42, 101, -109, -50, 96, -78, 28, 115, 86, -64, 20, -89, -116, -15, -36, 18, 117, -54, 31, 59, -66, -28, -47, 66, 61, -44, 48, -93, 60, -74, 38, 111, -65, 14, -38, 70, 105, 7, 87, 39, -14, 29, -101, -68, -108, 67, 3, -8, 17, -57, -10, -112, -17, 62, -25, 6, -61, -43, 47, -56, 102, 30, -41, 8, -24, -22, -34, Byte.MIN_VALUE, 82, -18, -9, -124, -86, 114, -84, 53, 77, 106, 42, -106, 26, -46, 113, 90, 21, 73, 116, 75, -97, -48, 94, 4, 24, -92, -20, -62, -32, 65, 110, 15, 81, -53, -52, 36, -111, -81, 80, -95, -12, 112, 57, -103, 124, 58, -123, 35, -72, -76, 122, -4, 2, 54, 91, 37, 85, -105, 49, 45, 93, -6, -104, -29, -118, -110, -82, 5, -33, 41, 16, 103, 108, -70, -55, -45, 0, -26, -49, -31, -98, -88, 44, 99, 22, 1, 63, 88, -30, -119, -87, 13, 56, 52, 27, -85, 51, -1, -80, -69, 72, 12, 95, -71, -79, -51, 46, -59, -13, -37, 71, -27, -91, -100, 119, 10, -90, 32, 104, -2, Byte.MAX_VALUE, -63, -83 };
  private static final int BLOCK_SIZE = 8;
  private int[] workingKey;
  private boolean encrypting;
  
  private int[] generateWorkingKey(byte[] paramArrayOfByte, int paramInt)
  {
    int[] arrayOfInt1 = new int[''];
    for (int j = 0; j != paramArrayOfByte.length; j++) {
      paramArrayOfByte[j] &= 0xFF;
    }
    j = paramArrayOfByte.length;
    if (j < 128)
    {
      k = 0;
      i = arrayOfInt1[(j - 1)];
      do
      {
        i = piTable[(i + arrayOfInt1[(k++)] & 0xFF)] & 0xFF;
        arrayOfInt1[(j++)] = i;
      } while (j < 128);
    }
    j = paramInt + 7 >> 3;
    int i = piTable[(arrayOfInt1[(128 - j)] & 255 >> (0x7 & -paramInt))] & 0xFF;
    arrayOfInt1[(128 - j)] = i;
    for (int k = 128 - j - 1; k >= 0; k--)
    {
      i = piTable[(i ^ arrayOfInt1[(k + j)])] & 0xFF;
      arrayOfInt1[k] = i;
    }
    int[] arrayOfInt2 = new int[64];
    for (int m = 0; m != arrayOfInt2.length; m++) {
      arrayOfInt2[m] = (arrayOfInt1[(2 * m)] + (arrayOfInt1[(2 * m + 1)] << 8));
    }
    return arrayOfInt2;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.encrypting = paramBoolean;
    Object localObject;
    if ((paramCipherParameters instanceof RC2Parameters))
    {
      localObject = (RC2Parameters)paramCipherParameters;
      this.workingKey = generateWorkingKey(((RC2Parameters)localObject).getKey(), ((RC2Parameters)localObject).getEffectiveKeyBits());
    }
    else if ((paramCipherParameters instanceof KeyParameter))
    {
      localObject = ((KeyParameter)paramCipherParameters).getKey();
      this.workingKey = generateWorkingKey((byte[])localObject, localObject.length * 8);
    }
    else
    {
      throw new IllegalArgumentException("invalid parameter passed to RC2 init - " + paramCipherParameters.getClass().getName());
    }
  }
  
  public void reset() {}
  
  public String getAlgorithmName()
  {
    return "RC2";
  }
  
  public int getBlockSize()
  {
    return 8;
  }
  
  public final int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (this.workingKey == null) {
      throw new IllegalStateException("RC2 engine not initialised");
    }
    if (paramInt1 + 8 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 8 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    if (this.encrypting) {
      encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    } else {
      decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    }
    return 8;
  }
  
  private int rotateWordLeft(int paramInt1, int paramInt2)
  {
    paramInt1 &= 0xFFFF;
    return paramInt1 << paramInt2 | paramInt1 >> 16 - paramInt2;
  }
  
  private void encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = ((paramArrayOfByte1[(paramInt1 + 7)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 6)] & 0xFF);
    int j = ((paramArrayOfByte1[(paramInt1 + 5)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 4)] & 0xFF);
    int k = ((paramArrayOfByte1[(paramInt1 + 3)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 2)] & 0xFF);
    int m = ((paramArrayOfByte1[(paramInt1 + 1)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 0)] & 0xFF);
    for (int n = 0; n <= 16; n += 4)
    {
      m = rotateWordLeft(m + (k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n], 1);
      k = rotateWordLeft(k + (j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)], 2);
      j = rotateWordLeft(j + (i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)], 3);
      i = rotateWordLeft(i + (m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)], 5);
    }
    m += this.workingKey[(i & 0x3F)];
    k += this.workingKey[(m & 0x3F)];
    j += this.workingKey[(k & 0x3F)];
    i += this.workingKey[(j & 0x3F)];
    for (n = 20; n <= 40; n += 4)
    {
      m = rotateWordLeft(m + (k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n], 1);
      k = rotateWordLeft(k + (j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)], 2);
      j = rotateWordLeft(j + (i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)], 3);
      i = rotateWordLeft(i + (m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)], 5);
    }
    m += this.workingKey[(i & 0x3F)];
    k += this.workingKey[(m & 0x3F)];
    j += this.workingKey[(k & 0x3F)];
    i += this.workingKey[(j & 0x3F)];
    for (n = 44; n < 64; n += 4)
    {
      m = rotateWordLeft(m + (k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n], 1);
      k = rotateWordLeft(k + (j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)], 2);
      j = rotateWordLeft(j + (i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)], 3);
      i = rotateWordLeft(i + (m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)], 5);
    }
    paramArrayOfByte2[(paramInt2 + 0)] = ((byte)m);
    paramArrayOfByte2[(paramInt2 + 1)] = ((byte)(m >> 8));
    paramArrayOfByte2[(paramInt2 + 2)] = ((byte)k);
    paramArrayOfByte2[(paramInt2 + 3)] = ((byte)(k >> 8));
    paramArrayOfByte2[(paramInt2 + 4)] = ((byte)j);
    paramArrayOfByte2[(paramInt2 + 5)] = ((byte)(j >> 8));
    paramArrayOfByte2[(paramInt2 + 6)] = ((byte)i);
    paramArrayOfByte2[(paramInt2 + 7)] = ((byte)(i >> 8));
  }
  
  private void decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int i = ((paramArrayOfByte1[(paramInt1 + 7)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 6)] & 0xFF);
    int j = ((paramArrayOfByte1[(paramInt1 + 5)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 4)] & 0xFF);
    int k = ((paramArrayOfByte1[(paramInt1 + 3)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 2)] & 0xFF);
    int m = ((paramArrayOfByte1[(paramInt1 + 1)] & 0xFF) << 8) + (paramArrayOfByte1[(paramInt1 + 0)] & 0xFF);
    for (int n = 60; n >= 44; n -= 4)
    {
      i = rotateWordLeft(i, 11) - ((m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)]);
      j = rotateWordLeft(j, 13) - ((i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)]);
      k = rotateWordLeft(k, 14) - ((j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)]);
      m = rotateWordLeft(m, 15) - ((k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n]);
    }
    i -= this.workingKey[(j & 0x3F)];
    j -= this.workingKey[(k & 0x3F)];
    k -= this.workingKey[(m & 0x3F)];
    m -= this.workingKey[(i & 0x3F)];
    for (n = 40; n >= 20; n -= 4)
    {
      i = rotateWordLeft(i, 11) - ((m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)]);
      j = rotateWordLeft(j, 13) - ((i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)]);
      k = rotateWordLeft(k, 14) - ((j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)]);
      m = rotateWordLeft(m, 15) - ((k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n]);
    }
    i -= this.workingKey[(j & 0x3F)];
    j -= this.workingKey[(k & 0x3F)];
    k -= this.workingKey[(m & 0x3F)];
    m -= this.workingKey[(i & 0x3F)];
    for (n = 16; n >= 0; n -= 4)
    {
      i = rotateWordLeft(i, 11) - ((m & (j ^ 0xFFFFFFFF)) + (k & j) + this.workingKey[(n + 3)]);
      j = rotateWordLeft(j, 13) - ((i & (k ^ 0xFFFFFFFF)) + (m & k) + this.workingKey[(n + 2)]);
      k = rotateWordLeft(k, 14) - ((j & (m ^ 0xFFFFFFFF)) + (i & m) + this.workingKey[(n + 1)]);
      m = rotateWordLeft(m, 15) - ((k & (i ^ 0xFFFFFFFF)) + (j & i) + this.workingKey[n]);
    }
    paramArrayOfByte2[(paramInt2 + 0)] = ((byte)m);
    paramArrayOfByte2[(paramInt2 + 1)] = ((byte)(m >> 8));
    paramArrayOfByte2[(paramInt2 + 2)] = ((byte)k);
    paramArrayOfByte2[(paramInt2 + 3)] = ((byte)(k >> 8));
    paramArrayOfByte2[(paramInt2 + 4)] = ((byte)j);
    paramArrayOfByte2[(paramInt2 + 5)] = ((byte)(j >> 8));
    paramArrayOfByte2[(paramInt2 + 6)] = ((byte)i);
    paramArrayOfByte2[(paramInt2 + 7)] = ((byte)(i >> 8));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\RC2Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */