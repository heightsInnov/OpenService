package org.bouncycastle.crypto.engines;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.params.RSAPrivateCrtKeyParameters;

public class RSABlindedEngine
  implements AsymmetricBlockCipher
{
  private static BigInteger ZERO = BigInteger.valueOf(0L);
  private RSACoreEngine core = new RSACoreEngine();
  private RSAKeyParameters key;
  private SecureRandom random;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.core.init(paramBoolean, paramCipherParameters);
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.key = ((RSAKeyParameters)localParametersWithRandom.getParameters());
      this.random = localParametersWithRandom.getRandom();
    }
    else
    {
      this.key = ((RSAKeyParameters)paramCipherParameters);
      this.random = new SecureRandom();
    }
  }
  
  public int getInputBlockSize()
  {
    return this.core.getInputBlockSize();
  }
  
  public int getOutputBlockSize()
  {
    return this.core.getOutputBlockSize();
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (this.key == null) {
      throw new IllegalStateException("RSA engine not initialised");
    }
    if ((this.key instanceof RSAPrivateCrtKeyParameters))
    {
      RSAPrivateCrtKeyParameters localRSAPrivateCrtKeyParameters = (RSAPrivateCrtKeyParameters)this.key;
      if (localRSAPrivateCrtKeyParameters.getPublicExponent() != null)
      {
        BigInteger localBigInteger1 = this.core.convertInput(paramArrayOfByte, paramInt1, paramInt2);
        BigInteger localBigInteger2 = localRSAPrivateCrtKeyParameters.getModulus();
        BigInteger localBigInteger3 = calculateR(localBigInteger2);
        BigInteger localBigInteger4 = this.core.processBlock(localBigInteger3.modPow(localRSAPrivateCrtKeyParameters.getPublicExponent(), localBigInteger2).multiply(localBigInteger1).mod(localBigInteger2));
        return this.core.convertOutput(localBigInteger4.multiply(localBigInteger3.modInverse(localBigInteger2)).mod(localBigInteger2));
      }
      return this.core.convertOutput(this.core.processBlock(this.core.convertInput(paramArrayOfByte, paramInt1, paramInt2)));
    }
    return this.core.convertOutput(this.core.processBlock(this.core.convertInput(paramArrayOfByte, paramInt1, paramInt2)));
  }
  
  private BigInteger calculateR(BigInteger paramBigInteger)
  {
    int i = paramBigInteger.bitLength() - 1;
    int j = i / 2;
    int k = (this.random.nextInt() & 0xFF) * ((i - j) / 255) + j;
    for (BigInteger localBigInteger = new BigInteger(k, this.random); localBigInteger.equals(ZERO); localBigInteger = new BigInteger(k, this.random)) {}
    return localBigInteger;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\RSABlindedEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */