package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;

public class NullEngine
  implements BlockCipher
{
  private boolean initialised;
  protected static final int BLOCK_SIZE = 1;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.initialised = true;
  }
  
  public String getAlgorithmName()
  {
    return "Null";
  }
  
  public int getBlockSize()
  {
    return 1;
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (!this.initialised) {
      throw new IllegalStateException("Null engine not initialised");
    }
    if (paramInt1 + 1 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 1 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    for (int i = 0; i < 1; i++) {
      paramArrayOfByte2[(paramInt2 + i)] = paramArrayOfByte1[(paramInt1 + i)];
    }
    return 1;
  }
  
  public void reset() {}
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\NullEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */