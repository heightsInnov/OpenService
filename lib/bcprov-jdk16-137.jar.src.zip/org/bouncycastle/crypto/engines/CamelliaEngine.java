package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;

public class CamelliaEngine
  implements BlockCipher
{
  private boolean initialised;
  private boolean _keyIs128;
  private static final int BLOCK_SIZE = 16;
  private static final long MASK8 = 255L;
  private static final long MASK32 = 4294967295L;
  private static final long SIGMA1 = -6872943284670656373L;
  private static final long SIGMA2 = -5297666545706961998L;
  private static final long SIGMA3 = -4112007255848680770L;
  private static final long SIGMA4 = 6124705990439038748L;
  private static final long SIGMA5 = 1217423232700263709L;
  private static final long SIGMA6 = -5740250305213840899L;
  private long _kw1;
  private long _kw2;
  private long _kw3;
  private long _kw4;
  private long _k1;
  private long _k2;
  private long _k3;
  private long _k4;
  private long _k5;
  private long _k6;
  private long _k7;
  private long _k8;
  private long _k9;
  private long _k10;
  private long _k11;
  private long _k12;
  private long _k13;
  private long _k14;
  private long _k15;
  private long _k16;
  private long _k17;
  private long _k18;
  private long _k19;
  private long _k20;
  private long _k21;
  private long _k22;
  private long _k23;
  private long _k24;
  private long _ke1;
  private long _ke2;
  private long _ke3;
  private long _ke4;
  private long _ke5;
  private long _ke6;
  private final byte[] SBOX1 = { 112, -126, 44, -20, -77, 39, -64, -27, -28, -123, 87, 53, -22, 12, -82, 65, 35, -17, 107, -109, 69, 25, -91, 33, -19, 14, 79, 78, 29, 101, -110, -67, -122, -72, -81, -113, 124, -21, 31, -50, 62, 48, -36, 95, 94, -59, 11, 26, -90, -31, 57, -54, -43, 71, 93, 61, -39, 1, 90, -42, 81, 86, 108, 77, -117, 13, -102, 102, -5, -52, -80, 45, 116, 18, 43, 32, -16, -79, -124, -103, -33, 76, -53, -62, 52, 126, 118, 5, 109, -73, -87, 49, -47, 23, 4, -41, 20, 88, 58, 97, -34, 27, 17, 28, 50, 15, -100, 22, 83, 24, -14, 34, -2, 68, -49, -78, -61, -75, 122, -111, 36, 8, -24, -88, 96, -4, 105, 80, -86, -48, -96, 125, -95, -119, 98, -105, 84, 91, 30, -107, -32, -1, 100, -46, 16, -60, 0, 72, -93, -9, 117, -37, -118, 3, -26, -38, 9, 63, -35, -108, -121, 92, -125, 2, -51, 74, -112, 51, 115, 103, -10, -13, -99, Byte.MAX_VALUE, -65, -30, 82, -101, -40, 38, -56, 55, -58, 59, -127, -106, 111, 75, 19, -66, 99, 46, -23, 121, -89, -116, -97, 110, -68, -114, 41, -11, -7, -74, 47, -3, -76, 89, 120, -104, 6, 106, -25, 70, 113, -70, -44, 37, -85, 66, -120, -94, -115, -6, 114, 7, -71, 85, -8, -18, -84, 10, 54, 73, 42, 104, 60, 56, -15, -92, 64, 40, -45, 123, -69, -55, 67, -63, 21, -29, -83, -12, 119, -57, Byte.MIN_VALUE, -98 };
  private final byte[] SBOX2 = new byte['Ā'];
  private final byte[] SBOX3 = new byte['Ā'];
  private final byte[] SBOX4 = new byte['Ā'];
  
  public CamelliaEngine()
  {
    for (int i = 0; i != 256; i++)
    {
      this.SBOX2[i] = lRot8(this.SBOX1[i], 1);
      this.SBOX3[i] = lRot8(this.SBOX1[i], 7);
      this.SBOX4[i] = this.SBOX1[(lRot8((byte)i, 1) & 0xFF)];
    }
  }
  
  private void setKey(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    long l1;
    long l2;
    long l3;
    long l4;
    switch (paramArrayOfByte.length)
    {
    case 16: 
      this._keyIs128 = true;
      l1 = bytesToWord(paramArrayOfByte, 0);
      l2 = bytesToWord(paramArrayOfByte, 8);
      l3 = 0L;
      l4 = 0L;
      break;
    case 24: 
      l1 = bytesToWord(paramArrayOfByte, 0);
      l2 = bytesToWord(paramArrayOfByte, 8);
      l3 = bytesToWord(paramArrayOfByte, 16);
      l4 = bytesToWord(paramArrayOfByte, 16) ^ 0xFFFFFFFFFFFFFFFF;
      this._keyIs128 = false;
      break;
    case 32: 
      l1 = bytesToWord(paramArrayOfByte, 0);
      l2 = bytesToWord(paramArrayOfByte, 8);
      l3 = bytesToWord(paramArrayOfByte, 16);
      l4 = bytesToWord(paramArrayOfByte, 24);
      this._keyIs128 = false;
      break;
    default: 
      throw new IllegalArgumentException("only a key sizes of 128/192/256 are acceptable.");
    }
    long l5 = l1 ^ l3;
    long l6 = l2 ^ l4;
    l6 ^= f(l5, -6872943284670656373L);
    l5 ^= f(l6, -5297666545706961998L);
    l5 ^= l1;
    l6 ^= l2;
    l6 ^= f(l5, -4112007255848680770L);
    l5 ^= f(l6, 6124705990439038748L);
    long l7 = l5;
    long l8 = l6;
    if (this._keyIs128)
    {
      if (paramBoolean)
      {
        this._kw1 = l1;
        this._kw2 = l2;
        this._kw3 = lRot128high(l7, l8, 111);
        this._kw4 = lRot128low(l7, l8, 111);
        this._k1 = l7;
        this._k2 = l8;
        this._k3 = lRot128high(l1, l2, 15);
        this._k4 = lRot128low(l1, l2, 15);
        this._k5 = lRot128high(l7, l8, 15);
        this._k6 = lRot128low(l7, l8, 15);
        this._k7 = lRot128high(l1, l2, 45);
        this._k8 = lRot128low(l1, l2, 45);
        this._k9 = lRot128high(l7, l8, 45);
        this._k10 = lRot128low(l1, l2, 60);
        this._k11 = lRot128high(l7, l8, 60);
        this._k12 = lRot128low(l7, l8, 60);
        this._k13 = lRot128high(l1, l2, 94);
        this._k14 = lRot128low(l1, l2, 94);
        this._k15 = lRot128high(l7, l8, 94);
        this._k16 = lRot128low(l7, l8, 94);
        this._k17 = lRot128high(l1, l2, 111);
        this._k18 = lRot128low(l1, l2, 111);
        this._ke1 = lRot128high(l7, l8, 30);
        this._ke2 = lRot128low(l7, l8, 30);
        this._ke3 = lRot128high(l1, l2, 77);
        this._ke4 = lRot128low(l1, l2, 77);
      }
      else
      {
        this._kw3 = l1;
        this._kw4 = l2;
        this._kw1 = lRot128high(l7, l8, 111);
        this._kw2 = lRot128low(l7, l8, 111);
        this._k18 = l7;
        this._k17 = l8;
        this._k16 = lRot128high(l1, l2, 15);
        this._k15 = lRot128low(l1, l2, 15);
        this._k14 = lRot128high(l7, l8, 15);
        this._k13 = lRot128low(l7, l8, 15);
        this._k12 = lRot128high(l1, l2, 45);
        this._k11 = lRot128low(l1, l2, 45);
        this._k10 = lRot128high(l7, l8, 45);
        this._k9 = lRot128low(l1, l2, 60);
        this._k8 = lRot128high(l7, l8, 60);
        this._k7 = lRot128low(l7, l8, 60);
        this._k6 = lRot128high(l1, l2, 94);
        this._k5 = lRot128low(l1, l2, 94);
        this._k4 = lRot128high(l7, l8, 94);
        this._k3 = lRot128low(l7, l8, 94);
        this._k2 = lRot128high(l1, l2, 111);
        this._k1 = lRot128low(l1, l2, 111);
        this._ke4 = lRot128high(l7, l8, 30);
        this._ke3 = lRot128low(l7, l8, 30);
        this._ke2 = lRot128high(l1, l2, 77);
        this._ke1 = lRot128low(l1, l2, 77);
      }
    }
    else
    {
      l5 = l7 ^ l3;
      l6 = l8 ^ l4;
      l6 ^= f(l5, 1217423232700263709L);
      l5 ^= f(l6, -5740250305213840899L);
      long l9 = l5;
      long l10 = l6;
      if (paramBoolean)
      {
        this._kw1 = l1;
        this._kw2 = l2;
        this._k1 = l9;
        this._k2 = l10;
        this._k3 = lRot128high(l3, l4, 15);
        this._k4 = lRot128low(l3, l4, 15);
        this._k5 = lRot128high(l7, l8, 15);
        this._k6 = lRot128low(l7, l8, 15);
        this._ke1 = lRot128high(l3, l4, 30);
        this._ke2 = lRot128low(l3, l4, 30);
        this._k7 = lRot128high(l9, l10, 30);
        this._k8 = lRot128low(l9, l10, 30);
        this._k9 = lRot128high(l1, l2, 45);
        this._k10 = lRot128low(l1, l2, 45);
        this._k11 = lRot128high(l7, l8, 45);
        this._k12 = lRot128low(l7, l8, 45);
        this._ke3 = lRot128high(l1, l2, 60);
        this._ke4 = lRot128low(l1, l2, 60);
        this._k13 = lRot128high(l3, l4, 60);
        this._k14 = lRot128low(l3, l4, 60);
        this._k15 = lRot128high(l9, l10, 60);
        this._k16 = lRot128low(l9, l10, 60);
        this._k17 = lRot128high(l1, l2, 77);
        this._k18 = lRot128low(l1, l2, 77);
        this._ke5 = lRot128high(l7, l8, 77);
        this._ke6 = lRot128low(l7, l8, 77);
        this._k19 = lRot128high(l3, l4, 94);
        this._k20 = lRot128low(l3, l4, 94);
        this._k21 = lRot128high(l7, l8, 94);
        this._k22 = lRot128low(l7, l8, 94);
        this._k23 = lRot128high(l1, l2, 111);
        this._k24 = lRot128low(l1, l2, 111);
        this._kw3 = lRot128high(l9, l10, 111);
        this._kw4 = lRot128low(l9, l10, 111);
      }
      else
      {
        this._kw3 = l1;
        this._kw4 = l2;
        this._kw1 = lRot128high(l9, l10, 111);
        this._kw2 = lRot128low(l9, l10, 111);
        this._k24 = l9;
        this._k23 = l10;
        this._k22 = lRot128high(l3, l4, 15);
        this._k21 = lRot128low(l3, l4, 15);
        this._k20 = lRot128high(l7, l8, 15);
        this._k19 = lRot128low(l7, l8, 15);
        this._k18 = lRot128high(l9, l10, 30);
        this._k17 = lRot128low(l9, l10, 30);
        this._k16 = lRot128high(l1, l2, 45);
        this._k15 = lRot128low(l1, l2, 45);
        this._k14 = lRot128high(l7, l8, 45);
        this._k13 = lRot128low(l7, l8, 45);
        this._k12 = lRot128high(l3, l4, 60);
        this._k11 = lRot128low(l3, l4, 60);
        this._k10 = lRot128high(l9, l10, 60);
        this._k9 = lRot128low(l9, l10, 60);
        this._k8 = lRot128high(l1, l2, 77);
        this._k7 = lRot128low(l1, l2, 77);
        this._k6 = lRot128high(l3, l4, 94);
        this._k5 = lRot128low(l3, l4, 94);
        this._k4 = lRot128high(l7, l8, 94);
        this._k3 = lRot128low(l7, l8, 94);
        this._k2 = lRot128high(l1, l2, 111);
        this._k1 = lRot128low(l1, l2, 111);
        this._ke6 = lRot128high(l3, l4, 30);
        this._ke5 = lRot128low(l3, l4, 30);
        this._ke4 = lRot128high(l1, l2, 60);
        this._ke3 = lRot128low(l1, l2, 60);
        this._ke2 = lRot128high(l7, l8, 77);
        this._ke1 = lRot128low(l7, l8, 77);
      }
    }
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("only simple KeyParameter expected.");
    }
    setKey(paramBoolean, ((KeyParameter)paramCipherParameters).getKey());
    this.initialised = true;
  }
  
  public String getAlgorithmName()
  {
    return "Camellia";
  }
  
  public int getBlockSize()
  {
    return 16;
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (!this.initialised) {
      throw new IllegalStateException("Camellia engine not initialised");
    }
    if (paramInt1 + 16 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 16 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    if (this._keyIs128) {
      return processBlock128(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    }
    return processBlock192or256(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset() {}
  
  private byte lRot8(byte paramByte, int paramInt)
  {
    return (byte)(paramByte << paramInt | (paramByte & 0xFF) >>> 8 - paramInt);
  }
  
  private int lRot32(int paramInt1, int paramInt2)
  {
    return paramInt1 << paramInt2 | paramInt1 >>> -paramInt2;
  }
  
  private long lRot128high(long paramLong1, long paramLong2, int paramInt)
  {
    if (paramInt < 64) {
      paramLong1 = paramLong1 << paramInt | paramLong2 >>> -paramInt;
    } else if (paramInt == 64) {
      paramLong1 = paramLong2;
    } else {
      paramLong1 = paramLong2 << paramInt - 64 | paramLong1 >>> -(paramInt - 64);
    }
    return paramLong1;
  }
  
  private long lRot128low(long paramLong1, long paramLong2, int paramInt)
  {
    if (paramInt < 64) {
      paramLong2 = paramLong2 << paramInt | paramLong1 >>> -paramInt;
    } else if (paramInt == 64) {
      paramLong2 = paramLong1;
    } else {
      paramLong2 = paramLong1 << paramInt - 64 | paramLong2 >>> -(paramInt - 64);
    }
    return paramLong2;
  }
  
  private long fl(long paramLong1, long paramLong2)
  {
    int i = (int)(paramLong1 >> 32);
    int j = (int)paramLong1;
    int k = (int)(paramLong2 >> 32);
    int m = (int)paramLong2;
    j ^= lRot32(i & k, 1);
    i ^= (j | m);
    return i << 32 | j & 0xFFFFFFFF;
  }
  
  private long flInv(long paramLong1, long paramLong2)
  {
    int i = (int)(paramLong1 >> 32);
    int j = (int)paramLong1;
    int k = (int)(paramLong2 >> 32);
    int m = (int)paramLong2;
    i ^= (j | m);
    j ^= lRot32(i & k, 1);
    return i << 32 | j & 0xFFFFFFFF;
  }
  
  private long f(long paramLong1, long paramLong2)
  {
    long l = paramLong1 ^ paramLong2;
    int i = (int)(l >> 32);
    int j = (int)l;
    int k = this.SBOX1[(i >> 24 & 0xFF)];
    int m = this.SBOX2[(i >> 16 & 0xFF)];
    int n = this.SBOX3[(i >> 8 & 0xFF)];
    int i1 = this.SBOX4[(i & 0xFF)];
    int i2 = this.SBOX2[(j >> 24 & 0xFF)];
    int i3 = this.SBOX3[(j >> 16 & 0xFF)];
    int i4 = this.SBOX4[(j >> 8 & 0xFF)];
    int i5 = this.SBOX1[(j & 0xFF)];
    int i6 = k ^ n ^ i1 ^ i3 ^ i4 ^ i5;
    int i7 = k ^ m ^ i1 ^ i2 ^ i4 ^ i5;
    int i8 = k ^ m ^ n ^ i2 ^ i3 ^ i5;
    int i9 = m ^ n ^ i1 ^ i2 ^ i3 ^ i4;
    int i10 = k ^ m ^ i3 ^ i4 ^ i5;
    int i11 = m ^ n ^ i2 ^ i4 ^ i5;
    int i12 = n ^ i1 ^ i2 ^ i3 ^ i5;
    int i13 = k ^ i1 ^ i2 ^ i3 ^ i4;
    return i6 << 56 | (i7 & 0xFF) << 48 | (i8 & 0xFF) << 40 | (i9 & 0xFF) << 32 | (i10 & 0xFF) << 24 | (i11 & 0xFF) << 16 | (i12 & 0xFF) << 8 | i13 & 0xFF;
  }
  
  private long bytesToWord(byte[] paramArrayOfByte, int paramInt)
  {
    long l = 0L;
    for (int i = 0; i < 8; i++) {
      l = (l << 8) + (paramArrayOfByte[(i + paramInt)] & 0xFF);
    }
    return l;
  }
  
  private void wordToBytes(long paramLong, byte[] paramArrayOfByte, int paramInt)
  {
    for (int i = 0; i < 8; i++)
    {
      paramArrayOfByte[(7 - i + paramInt)] = ((byte)(int)paramLong);
      paramLong >>>= 8;
    }
  }
  
  private int processBlock128(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    long l1 = bytesToWord(paramArrayOfByte1, paramInt1);
    long l2 = bytesToWord(paramArrayOfByte1, paramInt1 + 8);
    l1 ^= this._kw1;
    l2 ^= this._kw2;
    l2 ^= f(l1, this._k1);
    l1 ^= f(l2, this._k2);
    l2 ^= f(l1, this._k3);
    l1 ^= f(l2, this._k4);
    l2 ^= f(l1, this._k5);
    l1 ^= f(l2, this._k6);
    l1 = fl(l1, this._ke1);
    l2 = flInv(l2, this._ke2);
    l2 ^= f(l1, this._k7);
    l1 ^= f(l2, this._k8);
    l2 ^= f(l1, this._k9);
    l1 ^= f(l2, this._k10);
    l2 ^= f(l1, this._k11);
    l1 ^= f(l2, this._k12);
    l1 = fl(l1, this._ke3);
    l2 = flInv(l2, this._ke4);
    l2 ^= f(l1, this._k13);
    l1 ^= f(l2, this._k14);
    l2 ^= f(l1, this._k15);
    l1 ^= f(l2, this._k16);
    l2 ^= f(l1, this._k17);
    l1 ^= f(l2, this._k18);
    l2 ^= this._kw3;
    l1 ^= this._kw4;
    wordToBytes(l2, paramArrayOfByte2, paramInt2);
    wordToBytes(l1, paramArrayOfByte2, paramInt2 + 8);
    return 16;
  }
  
  private int processBlock192or256(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    long l1 = bytesToWord(paramArrayOfByte1, paramInt1);
    long l2 = bytesToWord(paramArrayOfByte1, paramInt1 + 8);
    l1 ^= this._kw1;
    l2 ^= this._kw2;
    l2 ^= f(l1, this._k1);
    l1 ^= f(l2, this._k2);
    l2 ^= f(l1, this._k3);
    l1 ^= f(l2, this._k4);
    l2 ^= f(l1, this._k5);
    l1 ^= f(l2, this._k6);
    l1 = fl(l1, this._ke1);
    l2 = flInv(l2, this._ke2);
    l2 ^= f(l1, this._k7);
    l1 ^= f(l2, this._k8);
    l2 ^= f(l1, this._k9);
    l1 ^= f(l2, this._k10);
    l2 ^= f(l1, this._k11);
    l1 ^= f(l2, this._k12);
    l1 = fl(l1, this._ke3);
    l2 = flInv(l2, this._ke4);
    l2 ^= f(l1, this._k13);
    l1 ^= f(l2, this._k14);
    l2 ^= f(l1, this._k15);
    l1 ^= f(l2, this._k16);
    l2 ^= f(l1, this._k17);
    l1 ^= f(l2, this._k18);
    l1 = fl(l1, this._ke5);
    l2 = flInv(l2, this._ke6);
    l2 ^= f(l1, this._k19);
    l1 ^= f(l2, this._k20);
    l2 ^= f(l1, this._k21);
    l1 ^= f(l2, this._k22);
    l2 ^= f(l1, this._k23);
    l1 ^= f(l2, this._k24);
    l2 ^= this._kw3;
    l1 ^= this._kw4;
    wordToBytes(l2, paramArrayOfByte2, paramInt2);
    wordToBytes(l1, paramArrayOfByte2, paramInt2 + 8);
    return 16;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\CamelliaEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */