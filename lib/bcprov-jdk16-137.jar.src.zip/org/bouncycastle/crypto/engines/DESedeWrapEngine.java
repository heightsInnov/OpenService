package org.bouncycastle.crypto.engines;

import java.security.SecureRandom;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Wrapper;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class DESedeWrapEngine
  implements Wrapper
{
  private CBCBlockCipher engine;
  private KeyParameter param;
  private ParametersWithIV paramPlusIV;
  private byte[] iv;
  private boolean forWrapping;
  private static final byte[] IV2 = { 74, -35, -94, 44, 121, -24, 33, 5 };
  Digest sha1 = new SHA1Digest();
  byte[] digest = new byte[20];
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    this.forWrapping = paramBoolean;
    this.engine = new CBCBlockCipher(new DESedeEngine());
    if ((paramCipherParameters instanceof KeyParameter))
    {
      this.param = ((KeyParameter)paramCipherParameters);
      if (this.forWrapping)
      {
        this.iv = new byte[8];
        SecureRandom localSecureRandom = new SecureRandom();
        localSecureRandom.nextBytes(this.iv);
        this.paramPlusIV = new ParametersWithIV(this.param, this.iv);
      }
    }
    else if ((paramCipherParameters instanceof ParametersWithIV))
    {
      this.paramPlusIV = ((ParametersWithIV)paramCipherParameters);
      this.iv = this.paramPlusIV.getIV();
      this.param = ((KeyParameter)this.paramPlusIV.getParameters());
      if (this.forWrapping)
      {
        if ((this.iv == null) || (this.iv.length != 8)) {
          throw new IllegalArgumentException("IV is not 8 octets");
        }
      }
      else {
        throw new IllegalArgumentException("You should not supply an IV for unwrapping");
      }
    }
  }
  
  public String getAlgorithmName()
  {
    return "DESede";
  }
  
  public byte[] wrap(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (!this.forWrapping) {
      throw new IllegalStateException("Not initialized for wrapping");
    }
    byte[] arrayOfByte1 = new byte[paramInt2];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, paramInt2);
    byte[] arrayOfByte2 = calculateCMSKeyChecksum(arrayOfByte1);
    byte[] arrayOfByte3 = new byte[arrayOfByte1.length + arrayOfByte2.length];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, arrayOfByte1.length);
    System.arraycopy(arrayOfByte2, 0, arrayOfByte3, arrayOfByte1.length, arrayOfByte2.length);
    byte[] arrayOfByte4 = new byte[arrayOfByte3.length];
    System.arraycopy(arrayOfByte3, 0, arrayOfByte4, 0, arrayOfByte3.length);
    int i = arrayOfByte3.length / this.engine.getBlockSize();
    int j = arrayOfByte3.length % this.engine.getBlockSize();
    if (j != 0) {
      throw new IllegalStateException("Not multiple of block length");
    }
    this.engine.init(true, this.paramPlusIV);
    for (int k = 0; k < i; k++)
    {
      int m = k * this.engine.getBlockSize();
      this.engine.processBlock(arrayOfByte4, m, arrayOfByte4, m);
    }
    byte[] arrayOfByte5 = new byte[this.iv.length + arrayOfByte4.length];
    System.arraycopy(this.iv, 0, arrayOfByte5, 0, this.iv.length);
    System.arraycopy(arrayOfByte4, 0, arrayOfByte5, this.iv.length, arrayOfByte4.length);
    byte[] arrayOfByte6 = new byte[arrayOfByte5.length];
    for (int n = 0; n < arrayOfByte5.length; n++) {
      arrayOfByte6[n] = arrayOfByte5[(arrayOfByte5.length - (n + 1))];
    }
    ParametersWithIV localParametersWithIV = new ParametersWithIV(this.param, IV2);
    this.engine.init(true, localParametersWithIV);
    for (int i1 = 0; i1 < i + 1; i1++)
    {
      int i2 = i1 * this.engine.getBlockSize();
      this.engine.processBlock(arrayOfByte6, i2, arrayOfByte6, i2);
    }
    return arrayOfByte6;
  }
  
  public byte[] unwrap(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    if (this.forWrapping) {
      throw new IllegalStateException("Not set for unwrapping");
    }
    if (paramArrayOfByte == null) {
      throw new InvalidCipherTextException("Null pointer as ciphertext");
    }
    if (paramInt2 % this.engine.getBlockSize() != 0) {
      throw new InvalidCipherTextException("Ciphertext not multiple of " + this.engine.getBlockSize());
    }
    ParametersWithIV localParametersWithIV = new ParametersWithIV(this.param, IV2);
    this.engine.init(false, localParametersWithIV);
    byte[] arrayOfByte1 = new byte[paramInt2];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte1, 0, paramInt2);
    for (int i = 0; i < arrayOfByte1.length / this.engine.getBlockSize(); i++)
    {
      j = i * this.engine.getBlockSize();
      this.engine.processBlock(arrayOfByte1, j, arrayOfByte1, j);
    }
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    for (int j = 0; j < arrayOfByte1.length; j++) {
      arrayOfByte2[j] = arrayOfByte1[(arrayOfByte1.length - (j + 1))];
    }
    this.iv = new byte[8];
    byte[] arrayOfByte3 = new byte[arrayOfByte2.length - 8];
    System.arraycopy(arrayOfByte2, 0, this.iv, 0, 8);
    System.arraycopy(arrayOfByte2, 8, arrayOfByte3, 0, arrayOfByte2.length - 8);
    this.paramPlusIV = new ParametersWithIV(this.param, this.iv);
    this.engine.init(false, this.paramPlusIV);
    byte[] arrayOfByte4 = new byte[arrayOfByte3.length];
    System.arraycopy(arrayOfByte3, 0, arrayOfByte4, 0, arrayOfByte3.length);
    for (int k = 0; k < arrayOfByte4.length / this.engine.getBlockSize(); k++)
    {
      int m = k * this.engine.getBlockSize();
      this.engine.processBlock(arrayOfByte4, m, arrayOfByte4, m);
    }
    byte[] arrayOfByte5 = new byte[arrayOfByte4.length - 8];
    byte[] arrayOfByte6 = new byte[8];
    System.arraycopy(arrayOfByte4, 0, arrayOfByte5, 0, arrayOfByte4.length - 8);
    System.arraycopy(arrayOfByte4, arrayOfByte4.length - 8, arrayOfByte6, 0, 8);
    if (!checkCMSKeyChecksum(arrayOfByte5, arrayOfByte6)) {
      throw new InvalidCipherTextException("Checksum inside ciphertext is corrupted");
    }
    return arrayOfByte5;
  }
  
  private byte[] calculateCMSKeyChecksum(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[8];
    this.sha1.update(paramArrayOfByte, 0, paramArrayOfByte.length);
    this.sha1.doFinal(this.digest, 0);
    System.arraycopy(this.digest, 0, arrayOfByte, 0, 8);
    return arrayOfByte;
  }
  
  private boolean checkCMSKeyChecksum(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte = calculateCMSKeyChecksum(paramArrayOfByte1);
    if (paramArrayOfByte2.length != arrayOfByte.length) {
      return false;
    }
    for (int i = 0; i != paramArrayOfByte2.length; i++) {
      if (paramArrayOfByte2[i] != arrayOfByte[i]) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\DESedeWrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */