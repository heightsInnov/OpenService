package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.RC5Parameters;

public class RC564Engine
  implements BlockCipher
{
  private static final int wordSize = 64;
  private static final int bytesPerWord = 8;
  private int _noRounds = 12;
  private long[] _S = null;
  private static final long P64 = -5196783011329398165L;
  private static final long Q64 = -7046029254386353131L;
  private boolean forEncryption;
  
  public String getAlgorithmName()
  {
    return "RC5-64";
  }
  
  public int getBlockSize()
  {
    return 16;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof RC5Parameters)) {
      throw new IllegalArgumentException("invalid parameter passed to RC564 init - " + paramCipherParameters.getClass().getName());
    }
    RC5Parameters localRC5Parameters = (RC5Parameters)paramCipherParameters;
    this.forEncryption = paramBoolean;
    this._noRounds = localRC5Parameters.getRounds();
    setKey(localRC5Parameters.getKey());
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    return this.forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset() {}
  
  private void setKey(byte[] paramArrayOfByte)
  {
    long[] arrayOfLong = new long[(paramArrayOfByte.length + 7) / 8];
    for (int i = 0; i != paramArrayOfByte.length; i++) {
      arrayOfLong[(i / 8)] += ((paramArrayOfByte[i] & 0xFF) << 8 * (i % 8));
    }
    this._S = new long[2 * (this._noRounds + 1)];
    this._S[0] = -5196783011329398165L;
    for (i = 1; i < this._S.length; i++) {
      this._S[i] = (this._S[(i - 1)] + -7046029254386353131L);
    }
    if (arrayOfLong.length > this._S.length) {
      i = 3 * arrayOfLong.length;
    } else {
      i = 3 * this._S.length;
    }
    long l1 = 0L;
    long l2 = 0L;
    int j = 0;
    int k = 0;
    for (int m = 0; m < i; m++)
    {
      l1 = this._S[j] = rotateLeft(this._S[j] + l1 + l2, 3L);
      l2 = arrayOfLong[k] = rotateLeft(arrayOfLong[k] + l1 + l2, l1 + l2);
      j = (j + 1) % this._S.length;
      k = (k + 1) % arrayOfLong.length;
    }
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    long l1 = bytesToWord(paramArrayOfByte1, paramInt1) + this._S[0];
    long l2 = bytesToWord(paramArrayOfByte1, paramInt1 + 8) + this._S[1];
    for (int i = 1; i <= this._noRounds; i++)
    {
      l1 = rotateLeft(l1 ^ l2, l2) + this._S[(2 * i)];
      l2 = rotateLeft(l2 ^ l1, l1) + this._S[(2 * i + 1)];
    }
    wordToBytes(l1, paramArrayOfByte2, paramInt2);
    wordToBytes(l2, paramArrayOfByte2, paramInt2 + 8);
    return 16;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    long l1 = bytesToWord(paramArrayOfByte1, paramInt1);
    long l2 = bytesToWord(paramArrayOfByte1, paramInt1 + 8);
    for (int i = this._noRounds; i >= 1; i--)
    {
      l2 = rotateRight(l2 - this._S[(2 * i + 1)], l1) ^ l1;
      l1 = rotateRight(l1 - this._S[(2 * i)], l2) ^ l2;
    }
    wordToBytes(l1 - this._S[0], paramArrayOfByte2, paramInt2);
    wordToBytes(l2 - this._S[1], paramArrayOfByte2, paramInt2 + 8);
    return 16;
  }
  
  private long rotateLeft(long paramLong1, long paramLong2)
  {
    return paramLong1 << (int)(paramLong2 & 0x3F) | paramLong1 >>> (int)(64L - (paramLong2 & 0x3F));
  }
  
  private long rotateRight(long paramLong1, long paramLong2)
  {
    return paramLong1 >>> (int)(paramLong2 & 0x3F) | paramLong1 << (int)(64L - (paramLong2 & 0x3F));
  }
  
  private long bytesToWord(byte[] paramArrayOfByte, int paramInt)
  {
    long l = 0L;
    for (int i = 7; i >= 0; i--) {
      l = (l << 8) + (paramArrayOfByte[(i + paramInt)] & 0xFF);
    }
    return l;
  }
  
  private void wordToBytes(long paramLong, byte[] paramArrayOfByte, int paramInt)
  {
    for (int i = 0; i < 8; i++)
    {
      paramArrayOfByte[(i + paramInt)] = ((byte)(int)paramLong);
      paramLong >>>= 8;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\RC564Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */