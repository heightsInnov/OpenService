package org.bouncycastle.crypto.engines;

public class AESWrapEngine
  extends RFC3394WrapEngine
{
  public AESWrapEngine()
  {
    super(new AESEngine());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\AESWrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */