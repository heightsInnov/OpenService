package org.bouncycastle.crypto.engines;

public final class CAST6Engine
  extends CAST5Engine
{
  protected static final int ROUNDS = 12;
  protected static final int BLOCK_SIZE = 16;
  protected int[] _Kr = new int[48];
  protected int[] _Km = new int[48];
  protected int[] _Tr = new int['À'];
  protected int[] _Tm = new int['À'];
  private int[] _workingKey = new int[8];
  
  public String getAlgorithmName()
  {
    return "CAST6";
  }
  
  public void reset() {}
  
  public int getBlockSize()
  {
    return 16;
  }
  
  protected void setKey(byte[] paramArrayOfByte)
  {
    int i = 1518500249;
    int j = 1859775393;
    int k = 19;
    int m = 17;
    for (int n = 0; n < 24; n++) {
      for (i1 = 0; i1 < 8; i1++)
      {
        this._Tm[(n * 8 + i1)] = i;
        i += j;
        this._Tr[(n * 8 + i1)] = k;
        k = k + m & 0x1F;
      }
    }
    byte[] arrayOfByte = new byte[64];
    int i1 = paramArrayOfByte.length;
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, i1);
    for (int i2 = 0; i2 < 8; i2++) {
      this._workingKey[i2] = BytesTo32bits(arrayOfByte, i2 * 4);
    }
    for (i2 = 0; i2 < 12; i2++)
    {
      int i3 = i2 * 2 * 8;
      this._workingKey[6] ^= F1(this._workingKey[7], this._Tm[i3], this._Tr[i3]);
      this._workingKey[5] ^= F2(this._workingKey[6], this._Tm[(i3 + 1)], this._Tr[(i3 + 1)]);
      this._workingKey[4] ^= F3(this._workingKey[5], this._Tm[(i3 + 2)], this._Tr[(i3 + 2)]);
      this._workingKey[3] ^= F1(this._workingKey[4], this._Tm[(i3 + 3)], this._Tr[(i3 + 3)]);
      this._workingKey[2] ^= F2(this._workingKey[3], this._Tm[(i3 + 4)], this._Tr[(i3 + 4)]);
      this._workingKey[1] ^= F3(this._workingKey[2], this._Tm[(i3 + 5)], this._Tr[(i3 + 5)]);
      this._workingKey[0] ^= F1(this._workingKey[1], this._Tm[(i3 + 6)], this._Tr[(i3 + 6)]);
      this._workingKey[7] ^= F2(this._workingKey[0], this._Tm[(i3 + 7)], this._Tr[(i3 + 7)]);
      i3 = (i2 * 2 + 1) * 8;
      this._workingKey[6] ^= F1(this._workingKey[7], this._Tm[i3], this._Tr[i3]);
      this._workingKey[5] ^= F2(this._workingKey[6], this._Tm[(i3 + 1)], this._Tr[(i3 + 1)]);
      this._workingKey[4] ^= F3(this._workingKey[5], this._Tm[(i3 + 2)], this._Tr[(i3 + 2)]);
      this._workingKey[3] ^= F1(this._workingKey[4], this._Tm[(i3 + 3)], this._Tr[(i3 + 3)]);
      this._workingKey[2] ^= F2(this._workingKey[3], this._Tm[(i3 + 4)], this._Tr[(i3 + 4)]);
      this._workingKey[1] ^= F3(this._workingKey[2], this._Tm[(i3 + 5)], this._Tr[(i3 + 5)]);
      this._workingKey[0] ^= F1(this._workingKey[1], this._Tm[(i3 + 6)], this._Tr[(i3 + 6)]);
      this._workingKey[7] ^= F2(this._workingKey[0], this._Tm[(i3 + 7)], this._Tr[(i3 + 7)]);
      this._Kr[(i2 * 4)] = (this._workingKey[0] & 0x1F);
      this._Kr[(i2 * 4 + 1)] = (this._workingKey[2] & 0x1F);
      this._Kr[(i2 * 4 + 2)] = (this._workingKey[4] & 0x1F);
      this._Kr[(i2 * 4 + 3)] = (this._workingKey[6] & 0x1F);
      this._Km[(i2 * 4)] = this._workingKey[7];
      this._Km[(i2 * 4 + 1)] = this._workingKey[5];
      this._Km[(i2 * 4 + 2)] = this._workingKey[3];
      this._Km[(i2 * 4 + 3)] = this._workingKey[1];
    }
  }
  
  protected int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int[] arrayOfInt = new int[4];
    int i = BytesTo32bits(paramArrayOfByte1, paramInt1);
    int j = BytesTo32bits(paramArrayOfByte1, paramInt1 + 4);
    int k = BytesTo32bits(paramArrayOfByte1, paramInt1 + 8);
    int m = BytesTo32bits(paramArrayOfByte1, paramInt1 + 12);
    CAST_Encipher(i, j, k, m, arrayOfInt);
    Bits32ToBytes(arrayOfInt[0], paramArrayOfByte2, paramInt2);
    Bits32ToBytes(arrayOfInt[1], paramArrayOfByte2, paramInt2 + 4);
    Bits32ToBytes(arrayOfInt[2], paramArrayOfByte2, paramInt2 + 8);
    Bits32ToBytes(arrayOfInt[3], paramArrayOfByte2, paramInt2 + 12);
    return 16;
  }
  
  protected int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    int[] arrayOfInt = new int[4];
    int i = BytesTo32bits(paramArrayOfByte1, paramInt1);
    int j = BytesTo32bits(paramArrayOfByte1, paramInt1 + 4);
    int k = BytesTo32bits(paramArrayOfByte1, paramInt1 + 8);
    int m = BytesTo32bits(paramArrayOfByte1, paramInt1 + 12);
    CAST_Decipher(i, j, k, m, arrayOfInt);
    Bits32ToBytes(arrayOfInt[0], paramArrayOfByte2, paramInt2);
    Bits32ToBytes(arrayOfInt[1], paramArrayOfByte2, paramInt2 + 4);
    Bits32ToBytes(arrayOfInt[2], paramArrayOfByte2, paramInt2 + 8);
    Bits32ToBytes(arrayOfInt[3], paramArrayOfByte2, paramInt2 + 12);
    return 16;
  }
  
  protected final void CAST_Encipher(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    int i;
    for (int j = 0; j < 6; j++)
    {
      i = j * 4;
      paramInt3 ^= F1(paramInt4, this._Km[i], this._Kr[i]);
      paramInt2 ^= F2(paramInt3, this._Km[(i + 1)], this._Kr[(i + 1)]);
      paramInt1 ^= F3(paramInt2, this._Km[(i + 2)], this._Kr[(i + 2)]);
      paramInt4 ^= F1(paramInt1, this._Km[(i + 3)], this._Kr[(i + 3)]);
    }
    for (j = 6; j < 12; j++)
    {
      i = j * 4;
      paramInt4 ^= F1(paramInt1, this._Km[(i + 3)], this._Kr[(i + 3)]);
      paramInt1 ^= F3(paramInt2, this._Km[(i + 2)], this._Kr[(i + 2)]);
      paramInt2 ^= F2(paramInt3, this._Km[(i + 1)], this._Kr[(i + 1)]);
      paramInt3 ^= F1(paramInt4, this._Km[i], this._Kr[i]);
    }
    paramArrayOfInt[0] = paramInt1;
    paramArrayOfInt[1] = paramInt2;
    paramArrayOfInt[2] = paramInt3;
    paramArrayOfInt[3] = paramInt4;
  }
  
  protected final void CAST_Decipher(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    int i;
    for (int j = 0; j < 6; j++)
    {
      i = (11 - j) * 4;
      paramInt3 ^= F1(paramInt4, this._Km[i], this._Kr[i]);
      paramInt2 ^= F2(paramInt3, this._Km[(i + 1)], this._Kr[(i + 1)]);
      paramInt1 ^= F3(paramInt2, this._Km[(i + 2)], this._Kr[(i + 2)]);
      paramInt4 ^= F1(paramInt1, this._Km[(i + 3)], this._Kr[(i + 3)]);
    }
    for (j = 6; j < 12; j++)
    {
      i = (11 - j) * 4;
      paramInt4 ^= F1(paramInt1, this._Km[(i + 3)], this._Kr[(i + 3)]);
      paramInt1 ^= F3(paramInt2, this._Km[(i + 2)], this._Kr[(i + 2)]);
      paramInt2 ^= F2(paramInt3, this._Km[(i + 1)], this._Kr[(i + 1)]);
      paramInt3 ^= F1(paramInt4, this._Km[i], this._Kr[i]);
    }
    paramArrayOfInt[0] = paramInt1;
    paramArrayOfInt[1] = paramInt2;
    paramArrayOfInt[2] = paramInt3;
    paramArrayOfInt[3] = paramInt4;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\CAST6Engine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */