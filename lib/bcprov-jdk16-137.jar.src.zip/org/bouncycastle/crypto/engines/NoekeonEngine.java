package org.bouncycastle.crypto.engines;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.KeyParameter;

public class NoekeonEngine
  implements BlockCipher
{
  private static final int genericSize = 16;
  private static final int[] nullVector = { 0, 0, 0, 0 };
  private static final int[] roundConstants = { 128, 27, 54, 108, 216, 171, 77, 154, 47, 94, 188, 99, 198, 151, 53, 106, 212 };
  private int[] state = new int[4];
  private int[] subKeys = new int[4];
  private int[] decryptKeys = new int[4];
  private boolean _initialised = false;
  private boolean _forEncryption;
  
  public String getAlgorithmName()
  {
    return "Noekeon";
  }
  
  public int getBlockSize()
  {
    return 16;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("invalid parameter passed to Noekeon init - " + paramCipherParameters.getClass().getName());
    }
    this._forEncryption = paramBoolean;
    this._initialised = true;
    KeyParameter localKeyParameter = (KeyParameter)paramCipherParameters;
    setKey(localKeyParameter.getKey());
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    if (!this._initialised) {
      throw new IllegalStateException(getAlgorithmName() + " not initialised");
    }
    if (paramInt1 + 16 > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + 16 > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    return this._forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset() {}
  
  private void setKey(byte[] paramArrayOfByte)
  {
    this.subKeys[0] = bytesToIntBig(paramArrayOfByte, 0);
    this.subKeys[1] = bytesToIntBig(paramArrayOfByte, 4);
    this.subKeys[2] = bytesToIntBig(paramArrayOfByte, 8);
    this.subKeys[3] = bytesToIntBig(paramArrayOfByte, 12);
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    this.state[0] = bytesToIntBig(paramArrayOfByte1, paramInt1);
    this.state[1] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 4);
    this.state[2] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 8);
    this.state[3] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 12);
    for (int i = 0; i < 16; i++)
    {
      this.state[0] ^= roundConstants[i];
      theta(this.state, this.subKeys);
      pi1(this.state);
      gamma(this.state);
      pi2(this.state);
    }
    this.state[0] ^= roundConstants[i];
    theta(this.state, this.subKeys);
    intToBytesBig(this.state[0], paramArrayOfByte2, paramInt2);
    intToBytesBig(this.state[1], paramArrayOfByte2, paramInt2 + 4);
    intToBytesBig(this.state[2], paramArrayOfByte2, paramInt2 + 8);
    intToBytesBig(this.state[3], paramArrayOfByte2, paramInt2 + 12);
    return 16;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
  {
    this.state[0] = bytesToIntBig(paramArrayOfByte1, paramInt1);
    this.state[1] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 4);
    this.state[2] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 8);
    this.state[3] = bytesToIntBig(paramArrayOfByte1, paramInt1 + 12);
    System.arraycopy(this.subKeys, 0, this.decryptKeys, 0, this.subKeys.length);
    theta(this.decryptKeys, nullVector);
    for (int i = 16; i > 0; i--)
    {
      theta(this.state, this.decryptKeys);
      this.state[0] ^= roundConstants[i];
      pi1(this.state);
      gamma(this.state);
      pi2(this.state);
    }
    theta(this.state, this.decryptKeys);
    this.state[0] ^= roundConstants[i];
    intToBytesBig(this.state[0], paramArrayOfByte2, paramInt2);
    intToBytesBig(this.state[1], paramArrayOfByte2, paramInt2 + 4);
    intToBytesBig(this.state[2], paramArrayOfByte2, paramInt2 + 8);
    intToBytesBig(this.state[3], paramArrayOfByte2, paramInt2 + 12);
    return 16;
  }
  
  private void gamma(int[] paramArrayOfInt)
  {
    paramArrayOfInt[1] ^= (paramArrayOfInt[3] ^ 0xFFFFFFFF) & (paramArrayOfInt[2] ^ 0xFFFFFFFF);
    paramArrayOfInt[0] ^= paramArrayOfInt[2] & paramArrayOfInt[1];
    int i = paramArrayOfInt[3];
    paramArrayOfInt[3] = paramArrayOfInt[0];
    paramArrayOfInt[0] = i;
    paramArrayOfInt[2] ^= paramArrayOfInt[0] ^ paramArrayOfInt[1] ^ paramArrayOfInt[3];
    paramArrayOfInt[1] ^= (paramArrayOfInt[3] ^ 0xFFFFFFFF) & (paramArrayOfInt[2] ^ 0xFFFFFFFF);
    paramArrayOfInt[0] ^= paramArrayOfInt[2] & paramArrayOfInt[1];
  }
  
  private void theta(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i = paramArrayOfInt1[0] ^ paramArrayOfInt1[2];
    i ^= rotl(i, 8) ^ rotl(i, 24);
    paramArrayOfInt1[1] ^= i;
    paramArrayOfInt1[3] ^= i;
    for (int j = 0; j < 4; j++) {
      paramArrayOfInt1[j] ^= paramArrayOfInt2[j];
    }
    i = paramArrayOfInt1[1] ^ paramArrayOfInt1[3];
    i ^= rotl(i, 8) ^ rotl(i, 24);
    paramArrayOfInt1[0] ^= i;
    paramArrayOfInt1[2] ^= i;
  }
  
  private void pi1(int[] paramArrayOfInt)
  {
    paramArrayOfInt[1] = rotl(paramArrayOfInt[1], 1);
    paramArrayOfInt[2] = rotl(paramArrayOfInt[2], 5);
    paramArrayOfInt[3] = rotl(paramArrayOfInt[3], 2);
  }
  
  private void pi2(int[] paramArrayOfInt)
  {
    paramArrayOfInt[1] = rotl(paramArrayOfInt[1], 31);
    paramArrayOfInt[2] = rotl(paramArrayOfInt[2], 27);
    paramArrayOfInt[3] = rotl(paramArrayOfInt[3], 30);
  }
  
  private int bytesToIntBig(byte[] paramArrayOfByte, int paramInt)
  {
    return paramArrayOfByte[(paramInt++)] << 24 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 16 | (paramArrayOfByte[(paramInt++)] & 0xFF) << 8 | paramArrayOfByte[paramInt] & 0xFF;
  }
  
  private void intToBytesBig(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 24));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 16));
    paramArrayOfByte[(paramInt2++)] = ((byte)(paramInt1 >>> 8));
    paramArrayOfByte[paramInt2] = ((byte)paramInt1);
  }
  
  private int rotl(int paramInt1, int paramInt2)
  {
    return paramInt1 << paramInt2 | paramInt1 >>> 32 - paramInt2;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\NoekeonEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */