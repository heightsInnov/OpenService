package org.bouncycastle.crypto.engines;

public class CamelliaWrapEngine
  extends RFC3394WrapEngine
{
  public CamelliaWrapEngine()
  {
    super(new CamelliaEngine());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\engines\CamelliaWrapEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */