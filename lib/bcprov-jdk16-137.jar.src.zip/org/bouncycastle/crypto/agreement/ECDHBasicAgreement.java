package org.bouncycastle.crypto.agreement;

import java.math.BigInteger;
import org.bouncycastle.crypto.BasicAgreement;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.math.ec.ECFieldElement;
import org.bouncycastle.math.ec.ECPoint;

public class ECDHBasicAgreement
  implements BasicAgreement
{
  private ECPrivateKeyParameters key;
  
  public void init(CipherParameters paramCipherParameters)
  {
    this.key = ((ECPrivateKeyParameters)paramCipherParameters);
  }
  
  public BigInteger calculateAgreement(CipherParameters paramCipherParameters)
  {
    ECPublicKeyParameters localECPublicKeyParameters = (ECPublicKeyParameters)paramCipherParameters;
    ECPoint localECPoint = localECPublicKeyParameters.getQ().multiply(this.key.getD());
    return localECPoint.getX().toBigInteger();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\agreement\ECDHBasicAgreement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */