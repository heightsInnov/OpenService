package org.bouncycastle.crypto.encodings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.params.AsymmetricKeyParameter;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class PKCS1Encoding
  implements AsymmetricBlockCipher
{
  public static final String STRICT_LENGTH_ENABLED_PROPERTY = "org.bouncycastle.pkcs1.strict";
  private static final int HEADER_LENGTH = 10;
  private SecureRandom random;
  private AsymmetricBlockCipher engine;
  private boolean forEncryption;
  private boolean forPrivateKey;
  private boolean useStrictLength;
  
  public PKCS1Encoding(AsymmetricBlockCipher paramAsymmetricBlockCipher)
  {
    this.engine = paramAsymmetricBlockCipher;
    this.useStrictLength = useStrict();
  }
  
  private boolean useStrict()
  {
    String str = System.getProperty("org.bouncycastle.pkcs1.strict");
    return (str == null) || (str.equals("true"));
  }
  
  public AsymmetricBlockCipher getUnderlyingCipher()
  {
    return this.engine;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    AsymmetricKeyParameter localAsymmetricKeyParameter;
    if ((paramCipherParameters instanceof ParametersWithRandom))
    {
      ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
      this.random = localParametersWithRandom.getRandom();
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)localParametersWithRandom.getParameters();
    }
    else
    {
      this.random = new SecureRandom();
      localAsymmetricKeyParameter = (AsymmetricKeyParameter)paramCipherParameters;
    }
    this.engine.init(paramBoolean, paramCipherParameters);
    this.forPrivateKey = localAsymmetricKeyParameter.isPrivate();
    this.forEncryption = paramBoolean;
  }
  
  public int getInputBlockSize()
  {
    int i = this.engine.getInputBlockSize();
    if (this.forEncryption) {
      return i - 10;
    }
    return i;
  }
  
  public int getOutputBlockSize()
  {
    int i = this.engine.getOutputBlockSize();
    if (this.forEncryption) {
      return i;
    }
    return i - 10;
  }
  
  public byte[] processBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    if (this.forEncryption) {
      return encodeBlock(paramArrayOfByte, paramInt1, paramInt2);
    }
    return decodeBlock(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  private byte[] encodeBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte = new byte[this.engine.getInputBlockSize()];
    int i;
    if (this.forPrivateKey)
    {
      arrayOfByte[0] = 1;
      for (i = 1; i != arrayOfByte.length - paramInt2 - 1; i++) {
        arrayOfByte[i] = -1;
      }
    }
    else
    {
      this.random.nextBytes(arrayOfByte);
      arrayOfByte[0] = 2;
      for (i = 1; i != arrayOfByte.length - paramInt2 - 1; i++) {
        while (arrayOfByte[i] == 0) {
          arrayOfByte[i] = ((byte)this.random.nextInt());
        }
      }
    }
    arrayOfByte[(arrayOfByte.length - paramInt2 - 1)] = 0;
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, arrayOfByte.length - paramInt2, paramInt2);
    return this.engine.processBlock(arrayOfByte, 0, arrayOfByte.length);
  }
  
  private byte[] decodeBlock(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws InvalidCipherTextException
  {
    byte[] arrayOfByte1 = this.engine.processBlock(paramArrayOfByte, paramInt1, paramInt2);
    if (arrayOfByte1.length < getOutputBlockSize()) {
      throw new InvalidCipherTextException("block truncated");
    }
    int i = arrayOfByte1[0];
    if ((i != 1) && (i != 2)) {
      throw new InvalidCipherTextException("unknown block type");
    }
    if ((this.useStrictLength) && (arrayOfByte1.length != this.engine.getOutputBlockSize())) {
      throw new InvalidCipherTextException("block incorrect size");
    }
    for (int j = 1; j != arrayOfByte1.length; j++)
    {
      int k = arrayOfByte1[j];
      if (k == 0) {
        break;
      }
      if ((i == 1) && (k != -1)) {
        throw new InvalidCipherTextException("block padding incorrect");
      }
    }
    j++;
    if ((j >= arrayOfByte1.length) || (j < 10)) {
      throw new InvalidCipherTextException("no data in block");
    }
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length - j];
    System.arraycopy(arrayOfByte1, j, arrayOfByte2, 0, arrayOfByte2.length);
    return arrayOfByte2;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\encodings\PKCS1Encoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */