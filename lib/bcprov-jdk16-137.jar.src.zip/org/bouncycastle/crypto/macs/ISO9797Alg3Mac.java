package org.bouncycastle.crypto.macs;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.engines.DESEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.BlockCipherPadding;
import org.bouncycastle.crypto.params.KeyParameter;

public class ISO9797Alg3Mac
  implements Mac
{
  private byte[] mac;
  private byte[] buf;
  private int bufOff;
  private BlockCipher cipher;
  private BlockCipherPadding padding;
  private int macSize;
  private KeyParameter lastKey2;
  private KeyParameter lastKey3;
  
  public ISO9797Alg3Mac(BlockCipher paramBlockCipher)
  {
    this(paramBlockCipher, paramBlockCipher.getBlockSize() * 8, null);
  }
  
  public ISO9797Alg3Mac(BlockCipher paramBlockCipher, BlockCipherPadding paramBlockCipherPadding)
  {
    this(paramBlockCipher, paramBlockCipher.getBlockSize() * 8, paramBlockCipherPadding);
  }
  
  public ISO9797Alg3Mac(BlockCipher paramBlockCipher, int paramInt)
  {
    this(paramBlockCipher, paramInt, null);
  }
  
  public ISO9797Alg3Mac(BlockCipher paramBlockCipher, int paramInt, BlockCipherPadding paramBlockCipherPadding)
  {
    if (paramInt % 8 != 0) {
      throw new IllegalArgumentException("MAC size must be multiple of 8");
    }
    if (!(paramBlockCipher instanceof DESEngine)) {
      throw new IllegalArgumentException("cipher must be instance of DESEngine");
    }
    this.cipher = new CBCBlockCipher(paramBlockCipher);
    this.padding = paramBlockCipherPadding;
    this.macSize = (paramInt / 8);
    this.mac = new byte[paramBlockCipher.getBlockSize()];
    this.buf = new byte[paramBlockCipher.getBlockSize()];
    this.bufOff = 0;
  }
  
  public String getAlgorithmName()
  {
    return "ISO9797Alg3";
  }
  
  public void init(CipherParameters paramCipherParameters)
  {
    reset();
    if (!(paramCipherParameters instanceof KeyParameter)) {
      throw new IllegalArgumentException("params must be an instance of KeyParameter");
    }
    KeyParameter localKeyParameter1 = (KeyParameter)paramCipherParameters;
    byte[] arrayOfByte = localKeyParameter1.getKey();
    KeyParameter localKeyParameter2;
    if (arrayOfByte.length == 16)
    {
      localKeyParameter2 = new KeyParameter(arrayOfByte, 0, 8);
      this.lastKey2 = new KeyParameter(arrayOfByte, 8, 8);
      this.lastKey3 = localKeyParameter2;
    }
    else if (arrayOfByte.length == 24)
    {
      localKeyParameter2 = new KeyParameter(arrayOfByte, 0, 8);
      this.lastKey2 = new KeyParameter(arrayOfByte, 8, 8);
      this.lastKey3 = new KeyParameter(arrayOfByte, 16, 8);
    }
    else
    {
      throw new IllegalArgumentException("Key must be either 112 or 168 bit long");
    }
    this.cipher.init(true, localKeyParameter2);
  }
  
  public int getMacSize()
  {
    return this.macSize;
  }
  
  public void update(byte paramByte)
  {
    int i = 0;
    if (this.bufOff == this.buf.length)
    {
      i = this.cipher.processBlock(this.buf, 0, this.mac, 0);
      this.bufOff = 0;
    }
    this.buf[(this.bufOff++)] = paramByte;
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramInt2 < 0) {
      throw new IllegalArgumentException("Can't have a negative input length!");
    }
    int i = this.cipher.getBlockSize();
    int j = 0;
    int k = i - this.bufOff;
    if (paramInt2 > k)
    {
      System.arraycopy(paramArrayOfByte, paramInt1, this.buf, this.bufOff, k);
      j += this.cipher.processBlock(this.buf, 0, this.mac, 0);
      this.bufOff = 0;
      paramInt2 -= k;
      paramInt1 += k;
      while (paramInt2 > i)
      {
        j += this.cipher.processBlock(paramArrayOfByte, paramInt1, this.mac, 0);
        paramInt2 -= i;
        paramInt1 += i;
      }
    }
    System.arraycopy(paramArrayOfByte, paramInt1, this.buf, this.bufOff, paramInt2);
    this.bufOff += paramInt2;
  }
  
  public int doFinal(byte[] paramArrayOfByte, int paramInt)
  {
    int i = this.cipher.getBlockSize();
    if (this.padding == null) {
      while (this.bufOff < i)
      {
        this.buf[this.bufOff] = 0;
        this.bufOff += 1;
      }
    }
    if (this.bufOff == i)
    {
      this.cipher.processBlock(this.buf, 0, this.mac, 0);
      this.bufOff = 0;
    }
    this.padding.addPadding(this.buf, this.bufOff);
    this.cipher.processBlock(this.buf, 0, this.mac, 0);
    DESEngine localDESEngine = new DESEngine();
    localDESEngine.init(false, this.lastKey2);
    localDESEngine.processBlock(this.mac, 0, this.mac, 0);
    localDESEngine.init(true, this.lastKey3);
    localDESEngine.processBlock(this.mac, 0, this.mac, 0);
    System.arraycopy(this.mac, 0, paramArrayOfByte, paramInt, this.macSize);
    reset();
    return this.macSize;
  }
  
  public void reset()
  {
    for (int i = 0; i < this.buf.length; i++) {
      this.buf[i] = 0;
    }
    this.bufOff = 0;
    this.cipher.reset();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\macs\ISO9797Alg3Mac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */