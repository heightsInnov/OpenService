package org.bouncycastle.crypto.macs;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.params.KeyParameter;

public class OldHMac
  implements Mac
{
  private static final int BLOCK_LENGTH = 64;
  private static final byte IPAD = 54;
  private static final byte OPAD = 92;
  private Digest digest;
  private int digestSize;
  private byte[] inputPad = new byte[64];
  private byte[] outputPad = new byte[64];
  
  /**
   * @deprecated
   */
  public OldHMac(Digest paramDigest)
  {
    this.digest = paramDigest;
    this.digestSize = paramDigest.getDigestSize();
  }
  
  public String getAlgorithmName()
  {
    return this.digest.getAlgorithmName() + "/HMAC";
  }
  
  public Digest getUnderlyingDigest()
  {
    return this.digest;
  }
  
  public void init(CipherParameters paramCipherParameters)
  {
    this.digest.reset();
    byte[] arrayOfByte = ((KeyParameter)paramCipherParameters).getKey();
    if (arrayOfByte.length > 64)
    {
      this.digest.update(arrayOfByte, 0, arrayOfByte.length);
      this.digest.doFinal(this.inputPad, 0);
      for (i = this.digestSize; i < this.inputPad.length; i++) {
        this.inputPad[i] = 0;
      }
    }
    else
    {
      System.arraycopy(arrayOfByte, 0, this.inputPad, 0, arrayOfByte.length);
      for (i = arrayOfByte.length; i < this.inputPad.length; i++) {
        this.inputPad[i] = 0;
      }
    }
    this.outputPad = new byte[this.inputPad.length];
    System.arraycopy(this.inputPad, 0, this.outputPad, 0, this.inputPad.length);
    for (int i = 0; i < this.inputPad.length; i++)
    {
      int tmp164_163 = i;
      byte[] tmp164_160 = this.inputPad;
      tmp164_160[tmp164_163] = ((byte)(tmp164_160[tmp164_163] ^ 0x36));
    }
    for (i = 0; i < this.outputPad.length; i++)
    {
      int tmp193_192 = i;
      byte[] tmp193_189 = this.outputPad;
      tmp193_189[tmp193_192] = ((byte)(tmp193_189[tmp193_192] ^ 0x5C));
    }
    this.digest.update(this.inputPad, 0, this.inputPad.length);
  }
  
  public int getMacSize()
  {
    return this.digestSize;
  }
  
  public void update(byte paramByte)
  {
    this.digest.update(paramByte);
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.digest.update(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public int doFinal(byte[] paramArrayOfByte, int paramInt)
  {
    byte[] arrayOfByte = new byte[this.digestSize];
    this.digest.doFinal(arrayOfByte, 0);
    this.digest.update(this.outputPad, 0, this.outputPad.length);
    this.digest.update(arrayOfByte, 0, arrayOfByte.length);
    int i = this.digest.doFinal(paramArrayOfByte, paramInt);
    reset();
    return i;
  }
  
  public void reset()
  {
    this.digest.reset();
    this.digest.update(this.inputPad, 0, this.inputPad.length);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\macs\OldHMac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */