package org.bouncycastle.crypto.prng;

public abstract interface RandomGenerator
{
  public abstract void addSeedMaterial(byte[] paramArrayOfByte);
  
  public abstract void addSeedMaterial(long paramLong);
  
  public abstract void nextBytes(byte[] paramArrayOfByte);
  
  public abstract void nextBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\prng\RandomGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */