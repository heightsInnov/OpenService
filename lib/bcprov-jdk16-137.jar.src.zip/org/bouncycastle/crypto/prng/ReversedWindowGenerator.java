package org.bouncycastle.crypto.prng;

public class ReversedWindowGenerator
  implements RandomGenerator
{
  private final RandomGenerator generator;
  private byte[] window;
  private int windowCount;
  
  public ReversedWindowGenerator(RandomGenerator paramRandomGenerator, int paramInt)
  {
    if (paramRandomGenerator == null) {
      throw new IllegalArgumentException("generator cannot be null");
    }
    if (paramInt < 2) {
      throw new IllegalArgumentException("windowSize must be at least 2");
    }
    this.generator = paramRandomGenerator;
    this.window = new byte[paramInt];
  }
  
  public void addSeedMaterial(byte[] paramArrayOfByte)
  {
    synchronized (this)
    {
      this.windowCount = 0;
      this.generator.addSeedMaterial(paramArrayOfByte);
    }
  }
  
  public void addSeedMaterial(long paramLong)
  {
    synchronized (this)
    {
      this.windowCount = 0;
      this.generator.addSeedMaterial(paramLong);
    }
  }
  
  public void nextBytes(byte[] paramArrayOfByte)
  {
    doNextBytes(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void nextBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    doNextBytes(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  private void doNextBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    synchronized (this)
    {
      int i = 0;
      while (i < paramInt2)
      {
        if (this.windowCount < 1)
        {
          this.generator.nextBytes(this.window, 0, this.window.length);
          this.windowCount = this.window.length;
        }
        paramArrayOfByte[(paramInt1 + i++)] = this.window[(--this.windowCount)];
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\prng\ReversedWindowGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */