package org.bouncycastle.crypto.prng;

import org.bouncycastle.crypto.Digest;

public class DigestRandomGenerator
  implements RandomGenerator
{
  private long counter;
  private Digest digest;
  private byte[] state;
  
  public DigestRandomGenerator(Digest paramDigest)
  {
    this.digest = paramDigest;
    this.state = new byte[paramDigest.getDigestSize()];
    this.counter = 1L;
  }
  
  public void addSeedMaterial(byte[] paramArrayOfByte)
  {
    synchronized (this)
    {
      digestUpdate(paramArrayOfByte);
    }
  }
  
  public void addSeedMaterial(long paramLong)
  {
    synchronized (this)
    {
      for (int i = 0; i != 8; i++)
      {
        digestUpdate((byte)(int)paramLong);
        paramLong >>>= 8;
      }
    }
  }
  
  public void nextBytes(byte[] paramArrayOfByte)
  {
    nextBytes(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void nextBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    synchronized (this)
    {
      int i = 0;
      digestDoFinal(this.state);
      int j = paramInt1 + paramInt2;
      for (int k = paramInt1; k != j; k++)
      {
        if (i == this.state.length)
        {
          digestUpdate(this.counter++);
          digestUpdate(this.state);
          digestDoFinal(this.state);
          i = 0;
        }
        paramArrayOfByte[k] = this.state[(i++)];
      }
      digestUpdate(this.counter++);
      digestUpdate(this.state);
    }
  }
  
  private void digestUpdate(long paramLong)
  {
    for (int i = 0; i != 8; i++)
    {
      this.digest.update((byte)(int)paramLong);
      paramLong >>>= 8;
    }
  }
  
  private void digestUpdate(byte[] paramArrayOfByte)
  {
    this.digest.update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  private void digestDoFinal(byte[] paramArrayOfByte)
  {
    this.digest.doFinal(paramArrayOfByte, 0);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\prng\DigestRandomGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */