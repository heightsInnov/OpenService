package org.bouncycastle.crypto.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.crypto.Mac;

public class MacInputStream
  extends FilterInputStream
{
  protected Mac mac;
  
  public MacInputStream(InputStream paramInputStream, Mac paramMac)
  {
    super(paramInputStream);
    this.mac = paramMac;
  }
  
  public int read()
    throws IOException
  {
    int i = this.in.read();
    if (i >= 0) {
      this.mac.update((byte)i);
    }
    return i;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    if (i >= 0) {
      this.mac.update(paramArrayOfByte, paramInt1, i);
    }
    return i;
  }
  
  public Mac getMac()
  {
    return this.mac;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\io\MacInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */