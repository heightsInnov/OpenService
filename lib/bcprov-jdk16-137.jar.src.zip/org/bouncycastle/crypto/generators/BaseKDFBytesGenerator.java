package org.bouncycastle.crypto.generators;

import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.DerivationFunction;
import org.bouncycastle.crypto.DerivationParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.params.ISO18033KDFParameters;
import org.bouncycastle.crypto.params.KDFParameters;

public class BaseKDFBytesGenerator
  implements DerivationFunction
{
  private int counterStart;
  private Digest digest;
  private byte[] shared;
  private byte[] iv;
  
  protected BaseKDFBytesGenerator(int paramInt, Digest paramDigest)
  {
    this.counterStart = paramInt;
    this.digest = paramDigest;
  }
  
  public void init(DerivationParameters paramDerivationParameters)
  {
    Object localObject;
    if ((paramDerivationParameters instanceof KDFParameters))
    {
      localObject = (KDFParameters)paramDerivationParameters;
      this.shared = ((KDFParameters)localObject).getSharedSecret();
      this.iv = ((KDFParameters)localObject).getIV();
    }
    else if ((paramDerivationParameters instanceof ISO18033KDFParameters))
    {
      localObject = (ISO18033KDFParameters)paramDerivationParameters;
      this.shared = ((ISO18033KDFParameters)localObject).getSeed();
      this.iv = null;
    }
    else
    {
      throw new IllegalArgumentException("KDF parameters required for KDF2Generator");
    }
  }
  
  public Digest getDigest()
  {
    return this.digest;
  }
  
  public int generateBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws DataLengthException, IllegalArgumentException
  {
    if (paramArrayOfByte.length - paramInt2 < paramInt1) {
      throw new DataLengthException("output buffer too small");
    }
    long l = paramInt2;
    int i = this.digest.getDigestSize();
    if (l > 8589934591L) {
      throw new IllegalArgumentException("Output length too large");
    }
    int j = (int)((l + i - 1L) / i);
    byte[] arrayOfByte = null;
    arrayOfByte = new byte[this.digest.getDigestSize()];
    int k = this.counterStart;
    for (int m = 0; m < j; m++)
    {
      this.digest.update(this.shared, 0, this.shared.length);
      this.digest.update((byte)(k >> 24));
      this.digest.update((byte)(k >> 16));
      this.digest.update((byte)(k >> 8));
      this.digest.update((byte)k);
      if (this.iv != null) {
        this.digest.update(this.iv, 0, this.iv.length);
      }
      this.digest.doFinal(arrayOfByte, 0);
      if (paramInt2 > i)
      {
        System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt1, i);
        paramInt1 += i;
        paramInt2 -= i;
      }
      else
      {
        System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt1, paramInt2);
      }
      k++;
    }
    this.digest.reset();
    return paramInt2;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\BaseKDFBytesGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */