package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAKeyGenerationParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAPrivateKeyParameters;
import org.bouncycastle.crypto.params.DSAPublicKeyParameters;

public class DSAKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private static final BigInteger ZERO = BigInteger.valueOf(0L);
  private DSAKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((DSAKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    DSAParameters localDSAParameters = this.param.getParameters();
    SecureRandom localSecureRandom = this.param.getRandom();
    BigInteger localBigInteger2 = localDSAParameters.getQ();
    BigInteger localBigInteger1 = localDSAParameters.getP();
    BigInteger localBigInteger3 = localDSAParameters.getG();
    BigInteger localBigInteger4;
    do
    {
      localBigInteger4 = new BigInteger(160, localSecureRandom);
    } while ((localBigInteger4.equals(ZERO)) || (localBigInteger4.compareTo(localBigInteger2) >= 0));
    BigInteger localBigInteger5 = localBigInteger3.modPow(localBigInteger4, localBigInteger1);
    return new AsymmetricCipherKeyPair(new DSAPublicKeyParameters(localBigInteger5, localDSAParameters), new DSAPrivateKeyParameters(localBigInteger4, localDSAParameters));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DSAKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */