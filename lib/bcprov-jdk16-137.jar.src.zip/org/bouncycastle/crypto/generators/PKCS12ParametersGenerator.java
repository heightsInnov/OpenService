package org.bouncycastle.crypto.generators;

import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.ExtendedDigest;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class PKCS12ParametersGenerator
  extends PBEParametersGenerator
{
  public static final int KEY_MATERIAL = 1;
  public static final int IV_MATERIAL = 2;
  public static final int MAC_MATERIAL = 3;
  private Digest digest;
  private int u;
  private int v;
  
  public PKCS12ParametersGenerator(Digest paramDigest)
  {
    this.digest = paramDigest;
    if ((paramDigest instanceof ExtendedDigest))
    {
      this.u = paramDigest.getDigestSize();
      this.v = ((ExtendedDigest)paramDigest).getByteLength();
    }
    else
    {
      throw new IllegalArgumentException("Digest " + paramDigest.getAlgorithmName() + " unsupported");
    }
  }
  
  private void adjust(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    int i = (paramArrayOfByte2[(paramArrayOfByte2.length - 1)] & 0xFF) + (paramArrayOfByte1[(paramInt + paramArrayOfByte2.length - 1)] & 0xFF) + 1;
    paramArrayOfByte1[(paramInt + paramArrayOfByte2.length - 1)] = ((byte)i);
    i >>>= 8;
    for (int j = paramArrayOfByte2.length - 2; j >= 0; j--)
    {
      i += (paramArrayOfByte2[j] & 0xFF) + (paramArrayOfByte1[(paramInt + j)] & 0xFF);
      paramArrayOfByte1[(paramInt + j)] = ((byte)i);
      i >>>= 8;
    }
  }
  
  private byte[] generateDerivedKey(int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = new byte[this.v];
    byte[] arrayOfByte2 = new byte[paramInt2];
    for (int i = 0; i != arrayOfByte1.length; i++) {
      arrayOfByte1[i] = ((byte)paramInt1);
    }
    byte[] arrayOfByte3;
    if ((this.salt != null) && (this.salt.length != 0))
    {
      arrayOfByte3 = new byte[this.v * ((this.salt.length + this.v - 1) / this.v)];
      for (int j = 0; j != arrayOfByte3.length; j++) {
        arrayOfByte3[j] = this.salt[(j % this.salt.length)];
      }
    }
    else
    {
      arrayOfByte3 = new byte[0];
    }
    byte[] arrayOfByte4;
    if ((this.password != null) && (this.password.length != 0))
    {
      arrayOfByte4 = new byte[this.v * ((this.password.length + this.v - 1) / this.v)];
      for (int k = 0; k != arrayOfByte4.length; k++) {
        arrayOfByte4[k] = this.password[(k % this.password.length)];
      }
    }
    else
    {
      arrayOfByte4 = new byte[0];
    }
    byte[] arrayOfByte5 = new byte[arrayOfByte3.length + arrayOfByte4.length];
    System.arraycopy(arrayOfByte3, 0, arrayOfByte5, 0, arrayOfByte3.length);
    System.arraycopy(arrayOfByte4, 0, arrayOfByte5, arrayOfByte3.length, arrayOfByte4.length);
    byte[] arrayOfByte6 = new byte[this.v];
    int m = (paramInt2 + this.u - 1) / this.u;
    for (int n = 1; n <= m; n++)
    {
      byte[] arrayOfByte7 = new byte[this.u];
      this.digest.update(arrayOfByte1, 0, arrayOfByte1.length);
      this.digest.update(arrayOfByte5, 0, arrayOfByte5.length);
      this.digest.doFinal(arrayOfByte7, 0);
      for (int i1 = 1; i1 != this.iterationCount; i1++)
      {
        this.digest.update(arrayOfByte7, 0, arrayOfByte7.length);
        this.digest.doFinal(arrayOfByte7, 0);
      }
      for (i1 = 0; i1 != arrayOfByte6.length; i1++) {
        arrayOfByte6[i1] = arrayOfByte7[(i1 % arrayOfByte7.length)];
      }
      for (i1 = 0; i1 != arrayOfByte5.length / this.v; i1++) {
        adjust(arrayOfByte5, i1 * this.v, arrayOfByte6);
      }
      if (n == m) {
        System.arraycopy(arrayOfByte7, 0, arrayOfByte2, (n - 1) * this.u, arrayOfByte2.length - (n - 1) * this.u);
      } else {
        System.arraycopy(arrayOfByte7, 0, arrayOfByte2, (n - 1) * this.u, arrayOfByte7.length);
      }
    }
    return arrayOfByte2;
  }
  
  public CipherParameters generateDerivedParameters(int paramInt)
  {
    paramInt /= 8;
    byte[] arrayOfByte = generateDerivedKey(1, paramInt);
    return new KeyParameter(arrayOfByte, 0, paramInt);
  }
  
  public CipherParameters generateDerivedParameters(int paramInt1, int paramInt2)
  {
    paramInt1 /= 8;
    paramInt2 /= 8;
    byte[] arrayOfByte1 = generateDerivedKey(1, paramInt1);
    byte[] arrayOfByte2 = generateDerivedKey(2, paramInt2);
    return new ParametersWithIV(new KeyParameter(arrayOfByte1, 0, paramInt1), arrayOfByte2, 0, paramInt2);
  }
  
  public CipherParameters generateDerivedMacParameters(int paramInt)
  {
    paramInt /= 8;
    byte[] arrayOfByte = generateDerivedKey(3, paramInt);
    return new KeyParameter(arrayOfByte, 0, paramInt);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\PKCS12ParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */