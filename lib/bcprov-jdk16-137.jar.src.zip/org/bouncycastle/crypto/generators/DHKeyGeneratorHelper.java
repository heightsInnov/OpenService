package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;

class DHKeyGeneratorHelper
{
  private static final int MAX_ITERATIONS = 1000;
  static final DHKeyGeneratorHelper INSTANCE = new DHKeyGeneratorHelper();
  private static final BigInteger ZERO = BigInteger.valueOf(0L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  BigInteger calculatePrivate(BigInteger paramBigInteger, SecureRandom paramSecureRandom, int paramInt)
  {
    BigInteger localBigInteger1 = paramBigInteger.subtract(TWO);
    BigInteger localBigInteger2;
    if (paramInt == 0) {
      localBigInteger2 = createInRange(localBigInteger1, paramSecureRandom);
    } else {
      do
      {
        localBigInteger2 = new BigInteger(paramInt, 0, paramSecureRandom);
      } while (localBigInteger2.equals(ZERO));
    }
    return localBigInteger2;
  }
  
  private BigInteger createInRange(BigInteger paramBigInteger, SecureRandom paramSecureRandom)
  {
    int i = paramBigInteger.bitLength();
    int j = 0;
    BigInteger localBigInteger;
    do
    {
      localBigInteger = new BigInteger(i, paramSecureRandom);
      j++;
    } while (((localBigInteger.equals(ZERO)) || (localBigInteger.compareTo(paramBigInteger) > 0)) && (j != 1000));
    if (j == 1000) {
      return new BigInteger(i - 1, paramSecureRandom).setBit(0);
    }
    return localBigInteger;
  }
  
  BigInteger calculatePublic(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    return paramBigInteger2.modPow(paramBigInteger3, paramBigInteger1);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DHKeyGeneratorHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */