package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.params.DHParameters;

public class DHParametersGenerator
{
  private int size;
  private int certainty;
  private SecureRandom random;
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  public void init(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    this.size = paramInt1;
    this.certainty = paramInt2;
    this.random = paramSecureRandom;
  }
  
  public DHParameters generateParameters()
  {
    BigInteger[] arrayOfBigInteger = DHParametersHelper.generateSafePrimes(this.size, this.certainty, this.random);
    BigInteger localBigInteger1 = arrayOfBigInteger[0];
    BigInteger localBigInteger2 = arrayOfBigInteger[1];
    int i = this.size - 1;
    BigInteger localBigInteger3;
    do
    {
      localBigInteger3 = new BigInteger(i, this.random);
    } while ((localBigInteger3.modPow(TWO, localBigInteger1).equals(ONE)) || (localBigInteger3.modPow(localBigInteger2, localBigInteger1).equals(ONE)));
    return new DHParameters(localBigInteger1, localBigInteger3, localBigInteger2);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DHParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */