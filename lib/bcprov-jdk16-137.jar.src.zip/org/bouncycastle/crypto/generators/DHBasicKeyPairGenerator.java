package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.DHKeyGenerationParameters;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.crypto.params.DHPrivateKeyParameters;
import org.bouncycastle.crypto.params.DHPublicKeyParameters;

public class DHBasicKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private DHKeyGeneratorHelper helper = DHKeyGeneratorHelper.INSTANCE;
  private DHKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((DHKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    DHParameters localDHParameters = this.param.getParameters();
    BigInteger localBigInteger1 = localDHParameters.getP();
    BigInteger localBigInteger2 = this.helper.calculatePrivate(localBigInteger1, this.param.getRandom(), localDHParameters.getJ());
    BigInteger localBigInteger3 = this.helper.calculatePublic(localBigInteger1, localDHParameters.getG(), localBigInteger2);
    return new AsymmetricCipherKeyPair(new DHPublicKeyParameters(localBigInteger3, localDHParameters), new DHPrivateKeyParameters(localBigInteger2, localDHParameters));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DHBasicKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */