package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.params.GOST3410Parameters;
import org.bouncycastle.crypto.params.GOST3410ValidationParameters;

public class GOST3410ParametersGenerator
{
  private int size;
  private int typeproc;
  private SecureRandom init_random;
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  public void init(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    this.size = paramInt1;
    this.typeproc = paramInt2;
    this.init_random = paramSecureRandom;
  }
  
  private int procedure_A(int paramInt1, int paramInt2, BigInteger[] paramArrayOfBigInteger, int paramInt3)
  {
    while ((paramInt1 < 0) || (paramInt1 > 65536)) {
      paramInt1 = this.init_random.nextInt() / 32768;
    }
    while ((paramInt2 < 0) || (paramInt2 > 65536) || (paramInt2 / 2 == 0)) {
      paramInt2 = this.init_random.nextInt() / 32768 + 1;
    }
    BigInteger localBigInteger1 = new BigInteger(Integer.toString(paramInt2));
    BigInteger localBigInteger2 = new BigInteger("19381");
    BigInteger[] arrayOfBigInteger1 = new BigInteger[1];
    arrayOfBigInteger1[0] = new BigInteger(Integer.toString(paramInt1));
    int[] arrayOfInt1 = new int[1];
    arrayOfInt1[0] = paramInt3;
    int i = 0;
    for (int j = 0; arrayOfInt1[j] >= 17; j++)
    {
      int[] arrayOfInt2 = new int[arrayOfInt1.length + 1];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, arrayOfInt1.length);
      arrayOfInt1 = new int[arrayOfInt2.length];
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      arrayOfInt1[(j + 1)] = (arrayOfInt1[j] / 2);
      i = j + 1;
    }
    BigInteger[] arrayOfBigInteger2 = new BigInteger[i + 1];
    arrayOfBigInteger2[i] = new BigInteger("8003", 16);
    int k = i - 1;
    for (int m = 0; m < i; m++)
    {
      int n = arrayOfInt1[k] / 16;
      BigInteger[] arrayOfBigInteger3 = new BigInteger[arrayOfBigInteger1.length];
      System.arraycopy(arrayOfBigInteger1, 0, arrayOfBigInteger3, 0, arrayOfBigInteger1.length);
      arrayOfBigInteger1 = new BigInteger[n + 1];
      System.arraycopy(arrayOfBigInteger3, 0, arrayOfBigInteger1, 0, arrayOfBigInteger3.length);
      for (int i1 = 0; i1 < n; i1++) {
        arrayOfBigInteger1[(i1 + 1)] = arrayOfBigInteger1[i1].multiply(localBigInteger2).add(localBigInteger1).mod(TWO.pow(16));
      }
      BigInteger localBigInteger3 = new BigInteger("0");
      for (int i2 = 0; i2 < n; i2++) {
        localBigInteger3 = localBigInteger3.add(arrayOfBigInteger1[i2].multiply(TWO.pow(16 * i2)));
      }
      arrayOfBigInteger1[0] = arrayOfBigInteger1[n];
      BigInteger localBigInteger4 = TWO.pow(arrayOfInt1[k] - 1).divide(arrayOfBigInteger2[(k + 1)]).add(TWO.pow(arrayOfInt1[k] - 1).multiply(localBigInteger3).divide(arrayOfBigInteger2[(k + 1)].multiply(TWO.pow(16 * n))));
      if (localBigInteger4.mod(TWO).compareTo(ONE) == 0) {
        localBigInteger4 = localBigInteger4.add(ONE);
      }
      for (int i3 = 0;; i3 += 2)
      {
        arrayOfBigInteger2[k] = arrayOfBigInteger2[(k + 1)].multiply(localBigInteger4.add(BigInteger.valueOf(i3))).add(ONE);
        if (arrayOfBigInteger2[k].compareTo(TWO.pow(arrayOfInt1[k])) == 1) {
          break;
        }
        if ((TWO.modPow(arrayOfBigInteger2[(k + 1)].multiply(localBigInteger4.add(BigInteger.valueOf(i3))), arrayOfBigInteger2[k]).compareTo(ONE) == 0) && (TWO.modPow(localBigInteger4.add(BigInteger.valueOf(i3)), arrayOfBigInteger2[k]).compareTo(ONE) != 0))
        {
          k--;
          break label639;
        }
      }
      label639:
      if (k < 0)
      {
        paramArrayOfBigInteger[0] = arrayOfBigInteger2[0];
        paramArrayOfBigInteger[1] = arrayOfBigInteger2[1];
        return arrayOfBigInteger1[0].intValue();
      }
    }
    return arrayOfBigInteger1[0].intValue();
  }
  
  private long procedure_Aa(long paramLong1, long paramLong2, BigInteger[] paramArrayOfBigInteger, int paramInt)
  {
    while ((paramLong1 < 0L) || (paramLong1 > 4294967296L)) {
      paramLong1 = this.init_random.nextInt() * 2;
    }
    while ((paramLong2 < 0L) || (paramLong2 > 4294967296L) || (paramLong2 / 2L == 0L)) {
      paramLong2 = this.init_random.nextInt() * 2 + 1;
    }
    BigInteger localBigInteger1 = new BigInteger(Long.toString(paramLong2));
    BigInteger localBigInteger2 = new BigInteger("97781173");
    BigInteger[] arrayOfBigInteger1 = new BigInteger[1];
    arrayOfBigInteger1[0] = new BigInteger(Long.toString(paramLong1));
    int[] arrayOfInt1 = new int[1];
    arrayOfInt1[0] = paramInt;
    int i = 0;
    for (int j = 0; arrayOfInt1[j] >= 33; j++)
    {
      int[] arrayOfInt2 = new int[arrayOfInt1.length + 1];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, arrayOfInt1.length);
      arrayOfInt1 = new int[arrayOfInt2.length];
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      arrayOfInt1[(j + 1)] = (arrayOfInt1[j] / 2);
      i = j + 1;
    }
    BigInteger[] arrayOfBigInteger2 = new BigInteger[i + 1];
    arrayOfBigInteger2[i] = new BigInteger("8000000B", 16);
    int k = i - 1;
    for (int m = 0; m < i; m++)
    {
      int n = arrayOfInt1[k] / 32;
      BigInteger[] arrayOfBigInteger3 = new BigInteger[arrayOfBigInteger1.length];
      System.arraycopy(arrayOfBigInteger1, 0, arrayOfBigInteger3, 0, arrayOfBigInteger1.length);
      arrayOfBigInteger1 = new BigInteger[n + 1];
      System.arraycopy(arrayOfBigInteger3, 0, arrayOfBigInteger1, 0, arrayOfBigInteger3.length);
      for (int i1 = 0; i1 < n; i1++) {
        arrayOfBigInteger1[(i1 + 1)] = arrayOfBigInteger1[i1].multiply(localBigInteger2).add(localBigInteger1).mod(TWO.pow(32));
      }
      BigInteger localBigInteger3 = new BigInteger("0");
      for (int i2 = 0; i2 < n; i2++) {
        localBigInteger3 = localBigInteger3.add(arrayOfBigInteger1[i2].multiply(TWO.pow(32 * i2)));
      }
      arrayOfBigInteger1[0] = arrayOfBigInteger1[n];
      BigInteger localBigInteger4 = TWO.pow(arrayOfInt1[k] - 1).divide(arrayOfBigInteger2[(k + 1)]).add(TWO.pow(arrayOfInt1[k] - 1).multiply(localBigInteger3).divide(arrayOfBigInteger2[(k + 1)].multiply(TWO.pow(32 * n))));
      if (localBigInteger4.mod(TWO).compareTo(ONE) == 0) {
        localBigInteger4 = localBigInteger4.add(ONE);
      }
      for (int i3 = 0;; i3 += 2)
      {
        arrayOfBigInteger2[k] = arrayOfBigInteger2[(k + 1)].multiply(localBigInteger4.add(BigInteger.valueOf(i3))).add(ONE);
        if (arrayOfBigInteger2[k].compareTo(TWO.pow(arrayOfInt1[k])) == 1) {
          break;
        }
        if ((TWO.modPow(arrayOfBigInteger2[(k + 1)].multiply(localBigInteger4.add(BigInteger.valueOf(i3))), arrayOfBigInteger2[k]).compareTo(ONE) == 0) && (TWO.modPow(localBigInteger4.add(BigInteger.valueOf(i3)), arrayOfBigInteger2[k]).compareTo(ONE) != 0))
        {
          k--;
          break label651;
        }
      }
      label651:
      if (k < 0)
      {
        paramArrayOfBigInteger[0] = arrayOfBigInteger2[0];
        paramArrayOfBigInteger[1] = arrayOfBigInteger2[1];
        return arrayOfBigInteger1[0].longValue();
      }
    }
    return arrayOfBigInteger1[0].longValue();
  }
  
  private void procedure_B(int paramInt1, int paramInt2, BigInteger[] paramArrayOfBigInteger)
  {
    while ((paramInt1 < 0) || (paramInt1 > 65536)) {
      paramInt1 = this.init_random.nextInt() / 32768;
    }
    while ((paramInt2 < 0) || (paramInt2 > 65536) || (paramInt2 / 2 == 0)) {
      paramInt2 = this.init_random.nextInt() / 32768 + 1;
    }
    BigInteger[] arrayOfBigInteger1 = new BigInteger[2];
    BigInteger localBigInteger1 = null;
    BigInteger localBigInteger2 = null;
    BigInteger localBigInteger3 = null;
    BigInteger localBigInteger4 = new BigInteger(Integer.toString(paramInt2));
    BigInteger localBigInteger5 = new BigInteger("19381");
    paramInt1 = procedure_A(paramInt1, paramInt2, arrayOfBigInteger1, 256);
    localBigInteger1 = arrayOfBigInteger1[0];
    paramInt1 = procedure_A(paramInt1, paramInt2, arrayOfBigInteger1, 512);
    localBigInteger2 = arrayOfBigInteger1[0];
    BigInteger[] arrayOfBigInteger2 = new BigInteger[65];
    arrayOfBigInteger2[0] = new BigInteger(Integer.toString(paramInt1));
    int i = 1024;
    for (int j = 0; j < 64; j++) {
      arrayOfBigInteger2[(j + 1)] = arrayOfBigInteger2[j].multiply(localBigInteger5).add(localBigInteger4).mod(TWO.pow(16));
    }
    BigInteger localBigInteger6 = new BigInteger("0");
    for (int k = 0; k < 64; k++) {
      localBigInteger6 = localBigInteger6.add(arrayOfBigInteger2[k].multiply(TWO.pow(16 * k)));
    }
    arrayOfBigInteger2[0] = arrayOfBigInteger2[64];
    BigInteger localBigInteger7 = TWO.pow(i - 1).divide(localBigInteger1.multiply(localBigInteger2)).add(TWO.pow(i - 1).multiply(localBigInteger6).divide(localBigInteger1.multiply(localBigInteger2).multiply(TWO.pow(1024))));
    if (localBigInteger7.mod(TWO).compareTo(ONE) == 0) {
      localBigInteger7 = localBigInteger7.add(ONE);
    }
    for (int m = 0;; m += 2)
    {
      localBigInteger3 = localBigInteger1.multiply(localBigInteger2).multiply(localBigInteger7.add(BigInteger.valueOf(m))).add(ONE);
      if (localBigInteger3.compareTo(TWO.pow(i)) == 1) {
        break;
      }
      if ((TWO.modPow(localBigInteger1.multiply(localBigInteger2).multiply(localBigInteger7.add(BigInteger.valueOf(m))), localBigInteger3).compareTo(ONE) == 0) && (TWO.modPow(localBigInteger1.multiply(localBigInteger7.add(BigInteger.valueOf(m))), localBigInteger3).compareTo(ONE) != 0))
      {
        paramArrayOfBigInteger[0] = localBigInteger3;
        paramArrayOfBigInteger[1] = localBigInteger1;
        return;
      }
    }
  }
  
  private void procedure_Bb(long paramLong1, long paramLong2, BigInteger[] paramArrayOfBigInteger)
  {
    while ((paramLong1 < 0L) || (paramLong1 > 4294967296L)) {
      paramLong1 = this.init_random.nextInt() * 2;
    }
    while ((paramLong2 < 0L) || (paramLong2 > 4294967296L) || (paramLong2 / 2L == 0L)) {
      paramLong2 = this.init_random.nextInt() * 2 + 1;
    }
    BigInteger[] arrayOfBigInteger1 = new BigInteger[2];
    BigInteger localBigInteger1 = null;
    BigInteger localBigInteger2 = null;
    BigInteger localBigInteger3 = null;
    BigInteger localBigInteger4 = new BigInteger(Long.toString(paramLong2));
    BigInteger localBigInteger5 = new BigInteger("97781173");
    paramLong1 = procedure_Aa(paramLong1, paramLong2, arrayOfBigInteger1, 256);
    localBigInteger1 = arrayOfBigInteger1[0];
    paramLong1 = procedure_Aa(paramLong1, paramLong2, arrayOfBigInteger1, 512);
    localBigInteger2 = arrayOfBigInteger1[0];
    BigInteger[] arrayOfBigInteger2 = new BigInteger[33];
    arrayOfBigInteger2[0] = new BigInteger(Long.toString(paramLong1));
    int i = 1024;
    for (int j = 0; j < 32; j++) {
      arrayOfBigInteger2[(j + 1)] = arrayOfBigInteger2[j].multiply(localBigInteger5).add(localBigInteger4).mod(TWO.pow(32));
    }
    BigInteger localBigInteger6 = new BigInteger("0");
    for (int k = 0; k < 32; k++) {
      localBigInteger6 = localBigInteger6.add(arrayOfBigInteger2[k].multiply(TWO.pow(32 * k)));
    }
    arrayOfBigInteger2[0] = arrayOfBigInteger2[32];
    BigInteger localBigInteger7 = TWO.pow(i - 1).divide(localBigInteger1.multiply(localBigInteger2)).add(TWO.pow(i - 1).multiply(localBigInteger6).divide(localBigInteger1.multiply(localBigInteger2).multiply(TWO.pow(1024))));
    if (localBigInteger7.mod(TWO).compareTo(ONE) == 0) {
      localBigInteger7 = localBigInteger7.add(ONE);
    }
    for (int m = 0;; m += 2)
    {
      localBigInteger3 = localBigInteger1.multiply(localBigInteger2).multiply(localBigInteger7.add(BigInteger.valueOf(m))).add(ONE);
      if (localBigInteger3.compareTo(TWO.pow(i)) == 1) {
        break;
      }
      if ((TWO.modPow(localBigInteger1.multiply(localBigInteger2).multiply(localBigInteger7.add(BigInteger.valueOf(m))), localBigInteger3).compareTo(ONE) == 0) && (TWO.modPow(localBigInteger1.multiply(localBigInteger7.add(BigInteger.valueOf(m))), localBigInteger3).compareTo(ONE) != 0))
      {
        paramArrayOfBigInteger[0] = localBigInteger3;
        paramArrayOfBigInteger[1] = localBigInteger1;
        return;
      }
    }
  }
  
  private BigInteger procedure_C(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    BigInteger localBigInteger1 = paramBigInteger1.subtract(ONE);
    BigInteger localBigInteger2 = localBigInteger1.divide(paramBigInteger2);
    int i = paramBigInteger1.bitLength();
    for (;;)
    {
      BigInteger localBigInteger3 = new BigInteger(i, this.init_random);
      if ((localBigInteger3.compareTo(ONE) > 0) && (localBigInteger3.compareTo(localBigInteger1) < 0))
      {
        BigInteger localBigInteger4 = localBigInteger3.modPow(localBigInteger2, paramBigInteger1);
        if (localBigInteger4.compareTo(ONE) != 0) {
          return localBigInteger4;
        }
      }
    }
  }
  
  public GOST3410Parameters generateParameters()
  {
    BigInteger[] arrayOfBigInteger = new BigInteger[2];
    BigInteger localBigInteger1 = null;
    BigInteger localBigInteger2 = null;
    BigInteger localBigInteger3 = null;
    if (this.typeproc == 1)
    {
      int i = this.init_random.nextInt();
      int j = this.init_random.nextInt();
      switch (this.size)
      {
      case 512: 
        procedure_A(i, j, arrayOfBigInteger, 512);
        break;
      case 1024: 
        procedure_B(i, j, arrayOfBigInteger);
        break;
      default: 
        throw new IllegalArgumentException("Ooops! key size 512 or 1024 bit.");
      }
      localBigInteger2 = arrayOfBigInteger[0];
      localBigInteger1 = arrayOfBigInteger[1];
      localBigInteger3 = procedure_C(localBigInteger2, localBigInteger1);
      return new GOST3410Parameters(localBigInteger2, localBigInteger1, localBigInteger3, new GOST3410ValidationParameters(i, j));
    }
    long l1 = this.init_random.nextLong();
    long l2 = this.init_random.nextLong();
    switch (this.size)
    {
    case 512: 
      procedure_Aa(l1, l2, arrayOfBigInteger, 512);
      break;
    case 1024: 
      procedure_Bb(l1, l2, arrayOfBigInteger);
      break;
    default: 
      throw new IllegalStateException("Ooops! key size 512 or 1024 bit.");
    }
    localBigInteger2 = arrayOfBigInteger[0];
    localBigInteger1 = arrayOfBigInteger[1];
    localBigInteger3 = procedure_C(localBigInteger2, localBigInteger1);
    return new GOST3410Parameters(localBigInteger2, localBigInteger1, localBigInteger3, new GOST3410ValidationParameters(l1, l2));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\GOST3410ParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */