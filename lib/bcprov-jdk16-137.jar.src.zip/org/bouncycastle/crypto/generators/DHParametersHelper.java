package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;

class DHParametersHelper
{
  private static BigInteger ONE = BigInteger.valueOf(1L);
  
  static BigInteger[] generateSafePrimes(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    int i = paramInt1 - 1;
    BigInteger localBigInteger2;
    BigInteger localBigInteger1;
    for (;;)
    {
      localBigInteger2 = new BigInteger(i, 2, paramSecureRandom);
      localBigInteger1 = localBigInteger2.shiftLeft(1).add(ONE);
      if (localBigInteger1.isProbablePrime(paramInt2)) {
        if (paramInt2 > 2) {
          if (localBigInteger2.isProbablePrime(paramInt2)) {
            break;
          }
        }
      }
    }
    return new BigInteger[] { localBigInteger1, localBigInteger2 };
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DHParametersHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */