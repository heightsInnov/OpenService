package org.bouncycastle.crypto.generators;

import java.security.SecureRandom;
import org.bouncycastle.crypto.CipherKeyGenerator;
import org.bouncycastle.crypto.params.DESParameters;

public class DESKeyGenerator
  extends CipherKeyGenerator
{
  public byte[] generateKey()
  {
    byte[] arrayOfByte = new byte[8];
    do
    {
      this.random.nextBytes(arrayOfByte);
      DESParameters.setOddParity(arrayOfByte);
    } while (DESParameters.isWeakKey(arrayOfByte, 0));
    return arrayOfByte;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DESKeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */