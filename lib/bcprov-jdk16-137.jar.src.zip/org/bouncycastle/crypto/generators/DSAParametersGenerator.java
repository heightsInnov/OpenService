package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.digests.SHA1Digest;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAValidationParameters;

public class DSAParametersGenerator
{
  private int size;
  private int certainty;
  private SecureRandom random;
  private static final BigInteger ONE = BigInteger.valueOf(1L);
  private static final BigInteger TWO = BigInteger.valueOf(2L);
  
  public void init(int paramInt1, int paramInt2, SecureRandom paramSecureRandom)
  {
    this.size = paramInt1;
    this.certainty = paramInt2;
    this.random = paramSecureRandom;
  }
  
  private void add(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    int i = (paramArrayOfByte2[(paramArrayOfByte2.length - 1)] & 0xFF) + paramInt;
    paramArrayOfByte1[(paramArrayOfByte2.length - 1)] = ((byte)i);
    i >>>= 8;
    for (int j = paramArrayOfByte2.length - 2; j >= 0; j--)
    {
      i += (paramArrayOfByte2[j] & 0xFF);
      paramArrayOfByte1[j] = ((byte)i);
      i >>>= 8;
    }
  }
  
  public DSAParameters generateParameters()
  {
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[20];
    byte[] arrayOfByte3 = new byte[20];
    byte[] arrayOfByte4 = new byte[20];
    SHA1Digest localSHA1Digest = new SHA1Digest();
    int i = (this.size - 1) / 160;
    byte[] arrayOfByte5 = new byte[this.size / 8];
    BigInteger localBigInteger1 = null;
    BigInteger localBigInteger2 = null;
    BigInteger localBigInteger3 = null;
    int j = 0;
    int k = 0;
    BigInteger localBigInteger5;
    while (k == 0)
    {
      do
      {
        this.random.nextBytes(arrayOfByte1);
        localSHA1Digest.update(arrayOfByte1, 0, arrayOfByte1.length);
        localSHA1Digest.doFinal(arrayOfByte2, 0);
        System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, arrayOfByte1.length);
        add(arrayOfByte3, arrayOfByte1, 1);
        localSHA1Digest.update(arrayOfByte3, 0, arrayOfByte3.length);
        localSHA1Digest.doFinal(arrayOfByte3, 0);
        for (m = 0; m != arrayOfByte4.length; m++) {
          arrayOfByte4[m] = ((byte)(arrayOfByte2[m] ^ arrayOfByte3[m]));
        }
        int tmp166_165 = 0;
        byte[] tmp166_163 = arrayOfByte4;
        tmp166_163[tmp166_165] = ((byte)(tmp166_163[tmp166_165] | 0xFFFFFF80));
        byte[] tmp177_173 = arrayOfByte4;
        tmp177_173[19] = ((byte)(tmp177_173[19] | 0x1));
        localBigInteger1 = new BigInteger(1, arrayOfByte4);
      } while (!localBigInteger1.isProbablePrime(this.certainty));
      j = 0;
      int m = 2;
      while (j < 4096)
      {
        for (int n = 0; n < i; n++)
        {
          add(arrayOfByte2, arrayOfByte1, m + n);
          localSHA1Digest.update(arrayOfByte2, 0, arrayOfByte2.length);
          localSHA1Digest.doFinal(arrayOfByte2, 0);
          System.arraycopy(arrayOfByte2, 0, arrayOfByte5, arrayOfByte5.length - (n + 1) * arrayOfByte2.length, arrayOfByte2.length);
        }
        add(arrayOfByte2, arrayOfByte1, m + i);
        localSHA1Digest.update(arrayOfByte2, 0, arrayOfByte2.length);
        localSHA1Digest.doFinal(arrayOfByte2, 0);
        System.arraycopy(arrayOfByte2, arrayOfByte2.length - (arrayOfByte5.length - i * arrayOfByte2.length), arrayOfByte5, 0, arrayOfByte5.length - i * arrayOfByte2.length);
        int tmp344_343 = 0;
        byte[] tmp344_341 = arrayOfByte5;
        tmp344_341[tmp344_343] = ((byte)(tmp344_341[tmp344_343] | 0xFFFFFF80));
        localBigInteger5 = new BigInteger(1, arrayOfByte5);
        BigInteger localBigInteger6 = localBigInteger5.mod(localBigInteger1.multiply(TWO));
        localBigInteger2 = localBigInteger5.subtract(localBigInteger6.subtract(ONE));
        if ((localBigInteger2.testBit(this.size - 1)) && (localBigInteger2.isProbablePrime(this.certainty)))
        {
          k = 1;
          break;
        }
        j++;
        m += i + 1;
      }
    }
    BigInteger localBigInteger4 = localBigInteger2.subtract(ONE).divide(localBigInteger1);
    do
    {
      do
      {
        localBigInteger5 = new BigInteger(this.size, this.random);
      } while ((localBigInteger5.compareTo(ONE) <= 0) || (localBigInteger5.compareTo(localBigInteger2.subtract(ONE)) >= 0));
      localBigInteger3 = localBigInteger5.modPow(localBigInteger4, localBigInteger2);
    } while (localBigInteger3.compareTo(ONE) <= 0);
    return new DSAParameters(localBigInteger2, localBigInteger1, localBigInteger3, new DSAValidationParameters(arrayOfByte1, j));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\DSAParametersGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */