package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import org.bouncycastle.crypto.KeyGenerationParameters;
import org.bouncycastle.crypto.params.ElGamalKeyGenerationParameters;
import org.bouncycastle.crypto.params.ElGamalParameters;
import org.bouncycastle.crypto.params.ElGamalPrivateKeyParameters;
import org.bouncycastle.crypto.params.ElGamalPublicKeyParameters;

public class ElGamalKeyPairGenerator
  implements AsymmetricCipherKeyPairGenerator
{
  private DHKeyGeneratorHelper helper = DHKeyGeneratorHelper.INSTANCE;
  private ElGamalKeyGenerationParameters param;
  
  public void init(KeyGenerationParameters paramKeyGenerationParameters)
  {
    this.param = ((ElGamalKeyGenerationParameters)paramKeyGenerationParameters);
  }
  
  public AsymmetricCipherKeyPair generateKeyPair()
  {
    ElGamalParameters localElGamalParameters = this.param.getParameters();
    BigInteger localBigInteger1 = localElGamalParameters.getP();
    BigInteger localBigInteger2 = this.helper.calculatePrivate(localBigInteger1, this.param.getRandom(), localElGamalParameters.getL());
    BigInteger localBigInteger3 = this.helper.calculatePublic(localBigInteger1, localElGamalParameters.getG(), localBigInteger2);
    return new AsymmetricCipherKeyPair(new ElGamalPublicKeyParameters(localBigInteger3, localElGamalParameters), new ElGamalPrivateKeyParameters(localBigInteger2, localElGamalParameters));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\generators\ElGamalKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */