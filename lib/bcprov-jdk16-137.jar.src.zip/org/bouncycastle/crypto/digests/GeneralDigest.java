package org.bouncycastle.crypto.digests;

import org.bouncycastle.crypto.ExtendedDigest;

public abstract class GeneralDigest
  implements ExtendedDigest
{
  private static final int BYTE_LENGTH = 64;
  private byte[] xBuf;
  private int xBufOff;
  private long byteCount;
  
  protected GeneralDigest()
  {
    this.xBuf = new byte[4];
    this.xBufOff = 0;
  }
  
  protected GeneralDigest(GeneralDigest paramGeneralDigest)
  {
    this.xBuf = new byte[paramGeneralDigest.xBuf.length];
    System.arraycopy(paramGeneralDigest.xBuf, 0, this.xBuf, 0, paramGeneralDigest.xBuf.length);
    this.xBufOff = paramGeneralDigest.xBufOff;
    this.byteCount = paramGeneralDigest.byteCount;
  }
  
  public void update(byte paramByte)
  {
    this.xBuf[(this.xBufOff++)] = paramByte;
    if (this.xBufOff == this.xBuf.length)
    {
      processWord(this.xBuf, 0);
      this.xBufOff = 0;
    }
    this.byteCount += 1L;
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    while ((this.xBufOff != 0) && (paramInt2 > 0))
    {
      update(paramArrayOfByte[paramInt1]);
      paramInt1++;
      paramInt2--;
    }
    while (paramInt2 > this.xBuf.length)
    {
      processWord(paramArrayOfByte, paramInt1);
      paramInt1 += this.xBuf.length;
      paramInt2 -= this.xBuf.length;
      this.byteCount += this.xBuf.length;
    }
    while (paramInt2 > 0)
    {
      update(paramArrayOfByte[paramInt1]);
      paramInt1++;
      paramInt2--;
    }
  }
  
  public void finish()
  {
    long l = this.byteCount << 3;
    update((byte)Byte.MIN_VALUE);
    while (this.xBufOff != 0) {
      update((byte)0);
    }
    processLength(l);
    processBlock();
  }
  
  public void reset()
  {
    this.byteCount = 0L;
    this.xBufOff = 0;
    for (int i = 0; i < this.xBuf.length; i++) {
      this.xBuf[i] = 0;
    }
  }
  
  public int getByteLength()
  {
    return 64;
  }
  
  protected abstract void processWord(byte[] paramArrayOfByte, int paramInt);
  
  protected abstract void processLength(long paramLong);
  
  protected abstract void processBlock();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\digests\GeneralDigest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */