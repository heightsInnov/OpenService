package org.bouncycastle.crypto.signers;

import java.math.BigInteger;
import java.security.SecureRandom;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DSA;
import org.bouncycastle.crypto.params.DSAKeyParameters;
import org.bouncycastle.crypto.params.DSAParameters;
import org.bouncycastle.crypto.params.DSAPrivateKeyParameters;
import org.bouncycastle.crypto.params.DSAPublicKeyParameters;
import org.bouncycastle.crypto.params.ParametersWithRandom;

public class DSASigner
  implements DSA
{
  DSAKeyParameters key;
  SecureRandom random;
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
  {
    if (paramBoolean)
    {
      if ((paramCipherParameters instanceof ParametersWithRandom))
      {
        ParametersWithRandom localParametersWithRandom = (ParametersWithRandom)paramCipherParameters;
        this.random = localParametersWithRandom.getRandom();
        this.key = ((DSAPrivateKeyParameters)localParametersWithRandom.getParameters());
      }
      else
      {
        this.random = new SecureRandom();
        this.key = ((DSAPrivateKeyParameters)paramCipherParameters);
      }
    }
    else {
      this.key = ((DSAPublicKeyParameters)paramCipherParameters);
    }
  }
  
  public BigInteger[] generateSignature(byte[] paramArrayOfByte)
  {
    DSAParameters localDSAParameters = this.key.getParameters();
    BigInteger localBigInteger1 = calculateE(localDSAParameters.getQ(), paramArrayOfByte);
    int i = localDSAParameters.getQ().bitLength();
    do
    {
      localBigInteger2 = new BigInteger(i, this.random);
    } while (localBigInteger2.compareTo(localDSAParameters.getQ()) >= 0);
    BigInteger localBigInteger3 = localDSAParameters.getG().modPow(localBigInteger2, localDSAParameters.getP()).mod(localDSAParameters.getQ());
    BigInteger localBigInteger2 = localBigInteger2.modInverse(localDSAParameters.getQ()).multiply(localBigInteger1.add(((DSAPrivateKeyParameters)this.key).getX().multiply(localBigInteger3)));
    BigInteger localBigInteger4 = localBigInteger2.mod(localDSAParameters.getQ());
    BigInteger[] arrayOfBigInteger = new BigInteger[2];
    arrayOfBigInteger[0] = localBigInteger3;
    arrayOfBigInteger[1] = localBigInteger4;
    return arrayOfBigInteger;
  }
  
  public boolean verifySignature(byte[] paramArrayOfByte, BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    DSAParameters localDSAParameters = this.key.getParameters();
    BigInteger localBigInteger1 = calculateE(localDSAParameters.getQ(), paramArrayOfByte);
    BigInteger localBigInteger2 = BigInteger.valueOf(0L);
    if ((localBigInteger2.compareTo(paramBigInteger1) >= 0) || (localDSAParameters.getQ().compareTo(paramBigInteger1) <= 0)) {
      return false;
    }
    if ((localBigInteger2.compareTo(paramBigInteger2) >= 0) || (localDSAParameters.getQ().compareTo(paramBigInteger2) <= 0)) {
      return false;
    }
    BigInteger localBigInteger3 = paramBigInteger2.modInverse(localDSAParameters.getQ());
    BigInteger localBigInteger4 = localBigInteger1.multiply(localBigInteger3).mod(localDSAParameters.getQ());
    BigInteger localBigInteger5 = paramBigInteger1.multiply(localBigInteger3).mod(localDSAParameters.getQ());
    localBigInteger4 = localDSAParameters.getG().modPow(localBigInteger4, localDSAParameters.getP());
    localBigInteger5 = ((DSAPublicKeyParameters)this.key).getY().modPow(localBigInteger5, localDSAParameters.getP());
    BigInteger localBigInteger6 = localBigInteger4.multiply(localBigInteger5).mod(localDSAParameters.getP()).mod(localDSAParameters.getQ());
    return localBigInteger6.equals(paramBigInteger1);
  }
  
  private BigInteger calculateE(BigInteger paramBigInteger, byte[] paramArrayOfByte)
  {
    if (paramBigInteger.bitLength() >= paramArrayOfByte.length * 8) {
      return new BigInteger(1, paramArrayOfByte);
    }
    byte[] arrayOfByte = new byte[paramBigInteger.bitLength() / 8];
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, arrayOfByte.length);
    return new BigInteger(1, arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\signers\DSASigner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */