package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;

public class OpenPGPCFBBlockCipher
  implements BlockCipher
{
  private byte[] IV;
  private byte[] FR;
  private byte[] FRE;
  private byte[] tmp;
  private BlockCipher cipher;
  private int count;
  private int blockSize;
  private boolean forEncryption;
  
  public OpenPGPCFBBlockCipher(BlockCipher paramBlockCipher)
  {
    this.cipher = paramBlockCipher;
    this.blockSize = paramBlockCipher.getBlockSize();
    this.IV = new byte[this.blockSize];
    this.FR = new byte[this.blockSize];
    this.FRE = new byte[this.blockSize];
    this.tmp = new byte[this.blockSize];
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher;
  }
  
  public String getAlgorithmName()
  {
    return this.cipher.getAlgorithmName() + "/OpenPGPCFB";
  }
  
  public int getBlockSize()
  {
    return this.cipher.getBlockSize();
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    return this.forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset()
  {
    this.count = 0;
    System.arraycopy(this.IV, 0, this.FR, 0, this.FR.length);
    this.cipher.reset();
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.forEncryption = paramBoolean;
    reset();
    this.cipher.init(true, paramCipherParameters);
  }
  
  private byte encryptByte(byte paramByte, int paramInt)
  {
    return (byte)(this.FRE[paramInt] ^ paramByte);
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    int i;
    if (this.count > this.blockSize)
    {
      this.FR[(this.blockSize - 2)] = (paramArrayOfByte2[paramInt2] = encryptByte(paramArrayOfByte1[paramInt1], this.blockSize - 2));
      this.FR[(this.blockSize - 1)] = (paramArrayOfByte2[(paramInt2 + 1)] = encryptByte(paramArrayOfByte1[(paramInt1 + 1)], this.blockSize - 1));
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 2; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i - 2);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2 + 2, this.FR, 0, this.blockSize - 2);
    }
    else if (this.count == 0)
    {
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2, this.FR, 0, this.blockSize);
      this.count += this.blockSize;
    }
    else if (this.count == this.blockSize)
    {
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      paramArrayOfByte2[paramInt2] = encryptByte(paramArrayOfByte1[paramInt1], 0);
      paramArrayOfByte2[(paramInt2 + 1)] = encryptByte(paramArrayOfByte1[(paramInt1 + 1)], 1);
      System.arraycopy(this.FR, 2, this.FR, 0, this.blockSize - 2);
      System.arraycopy(paramArrayOfByte2, paramInt2, this.FR, this.blockSize - 2, 2);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 2; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i - 2);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2 + 2, this.FR, 0, this.blockSize - 2);
      this.count += this.blockSize;
    }
    return this.blockSize;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    int i;
    if (this.count > this.blockSize)
    {
      System.arraycopy(paramArrayOfByte1, paramInt1, this.tmp, 0, this.blockSize);
      paramArrayOfByte2[paramInt2] = encryptByte(this.tmp[0], this.blockSize - 2);
      paramArrayOfByte2[(paramInt2 + 1)] = encryptByte(this.tmp[1], this.blockSize - 1);
      System.arraycopy(this.tmp, 0, this.FR, this.blockSize - 2, 2);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 2; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(this.tmp[i], i - 2);
      }
      System.arraycopy(this.tmp, 2, this.FR, 0, this.blockSize - 2);
    }
    else if (this.count == 0)
    {
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize; i++)
      {
        this.FR[i] = paramArrayOfByte1[(paramInt1 + i)];
        paramArrayOfByte2[i] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
      }
      this.count += this.blockSize;
    }
    else if (this.count == this.blockSize)
    {
      System.arraycopy(paramArrayOfByte1, paramInt1, this.tmp, 0, this.blockSize);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      paramArrayOfByte2[paramInt2] = encryptByte(this.tmp[0], 0);
      paramArrayOfByte2[(paramInt2 + 1)] = encryptByte(this.tmp[1], 1);
      System.arraycopy(this.FR, 2, this.FR, 0, this.blockSize - 2);
      this.FR[(this.blockSize - 2)] = this.tmp[0];
      this.FR[(this.blockSize - 1)] = this.tmp[1];
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 2; i < this.blockSize; i++)
      {
        this.FR[(i - 2)] = paramArrayOfByte1[(paramInt1 + i)];
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i - 2);
      }
      this.count += this.blockSize;
    }
    return this.blockSize;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\OpenPGPCFBBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */