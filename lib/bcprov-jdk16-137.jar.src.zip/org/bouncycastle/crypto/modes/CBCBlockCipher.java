package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class CBCBlockCipher
  implements BlockCipher
{
  private byte[] IV;
  private byte[] cbcV;
  private byte[] cbcNextV;
  private int blockSize;
  private BlockCipher cipher = null;
  private boolean encrypting;
  
  public CBCBlockCipher(BlockCipher paramBlockCipher)
  {
    this.cipher = paramBlockCipher;
    this.blockSize = paramBlockCipher.getBlockSize();
    this.IV = new byte[this.blockSize];
    this.cbcV = new byte[this.blockSize];
    this.cbcNextV = new byte[this.blockSize];
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.encrypting = paramBoolean;
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      ParametersWithIV localParametersWithIV = (ParametersWithIV)paramCipherParameters;
      byte[] arrayOfByte = localParametersWithIV.getIV();
      if (arrayOfByte.length != this.blockSize) {
        throw new IllegalArgumentException("initialisation vector must be the same length as block size");
      }
      System.arraycopy(arrayOfByte, 0, this.IV, 0, arrayOfByte.length);
      reset();
      this.cipher.init(paramBoolean, localParametersWithIV.getParameters());
    }
    else
    {
      reset();
      this.cipher.init(paramBoolean, paramCipherParameters);
    }
  }
  
  public String getAlgorithmName()
  {
    return this.cipher.getAlgorithmName() + "/CBC";
  }
  
  public int getBlockSize()
  {
    return this.cipher.getBlockSize();
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    return this.encrypting ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset()
  {
    System.arraycopy(this.IV, 0, this.cbcV, 0, this.IV.length);
    this.cipher.reset();
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    for (int i = 0; i < this.blockSize; i++)
    {
      int tmp39_37 = i;
      byte[] tmp39_34 = this.cbcV;
      tmp39_34[tmp39_37] = ((byte)(tmp39_34[tmp39_37] ^ paramArrayOfByte1[(paramInt1 + i)]));
    }
    i = this.cipher.processBlock(this.cbcV, 0, paramArrayOfByte2, paramInt2);
    System.arraycopy(paramArrayOfByte2, paramInt2, this.cbcV, 0, this.cbcV.length);
    return i;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    System.arraycopy(paramArrayOfByte1, paramInt1, this.cbcNextV, 0, this.blockSize);
    int i = this.cipher.processBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    for (int j = 0; j < this.blockSize; j++)
    {
      int tmp69_68 = (paramInt2 + j);
      byte[] tmp69_63 = paramArrayOfByte2;
      tmp69_63[tmp69_68] = ((byte)(tmp69_63[tmp69_68] ^ this.cbcV[j]));
    }
    byte[] arrayOfByte = this.cbcV;
    this.cbcV = this.cbcNextV;
    this.cbcNextV = arrayOfByte;
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\CBCBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */