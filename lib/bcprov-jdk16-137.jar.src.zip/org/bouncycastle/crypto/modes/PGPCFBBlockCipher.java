package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class PGPCFBBlockCipher
  implements BlockCipher
{
  private byte[] IV;
  private byte[] FR;
  private byte[] FRE;
  private byte[] tmp;
  private BlockCipher cipher;
  private int count;
  private int blockSize;
  private boolean forEncryption;
  private boolean inlineIv;
  
  public PGPCFBBlockCipher(BlockCipher paramBlockCipher, boolean paramBoolean)
  {
    this.cipher = paramBlockCipher;
    this.inlineIv = paramBoolean;
    this.blockSize = paramBlockCipher.getBlockSize();
    this.IV = new byte[this.blockSize];
    this.FR = new byte[this.blockSize];
    this.FRE = new byte[this.blockSize];
    this.tmp = new byte[this.blockSize];
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher;
  }
  
  public String getAlgorithmName()
  {
    if (this.inlineIv) {
      return this.cipher.getAlgorithmName() + "/PGPCFBwithIV";
    }
    return this.cipher.getAlgorithmName() + "/PGPCFB";
  }
  
  public int getBlockSize()
  {
    return this.cipher.getBlockSize();
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (this.inlineIv) {
      return this.forEncryption ? encryptBlockWithIV(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlockWithIV(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
    }
    return this.forEncryption ? encryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2) : decryptBlock(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt2);
  }
  
  public void reset()
  {
    this.count = 0;
    for (int i = 0; i != this.FR.length; i++) {
      if (this.inlineIv) {
        this.FR[i] = 0;
      } else {
        this.FR[i] = this.IV[i];
      }
    }
    this.cipher.reset();
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.forEncryption = paramBoolean;
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      ParametersWithIV localParametersWithIV = (ParametersWithIV)paramCipherParameters;
      byte[] arrayOfByte = localParametersWithIV.getIV();
      if (arrayOfByte.length < this.IV.length)
      {
        System.arraycopy(arrayOfByte, 0, this.IV, this.IV.length - arrayOfByte.length, arrayOfByte.length);
        for (int i = 0; i < this.IV.length - arrayOfByte.length; i++) {
          this.IV[i] = 0;
        }
      }
      else
      {
        System.arraycopy(arrayOfByte, 0, this.IV, 0, this.IV.length);
      }
      reset();
      this.cipher.init(true, localParametersWithIV.getParameters());
    }
    else
    {
      reset();
      this.cipher.init(true, paramCipherParameters);
    }
  }
  
  private byte encryptByte(byte paramByte, int paramInt)
  {
    return (byte)(this.FRE[paramInt] ^ paramByte);
  }
  
  private int encryptBlockWithIV(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    int i;
    if (this.count == 0)
    {
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(this.IV[i], i);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2, this.FR, 0, this.blockSize);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      paramArrayOfByte2[(paramInt2 + this.blockSize)] = encryptByte(this.IV[(this.blockSize - 2)], 0);
      paramArrayOfByte2[(paramInt2 + this.blockSize + 1)] = encryptByte(this.IV[(this.blockSize - 1)], 1);
      System.arraycopy(paramArrayOfByte2, paramInt2 + 2, this.FR, 0, this.blockSize);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + this.blockSize + 2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2 + this.blockSize + 2, this.FR, 0, this.blockSize);
      this.count += 2 * this.blockSize + 2;
      return 2 * this.blockSize + 2;
    }
    if (this.count >= this.blockSize + 2)
    {
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
      }
      System.arraycopy(paramArrayOfByte2, paramInt2, this.FR, 0, this.blockSize);
    }
    return this.blockSize;
  }
  
  private int decryptBlockWithIV(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    int i;
    if (this.count == 0)
    {
      for (i = 0; i < this.blockSize; i++) {
        this.FR[i] = paramArrayOfByte1[(paramInt1 + i)];
      }
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      this.count += this.blockSize;
      return 0;
    }
    if (this.count == this.blockSize)
    {
      System.arraycopy(paramArrayOfByte1, paramInt1, this.tmp, 0, this.blockSize);
      System.arraycopy(this.FR, 2, this.FR, 0, this.blockSize - 2);
      this.FR[(this.blockSize - 2)] = this.tmp[0];
      this.FR[(this.blockSize - 1)] = this.tmp[1];
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize - 2; i++) {
        paramArrayOfByte2[(paramInt2 + i)] = encryptByte(this.tmp[(i + 2)], i);
      }
      System.arraycopy(this.tmp, 2, this.FR, 0, this.blockSize - 2);
      this.count += 2;
      return this.blockSize - 2;
    }
    if (this.count >= this.blockSize + 2)
    {
      System.arraycopy(paramArrayOfByte1, paramInt1, this.tmp, 0, this.blockSize);
      paramArrayOfByte2[(paramInt2 + 0)] = encryptByte(this.tmp[0], this.blockSize - 2);
      paramArrayOfByte2[(paramInt2 + 1)] = encryptByte(this.tmp[1], this.blockSize - 1);
      System.arraycopy(this.tmp, 0, this.FR, this.blockSize - 2, 2);
      this.cipher.processBlock(this.FR, 0, this.FRE, 0);
      for (i = 0; i < this.blockSize - 2; i++) {
        paramArrayOfByte2[(paramInt2 + i + 2)] = encryptByte(this.tmp[(i + 2)], i);
      }
      System.arraycopy(this.tmp, 2, this.FR, 0, this.blockSize - 2);
    }
    return this.blockSize;
  }
  
  private int encryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    this.cipher.processBlock(this.FR, 0, this.FRE, 0);
    for (int i = 0; i < this.blockSize; i++) {
      paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
    }
    for (i = 0; i < this.blockSize; i++) {
      this.FR[i] = paramArrayOfByte2[(paramInt2 + i)];
    }
    return this.blockSize;
  }
  
  private int decryptBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    this.cipher.processBlock(this.FR, 0, this.FRE, 0);
    for (int i = 0; i < this.blockSize; i++) {
      paramArrayOfByte2[(paramInt2 + i)] = encryptByte(paramArrayOfByte1[(paramInt1 + i)], i);
    }
    for (i = 0; i < this.blockSize; i++) {
      this.FR[i] = paramArrayOfByte1[(paramInt1 + i)];
    }
    return this.blockSize;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\PGPCFBBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */