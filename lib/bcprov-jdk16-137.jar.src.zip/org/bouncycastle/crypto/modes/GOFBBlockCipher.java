package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class GOFBBlockCipher
  implements BlockCipher
{
  private byte[] IV;
  private byte[] ofbV;
  private byte[] ofbOutV;
  private final int blockSize;
  private final BlockCipher cipher;
  boolean firstStep = true;
  int N3;
  int N4;
  static final int C1 = 16843012;
  static final int C2 = 16843009;
  
  public GOFBBlockCipher(BlockCipher paramBlockCipher)
  {
    this.cipher = paramBlockCipher;
    this.blockSize = paramBlockCipher.getBlockSize();
    if (this.blockSize != 8) {
      throw new IllegalArgumentException("GTCR only for 64 bit block ciphers");
    }
    this.IV = new byte[paramBlockCipher.getBlockSize()];
    this.ofbV = new byte[paramBlockCipher.getBlockSize()];
    this.ofbOutV = new byte[paramBlockCipher.getBlockSize()];
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.firstStep = true;
    this.N3 = 0;
    this.N4 = 0;
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      ParametersWithIV localParametersWithIV = (ParametersWithIV)paramCipherParameters;
      byte[] arrayOfByte = localParametersWithIV.getIV();
      if (arrayOfByte.length < this.IV.length)
      {
        System.arraycopy(arrayOfByte, 0, this.IV, this.IV.length - arrayOfByte.length, arrayOfByte.length);
        for (int i = 0; i < this.IV.length - arrayOfByte.length; i++) {
          this.IV[i] = 0;
        }
      }
      else
      {
        System.arraycopy(arrayOfByte, 0, this.IV, 0, this.IV.length);
      }
      reset();
      this.cipher.init(true, localParametersWithIV.getParameters());
    }
    else
    {
      reset();
      this.cipher.init(true, paramCipherParameters);
    }
  }
  
  public String getAlgorithmName()
  {
    return this.cipher.getAlgorithmName() + "/GCTR";
  }
  
  public int getBlockSize()
  {
    return this.blockSize;
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt1 + this.blockSize > paramArrayOfByte1.length) {
      throw new DataLengthException("input buffer too short");
    }
    if (paramInt2 + this.blockSize > paramArrayOfByte2.length) {
      throw new DataLengthException("output buffer too short");
    }
    if (this.firstStep)
    {
      this.firstStep = false;
      this.cipher.processBlock(this.ofbV, 0, this.ofbOutV, 0);
      this.N3 = bytesToint(this.ofbOutV, 0);
      this.N4 = bytesToint(this.ofbOutV, 4);
    }
    this.N3 += 16843009;
    this.N4 += 16843012;
    intTobytes(this.N3, this.ofbV, 0);
    intTobytes(this.N4, this.ofbV, 4);
    this.cipher.processBlock(this.ofbV, 0, this.ofbOutV, 0);
    for (int i = 0; i < this.blockSize; i++) {
      paramArrayOfByte2[(paramInt2 + i)] = ((byte)(this.ofbOutV[i] ^ paramArrayOfByte1[(paramInt1 + i)]));
    }
    System.arraycopy(this.ofbV, this.blockSize, this.ofbV, 0, this.ofbV.length - this.blockSize);
    System.arraycopy(this.ofbOutV, 0, this.ofbV, this.ofbV.length - this.blockSize, this.blockSize);
    return this.blockSize;
  }
  
  public void reset()
  {
    System.arraycopy(this.IV, 0, this.ofbV, 0, this.IV.length);
    this.cipher.reset();
  }
  
  private int bytesToint(byte[] paramArrayOfByte, int paramInt)
  {
    return (paramArrayOfByte[(paramInt + 3)] << 24 & 0xFF000000) + (paramArrayOfByte[(paramInt + 2)] << 16 & 0xFF0000) + (paramArrayOfByte[(paramInt + 1)] << 8 & 0xFF00) + (paramArrayOfByte[paramInt] & 0xFF);
  }
  
  private void intTobytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    paramArrayOfByte[(paramInt2 + 3)] = ((byte)(paramInt1 >>> 24));
    paramArrayOfByte[(paramInt2 + 2)] = ((byte)(paramInt1 >>> 16));
    paramArrayOfByte[(paramInt2 + 1)] = ((byte)(paramInt1 >>> 8));
    paramArrayOfByte[paramInt2] = ((byte)paramInt1);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\GOFBBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */