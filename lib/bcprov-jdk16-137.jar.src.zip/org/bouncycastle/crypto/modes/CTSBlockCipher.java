package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class CTSBlockCipher
  extends BufferedBlockCipher
{
  private int blockSize;
  
  public CTSBlockCipher(BlockCipher paramBlockCipher)
  {
    if (((paramBlockCipher instanceof OFBBlockCipher)) || ((paramBlockCipher instanceof CFBBlockCipher))) {
      throw new IllegalArgumentException("CTSBlockCipher can only accept ECB, or CBC ciphers");
    }
    this.cipher = paramBlockCipher;
    this.blockSize = paramBlockCipher.getBlockSize();
    this.buf = new byte[this.blockSize * 2];
    this.bufOff = 0;
  }
  
  public int getUpdateOutputSize(int paramInt)
  {
    int i = paramInt + this.bufOff;
    int j = i % this.buf.length;
    if (j == 0) {
      return i - this.buf.length;
    }
    return i - j;
  }
  
  public int getOutputSize(int paramInt)
  {
    return paramInt + this.bufOff;
  }
  
  public int processByte(byte paramByte, byte[] paramArrayOfByte, int paramInt)
    throws DataLengthException, IllegalStateException
  {
    int i = 0;
    if (this.bufOff == this.buf.length)
    {
      i = this.cipher.processBlock(this.buf, 0, paramArrayOfByte, paramInt);
      System.arraycopy(this.buf, this.blockSize, this.buf, 0, this.blockSize);
      this.bufOff = this.blockSize;
    }
    this.buf[(this.bufOff++)] = paramByte;
    return i;
  }
  
  public int processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws DataLengthException, IllegalStateException
  {
    if (paramInt2 < 0) {
      throw new IllegalArgumentException("Can't have a negative input length!");
    }
    int i = getBlockSize();
    int j = getUpdateOutputSize(paramInt2);
    if ((j > 0) && (paramInt3 + j > paramArrayOfByte2.length)) {
      throw new DataLengthException("output buffer too short");
    }
    int k = 0;
    int m = this.buf.length - this.bufOff;
    if (paramInt2 > m)
    {
      System.arraycopy(paramArrayOfByte1, paramInt1, this.buf, this.bufOff, m);
      k += this.cipher.processBlock(this.buf, 0, paramArrayOfByte2, paramInt3);
      System.arraycopy(this.buf, i, this.buf, 0, i);
      this.bufOff = i;
      paramInt2 -= m;
      paramInt1 += m;
      while (paramInt2 > i)
      {
        System.arraycopy(paramArrayOfByte1, paramInt1, this.buf, this.bufOff, i);
        k += this.cipher.processBlock(this.buf, 0, paramArrayOfByte2, paramInt3 + k);
        System.arraycopy(this.buf, i, this.buf, 0, i);
        paramInt2 -= i;
        paramInt1 += i;
      }
    }
    System.arraycopy(paramArrayOfByte1, paramInt1, this.buf, this.bufOff, paramInt2);
    this.bufOff += paramInt2;
    return k;
  }
  
  public int doFinal(byte[] paramArrayOfByte, int paramInt)
    throws DataLengthException, IllegalStateException, InvalidCipherTextException
  {
    if (this.bufOff + paramInt > paramArrayOfByte.length) {
      throw new DataLengthException("output buffer to small in doFinal");
    }
    int i = this.cipher.getBlockSize();
    int j = this.bufOff - i;
    byte[] arrayOfByte = new byte[i];
    Object localObject;
    if (this.forEncryption)
    {
      this.cipher.processBlock(this.buf, 0, arrayOfByte, 0);
      if (this.bufOff < i) {
        throw new DataLengthException("need at least one block of input for CTS");
      }
      for (int k = this.bufOff; k != this.buf.length; k++) {
        this.buf[k] = arrayOfByte[(k - i)];
      }
      for (k = i; k != this.bufOff; k++)
      {
        int tmp141_139 = k;
        byte[] tmp141_136 = this.buf;
        tmp141_136[tmp141_139] = ((byte)(tmp141_136[tmp141_139] ^ arrayOfByte[(k - i)]));
      }
      if ((this.cipher instanceof CBCBlockCipher))
      {
        localObject = ((CBCBlockCipher)this.cipher).getUnderlyingCipher();
        ((BlockCipher)localObject).processBlock(this.buf, i, paramArrayOfByte, paramInt);
      }
      else
      {
        this.cipher.processBlock(this.buf, i, paramArrayOfByte, paramInt);
      }
      System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt + i, j);
    }
    else
    {
      localObject = new byte[i];
      if ((this.cipher instanceof CBCBlockCipher))
      {
        BlockCipher localBlockCipher = ((CBCBlockCipher)this.cipher).getUnderlyingCipher();
        localBlockCipher.processBlock(this.buf, 0, arrayOfByte, 0);
      }
      else
      {
        this.cipher.processBlock(this.buf, 0, arrayOfByte, 0);
      }
      for (int n = i; n != this.bufOff; n++) {
        localObject[(n - i)] = ((byte)(arrayOfByte[(n - i)] ^ this.buf[n]));
      }
      System.arraycopy(this.buf, i, arrayOfByte, 0, j);
      this.cipher.processBlock(arrayOfByte, 0, paramArrayOfByte, paramInt);
      System.arraycopy(localObject, 0, paramArrayOfByte, paramInt + i, j);
    }
    int m = this.bufOff;
    reset();
    return m;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\CTSBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */