package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class SICBlockCipher
  implements BlockCipher
{
  private final BlockCipher cipher;
  private final int blockSize;
  private byte[] IV;
  private byte[] counter;
  private byte[] counterOut;
  
  public SICBlockCipher(BlockCipher paramBlockCipher)
  {
    this.cipher = paramBlockCipher;
    this.blockSize = this.cipher.getBlockSize();
    this.IV = new byte[this.blockSize];
    this.counter = new byte[this.blockSize];
    this.counterOut = new byte[this.blockSize];
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher;
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    if ((paramCipherParameters instanceof ParametersWithIV))
    {
      ParametersWithIV localParametersWithIV = (ParametersWithIV)paramCipherParameters;
      byte[] arrayOfByte = localParametersWithIV.getIV();
      System.arraycopy(arrayOfByte, 0, this.IV, 0, this.IV.length);
      reset();
      this.cipher.init(true, localParametersWithIV.getParameters());
    }
  }
  
  public String getAlgorithmName()
  {
    return this.cipher.getAlgorithmName() + "/SIC";
  }
  
  public int getBlockSize()
  {
    return this.cipher.getBlockSize();
  }
  
  public int processBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2)
    throws DataLengthException, IllegalStateException
  {
    this.cipher.processBlock(this.counter, 0, this.counterOut, 0);
    for (int i = 0; i < this.counterOut.length; i++) {
      paramArrayOfByte2[(paramInt2 + i)] = ((byte)(this.counterOut[i] ^ paramArrayOfByte1[(paramInt1 + i)]));
    }
    i = 1;
    for (int j = this.counter.length - 1; j >= 0; j--)
    {
      int k = (this.counter[j] & 0xFF) + i;
      if (k > 255) {
        i = 1;
      } else {
        i = 0;
      }
      this.counter[j] = ((byte)k);
    }
    return this.counter.length;
  }
  
  public void reset()
  {
    System.arraycopy(this.IV, 0, this.counter, 0, this.counter.length);
    this.cipher.reset();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\SICBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */