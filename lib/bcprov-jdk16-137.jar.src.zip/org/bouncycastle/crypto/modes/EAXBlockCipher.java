package org.bouncycastle.crypto.modes;

import org.bouncycastle.crypto.BlockCipher;
import org.bouncycastle.crypto.CipherParameters;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.Mac;
import org.bouncycastle.crypto.macs.CMac;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.ParametersWithIV;

public class EAXBlockCipher
  implements AEADBlockCipher
{
  private static final byte nTAG = 0;
  private static final byte hTAG = 1;
  private static final byte cTAG = 2;
  private SICBlockCipher cipher;
  private boolean forEncryption;
  private int blockSize;
  private Mac mac;
  private byte[] nonceMac;
  private byte[] associatedTextMac;
  private byte[] macBlock;
  private int macSize;
  private byte[] bufBlock;
  private int bufOff;
  
  public EAXBlockCipher(BlockCipher paramBlockCipher)
  {
    this.blockSize = paramBlockCipher.getBlockSize();
    this.mac = new CMac(paramBlockCipher);
    this.macBlock = new byte[this.blockSize];
    this.bufBlock = new byte[this.blockSize * 2];
    this.associatedTextMac = new byte[this.mac.getMacSize()];
    this.nonceMac = new byte[this.mac.getMacSize()];
    this.cipher = new SICBlockCipher(paramBlockCipher);
  }
  
  public String getAlgorithmName()
  {
    return this.cipher.getUnderlyingCipher().getAlgorithmName() + "/EAX";
  }
  
  public BlockCipher getUnderlyingCipher()
  {
    return this.cipher.getUnderlyingCipher();
  }
  
  public int getBlockSize()
  {
    return this.cipher.getBlockSize();
  }
  
  public void init(boolean paramBoolean, CipherParameters paramCipherParameters)
    throws IllegalArgumentException
  {
    this.forEncryption = paramBoolean;
    byte[] arrayOfByte1;
    byte[] arrayOfByte2;
    Object localObject1;
    if ((paramCipherParameters instanceof AEADParameters))
    {
      localObject2 = (AEADParameters)paramCipherParameters;
      arrayOfByte1 = ((AEADParameters)localObject2).getNonce();
      arrayOfByte2 = ((AEADParameters)localObject2).getAssociatedText();
      this.macSize = (((AEADParameters)localObject2).getMacSize() / 8);
      localObject1 = ((AEADParameters)localObject2).getKey();
    }
    else if ((paramCipherParameters instanceof ParametersWithIV))
    {
      localObject2 = (ParametersWithIV)paramCipherParameters;
      arrayOfByte1 = ((ParametersWithIV)localObject2).getIV();
      arrayOfByte2 = new byte[0];
      this.macSize = (this.mac.getMacSize() / 2);
      localObject1 = ((ParametersWithIV)localObject2).getParameters();
    }
    else
    {
      throw new IllegalArgumentException("invalid parameters passed to EAX");
    }
    Object localObject2 = new byte[this.blockSize];
    this.mac.init((CipherParameters)localObject1);
    localObject2[(this.blockSize - 1)] = 1;
    this.mac.update((byte[])localObject2, 0, this.blockSize);
    this.mac.update(arrayOfByte2, 0, arrayOfByte2.length);
    this.mac.doFinal(this.associatedTextMac, 0);
    localObject2[(this.blockSize - 1)] = 0;
    this.mac.update((byte[])localObject2, 0, this.blockSize);
    this.mac.update(arrayOfByte1, 0, arrayOfByte1.length);
    this.mac.doFinal(this.nonceMac, 0);
    localObject2[(this.blockSize - 1)] = 2;
    this.mac.update((byte[])localObject2, 0, this.blockSize);
    this.cipher.init(true, new ParametersWithIV((CipherParameters)localObject1, this.nonceMac));
  }
  
  private void calculateMac()
  {
    byte[] arrayOfByte = new byte[this.blockSize];
    this.mac.doFinal(arrayOfByte, 0);
    for (int i = 0; i < this.macBlock.length; i++) {
      this.macBlock[i] = ((byte)(this.nonceMac[i] ^ this.associatedTextMac[i] ^ arrayOfByte[i]));
    }
  }
  
  public void reset()
  {
    this.cipher.reset();
    this.mac.reset();
    this.bufOff = 0;
  }
  
  public int processByte(byte paramByte, byte[] paramArrayOfByte, int paramInt)
    throws DataLengthException
  {
    return process(paramByte, paramArrayOfByte, paramInt);
  }
  
  public int processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws DataLengthException
  {
    int i = 0;
    for (int j = 0; j != paramInt2; j++) {
      i += process(paramArrayOfByte1[(paramInt1 + j)], paramArrayOfByte2, paramInt3 + i);
    }
    return i;
  }
  
  public int doFinal(byte[] paramArrayOfByte, int paramInt)
    throws IllegalStateException, InvalidCipherTextException
  {
    int i = this.bufOff;
    byte[] arrayOfByte = new byte[this.bufBlock.length];
    this.bufOff = 0;
    if (this.forEncryption)
    {
      this.cipher.processBlock(this.bufBlock, 0, arrayOfByte, 0);
      this.cipher.processBlock(this.bufBlock, this.blockSize, arrayOfByte, this.blockSize);
      System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt, i);
      this.mac.update(arrayOfByte, 0, i);
      calculateMac();
      System.arraycopy(this.macBlock, 0, paramArrayOfByte, paramInt + i, this.macSize);
      return i + this.macSize;
    }
    if (i > this.macSize)
    {
      this.mac.update(this.bufBlock, 0, i - this.macSize);
      this.cipher.processBlock(this.bufBlock, 0, arrayOfByte, 0);
      this.cipher.processBlock(this.bufBlock, this.blockSize, arrayOfByte, this.blockSize);
      System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt, i - this.macSize);
    }
    calculateMac();
    if (!verifyMac(this.bufBlock, i - this.macSize)) {
      throw new InvalidCipherTextException("mac check in EAX failed");
    }
    return i - this.macSize;
  }
  
  public byte[] getMac()
  {
    byte[] arrayOfByte = new byte[this.macSize];
    System.arraycopy(this.macBlock, 0, arrayOfByte, 0, this.macSize);
    return arrayOfByte;
  }
  
  public int getUpdateOutputSize(int paramInt)
  {
    return (paramInt + this.bufOff) / this.blockSize * this.blockSize;
  }
  
  public int getOutputSize(int paramInt)
  {
    if (this.forEncryption) {
      return paramInt + this.bufOff + this.macSize;
    }
    return paramInt + this.bufOff - this.macSize;
  }
  
  private int process(byte paramByte, byte[] paramArrayOfByte, int paramInt)
  {
    this.bufBlock[(this.bufOff++)] = paramByte;
    if (this.bufOff == this.bufBlock.length)
    {
      int i;
      if (this.forEncryption)
      {
        i = this.cipher.processBlock(this.bufBlock, 0, paramArrayOfByte, paramInt);
        this.mac.update(paramArrayOfByte, 0, this.blockSize);
      }
      else
      {
        this.mac.update(this.bufBlock, 0, this.blockSize);
        i = this.cipher.processBlock(this.bufBlock, 0, paramArrayOfByte, paramInt);
      }
      this.bufOff = this.blockSize;
      System.arraycopy(this.bufBlock, this.blockSize, this.bufBlock, 0, this.blockSize);
      return i;
    }
    return 0;
  }
  
  private boolean verifyMac(byte[] paramArrayOfByte, int paramInt)
  {
    for (int i = 0; i < this.macSize; i++) {
      if (this.macBlock[i] != paramArrayOfByte[(paramInt + i)]) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\modes\EAXBlockCipher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */