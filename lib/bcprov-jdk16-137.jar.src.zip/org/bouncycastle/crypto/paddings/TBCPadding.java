package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class TBCPadding
  implements BlockCipherPadding
{
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {}
  
  public String getPaddingName()
  {
    return "TBC";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramArrayOfByte.length - paramInt;
    int j;
    if (paramInt > 0) {
      j = (byte)((paramArrayOfByte[(paramInt - 1)] & 0x1) == 0 ? 255 : 0);
    } else {
      j = (byte)((paramArrayOfByte[(paramArrayOfByte.length - 1)] & 0x1) == 0 ? 255 : 0);
    }
    while (paramInt < paramArrayOfByte.length)
    {
      paramArrayOfByte[paramInt] = j;
      paramInt++;
    }
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    int i = paramArrayOfByte[(paramArrayOfByte.length - 1)];
    for (int j = paramArrayOfByte.length - 1; (j > 0) && (paramArrayOfByte[(j - 1)] == i); j--) {}
    return paramArrayOfByte.length - j;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\TBCPadding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */