package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class ZeroBytePadding
  implements BlockCipherPadding
{
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {}
  
  public String getPaddingName()
  {
    return "ZeroByte";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramArrayOfByte.length - paramInt;
    while (paramInt < paramArrayOfByte.length)
    {
      paramArrayOfByte[paramInt] = 0;
      paramInt++;
    }
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    for (int i = paramArrayOfByte.length; (i > 0) && (paramArrayOfByte[(i - 1)] == 0); i--) {}
    return paramArrayOfByte.length - i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\ZeroBytePadding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */