package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class ISO10126d2Padding
  implements BlockCipherPadding
{
  SecureRandom random;
  
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {
    if (paramSecureRandom != null) {
      this.random = paramSecureRandom;
    } else {
      this.random = new SecureRandom();
    }
  }
  
  public String getPaddingName()
  {
    return "ISO10126-2";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = (byte)(paramArrayOfByte.length - paramInt);
    while (paramInt < paramArrayOfByte.length - 1)
    {
      paramArrayOfByte[paramInt] = ((byte)this.random.nextInt());
      paramInt++;
    }
    paramArrayOfByte[paramInt] = i;
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    int i = paramArrayOfByte[(paramArrayOfByte.length - 1)] & 0xFF;
    if (i > paramArrayOfByte.length) {
      throw new InvalidCipherTextException("pad block corrupted");
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\ISO10126d2Padding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */