package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class ISO7816d4Padding
  implements BlockCipherPadding
{
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {}
  
  public String getPaddingName()
  {
    return "ISO7816-4";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = paramArrayOfByte.length - paramInt;
    paramArrayOfByte[paramInt] = Byte.MIN_VALUE;
    paramInt++;
    while (paramInt < paramArrayOfByte.length)
    {
      paramArrayOfByte[paramInt] = 0;
      paramInt++;
    }
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    for (int i = paramArrayOfByte.length - 1; (i > 0) && (paramArrayOfByte[i] == 0); i--) {}
    if (paramArrayOfByte[i] != Byte.MIN_VALUE) {
      throw new InvalidCipherTextException("pad block corrupted");
    }
    return paramArrayOfByte.length - i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\ISO7816d4Padding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */