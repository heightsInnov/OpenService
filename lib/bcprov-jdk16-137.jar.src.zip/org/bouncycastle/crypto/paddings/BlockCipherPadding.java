package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public abstract interface BlockCipherPadding
{
  public abstract void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException;
  
  public abstract String getPaddingName();
  
  public abstract int addPadding(byte[] paramArrayOfByte, int paramInt);
  
  public abstract int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\BlockCipherPadding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */