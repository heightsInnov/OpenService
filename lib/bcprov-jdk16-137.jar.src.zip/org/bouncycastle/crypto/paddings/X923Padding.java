package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class X923Padding
  implements BlockCipherPadding
{
  SecureRandom random = null;
  
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {
    this.random = paramSecureRandom;
  }
  
  public String getPaddingName()
  {
    return "X9.23";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = (byte)(paramArrayOfByte.length - paramInt);
    while (paramInt < paramArrayOfByte.length - 1)
    {
      if (this.random == null) {
        paramArrayOfByte[paramInt] = 0;
      } else {
        paramArrayOfByte[paramInt] = ((byte)this.random.nextInt());
      }
      paramInt++;
    }
    paramArrayOfByte[paramInt] = i;
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    int i = paramArrayOfByte[(paramArrayOfByte.length - 1)] & 0xFF;
    if (i > paramArrayOfByte.length) {
      throw new InvalidCipherTextException("pad block corrupted");
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\X923Padding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */