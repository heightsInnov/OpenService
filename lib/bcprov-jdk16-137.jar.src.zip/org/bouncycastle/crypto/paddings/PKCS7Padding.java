package org.bouncycastle.crypto.paddings;

import java.security.SecureRandom;
import org.bouncycastle.crypto.InvalidCipherTextException;

public class PKCS7Padding
  implements BlockCipherPadding
{
  public void init(SecureRandom paramSecureRandom)
    throws IllegalArgumentException
  {}
  
  public String getPaddingName()
  {
    return "PKCS7";
  }
  
  public int addPadding(byte[] paramArrayOfByte, int paramInt)
  {
    int i = (byte)(paramArrayOfByte.length - paramInt);
    while (paramInt < paramArrayOfByte.length)
    {
      paramArrayOfByte[paramInt] = i;
      paramInt++;
    }
    return i;
  }
  
  public int padCount(byte[] paramArrayOfByte)
    throws InvalidCipherTextException
  {
    int i = paramArrayOfByte[(paramArrayOfByte.length - 1)] & 0xFF;
    if (i > paramArrayOfByte.length) {
      throw new InvalidCipherTextException("pad block corrupted");
    }
    for (int j = 1; j <= i; j++) {
      if (paramArrayOfByte[(paramArrayOfByte.length - j)] != i) {
        throw new InvalidCipherTextException("pad block corrupted");
      }
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\crypto\paddings\PKCS7Padding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */