package org.bouncycastle.asn1.mozilla;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;

public class PublicKeyAndChallenge
  extends ASN1Encodable
{
  private ASN1Sequence pkacSeq;
  private SubjectPublicKeyInfo spki;
  private DERIA5String challenge;
  
  public static PublicKeyAndChallenge getInstance(Object paramObject)
  {
    if ((paramObject instanceof PublicKeyAndChallenge)) {
      return (PublicKeyAndChallenge)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PublicKeyAndChallenge((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unkown object in factory");
  }
  
  public PublicKeyAndChallenge(ASN1Sequence paramASN1Sequence)
  {
    this.pkacSeq = paramASN1Sequence;
    this.spki = SubjectPublicKeyInfo.getInstance(paramASN1Sequence.getObjectAt(0));
    this.challenge = DERIA5String.getInstance(paramASN1Sequence.getObjectAt(1));
  }
  
  public DERObject toASN1Object()
  {
    return this.pkacSeq;
  }
  
  public SubjectPublicKeyInfo getSubjectPublicKeyInfo()
  {
    return this.spki;
  }
  
  public DERIA5String getChallenge()
  {
    return this.challenge;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\mozilla\PublicKeyAndChallenge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */