package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

public class ASN1ObjectParser
{
  private int _baseTag;
  private int _tagNumber;
  private ASN1StreamParser _aIn;
  
  protected ASN1ObjectParser(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._baseTag = paramInt1;
    this._tagNumber = paramInt2;
    this._aIn = new ASN1StreamParser(paramInputStream);
  }
  
  int getTagNumber()
  {
    return this._tagNumber;
  }
  
  int getBaseTag()
  {
    return this._baseTag;
  }
  
  DEREncodable readObject()
    throws IOException
  {
    return this._aIn.readObject();
  }
  
  ASN1EncodableVector readVector()
    throws IllegalStateException
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    try
    {
      DEREncodable localDEREncodable;
      while ((localDEREncodable = readObject()) != null) {
        localASN1EncodableVector.add(localDEREncodable.getDERObject());
      }
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException.getMessage());
    }
    return localASN1EncodableVector;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1ObjectParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */