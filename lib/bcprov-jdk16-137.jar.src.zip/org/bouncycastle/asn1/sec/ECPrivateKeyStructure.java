package org.bouncycastle.asn1.sec;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DEREncodableVector;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;

public class ECPrivateKeyStructure
  extends ASN1Encodable
{
  private ASN1Sequence seq;
  
  public ECPrivateKeyStructure(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
  }
  
  public ECPrivateKeyStructure(BigInteger paramBigInteger)
  {
    Object localObject1 = paramBigInteger.toByteArray();
    if (localObject1[0] == 0)
    {
      localObject2 = new byte[localObject1.length - 1];
      System.arraycopy(localObject1, 1, localObject2, 0, localObject2.length);
      localObject1 = localObject2;
    }
    Object localObject2 = new ASN1EncodableVector();
    ((ASN1EncodableVector)localObject2).add(new DERInteger(1));
    ((ASN1EncodableVector)localObject2).add(new DEROctetString((byte[])localObject1));
    this.seq = new DERSequence((DEREncodableVector)localObject2);
  }
  
  public BigInteger getKey()
  {
    ASN1OctetString localASN1OctetString = (ASN1OctetString)this.seq.getObjectAt(1);
    return new BigInteger(1, localASN1OctetString.getOctets());
  }
  
  public DERBitString getPublicKey()
  {
    return (DERBitString)getObjectInTag(1);
  }
  
  public ASN1Object getParameters()
  {
    return getObjectInTag(0);
  }
  
  private ASN1Object getObjectInTag(int paramInt)
  {
    Enumeration localEnumeration = this.seq.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      DEREncodable localDEREncodable = (DEREncodable)localEnumeration.nextElement();
      if ((localDEREncodable instanceof ASN1TaggedObject))
      {
        ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)localDEREncodable;
        if (localASN1TaggedObject.getTagNo() == paramInt) {
          return (ASN1Object)localASN1TaggedObject.getObject().getDERObject();
        }
      }
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    return this.seq;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\sec\ECPrivateKeyStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */