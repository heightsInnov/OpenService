package org.bouncycastle.asn1.ess;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;

public class ContentIdentifier
  extends ASN1Encodable
{
  ASN1OctetString value;
  
  public static ContentIdentifier getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ContentIdentifier))) {
      return (ContentIdentifier)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new ContentIdentifier((ASN1OctetString)paramObject);
    }
    throw new IllegalArgumentException("unknown object in 'ContentIdentifier' factory : " + paramObject.getClass().getName() + ".");
  }
  
  public ContentIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.value = paramASN1OctetString;
  }
  
  public ContentIdentifier(byte[] paramArrayOfByte)
  {
    this(new DEROctetString(paramArrayOfByte));
  }
  
  public ASN1OctetString getValue()
  {
    return this.value;
  }
  
  public DERObject toASN1Object()
  {
    return this.value;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ess\ContentIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */