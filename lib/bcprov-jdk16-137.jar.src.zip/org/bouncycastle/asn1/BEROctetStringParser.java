package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class BEROctetStringParser
  implements ASN1OctetStringParser
{
  private ASN1ObjectParser _parser;
  
  protected BEROctetStringParser(ASN1ObjectParser paramASN1ObjectParser)
  {
    this._parser = paramASN1ObjectParser;
  }
  
  public InputStream getOctetStream()
  {
    return new ConstructedOctetStream(this._parser);
  }
  
  public DERObject getDERObject()
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    InputStream localInputStream = getOctetStream();
    try
    {
      int i;
      while ((i = localInputStream.read()) >= 0) {
        localByteArrayOutputStream.write(i);
      }
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException("IOException converting stream to byte array: " + localIOException.getMessage());
    }
    return new BERConstructedOctetString(localByteArrayOutputStream.toByteArray());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\BEROctetStringParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */