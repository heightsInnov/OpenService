package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public abstract interface ESFAttributes
{
  public static final DERObjectIdentifier sigPolicyId = PKCSObjectIdentifiers.id_aa_sigPolicyId;
  public static final DERObjectIdentifier commitmentType = PKCSObjectIdentifiers.id_aa_commitmentType;
  public static final DERObjectIdentifier signerLocation = PKCSObjectIdentifiers.id_aa_signerLocation;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\esf\ESFAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */