package org.bouncycastle.asn1.esf;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class CommitmentTypeQualifier
  extends ASN1Encodable
{
  private DERObjectIdentifier commitmentTypeIdentifier;
  private DEREncodable qualifier;
  
  public CommitmentTypeQualifier(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this(paramDERObjectIdentifier, null);
  }
  
  public CommitmentTypeQualifier(DERObjectIdentifier paramDERObjectIdentifier, DEREncodable paramDEREncodable)
  {
    this.commitmentTypeIdentifier = paramDERObjectIdentifier;
    this.qualifier = paramDEREncodable;
  }
  
  public CommitmentTypeQualifier(ASN1Sequence paramASN1Sequence)
  {
    this.commitmentTypeIdentifier = ((DERObjectIdentifier)paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1) {
      this.qualifier = paramASN1Sequence.getObjectAt(1);
    }
  }
  
  public static CommitmentTypeQualifier getInstance(Object paramObject)
  {
    if (((paramObject instanceof CommitmentTypeQualifier)) || (paramObject == null)) {
      return (CommitmentTypeQualifier)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new CommitmentTypeQualifier((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in getInstance.");
  }
  
  public DERObjectIdentifier getCommitmentTypeIdentifier()
  {
    return this.commitmentTypeIdentifier;
  }
  
  public DEREncodable getQualifier()
  {
    return this.qualifier;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.commitmentTypeIdentifier);
    if (this.qualifier != null) {
      localASN1EncodableVector.add(this.qualifier);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\esf\CommitmentTypeQualifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */