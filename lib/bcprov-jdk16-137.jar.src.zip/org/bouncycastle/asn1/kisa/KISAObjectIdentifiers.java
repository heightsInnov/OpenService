package org.bouncycastle.asn1.kisa;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface KISAObjectIdentifiers
{
  public static final DERObjectIdentifier id_seedCBC = new DERObjectIdentifier("1.2.410.200004.1.4");
  public static final DERObjectIdentifier id_npki_app_cmsSeed_wrap = new DERObjectIdentifier("1.2.410.200004.7.1.1.1");
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\kisa\KISAObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */