package org.bouncycastle.asn1;

import java.io.IOException;

public abstract class ASN1Null
  extends ASN1Object
{
  public int hashCode()
  {
    return 0;
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    return (paramDERObject instanceof ASN1Null);
  }
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  public String toString()
  {
    return "NULL";
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1Null.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */