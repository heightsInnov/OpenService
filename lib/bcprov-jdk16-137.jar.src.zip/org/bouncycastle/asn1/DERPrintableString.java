package org.bouncycastle.asn1;

import java.io.IOException;

public class DERPrintableString
  extends ASN1Object
  implements DERString
{
  String string;
  
  public static DERPrintableString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERPrintableString))) {
      return (DERPrintableString)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERPrintableString(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERPrintableString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERPrintableString(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    this.string = new String(arrayOfChar);
  }
  
  public DERPrintableString(String paramString)
  {
    this(paramString, false);
  }
  
  public DERPrintableString(String paramString, boolean paramBoolean)
  {
    if ((paramBoolean) && (!isPrintableString(paramString))) {
      throw new IllegalArgumentException("string contains illegal characters");
    }
    this.string = paramString;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public byte[] getOctets()
  {
    char[] arrayOfChar = this.string.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(19, getOctets());
  }
  
  public int hashCode()
  {
    return getString().hashCode();
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERPrintableString)) {
      return false;
    }
    DERPrintableString localDERPrintableString = (DERPrintableString)paramDERObject;
    return getString().equals(localDERPrintableString.getString());
  }
  
  public String toString()
  {
    return this.string;
  }
  
  public static boolean isPrintableString(String paramString)
  {
    for (int i = paramString.length() - 1; i >= 0; i--)
    {
      int j = paramString.charAt(i);
      if (j > 127) {
        return false;
      }
      if (((97 > j) || (j > 122)) && ((65 > j) || (j > 90)) && ((48 > j) || (j > 57))) {
        switch (j)
        {
        case 32: 
        case 39: 
        case 40: 
        case 41: 
        case 43: 
        case 44: 
        case 45: 
        case 46: 
        case 47: 
        case 58: 
        case 61: 
        case 63: 
          break;
        case 33: 
        case 34: 
        case 35: 
        case 36: 
        case 37: 
        case 38: 
        case 42: 
        case 48: 
        case 49: 
        case 50: 
        case 51: 
        case 52: 
        case 53: 
        case 54: 
        case 55: 
        case 56: 
        case 57: 
        case 59: 
        case 60: 
        case 62: 
        default: 
          return false;
        }
      }
    }
    return true;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERPrintableString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */