package org.bouncycastle.asn1.ocsp;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREnumerated;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class OCSPResponse
  extends ASN1Encodable
{
  OCSPResponseStatus responseStatus;
  ResponseBytes responseBytes;
  
  public OCSPResponse(OCSPResponseStatus paramOCSPResponseStatus, ResponseBytes paramResponseBytes)
  {
    this.responseStatus = paramOCSPResponseStatus;
    this.responseBytes = paramResponseBytes;
  }
  
  public OCSPResponse(ASN1Sequence paramASN1Sequence)
  {
    this.responseStatus = new OCSPResponseStatus(DEREnumerated.getInstance(paramASN1Sequence.getObjectAt(0)));
    if (paramASN1Sequence.size() == 2) {
      this.responseBytes = ResponseBytes.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(1), true);
    }
  }
  
  public static OCSPResponse getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static OCSPResponse getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof OCSPResponse))) {
      return (OCSPResponse)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new OCSPResponse((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public OCSPResponseStatus getResponseStatus()
  {
    return this.responseStatus;
  }
  
  public ResponseBytes getResponseBytes()
  {
    return this.responseBytes;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.responseStatus);
    if (this.responseBytes != null) {
      localASN1EncodableVector.add(new DERTaggedObject(true, 0, this.responseBytes));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ocsp\OCSPResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */