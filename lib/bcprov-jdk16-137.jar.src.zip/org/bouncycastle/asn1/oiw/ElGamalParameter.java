package org.bouncycastle.asn1.oiw;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class ElGamalParameter
  extends ASN1Encodable
{
  DERInteger p;
  DERInteger g;
  
  public ElGamalParameter(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    this.p = new DERInteger(paramBigInteger1);
    this.g = new DERInteger(paramBigInteger2);
  }
  
  public ElGamalParameter(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.p = ((DERInteger)localEnumeration.nextElement());
    this.g = ((DERInteger)localEnumeration.nextElement());
  }
  
  public BigInteger getP()
  {
    return this.p.getPositiveValue();
  }
  
  public BigInteger getG()
  {
    return this.g.getPositiveValue();
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.p);
    localASN1EncodableVector.add(this.g);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\oiw\ElGamalParameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */