package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

public class BERTaggedObjectParser
  implements ASN1TaggedObjectParser
{
  private int _baseTag;
  private int _tagNumber;
  private InputStream _contentStream;
  private boolean _indefiniteLength;
  
  protected BERTaggedObjectParser(int paramInt1, int paramInt2, InputStream paramInputStream)
  {
    this._baseTag = paramInt1;
    this._tagNumber = paramInt2;
    this._contentStream = paramInputStream;
    this._indefiniteLength = (paramInputStream instanceof IndefiniteLengthInputStream);
  }
  
  public boolean isConstructed()
  {
    return (this._baseTag & 0x20) != 0;
  }
  
  public int getTagNo()
  {
    return this._tagNumber;
  }
  
  public DEREncodable getObjectParser(int paramInt, boolean paramBoolean)
    throws IOException
  {
    if (paramBoolean) {
      return new ASN1StreamParser(this._contentStream).readObject();
    }
    switch (paramInt)
    {
    case 17: 
      if (this._indefiniteLength) {
        return new BERSetParser(new ASN1ObjectParser(this._baseTag, this._tagNumber, this._contentStream));
      }
      return new DERSet(loadVector(this._contentStream)).parser();
    case 16: 
      if (this._indefiniteLength) {
        return new BERSequenceParser(new ASN1ObjectParser(this._baseTag, this._tagNumber, this._contentStream));
      }
      return new DERSequence(loadVector(this._contentStream)).parser();
    case 4: 
      if ((this._indefiniteLength) || (isConstructed())) {
        return new BEROctetStringParser(new ASN1ObjectParser(this._baseTag, this._tagNumber, this._contentStream));
      }
      return new DEROctetString(((DefiniteLengthInputStream)this._contentStream).toByteArray()).parser();
    }
    throw new RuntimeException("implicit tagging not implemented");
  }
  
  private ASN1EncodableVector loadVector(InputStream paramInputStream)
    throws IOException
  {
    ASN1StreamParser localASN1StreamParser = new ASN1StreamParser(paramInputStream);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (DEREncodable localDEREncodable = localASN1StreamParser.readObject(); localDEREncodable != null; localDEREncodable = localASN1StreamParser.readObject()) {
      localASN1EncodableVector.add(localDEREncodable.getDERObject());
    }
    return localASN1EncodableVector;
  }
  
  private ASN1EncodableVector rLoadVector(InputStream paramInputStream)
  {
    try
    {
      return loadVector(paramInputStream);
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException.getMessage());
    }
  }
  
  public DERObject getDERObject()
  {
    ASN1EncodableVector localASN1EncodableVector;
    if (this._indefiniteLength)
    {
      localASN1EncodableVector = rLoadVector(this._contentStream);
      if (localASN1EncodableVector.size() > 1) {
        return new BERTaggedObject(false, this._tagNumber, new BERSequence(localASN1EncodableVector));
      }
      if (localASN1EncodableVector.size() == 1) {
        return new BERTaggedObject(true, this._tagNumber, localASN1EncodableVector.get(0));
      }
      return new BERTaggedObject(false, this._tagNumber, new BERSequence());
    }
    if (isConstructed())
    {
      localASN1EncodableVector = rLoadVector(this._contentStream);
      if (localASN1EncodableVector.size() == 1) {
        return new DERTaggedObject(true, this._tagNumber, localASN1EncodableVector.get(0));
      }
      return new DERTaggedObject(false, this._tagNumber, new DERSequence(localASN1EncodableVector));
    }
    try
    {
      return new DERTaggedObject(false, this._tagNumber, new DEROctetString(((DefiniteLengthInputStream)this._contentStream).toByteArray()));
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException.getMessage());
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\BERTaggedObjectParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */