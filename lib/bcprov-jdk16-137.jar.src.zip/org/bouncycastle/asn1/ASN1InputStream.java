package org.bouncycastle.asn1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

public class ASN1InputStream
  extends FilterInputStream
  implements DERTags
{
  private static final DERObject END_OF_STREAM = new DERObject()
  {
    void encode(DEROutputStream paramAnonymousDEROutputStream)
      throws IOException
    {
      throw new IOException("Eeek!");
    }
    
    public int hashCode()
    {
      return 0;
    }
    
    public boolean equals(Object paramAnonymousObject)
    {
      return paramAnonymousObject == this;
    }
  };
  boolean eofFound = false;
  int limit = Integer.MAX_VALUE;
  
  public ASN1InputStream(InputStream paramInputStream)
  {
    super(paramInputStream);
  }
  
  public ASN1InputStream(byte[] paramArrayOfByte)
  {
    this(new ByteArrayInputStream(paramArrayOfByte), paramArrayOfByte.length);
  }
  
  public ASN1InputStream(InputStream paramInputStream, int paramInt)
  {
    super(paramInputStream);
    this.limit = paramInt;
  }
  
  protected int readLength()
    throws IOException
  {
    int i = read();
    if (i < 0) {
      throw new IOException("EOF found when length expected");
    }
    if (i == 128) {
      return -1;
    }
    if (i > 127)
    {
      int j = i & 0x7F;
      if (j > 4) {
        throw new IOException("DER length more than 4 bytes");
      }
      i = 0;
      for (int k = 0; k < j; k++)
      {
        int m = read();
        if (m < 0) {
          throw new IOException("EOF found reading length");
        }
        i = (i << 8) + m;
      }
      if (i < 0) {
        throw new IOException("corrupted steam - negative length found");
      }
      if (i >= this.limit) {
        throw new IOException("corrupted steam - out of bounds length found");
      }
    }
    return i;
  }
  
  protected void readFully(byte[] paramArrayOfByte)
    throws IOException
  {
    int i = paramArrayOfByte.length;
    if (i == 0) {
      return;
    }
    int j;
    while ((j = read(paramArrayOfByte, paramArrayOfByte.length - i, i)) > 0) {
      if (i -= j == 0) {
        return;
      }
    }
    if (i != 0) {
      throw new EOFException("EOF encountered in middle of object");
    }
  }
  
  protected DERObject buildObject(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws IOException
  {
    if ((paramInt1 & 0x40) != 0) {
      return new DERApplicationSpecific(paramInt2, paramArrayOfByte);
    }
    ASN1InputStream localASN1InputStream;
    ASN1EncodableVector localASN1EncodableVector;
    DERObject localDERObject1;
    switch (paramInt1)
    {
    case 5: 
      return new DERNull();
    case 48: 
      localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
      localASN1EncodableVector = new ASN1EncodableVector();
      for (localDERObject1 = localASN1InputStream.readObject(); localDERObject1 != null; localDERObject1 = localASN1InputStream.readObject()) {
        localASN1EncodableVector.add(localDERObject1);
      }
      return new DERSequence(localASN1EncodableVector);
    case 49: 
      localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
      localASN1EncodableVector = new ASN1EncodableVector();
      for (localDERObject1 = localASN1InputStream.readObject(); localDERObject1 != null; localDERObject1 = localASN1InputStream.readObject()) {
        localASN1EncodableVector.add(localDERObject1);
      }
      return new DERSet(localASN1EncodableVector, false);
    case 1: 
      return new DERBoolean(paramArrayOfByte);
    case 2: 
      return new DERInteger(paramArrayOfByte);
    case 10: 
      return new DEREnumerated(paramArrayOfByte);
    case 6: 
      return new DERObjectIdentifier(paramArrayOfByte);
    case 3: 
      int i = paramArrayOfByte[0];
      byte[] arrayOfByte = new byte[paramArrayOfByte.length - 1];
      System.arraycopy(paramArrayOfByte, 1, arrayOfByte, 0, paramArrayOfByte.length - 1);
      return new DERBitString(arrayOfByte, i);
    case 18: 
      return new DERNumericString(paramArrayOfByte);
    case 12: 
      return new DERUTF8String(paramArrayOfByte);
    case 19: 
      return new DERPrintableString(paramArrayOfByte);
    case 22: 
      return new DERIA5String(paramArrayOfByte);
    case 20: 
      return new DERT61String(paramArrayOfByte);
    case 26: 
      return new DERVisibleString(paramArrayOfByte);
    case 27: 
      return new DERGeneralString(paramArrayOfByte);
    case 28: 
      return new DERUniversalString(paramArrayOfByte);
    case 30: 
      return new DERBMPString(paramArrayOfByte);
    case 4: 
      return new DEROctetString(paramArrayOfByte);
    case 36: 
      return buildDerConstructedOctetString(paramArrayOfByte);
    case 23: 
      return new DERUTCTime(paramArrayOfByte);
    case 24: 
      return new DERGeneralizedTime(paramArrayOfByte);
    }
    if ((paramInt1 & 0x80) != 0)
    {
      if (paramArrayOfByte.length == 0)
      {
        if ((paramInt1 & 0x20) == 0) {
          return new DERTaggedObject(false, paramInt2, new DERNull());
        }
        return new DERTaggedObject(false, paramInt2, new DERSequence());
      }
      if ((paramInt1 & 0x20) == 0) {
        return new DERTaggedObject(false, paramInt2, new DEROctetString(paramArrayOfByte));
      }
      localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
      DERObject localDERObject2 = localASN1InputStream.readObject();
      if (localASN1InputStream.available() == 0) {
        return new DERTaggedObject(paramInt2, localDERObject2);
      }
      localASN1EncodableVector = new ASN1EncodableVector();
      while (localDERObject2 != null)
      {
        localASN1EncodableVector.add(localDERObject2);
        localDERObject2 = localASN1InputStream.readObject();
      }
      return new DERTaggedObject(false, paramInt2, new DERSequence(localASN1EncodableVector));
    }
    return new DERUnknownTag(paramInt1, paramArrayOfByte);
  }
  
  private byte[] readIndefiniteLengthFully()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    for (int j = read(); ((i = read()) >= 0) && ((j != 0) || (i != 0)); j = i) {
      localByteArrayOutputStream.write(j);
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  private BERConstructedOctetString buildConstructedOctetString()
    throws IOException
  {
    Vector localVector = new Vector();
    for (;;)
    {
      DERObject localDERObject = readObject();
      if (localDERObject == END_OF_STREAM) {
        break;
      }
      localVector.addElement(localDERObject);
    }
    return new BERConstructedOctetString(localVector);
  }
  
  private BERConstructedOctetString buildDerConstructedOctetString(byte[] paramArrayOfByte)
    throws IOException
  {
    Vector localVector = new Vector();
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    DERObject localDERObject;
    while ((localDERObject = localASN1InputStream.readObject()) != null) {
      localVector.addElement(localDERObject);
    }
    return new BERConstructedOctetString(localVector);
  }
  
  public DERObject readObject()
    throws IOException
  {
    int i = read();
    if (i == -1)
    {
      if (this.eofFound) {
        throw new EOFException("attempt to read past end of file.");
      }
      this.eofFound = true;
      return null;
    }
    int j = 0;
    if (((i & 0x80) != 0) || ((i & 0x40) != 0)) {
      j = readTagNumber(i);
    }
    int k = readLength();
    if (k < 0)
    {
      Object localObject2;
      switch (i)
      {
      case 5: 
        return new BERNull();
      case 48: 
        localObject1 = new ASN1EncodableVector();
        for (;;)
        {
          localObject2 = readObject();
          if (localObject2 == END_OF_STREAM) {
            break;
          }
          ((ASN1EncodableVector)localObject1).add((DEREncodable)localObject2);
        }
        return new BERSequence((DEREncodableVector)localObject1);
      case 49: 
        localObject1 = new ASN1EncodableVector();
        for (;;)
        {
          localObject2 = readObject();
          if (localObject2 == END_OF_STREAM) {
            break;
          }
          ((ASN1EncodableVector)localObject1).add((DEREncodable)localObject2);
        }
        return new BERSet((DEREncodableVector)localObject1, false);
      case 36: 
        return buildConstructedOctetString();
      }
      if ((i & 0x80) != 0)
      {
        if ((i & 0x20) == 0)
        {
          localObject2 = readIndefiniteLengthFully();
          return new BERTaggedObject(false, j, new DEROctetString((byte[])localObject2));
        }
        localObject2 = readObject();
        if (localObject2 == END_OF_STREAM) {
          return new DERTaggedObject(j);
        }
        DERObject localDERObject = readObject();
        if (localDERObject == END_OF_STREAM) {
          return new BERTaggedObject(j, (DEREncodable)localObject2);
        }
        localObject1 = new ASN1EncodableVector();
        ((ASN1EncodableVector)localObject1).add((DEREncodable)localObject2);
        do
        {
          ((ASN1EncodableVector)localObject1).add(localDERObject);
          localDERObject = readObject();
        } while (localDERObject != END_OF_STREAM);
        return new BERTaggedObject(false, j, new BERSequence((DEREncodableVector)localObject1));
      }
      throw new IOException("unknown BER object encountered");
    }
    if ((i == 0) && (k == 0)) {
      return END_OF_STREAM;
    }
    Object localObject1 = new byte[k];
    readFully((byte[])localObject1);
    return buildObject(i, j, (byte[])localObject1);
  }
  
  private int readTagNumber(int paramInt)
    throws IOException
  {
    int i = paramInt & 0x1F;
    if (i == 31)
    {
      int j = read();
      i = 0;
      while ((j >= 0) && ((j & 0x80) != 0))
      {
        i |= j & 0x7F;
        i <<= 7;
        j = read();
      }
      if (j < 0)
      {
        this.eofFound = true;
        throw new EOFException("EOF found inside tag value.");
      }
      i |= j & 0x7F;
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1InputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */