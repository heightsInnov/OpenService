package org.bouncycastle.asn1;

import java.io.IOException;

public class BERSetParser
  implements ASN1SetParser
{
  private ASN1ObjectParser _parser;
  
  BERSetParser(ASN1ObjectParser paramASN1ObjectParser)
  {
    this._parser = paramASN1ObjectParser;
  }
  
  public DEREncodable readObject()
    throws IOException
  {
    return this._parser.readObject();
  }
  
  public DERObject getDERObject()
  {
    return new BERSet(this._parser.readVector());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\BERSetParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */