package org.bouncycastle.asn1.nist;

import java.util.Enumeration;
import java.util.Hashtable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.sec.SECObjectIdentifiers;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.util.Strings;

public class NISTNamedCurves
{
  static final Hashtable objIds = new Hashtable();
  static final Hashtable names = new Hashtable();
  
  static void defineCurve(String paramString, DERObjectIdentifier paramDERObjectIdentifier)
  {
    objIds.put(paramString, paramDERObjectIdentifier);
    names.put(paramDERObjectIdentifier, paramString);
  }
  
  public static X9ECParameters getByName(String paramString)
  {
    DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)objIds.get(Strings.toUpperCase(paramString));
    if (localDERObjectIdentifier != null) {
      return getByOID(localDERObjectIdentifier);
    }
    return null;
  }
  
  public static X9ECParameters getByOID(DERObjectIdentifier paramDERObjectIdentifier)
  {
    return SECNamedCurves.getByOID(paramDERObjectIdentifier);
  }
  
  public static DERObjectIdentifier getOID(String paramString)
  {
    return (DERObjectIdentifier)objIds.get(Strings.toUpperCase(paramString));
  }
  
  public static String getName(DERObjectIdentifier paramDERObjectIdentifier)
  {
    return (String)names.get(paramDERObjectIdentifier);
  }
  
  public static Enumeration getNames()
  {
    return objIds.keys();
  }
  
  static
  {
    defineCurve("B-571", SECObjectIdentifiers.sect571r1);
    defineCurve("B-409", SECObjectIdentifiers.sect409r1);
    defineCurve("B-283", SECObjectIdentifiers.sect283r1);
    defineCurve("B-233", SECObjectIdentifiers.sect233r1);
    defineCurve("B-163", SECObjectIdentifiers.sect163r2);
    defineCurve("P-521", SECObjectIdentifiers.secp521r1);
    defineCurve("P-256", SECObjectIdentifiers.secp256r1);
    defineCurve("P-224", SECObjectIdentifiers.secp224r1);
    defineCurve("P-384", SECObjectIdentifiers.secp384r1);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\nist\NISTNamedCurves.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */