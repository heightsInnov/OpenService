package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class DERGenerator
  extends ASN1Generator
{
  private boolean _tagged = false;
  private boolean _isExplicit;
  private int _tagNo;
  
  protected DERGenerator(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public DERGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
  {
    super(paramOutputStream);
    this._tagged = true;
    this._isExplicit = paramBoolean;
    this._tagNo = paramInt;
  }
  
  private void writeLength(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    if (paramInt > 127)
    {
      int i = 1;
      int j = paramInt;
      while (j >>>= 8 != 0) {
        i++;
      }
      paramOutputStream.write((byte)(i | 0x80));
      for (int k = (i - 1) * 8; k >= 0; k -= 8) {
        paramOutputStream.write((byte)(paramInt >> k));
      }
    }
    else
    {
      paramOutputStream.write((byte)paramInt);
    }
  }
  
  void writeDEREncoded(OutputStream paramOutputStream, int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    paramOutputStream.write(paramInt);
    writeLength(paramOutputStream, paramArrayOfByte.length);
    paramOutputStream.write(paramArrayOfByte);
  }
  
  void writeDEREncoded(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    if (this._tagged)
    {
      int i = this._tagNo | 0x80;
      if (this._isExplicit)
      {
        int j = this._tagNo | 0x20 | 0x80;
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        writeDEREncoded(localByteArrayOutputStream, paramInt, paramArrayOfByte);
        writeDEREncoded(this._out, j, localByteArrayOutputStream.toByteArray());
      }
      else if ((paramInt & 0x20) != 0)
      {
        writeDEREncoded(this._out, i | 0x20, paramArrayOfByte);
      }
      else
      {
        writeDEREncoded(this._out, i, paramArrayOfByte);
      }
    }
    else
    {
      writeDEREncoded(this._out, paramInt, paramArrayOfByte);
    }
  }
  
  void writeDEREncoded(OutputStream paramOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    paramOutputStream.write(paramInt);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    while ((i = paramInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    writeLength(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */