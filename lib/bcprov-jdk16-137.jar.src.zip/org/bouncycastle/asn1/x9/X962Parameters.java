package org.bouncycastle.asn1.x9;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Null;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;

public class X962Parameters
  extends ASN1Encodable
  implements ASN1Choice
{
  private DERObject params = null;
  
  public static X962Parameters getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof X962Parameters))) {
      return (X962Parameters)paramObject;
    }
    if ((paramObject instanceof DERObject)) {
      return new X962Parameters((DERObject)paramObject);
    }
    throw new IllegalArgumentException("unknown object in getInstance()");
  }
  
  public static X962Parameters getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public X962Parameters(X9ECParameters paramX9ECParameters)
  {
    this.params = paramX9ECParameters.getDERObject();
  }
  
  public X962Parameters(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.params = paramDERObjectIdentifier;
  }
  
  public X962Parameters(DERObject paramDERObject)
  {
    this.params = paramDERObject;
  }
  
  public boolean isNamedCurve()
  {
    return this.params instanceof DERObjectIdentifier;
  }
  
  public boolean isImplicitlyCA()
  {
    return this.params instanceof ASN1Null;
  }
  
  public DERObject getParameters()
  {
    return this.params;
  }
  
  public DERObject toASN1Object()
  {
    return this.params;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x9\X962Parameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */