package org.bouncycastle.asn1.x9;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.math.ec.ECFieldElement;
import org.bouncycastle.math.ec.ECFieldElement.F2m;
import org.bouncycastle.math.ec.ECFieldElement.Fp;

public class X9FieldElement
  extends ASN1Encodable
{
  protected ECFieldElement f;
  private static X9IntegerConverter converter = new X9IntegerConverter();
  
  public X9FieldElement(ECFieldElement paramECFieldElement)
  {
    this.f = paramECFieldElement;
  }
  
  public X9FieldElement(BigInteger paramBigInteger, ASN1OctetString paramASN1OctetString)
  {
    this(new ECFieldElement.Fp(paramBigInteger, new BigInteger(1, paramASN1OctetString.getOctets())));
  }
  
  public X9FieldElement(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ASN1OctetString paramASN1OctetString)
  {
    this(new ECFieldElement.F2m(paramInt1, paramInt2, paramInt3, paramInt4, new BigInteger(1, paramASN1OctetString.getOctets())));
  }
  
  public ECFieldElement getValue()
  {
    return this.f;
  }
  
  public DERObject toASN1Object()
  {
    int i = converter.getByteLength(this.f);
    byte[] arrayOfByte = converter.integerToBytes(this.f.toBigInteger(), i);
    return new DEROctetString(arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x9\X9FieldElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */