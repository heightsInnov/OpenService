package org.bouncycastle.asn1.x9;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECCurve.F2m;
import org.bouncycastle.math.ec.ECCurve.Fp;
import org.bouncycastle.math.ec.ECFieldElement;

public class X9Curve
  extends ASN1Encodable
  implements X9ObjectIdentifiers
{
  private ECCurve curve;
  private byte[] seed;
  private DERObjectIdentifier fieldIdentifier = null;
  
  public X9Curve(ECCurve paramECCurve)
  {
    this.curve = paramECCurve;
    this.seed = null;
    setFieldIdentifier();
  }
  
  public X9Curve(ECCurve paramECCurve, byte[] paramArrayOfByte)
  {
    this.curve = paramECCurve;
    this.seed = paramArrayOfByte;
    setFieldIdentifier();
  }
  
  public X9Curve(X9FieldID paramX9FieldID, ASN1Sequence paramASN1Sequence)
  {
    this.fieldIdentifier = paramX9FieldID.getIdentifier();
    Object localObject1;
    Object localObject2;
    if (this.fieldIdentifier.equals(prime_field))
    {
      localObject1 = ((DERInteger)paramX9FieldID.getParameters()).getValue();
      X9FieldElement localX9FieldElement1 = new X9FieldElement((BigInteger)localObject1, (ASN1OctetString)paramASN1Sequence.getObjectAt(0));
      localObject2 = new X9FieldElement((BigInteger)localObject1, (ASN1OctetString)paramASN1Sequence.getObjectAt(1));
      this.curve = new ECCurve.Fp((BigInteger)localObject1, localX9FieldElement1.getValue().toBigInteger(), ((X9FieldElement)localObject2).getValue().toBigInteger());
    }
    else if (this.fieldIdentifier.equals(characteristic_two_field))
    {
      localObject1 = (DERSequence)paramX9FieldID.getParameters();
      int i = ((DERInteger)((DERSequence)localObject1).getObjectAt(0)).getValue().intValue();
      localObject2 = (DERObjectIdentifier)((DERSequence)localObject1).getObjectAt(1);
      int j = 0;
      int k = 0;
      int m = 0;
      if (((DERObjectIdentifier)localObject2).equals(tpBasis))
      {
        j = ((DERInteger)((DERSequence)localObject1).getObjectAt(2)).getValue().intValue();
      }
      else
      {
        localObject3 = (DERSequence)((DERSequence)localObject1).getObjectAt(2);
        j = ((DERInteger)((DERSequence)localObject3).getObjectAt(0)).getValue().intValue();
        k = ((DERInteger)((DERSequence)localObject3).getObjectAt(1)).getValue().intValue();
        m = ((DERInteger)((DERSequence)localObject3).getObjectAt(2)).getValue().intValue();
      }
      Object localObject3 = new X9FieldElement(i, j, k, m, (ASN1OctetString)paramASN1Sequence.getObjectAt(0));
      X9FieldElement localX9FieldElement2 = new X9FieldElement(i, j, k, m, (ASN1OctetString)paramASN1Sequence.getObjectAt(1));
      this.curve = new ECCurve.F2m(i, j, k, m, ((X9FieldElement)localObject3).getValue().toBigInteger(), localX9FieldElement2.getValue().toBigInteger());
    }
    if (paramASN1Sequence.size() == 3) {
      this.seed = ((DERBitString)paramASN1Sequence.getObjectAt(2)).getBytes();
    }
  }
  
  private void setFieldIdentifier()
  {
    if ((this.curve instanceof ECCurve.Fp)) {
      this.fieldIdentifier = prime_field;
    } else if ((this.curve instanceof ECCurve.F2m)) {
      this.fieldIdentifier = characteristic_two_field;
    } else {
      throw new IllegalArgumentException("This type of ECCurve is not implemented");
    }
  }
  
  public ECCurve getCurve()
  {
    return this.curve;
  }
  
  public byte[] getSeed()
  {
    return this.seed;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.fieldIdentifier.equals(prime_field))
    {
      localASN1EncodableVector.add(new X9FieldElement(this.curve.getA()).getDERObject());
      localASN1EncodableVector.add(new X9FieldElement(this.curve.getB()).getDERObject());
    }
    else if (this.fieldIdentifier.equals(characteristic_two_field))
    {
      localASN1EncodableVector.add(new X9FieldElement(this.curve.getA()).getDERObject());
      localASN1EncodableVector.add(new X9FieldElement(this.curve.getB()).getDERObject());
    }
    if (this.seed != null) {
      localASN1EncodableVector.add(new DERBitString(this.seed));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x9\X9Curve.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */