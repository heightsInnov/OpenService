package org.bouncycastle.asn1.x9;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class KeySpecificInfo
  extends ASN1Encodable
{
  private DERObjectIdentifier algorithm;
  private ASN1OctetString counter;
  
  public KeySpecificInfo(DERObjectIdentifier paramDERObjectIdentifier, ASN1OctetString paramASN1OctetString)
  {
    this.algorithm = paramDERObjectIdentifier;
    this.counter = paramASN1OctetString;
  }
  
  public KeySpecificInfo(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.algorithm = ((DERObjectIdentifier)localEnumeration.nextElement());
    this.counter = ((ASN1OctetString)localEnumeration.nextElement());
  }
  
  public DERObjectIdentifier getAlgorithm()
  {
    return this.algorithm;
  }
  
  public ASN1OctetString getCounter()
  {
    return this.counter;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.algorithm);
    localASN1EncodableVector.add(this.counter);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x9\KeySpecificInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */