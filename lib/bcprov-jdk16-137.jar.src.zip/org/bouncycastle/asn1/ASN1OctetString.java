package org.bouncycastle.asn1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.util.encoders.Hex;

public abstract class ASN1OctetString
  extends ASN1Object
  implements ASN1OctetStringParser
{
  byte[] string;
  
  public static ASN1OctetString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public static ASN1OctetString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ASN1OctetString))) {
      return (ASN1OctetString)paramObject;
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    if ((paramObject instanceof ASN1Sequence))
    {
      Vector localVector = new Vector();
      Enumeration localEnumeration = ((ASN1Sequence)paramObject).getObjects();
      while (localEnumeration.hasMoreElements()) {
        localVector.addElement(localEnumeration.nextElement());
      }
      return new BERConstructedOctetString(localVector);
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public ASN1OctetString(byte[] paramArrayOfByte)
  {
    this.string = paramArrayOfByte;
  }
  
  public ASN1OctetString(DEREncodable paramDEREncodable)
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
      localDEROutputStream.writeObject(paramDEREncodable);
      localDEROutputStream.close();
      this.string = localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("Error processing object : " + localIOException.toString());
    }
  }
  
  public InputStream getOctetStream()
  {
    return new ByteArrayInputStream(this.string);
  }
  
  public ASN1OctetStringParser parser()
  {
    return this;
  }
  
  public byte[] getOctets()
  {
    return this.string;
  }
  
  public int hashCode()
  {
    byte[] arrayOfByte = getOctets();
    int i = 0;
    for (int j = 0; j != arrayOfByte.length; j++) {
      i ^= (arrayOfByte[j] & 0xFF) << j % 4;
    }
    return i;
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof ASN1OctetString)) {
      return false;
    }
    ASN1OctetString localASN1OctetString = (ASN1OctetString)paramDERObject;
    byte[] arrayOfByte1 = localASN1OctetString.string;
    byte[] arrayOfByte2 = this.string;
    if (arrayOfByte1.length != arrayOfByte2.length) {
      return false;
    }
    for (int i = 0; i != arrayOfByte1.length; i++) {
      if (arrayOfByte1[i] != arrayOfByte2[i]) {
        return false;
      }
    }
    return true;
  }
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  public String toString()
  {
    return "#" + new String(Hex.encode(this.string));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1OctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */