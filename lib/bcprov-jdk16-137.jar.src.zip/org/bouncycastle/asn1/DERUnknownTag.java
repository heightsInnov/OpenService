package org.bouncycastle.asn1;

import java.io.IOException;

public class DERUnknownTag
  extends DERObject
{
  int tag;
  byte[] data;
  
  public DERUnknownTag(int paramInt, byte[] paramArrayOfByte)
  {
    this.tag = paramInt;
    this.data = paramArrayOfByte;
  }
  
  public int getTag()
  {
    return this.tag;
  }
  
  public byte[] getData()
  {
    return this.data;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(this.tag, this.data);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof DERUnknownTag)) {
      return false;
    }
    DERUnknownTag localDERUnknownTag = (DERUnknownTag)paramObject;
    if (this.tag != localDERUnknownTag.tag) {
      return false;
    }
    if (this.data.length != localDERUnknownTag.data.length) {
      return false;
    }
    for (int i = 0; i < this.data.length; i++) {
      if (this.data[i] != localDERUnknownTag.data[i]) {
        return false;
      }
    }
    return true;
  }
  
  public int hashCode()
  {
    byte[] arrayOfByte = getData();
    int i = 0;
    for (int j = 0; j != arrayOfByte.length; j++) {
      i ^= (arrayOfByte[j] & 0xFF) << j % 4;
    }
    return i ^ getTag();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERUnknownTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */