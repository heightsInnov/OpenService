package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.InputStream;

class ConstructedOctetStream
  extends InputStream
{
  private final ASN1ObjectParser _parser;
  private boolean _first = true;
  private InputStream _currentStream;
  
  ConstructedOctetStream(ASN1ObjectParser paramASN1ObjectParser)
  {
    this._parser = paramASN1ObjectParser;
  }
  
  public int read()
    throws IOException
  {
    if (this._first)
    {
      ASN1OctetStringParser localASN1OctetStringParser1 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser1 == null) {
        return -1;
      }
      this._first = false;
      this._currentStream = localASN1OctetStringParser1.getOctetStream();
    }
    else if (this._currentStream == null)
    {
      return -1;
    }
    int i = this._currentStream.read();
    if (i < 0)
    {
      ASN1OctetStringParser localASN1OctetStringParser2 = (ASN1OctetStringParser)this._parser.readObject();
      if (localASN1OctetStringParser2 == null)
      {
        this._currentStream = null;
        return -1;
      }
      this._currentStream = localASN1OctetStringParser2.getOctetStream();
      return this._currentStream.read();
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ConstructedOctetStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */