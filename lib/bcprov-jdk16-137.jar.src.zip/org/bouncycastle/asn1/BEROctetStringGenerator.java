package org.bouncycastle.asn1;

import java.io.IOException;
import java.io.OutputStream;

public class BEROctetStringGenerator
  extends BERGenerator
{
  public BEROctetStringGenerator(OutputStream paramOutputStream)
    throws IOException
  {
    super(paramOutputStream);
    writeBERHeader(36);
  }
  
  public BEROctetStringGenerator(OutputStream paramOutputStream, int paramInt, boolean paramBoolean)
    throws IOException
  {
    super(paramOutputStream, paramInt, paramBoolean);
    writeBERHeader(36);
  }
  
  public OutputStream getOctetOutputStream()
  {
    return new BEROctetStream(null);
  }
  
  public OutputStream getOctetOutputStream(byte[] paramArrayOfByte)
  {
    return new BufferedBEROctetStream(paramArrayOfByte);
  }
  
  private class BufferedBEROctetStream
    extends OutputStream
  {
    private byte[] _buf;
    private int _off;
    
    BufferedBEROctetStream(byte[] paramArrayOfByte)
    {
      this._buf = paramArrayOfByte;
      this._off = 0;
    }
    
    public void write(int paramInt)
      throws IOException
    {
      this._buf[(this._off++)] = ((byte)paramInt);
      if (this._off == this._buf.length)
      {
        BEROctetStringGenerator.this._out.write(new DEROctetString(this._buf).getEncoded());
        this._off = 0;
      }
    }
    
    public void close()
      throws IOException
    {
      if (this._off != 0)
      {
        byte[] arrayOfByte = new byte[this._off];
        System.arraycopy(this._buf, 0, arrayOfByte, 0, this._off);
        BEROctetStringGenerator.this._out.write(new DEROctetString(arrayOfByte).getEncoded());
      }
      BEROctetStringGenerator.this.writeBEREnd();
    }
  }
  
  private class BEROctetStream
    extends OutputStream
  {
    private byte[] _buf = new byte[1];
    
    private BEROctetStream() {}
    
    public void write(int paramInt)
      throws IOException
    {
      this._buf[0] = ((byte)paramInt);
      BEROctetStringGenerator.this._out.write(new DEROctetString(this._buf).getEncoded());
    }
    
    public void write(byte[] paramArrayOfByte)
      throws IOException
    {
      BEROctetStringGenerator.this._out.write(new DEROctetString(paramArrayOfByte).getEncoded());
    }
    
    public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      byte[] arrayOfByte = new byte[paramInt2];
      System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
      BEROctetStringGenerator.this._out.write(new DEROctetString(arrayOfByte).getEncoded());
    }
    
    public void close()
      throws IOException
    {
      BEROctetStringGenerator.this.writeBEREnd();
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\BEROctetStringGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */