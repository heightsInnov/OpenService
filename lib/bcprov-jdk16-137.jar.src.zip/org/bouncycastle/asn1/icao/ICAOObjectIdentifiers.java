package org.bouncycastle.asn1.icao;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface ICAOObjectIdentifiers
{
  public static final String id_icao = "1.3.27";
  public static final DERObjectIdentifier id_icao_mrtd = new DERObjectIdentifier("1.3.27.1");
  public static final DERObjectIdentifier id_icao_mrtd_security = new DERObjectIdentifier(id_icao_mrtd + ".1");
  public static final DERObjectIdentifier id_icao_ldsSecurityObject = new DERObjectIdentifier(id_icao_mrtd_security + ".1");
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\icao\ICAOObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */