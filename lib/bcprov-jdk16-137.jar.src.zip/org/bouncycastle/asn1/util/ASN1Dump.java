package org.bouncycastle.asn1.util;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERConstructedOctetString;
import org.bouncycastle.asn1.BERConstructedSequence;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.BERSet;
import org.bouncycastle.asn1.BERTaggedObject;
import org.bouncycastle.asn1.DERBMPString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERBoolean;
import org.bouncycastle.asn1.DERConstructedSequence;
import org.bouncycastle.asn1.DERConstructedSet;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERT61String;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTCTime;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.DERUnknownTag;
import org.bouncycastle.asn1.DERVisibleString;
import org.bouncycastle.util.encoders.Hex;

public class ASN1Dump
{
  private static final String TAB = "    ";
  
  static String _dumpAsString(String paramString, DERObject paramDERObject)
  {
    StringBuffer localStringBuffer;
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if ((paramDERObject instanceof ASN1Sequence))
    {
      localStringBuffer = new StringBuffer();
      localObject1 = ((ASN1Sequence)paramDERObject).getObjects();
      localObject2 = paramString + "    ";
      localStringBuffer.append(paramString);
      if ((paramDERObject instanceof BERConstructedSequence)) {
        localStringBuffer.append("BER ConstructedSequence");
      } else if ((paramDERObject instanceof DERConstructedSequence)) {
        localStringBuffer.append("DER ConstructedSequence");
      } else if ((paramDERObject instanceof BERSequence)) {
        localStringBuffer.append("BER Sequence");
      } else if ((paramDERObject instanceof DERSequence)) {
        localStringBuffer.append("DER Sequence");
      } else {
        localStringBuffer.append("Sequence");
      }
      localStringBuffer.append(System.getProperty("line.separator"));
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject3 = ((Enumeration)localObject1).nextElement();
        if ((localObject3 == null) || (localObject3.equals(new DERNull())))
        {
          localStringBuffer.append((String)localObject2);
          localStringBuffer.append("NULL");
          localStringBuffer.append(System.getProperty("line.separator"));
        }
        else if ((localObject3 instanceof DERObject))
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, (DERObject)localObject3));
        }
        else
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, ((DEREncodable)localObject3).getDERObject()));
        }
      }
      return localStringBuffer.toString();
    }
    if ((paramDERObject instanceof DERTaggedObject))
    {
      localStringBuffer = new StringBuffer();
      localObject1 = paramString + "    ";
      localStringBuffer.append(paramString);
      if ((paramDERObject instanceof BERTaggedObject)) {
        localStringBuffer.append("BER Tagged [");
      } else {
        localStringBuffer.append("Tagged [");
      }
      localObject2 = (DERTaggedObject)paramDERObject;
      localStringBuffer.append(Integer.toString(((DERTaggedObject)localObject2).getTagNo()));
      localStringBuffer.append(']');
      if (!((DERTaggedObject)localObject2).isExplicit()) {
        localStringBuffer.append(" IMPLICIT ");
      }
      localStringBuffer.append(System.getProperty("line.separator"));
      if (((DERTaggedObject)localObject2).isEmpty())
      {
        localStringBuffer.append((String)localObject1);
        localStringBuffer.append("EMPTY");
        localStringBuffer.append(System.getProperty("line.separator"));
      }
      else
      {
        localStringBuffer.append(_dumpAsString((String)localObject1, ((DERTaggedObject)localObject2).getObject()));
      }
      return localStringBuffer.toString();
    }
    if ((paramDERObject instanceof DERConstructedSet))
    {
      localStringBuffer = new StringBuffer();
      localObject1 = ((ASN1Set)paramDERObject).getObjects();
      localObject2 = paramString + "    ";
      localStringBuffer.append(paramString);
      localStringBuffer.append("ConstructedSet");
      localStringBuffer.append(System.getProperty("line.separator"));
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject3 = ((Enumeration)localObject1).nextElement();
        if (localObject3 == null)
        {
          localStringBuffer.append((String)localObject2);
          localStringBuffer.append("NULL");
          localStringBuffer.append(System.getProperty("line.separator"));
        }
        else if ((localObject3 instanceof DERObject))
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, (DERObject)localObject3));
        }
        else
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, ((DEREncodable)localObject3).getDERObject()));
        }
      }
      return localStringBuffer.toString();
    }
    if ((paramDERObject instanceof BERSet))
    {
      localStringBuffer = new StringBuffer();
      localObject1 = ((ASN1Set)paramDERObject).getObjects();
      localObject2 = paramString + "    ";
      localStringBuffer.append(paramString);
      localStringBuffer.append("BER Set");
      localStringBuffer.append(System.getProperty("line.separator"));
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject3 = ((Enumeration)localObject1).nextElement();
        if (localObject3 == null)
        {
          localStringBuffer.append((String)localObject2);
          localStringBuffer.append("NULL");
          localStringBuffer.append(System.getProperty("line.separator"));
        }
        else if ((localObject3 instanceof DERObject))
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, (DERObject)localObject3));
        }
        else
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, ((DEREncodable)localObject3).getDERObject()));
        }
      }
      return localStringBuffer.toString();
    }
    if ((paramDERObject instanceof DERSet))
    {
      localStringBuffer = new StringBuffer();
      localObject1 = ((ASN1Set)paramDERObject).getObjects();
      localObject2 = paramString + "    ";
      localStringBuffer.append(paramString);
      localStringBuffer.append("DER Set");
      localStringBuffer.append(System.getProperty("line.separator"));
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject3 = ((Enumeration)localObject1).nextElement();
        if (localObject3 == null)
        {
          localStringBuffer.append((String)localObject2);
          localStringBuffer.append("NULL");
          localStringBuffer.append(System.getProperty("line.separator"));
        }
        else if ((localObject3 instanceof DERObject))
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, (DERObject)localObject3));
        }
        else
        {
          localStringBuffer.append(_dumpAsString((String)localObject2, ((DEREncodable)localObject3).getDERObject()));
        }
      }
      return localStringBuffer.toString();
    }
    if ((paramDERObject instanceof DERObjectIdentifier)) {
      return paramString + "ObjectIdentifier(" + ((DERObjectIdentifier)paramDERObject).getId() + ")" + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERBoolean)) {
      return paramString + "Boolean(" + ((DERBoolean)paramDERObject).isTrue() + ")" + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERInteger)) {
      return paramString + "Integer(" + ((DERInteger)paramDERObject).getValue() + ")" + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof BERConstructedOctetString)) {
      return paramString + "BER Constructed Octet String" + "[" + ((ASN1OctetString)paramDERObject).getOctets().length + "] " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DEROctetString)) {
      return paramString + "DER Octet String" + "[" + ((ASN1OctetString)paramDERObject).getOctets().length + "] " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERBitString)) {
      return paramString + "DER Bit String" + "[" + ((DERBitString)paramDERObject).getBytes().length + ", " + ((DERBitString)paramDERObject).getPadBits() + "] " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERIA5String)) {
      return paramString + "IA5String(" + ((DERIA5String)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERUTF8String)) {
      return paramString + "UTF8String(" + ((DERUTF8String)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERPrintableString)) {
      return paramString + "PrintableString(" + ((DERPrintableString)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERVisibleString)) {
      return paramString + "VisibleString(" + ((DERVisibleString)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERBMPString)) {
      return paramString + "BMPString(" + ((DERBMPString)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERT61String)) {
      return paramString + "T61String(" + ((DERT61String)paramDERObject).getString() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERUTCTime)) {
      return paramString + "UTCTime(" + ((DERUTCTime)paramDERObject).getTime() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERGeneralizedTime)) {
      return paramString + "GeneralizedTime(" + ((DERGeneralizedTime)paramDERObject).getTime() + ") " + System.getProperty("line.separator");
    }
    if ((paramDERObject instanceof DERUnknownTag)) {
      return paramString + "Unknown " + Integer.toString(((DERUnknownTag)paramDERObject).getTag(), 16) + " " + new String(Hex.encode(((DERUnknownTag)paramDERObject).getData())) + System.getProperty("line.separator");
    }
    return paramString + paramDERObject.toString() + System.getProperty("line.separator");
  }
  
  public static String dumpAsString(Object paramObject)
  {
    if ((paramObject instanceof DERObject)) {
      return _dumpAsString("", (DERObject)paramObject);
    }
    if ((paramObject instanceof DEREncodable)) {
      return _dumpAsString("", ((DEREncodable)paramObject).getDERObject());
    }
    return "unknown object type " + paramObject.toString();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\util\ASN1Dump.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */