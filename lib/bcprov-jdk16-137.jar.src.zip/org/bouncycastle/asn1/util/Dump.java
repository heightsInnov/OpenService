package org.bouncycastle.asn1.util;

import java.io.FileInputStream;
import java.io.PrintStream;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObject;

public class Dump
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(paramArrayOfString[0]);
    ASN1InputStream localASN1InputStream = new ASN1InputStream(localFileInputStream);
    DERObject localDERObject = null;
    while ((localDERObject = localASN1InputStream.readObject()) != null) {
      System.out.println(ASN1Dump.dumpAsString(localDERObject));
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\util\Dump.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */