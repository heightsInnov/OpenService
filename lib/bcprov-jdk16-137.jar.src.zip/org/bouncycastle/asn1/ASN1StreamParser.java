package org.bouncycastle.asn1;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class ASN1StreamParser
{
  InputStream _in;
  private int _limit;
  private boolean _eofFound;
  
  public ASN1StreamParser(InputStream paramInputStream)
  {
    this(paramInputStream, Integer.MAX_VALUE);
  }
  
  public ASN1StreamParser(InputStream paramInputStream, int paramInt)
  {
    this._in = paramInputStream;
    this._limit = paramInt;
  }
  
  public ASN1StreamParser(byte[] paramArrayOfByte)
  {
    this(new ByteArrayInputStream(paramArrayOfByte), paramArrayOfByte.length);
  }
  
  InputStream getParentStream()
  {
    return this._in;
  }
  
  private int readLength()
    throws IOException
  {
    int i = this._in.read();
    if (i < 0) {
      throw new EOFException("EOF found when length expected");
    }
    if (i == 128) {
      return -1;
    }
    if (i > 127)
    {
      int j = i & 0x7F;
      if (j > 4) {
        throw new IOException("DER length more than 4 bytes");
      }
      i = 0;
      for (int k = 0; k < j; k++)
      {
        int m = this._in.read();
        if (m < 0) {
          throw new EOFException("EOF found reading length");
        }
        i = (i << 8) + m;
      }
      if (i < 0) {
        throw new IOException("corrupted steam - negative length found");
      }
      if (i >= this._limit) {
        throw new IOException("corrupted steam - out of bounds length found");
      }
    }
    return i;
  }
  
  public DEREncodable readObject()
    throws IOException
  {
    int i = this._in.read();
    if (i == -1)
    {
      if (this._eofFound) {
        throw new EOFException("attempt to read past end of file.");
      }
      this._eofFound = true;
      return null;
    }
    if ((this._in instanceof IndefiniteLengthInputStream)) {
      ((IndefiniteLengthInputStream)this._in).setEofOn00(false);
    }
    int j = i & 0xFFFFFFDF;
    int k = j;
    if ((i & 0x80) != 0)
    {
      k = i & 0x1F;
      if (k == 31)
      {
        k = 0;
        for (m = this._in.read(); (m >= 0) && ((m & 0x80) != 0); m = this._in.read())
        {
          k |= m & 0x7F;
          k <<= 7;
        }
        if (m < 0)
        {
          this._eofFound = true;
          throw new EOFException("EOF encountered inside tag value.");
        }
        k |= m & 0x7F;
      }
    }
    int m = readLength();
    if (m < 0)
    {
      localObject = new IndefiniteLengthInputStream(this._in);
      if (j == 5) {
        return BERNull.INSTANCE;
      }
      switch (j)
      {
      case 4: 
        return new BEROctetStringParser(new ASN1ObjectParser(i, k, (InputStream)localObject));
      case 16: 
        return new BERSequenceParser(new ASN1ObjectParser(i, k, (InputStream)localObject));
      case 17: 
        return new BERSetParser(new ASN1ObjectParser(i, k, (InputStream)localObject));
      }
      return new BERTaggedObjectParser(i, k, (InputStream)localObject);
    }
    Object localObject = new DefiniteLengthInputStream(this._in, m);
    switch (j)
    {
    case 2: 
      return new DERInteger(((DefiniteLengthInputStream)localObject).toByteArray());
    case 5: 
      return DERNull.INSTANCE;
    case 6: 
      return new DERObjectIdentifier(((DefiniteLengthInputStream)localObject).toByteArray());
    case 4: 
      return new DEROctetString(((DefiniteLengthInputStream)localObject).toByteArray());
    case 16: 
      return new DERSequence(loadVector(((DefiniteLengthInputStream)localObject).toByteArray())).parser();
    case 17: 
      return new DERSet(loadVector(((DefiniteLengthInputStream)localObject).toByteArray())).parser();
    }
    return new BERTaggedObjectParser(i, k, (InputStream)localObject);
  }
  
  private ASN1EncodableVector loadVector(byte[] paramArrayOfByte)
    throws IOException
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    for (DERObject localDERObject = localASN1InputStream.readObject(); localDERObject != null; localDERObject = localASN1InputStream.readObject()) {
      localASN1EncodableVector.add(localDERObject);
    }
    return localASN1EncodableVector;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1StreamParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */