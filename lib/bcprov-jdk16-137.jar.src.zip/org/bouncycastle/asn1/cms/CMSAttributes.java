package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public abstract interface CMSAttributes
{
  public static final DERObjectIdentifier contentType = PKCSObjectIdentifiers.pkcs_9_at_contentType;
  public static final DERObjectIdentifier messageDigest = PKCSObjectIdentifiers.pkcs_9_at_messageDigest;
  public static final DERObjectIdentifier signingTime = PKCSObjectIdentifiers.pkcs_9_at_signingTime;
  public static final DERObjectIdentifier counterSignature = PKCSObjectIdentifiers.pkcs_9_at_counterSignature;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\cms\CMSAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */