package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class RecipientEncryptedKey
  extends ASN1Encodable
{
  private KeyAgreeRecipientIdentifier identifier;
  private ASN1OctetString encryptedKey;
  
  private RecipientEncryptedKey(ASN1Sequence paramASN1Sequence)
  {
    this.identifier = KeyAgreeRecipientIdentifier.getInstance(paramASN1Sequence.getObjectAt(0));
    this.encryptedKey = ((ASN1OctetString)paramASN1Sequence.getObjectAt(1));
  }
  
  public static RecipientEncryptedKey getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static RecipientEncryptedKey getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof RecipientEncryptedKey))) {
      return (RecipientEncryptedKey)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RecipientEncryptedKey((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid RecipientEncryptedKey: " + paramObject.getClass().getName());
  }
  
  public RecipientEncryptedKey(KeyAgreeRecipientIdentifier paramKeyAgreeRecipientIdentifier, ASN1OctetString paramASN1OctetString)
  {
    this.identifier = paramKeyAgreeRecipientIdentifier;
    this.encryptedKey = paramASN1OctetString;
  }
  
  public KeyAgreeRecipientIdentifier getIdentifier()
  {
    return this.identifier;
  }
  
  public ASN1OctetString getEncryptedKey()
  {
    return this.encryptedKey;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.identifier);
    localASN1EncodableVector.add(this.encryptedKey);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\cms\RecipientEncryptedKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */