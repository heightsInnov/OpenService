package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class OriginatorIdentifierOrKey
  extends ASN1Encodable
{
  private DEREncodable id;
  
  public OriginatorIdentifierOrKey(IssuerAndSerialNumber paramIssuerAndSerialNumber)
  {
    this.id = paramIssuerAndSerialNumber;
  }
  
  public OriginatorIdentifierOrKey(ASN1OctetString paramASN1OctetString)
  {
    this.id = new DERTaggedObject(false, 0, paramASN1OctetString);
  }
  
  public OriginatorIdentifierOrKey(OriginatorPublicKey paramOriginatorPublicKey)
  {
    this.id = new DERTaggedObject(false, 1, paramOriginatorPublicKey);
  }
  
  public OriginatorIdentifierOrKey(DERObject paramDERObject)
  {
    this.id = paramDERObject;
  }
  
  public static OriginatorIdentifierOrKey getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    if (!paramBoolean) {
      throw new IllegalArgumentException("Can't implicitly tag OriginatorIdentifierOrKey");
    }
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public static OriginatorIdentifierOrKey getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof OriginatorIdentifierOrKey))) {
      return (OriginatorIdentifierOrKey)paramObject;
    }
    if ((paramObject instanceof DERObject)) {
      return new OriginatorIdentifierOrKey((DERObject)paramObject);
    }
    throw new IllegalArgumentException("Invalid OriginatorIdentifierOrKey: " + paramObject.getClass().getName());
  }
  
  public DEREncodable getId()
  {
    return this.id;
  }
  
  public OriginatorPublicKey getOriginatorKey()
  {
    if (((this.id instanceof ASN1TaggedObject)) && (((ASN1TaggedObject)this.id).getTagNo() == 1)) {
      return OriginatorPublicKey.getInstance((ASN1TaggedObject)this.id, false);
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    return this.id.getDERObject();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\cms\OriginatorIdentifierOrKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */