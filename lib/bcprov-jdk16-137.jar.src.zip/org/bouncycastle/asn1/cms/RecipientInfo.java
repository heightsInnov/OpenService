package org.bouncycastle.asn1.cms;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class RecipientInfo
  extends ASN1Encodable
{
  DEREncodable info;
  
  public RecipientInfo(KeyTransRecipientInfo paramKeyTransRecipientInfo)
  {
    this.info = paramKeyTransRecipientInfo;
  }
  
  public RecipientInfo(KeyAgreeRecipientInfo paramKeyAgreeRecipientInfo)
  {
    this.info = new DERTaggedObject(false, 1, paramKeyAgreeRecipientInfo);
  }
  
  public RecipientInfo(KEKRecipientInfo paramKEKRecipientInfo)
  {
    this.info = new DERTaggedObject(false, 2, paramKEKRecipientInfo);
  }
  
  public RecipientInfo(PasswordRecipientInfo paramPasswordRecipientInfo)
  {
    this.info = new DERTaggedObject(false, 3, paramPasswordRecipientInfo);
  }
  
  public RecipientInfo(OtherRecipientInfo paramOtherRecipientInfo)
  {
    this.info = new DERTaggedObject(false, 4, paramOtherRecipientInfo);
  }
  
  public RecipientInfo(DERObject paramDERObject)
  {
    this.info = paramDERObject;
  }
  
  public static RecipientInfo getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof RecipientInfo))) {
      return (RecipientInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RecipientInfo((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return new RecipientInfo((ASN1TaggedObject)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass().getName());
  }
  
  public DERInteger getVersion()
  {
    if ((this.info instanceof ASN1TaggedObject))
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)this.info;
      switch (localASN1TaggedObject.getTagNo())
      {
      case 1: 
        return KeyAgreeRecipientInfo.getInstance(localASN1TaggedObject, false).getVersion();
      case 2: 
        return getKEKInfo(localASN1TaggedObject).getVersion();
      case 3: 
        return PasswordRecipientInfo.getInstance(localASN1TaggedObject, false).getVersion();
      case 4: 
        return new DERInteger(0);
      }
      throw new IllegalStateException("unknown tag");
    }
    return KeyTransRecipientInfo.getInstance(this.info).getVersion();
  }
  
  public boolean isTagged()
  {
    return this.info instanceof ASN1TaggedObject;
  }
  
  public DEREncodable getInfo()
  {
    if ((this.info instanceof ASN1TaggedObject))
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)this.info;
      switch (localASN1TaggedObject.getTagNo())
      {
      case 1: 
        return KeyAgreeRecipientInfo.getInstance(localASN1TaggedObject, false);
      case 2: 
        return getKEKInfo(localASN1TaggedObject);
      case 3: 
        return PasswordRecipientInfo.getInstance(localASN1TaggedObject, false);
      case 4: 
        return OtherRecipientInfo.getInstance(localASN1TaggedObject, false);
      }
      throw new IllegalStateException("unknown tag");
    }
    return KeyTransRecipientInfo.getInstance(this.info);
  }
  
  private KEKRecipientInfo getKEKInfo(ASN1TaggedObject paramASN1TaggedObject)
  {
    if (paramASN1TaggedObject.isExplicit()) {
      return KEKRecipientInfo.getInstance(paramASN1TaggedObject, true);
    }
    return KEKRecipientInfo.getInstance(paramASN1TaggedObject, false);
  }
  
  public DERObject toASN1Object()
  {
    return this.info.getDERObject();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\cms\RecipientInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */