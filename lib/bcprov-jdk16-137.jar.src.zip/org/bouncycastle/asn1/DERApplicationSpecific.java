package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class DERApplicationSpecific
  extends ASN1Object
{
  private int tag;
  private byte[] octets;
  
  public DERApplicationSpecific(int paramInt, byte[] paramArrayOfByte)
  {
    this.tag = paramInt;
    this.octets = paramArrayOfByte;
  }
  
  public DERApplicationSpecific(int paramInt, DEREncodable paramDEREncodable)
    throws IOException
  {
    this(true, paramInt, paramDEREncodable);
  }
  
  public DERApplicationSpecific(boolean paramBoolean, int paramInt, DEREncodable paramDEREncodable)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    localDEROutputStream.writeObject(paramDEREncodable);
    byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
    if (paramInt >= 31) {
      throw new IOException("unsupported tag number");
    }
    if (paramBoolean)
    {
      this.tag = (paramInt | 0x20);
      this.octets = arrayOfByte1;
    }
    else
    {
      this.tag = paramInt;
      int i = getLengthOfLength(arrayOfByte1);
      byte[] arrayOfByte2 = new byte[arrayOfByte1.length - i];
      System.arraycopy(arrayOfByte1, i, arrayOfByte2, 0, arrayOfByte2.length);
      this.octets = arrayOfByte2;
    }
  }
  
  private int getLengthOfLength(byte[] paramArrayOfByte)
  {
    for (int i = 2; (paramArrayOfByte[(i - 1)] & 0x80) != 0; i++) {}
    return i;
  }
  
  public boolean isConstructed()
  {
    return (this.tag & 0x20) != 0;
  }
  
  public byte[] getContents()
  {
    return this.octets;
  }
  
  public int getApplicationTag()
  {
    return this.tag;
  }
  
  public DERObject getObject()
    throws IOException
  {
    return new ASN1InputStream(getContents()).readObject();
  }
  
  public DERObject getObject(int paramInt)
    throws IOException
  {
    if (this.tag >= 31) {
      throw new IOException("unsupported tag number");
    }
    byte[] arrayOfByte = getEncoded();
    arrayOfByte[0] = ((byte)paramInt);
    return new ASN1InputStream(arrayOfByte).readObject();
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(0x40 | this.tag, this.octets);
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERApplicationSpecific)) {
      return false;
    }
    DERApplicationSpecific localDERApplicationSpecific = (DERApplicationSpecific)paramDERObject;
    if (this.tag != localDERApplicationSpecific.tag) {
      return false;
    }
    if (this.octets.length != localDERApplicationSpecific.octets.length) {
      return false;
    }
    for (int i = 0; i < this.octets.length; i++) {
      if (this.octets[i] != localDERApplicationSpecific.octets[i]) {
        return false;
      }
    }
    return true;
  }
  
  public int hashCode()
  {
    byte[] arrayOfByte = getContents();
    int i = 0;
    for (int j = 0; j != arrayOfByte.length; j++) {
      i ^= (arrayOfByte[j] & 0xFF) << j % 4;
    }
    return i ^ getApplicationTag();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERApplicationSpecific.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */