package org.bouncycastle.asn1.microsoft;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface MicrosoftObjectIdentifiers
{
  public static final DERObjectIdentifier microsoft = new DERObjectIdentifier("1.3.6.1.4.1.311");
  public static final DERObjectIdentifier microsoftCertTemplateV1 = new DERObjectIdentifier(microsoft + ".20.2");
  public static final DERObjectIdentifier microsoftCaVersion = new DERObjectIdentifier(microsoft + ".21.1");
  public static final DERObjectIdentifier microsoftPrevCaCertHash = new DERObjectIdentifier(microsoft + ".21.2");
  public static final DERObjectIdentifier microsoftCertTemplateV2 = new DERObjectIdentifier(microsoft + ".21.7");
  public static final DERObjectIdentifier microsoftAppPolicies = new DERObjectIdentifier(microsoft + ".21.10");
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\microsoft\MicrosoftObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */