package org.bouncycastle.asn1.misc;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;

public class IDEACBCPar
  extends ASN1Encodable
{
  ASN1OctetString iv;
  
  public static IDEACBCPar getInstance(Object paramObject)
  {
    if ((paramObject instanceof IDEACBCPar)) {
      return (IDEACBCPar)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new IDEACBCPar((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in IDEACBCPar factory");
  }
  
  public IDEACBCPar(byte[] paramArrayOfByte)
  {
    this.iv = new DEROctetString(paramArrayOfByte);
  }
  
  public IDEACBCPar(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() == 1) {
      this.iv = ((ASN1OctetString)paramASN1Sequence.getObjectAt(0));
    } else {
      this.iv = null;
    }
  }
  
  public byte[] getIV()
  {
    if (this.iv != null) {
      return this.iv.getOctets();
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.iv != null) {
      localASN1EncodableVector.add(this.iv);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\misc\IDEACBCPar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */