package org.bouncycastle.asn1;

import java.io.IOException;

public class DEROctetString
  extends ASN1OctetString
{
  public DEROctetString(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
  
  public DEROctetString(DEREncodable paramDEREncodable)
  {
    super(paramDEREncodable);
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(4, this.string);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DEROctetString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */