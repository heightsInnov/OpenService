package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.util.Strings;
import org.bouncycastle.util.encoders.Hex;

public class X509Name
  extends ASN1Encodable
{
  public static final DERObjectIdentifier C = new DERObjectIdentifier("2.5.4.6");
  public static final DERObjectIdentifier O = new DERObjectIdentifier("2.5.4.10");
  public static final DERObjectIdentifier OU = new DERObjectIdentifier("2.5.4.11");
  public static final DERObjectIdentifier T = new DERObjectIdentifier("2.5.4.12");
  public static final DERObjectIdentifier CN = new DERObjectIdentifier("2.5.4.3");
  public static final DERObjectIdentifier SN = new DERObjectIdentifier("2.5.4.5");
  public static final DERObjectIdentifier STREET = new DERObjectIdentifier("2.5.4.9");
  public static final DERObjectIdentifier SERIALNUMBER = SN;
  public static final DERObjectIdentifier L = new DERObjectIdentifier("2.5.4.7");
  public static final DERObjectIdentifier ST = new DERObjectIdentifier("2.5.4.8");
  public static final DERObjectIdentifier SURNAME = new DERObjectIdentifier("2.5.4.4");
  public static final DERObjectIdentifier GIVENNAME = new DERObjectIdentifier("2.5.4.42");
  public static final DERObjectIdentifier INITIALS = new DERObjectIdentifier("2.5.4.43");
  public static final DERObjectIdentifier GENERATION = new DERObjectIdentifier("2.5.4.44");
  public static final DERObjectIdentifier UNIQUE_IDENTIFIER = new DERObjectIdentifier("2.5.4.45");
  public static final DERObjectIdentifier BUSINESS_CATEGORY = new DERObjectIdentifier("2.5.4.15");
  public static final DERObjectIdentifier POSTAL_CODE = new DERObjectIdentifier("2.5.4.17");
  public static final DERObjectIdentifier DN_QUALIFIER = new DERObjectIdentifier("2.5.4.46");
  public static final DERObjectIdentifier PSEUDONYM = new DERObjectIdentifier("2.5.4.65");
  public static final DERObjectIdentifier DATE_OF_BIRTH = new DERObjectIdentifier("1.3.6.1.5.5.7.9.1");
  public static final DERObjectIdentifier PLACE_OF_BIRTH = new DERObjectIdentifier("1.3.6.1.5.5.7.9.2");
  public static final DERObjectIdentifier GENDER = new DERObjectIdentifier("1.3.6.1.5.5.7.9.3");
  public static final DERObjectIdentifier COUNTRY_OF_CITIZENSHIP = new DERObjectIdentifier("1.3.6.1.5.5.7.9.4");
  public static final DERObjectIdentifier COUNTRY_OF_RESIDENCE = new DERObjectIdentifier("1.3.6.1.5.5.7.9.5");
  public static final DERObjectIdentifier NAME_AT_BIRTH = new DERObjectIdentifier("1.3.36.8.3.14");
  public static final DERObjectIdentifier POSTAL_ADDRESS = new DERObjectIdentifier("2.5.4.16");
  public static final DERObjectIdentifier EmailAddress = PKCSObjectIdentifiers.pkcs_9_at_emailAddress;
  public static final DERObjectIdentifier UnstructuredName = PKCSObjectIdentifiers.pkcs_9_at_unstructuredName;
  public static final DERObjectIdentifier UnstructuredAddress = PKCSObjectIdentifiers.pkcs_9_at_unstructuredAddress;
  public static final DERObjectIdentifier E = EmailAddress;
  public static final DERObjectIdentifier DC = new DERObjectIdentifier("0.9.2342.19200300.100.1.25");
  public static final DERObjectIdentifier UID = new DERObjectIdentifier("0.9.2342.19200300.100.1.1");
  public static Hashtable OIDLookUp = new Hashtable();
  public static boolean DefaultReverse = false;
  public static Hashtable DefaultSymbols = OIDLookUp;
  public static Hashtable RFC2253Symbols = new Hashtable();
  public static Hashtable RFC1779Symbols = new Hashtable();
  public static Hashtable SymbolLookUp = new Hashtable();
  public static Hashtable DefaultLookUp = SymbolLookUp;
  private static final Boolean TRUE = new Boolean(true);
  private static final Boolean FALSE = new Boolean(false);
  private X509NameEntryConverter converter = null;
  private Vector ordering = new Vector();
  private Vector values = new Vector();
  private Vector added = new Vector();
  private ASN1Sequence seq;
  
  public static X509Name getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static X509Name getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof X509Name))) {
      return (X509Name)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new X509Name((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory \"" + paramObject.getClass().getName() + "\"");
  }
  
  public X509Name(ASN1Sequence paramASN1Sequence)
  {
    this.seq = paramASN1Sequence;
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      ASN1Set localASN1Set = ASN1Set.getInstance(localEnumeration.nextElement());
      for (int i = 0; i < localASN1Set.size(); i++)
      {
        ASN1Sequence localASN1Sequence = ASN1Sequence.getInstance(localASN1Set.getObjectAt(i));
        if (localASN1Sequence.size() != 2) {
          throw new IllegalArgumentException("badly sized pair");
        }
        this.ordering.addElement(DERObjectIdentifier.getInstance(localASN1Sequence.getObjectAt(0)));
        DEREncodable localDEREncodable = localASN1Sequence.getObjectAt(1);
        if ((localDEREncodable instanceof DERString)) {
          this.values.addElement(((DERString)localDEREncodable).getString());
        } else {
          this.values.addElement("#" + bytesToString(Hex.encode(localDEREncodable.getDERObject().getDEREncoded())));
        }
        this.added.addElement(i != 0 ? TRUE : FALSE);
      }
    }
  }
  
  /**
   * @deprecated
   */
  public X509Name(Hashtable paramHashtable)
  {
    this(null, paramHashtable);
  }
  
  public X509Name(Vector paramVector, Hashtable paramHashtable)
  {
    this(paramVector, paramHashtable, new X509DefaultEntryConverter());
  }
  
  public X509Name(Vector paramVector, Hashtable paramHashtable, X509NameEntryConverter paramX509NameEntryConverter)
  {
    this.converter = paramX509NameEntryConverter;
    if (paramVector != null)
    {
      for (int i = 0; i != paramVector.size(); i++)
      {
        this.ordering.addElement(paramVector.elementAt(i));
        this.added.addElement(FALSE);
      }
    }
    else
    {
      Enumeration localEnumeration = paramHashtable.keys();
      while (localEnumeration.hasMoreElements())
      {
        this.ordering.addElement(localEnumeration.nextElement());
        this.added.addElement(FALSE);
      }
    }
    for (int j = 0; j != this.ordering.size(); j++)
    {
      DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)this.ordering.elementAt(j);
      if (paramHashtable.get(localDERObjectIdentifier) == null) {
        throw new IllegalArgumentException("No attribute for object id - " + localDERObjectIdentifier.getId() + " - passed to distinguished name");
      }
      this.values.addElement(paramHashtable.get(localDERObjectIdentifier));
    }
  }
  
  public X509Name(Vector paramVector1, Vector paramVector2)
  {
    this(paramVector1, paramVector2, new X509DefaultEntryConverter());
  }
  
  public X509Name(Vector paramVector1, Vector paramVector2, X509NameEntryConverter paramX509NameEntryConverter)
  {
    this.converter = paramX509NameEntryConverter;
    if (paramVector1.size() != paramVector2.size()) {
      throw new IllegalArgumentException("oids vector must be same length as values.");
    }
    for (int i = 0; i < paramVector1.size(); i++)
    {
      this.ordering.addElement(paramVector1.elementAt(i));
      this.values.addElement(paramVector2.elementAt(i));
      this.added.addElement(FALSE);
    }
  }
  
  public X509Name(String paramString)
  {
    this(DefaultReverse, DefaultLookUp, paramString);
  }
  
  public X509Name(String paramString, X509NameEntryConverter paramX509NameEntryConverter)
  {
    this(DefaultReverse, DefaultLookUp, paramString, paramX509NameEntryConverter);
  }
  
  public X509Name(boolean paramBoolean, String paramString)
  {
    this(paramBoolean, DefaultLookUp, paramString);
  }
  
  public X509Name(boolean paramBoolean, String paramString, X509NameEntryConverter paramX509NameEntryConverter)
  {
    this(paramBoolean, DefaultLookUp, paramString, paramX509NameEntryConverter);
  }
  
  public X509Name(boolean paramBoolean, Hashtable paramHashtable, String paramString)
  {
    this(paramBoolean, paramHashtable, paramString, new X509DefaultEntryConverter());
  }
  
  private DERObjectIdentifier decodeOID(String paramString, Hashtable paramHashtable)
  {
    if (Strings.toUpperCase(paramString).startsWith("OID.")) {
      return new DERObjectIdentifier(paramString.substring(4));
    }
    if ((paramString.charAt(0) >= '0') && (paramString.charAt(0) <= '9')) {
      return new DERObjectIdentifier(paramString);
    }
    DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)paramHashtable.get(Strings.toLowerCase(paramString));
    if (localDERObjectIdentifier == null) {
      throw new IllegalArgumentException("Unknown object id - " + paramString + " - passed to distinguished name");
    }
    return localDERObjectIdentifier;
  }
  
  public X509Name(boolean paramBoolean, Hashtable paramHashtable, String paramString, X509NameEntryConverter paramX509NameEntryConverter)
  {
    this.converter = paramX509NameEntryConverter;
    X509NameTokenizer localX509NameTokenizer1 = new X509NameTokenizer(paramString);
    Object localObject1;
    Object localObject2;
    while (localX509NameTokenizer1.hasMoreTokens())
    {
      localObject1 = localX509NameTokenizer1.nextToken();
      int i = ((String)localObject1).indexOf('=');
      if (i == -1) {
        throw new IllegalArgumentException("badly formated directory string");
      }
      localObject2 = ((String)localObject1).substring(0, i);
      String str1 = ((String)localObject1).substring(i + 1);
      DERObjectIdentifier localDERObjectIdentifier = decodeOID((String)localObject2, paramHashtable);
      if (str1.indexOf('+') > 0)
      {
        X509NameTokenizer localX509NameTokenizer2 = new X509NameTokenizer(str1, '+');
        this.ordering.addElement(localDERObjectIdentifier);
        this.values.addElement(localX509NameTokenizer2.nextToken());
        this.added.addElement(FALSE);
        while (localX509NameTokenizer2.hasMoreTokens())
        {
          String str2 = localX509NameTokenizer2.nextToken();
          int m = str2.indexOf('=');
          String str3 = str2.substring(0, m);
          String str4 = str2.substring(m + 1);
          this.ordering.addElement(decodeOID(str3, paramHashtable));
          this.values.addElement(str4);
          this.added.addElement(TRUE);
        }
      }
      else
      {
        this.ordering.addElement(localDERObjectIdentifier);
        this.values.addElement(str1);
        this.added.addElement(FALSE);
      }
    }
    if (paramBoolean)
    {
      localObject1 = new Vector();
      Vector localVector = new Vector();
      localObject2 = new Vector();
      int j = 1;
      for (int k = 0; k < this.ordering.size(); k++) {
        if (((Boolean)this.added.elementAt(k)).booleanValue())
        {
          ((Vector)localObject1).insertElementAt(this.ordering.elementAt(k), j);
          localVector.insertElementAt(this.values.elementAt(k), j);
          ((Vector)localObject2).insertElementAt(this.added.elementAt(k), j);
          j++;
        }
        else
        {
          ((Vector)localObject1).insertElementAt(this.ordering.elementAt(k), 0);
          localVector.insertElementAt(this.values.elementAt(k), 0);
          ((Vector)localObject2).insertElementAt(this.added.elementAt(k), 0);
          j = 1;
        }
      }
      this.ordering = ((Vector)localObject1);
      this.values = localVector;
      this.added = ((Vector)localObject2);
    }
  }
  
  public Vector getOIDs()
  {
    Vector localVector = new Vector();
    for (int i = 0; i != this.ordering.size(); i++) {
      localVector.addElement(this.ordering.elementAt(i));
    }
    return localVector;
  }
  
  public Vector getValues()
  {
    Vector localVector = new Vector();
    for (int i = 0; i != this.values.size(); i++) {
      localVector.addElement(this.values.elementAt(i));
    }
    return localVector;
  }
  
  public Vector getValues(DERObjectIdentifier paramDERObjectIdentifier)
  {
    Vector localVector = new Vector();
    for (int i = 0; i != this.values.size(); i++) {
      if (this.ordering.elementAt(i).equals(paramDERObjectIdentifier)) {
        localVector.addElement(this.values.elementAt(i));
      }
    }
    return localVector;
  }
  
  public DERObject toASN1Object()
  {
    if (this.seq == null)
    {
      ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
      ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
      Object localObject = null;
      for (int i = 0; i != this.ordering.size(); i++)
      {
        ASN1EncodableVector localASN1EncodableVector3 = new ASN1EncodableVector();
        DERObjectIdentifier localDERObjectIdentifier = (DERObjectIdentifier)this.ordering.elementAt(i);
        localASN1EncodableVector3.add(localDERObjectIdentifier);
        String str = (String)this.values.elementAt(i);
        localASN1EncodableVector3.add(this.converter.getConvertedValue(localDERObjectIdentifier, str));
        if ((localObject == null) || (((Boolean)this.added.elementAt(i)).booleanValue()))
        {
          localASN1EncodableVector2.add(new DERSequence(localASN1EncodableVector3));
        }
        else
        {
          localASN1EncodableVector1.add(new DERSet(localASN1EncodableVector2));
          localASN1EncodableVector2 = new ASN1EncodableVector();
          localASN1EncodableVector2.add(new DERSequence(localASN1EncodableVector3));
        }
        localObject = localDERObjectIdentifier;
      }
      localASN1EncodableVector1.add(new DERSet(localASN1EncodableVector2));
      this.seq = new DERSequence(localASN1EncodableVector1);
    }
    return this.seq;
  }
  
  public boolean equals(Object paramObject, boolean paramBoolean)
  {
    if (!paramBoolean) {
      return equals(paramObject);
    }
    if (paramObject == this) {
      return true;
    }
    if ((!(paramObject instanceof X509Name)) && (!(paramObject instanceof ASN1Sequence))) {
      return false;
    }
    DERObject localDERObject = ((DEREncodable)paramObject).getDERObject();
    if (getDERObject().equals(localDERObject)) {
      return true;
    }
    X509Name localX509Name;
    try
    {
      localX509Name = getInstance(paramObject);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      return false;
    }
    int i = this.ordering.size();
    if (i != localX509Name.ordering.size()) {
      return false;
    }
    for (int j = 0; j < i; j++)
    {
      DERObjectIdentifier localDERObjectIdentifier1 = (DERObjectIdentifier)this.ordering.elementAt(j);
      DERObjectIdentifier localDERObjectIdentifier2 = (DERObjectIdentifier)localX509Name.ordering.elementAt(j);
      if (localDERObjectIdentifier1.equals(localDERObjectIdentifier2))
      {
        String str1 = (String)this.values.elementAt(j);
        String str2 = (String)localX509Name.values.elementAt(j);
        if (!equivalentStrings(str1, str2)) {
          return false;
        }
      }
      else
      {
        return false;
      }
    }
    return true;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if ((!(paramObject instanceof X509Name)) && (!(paramObject instanceof ASN1Sequence))) {
      return false;
    }
    DERObject localDERObject = ((DEREncodable)paramObject).getDERObject();
    if (getDERObject().equals(localDERObject)) {
      return true;
    }
    X509Name localX509Name;
    try
    {
      localX509Name = getInstance(paramObject);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      return false;
    }
    int i = this.ordering.size();
    if (i != localX509Name.ordering.size()) {
      return false;
    }
    boolean[] arrayOfBoolean = new boolean[i];
    int j;
    int k;
    int m;
    if (this.ordering.elementAt(0).equals(localX509Name.ordering.elementAt(0)))
    {
      j = 0;
      k = i;
      m = 1;
    }
    else
    {
      j = i - 1;
      k = -1;
      m = -1;
    }
    int n = j;
    while (n != k)
    {
      int i1 = 0;
      DERObjectIdentifier localDERObjectIdentifier1 = (DERObjectIdentifier)this.ordering.elementAt(n);
      String str1 = (String)this.values.elementAt(n);
      for (int i2 = 0; i2 < i; i2++) {
        if (arrayOfBoolean[i2] == 0)
        {
          DERObjectIdentifier localDERObjectIdentifier2 = (DERObjectIdentifier)localX509Name.ordering.elementAt(i2);
          if (localDERObjectIdentifier1.equals(localDERObjectIdentifier2))
          {
            String str2 = (String)localX509Name.values.elementAt(i2);
            if (equivalentStrings(str1, str2))
            {
              arrayOfBoolean[i2] = true;
              i1 = 1;
              break;
            }
          }
        }
      }
      if (i1 == 0) {
        return false;
      }
      n += m;
    }
    return true;
  }
  
  private boolean equivalentStrings(String paramString1, String paramString2)
  {
    String str1 = Strings.toLowerCase(paramString1.trim());
    String str2 = Strings.toLowerCase(paramString2.trim());
    if (!str1.equals(str2))
    {
      str1 = stripInternalSpaces(str1);
      str2 = stripInternalSpaces(str2);
      if (!str1.equals(str2)) {
        return false;
      }
    }
    return true;
  }
  
  private String stripInternalSpaces(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramString.length() != 0)
    {
      char c1 = paramString.charAt(0);
      localStringBuffer.append(c1);
      for (int i = 1; i < paramString.length(); i++)
      {
        char c2 = paramString.charAt(i);
        if ((c1 != ' ') || (c2 != ' ')) {
          localStringBuffer.append(c2);
        }
        c1 = c2;
      }
    }
    return localStringBuffer.toString();
  }
  
  public int hashCode()
  {
    ASN1Sequence localASN1Sequence = (ASN1Sequence)getDERObject();
    Enumeration localEnumeration = localASN1Sequence.getObjects();
    int i = 0;
    while (localEnumeration.hasMoreElements()) {
      i ^= localEnumeration.nextElement().hashCode();
    }
    return i;
  }
  
  private void appendValue(StringBuffer paramStringBuffer, Hashtable paramHashtable, DERObjectIdentifier paramDERObjectIdentifier, String paramString)
  {
    String str = (String)paramHashtable.get(paramDERObjectIdentifier);
    if (str != null) {
      paramStringBuffer.append(str);
    } else {
      paramStringBuffer.append(paramDERObjectIdentifier.getId());
    }
    paramStringBuffer.append('=');
    int i = paramStringBuffer.length();
    paramStringBuffer.append(paramString);
    int j = paramStringBuffer.length();
    while (i != j)
    {
      if ((paramStringBuffer.charAt(i) == ',') || (paramStringBuffer.charAt(i) == '"') || (paramStringBuffer.charAt(i) == '\\') || (paramStringBuffer.charAt(i) == '+') || (paramStringBuffer.charAt(i) == '<') || (paramStringBuffer.charAt(i) == '>') || (paramStringBuffer.charAt(i) == ';'))
      {
        paramStringBuffer.insert(i, "\\");
        i++;
        j++;
      }
      i++;
    }
  }
  
  public String toString(boolean paramBoolean, Hashtable paramHashtable)
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    Vector localVector = new Vector();
    int i = 1;
    StringBuffer localStringBuffer2 = null;
    for (int j = 0; j < this.ordering.size(); j++) {
      if (((Boolean)this.added.elementAt(j)).booleanValue())
      {
        localStringBuffer2.append('+');
        appendValue(localStringBuffer2, paramHashtable, (DERObjectIdentifier)this.ordering.elementAt(j), (String)this.values.elementAt(j));
      }
      else
      {
        localStringBuffer2 = new StringBuffer();
        appendValue(localStringBuffer2, paramHashtable, (DERObjectIdentifier)this.ordering.elementAt(j), (String)this.values.elementAt(j));
        localVector.addElement(localStringBuffer2);
      }
    }
    if (paramBoolean) {
      for (j = localVector.size() - 1; j >= 0; j--)
      {
        if (i != 0) {
          i = 0;
        } else {
          localStringBuffer1.append(',');
        }
        localStringBuffer1.append(localVector.elementAt(j).toString());
      }
    } else {
      for (j = 0; j < localVector.size(); j++)
      {
        if (i != 0) {
          i = 0;
        } else {
          localStringBuffer1.append(',');
        }
        localStringBuffer1.append(localVector.elementAt(j).toString());
      }
    }
    return localStringBuffer1.toString();
  }
  
  private String bytesToString(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    return new String(arrayOfChar);
  }
  
  public String toString()
  {
    return toString(DefaultReverse, DefaultSymbols);
  }
  
  static
  {
    DefaultSymbols.put(C, "C");
    DefaultSymbols.put(O, "O");
    DefaultSymbols.put(T, "T");
    DefaultSymbols.put(OU, "OU");
    DefaultSymbols.put(CN, "CN");
    DefaultSymbols.put(L, "L");
    DefaultSymbols.put(ST, "ST");
    DefaultSymbols.put(SN, "SERIALNUMBER");
    DefaultSymbols.put(EmailAddress, "E");
    DefaultSymbols.put(DC, "DC");
    DefaultSymbols.put(UID, "UID");
    DefaultSymbols.put(STREET, "STREET");
    DefaultSymbols.put(SURNAME, "SURNAME");
    DefaultSymbols.put(GIVENNAME, "GIVENNAME");
    DefaultSymbols.put(INITIALS, "INITIALS");
    DefaultSymbols.put(GENERATION, "GENERATION");
    DefaultSymbols.put(UnstructuredAddress, "unstructuredAddress");
    DefaultSymbols.put(UnstructuredName, "unstructuredName");
    DefaultSymbols.put(UNIQUE_IDENTIFIER, "UniqueIdentifier");
    DefaultSymbols.put(DN_QUALIFIER, "DN");
    DefaultSymbols.put(PSEUDONYM, "Pseudonym");
    DefaultSymbols.put(POSTAL_ADDRESS, "PostalAddress");
    DefaultSymbols.put(NAME_AT_BIRTH, "NameAtBirth");
    DefaultSymbols.put(COUNTRY_OF_CITIZENSHIP, "CountryOfCitizenship");
    DefaultSymbols.put(COUNTRY_OF_RESIDENCE, "CountryOfResidence");
    DefaultSymbols.put(GENDER, "Gender");
    DefaultSymbols.put(PLACE_OF_BIRTH, "PlaceOfBirth");
    DefaultSymbols.put(DATE_OF_BIRTH, "DateOfBirth");
    DefaultSymbols.put(POSTAL_CODE, "PostalCode");
    DefaultSymbols.put(BUSINESS_CATEGORY, "BusinessCategory");
    RFC2253Symbols.put(C, "C");
    RFC2253Symbols.put(O, "O");
    RFC2253Symbols.put(OU, "OU");
    RFC2253Symbols.put(CN, "CN");
    RFC2253Symbols.put(L, "L");
    RFC2253Symbols.put(ST, "ST");
    RFC2253Symbols.put(STREET, "STREET");
    RFC2253Symbols.put(DC, "DC");
    RFC2253Symbols.put(UID, "UID");
    RFC1779Symbols.put(C, "C");
    RFC1779Symbols.put(O, "O");
    RFC1779Symbols.put(OU, "OU");
    RFC1779Symbols.put(CN, "CN");
    RFC1779Symbols.put(L, "L");
    RFC1779Symbols.put(ST, "ST");
    RFC1779Symbols.put(STREET, "STREET");
    DefaultLookUp.put("c", C);
    DefaultLookUp.put("o", O);
    DefaultLookUp.put("t", T);
    DefaultLookUp.put("ou", OU);
    DefaultLookUp.put("cn", CN);
    DefaultLookUp.put("l", L);
    DefaultLookUp.put("st", ST);
    DefaultLookUp.put("sn", SN);
    DefaultLookUp.put("serialnumber", SN);
    DefaultLookUp.put("street", STREET);
    DefaultLookUp.put("emailaddress", E);
    DefaultLookUp.put("dc", DC);
    DefaultLookUp.put("e", E);
    DefaultLookUp.put("uid", UID);
    DefaultLookUp.put("surname", SURNAME);
    DefaultLookUp.put("givenname", GIVENNAME);
    DefaultLookUp.put("initials", INITIALS);
    DefaultLookUp.put("generation", GENERATION);
    DefaultLookUp.put("unstructuredaddress", UnstructuredAddress);
    DefaultLookUp.put("unstructuredname", UnstructuredName);
    DefaultLookUp.put("uniqueidentifier", UNIQUE_IDENTIFIER);
    DefaultLookUp.put("dn", DN_QUALIFIER);
    DefaultLookUp.put("pseudonym", PSEUDONYM);
    DefaultLookUp.put("postaladdress", POSTAL_ADDRESS);
    DefaultLookUp.put("nameofbirth", NAME_AT_BIRTH);
    DefaultLookUp.put("countryofcitizenship", COUNTRY_OF_CITIZENSHIP);
    DefaultLookUp.put("countryofresidence", COUNTRY_OF_RESIDENCE);
    DefaultLookUp.put("gender", GENDER);
    DefaultLookUp.put("placeofbirth", PLACE_OF_BIRTH);
    DefaultLookUp.put("dateofbirth", DATE_OF_BIRTH);
    DefaultLookUp.put("postalcode", POSTAL_CODE);
    DefaultLookUp.put("businesscategory", BUSINESS_CATEGORY);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\X509Name.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */