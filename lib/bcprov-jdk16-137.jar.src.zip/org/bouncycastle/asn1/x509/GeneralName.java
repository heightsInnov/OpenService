package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.util.IPAddress;
import org.bouncycastle.util.Strings;

public class GeneralName
  extends ASN1Encodable
  implements ASN1Choice
{
  public static final int otherName = 0;
  public static final int rfc822Name = 1;
  public static final int dNSName = 2;
  public static final int x400Address = 3;
  public static final int directoryName = 4;
  public static final int ediPartyName = 5;
  public static final int uniformResourceIdentifier = 6;
  public static final int iPAddress = 7;
  public static final int registeredID = 8;
  DEREncodable obj;
  int tag;
  
  public GeneralName(X509Name paramX509Name)
  {
    this.obj = paramX509Name;
    this.tag = 4;
  }
  
  /**
   * @deprecated
   */
  public GeneralName(DERObject paramDERObject, int paramInt)
  {
    this.obj = paramDERObject;
    this.tag = paramInt;
  }
  
  public GeneralName(int paramInt, ASN1Encodable paramASN1Encodable)
  {
    this.obj = paramASN1Encodable;
    this.tag = paramInt;
  }
  
  public GeneralName(int paramInt, String paramString)
  {
    this.tag = paramInt;
    if ((paramInt == 1) || (paramInt == 2) || (paramInt == 6)) {
      this.obj = new DERIA5String(paramString);
    } else if (paramInt == 8) {
      this.obj = new DERObjectIdentifier(paramString);
    } else if (paramInt == 4) {
      this.obj = new X509Name(paramString);
    } else if (paramInt == 7)
    {
      if (IPAddress.isValid(paramString)) {
        this.obj = new DEROctetString(Strings.toUTF8ByteArray(paramString));
      } else {
        throw new IllegalArgumentException("IP Address is invalid");
      }
    }
    else {
      throw new IllegalArgumentException("can't process String for tag: " + paramInt);
    }
  }
  
  public static GeneralName getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof GeneralName))) {
      return (GeneralName)paramObject;
    }
    if ((paramObject instanceof ASN1TaggedObject))
    {
      ASN1TaggedObject localASN1TaggedObject = (ASN1TaggedObject)paramObject;
      int i = localASN1TaggedObject.getTagNo();
      switch (i)
      {
      case 0: 
        return new GeneralName(i, ASN1Sequence.getInstance(localASN1TaggedObject, false));
      case 1: 
        return new GeneralName(i, DERIA5String.getInstance(localASN1TaggedObject, false));
      case 2: 
        return new GeneralName(i, DERIA5String.getInstance(localASN1TaggedObject, false));
      case 3: 
        throw new IllegalArgumentException("unknown tag: " + i);
      case 4: 
        return new GeneralName(i, ASN1Sequence.getInstance(localASN1TaggedObject, true));
      case 5: 
        return new GeneralName(i, ASN1Sequence.getInstance(localASN1TaggedObject, false));
      case 6: 
        return new GeneralName(i, DERIA5String.getInstance(localASN1TaggedObject, false));
      case 7: 
        return new GeneralName(i, ASN1OctetString.getInstance(localASN1TaggedObject, false));
      case 8: 
        return new GeneralName(i, DERObjectIdentifier.getInstance(localASN1TaggedObject, false));
      }
    }
    throw new IllegalArgumentException("unknown object in getInstance");
  }
  
  public static GeneralName getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1TaggedObject.getInstance(paramASN1TaggedObject, true));
  }
  
  public int getTagNo()
  {
    return this.tag;
  }
  
  public DEREncodable getName()
  {
    return this.obj;
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.tag);
    localStringBuffer.append(": ");
    switch (this.tag)
    {
    case 1: 
    case 2: 
    case 6: 
      localStringBuffer.append(DERIA5String.getInstance(this.obj).getString());
      break;
    case 4: 
      localStringBuffer.append(X509Name.getInstance(this.obj).toString());
      break;
    case 3: 
    case 5: 
    default: 
      localStringBuffer.append(this.obj.toString());
    }
    return localStringBuffer.toString();
  }
  
  public DERObject toASN1Object()
  {
    if (this.tag == 4) {
      return new DERTaggedObject(true, this.tag, this.obj);
    }
    return new DERTaggedObject(false, this.tag, this.obj);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\GeneralName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */