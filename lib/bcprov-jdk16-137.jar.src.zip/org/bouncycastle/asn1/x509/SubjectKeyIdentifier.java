package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.digests.SHA1Digest;

public class SubjectKeyIdentifier
  extends ASN1Encodable
{
  private byte[] keyidentifier;
  
  public static SubjectKeyIdentifier getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1OctetString.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static SubjectKeyIdentifier getInstance(Object paramObject)
  {
    if ((paramObject instanceof SubjectKeyIdentifier)) {
      return (SubjectKeyIdentifier)paramObject;
    }
    if ((paramObject instanceof SubjectPublicKeyInfo)) {
      return new SubjectKeyIdentifier((SubjectPublicKeyInfo)paramObject);
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new SubjectKeyIdentifier((ASN1OctetString)paramObject);
    }
    if ((paramObject instanceof X509Extension)) {
      return getInstance(X509Extension.convertValueToObject((X509Extension)paramObject));
    }
    throw new IllegalArgumentException("Invalid SubjectKeyIdentifier: " + paramObject.getClass().getName());
  }
  
  public SubjectKeyIdentifier(byte[] paramArrayOfByte)
  {
    this.keyidentifier = paramArrayOfByte;
  }
  
  public SubjectKeyIdentifier(ASN1OctetString paramASN1OctetString)
  {
    this.keyidentifier = paramASN1OctetString.getOctets();
  }
  
  public SubjectKeyIdentifier(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    SHA1Digest localSHA1Digest = new SHA1Digest();
    byte[] arrayOfByte1 = new byte[localSHA1Digest.getDigestSize()];
    byte[] arrayOfByte2 = paramSubjectPublicKeyInfo.getPublicKeyData().getBytes();
    localSHA1Digest.update(arrayOfByte2, 0, arrayOfByte2.length);
    localSHA1Digest.doFinal(arrayOfByte1, 0);
    this.keyidentifier = arrayOfByte1;
  }
  
  public byte[] getKeyIdentifier()
  {
    return this.keyidentifier;
  }
  
  public DERObject toASN1Object()
  {
    return new DEROctetString(this.keyidentifier);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\SubjectKeyIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */