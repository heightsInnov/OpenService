package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class AccessDescription
  extends ASN1Encodable
{
  public static final DERObjectIdentifier id_ad_caIssuers = new DERObjectIdentifier("1.3.6.1.5.5.7.48.2");
  public static final DERObjectIdentifier id_ad_ocsp = new DERObjectIdentifier("1.3.6.1.5.5.7.48.1");
  DERObjectIdentifier accessMethod = null;
  GeneralName accessLocation = null;
  
  public static AccessDescription getInstance(Object paramObject)
  {
    if ((paramObject instanceof AccessDescription)) {
      return (AccessDescription)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new AccessDescription((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public AccessDescription(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() != 2) {
      throw new IllegalArgumentException("wrong number of elements in inner sequence");
    }
    this.accessMethod = DERObjectIdentifier.getInstance(paramASN1Sequence.getObjectAt(0));
    this.accessLocation = GeneralName.getInstance(paramASN1Sequence.getObjectAt(1));
  }
  
  public AccessDescription(DERObjectIdentifier paramDERObjectIdentifier, GeneralName paramGeneralName)
  {
    this.accessMethod = paramDERObjectIdentifier;
    this.accessLocation = paramGeneralName;
  }
  
  public DERObjectIdentifier getAccessMethod()
  {
    return this.accessMethod;
  }
  
  public GeneralName getAccessLocation()
  {
    return this.accessLocation;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.accessMethod);
    localASN1EncodableVector.add(this.accessLocation);
    return new DERSequence(localASN1EncodableVector);
  }
  
  public String toString()
  {
    return "AccessDescription: Oid(" + this.accessMethod.getId() + ")";
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\AccessDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */