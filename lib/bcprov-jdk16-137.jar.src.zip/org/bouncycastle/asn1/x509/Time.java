package org.bouncycastle.asn1.x509;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.SimpleTimeZone;
import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERUTCTime;

public class Time
  extends ASN1Encodable
  implements ASN1Choice
{
  DERObject time;
  
  public static Time getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public Time(DERObject paramDERObject)
  {
    if ((!(paramDERObject instanceof DERUTCTime)) && (!(paramDERObject instanceof DERGeneralizedTime))) {
      throw new IllegalArgumentException("unknown object passed to Time");
    }
    this.time = paramDERObject;
  }
  
  public Time(Date paramDate)
  {
    SimpleTimeZone localSimpleTimeZone = new SimpleTimeZone(0, "Z");
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    localSimpleDateFormat.setTimeZone(localSimpleTimeZone);
    String str = localSimpleDateFormat.format(paramDate) + "Z";
    int i = Integer.parseInt(str.substring(0, 4));
    if ((i < 1950) || (i > 2049)) {
      this.time = new DERGeneralizedTime(str);
    } else {
      this.time = new DERUTCTime(str.substring(2));
    }
  }
  
  public static Time getInstance(Object paramObject)
  {
    if ((paramObject instanceof Time)) {
      return (Time)paramObject;
    }
    if ((paramObject instanceof DERUTCTime)) {
      return new Time((DERUTCTime)paramObject);
    }
    if ((paramObject instanceof DERGeneralizedTime)) {
      return new Time((DERGeneralizedTime)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public String getTime()
  {
    if ((this.time instanceof DERUTCTime)) {
      return ((DERUTCTime)this.time).getAdjustedTime();
    }
    return ((DERGeneralizedTime)this.time).getTime();
  }
  
  public Date getDate()
  {
    try
    {
      if ((this.time instanceof DERUTCTime)) {
        return ((DERUTCTime)this.time).getAdjustedDate();
      }
      return ((DERGeneralizedTime)this.time).getDate();
    }
    catch (ParseException localParseException)
    {
      throw new IllegalStateException("invalid date string: " + localParseException.getMessage());
    }
  }
  
  public DERObject toASN1Object()
  {
    return this.time;
  }
  
  public String toString()
  {
    return getTime();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\Time.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */