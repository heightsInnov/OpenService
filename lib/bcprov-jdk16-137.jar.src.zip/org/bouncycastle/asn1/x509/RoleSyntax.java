package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.DERTaggedObject;

public class RoleSyntax
  extends ASN1Encodable
{
  private GeneralNames roleAuthority;
  private GeneralName roleName;
  
  public static RoleSyntax getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof RoleSyntax))) {
      return (RoleSyntax)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new RoleSyntax((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Unknown object in RoleSyntax factory.");
  }
  
  public RoleSyntax(GeneralNames paramGeneralNames, GeneralName paramGeneralName)
  {
    if ((paramGeneralName == null) || (paramGeneralName.getTagNo() != 6) || (((DERString)paramGeneralName.getName()).getString().equals(""))) {
      throw new IllegalArgumentException("the role name MUST be non empty and MUST use the URI option of GeneralName");
    }
    this.roleAuthority = paramGeneralNames;
    this.roleName = paramGeneralName;
  }
  
  public RoleSyntax(GeneralName paramGeneralName)
  {
    this(null, paramGeneralName);
  }
  
  public RoleSyntax(String paramString)
  {
    this(new GeneralName(6, paramString == null ? "" : paramString));
  }
  
  public RoleSyntax(ASN1Sequence paramASN1Sequence)
  {
    if ((paramASN1Sequence.size() < 1) || (paramASN1Sequence.size() > 2)) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    for (int i = 0; i != paramASN1Sequence.size(); i++)
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(paramASN1Sequence.getObjectAt(i));
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.roleAuthority = GeneralNames.getInstance(localASN1TaggedObject, false);
        break;
      case 1: 
        this.roleName = GeneralName.getInstance(localASN1TaggedObject, false);
        break;
      default: 
        throw new IllegalArgumentException("Unknown tag in RoleSyntax");
      }
    }
  }
  
  public GeneralNames getRoleAuthority()
  {
    return this.roleAuthority;
  }
  
  public GeneralName getRoleName()
  {
    return this.roleName;
  }
  
  public String getRoleNameAsString()
  {
    DERString localDERString = (DERString)this.roleName.getName();
    return localDERString.getString();
  }
  
  public String[] getRoleAuthorityAsString()
  {
    if (this.roleAuthority == null) {
      return new String[0];
    }
    GeneralName[] arrayOfGeneralName = this.roleAuthority.getNames();
    String[] arrayOfString = new String[arrayOfGeneralName.length];
    for (int i = 0; i < arrayOfGeneralName.length; i++)
    {
      DEREncodable localDEREncodable = arrayOfGeneralName[i].getName();
      if ((localDEREncodable instanceof DERString)) {
        arrayOfString[i] = ((DERString)localDEREncodable).getString();
      } else {
        arrayOfString[i] = localDEREncodable.toString();
      }
    }
    return arrayOfString;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if (this.roleAuthority != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.roleAuthority));
    }
    localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.roleName));
    return new DERSequence(localASN1EncodableVector);
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer("Name: " + getRoleNameAsString() + " - Auth: ");
    if ((this.roleAuthority == null) || (this.roleAuthority.getNames().length == 0))
    {
      localStringBuffer.append("N/A");
    }
    else
    {
      String[] arrayOfString = getRoleAuthorityAsString();
      localStringBuffer.append('[').append(arrayOfString[0]);
      for (int i = 1; i < arrayOfString.length; i++) {
        localStringBuffer.append(", ").append(arrayOfString[i]);
      }
      localStringBuffer.append(']');
    }
    return localStringBuffer.toString();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\RoleSyntax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */