package org.bouncycastle.asn1.x509;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.util.Strings;

public abstract class X509NameEntryConverter
{
  protected DERObject convertHexEncoded(String paramString, int paramInt)
    throws IOException
  {
    paramString = Strings.toLowerCase(paramString);
    byte[] arrayOfByte = new byte[(paramString.length() - paramInt) / 2];
    for (int i = 0; i != arrayOfByte.length; i++)
    {
      int j = paramString.charAt(i * 2 + paramInt);
      int k = paramString.charAt(i * 2 + paramInt + 1);
      if (j < 97) {
        arrayOfByte[i] = ((byte)(j - 48 << 4));
      } else {
        arrayOfByte[i] = ((byte)(j - 97 + 10 << 4));
      }
      if (k < 97)
      {
        int tmp99_97 = i;
        byte[] tmp99_96 = arrayOfByte;
        tmp99_96[tmp99_97] = ((byte)(tmp99_96[tmp99_97] | (byte)(k - 48)));
      }
      else
      {
        int tmp116_114 = i;
        byte[] tmp116_113 = arrayOfByte;
        tmp116_113[tmp116_114] = ((byte)(tmp116_113[tmp116_114] | (byte)(k - 97 + 10)));
      }
    }
    ASN1InputStream localASN1InputStream = new ASN1InputStream(arrayOfByte);
    return localASN1InputStream.readObject();
  }
  
  protected boolean canBePrintable(String paramString)
  {
    return DERPrintableString.isPrintableString(paramString);
  }
  
  public abstract DERObject getConvertedValue(DERObjectIdentifier paramDERObjectIdentifier, String paramString);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\X509NameEntryConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */