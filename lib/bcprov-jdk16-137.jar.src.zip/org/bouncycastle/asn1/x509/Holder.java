package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;

public class Holder
  extends ASN1Encodable
{
  IssuerSerial baseCertificateID;
  GeneralNames entityName;
  ObjectDigestInfo objectDigestInfo;
  private int version = 1;
  
  public static Holder getInstance(Object paramObject)
  {
    if ((paramObject instanceof Holder)) {
      return (Holder)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new Holder((ASN1Sequence)paramObject);
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return new Holder((ASN1TaggedObject)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public Holder(ASN1TaggedObject paramASN1TaggedObject)
  {
    switch (paramASN1TaggedObject.getTagNo())
    {
    case 0: 
      this.baseCertificateID = IssuerSerial.getInstance(paramASN1TaggedObject, false);
      break;
    case 1: 
      this.entityName = GeneralNames.getInstance(paramASN1TaggedObject, false);
      break;
    default: 
      throw new IllegalArgumentException("unknown tag in Holder");
    }
    this.version = 0;
  }
  
  public Holder(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() > 3) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    for (int i = 0; i != paramASN1Sequence.size(); i++)
    {
      ASN1TaggedObject localASN1TaggedObject = ASN1TaggedObject.getInstance(paramASN1Sequence.getObjectAt(i));
      switch (localASN1TaggedObject.getTagNo())
      {
      case 0: 
        this.baseCertificateID = IssuerSerial.getInstance(localASN1TaggedObject, false);
        break;
      case 1: 
        this.entityName = GeneralNames.getInstance(localASN1TaggedObject, false);
        break;
      case 2: 
        this.objectDigestInfo = ObjectDigestInfo.getInstance(localASN1TaggedObject, false);
        break;
      default: 
        throw new IllegalArgumentException("unknown tag in Holder");
      }
    }
    this.version = 1;
  }
  
  public Holder(IssuerSerial paramIssuerSerial)
  {
    this.baseCertificateID = paramIssuerSerial;
  }
  
  public Holder(IssuerSerial paramIssuerSerial, int paramInt)
  {
    this.baseCertificateID = paramIssuerSerial;
    this.version = paramInt;
  }
  
  public int getVersion()
  {
    return this.version;
  }
  
  public Holder(GeneralNames paramGeneralNames)
  {
    this.entityName = paramGeneralNames;
  }
  
  public Holder(GeneralNames paramGeneralNames, int paramInt)
  {
    this.entityName = paramGeneralNames;
    this.version = paramInt;
  }
  
  public Holder(ObjectDigestInfo paramObjectDigestInfo)
  {
    this.objectDigestInfo = paramObjectDigestInfo;
  }
  
  public IssuerSerial getBaseCertificateID()
  {
    return this.baseCertificateID;
  }
  
  public GeneralNames getEntityName()
  {
    return this.entityName;
  }
  
  public ObjectDigestInfo getObjectDigestInfo()
  {
    return this.objectDigestInfo;
  }
  
  public DERObject toASN1Object()
  {
    if (this.version == 1)
    {
      ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
      if (this.baseCertificateID != null) {
        localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.baseCertificateID));
      }
      if (this.entityName != null) {
        localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.entityName));
      }
      if (this.objectDigestInfo != null) {
        localASN1EncodableVector.add(new DERTaggedObject(false, 2, this.objectDigestInfo));
      }
      return new DERSequence(localASN1EncodableVector);
    }
    if (this.entityName != null) {
      return new DERTaggedObject(false, 1, this.entityName);
    }
    return new DERTaggedObject(false, 0, this.baseCertificateID);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\Holder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */