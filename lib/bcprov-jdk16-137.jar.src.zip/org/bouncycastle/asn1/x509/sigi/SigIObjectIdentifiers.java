package org.bouncycastle.asn1.x509.sigi;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface SigIObjectIdentifiers
{
  public static final DERObjectIdentifier id_sigi = new DERObjectIdentifier("1.3.36.8");
  public static final DERObjectIdentifier id_sigi_kp = new DERObjectIdentifier(id_sigi + ".2");
  public static final DERObjectIdentifier id_sigi_cp = new DERObjectIdentifier(id_sigi + ".1");
  public static final DERObjectIdentifier id_sigi_on = new DERObjectIdentifier(id_sigi + ".4");
  public static final DERObjectIdentifier id_sigi_kp_directoryService = new DERObjectIdentifier(id_sigi_kp + ".1");
  public static final DERObjectIdentifier id_sigi_on_personalData = new DERObjectIdentifier(id_sigi_on + ".1");
  public static final DERObjectIdentifier id_sigi_cp_sigconform = new DERObjectIdentifier(id_sigi_cp + ".1");
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\sigi\SigIObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */