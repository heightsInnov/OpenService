package org.bouncycastle.asn1.x509.qualified;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class MonetaryValue
  extends ASN1Encodable
{
  Iso4217CurrencyCode currency;
  DERInteger amount;
  DERInteger exponent;
  
  public static MonetaryValue getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof MonetaryValue))) {
      return (MonetaryValue)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new MonetaryValue(ASN1Sequence.getInstance(paramObject));
    }
    throw new IllegalArgumentException("unknown object in getInstance");
  }
  
  public MonetaryValue(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.currency = Iso4217CurrencyCode.getInstance(localEnumeration.nextElement());
    this.amount = DERInteger.getInstance(localEnumeration.nextElement());
    this.exponent = DERInteger.getInstance(localEnumeration.nextElement());
  }
  
  public MonetaryValue(Iso4217CurrencyCode paramIso4217CurrencyCode, int paramInt1, int paramInt2)
  {
    this.currency = paramIso4217CurrencyCode;
    this.amount = new DERInteger(paramInt1);
    this.exponent = new DERInteger(paramInt2);
  }
  
  public Iso4217CurrencyCode getCurrency()
  {
    return this.currency;
  }
  
  public BigInteger getAmount()
  {
    return this.amount.getValue();
  }
  
  public BigInteger getExponent()
  {
    return this.exponent.getValue();
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.currency);
    localASN1EncodableVector.add(this.amount);
    localASN1EncodableVector.add(this.exponent);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\qualified\MonetaryValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */