package org.bouncycastle.asn1.x509.qualified;

import org.bouncycastle.asn1.DERObjectIdentifier;

public abstract interface RFC3739QCObjectIdentifiers
{
  public static final String id_qcs = "1.3.6.1.5.5.7.11";
  public static final DERObjectIdentifier id_qcs_pkixQCSyntax_v1 = new DERObjectIdentifier("1.3.6.1.5.5.7.11.1");
  public static final DERObjectIdentifier id_qcs_pkixQCSyntax_v2 = new DERObjectIdentifier("1.3.6.1.5.5.7.11.2");
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\qualified\RFC3739QCObjectIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */