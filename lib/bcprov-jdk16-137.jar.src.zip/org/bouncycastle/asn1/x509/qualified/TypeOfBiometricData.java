package org.bouncycastle.asn1.x509.qualified;

import java.math.BigInteger;
import org.bouncycastle.asn1.ASN1Choice;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;

public class TypeOfBiometricData
  extends ASN1Encodable
  implements ASN1Choice
{
  public static final int PICTURE = 0;
  public static final int HANDWRITTEN_SIGNATURE = 1;
  DEREncodable obj;
  
  public static TypeOfBiometricData getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof TypeOfBiometricData))) {
      return (TypeOfBiometricData)paramObject;
    }
    Object localObject;
    if ((paramObject instanceof DERInteger))
    {
      localObject = DERInteger.getInstance(paramObject);
      int i = ((DERInteger)localObject).getValue().intValue();
      return new TypeOfBiometricData(i);
    }
    if ((paramObject instanceof DERObjectIdentifier))
    {
      localObject = DERObjectIdentifier.getInstance(paramObject);
      return new TypeOfBiometricData((DERObjectIdentifier)localObject);
    }
    throw new IllegalArgumentException("unknown object in getInstance");
  }
  
  public TypeOfBiometricData(int paramInt)
  {
    if ((paramInt == 0) || (paramInt == 1)) {
      this.obj = new DERInteger(paramInt);
    } else {
      throw new IllegalArgumentException("unknow PredefinedBiometricType : " + paramInt);
    }
  }
  
  public TypeOfBiometricData(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.obj = paramDERObjectIdentifier;
  }
  
  public boolean isPredefined()
  {
    return this.obj instanceof DERInteger;
  }
  
  public int getPredefinedBiometricType()
  {
    return ((DERInteger)this.obj).getValue().intValue();
  }
  
  public DERObjectIdentifier getBiometricDataOid()
  {
    return (DERObjectIdentifier)this.obj;
  }
  
  public DERObject toASN1Object()
  {
    return this.obj.getDERObject();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\qualified\TypeOfBiometricData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */