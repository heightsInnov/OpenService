package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTCTime;

public class V1TBSCertificateGenerator
{
  DERTaggedObject version = new DERTaggedObject(0, new DERInteger(0));
  DERInteger serialNumber;
  AlgorithmIdentifier signature;
  X509Name issuer;
  Time startDate;
  Time endDate;
  X509Name subject;
  SubjectPublicKeyInfo subjectPublicKeyInfo;
  
  public void setSerialNumber(DERInteger paramDERInteger)
  {
    this.serialNumber = paramDERInteger;
  }
  
  public void setSignature(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    this.signature = paramAlgorithmIdentifier;
  }
  
  public void setIssuer(X509Name paramX509Name)
  {
    this.issuer = paramX509Name;
  }
  
  public void setStartDate(Time paramTime)
  {
    this.startDate = paramTime;
  }
  
  public void setStartDate(DERUTCTime paramDERUTCTime)
  {
    this.startDate = new Time(paramDERUTCTime);
  }
  
  public void setEndDate(Time paramTime)
  {
    this.endDate = paramTime;
  }
  
  public void setEndDate(DERUTCTime paramDERUTCTime)
  {
    this.endDate = new Time(paramDERUTCTime);
  }
  
  public void setSubject(X509Name paramX509Name)
  {
    this.subject = paramX509Name;
  }
  
  public void setSubjectPublicKeyInfo(SubjectPublicKeyInfo paramSubjectPublicKeyInfo)
  {
    this.subjectPublicKeyInfo = paramSubjectPublicKeyInfo;
  }
  
  public TBSCertificateStructure generateTBSCertificate()
  {
    if ((this.serialNumber == null) || (this.signature == null) || (this.issuer == null) || (this.startDate == null) || (this.endDate == null) || (this.subject == null) || (this.subjectPublicKeyInfo == null)) {
      throw new IllegalStateException("not all mandatory fields set in V1 TBScertificate generator");
    }
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    localASN1EncodableVector1.add(this.serialNumber);
    localASN1EncodableVector1.add(this.signature);
    localASN1EncodableVector1.add(this.issuer);
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    localASN1EncodableVector2.add(this.startDate);
    localASN1EncodableVector2.add(this.endDate);
    localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
    localASN1EncodableVector1.add(this.subject);
    localASN1EncodableVector1.add(this.subjectPublicKeyInfo);
    return new TBSCertificateStructure(new DERSequence(localASN1EncodableVector1));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\V1TBSCertificateGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */