package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class Targets
  extends ASN1Encodable
{
  private ASN1Sequence targets;
  
  public static Targets getInstance(Object paramObject)
  {
    if ((paramObject instanceof Targets)) {
      return (Targets)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new Targets((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject.getClass());
  }
  
  private Targets(ASN1Sequence paramASN1Sequence)
  {
    this.targets = paramASN1Sequence;
  }
  
  public Targets(Target[] paramArrayOfTarget)
  {
    this.targets = new DERSequence(paramArrayOfTarget);
  }
  
  public Target[] getTargets()
  {
    Target[] arrayOfTarget = new Target[this.targets.size()];
    int i = 0;
    Enumeration localEnumeration = this.targets.getObjects();
    while (localEnumeration.hasMoreElements()) {
      arrayOfTarget[(i++)] = Target.getInstance(localEnumeration.nextElement());
    }
    return arrayOfTarget;
  }
  
  public DERObject toASN1Object()
  {
    return this.targets;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\Targets.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */