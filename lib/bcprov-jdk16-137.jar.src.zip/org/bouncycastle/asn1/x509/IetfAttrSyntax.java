package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTF8String;

public class IetfAttrSyntax
  extends ASN1Encodable
{
  public static final int VALUE_OCTETS = 1;
  public static final int VALUE_OID = 2;
  public static final int VALUE_UTF8 = 3;
  GeneralNames policyAuthority = null;
  Vector values = new Vector();
  int valueChoice = -1;
  
  public IetfAttrSyntax(ASN1Sequence paramASN1Sequence)
  {
    int i = 0;
    if ((paramASN1Sequence.getObjectAt(0) instanceof ASN1TaggedObject))
    {
      this.policyAuthority = GeneralNames.getInstance((ASN1TaggedObject)paramASN1Sequence.getObjectAt(0), false);
      i++;
    }
    else if (paramASN1Sequence.size() == 2)
    {
      this.policyAuthority = GeneralNames.getInstance(paramASN1Sequence.getObjectAt(0));
      i++;
    }
    if (!(paramASN1Sequence.getObjectAt(i) instanceof ASN1Sequence)) {
      throw new IllegalArgumentException("Non-IetfAttrSyntax encoding");
    }
    paramASN1Sequence = (ASN1Sequence)paramASN1Sequence.getObjectAt(i);
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    while (localEnumeration.hasMoreElements())
    {
      DERObject localDERObject = (DERObject)localEnumeration.nextElement();
      int j;
      if ((localDERObject instanceof DERObjectIdentifier)) {
        j = 2;
      } else if ((localDERObject instanceof DERUTF8String)) {
        j = 3;
      } else if ((localDERObject instanceof DEROctetString)) {
        j = 1;
      } else {
        throw new IllegalArgumentException("Bad value type encoding IetfAttrSyntax");
      }
      if (this.valueChoice < 0) {
        this.valueChoice = j;
      }
      if (j != this.valueChoice) {
        throw new IllegalArgumentException("Mix of value types in IetfAttrSyntax");
      }
      this.values.addElement(localDERObject);
    }
  }
  
  public GeneralNames getPolicyAuthority()
  {
    return this.policyAuthority;
  }
  
  public int getValueType()
  {
    return this.valueChoice;
  }
  
  public Object[] getValues()
  {
    if (getValueType() == 1)
    {
      localObject = new ASN1OctetString[this.values.size()];
      for (i = 0; i != localObject.length; i++) {
        localObject[i] = ((ASN1OctetString)this.values.elementAt(i));
      }
      return (Object[])localObject;
    }
    if (getValueType() == 2)
    {
      localObject = new DERObjectIdentifier[this.values.size()];
      for (i = 0; i != localObject.length; i++) {
        localObject[i] = ((DERObjectIdentifier)this.values.elementAt(i));
      }
      return (Object[])localObject;
    }
    Object localObject = new DERUTF8String[this.values.size()];
    for (int i = 0; i != localObject.length; i++) {
      localObject[i] = ((DERUTF8String)this.values.elementAt(i));
    }
    return (Object[])localObject;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector1 = new ASN1EncodableVector();
    if (this.policyAuthority != null) {
      localASN1EncodableVector1.add(new DERTaggedObject(0, this.policyAuthority));
    }
    ASN1EncodableVector localASN1EncodableVector2 = new ASN1EncodableVector();
    Enumeration localEnumeration = this.values.elements();
    while (localEnumeration.hasMoreElements()) {
      localASN1EncodableVector2.add((ASN1Encodable)localEnumeration.nextElement());
    }
    localASN1EncodableVector1.add(new DERSequence(localASN1EncodableVector2));
    return new DERSequence(localASN1EncodableVector1);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\IetfAttrSyntax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */