package org.bouncycastle.asn1.x509;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DEROutputStream;

public class X509ExtensionsGenerator
{
  private Hashtable extensions = new Hashtable();
  private Vector extOrdering = new Vector();
  
  public void reset()
  {
    this.extensions = new Hashtable();
    this.extOrdering = new Vector();
  }
  
  public void addExtension(DERObjectIdentifier paramDERObjectIdentifier, boolean paramBoolean, DEREncodable paramDEREncodable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    DEROutputStream localDEROutputStream = new DEROutputStream(localByteArrayOutputStream);
    try
    {
      localDEROutputStream.writeObject(paramDEREncodable);
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("error encoding value: " + localIOException);
    }
    addExtension(paramDERObjectIdentifier, paramBoolean, localByteArrayOutputStream.toByteArray());
  }
  
  public void addExtension(DERObjectIdentifier paramDERObjectIdentifier, boolean paramBoolean, byte[] paramArrayOfByte)
  {
    if (this.extensions.containsKey(paramDERObjectIdentifier)) {
      throw new IllegalArgumentException("extension " + paramDERObjectIdentifier + " already added");
    }
    this.extOrdering.addElement(paramDERObjectIdentifier);
    this.extensions.put(paramDERObjectIdentifier, new X509Extension(paramBoolean, new DEROctetString(paramArrayOfByte)));
  }
  
  public boolean isEmpty()
  {
    return this.extOrdering.isEmpty();
  }
  
  public X509Extensions generate()
  {
    return new X509Extensions(this.extOrdering, this.extensions);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\X509ExtensionsGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */