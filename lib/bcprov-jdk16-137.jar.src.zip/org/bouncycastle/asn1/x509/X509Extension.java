package org.bouncycastle.asn1.x509;

import java.io.IOException;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.DERBoolean;

public class X509Extension
{
  boolean critical;
  ASN1OctetString value;
  
  public X509Extension(DERBoolean paramDERBoolean, ASN1OctetString paramASN1OctetString)
  {
    this.critical = paramDERBoolean.isTrue();
    this.value = paramASN1OctetString;
  }
  
  public X509Extension(boolean paramBoolean, ASN1OctetString paramASN1OctetString)
  {
    this.critical = paramBoolean;
    this.value = paramASN1OctetString;
  }
  
  public boolean isCritical()
  {
    return this.critical;
  }
  
  public ASN1OctetString getValue()
  {
    return this.value;
  }
  
  public int hashCode()
  {
    if (isCritical()) {
      return getValue().hashCode();
    }
    return getValue().hashCode() ^ 0xFFFFFFFF;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof X509Extension)) {
      return false;
    }
    X509Extension localX509Extension = (X509Extension)paramObject;
    return (localX509Extension.getValue().equals(getValue())) && (localX509Extension.isCritical() == isCritical());
  }
  
  public static ASN1Object convertValueToObject(X509Extension paramX509Extension)
    throws IllegalArgumentException
  {
    try
    {
      return ASN1Object.fromByteArray(paramX509Extension.getValue().getOctets());
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("can't convert extension: " + localIOException);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\X509Extension.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */