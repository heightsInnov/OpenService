package org.bouncycastle.asn1.x509;

import java.util.Enumeration;
import java.util.Vector;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;

public class NoticeReference
  extends ASN1Encodable
{
  private DisplayText organization;
  private ASN1Sequence noticeNumbers;
  
  public NoticeReference(String paramString, Vector paramVector)
  {
    this.organization = new DisplayText(paramString);
    Object localObject = paramVector.elementAt(0);
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    if ((localObject instanceof Integer))
    {
      Enumeration localEnumeration = paramVector.elements();
      while (localEnumeration.hasMoreElements())
      {
        Integer localInteger = (Integer)localEnumeration.nextElement();
        DERInteger localDERInteger = new DERInteger(localInteger.intValue());
        localASN1EncodableVector.add(localDERInteger);
      }
    }
    this.noticeNumbers = new DERSequence(localASN1EncodableVector);
  }
  
  public NoticeReference(String paramString, ASN1Sequence paramASN1Sequence)
  {
    this.organization = new DisplayText(paramString);
    this.noticeNumbers = paramASN1Sequence;
  }
  
  public NoticeReference(int paramInt, String paramString, ASN1Sequence paramASN1Sequence)
  {
    this.organization = new DisplayText(paramInt, paramString);
    this.noticeNumbers = paramASN1Sequence;
  }
  
  public NoticeReference(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() != 2) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    this.organization = DisplayText.getInstance(paramASN1Sequence.getObjectAt(0));
    this.noticeNumbers = ASN1Sequence.getInstance(paramASN1Sequence.getObjectAt(1));
  }
  
  public static NoticeReference getInstance(Object paramObject)
  {
    if ((paramObject instanceof NoticeReference)) {
      return (NoticeReference)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new NoticeReference((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in getInstance.");
  }
  
  public DisplayText getOrganization()
  {
    return this.organization;
  }
  
  public ASN1Sequence getNoticeNumbers()
  {
    return this.noticeNumbers;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.organization);
    localASN1EncodableVector.add(this.noticeNumbers);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\NoticeReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */