package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DERGeneralizedTime;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;

public class V2AttributeCertificateInfoGenerator
{
  private DERInteger version = new DERInteger(1);
  private Holder holder;
  private AttCertIssuer issuer;
  private AlgorithmIdentifier signature;
  private DERInteger serialNumber;
  private ASN1EncodableVector attributes = new ASN1EncodableVector();
  private DERBitString issuerUniqueID;
  private X509Extensions extensions;
  private DERGeneralizedTime startDate;
  private DERGeneralizedTime endDate;
  
  public void setHolder(Holder paramHolder)
  {
    this.holder = paramHolder;
  }
  
  public void addAttribute(String paramString, ASN1Encodable paramASN1Encodable)
  {
    this.attributes.add(new Attribute(new DERObjectIdentifier(paramString), new DERSet(paramASN1Encodable)));
  }
  
  public void addAttribute(Attribute paramAttribute)
  {
    this.attributes.add(paramAttribute);
  }
  
  public void setSerialNumber(DERInteger paramDERInteger)
  {
    this.serialNumber = paramDERInteger;
  }
  
  public void setSignature(AlgorithmIdentifier paramAlgorithmIdentifier)
  {
    this.signature = paramAlgorithmIdentifier;
  }
  
  public void setIssuer(AttCertIssuer paramAttCertIssuer)
  {
    this.issuer = paramAttCertIssuer;
  }
  
  public void setStartDate(DERGeneralizedTime paramDERGeneralizedTime)
  {
    this.startDate = paramDERGeneralizedTime;
  }
  
  public void setEndDate(DERGeneralizedTime paramDERGeneralizedTime)
  {
    this.endDate = paramDERGeneralizedTime;
  }
  
  public void setIssuerUniqueID(DERBitString paramDERBitString)
  {
    this.issuerUniqueID = paramDERBitString;
  }
  
  public void setExtensions(X509Extensions paramX509Extensions)
  {
    this.extensions = paramX509Extensions;
  }
  
  public AttributeCertificateInfo generateAttributeCertificateInfo()
  {
    if ((this.serialNumber == null) || (this.signature == null) || (this.issuer == null) || (this.startDate == null) || (this.endDate == null) || (this.holder == null) || (this.attributes == null)) {
      throw new IllegalStateException("not all mandatory fields set in V2 AttributeCertificateInfo generator");
    }
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    localASN1EncodableVector.add(this.holder);
    localASN1EncodableVector.add(this.issuer);
    localASN1EncodableVector.add(this.signature);
    localASN1EncodableVector.add(this.serialNumber);
    AttCertValidityPeriod localAttCertValidityPeriod = new AttCertValidityPeriod(this.startDate, this.endDate);
    localASN1EncodableVector.add(localAttCertValidityPeriod);
    localASN1EncodableVector.add(new DERSequence(this.attributes));
    if (this.issuerUniqueID != null) {
      localASN1EncodableVector.add(this.issuerUniqueID);
    }
    if (this.extensions != null) {
      localASN1EncodableVector.add(this.extensions);
    }
    return new AttributeCertificateInfo(new DERSequence(localASN1EncodableVector));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\x509\V2AttributeCertificateInfoGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */