package org.bouncycastle.asn1;

import java.io.IOException;

public class DERBMPString
  extends ASN1Object
  implements DERString
{
  String string;
  
  public static DERBMPString getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERBMPString))) {
      return (DERBMPString)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERBMPString(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERBMPString getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERBMPString(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length / 2];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[(2 * i)] << 8 | paramArrayOfByte[(2 * i + 1)] & 0xFF));
    }
    this.string = new String(arrayOfChar);
  }
  
  public DERBMPString(String paramString)
  {
    this.string = paramString;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public String toString()
  {
    return this.string;
  }
  
  public int hashCode()
  {
    return getString().hashCode();
  }
  
  protected boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERBMPString)) {
      return false;
    }
    DERBMPString localDERBMPString = (DERBMPString)paramDERObject;
    return getString().equals(localDERBMPString.getString());
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    char[] arrayOfChar = this.string.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length * 2];
    for (int i = 0; i != arrayOfChar.length; i++)
    {
      arrayOfByte[(2 * i)] = ((byte)(arrayOfChar[i] >> '\b'));
      arrayOfByte[(2 * i + 1)] = ((byte)arrayOfChar[i]);
    }
    paramDEROutputStream.writeEncoded(30, arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERBMPString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */