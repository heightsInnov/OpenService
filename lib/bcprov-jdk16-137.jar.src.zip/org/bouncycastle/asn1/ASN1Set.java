package org.bouncycastle.asn1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

public abstract class ASN1Set
  extends ASN1Object
{
  protected Vector set = new Vector();
  
  public static ASN1Set getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof ASN1Set))) {
      return (ASN1Set)paramObject;
    }
    throw new IllegalArgumentException("unknown object in getInstance");
  }
  
  public static ASN1Set getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (!paramASN1TaggedObject.isExplicit()) {
        throw new IllegalArgumentException("object implicit - explicit expected.");
      }
      return (ASN1Set)paramASN1TaggedObject.getObject();
    }
    if (paramASN1TaggedObject.isExplicit())
    {
      localObject = new DERSet(paramASN1TaggedObject.getObject());
      return (ASN1Set)localObject;
    }
    if ((paramASN1TaggedObject.getObject() instanceof ASN1Set)) {
      return (ASN1Set)paramASN1TaggedObject.getObject();
    }
    Object localObject = new ASN1EncodableVector();
    if ((paramASN1TaggedObject.getObject() instanceof ASN1Sequence))
    {
      ASN1Sequence localASN1Sequence = (ASN1Sequence)paramASN1TaggedObject.getObject();
      Enumeration localEnumeration = localASN1Sequence.getObjects();
      while (localEnumeration.hasMoreElements()) {
        ((ASN1EncodableVector)localObject).add((DEREncodable)localEnumeration.nextElement());
      }
      return new DERSet((DEREncodableVector)localObject, false);
    }
    throw new IllegalArgumentException("unknown object in getInstanceFromTagged");
  }
  
  public Enumeration getObjects()
  {
    return this.set.elements();
  }
  
  public DEREncodable getObjectAt(int paramInt)
  {
    return (DEREncodable)this.set.elementAt(paramInt);
  }
  
  public int size()
  {
    return this.set.size();
  }
  
  public ASN1SetParser parser()
  {
    final ASN1Set localASN1Set = this;
    new ASN1SetParser()
    {
      private final int max = ASN1Set.this.size();
      private int index;
      
      public DEREncodable readObject()
        throws IOException
      {
        if (this.index == this.max) {
          return null;
        }
        DEREncodable localDEREncodable = ASN1Set.this.getObjectAt(this.index++);
        if ((localDEREncodable instanceof ASN1Sequence)) {
          return ((ASN1Sequence)localDEREncodable).parser();
        }
        if ((localDEREncodable instanceof ASN1Set)) {
          return ((ASN1Set)localDEREncodable).parser();
        }
        return localDEREncodable;
      }
      
      public DERObject getDERObject()
      {
        return localASN1Set;
      }
    };
  }
  
  public int hashCode()
  {
    Enumeration localEnumeration = getObjects();
    int i = 0;
    while (localEnumeration.hasMoreElements()) {
      i ^= localEnumeration.nextElement().hashCode();
    }
    return i;
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof ASN1Set)) {
      return false;
    }
    ASN1Set localASN1Set = (ASN1Set)paramDERObject;
    if (size() != localASN1Set.size()) {
      return false;
    }
    Enumeration localEnumeration1 = getObjects();
    Enumeration localEnumeration2 = localASN1Set.getObjects();
    while (localEnumeration1.hasMoreElements())
    {
      DERObject localDERObject1 = ((DEREncodable)localEnumeration1.nextElement()).getDERObject();
      DERObject localDERObject2 = ((DEREncodable)localEnumeration2.nextElement()).getDERObject();
      if ((localDERObject1 != localDERObject2) && ((localDERObject1 == null) || (!localDERObject1.equals(localDERObject2)))) {
        return false;
      }
    }
    return true;
  }
  
  private boolean lessThanOrEqual(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    int j;
    int k;
    if (paramArrayOfByte1.length <= paramArrayOfByte2.length)
    {
      for (i = 0; i != paramArrayOfByte1.length; i++)
      {
        j = paramArrayOfByte1[i] & 0xFF;
        k = paramArrayOfByte2[i] & 0xFF;
        if (k > j) {
          return true;
        }
        if (j > k) {
          return false;
        }
      }
      return true;
    }
    for (int i = 0; i != paramArrayOfByte2.length; i++)
    {
      j = paramArrayOfByte1[i] & 0xFF;
      k = paramArrayOfByte2[i] & 0xFF;
      if (k > j) {
        return true;
      }
      if (j > k) {
        return false;
      }
    }
    return false;
  }
  
  private byte[] getEncoded(DEREncodable paramDEREncodable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    ASN1OutputStream localASN1OutputStream = new ASN1OutputStream(localByteArrayOutputStream);
    try
    {
      localASN1OutputStream.writeObject(paramDEREncodable);
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("cannot encode object added to SET");
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  protected void sort()
  {
    if (this.set.size() > 1)
    {
      int i = 1;
      while (i != 0)
      {
        int j = 0;
        Object localObject1 = getEncoded((DEREncodable)this.set.elementAt(0));
        i = 0;
        while (j != this.set.size() - 1)
        {
          byte[] arrayOfByte = getEncoded((DEREncodable)this.set.elementAt(j + 1));
          if (lessThanOrEqual((byte[])localObject1, arrayOfByte))
          {
            localObject1 = arrayOfByte;
          }
          else
          {
            Object localObject2 = this.set.elementAt(j);
            this.set.setElementAt(this.set.elementAt(j + 1), j);
            this.set.setElementAt(localObject2, j + 1);
            i = 1;
          }
          j++;
        }
      }
    }
  }
  
  protected void addObject(DEREncodable paramDEREncodable)
  {
    this.set.addElement(paramDEREncodable);
  }
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  public String toString()
  {
    return this.set.toString();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1Set.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */