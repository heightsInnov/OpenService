package org.bouncycastle.asn1;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class DEROutputStream
  extends FilterOutputStream
  implements DERTags
{
  public DEROutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  private void writeLength(int paramInt)
    throws IOException
  {
    if (paramInt > 127)
    {
      int i = 1;
      int j = paramInt;
      while (j >>>= 8 != 0) {
        i++;
      }
      write((byte)(i | 0x80));
      for (int k = (i - 1) * 8; k >= 0; k -= 8) {
        write((byte)(paramInt >> k));
      }
    }
    else
    {
      write((byte)paramInt);
    }
  }
  
  void writeEncoded(int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramInt);
    writeLength(paramArrayOfByte.length);
    write(paramArrayOfByte);
  }
  
  protected void writeNull()
    throws IOException
  {
    write(5);
    write(0);
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    this.out.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.out.write(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public void writeObject(Object paramObject)
    throws IOException
  {
    if (paramObject == null) {
      writeNull();
    } else if ((paramObject instanceof DERObject)) {
      ((DERObject)paramObject).encode(this);
    } else if ((paramObject instanceof DEREncodable)) {
      ((DEREncodable)paramObject).getDERObject().encode(this);
    } else {
      throw new IOException("object not DEREncodable");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DEROutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */