package org.bouncycastle.asn1;

import java.io.IOException;

public abstract class ASN1Object
  extends DERObject
{
  public static ASN1Object fromByteArray(byte[] paramArrayOfByte)
    throws IOException
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    return (ASN1Object)localASN1InputStream.readObject();
  }
  
  public final boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    return ((paramObject instanceof DEREncodable)) && (asn1Equals(((DEREncodable)paramObject).getDERObject()));
  }
  
  public abstract int hashCode();
  
  abstract void encode(DEROutputStream paramDEROutputStream)
    throws IOException;
  
  abstract boolean asn1Equals(DERObject paramDERObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\ASN1Object.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */