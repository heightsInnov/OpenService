package org.bouncycastle.asn1.isismtt.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.x500.DirectoryString;

public class Restriction
  extends ASN1Encodable
{
  private DirectoryString restriction;
  
  public static Restriction getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof Restriction))) {
      return (Restriction)paramObject;
    }
    if ((paramObject instanceof DERString)) {
      return new Restriction(DirectoryString.getInstance(paramObject));
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private Restriction(DirectoryString paramDirectoryString)
  {
    this.restriction = paramDirectoryString;
  }
  
  public Restriction(String paramString)
  {
    this.restriction = new DirectoryString(paramString);
  }
  
  public DirectoryString getRestriction()
  {
    return this.restriction;
  }
  
  public DERObject toASN1Object()
  {
    return this.restriction.toASN1Object();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\isismtt\x509\Restriction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */