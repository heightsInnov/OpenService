package org.bouncycastle.asn1.isismtt.x509;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERString;
import org.bouncycastle.asn1.x500.DirectoryString;

public class AdditionalInformationSyntax
  extends ASN1Encodable
{
  private DirectoryString information;
  
  public static AdditionalInformationSyntax getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof AdditionalInformationSyntax))) {
      return (AdditionalInformationSyntax)paramObject;
    }
    if ((paramObject instanceof DERString)) {
      return new AdditionalInformationSyntax(DirectoryString.getInstance(paramObject));
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  private AdditionalInformationSyntax(DirectoryString paramDirectoryString)
  {
    this.information = paramDirectoryString;
  }
  
  public AdditionalInformationSyntax(String paramString)
  {
    this(new DirectoryString(paramString));
  }
  
  public DirectoryString getInformation()
  {
    return this.information;
  }
  
  public DERObject toASN1Object()
  {
    return this.information.toASN1Object();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\isismtt\x509\AdditionalInformationSyntax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */