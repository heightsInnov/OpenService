package org.bouncycastle.asn1.isismtt.x509;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERPrintableString;
import org.bouncycastle.asn1.DERSequence;

public class MonetaryLimit
  extends ASN1Encodable
{
  DERPrintableString currency;
  DERInteger amount;
  DERInteger exponent;
  
  public static MonetaryLimit getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof MonetaryLimit))) {
      return (MonetaryLimit)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new MonetaryLimit(ASN1Sequence.getInstance(paramObject));
    }
    throw new IllegalArgumentException("unknown object in getInstance");
  }
  
  private MonetaryLimit(ASN1Sequence paramASN1Sequence)
  {
    if (paramASN1Sequence.size() != 3) {
      throw new IllegalArgumentException("Bad sequence size: " + paramASN1Sequence.size());
    }
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.currency = DERPrintableString.getInstance(localEnumeration.nextElement());
    this.amount = DERInteger.getInstance(localEnumeration.nextElement());
    this.exponent = DERInteger.getInstance(localEnumeration.nextElement());
  }
  
  public MonetaryLimit(String paramString, int paramInt1, int paramInt2)
  {
    this.currency = new DERPrintableString(paramString, true);
    this.amount = new DERInteger(paramInt1);
    this.exponent = new DERInteger(paramInt2);
  }
  
  public String getCurrency()
  {
    return this.currency.getString();
  }
  
  public BigInteger getAmount()
  {
    return this.amount.getValue();
  }
  
  public BigInteger getExponent()
  {
    return this.exponent.getValue();
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.currency);
    localASN1EncodableVector.add(this.amount);
    localASN1EncodableVector.add(this.exponent);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\isismtt\x509\MonetaryLimit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */