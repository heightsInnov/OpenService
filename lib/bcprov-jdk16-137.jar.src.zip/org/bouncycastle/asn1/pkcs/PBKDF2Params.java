package org.bouncycastle.asn1.pkcs;

import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;

public class PBKDF2Params
  extends ASN1Encodable
{
  ASN1OctetString octStr;
  DERInteger iterationCount;
  DERInteger keyLength;
  
  public static PBKDF2Params getInstance(Object paramObject)
  {
    if ((paramObject instanceof PBKDF2Params)) {
      return (PBKDF2Params)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PBKDF2Params((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public PBKDF2Params(byte[] paramArrayOfByte, int paramInt)
  {
    this.octStr = new DEROctetString(paramArrayOfByte);
    this.iterationCount = new DERInteger(paramInt);
  }
  
  public PBKDF2Params(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.octStr = ((ASN1OctetString)localEnumeration.nextElement());
    this.iterationCount = ((DERInteger)localEnumeration.nextElement());
    if (localEnumeration.hasMoreElements()) {
      this.keyLength = ((DERInteger)localEnumeration.nextElement());
    } else {
      this.keyLength = null;
    }
  }
  
  public byte[] getSalt()
  {
    return this.octStr.getOctets();
  }
  
  public BigInteger getIterationCount()
  {
    return this.iterationCount.getValue();
  }
  
  public BigInteger getKeyLength()
  {
    if (this.keyLength != null) {
      return this.keyLength.getValue();
    }
    return null;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.octStr);
    localASN1EncodableVector.add(this.iterationCount);
    if (this.keyLength != null) {
      localASN1EncodableVector.add(this.keyLength);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\pkcs\PBKDF2Params.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */