package org.bouncycastle.asn1.pkcs;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class PrivateKeyInfo
  extends ASN1Encodable
{
  private DERObject privKey;
  private AlgorithmIdentifier algId;
  private ASN1Set attributes;
  
  public static PrivateKeyInfo getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(ASN1Sequence.getInstance(paramASN1TaggedObject, paramBoolean));
  }
  
  public static PrivateKeyInfo getInstance(Object paramObject)
  {
    if ((paramObject instanceof PrivateKeyInfo)) {
      return (PrivateKeyInfo)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new PrivateKeyInfo((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory");
  }
  
  public PrivateKeyInfo(AlgorithmIdentifier paramAlgorithmIdentifier, DERObject paramDERObject)
  {
    this(paramAlgorithmIdentifier, paramDERObject, null);
  }
  
  public PrivateKeyInfo(AlgorithmIdentifier paramAlgorithmIdentifier, DERObject paramDERObject, ASN1Set paramASN1Set)
  {
    this.privKey = paramDERObject;
    this.algId = paramAlgorithmIdentifier;
    this.attributes = paramASN1Set;
  }
  
  public PrivateKeyInfo(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    BigInteger localBigInteger = ((DERInteger)localEnumeration.nextElement()).getValue();
    if (localBigInteger.intValue() != 0) {
      throw new IllegalArgumentException("wrong version for private key info");
    }
    this.algId = new AlgorithmIdentifier((ASN1Sequence)localEnumeration.nextElement());
    try
    {
      ASN1InputStream localASN1InputStream = new ASN1InputStream(((ASN1OctetString)localEnumeration.nextElement()).getOctets());
      this.privKey = localASN1InputStream.readObject();
    }
    catch (IOException localIOException)
    {
      throw new IllegalArgumentException("Error recoverying private key from sequence");
    }
    if (localEnumeration.hasMoreElements()) {
      this.attributes = ASN1Set.getInstance((ASN1TaggedObject)localEnumeration.nextElement(), false);
    }
  }
  
  public AlgorithmIdentifier getAlgorithmId()
  {
    return this.algId;
  }
  
  public DERObject getPrivateKey()
  {
    return this.privKey;
  }
  
  public ASN1Set getAttributes()
  {
    return this.attributes;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(new DERInteger(0));
    localASN1EncodableVector.add(this.algId);
    localASN1EncodableVector.add(new DEROctetString(this.privKey));
    if (this.attributes != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.attributes));
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\pkcs\PrivateKeyInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */