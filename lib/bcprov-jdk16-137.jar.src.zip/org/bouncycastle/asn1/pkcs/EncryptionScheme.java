package org.bouncycastle.asn1.pkcs;

import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;

public class EncryptionScheme
  extends AlgorithmIdentifier
{
  DERObject objectId;
  DERObject obj;
  
  EncryptionScheme(ASN1Sequence paramASN1Sequence)
  {
    super(paramASN1Sequence);
    this.objectId = ((DERObject)paramASN1Sequence.getObjectAt(0));
    this.obj = ((DERObject)paramASN1Sequence.getObjectAt(1));
  }
  
  public DERObject getObject()
  {
    return this.obj;
  }
  
  public DERObject getDERObject()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.objectId);
    localASN1EncodableVector.add(this.obj);
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\pkcs\EncryptionScheme.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */