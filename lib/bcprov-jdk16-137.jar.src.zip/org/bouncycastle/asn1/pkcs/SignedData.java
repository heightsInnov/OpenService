package org.bouncycastle.asn1.pkcs;

import java.util.Enumeration;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.BERSequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERTaggedObject;

public class SignedData
  extends ASN1Encodable
  implements PKCSObjectIdentifiers
{
  private DERInteger version;
  private ASN1Set digestAlgorithms;
  private ContentInfo contentInfo;
  private ASN1Set certificates;
  private ASN1Set crls;
  private ASN1Set signerInfos;
  
  public static SignedData getInstance(Object paramObject)
  {
    if ((paramObject instanceof SignedData)) {
      return (SignedData)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SignedData((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("unknown object in factory: " + paramObject);
  }
  
  public SignedData(DERInteger paramDERInteger, ASN1Set paramASN1Set1, ContentInfo paramContentInfo, ASN1Set paramASN1Set2, ASN1Set paramASN1Set3, ASN1Set paramASN1Set4)
  {
    this.version = paramDERInteger;
    this.digestAlgorithms = paramASN1Set1;
    this.contentInfo = paramContentInfo;
    this.certificates = paramASN1Set2;
    this.crls = paramASN1Set3;
    this.signerInfos = paramASN1Set4;
  }
  
  public SignedData(ASN1Sequence paramASN1Sequence)
  {
    Enumeration localEnumeration = paramASN1Sequence.getObjects();
    this.version = ((DERInteger)localEnumeration.nextElement());
    this.digestAlgorithms = ((ASN1Set)localEnumeration.nextElement());
    this.contentInfo = ContentInfo.getInstance(localEnumeration.nextElement());
    while (localEnumeration.hasMoreElements())
    {
      DERObject localDERObject = (DERObject)localEnumeration.nextElement();
      if ((localDERObject instanceof DERTaggedObject))
      {
        DERTaggedObject localDERTaggedObject = (DERTaggedObject)localDERObject;
        switch (localDERTaggedObject.getTagNo())
        {
        case 0: 
          this.certificates = ASN1Set.getInstance(localDERTaggedObject, false);
          break;
        case 1: 
          this.crls = ASN1Set.getInstance(localDERTaggedObject, false);
          break;
        default: 
          throw new IllegalArgumentException("unknown tag value " + localDERTaggedObject.getTagNo());
        }
      }
      else
      {
        this.signerInfos = ((ASN1Set)localDERObject);
      }
    }
  }
  
  public DERInteger getVersion()
  {
    return this.version;
  }
  
  public ASN1Set getDigestAlgorithms()
  {
    return this.digestAlgorithms;
  }
  
  public ContentInfo getContentInfo()
  {
    return this.contentInfo;
  }
  
  public ASN1Set getCertificates()
  {
    return this.certificates;
  }
  
  public ASN1Set getCRLs()
  {
    return this.crls;
  }
  
  public ASN1Set getSignerInfos()
  {
    return this.signerInfos;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.version);
    localASN1EncodableVector.add(this.digestAlgorithms);
    localASN1EncodableVector.add(this.contentInfo);
    if (this.certificates != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 0, this.certificates));
    }
    if (this.crls != null) {
      localASN1EncodableVector.add(new DERTaggedObject(false, 1, this.crls));
    }
    localASN1EncodableVector.add(this.signerInfos);
    return new BERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\pkcs\SignedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */