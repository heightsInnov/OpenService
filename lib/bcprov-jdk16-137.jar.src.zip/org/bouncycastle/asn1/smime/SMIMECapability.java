package org.bouncycastle.asn1.smime;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERObject;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;

public class SMIMECapability
  extends ASN1Encodable
{
  public static final DERObjectIdentifier preferSignedData = PKCSObjectIdentifiers.preferSignedData;
  public static final DERObjectIdentifier canNotDecryptAny = PKCSObjectIdentifiers.canNotDecryptAny;
  public static final DERObjectIdentifier sMIMECapabilitiesVersions = PKCSObjectIdentifiers.sMIMECapabilitiesVersions;
  public static final DERObjectIdentifier dES_CBC = new DERObjectIdentifier("1.3.14.3.2.7");
  public static final DERObjectIdentifier dES_EDE3_CBC = PKCSObjectIdentifiers.des_EDE3_CBC;
  public static final DERObjectIdentifier rC2_CBC = PKCSObjectIdentifiers.RC2_CBC;
  public static final DERObjectIdentifier aES128_CBC = NISTObjectIdentifiers.id_aes128_CBC;
  public static final DERObjectIdentifier aES192_CBC = NISTObjectIdentifiers.id_aes192_CBC;
  public static final DERObjectIdentifier aES256_CBC = NISTObjectIdentifiers.id_aes256_CBC;
  private DERObjectIdentifier capabilityID;
  private DEREncodable parameters;
  
  public SMIMECapability(ASN1Sequence paramASN1Sequence)
  {
    this.capabilityID = ((DERObjectIdentifier)paramASN1Sequence.getObjectAt(0));
    if (paramASN1Sequence.size() > 1) {
      this.parameters = ((DERObject)paramASN1Sequence.getObjectAt(1));
    }
  }
  
  public SMIMECapability(DERObjectIdentifier paramDERObjectIdentifier, DEREncodable paramDEREncodable)
  {
    this.capabilityID = paramDERObjectIdentifier;
    this.parameters = paramDEREncodable;
  }
  
  public static SMIMECapability getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof SMIMECapability))) {
      return (SMIMECapability)paramObject;
    }
    if ((paramObject instanceof ASN1Sequence)) {
      return new SMIMECapability((ASN1Sequence)paramObject);
    }
    throw new IllegalArgumentException("Invalid SMIMECapability");
  }
  
  public DERObjectIdentifier getCapabilityID()
  {
    return this.capabilityID;
  }
  
  public DEREncodable getParameters()
  {
    return this.parameters;
  }
  
  public DERObject toASN1Object()
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(this.capabilityID);
    if (this.parameters != null) {
      localASN1EncodableVector.add(this.parameters);
    }
    return new DERSequence(localASN1EncodableVector);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\smime\SMIMECapability.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */