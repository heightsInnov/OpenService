package org.bouncycastle.asn1.smime;

import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.cms.Attribute;

public class SMIMECapabilitiesAttribute
  extends Attribute
{
  public SMIMECapabilitiesAttribute(SMIMECapabilityVector paramSMIMECapabilityVector)
  {
    super(SMIMEAttributes.smimeCapabilities, new DERSet(new DERSequence(paramSMIMECapabilityVector.toDEREncodableVector())));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\smime\SMIMECapabilitiesAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */