package org.bouncycastle.asn1.smime;

import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DEREncodableVector;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DERSequence;

public class SMIMECapabilityVector
{
  private ASN1EncodableVector capabilities = new ASN1EncodableVector();
  
  public void addCapability(DERObjectIdentifier paramDERObjectIdentifier)
  {
    this.capabilities.add(new DERSequence(paramDERObjectIdentifier));
  }
  
  public void addCapability(DERObjectIdentifier paramDERObjectIdentifier, int paramInt)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(paramDERObjectIdentifier);
    localASN1EncodableVector.add(new DERInteger(paramInt));
    this.capabilities.add(new DERSequence(localASN1EncodableVector));
  }
  
  public void addCapability(DERObjectIdentifier paramDERObjectIdentifier, DEREncodable paramDEREncodable)
  {
    ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
    localASN1EncodableVector.add(paramDERObjectIdentifier);
    localASN1EncodableVector.add(paramDEREncodable);
    this.capabilities.add(new DERSequence(localASN1EncodableVector));
  }
  
  public DEREncodableVector toDEREncodableVector()
  {
    return this.capabilities;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\smime\SMIMECapabilityVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */