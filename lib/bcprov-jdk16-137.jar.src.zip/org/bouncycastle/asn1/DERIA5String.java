package org.bouncycastle.asn1;

import java.io.IOException;

public class DERIA5String
  extends ASN1Object
  implements DERString
{
  String string;
  
  public static DERIA5String getInstance(Object paramObject)
  {
    if ((paramObject == null) || ((paramObject instanceof DERIA5String))) {
      return (DERIA5String)paramObject;
    }
    if ((paramObject instanceof ASN1OctetString)) {
      return new DERIA5String(((ASN1OctetString)paramObject).getOctets());
    }
    if ((paramObject instanceof ASN1TaggedObject)) {
      return getInstance(((ASN1TaggedObject)paramObject).getObject());
    }
    throw new IllegalArgumentException("illegal object in getInstance: " + paramObject.getClass().getName());
  }
  
  public static DERIA5String getInstance(ASN1TaggedObject paramASN1TaggedObject, boolean paramBoolean)
  {
    return getInstance(paramASN1TaggedObject.getObject());
  }
  
  public DERIA5String(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(paramArrayOfByte[i] & 0xFF));
    }
    this.string = new String(arrayOfChar);
  }
  
  public DERIA5String(String paramString)
  {
    this(paramString, false);
  }
  
  public DERIA5String(String paramString, boolean paramBoolean)
  {
    if ((paramBoolean) && (!isIA5String(paramString))) {
      throw new IllegalArgumentException("string contains illegal characters");
    }
    this.string = paramString;
  }
  
  public String getString()
  {
    return this.string;
  }
  
  public String toString()
  {
    return this.string;
  }
  
  public byte[] getOctets()
  {
    char[] arrayOfChar = this.string.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  void encode(DEROutputStream paramDEROutputStream)
    throws IOException
  {
    paramDEROutputStream.writeEncoded(22, getOctets());
  }
  
  public int hashCode()
  {
    return getString().hashCode();
  }
  
  boolean asn1Equals(DERObject paramDERObject)
  {
    if (!(paramDERObject instanceof DERIA5String)) {
      return false;
    }
    DERIA5String localDERIA5String = (DERIA5String)paramDERObject;
    return getString().equals(localDERIA5String.getString());
  }
  
  public static boolean isIA5String(String paramString)
  {
    for (int i = paramString.length() - 1; i >= 0; i--)
    {
      int j = paramString.charAt(i);
      if (j > 127) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcprov-jdk16-137.jar!\org\bouncycastle\asn1\DERIA5String.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */