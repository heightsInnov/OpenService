package org.apache.log4j.or;

public abstract interface ObjectRenderer
{
  public abstract String doRender(Object paramObject);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\log4j-1.2.15.jar!\org\apache\log4j\or\ObjectRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */