package org.apache.log4j.lf5;

public abstract interface LogRecordFilter
{
  public abstract boolean passes(LogRecord paramLogRecord);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\log4j-1.2.15.jar!\org\apache\log4j\lf5\LogRecordFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */