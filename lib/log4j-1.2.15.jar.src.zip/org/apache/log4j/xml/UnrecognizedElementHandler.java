package org.apache.log4j.xml;

import java.util.Properties;
import org.w3c.dom.Element;

public abstract interface UnrecognizedElementHandler
{
  public abstract boolean parseUnrecognizedElement(Element paramElement, Properties paramProperties)
    throws Exception;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\log4j-1.2.15.jar!\org\apache\log4j\xml\UnrecognizedElementHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */