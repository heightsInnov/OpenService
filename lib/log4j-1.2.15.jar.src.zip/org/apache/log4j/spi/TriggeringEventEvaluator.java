package org.apache.log4j.spi;

public abstract interface TriggeringEventEvaluator
{
  public abstract boolean isTriggeringEvent(LoggingEvent paramLoggingEvent);
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\log4j-1.2.15.jar!\org\apache\log4j\spi\TriggeringEventEvaluator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */