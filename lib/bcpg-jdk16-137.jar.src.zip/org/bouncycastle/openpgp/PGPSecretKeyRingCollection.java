package org.bouncycastle.openpgp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.bcpg.BCPGOutputStream;

public class PGPSecretKeyRingCollection
{
  private Map secretRings = new HashMap();
  private List order = new ArrayList();
  
  private PGPSecretKeyRingCollection(Map paramMap, List paramList)
  {
    this.secretRings = paramMap;
    this.order = paramList;
  }
  
  public PGPSecretKeyRingCollection(byte[] paramArrayOfByte)
    throws IOException, PGPException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public PGPSecretKeyRingCollection(InputStream paramInputStream)
    throws IOException, PGPException
  {
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramInputStream);
    Object localObject;
    while ((localObject = localPGPObjectFactory.nextObject()) != null)
    {
      if (!(localObject instanceof PGPSecretKeyRing)) {
        throw new PGPException(localObject.getClass().getName() + " found where PGPSecretKeyRing expected");
      }
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localObject;
      Long localLong = new Long(localPGPSecretKeyRing.getPublicKey().getKeyID());
      this.secretRings.put(localLong, localPGPSecretKeyRing);
      this.order.add(localLong);
    }
  }
  
  public PGPSecretKeyRingCollection(Collection paramCollection)
    throws IOException, PGPException
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator.next();
      Long localLong = new Long(localPGPSecretKeyRing.getPublicKey().getKeyID());
      this.secretRings.put(localLong, localPGPSecretKeyRing);
      this.order.add(localLong);
    }
  }
  
  public int size()
  {
    return this.order.size();
  }
  
  public Iterator getKeyRings()
  {
    return this.secretRings.values().iterator();
  }
  
  public Iterator getKeyRings(String paramString, boolean paramBoolean)
    throws PGPException
  {
    Iterator localIterator1 = getKeyRings();
    ArrayList localArrayList = new ArrayList();
    while (localIterator1.hasNext())
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPSecretKeyRing.getSecretKey().getUserIDs();
      while (localIterator2.hasNext()) {
        if (paramBoolean)
        {
          if (((String)localIterator2.next()).indexOf(paramString) > -1) {
            localArrayList.add(localPGPSecretKeyRing);
          }
        }
        else if (localIterator2.next().equals(paramString)) {
          localArrayList.add(localPGPSecretKeyRing);
        }
      }
    }
    return localArrayList.iterator();
  }
  
  public Iterator getKeyRings(String paramString)
    throws PGPException
  {
    return getKeyRings(paramString, false);
  }
  
  public PGPSecretKey getSecretKey(long paramLong)
    throws PGPException
  {
    Iterator localIterator = getKeyRings();
    while (localIterator.hasNext())
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator.next();
      PGPSecretKey localPGPSecretKey = localPGPSecretKeyRing.getSecretKey(paramLong);
      if (localPGPSecretKey != null) {
        return localPGPSecretKey;
      }
    }
    return null;
  }
  
  public PGPSecretKeyRing getSecretKeyRing(long paramLong)
    throws PGPException
  {
    Long localLong = new Long(paramLong);
    if (this.secretRings.containsKey(localLong)) {
      return (PGPSecretKeyRing)this.secretRings.get(localLong);
    }
    Iterator localIterator = getKeyRings();
    while (localIterator.hasNext())
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator.next();
      PGPSecretKey localPGPSecretKey = localPGPSecretKeyRing.getSecretKey(paramLong);
      if (localPGPSecretKey != null) {
        return localPGPSecretKeyRing;
      }
    }
    return null;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    Iterator localIterator = this.order.iterator();
    while (localIterator.hasNext())
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)this.secretRings.get(localIterator.next());
      localPGPSecretKeyRing.encode(localBCPGOutputStream);
    }
  }
  
  public static PGPSecretKeyRingCollection addSecretKeyRing(PGPSecretKeyRingCollection paramPGPSecretKeyRingCollection, PGPSecretKeyRing paramPGPSecretKeyRing)
  {
    Long localLong = new Long(paramPGPSecretKeyRing.getPublicKey().getKeyID());
    if (paramPGPSecretKeyRingCollection.secretRings.containsKey(localLong)) {
      throw new IllegalArgumentException("Collection already contains a key with a keyID for the passed in ring.");
    }
    HashMap localHashMap = new HashMap(paramPGPSecretKeyRingCollection.secretRings);
    ArrayList localArrayList = new ArrayList(paramPGPSecretKeyRingCollection.order);
    localHashMap.put(localLong, paramPGPSecretKeyRing);
    localArrayList.add(localLong);
    return new PGPSecretKeyRingCollection(localHashMap, localArrayList);
  }
  
  public static PGPSecretKeyRingCollection removeSecretKeyRing(PGPSecretKeyRingCollection paramPGPSecretKeyRingCollection, PGPSecretKeyRing paramPGPSecretKeyRing)
  {
    Long localLong1 = new Long(paramPGPSecretKeyRing.getPublicKey().getKeyID());
    if (!paramPGPSecretKeyRingCollection.secretRings.containsKey(localLong1)) {
      throw new IllegalArgumentException("Collection does not contain a key with a keyID for the passed in ring.");
    }
    HashMap localHashMap = new HashMap(paramPGPSecretKeyRingCollection.secretRings);
    ArrayList localArrayList = new ArrayList(paramPGPSecretKeyRingCollection.order);
    localHashMap.remove(localLong1);
    for (int i = 0; i < localArrayList.size(); i++)
    {
      Long localLong2 = (Long)localArrayList.get(i);
      if (localLong2.longValue() == localLong1.longValue())
      {
        localArrayList.remove(i);
        break;
      }
    }
    return new PGPSecretKeyRingCollection(localHashMap, localArrayList);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSecretKeyRingCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */