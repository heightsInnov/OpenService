package org.bouncycastle.openpgp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.bcpg.BCPGKey;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.ContainedPacket;
import org.bouncycastle.bcpg.DSAPublicBCPGKey;
import org.bouncycastle.bcpg.ElGamalPublicBCPGKey;
import org.bouncycastle.bcpg.MPInteger;
import org.bouncycastle.bcpg.PublicKeyAlgorithmTags;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.RSAPublicBCPGKey;
import org.bouncycastle.bcpg.TrustPacket;
import org.bouncycastle.bcpg.UserAttributePacket;
import org.bouncycastle.bcpg.UserIDPacket;
import org.bouncycastle.jce.interfaces.ElGamalPublicKey;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;
import org.bouncycastle.jce.spec.ElGamalPublicKeySpec;
import org.bouncycastle.util.Arrays;

public class PGPPublicKey
  implements PublicKeyAlgorithmTags
{
  private static final int[] MASTER_KEY_CERTIFICATION_TYPES = { 19, 18, 17, 16 };
  PublicKeyPacket publicPk;
  TrustPacket trustPk;
  List keySigs = new ArrayList();
  List ids = new ArrayList();
  List idTrusts = new ArrayList();
  List idSigs = new ArrayList();
  List subSigs = null;
  private long keyID;
  private byte[] fingerprint;
  private int keyStrength;
  
  private void init()
    throws IOException
  {
    BCPGKey localBCPGKey = this.publicPk.getKey();
    Object localObject;
    if (this.publicPk.getVersion() <= 3)
    {
      localObject = (RSAPublicBCPGKey)localBCPGKey;
      this.keyID = ((RSAPublicBCPGKey)localObject).getModulus().longValue();
      try
      {
        MessageDigest localMessageDigest1 = MessageDigest.getInstance("MD5");
        byte[] arrayOfByte = new MPInteger(((RSAPublicBCPGKey)localObject).getModulus()).getEncoded();
        localMessageDigest1.update(arrayOfByte, 2, arrayOfByte.length - 2);
        arrayOfByte = new MPInteger(((RSAPublicBCPGKey)localObject).getPublicExponent()).getEncoded();
        localMessageDigest1.update(arrayOfByte, 2, arrayOfByte.length - 2);
        this.fingerprint = localMessageDigest1.digest();
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
      {
        throw new IOException("can't find MD5");
      }
      this.keyStrength = ((RSAPublicBCPGKey)localObject).getModulus().bitLength();
    }
    else
    {
      localObject = this.publicPk.getEncodedContents();
      try
      {
        MessageDigest localMessageDigest2 = MessageDigest.getInstance("SHA1");
        localMessageDigest2.update((byte)-103);
        localMessageDigest2.update((byte)(localObject.length >> 8));
        localMessageDigest2.update((byte)localObject.length);
        localMessageDigest2.update((byte[])localObject);
        this.fingerprint = localMessageDigest2.digest();
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
      {
        throw new IOException("can't find SHA1");
      }
      this.keyID = ((this.fingerprint[(this.fingerprint.length - 8)] & 0xFF) << 56 | (this.fingerprint[(this.fingerprint.length - 7)] & 0xFF) << 48 | (this.fingerprint[(this.fingerprint.length - 6)] & 0xFF) << 40 | (this.fingerprint[(this.fingerprint.length - 5)] & 0xFF) << 32 | (this.fingerprint[(this.fingerprint.length - 4)] & 0xFF) << 24 | (this.fingerprint[(this.fingerprint.length - 3)] & 0xFF) << 16 | (this.fingerprint[(this.fingerprint.length - 2)] & 0xFF) << 8 | this.fingerprint[(this.fingerprint.length - 1)] & 0xFF);
      if ((localBCPGKey instanceof RSAPublicBCPGKey)) {
        this.keyStrength = ((RSAPublicBCPGKey)localBCPGKey).getModulus().bitLength();
      } else if ((localBCPGKey instanceof DSAPublicBCPGKey)) {
        this.keyStrength = ((DSAPublicBCPGKey)localBCPGKey).getP().bitLength();
      } else if ((localBCPGKey instanceof ElGamalPublicBCPGKey)) {
        this.keyStrength = ((ElGamalPublicBCPGKey)localBCPGKey).getP().bitLength();
      }
    }
  }
  
  public PGPPublicKey(int paramInt, PublicKey paramPublicKey, Date paramDate, String paramString)
    throws PGPException, NoSuchProviderException
  {
    Object localObject2;
    Object localObject1;
    if ((paramPublicKey instanceof RSAPublicKey))
    {
      localObject2 = (RSAPublicKey)paramPublicKey;
      localObject1 = new RSAPublicBCPGKey(((RSAPublicKey)localObject2).getModulus(), ((RSAPublicKey)localObject2).getPublicExponent());
    }
    else
    {
      Object localObject3;
      if ((paramPublicKey instanceof DSAPublicKey))
      {
        localObject2 = (DSAPublicKey)paramPublicKey;
        localObject3 = ((DSAPublicKey)localObject2).getParams();
        localObject1 = new DSAPublicBCPGKey(((DSAParams)localObject3).getP(), ((DSAParams)localObject3).getQ(), ((DSAParams)localObject3).getG(), ((DSAPublicKey)localObject2).getY());
      }
      else if ((paramPublicKey instanceof ElGamalPublicKey))
      {
        localObject2 = (ElGamalPublicKey)paramPublicKey;
        localObject3 = ((ElGamalPublicKey)localObject2).getParameters();
        localObject1 = new ElGamalPublicBCPGKey(((ElGamalParameterSpec)localObject3).getP(), ((ElGamalParameterSpec)localObject3).getG(), ((ElGamalPublicKey)localObject2).getY());
      }
      else
      {
        throw new PGPException("unknown key class");
      }
    }
    this.publicPk = new PublicKeyPacket(paramInt, paramDate, (BCPGKey)localObject1);
    this.ids = new ArrayList();
    this.idSigs = new ArrayList();
    try
    {
      init();
    }
    catch (IOException localIOException)
    {
      throw new PGPException("exception calculating keyID", localIOException);
    }
  }
  
  PGPPublicKey(PublicKeyPacket paramPublicKeyPacket, TrustPacket paramTrustPacket, List paramList)
    throws IOException
  {
    this.publicPk = paramPublicKeyPacket;
    this.trustPk = paramTrustPacket;
    this.subSigs = paramList;
    init();
  }
  
  PGPPublicKey(PGPPublicKey paramPGPPublicKey, TrustPacket paramTrustPacket, List paramList)
  {
    this.publicPk = paramPGPPublicKey.publicPk;
    this.trustPk = paramTrustPacket;
    this.subSigs = paramList;
    this.fingerprint = paramPGPPublicKey.fingerprint;
    this.keyID = paramPGPPublicKey.keyID;
    this.keyStrength = paramPGPPublicKey.keyStrength;
  }
  
  PGPPublicKey(PGPPublicKey paramPGPPublicKey)
  {
    this.publicPk = paramPGPPublicKey.publicPk;
    this.keySigs = new ArrayList(paramPGPPublicKey.keySigs);
    this.ids = new ArrayList(paramPGPPublicKey.ids);
    this.idTrusts = new ArrayList(paramPGPPublicKey.idTrusts);
    this.idSigs = new ArrayList(paramPGPPublicKey.idSigs.size());
    for (int i = 0; i != paramPGPPublicKey.idSigs.size(); i++) {
      this.idSigs.add(new ArrayList((ArrayList)paramPGPPublicKey.idSigs.get(i)));
    }
    if (paramPGPPublicKey.subSigs != null)
    {
      this.subSigs = new ArrayList(paramPGPPublicKey.subSigs.size());
      for (i = 0; i != paramPGPPublicKey.subSigs.size(); i++) {
        this.subSigs.add(paramPGPPublicKey.subSigs.get(i));
      }
    }
    this.fingerprint = paramPGPPublicKey.fingerprint;
    this.keyID = paramPGPPublicKey.keyID;
    this.keyStrength = paramPGPPublicKey.keyStrength;
  }
  
  PGPPublicKey(PublicKeyPacket paramPublicKeyPacket, TrustPacket paramTrustPacket, List paramList1, List paramList2, List paramList3, List paramList4)
    throws IOException
  {
    this.publicPk = paramPublicKeyPacket;
    this.trustPk = paramTrustPacket;
    this.keySigs = paramList1;
    this.ids = paramList2;
    this.idTrusts = paramList3;
    this.idSigs = paramList4;
    init();
  }
  
  PGPPublicKey(PublicKeyPacket paramPublicKeyPacket, List paramList1, List paramList2)
    throws IOException
  {
    this.publicPk = paramPublicKeyPacket;
    this.ids = paramList1;
    this.idSigs = paramList2;
    init();
  }
  
  public int getVersion()
  {
    return this.publicPk.getVersion();
  }
  
  public Date getCreationTime()
  {
    return this.publicPk.getTime();
  }
  
  public int getValidDays()
  {
    if (this.publicPk.getVersion() > 3) {
      return (int)(getValidSeconds() / 86400L);
    }
    return this.publicPk.getValidDays();
  }
  
  public byte[] getTrustData()
  {
    if (this.trustPk == null) {
      return null;
    }
    return Arrays.clone(this.trustPk.getLevelAndTrustAmount());
  }
  
  public long getValidSeconds()
  {
    if (this.publicPk.getVersion() > 3)
    {
      if (isMasterKey())
      {
        for (int i = 0; i != MASTER_KEY_CERTIFICATION_TYPES.length; i++)
        {
          long l2 = getExpirationTimeFromSig(true, MASTER_KEY_CERTIFICATION_TYPES[i]);
          if (l2 >= 0L) {
            return l2;
          }
        }
      }
      else
      {
        long l1 = getExpirationTimeFromSig(false, 24);
        if (l1 >= 0L) {
          return l1;
        }
      }
      return 0L;
    }
    return this.publicPk.getValidDays() * 24L * 60L * 60L;
  }
  
  private long getExpirationTimeFromSig(boolean paramBoolean, int paramInt)
  {
    Iterator localIterator = getSignaturesOfType(paramInt);
    if (localIterator.hasNext())
    {
      PGPSignature localPGPSignature = (PGPSignature)localIterator.next();
      if ((!paramBoolean) || (localPGPSignature.getKeyID() == getKeyID()))
      {
        PGPSignatureSubpacketVector localPGPSignatureSubpacketVector = localPGPSignature.getHashedSubPackets();
        if (localPGPSignatureSubpacketVector != null) {
          return localPGPSignatureSubpacketVector.getKeyExpirationTime();
        }
        return 0L;
      }
    }
    return -1L;
  }
  
  public long getKeyID()
  {
    return this.keyID;
  }
  
  public byte[] getFingerprint()
  {
    byte[] arrayOfByte = new byte[this.fingerprint.length];
    System.arraycopy(this.fingerprint, 0, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public boolean isEncryptionKey()
  {
    int i = this.publicPk.getAlgorithm();
    return (i == 1) || (i == 2) || (i == 16) || (i == 20);
  }
  
  public boolean isMasterKey()
  {
    return this.subSigs == null;
  }
  
  public int getAlgorithm()
  {
    return this.publicPk.getAlgorithm();
  }
  
  public int getBitStrength()
  {
    return this.keyStrength;
  }
  
  public PublicKey getKey(String paramString)
    throws PGPException, NoSuchProviderException
  {
    try
    {
      KeyFactory localKeyFactory;
      switch (this.publicPk.getAlgorithm())
      {
      case 1: 
      case 2: 
      case 3: 
        RSAPublicBCPGKey localRSAPublicBCPGKey = (RSAPublicBCPGKey)this.publicPk.getKey();
        RSAPublicKeySpec localRSAPublicKeySpec = new RSAPublicKeySpec(localRSAPublicBCPGKey.getModulus(), localRSAPublicBCPGKey.getPublicExponent());
        localKeyFactory = KeyFactory.getInstance("RSA", paramString);
        return localKeyFactory.generatePublic(localRSAPublicKeySpec);
      case 17: 
        DSAPublicBCPGKey localDSAPublicBCPGKey = (DSAPublicBCPGKey)this.publicPk.getKey();
        DSAPublicKeySpec localDSAPublicKeySpec = new DSAPublicKeySpec(localDSAPublicBCPGKey.getY(), localDSAPublicBCPGKey.getP(), localDSAPublicBCPGKey.getQ(), localDSAPublicBCPGKey.getG());
        localKeyFactory = KeyFactory.getInstance("DSA", paramString);
        return localKeyFactory.generatePublic(localDSAPublicKeySpec);
      case 16: 
      case 20: 
        ElGamalPublicBCPGKey localElGamalPublicBCPGKey = (ElGamalPublicBCPGKey)this.publicPk.getKey();
        ElGamalPublicKeySpec localElGamalPublicKeySpec = new ElGamalPublicKeySpec(localElGamalPublicBCPGKey.getY(), new ElGamalParameterSpec(localElGamalPublicBCPGKey.getP(), localElGamalPublicBCPGKey.getG()));
        localKeyFactory = KeyFactory.getInstance("ElGamal", paramString);
        return localKeyFactory.generatePublic(localElGamalPublicKeySpec);
      }
      throw new PGPException("unknown public key algorithm encountered");
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("exception constructing public key", localException);
    }
  }
  
  public Iterator getUserIDs()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != this.ids.size(); i++) {
      if ((this.ids.get(i) instanceof String)) {
        localArrayList.add(this.ids.get(i));
      }
    }
    return localArrayList.iterator();
  }
  
  public Iterator getUserAttributes()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != this.ids.size(); i++) {
      if ((this.ids.get(i) instanceof PGPUserAttributeSubpacketVector)) {
        localArrayList.add(this.ids.get(i));
      }
    }
    return localArrayList.iterator();
  }
  
  public Iterator getSignaturesForID(String paramString)
  {
    for (int i = 0; i != this.ids.size(); i++) {
      if (paramString.equals(this.ids.get(i))) {
        return ((ArrayList)this.idSigs.get(i)).iterator();
      }
    }
    return null;
  }
  
  public Iterator getSignaturesForUserAttribute(PGPUserAttributeSubpacketVector paramPGPUserAttributeSubpacketVector)
  {
    for (int i = 0; i != this.ids.size(); i++) {
      if (paramPGPUserAttributeSubpacketVector.equals(this.ids.get(i))) {
        return ((ArrayList)this.idSigs.get(i)).iterator();
      }
    }
    return null;
  }
  
  public Iterator getSignaturesOfType(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = getSignatures();
    while (localIterator.hasNext())
    {
      PGPSignature localPGPSignature = (PGPSignature)localIterator.next();
      if (localPGPSignature.getSignatureType() == paramInt) {
        localArrayList.add(localPGPSignature);
      }
    }
    return localArrayList.iterator();
  }
  
  public Iterator getSignatures()
  {
    if (this.subSigs == null)
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.addAll(this.keySigs);
      for (int i = 0; i != this.idSigs.size(); i++) {
        localArrayList.addAll((Collection)this.idSigs.get(i));
      }
      return localArrayList.iterator();
    }
    return this.subSigs.iterator();
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    localBCPGOutputStream.writePacket(this.publicPk);
    if (this.trustPk != null) {
      localBCPGOutputStream.writePacket(this.trustPk);
    }
    int i;
    if (this.subSigs == null)
    {
      for (i = 0; i != this.keySigs.size(); i++) {
        ((PGPSignature)this.keySigs.get(i)).encode(localBCPGOutputStream);
      }
      for (i = 0; i != this.ids.size(); i++)
      {
        if ((this.ids.get(i) instanceof String))
        {
          localObject = (String)this.ids.get(i);
          localBCPGOutputStream.writePacket(new UserIDPacket((String)localObject));
        }
        else
        {
          localObject = (PGPUserAttributeSubpacketVector)this.ids.get(i);
          localBCPGOutputStream.writePacket(new UserAttributePacket(((PGPUserAttributeSubpacketVector)localObject).toSubpacketArray()));
        }
        if (this.idTrusts.get(i) != null) {
          localBCPGOutputStream.writePacket((ContainedPacket)this.idTrusts.get(i));
        }
        Object localObject = (List)this.idSigs.get(i);
        for (int j = 0; j != ((List)localObject).size(); j++) {
          ((PGPSignature)((List)localObject).get(j)).encode(localBCPGOutputStream);
        }
      }
    }
    else
    {
      for (i = 0; i != this.subSigs.size(); i++) {
        ((PGPSignature)this.subSigs.get(i)).encode(localBCPGOutputStream);
      }
    }
  }
  
  public boolean isRevoked()
  {
    int i = 0;
    boolean bool = false;
    if (isMasterKey()) {
      while ((!bool) && (i < this.keySigs.size())) {
        if (((PGPSignature)this.keySigs.get(i++)).getSignatureType() == 32) {
          bool = true;
        }
      }
    }
    while ((!bool) && (i < this.subSigs.size())) {
      if (((PGPSignature)this.subSigs.get(i++)).getSignatureType() == 40) {
        bool = true;
      }
    }
    return bool;
  }
  
  public static PGPPublicKey addCertification(PGPPublicKey paramPGPPublicKey, String paramString, PGPSignature paramPGPSignature)
  {
    PGPPublicKey localPGPPublicKey = new PGPPublicKey(paramPGPPublicKey);
    Object localObject = null;
    for (int i = 0; i != localPGPPublicKey.ids.size(); i++) {
      if (paramString.equals(localPGPPublicKey.ids.get(i))) {
        localObject = (List)localPGPPublicKey.idSigs.get(i);
      }
    }
    if (localObject != null)
    {
      ((List)localObject).add(paramPGPSignature);
    }
    else
    {
      localObject = new ArrayList();
      ((List)localObject).add(paramPGPSignature);
      localPGPPublicKey.ids.add(paramString);
      localPGPPublicKey.idTrusts.add(null);
      localPGPPublicKey.idSigs.add(localObject);
    }
    return localPGPPublicKey;
  }
  
  public static PGPPublicKey removeCertification(PGPPublicKey paramPGPPublicKey, String paramString)
  {
    PGPPublicKey localPGPPublicKey = new PGPPublicKey(paramPGPPublicKey);
    int i = 0;
    for (int j = 0; j < localPGPPublicKey.ids.size(); j++) {
      if (paramString.equals(localPGPPublicKey.ids.get(j)))
      {
        i = 1;
        localPGPPublicKey.ids.remove(j);
        localPGPPublicKey.idTrusts.remove(j);
        localPGPPublicKey.idSigs.remove(j);
      }
    }
    if (i == 0) {
      return null;
    }
    return localPGPPublicKey;
  }
  
  public static PGPPublicKey removeCertification(PGPPublicKey paramPGPPublicKey, String paramString, PGPSignature paramPGPSignature)
  {
    PGPPublicKey localPGPPublicKey = new PGPPublicKey(paramPGPPublicKey);
    boolean bool = false;
    for (int i = 0; i < localPGPPublicKey.ids.size(); i++) {
      if (paramString.equals(localPGPPublicKey.ids.get(i))) {
        bool = ((List)localPGPPublicKey.idSigs.get(i)).remove(paramPGPSignature);
      }
    }
    if (!bool) {
      return null;
    }
    return localPGPPublicKey;
  }
  
  public static PGPPublicKey addCertification(PGPPublicKey paramPGPPublicKey, PGPSignature paramPGPSignature)
  {
    if (paramPGPPublicKey.isMasterKey())
    {
      if (paramPGPSignature.getSignatureType() == 40) {
        throw new IllegalArgumentException("signature type incorrect for master key revocation.");
      }
    }
    else if (paramPGPSignature.getSignatureType() == 32) {
      throw new IllegalArgumentException("signature type incorrect for sub-key revocation.");
    }
    PGPPublicKey localPGPPublicKey = new PGPPublicKey(paramPGPPublicKey);
    if (localPGPPublicKey.subSigs != null) {
      localPGPPublicKey.subSigs.add(paramPGPSignature);
    } else {
      localPGPPublicKey.keySigs.add(paramPGPSignature);
    }
    return localPGPPublicKey;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPublicKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */