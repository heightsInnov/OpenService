package org.bouncycastle.openpgp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.bcpg.MPInteger;
import org.bouncycastle.bcpg.OnePassSignaturePacket;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.SignaturePacket;
import org.bouncycastle.bcpg.SignatureSubpacket;
import org.bouncycastle.bcpg.sig.IssuerKeyID;
import org.bouncycastle.bcpg.sig.SignatureCreationTime;

public class PGPSignatureGenerator
{
  private int keyAlgorithm;
  private int hashAlgorithm;
  private PGPPrivateKey privKey;
  private Signature sig;
  private MessageDigest dig;
  private int signatureType;
  private byte lastb;
  SignatureSubpacket[] unhashed = new SignatureSubpacket[0];
  SignatureSubpacket[] hashed = new SignatureSubpacket[0];
  
  public PGPSignatureGenerator(int paramInt1, int paramInt2, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, PGPException
  {
    this(paramInt1, paramString, paramInt2, paramString);
  }
  
  public PGPSignatureGenerator(int paramInt1, String paramString1, int paramInt2, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException, PGPException
  {
    this.keyAlgorithm = paramInt1;
    this.hashAlgorithm = paramInt2;
    this.dig = PGPUtil.getDigestInstance(PGPUtil.getDigestName(paramInt2), paramString2);
    this.sig = Signature.getInstance(PGPUtil.getSignatureName(paramInt1, paramInt2), paramString1);
  }
  
  public void initSign(int paramInt, PGPPrivateKey paramPGPPrivateKey)
    throws PGPException
  {
    this.privKey = paramPGPPrivateKey;
    this.signatureType = paramInt;
    try
    {
      this.sig.initSign(paramPGPPrivateKey.getKey());
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new PGPException("invalid key.", localInvalidKeyException);
    }
    this.dig.reset();
    this.lastb = 0;
  }
  
  public void update(byte paramByte)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      if (paramByte == 13)
      {
        this.sig.update((byte)13);
        this.sig.update((byte)10);
        this.dig.update((byte)13);
        this.dig.update((byte)10);
      }
      else if (paramByte == 10)
      {
        if (this.lastb != 13)
        {
          this.sig.update((byte)13);
          this.sig.update((byte)10);
          this.dig.update((byte)13);
          this.dig.update((byte)10);
        }
      }
      else
      {
        this.sig.update(paramByte);
        this.dig.update(paramByte);
      }
      this.lastb = paramByte;
    }
    else
    {
      this.sig.update(paramByte);
      this.dig.update(paramByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte)
    throws SignatureException
  {
    update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      int i = paramInt1 + paramInt2;
      for (int j = paramInt1; j != i; j++) {
        update(paramArrayOfByte[j]);
      }
    }
    else
    {
      this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
      this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
  
  public void setHashedSubpackets(PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector)
  {
    if (paramPGPSignatureSubpacketVector == null)
    {
      this.hashed = new SignatureSubpacket[0];
      return;
    }
    this.hashed = paramPGPSignatureSubpacketVector.toSubpacketArray();
  }
  
  public void setUnhashedSubpackets(PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector)
  {
    if (paramPGPSignatureSubpacketVector == null)
    {
      this.unhashed = new SignatureSubpacket[0];
      return;
    }
    this.unhashed = paramPGPSignatureSubpacketVector.toSubpacketArray();
  }
  
  public PGPOnePassSignature generateOnePassVersion(boolean paramBoolean)
    throws PGPException
  {
    return new PGPOnePassSignature(new OnePassSignaturePacket(this.signatureType, this.hashAlgorithm, this.keyAlgorithm, this.privKey.getKeyID(), paramBoolean));
  }
  
  public PGPSignature generate()
    throws PGPException, SignatureException
  {
    int i = 4;
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    SignatureSubpacket[] arrayOfSignatureSubpacket1;
    if (!packetPresent(this.hashed, 2)) {
      arrayOfSignatureSubpacket1 = insertSubpacket(this.hashed, new SignatureCreationTime(false, new Date()));
    } else {
      arrayOfSignatureSubpacket1 = this.hashed;
    }
    SignatureSubpacket[] arrayOfSignatureSubpacket2;
    if ((!packetPresent(this.hashed, 16)) && (!packetPresent(this.unhashed, 16))) {
      arrayOfSignatureSubpacket2 = insertSubpacket(this.unhashed, new IssuerKeyID(false, this.privKey.getKeyID()));
    } else {
      arrayOfSignatureSubpacket2 = this.unhashed;
    }
    try
    {
      localByteArrayOutputStream1.write((byte)i);
      localByteArrayOutputStream1.write((byte)this.signatureType);
      localByteArrayOutputStream1.write((byte)this.keyAlgorithm);
      localByteArrayOutputStream1.write((byte)this.hashAlgorithm);
      ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
      for (int j = 0; j != arrayOfSignatureSubpacket1.length; j++) {
        arrayOfSignatureSubpacket1[j].encode(localByteArrayOutputStream2);
      }
      arrayOfByte2 = localByteArrayOutputStream2.toByteArray();
      localByteArrayOutputStream1.write((byte)(arrayOfByte2.length >> 8));
      localByteArrayOutputStream1.write((byte)arrayOfByte2.length);
      localByteArrayOutputStream1.write(arrayOfByte2);
    }
    catch (IOException localIOException)
    {
      throw new PGPException("exception encoding hashed data.", localIOException);
    }
    byte[] arrayOfByte1 = localByteArrayOutputStream1.toByteArray();
    localByteArrayOutputStream1.write((byte)i);
    localByteArrayOutputStream1.write(-1);
    localByteArrayOutputStream1.write((byte)(arrayOfByte1.length >> 24));
    localByteArrayOutputStream1.write((byte)(arrayOfByte1.length >> 16));
    localByteArrayOutputStream1.write((byte)(arrayOfByte1.length >> 8));
    localByteArrayOutputStream1.write((byte)arrayOfByte1.length);
    byte[] arrayOfByte2 = localByteArrayOutputStream1.toByteArray();
    this.sig.update(arrayOfByte2);
    this.dig.update(arrayOfByte2);
    MPInteger[] arrayOfMPInteger;
    if ((this.keyAlgorithm == 3) || (this.keyAlgorithm == 1))
    {
      arrayOfMPInteger = new MPInteger[1];
      arrayOfMPInteger[0] = new MPInteger(new BigInteger(1, this.sig.sign()));
    }
    else
    {
      arrayOfMPInteger = PGPUtil.dsaSigToMpi(this.sig.sign());
    }
    byte[] arrayOfByte3 = this.dig.digest();
    byte[] arrayOfByte4 = new byte[2];
    arrayOfByte4[0] = arrayOfByte3[0];
    arrayOfByte4[1] = arrayOfByte3[1];
    return new PGPSignature(new SignaturePacket(this.signatureType, this.privKey.getKeyID(), this.keyAlgorithm, this.hashAlgorithm, arrayOfSignatureSubpacket1, arrayOfSignatureSubpacket2, arrayOfByte4, arrayOfMPInteger));
  }
  
  public PGPSignature generateCertification(String paramString, PGPPublicKey paramPGPPublicKey)
    throws SignatureException, PGPException
  {
    byte[] arrayOfByte1 = getEncodedPublicKey(paramPGPPublicKey);
    update((byte)-103);
    update((byte)(arrayOfByte1.length >> 8));
    update((byte)arrayOfByte1.length);
    update(arrayOfByte1);
    byte[] arrayOfByte2 = new byte[paramString.length()];
    for (int i = 0; i != arrayOfByte2.length; i++) {
      arrayOfByte2[i] = ((byte)paramString.charAt(i));
    }
    update((byte)-76);
    update((byte)(arrayOfByte2.length >> 24));
    update((byte)(arrayOfByte2.length >> 16));
    update((byte)(arrayOfByte2.length >> 8));
    update((byte)arrayOfByte2.length);
    update(arrayOfByte2);
    return generate();
  }
  
  public PGPSignature generateCertification(PGPPublicKey paramPGPPublicKey1, PGPPublicKey paramPGPPublicKey2)
    throws SignatureException, PGPException
  {
    byte[] arrayOfByte = getEncodedPublicKey(paramPGPPublicKey1);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    arrayOfByte = getEncodedPublicKey(paramPGPPublicKey2);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    return generate();
  }
  
  public PGPSignature generateCertification(PGPPublicKey paramPGPPublicKey)
    throws SignatureException, PGPException
  {
    byte[] arrayOfByte = getEncodedPublicKey(paramPGPPublicKey);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    return generate();
  }
  
  private byte[] getEncodedPublicKey(PGPPublicKey paramPGPPublicKey)
    throws PGPException
  {
    byte[] arrayOfByte;
    try
    {
      arrayOfByte = paramPGPPublicKey.publicPk.getEncodedContents();
    }
    catch (IOException localIOException)
    {
      throw new PGPException("exception preparing key.", localIOException);
    }
    return arrayOfByte;
  }
  
  private boolean packetPresent(SignatureSubpacket[] paramArrayOfSignatureSubpacket, int paramInt)
  {
    for (int i = 0; i != paramArrayOfSignatureSubpacket.length; i++) {
      if (paramArrayOfSignatureSubpacket[i].getType() == paramInt) {
        return true;
      }
    }
    return false;
  }
  
  private SignatureSubpacket[] insertSubpacket(SignatureSubpacket[] paramArrayOfSignatureSubpacket, SignatureSubpacket paramSignatureSubpacket)
  {
    SignatureSubpacket[] arrayOfSignatureSubpacket = new SignatureSubpacket[paramArrayOfSignatureSubpacket.length + 1];
    arrayOfSignatureSubpacket[0] = paramSignatureSubpacket;
    System.arraycopy(paramArrayOfSignatureSubpacket, 0, arrayOfSignatureSubpacket, 1, paramArrayOfSignatureSubpacket.length);
    return arrayOfSignatureSubpacket;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSignatureGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */