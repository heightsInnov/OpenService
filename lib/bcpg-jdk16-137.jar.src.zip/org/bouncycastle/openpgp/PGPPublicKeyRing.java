package org.bouncycastle.openpgp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.TrustPacket;

public class PGPPublicKeyRing
  extends PGPKeyRing
{
  final List keys;
  
  public PGPPublicKeyRing(byte[] paramArrayOfByte)
    throws IOException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  PGPPublicKeyRing(List paramList)
  {
    this.keys = paramList;
  }
  
  public PGPPublicKeyRing(InputStream paramInputStream)
    throws IOException
  {
    this.keys = new ArrayList();
    BCPGInputStream localBCPGInputStream = wrap(paramInputStream);
    int i = localBCPGInputStream.nextPacketTag();
    if ((i != 6) && (i != 14)) {
      throw new IOException("public key ring doesn't start with public key tag: tag 0x" + Integer.toHexString(i));
    }
    PublicKeyPacket localPublicKeyPacket1 = (PublicKeyPacket)localBCPGInputStream.readPacket();
    TrustPacket localTrustPacket1 = readOptionalTrustPacket(localBCPGInputStream);
    List localList1 = readSignaturesAndTrust(localBCPGInputStream);
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList3 = new ArrayList();
    readUserIDs(localBCPGInputStream, localArrayList1, localArrayList2, localArrayList3);
    this.keys.add(new PGPPublicKey(localPublicKeyPacket1, localTrustPacket1, localList1, localArrayList1, localArrayList2, localArrayList3));
    while (localBCPGInputStream.nextPacketTag() == 14)
    {
      PublicKeyPacket localPublicKeyPacket2 = (PublicKeyPacket)localBCPGInputStream.readPacket();
      TrustPacket localTrustPacket2 = readOptionalTrustPacket(localBCPGInputStream);
      List localList2 = readSignaturesAndTrust(localBCPGInputStream);
      this.keys.add(new PGPPublicKey(localPublicKeyPacket2, localTrustPacket2, localList2));
    }
  }
  
  public PGPPublicKey getPublicKey()
  {
    return (PGPPublicKey)this.keys.get(0);
  }
  
  public PGPPublicKey getPublicKey(long paramLong)
    throws PGPException
  {
    for (int i = 0; i != this.keys.size(); i++)
    {
      PGPPublicKey localPGPPublicKey = (PGPPublicKey)this.keys.get(i);
      if (paramLong == localPGPPublicKey.getKeyID()) {
        return localPGPPublicKey;
      }
    }
    return null;
  }
  
  public Iterator getPublicKeys()
  {
    return Collections.unmodifiableList(this.keys).iterator();
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    for (int i = 0; i != this.keys.size(); i++)
    {
      PGPPublicKey localPGPPublicKey = (PGPPublicKey)this.keys.get(i);
      localPGPPublicKey.encode(paramOutputStream);
    }
  }
  
  public static PGPPublicKeyRing insertPublicKey(PGPPublicKeyRing paramPGPPublicKeyRing, PGPPublicKey paramPGPPublicKey)
  {
    ArrayList localArrayList = new ArrayList(paramPGPPublicKeyRing.keys);
    int i = 0;
    for (int j = 0; j != localArrayList.size(); j++)
    {
      PGPPublicKey localPGPPublicKey = (PGPPublicKey)localArrayList.get(j);
      if (localPGPPublicKey.getKeyID() == paramPGPPublicKey.getKeyID())
      {
        i = 1;
        localArrayList.set(j, paramPGPPublicKey);
      }
    }
    if (i == 0) {
      localArrayList.add(paramPGPPublicKey);
    }
    return new PGPPublicKeyRing(localArrayList);
  }
  
  public static PGPPublicKeyRing removePublicKey(PGPPublicKeyRing paramPGPPublicKeyRing, PGPPublicKey paramPGPPublicKey)
  {
    ArrayList localArrayList = new ArrayList(paramPGPPublicKeyRing.keys);
    int i = 0;
    for (int j = 0; j < localArrayList.size(); j++)
    {
      PGPPublicKey localPGPPublicKey = (PGPPublicKey)localArrayList.get(j);
      if (localPGPPublicKey.getKeyID() == paramPGPPublicKey.getKeyID())
      {
        i = 1;
        localArrayList.remove(j);
      }
    }
    if (i == 0) {
      return null;
    }
    return new PGPPublicKeyRing(localArrayList);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPublicKeyRing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */