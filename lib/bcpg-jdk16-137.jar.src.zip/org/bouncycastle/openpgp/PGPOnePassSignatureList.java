package org.bouncycastle.openpgp;

public class PGPOnePassSignatureList
{
  PGPOnePassSignature[] sigs;
  
  public PGPOnePassSignatureList(PGPOnePassSignature[] paramArrayOfPGPOnePassSignature)
  {
    this.sigs = new PGPOnePassSignature[paramArrayOfPGPOnePassSignature.length];
    System.arraycopy(paramArrayOfPGPOnePassSignature, 0, this.sigs, 0, paramArrayOfPGPOnePassSignature.length);
  }
  
  public PGPOnePassSignatureList(PGPOnePassSignature paramPGPOnePassSignature)
  {
    this.sigs = new PGPOnePassSignature[1];
    this.sigs[0] = paramPGPOnePassSignature;
  }
  
  public PGPOnePassSignature get(int paramInt)
  {
    return this.sigs[paramInt];
  }
  
  public int size()
  {
    return this.sigs.length;
  }
  
  public boolean isEmpty()
  {
    return this.sigs.length == 0;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPOnePassSignatureList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */