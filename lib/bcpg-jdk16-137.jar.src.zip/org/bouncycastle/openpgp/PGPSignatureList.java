package org.bouncycastle.openpgp;

public class PGPSignatureList
{
  PGPSignature[] sigs;
  
  public PGPSignatureList(PGPSignature[] paramArrayOfPGPSignature)
  {
    this.sigs = new PGPSignature[paramArrayOfPGPSignature.length];
    System.arraycopy(paramArrayOfPGPSignature, 0, this.sigs, 0, paramArrayOfPGPSignature.length);
  }
  
  public PGPSignatureList(PGPSignature paramPGPSignature)
  {
    this.sigs = new PGPSignature[1];
    this.sigs[0] = paramPGPSignature;
  }
  
  public PGPSignature get(int paramInt)
  {
    return this.sigs[paramInt];
  }
  
  public int size()
  {
    return this.sigs.length;
  }
  
  public boolean isEmpty()
  {
    return this.sigs.length == 0;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSignatureList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */