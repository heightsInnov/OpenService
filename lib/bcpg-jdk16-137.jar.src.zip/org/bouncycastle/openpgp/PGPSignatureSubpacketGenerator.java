package org.bouncycastle.openpgp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bouncycastle.bcpg.SignatureSubpacket;
import org.bouncycastle.bcpg.sig.Exportable;
import org.bouncycastle.bcpg.sig.KeyExpirationTime;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.bcpg.sig.NotationData;
import org.bouncycastle.bcpg.sig.PreferredAlgorithms;
import org.bouncycastle.bcpg.sig.PrimaryUserID;
import org.bouncycastle.bcpg.sig.Revocable;
import org.bouncycastle.bcpg.sig.SignatureCreationTime;
import org.bouncycastle.bcpg.sig.SignatureExpirationTime;
import org.bouncycastle.bcpg.sig.SignerUserID;
import org.bouncycastle.bcpg.sig.TrustSignature;

public class PGPSignatureSubpacketGenerator
{
  List list = new ArrayList();
  
  public void setRevocable(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.list.add(new Revocable(paramBoolean1, paramBoolean2));
  }
  
  public void setExportable(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.list.add(new Exportable(paramBoolean1, paramBoolean2));
  }
  
  public void setTrust(boolean paramBoolean, int paramInt1, int paramInt2)
  {
    this.list.add(new TrustSignature(paramBoolean, paramInt1, paramInt2));
  }
  
  public void setKeyExpirationTime(boolean paramBoolean, long paramLong)
  {
    this.list.add(new KeyExpirationTime(paramBoolean, paramLong));
  }
  
  public void setSignatureExpirationTime(boolean paramBoolean, long paramLong)
  {
    this.list.add(new SignatureExpirationTime(paramBoolean, paramLong));
  }
  
  public void setSignatureCreationTime(boolean paramBoolean, Date paramDate)
  {
    this.list.add(new SignatureCreationTime(paramBoolean, paramDate));
  }
  
  public void setPreferredHashAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    this.list.add(new PreferredAlgorithms(21, paramBoolean, paramArrayOfInt));
  }
  
  public void setPreferredSymmetricAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    this.list.add(new PreferredAlgorithms(11, paramBoolean, paramArrayOfInt));
  }
  
  public void setPreferredCompressionAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    this.list.add(new PreferredAlgorithms(22, paramBoolean, paramArrayOfInt));
  }
  
  public void setKeyFlags(boolean paramBoolean, int paramInt)
  {
    this.list.add(new KeyFlags(paramBoolean, paramInt));
  }
  
  public void setSignerUserID(boolean paramBoolean, String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("attempt to set null SignerUserID");
    }
    this.list.add(new SignerUserID(paramBoolean, paramString));
  }
  
  public void setPrimaryUserID(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.list.add(new PrimaryUserID(paramBoolean1, paramBoolean2));
  }
  
  public void setNotationData(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2)
  {
    this.list.add(new NotationData(paramBoolean1, paramBoolean2, paramString1, paramString2));
  }
  
  public PGPSignatureSubpacketVector generate()
  {
    return new PGPSignatureSubpacketVector((SignatureSubpacket[])this.list.toArray(new SignatureSubpacket[this.list.size()]));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSignatureSubpacketGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */