package org.bouncycastle.openpgp.examples;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;

public class RSAKeyPairGenerator
{
  private static void exportKeyPair(OutputStream paramOutputStream1, OutputStream paramOutputStream2, PublicKey paramPublicKey, PrivateKey paramPrivateKey, String paramString, char[] paramArrayOfChar, boolean paramBoolean)
    throws IOException, InvalidKeyException, NoSuchProviderException, SignatureException, PGPException
  {
    if (paramBoolean) {
      paramOutputStream1 = new ArmoredOutputStream(paramOutputStream1);
    }
    PGPSecretKey localPGPSecretKey = new PGPSecretKey(16, 1, paramPublicKey, paramPrivateKey, new Date(), paramString, 3, paramArrayOfChar, null, null, new SecureRandom(), "BC");
    localPGPSecretKey.encode(paramOutputStream1);
    paramOutputStream1.close();
    if (paramBoolean) {
      paramOutputStream2 = new ArmoredOutputStream(paramOutputStream2);
    }
    PGPPublicKey localPGPPublicKey = localPGPSecretKey.getPublicKey();
    localPGPPublicKey.encode(paramOutputStream2);
    paramOutputStream2.close();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
    localKeyPairGenerator.initialize(1024);
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    if (paramArrayOfString.length < 2)
    {
      System.out.println("RSAKeyPairGenerator [-a] identity passPhrase");
      System.exit(0);
    }
    FileOutputStream localFileOutputStream1;
    FileOutputStream localFileOutputStream2;
    if (paramArrayOfString[0].equals("-a"))
    {
      if (paramArrayOfString.length < 3)
      {
        System.out.println("RSAKeyPairGenerator [-a] identity passPhrase");
        System.exit(0);
      }
      localFileOutputStream1 = new FileOutputStream("secret.asc");
      localFileOutputStream2 = new FileOutputStream("pub.asc");
      exportKeyPair(localFileOutputStream1, localFileOutputStream2, localKeyPair.getPublic(), localKeyPair.getPrivate(), paramArrayOfString[1], paramArrayOfString[2].toCharArray(), true);
    }
    else
    {
      localFileOutputStream1 = new FileOutputStream("secret.bpg");
      localFileOutputStream2 = new FileOutputStream("pub.bpg");
      exportKeyPair(localFileOutputStream1, localFileOutputStream2, localKeyPair.getPublic(), localKeyPair.getPrivate(), paramArrayOfString[0], paramArrayOfString[1].toCharArray(), false);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\RSAKeyPairGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */