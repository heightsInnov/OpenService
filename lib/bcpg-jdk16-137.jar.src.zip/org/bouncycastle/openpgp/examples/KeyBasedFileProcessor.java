package org.bouncycastle.openpgp.examples;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;

public class KeyBasedFileProcessor
{
  private static PGPPublicKey readPublicKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    PGPPublicKeyRingCollection localPGPPublicKeyRingCollection = new PGPPublicKeyRingCollection(paramInputStream);
    Object localObject = null;
    Iterator localIterator1 = localPGPPublicKeyRingCollection.getKeyRings();
    while ((localObject == null) && (localIterator1.hasNext()))
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPPublicKeyRing.getPublicKeys();
      int i = 0;
      while ((localObject == null) && (localIterator2.hasNext()))
      {
        PGPPublicKey localPGPPublicKey = (PGPPublicKey)localIterator2.next();
        if (localPGPPublicKey.isEncryptionKey()) {
          localObject = localPGPPublicKey;
        }
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("Can't find encryption key in key ring.");
    }
    return (PGPPublicKey)localObject;
  }
  
  private static PGPPrivateKey findSecretKey(InputStream paramInputStream, long paramLong, char[] paramArrayOfChar)
    throws IOException, PGPException, NoSuchProviderException
  {
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(paramInputStream));
    PGPSecretKey localPGPSecretKey = localPGPSecretKeyRingCollection.getSecretKey(paramLong);
    if (localPGPSecretKey == null) {
      return null;
    }
    return localPGPSecretKey.extractPrivateKey(paramArrayOfChar, "BC");
  }
  
  private static void decryptFile(InputStream paramInputStream1, InputStream paramInputStream2, char[] paramArrayOfChar)
    throws Exception
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    try
    {
      PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(paramInputStream1);
      Object localObject1 = localPGPObjectFactory1.nextObject();
      PGPEncryptedDataList localPGPEncryptedDataList;
      if ((localObject1 instanceof PGPEncryptedDataList)) {
        localPGPEncryptedDataList = (PGPEncryptedDataList)localObject1;
      } else {
        localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory1.nextObject();
      }
      Iterator localIterator = localPGPEncryptedDataList.getEncryptedDataObjects();
      PGPPrivateKey localPGPPrivateKey = null;
      PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = null;
      while ((localPGPPrivateKey == null) && (localIterator.hasNext()))
      {
        localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localIterator.next();
        localPGPPrivateKey = findSecretKey(paramInputStream2, localPGPPublicKeyEncryptedData.getKeyID(), paramArrayOfChar);
      }
      if (localPGPPrivateKey == null) {
        throw new IllegalArgumentException("secret key for message not found.");
      }
      InputStream localInputStream1 = localPGPPublicKeyEncryptedData.getDataStream(localPGPPrivateKey, "BC");
      PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(localInputStream1);
      Object localObject2 = localPGPObjectFactory2.nextObject();
      Object localObject3;
      Object localObject4;
      if ((localObject2 instanceof PGPCompressedData))
      {
        localObject3 = (PGPCompressedData)localObject2;
        localObject4 = new PGPObjectFactory(((PGPCompressedData)localObject3).getDataStream());
        localObject2 = ((PGPObjectFactory)localObject4).nextObject();
      }
      if ((localObject2 instanceof PGPLiteralData))
      {
        localObject3 = (PGPLiteralData)localObject2;
        localObject4 = new FileOutputStream(((PGPLiteralData)localObject3).getFileName());
        InputStream localInputStream2 = ((PGPLiteralData)localObject3).getInputStream();
        int i;
        while ((i = localInputStream2.read()) >= 0) {
          ((FileOutputStream)localObject4).write(i);
        }
      }
      else
      {
        if ((localObject2 instanceof PGPOnePassSignatureList)) {
          throw new PGPException("encrypted message contains a signed message - not literal data.");
        }
        throw new PGPException("message is not a simple encrypted file - type unknown.");
      }
      if (localPGPPublicKeyEncryptedData.isIntegrityProtected())
      {
        if (!localPGPPublicKeyEncryptedData.verify()) {
          System.err.println("message failed integrity check");
        } else {
          System.err.println("message integrity check passed");
        }
      }
      else {
        System.err.println("no message integrity check");
      }
    }
    catch (PGPException localPGPException)
    {
      System.err.println(localPGPException);
      if (localPGPException.getUnderlyingException() != null) {
        localPGPException.getUnderlyingException().printStackTrace();
      }
    }
  }
  
  private static void encryptFile(OutputStream paramOutputStream, String paramString, PGPPublicKey paramPGPPublicKey, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, NoSuchProviderException
  {
    if (paramBoolean1) {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
    }
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
      PGPUtil.writeFileToLiteralData(localPGPCompressedDataGenerator.open(localByteArrayOutputStream), 'b', new File(paramString));
      localPGPCompressedDataGenerator.close();
      PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, paramBoolean2, new SecureRandom(), "BC");
      localPGPEncryptedDataGenerator.addMethod(paramPGPPublicKey);
      byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
      OutputStream localOutputStream = localPGPEncryptedDataGenerator.open(paramOutputStream, arrayOfByte.length);
      localOutputStream.write(arrayOfByte);
      localOutputStream.close();
      paramOutputStream.close();
    }
    catch (PGPException localPGPException)
    {
      System.err.println(localPGPException);
      if (localPGPException.getUnderlyingException() != null) {
        localPGPException.getUnderlyingException().printStackTrace();
      }
    }
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    if (paramArrayOfString.length == 0)
    {
      System.err.println("usage: KeyBasedFileProcessor -e|-d [-a|ai] file [secretKeyFile passPhrase|pubKeyFile]");
      return;
    }
    FileInputStream localFileInputStream;
    Object localObject;
    if (paramArrayOfString[0].equals("-e"))
    {
      if ((paramArrayOfString[1].equals("-a")) || (paramArrayOfString[1].equals("-ai")) || (paramArrayOfString[1].equals("-ia")))
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[3]);
        localObject = new FileOutputStream(paramArrayOfString[2] + ".asc");
        encryptFile((OutputStream)localObject, paramArrayOfString[2], readPublicKey(localFileInputStream), true, paramArrayOfString[1].indexOf('i') > 0);
      }
      else if (paramArrayOfString[1].equals("-i"))
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[3]);
        localObject = new FileOutputStream(paramArrayOfString[2] + ".bpg");
        encryptFile((OutputStream)localObject, paramArrayOfString[2], readPublicKey(localFileInputStream), false, true);
      }
      else
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[2]);
        localObject = new FileOutputStream(paramArrayOfString[1] + ".bpg");
        encryptFile((OutputStream)localObject, paramArrayOfString[1], readPublicKey(localFileInputStream), false, false);
      }
    }
    else if (paramArrayOfString[0].equals("-d"))
    {
      localFileInputStream = new FileInputStream(paramArrayOfString[1]);
      localObject = new FileInputStream(paramArrayOfString[2]);
      decryptFile(localFileInputStream, (InputStream)localObject, paramArrayOfString[3].toCharArray());
    }
    else
    {
      System.err.println("usage: KeyBasedFileProcessor -d|-e [-a|ai] file [secretKeyFile passPhrase|pubKeyFile]");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\KeyBasedFileProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */