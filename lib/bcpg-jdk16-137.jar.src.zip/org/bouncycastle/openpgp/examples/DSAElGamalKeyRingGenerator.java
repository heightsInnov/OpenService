package org.bouncycastle.openpgp.examples;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPKeyPair;
import org.bouncycastle.openpgp.PGPKeyRingGenerator;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRing;

public class DSAElGamalKeyRingGenerator
{
  private static void exportKeyPair(OutputStream paramOutputStream1, OutputStream paramOutputStream2, KeyPair paramKeyPair1, KeyPair paramKeyPair2, String paramString, char[] paramArrayOfChar, boolean paramBoolean)
    throws IOException, InvalidKeyException, NoSuchProviderException, SignatureException, PGPException
  {
    if (paramBoolean) {
      paramOutputStream1 = new ArmoredOutputStream(paramOutputStream1);
    }
    PGPKeyPair localPGPKeyPair1 = new PGPKeyPair(17, paramKeyPair1, new Date(), "BC");
    PGPKeyPair localPGPKeyPair2 = new PGPKeyPair(16, paramKeyPair2, new Date(), "BC");
    PGPKeyRingGenerator localPGPKeyRingGenerator = new PGPKeyRingGenerator(19, localPGPKeyPair1, paramString, 9, paramArrayOfChar, true, null, null, new SecureRandom(), "BC");
    localPGPKeyRingGenerator.addSubKey(localPGPKeyPair2);
    localPGPKeyRingGenerator.generateSecretKeyRing().encode(paramOutputStream1);
    paramOutputStream1.close();
    if (paramBoolean) {
      paramOutputStream2 = new ArmoredOutputStream(paramOutputStream2);
    }
    localPGPKeyRingGenerator.generatePublicKeyRing().encode(paramOutputStream2);
    paramOutputStream2.close();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    if (paramArrayOfString.length < 2)
    {
      System.out.println("DSAElGamalKeyRingGenerator [-a] identity passPhrase");
      System.exit(0);
    }
    KeyPairGenerator localKeyPairGenerator1 = KeyPairGenerator.getInstance("DSA", "BC");
    localKeyPairGenerator1.initialize(1024);
    KeyPair localKeyPair1 = localKeyPairGenerator1.generateKeyPair();
    KeyPairGenerator localKeyPairGenerator2 = KeyPairGenerator.getInstance("ELGAMAL", "BC");
    BigInteger localBigInteger1 = new BigInteger("153d5d6172adb43045b68ae8e1de1070b6137005686d29d3d73a7749199681ee5b212c9b96bfdcfa5b20cd5e3fd2044895d609cf9b410b7a0f12ca1cb9a428cc", 16);
    BigInteger localBigInteger2 = new BigInteger("9494fec095f3b85ee286542b3836fc81a5dd0a0349b4c239dd38744d488cf8e31db8bcb7d33b41abb9e5a33cca9144b1cef332c94bf0573bf047a3aca98cdf3b", 16);
    ElGamalParameterSpec localElGamalParameterSpec = new ElGamalParameterSpec(localBigInteger2, localBigInteger1);
    localKeyPairGenerator2.initialize(localElGamalParameterSpec);
    KeyPair localKeyPair2 = localKeyPairGenerator2.generateKeyPair();
    FileOutputStream localFileOutputStream1;
    FileOutputStream localFileOutputStream2;
    if (paramArrayOfString[0].equals("-a"))
    {
      if (paramArrayOfString.length < 3)
      {
        System.out.println("DSAElGamalKeyRingGenerator [-a] identity passPhrase");
        System.exit(0);
      }
      localFileOutputStream1 = new FileOutputStream("secret.asc");
      localFileOutputStream2 = new FileOutputStream("pub.asc");
      exportKeyPair(localFileOutputStream1, localFileOutputStream2, localKeyPair1, localKeyPair2, paramArrayOfString[1], paramArrayOfString[2].toCharArray(), true);
    }
    else
    {
      localFileOutputStream1 = new FileOutputStream("secret.bpg");
      localFileOutputStream2 = new FileOutputStream("pub.bpg");
      exportKeyPair(localFileOutputStream1, localFileOutputStream2, localKeyPair1, localKeyPair2, paramArrayOfString[0], paramArrayOfString[1].toCharArray(), false);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\DSAElGamalKeyRingGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */