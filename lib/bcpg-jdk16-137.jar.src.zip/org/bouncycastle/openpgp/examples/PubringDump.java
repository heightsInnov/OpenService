package org.bouncycastle.openpgp.examples;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.security.Security;
import java.util.Iterator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.util.encoders.Hex;

public class PubringDump
{
  public static String getAlgorithm(int paramInt)
  {
    switch (paramInt)
    {
    case 1: 
      return "RSA_GENERAL";
    case 2: 
      return "RSA_ENCRYPT";
    case 3: 
      return "RSA_SIGN";
    case 16: 
      return "ELGAMAL_ENCRYPT";
    case 17: 
      return "DSA";
    case 18: 
      return "EC";
    case 19: 
      return "ECDSA";
    case 20: 
      return "ELGAMAL_GENERAL";
    case 21: 
      return "DIFFIE_HELLMAN";
    }
    return "unknown";
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    PGPPublicKey localPGPPublicKey1 = null;
    Object localObject1 = null;
    PGPUtil.setDefaultProvider("BC");
    PGPPublicKeyRingCollection localPGPPublicKeyRingCollection = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[0])));
    Iterator localIterator1 = localPGPPublicKeyRingCollection.getKeyRings();
    while (localIterator1.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator1.next();
      try
      {
        localPGPPublicKey1 = localPGPPublicKeyRing.getPublicKey();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      continue;
      long l = 0L;
      Object localObject2 = null;
      Iterator localIterator2 = localPGPPublicKeyRing.getPublicKeys();
      int i = 1;
      while (localIterator2.hasNext())
      {
        PGPPublicKey localPGPPublicKey2 = (PGPPublicKey)localIterator2.next();
        if (i != 0)
        {
          System.out.println("Key ID: " + Long.toHexString(localPGPPublicKey2.getKeyID()));
          i = 0;
        }
        else
        {
          System.out.println("Key ID: " + Long.toHexString(localPGPPublicKey2.getKeyID()) + " (subkey)");
        }
        System.out.println("            Algorithm: " + getAlgorithm(localPGPPublicKey2.getAlgorithm()));
        System.out.println("            Fingerprint: " + new String(Hex.encode(localPGPPublicKey2.getFingerprint())));
      }
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\PubringDump.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */