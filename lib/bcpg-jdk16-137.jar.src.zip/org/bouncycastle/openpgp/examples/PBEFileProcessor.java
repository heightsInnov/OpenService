package org.bouncycastle.openpgp.examples;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPBEEncryptedData;
import org.bouncycastle.openpgp.PGPUtil;

public class PBEFileProcessor
{
  private static void decryptFile(InputStream paramInputStream, char[] paramArrayOfChar)
    throws Exception
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory(paramInputStream);
    Object localObject1 = localPGPObjectFactory1.nextObject();
    PGPEncryptedDataList localPGPEncryptedDataList;
    if ((localObject1 instanceof PGPEncryptedDataList)) {
      localPGPEncryptedDataList = (PGPEncryptedDataList)localObject1;
    } else {
      localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory1.nextObject();
    }
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(0);
    InputStream localInputStream1 = localPGPPBEEncryptedData.getDataStream(paramArrayOfChar, "BC");
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(localInputStream1);
    localObject1 = localPGPObjectFactory2.nextObject();
    if ((localObject1 instanceof PGPCompressedData))
    {
      localObject2 = (PGPCompressedData)localObject1;
      localPGPObjectFactory2 = new PGPObjectFactory(((PGPCompressedData)localObject2).getDataStream());
      localObject1 = localPGPObjectFactory2.nextObject();
    }
    Object localObject2 = (PGPLiteralData)localObject1;
    FileOutputStream localFileOutputStream = new FileOutputStream(((PGPLiteralData)localObject2).getFileName());
    InputStream localInputStream2 = ((PGPLiteralData)localObject2).getInputStream();
    int i;
    while ((i = localInputStream2.read()) >= 0) {
      localFileOutputStream.write(i);
    }
    if (localPGPPBEEncryptedData.isIntegrityProtected())
    {
      if (!localPGPPBEEncryptedData.verify()) {
        System.err.println("message failed integrity check");
      } else {
        System.err.println("message integrity check passed");
      }
    }
    else {
      System.err.println("no message integrity check");
    }
  }
  
  private static void encryptFile(OutputStream paramOutputStream, String paramString, char[] paramArrayOfChar, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, NoSuchProviderException, PGPException
  {
    if (paramBoolean1) {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    PGPUtil.writeFileToLiteralData(localPGPCompressedDataGenerator.open(localByteArrayOutputStream), 'b', new File(paramString));
    localPGPCompressedDataGenerator.close();
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(3, paramBoolean2, new SecureRandom(), "BC");
    localPGPEncryptedDataGenerator.addMethod(paramArrayOfChar);
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    OutputStream localOutputStream = localPGPEncryptedDataGenerator.open(paramOutputStream, arrayOfByte.length);
    localOutputStream.write(arrayOfByte);
    localOutputStream.close();
    paramOutputStream.close();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    Object localObject;
    if (paramArrayOfString[0].equals("-e"))
    {
      if ((paramArrayOfString[1].equals("-a")) || (paramArrayOfString[1].equals("-ai")) || (paramArrayOfString[1].equals("-ia")))
      {
        localObject = new FileOutputStream(paramArrayOfString[2] + ".asc");
        encryptFile((OutputStream)localObject, paramArrayOfString[2], paramArrayOfString[3].toCharArray(), true, paramArrayOfString[1].indexOf('i') > 0);
      }
      else if (paramArrayOfString[1].equals("-i"))
      {
        localObject = new FileOutputStream(paramArrayOfString[2] + ".bpg");
        encryptFile((OutputStream)localObject, paramArrayOfString[2], paramArrayOfString[3].toCharArray(), false, true);
      }
      else
      {
        localObject = new FileOutputStream(paramArrayOfString[1] + ".bpg");
        encryptFile((OutputStream)localObject, paramArrayOfString[1], paramArrayOfString[2].toCharArray(), false, false);
      }
    }
    else if (paramArrayOfString[0].equals("-d"))
    {
      localObject = new FileInputStream(paramArrayOfString[1]);
      decryptFile((InputStream)localObject, paramArrayOfString[2].toCharArray());
    }
    else
    {
      System.err.println("usage: PBEFileProcessor -e [-ai]|-d file passPhrase");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\PBEFileProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */