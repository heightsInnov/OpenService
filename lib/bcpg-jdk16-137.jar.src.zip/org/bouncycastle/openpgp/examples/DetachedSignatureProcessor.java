package org.bouncycastle.openpgp.examples;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.SignatureException;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPUtil;

public class DetachedSignatureProcessor
{
  private static PGPSecretKey readSecretKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection = new PGPSecretKeyRingCollection(paramInputStream);
    Object localObject = null;
    Iterator localIterator1 = localPGPSecretKeyRingCollection.getKeyRings();
    while ((localObject == null) && (localIterator1.hasNext()))
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPSecretKeyRing.getSecretKeys();
      while ((localObject == null) && (localIterator2.hasNext()))
      {
        PGPSecretKey localPGPSecretKey = (PGPSecretKey)localIterator2.next();
        if (localPGPSecretKey.isSigningKey()) {
          localObject = localPGPSecretKey;
        }
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("Can't find encryption key in key ring.");
    }
    return (PGPSecretKey)localObject;
  }
  
  private static void verifySignature(String paramString, InputStream paramInputStream1, InputStream paramInputStream2)
    throws Exception
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramInputStream1);
    PGPSignatureList localPGPSignatureList = null;
    Object localObject1 = localPGPObjectFactory.nextObject();
    if ((localObject1 instanceof PGPCompressedData))
    {
      localObject2 = (PGPCompressedData)localObject1;
      localPGPObjectFactory = new PGPObjectFactory(((PGPCompressedData)localObject2).getDataStream());
      localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    }
    else
    {
      localPGPSignatureList = (PGPSignatureList)localObject1;
    }
    Object localObject2 = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(paramInputStream2));
    FileInputStream localFileInputStream = new FileInputStream(paramString);
    PGPSignature localPGPSignature = localPGPSignatureList.get(0);
    PGPPublicKey localPGPPublicKey = ((PGPPublicKeyRingCollection)localObject2).getPublicKey(localPGPSignature.getKeyID());
    localPGPSignature.initVerify(localPGPPublicKey, "BC");
    int i;
    while ((i = localFileInputStream.read()) >= 0) {
      localPGPSignature.update((byte)i);
    }
    if (localPGPSignature.verify()) {
      System.out.println("signature verified.");
    } else {
      System.out.println("signature verification failed.");
    }
  }
  
  private static void createSignature(String paramString, InputStream paramInputStream, OutputStream paramOutputStream, char[] paramArrayOfChar, boolean paramBoolean)
    throws IOException, NoSuchAlgorithmException, NoSuchProviderException, PGPException, SignatureException
  {
    if (paramBoolean) {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
    }
    PGPSecretKey localPGPSecretKey = readSecretKey(paramInputStream);
    PGPPrivateKey localPGPPrivateKey = localPGPSecretKey.extractPrivateKey(paramArrayOfChar, "BC");
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(localPGPSecretKey.getPublicKey().getAlgorithm(), 2, "BC");
    localPGPSignatureGenerator.initSign(0, localPGPPrivateKey);
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    FileInputStream localFileInputStream = new FileInputStream(paramString);
    int i = 0;
    while ((i = localFileInputStream.read()) >= 0) {
      localPGPSignatureGenerator.update((byte)i);
    }
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
    paramOutputStream.close();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    FileInputStream localFileInputStream;
    Object localObject;
    if (paramArrayOfString[0].equals("-s"))
    {
      if (paramArrayOfString[1].equals("-a"))
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[3]);
        localObject = new FileOutputStream(paramArrayOfString[2] + ".asc");
        createSignature(paramArrayOfString[2], localFileInputStream, (OutputStream)localObject, paramArrayOfString[4].toCharArray(), true);
      }
      else
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[2]);
        localObject = new FileOutputStream(paramArrayOfString[1] + ".bpg");
        createSignature(paramArrayOfString[1], localFileInputStream, (OutputStream)localObject, paramArrayOfString[3].toCharArray(), false);
      }
    }
    else if (paramArrayOfString[0].equals("-v"))
    {
      localFileInputStream = new FileInputStream(paramArrayOfString[2]);
      localObject = new FileInputStream(paramArrayOfString[3]);
      verifySignature(paramArrayOfString[1], localFileInputStream, (InputStream)localObject);
    }
    else
    {
      System.err.println("usage: DetachedSignatureProcessor [-s [-a] file keyfile passPhrase]|[-v file sigFile keyFile]");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\DetachedSignatureProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */