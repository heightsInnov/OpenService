package org.bouncycastle.openpgp.examples;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPBEEncryptedData;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.util.encoders.Hex;

public class ByteArrayHandler
{
  public static byte[] decrypt(byte[] paramArrayOfByte, char[] paramArrayOfChar)
    throws IOException, PGPException, NoSuchProviderException
  {
    Object localObject1 = new ByteArrayInputStream(paramArrayOfByte);
    localObject1 = PGPUtil.getDecoderStream((InputStream)localObject1);
    PGPObjectFactory localPGPObjectFactory1 = new PGPObjectFactory((InputStream)localObject1);
    PGPEncryptedDataList localPGPEncryptedDataList = null;
    Object localObject2 = localPGPObjectFactory1.nextObject();
    if ((localObject2 instanceof PGPEncryptedDataList)) {
      localPGPEncryptedDataList = (PGPEncryptedDataList)localObject2;
    } else {
      localPGPEncryptedDataList = (PGPEncryptedDataList)localPGPObjectFactory1.nextObject();
    }
    PGPPBEEncryptedData localPGPPBEEncryptedData = (PGPPBEEncryptedData)localPGPEncryptedDataList.get(0);
    InputStream localInputStream1 = localPGPPBEEncryptedData.getDataStream(paramArrayOfChar, "BC");
    PGPObjectFactory localPGPObjectFactory2 = new PGPObjectFactory(localInputStream1);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory2.nextObject();
    localPGPObjectFactory2 = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory2.nextObject();
    InputStream localInputStream2 = localPGPLiteralData.getInputStream();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = localInputStream2.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    localByteArrayOutputStream.close();
    return arrayOfByte;
  }
  
  public static byte[] encrypt(byte[] paramArrayOfByte, char[] paramArrayOfChar, String paramString, int paramInt, boolean paramBoolean)
    throws IOException, PGPException, NoSuchProviderException
  {
    if (paramString == null) {
      paramString = "_CONSOLE";
    }
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    Object localObject = localByteArrayOutputStream1;
    if (paramBoolean) {
      localObject = new ArmoredOutputStream((OutputStream)localObject);
    }
    ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(1);
    OutputStream localOutputStream1 = localPGPCompressedDataGenerator.open(localByteArrayOutputStream2);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream2 = localPGPLiteralDataGenerator.open(localOutputStream1, 'b', paramString, paramArrayOfByte.length, new Date());
    localOutputStream2.write(paramArrayOfByte);
    localPGPLiteralDataGenerator.close();
    localPGPCompressedDataGenerator.close();
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = new PGPEncryptedDataGenerator(paramInt, new SecureRandom(), "BC");
    localPGPEncryptedDataGenerator.addMethod(paramArrayOfChar);
    byte[] arrayOfByte = localByteArrayOutputStream2.toByteArray();
    OutputStream localOutputStream3 = localPGPEncryptedDataGenerator.open((OutputStream)localObject, arrayOfByte.length);
    localOutputStream3.write(arrayOfByte);
    localOutputStream3.close();
    return localByteArrayOutputStream1.toByteArray();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    String str = "Dick Beck";
    char[] arrayOfChar = str.toCharArray();
    byte[] arrayOfByte1 = "Hello world".getBytes();
    System.out.println("Starting PGP test");
    byte[] arrayOfByte2 = encrypt(arrayOfByte1, arrayOfChar, "iway", 3, true);
    System.out.println("\nencrypted data = '" + new String(arrayOfByte2) + "'");
    byte[] arrayOfByte3 = decrypt(arrayOfByte2, arrayOfChar);
    System.out.println("\ndecrypted data = '" + new String(arrayOfByte3) + "'");
    arrayOfByte2 = encrypt(arrayOfByte1, arrayOfChar, "iway", 9, false);
    System.out.println("\nencrypted data = '" + new String(Hex.encode(arrayOfByte2)) + "'");
    arrayOfByte3 = decrypt(arrayOfByte2, arrayOfChar);
    System.out.println("\ndecrypted data = '" + new String(arrayOfByte3) + "'");
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\ByteArrayHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */