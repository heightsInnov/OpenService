package org.bouncycastle.openpgp.examples;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.Security;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.sig.NotationData;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import org.bouncycastle.openpgp.PGPUtil;

public class DirectKeySignature
{
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    Object localObject1;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    if (paramArrayOfString.length == 1)
    {
      localObject1 = new PGPPublicKeyRing(PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[0])));
      localObject2 = ((PGPPublicKeyRing)localObject1).getPublicKey();
      localObject3 = ((PGPPublicKey)localObject2).getSignaturesOfType(31);
      while (((Iterator)localObject3).hasNext())
      {
        localObject4 = (PGPSignature)((Iterator)localObject3).next();
        System.out.println("Signature date is: " + ((PGPSignature)localObject4).getHashedSubPackets().getSignatureCreationTime());
        localObject5 = ((PGPSignature)localObject4).getHashedSubPackets().getNotationDataOccurences();
        for (int i = 0; i < localObject5.length; i++) {
          System.out.println("Found Notaion named '" + localObject5[i].getNotationName() + "' with content '" + localObject5[i].getNotationValue() + "'.");
        }
      }
    }
    else if (paramArrayOfString.length == 5)
    {
      localObject1 = new PGPSecretKeyRing(PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[0])));
      localObject2 = paramArrayOfString[1];
      localObject3 = new PGPPublicKeyRing(PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[2])));
      localObject4 = paramArrayOfString[3];
      localObject5 = paramArrayOfString[4];
      PGPPublicKeyRing localPGPPublicKeyRing = null;
      localPGPPublicKeyRing = new PGPPublicKeyRing(new ByteArrayInputStream(signPublicKey(((PGPSecretKeyRing)localObject1).getSecretKey(), (String)localObject2, ((PGPPublicKeyRing)localObject3).getPublicKey(), (String)localObject4, (String)localObject5, true)));
      localObject3 = localPGPPublicKeyRing;
      ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(new FileOutputStream("SignedKey.asc"));
      localPGPPublicKeyRing.encode(localArmoredOutputStream);
      localArmoredOutputStream.flush();
      localArmoredOutputStream.close();
    }
    else
    {
      System.err.println("usage: DirectKeySignature secretKeyFile secretKeyPass publicKeyFile(key to be signed) NotationName NotationValue");
      System.err.println("or: DirectKeySignature signedPublicKeyFile");
    }
  }
  
  private static byte[] signPublicKey(PGPSecretKey paramPGPSecretKey, String paramString1, PGPPublicKey paramPGPPublicKey, String paramString2, String paramString3, boolean paramBoolean)
    throws Exception
  {
    Object localObject = new ByteArrayOutputStream();
    if (paramBoolean) {
      localObject = new ArmoredOutputStream((OutputStream)localObject);
    }
    PGPPrivateKey localPGPPrivateKey = paramPGPSecretKey.extractPrivateKey(paramString1.toCharArray(), "BC");
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(paramPGPSecretKey.getPublicKey().getAlgorithm(), 2, "BC");
    localPGPSignatureGenerator.initSign(31, localPGPPrivateKey);
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream((OutputStream)localObject);
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream);
    PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator = new PGPSignatureSubpacketGenerator();
    boolean bool = true;
    localPGPSignatureSubpacketGenerator.setNotationData(true, bool, paramString2, paramString3);
    PGPSignatureSubpacketVector localPGPSignatureSubpacketVector = localPGPSignatureSubpacketGenerator.generate();
    localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketVector);
    localBCPGOutputStream.flush();
    return PGPPublicKey.addCertification(paramPGPPublicKey, localPGPSignatureGenerator.generate()).getEncoded();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\DirectKeySignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */