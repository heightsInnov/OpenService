package org.bouncycastle.openpgp.examples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.SignatureException;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignature;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPUtil;

public class SignedFileProcessor
{
  private static PGPSecretKey readSecretKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection = new PGPSecretKeyRingCollection(paramInputStream);
    Object localObject = null;
    Iterator localIterator1 = localPGPSecretKeyRingCollection.getKeyRings();
    while ((localObject == null) && (localIterator1.hasNext()))
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPSecretKeyRing.getSecretKeys();
      while ((localObject == null) && (localIterator2.hasNext()))
      {
        PGPSecretKey localPGPSecretKey = (PGPSecretKey)localIterator2.next();
        if (localPGPSecretKey.isSigningKey()) {
          localObject = localPGPSecretKey;
        }
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("Can't find signing key in key ring.");
    }
    return (PGPSecretKey)localObject;
  }
  
  private static void verifyFile(InputStream paramInputStream1, InputStream paramInputStream2)
    throws Exception
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramInputStream1);
    PGPCompressedData localPGPCompressedData = (PGPCompressedData)localPGPObjectFactory.nextObject();
    localPGPObjectFactory = new PGPObjectFactory(localPGPCompressedData.getDataStream());
    PGPOnePassSignatureList localPGPOnePassSignatureList = (PGPOnePassSignatureList)localPGPObjectFactory.nextObject();
    PGPOnePassSignature localPGPOnePassSignature = localPGPOnePassSignatureList.get(0);
    PGPLiteralData localPGPLiteralData = (PGPLiteralData)localPGPObjectFactory.nextObject();
    InputStream localInputStream = localPGPLiteralData.getInputStream();
    PGPPublicKeyRingCollection localPGPPublicKeyRingCollection = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(paramInputStream2));
    PGPPublicKey localPGPPublicKey = localPGPPublicKeyRingCollection.getPublicKey(localPGPOnePassSignature.getKeyID());
    FileOutputStream localFileOutputStream = new FileOutputStream(localPGPLiteralData.getFileName());
    localPGPOnePassSignature.initVerify(localPGPPublicKey, "BC");
    int i;
    while ((i = localInputStream.read()) >= 0)
    {
      localPGPOnePassSignature.update((byte)i);
      localFileOutputStream.write(i);
    }
    localFileOutputStream.close();
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    if (localPGPOnePassSignature.verify(localPGPSignatureList.get(0))) {
      System.out.println("signature verified.");
    } else {
      System.out.println("signature verification failed.");
    }
  }
  
  private static void signFile(String paramString, InputStream paramInputStream, OutputStream paramOutputStream, char[] paramArrayOfChar, boolean paramBoolean)
    throws IOException, NoSuchAlgorithmException, NoSuchProviderException, PGPException, SignatureException
  {
    if (paramBoolean) {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
    }
    PGPSecretKey localPGPSecretKey = readSecretKey(paramInputStream);
    PGPPrivateKey localPGPPrivateKey = localPGPSecretKey.extractPrivateKey(paramArrayOfChar, "BC");
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(localPGPSecretKey.getPublicKey().getAlgorithm(), 2, "BC");
    localPGPSignatureGenerator.initSign(0, localPGPPrivateKey);
    Iterator localIterator = localPGPSecretKey.getPublicKey().getUserIDs();
    if (localIterator.hasNext())
    {
      localObject = new PGPSignatureSubpacketGenerator();
      ((PGPSignatureSubpacketGenerator)localObject).setSignerUserID(false, (String)localIterator.next());
      localPGPSignatureGenerator.setHashedSubpackets(((PGPSignatureSubpacketGenerator)localObject).generate());
    }
    Object localObject = new PGPCompressedDataGenerator(2);
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(((PGPCompressedDataGenerator)localObject).open(paramOutputStream));
    localPGPSignatureGenerator.generateOnePassVersion(false).encode(localBCPGOutputStream);
    File localFile = new File(paramString);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(localBCPGOutputStream, 'b', localFile);
    FileInputStream localFileInputStream = new FileInputStream(localFile);
    int i = 0;
    while ((i = localFileInputStream.read()) >= 0)
    {
      localOutputStream.write(i);
      localPGPSignatureGenerator.update((byte)i);
    }
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
    localPGPLiteralDataGenerator.close();
    ((PGPCompressedDataGenerator)localObject).close();
    paramOutputStream.close();
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    FileInputStream localFileInputStream;
    Object localObject;
    if (paramArrayOfString[0].equals("-s"))
    {
      if (paramArrayOfString[1].equals("-a"))
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[3]);
        localObject = new FileOutputStream(paramArrayOfString[2] + ".asc");
        signFile(paramArrayOfString[2], localFileInputStream, (OutputStream)localObject, paramArrayOfString[4].toCharArray(), true);
      }
      else
      {
        localFileInputStream = new FileInputStream(paramArrayOfString[2]);
        localObject = new FileOutputStream(paramArrayOfString[1] + ".bpg");
        signFile(paramArrayOfString[1], localFileInputStream, (OutputStream)localObject, paramArrayOfString[3].toCharArray(), false);
      }
    }
    else if (paramArrayOfString[0].equals("-v"))
    {
      localFileInputStream = new FileInputStream(paramArrayOfString[1]);
      localObject = new FileInputStream(paramArrayOfString[2]);
      verifyFile(localFileInputStream, (InputStream)localObject);
    }
    else
    {
      System.err.println("usage: SignedFileProcessor -v|-s [-a] file keyfile [passPhrase]");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\SignedFileProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */