package org.bouncycastle.openpgp.examples;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.SignatureException;
import java.util.Iterator;
import org.bouncycastle.bcpg.ArmoredInputStream;
import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureGenerator;
import org.bouncycastle.openpgp.PGPSignatureList;
import org.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import org.bouncycastle.openpgp.PGPUtil;

public class ClearSignedFileProcessor
{
  private static PGPSecretKey readSecretKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection = new PGPSecretKeyRingCollection(paramInputStream);
    Object localObject = null;
    Iterator localIterator1 = localPGPSecretKeyRingCollection.getKeyRings();
    while ((localObject == null) && (localIterator1.hasNext()))
    {
      PGPSecretKeyRing localPGPSecretKeyRing = (PGPSecretKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPSecretKeyRing.getSecretKeys();
      while ((localObject == null) && (localIterator2.hasNext()))
      {
        PGPSecretKey localPGPSecretKey = (PGPSecretKey)localIterator2.next();
        if (localPGPSecretKey.isSigningKey()) {
          localObject = localPGPSecretKey;
        }
      }
    }
    if (localObject == null) {
      throw new IllegalArgumentException("Can't find signing key in key ring.");
    }
    return (PGPSecretKey)localObject;
  }
  
  private static int readInputLine(ByteArrayOutputStream paramByteArrayOutputStream, InputStream paramInputStream)
    throws IOException
  {
    paramByteArrayOutputStream.reset();
    int i = -1;
    int j;
    while ((j = paramInputStream.read()) >= 0)
    {
      paramByteArrayOutputStream.write(j);
      if ((j == 13) || (j == 10)) {
        i = readPassedEOL(paramByteArrayOutputStream, j, paramInputStream);
      }
    }
    return i;
  }
  
  private static int readInputLine(ByteArrayOutputStream paramByteArrayOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    paramByteArrayOutputStream.reset();
    int i = paramInt;
    do
    {
      paramByteArrayOutputStream.write(i);
      if ((i == 13) || (i == 10))
      {
        paramInt = readPassedEOL(paramByteArrayOutputStream, i, paramInputStream);
        break;
      }
    } while ((i = paramInputStream.read()) >= 0);
    return paramInt;
  }
  
  private static int readPassedEOL(ByteArrayOutputStream paramByteArrayOutputStream, int paramInt, InputStream paramInputStream)
    throws IOException
  {
    int i = paramInputStream.read();
    if ((paramInt == 13) && (i == 10))
    {
      paramByteArrayOutputStream.write(i);
      i = paramInputStream.read();
    }
    return i;
  }
  
  private static void verifyFile(InputStream paramInputStream1, InputStream paramInputStream2, String paramString)
    throws Exception
  {
    ArmoredInputStream localArmoredInputStream = new ArmoredInputStream(paramInputStream1);
    BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString));
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i = readInputLine(localByteArrayOutputStream, localArmoredInputStream);
    byte[] arrayOfByte = getLineSeparator();
    if ((i != -1) && (localArmoredInputStream.isClearText()))
    {
      localObject = localByteArrayOutputStream.toByteArray();
      localBufferedOutputStream.write((byte[])localObject, 0, getLengthWithoutSeperator((byte[])localObject));
      localBufferedOutputStream.write(arrayOfByte);
      while ((i != -1) && (localArmoredInputStream.isClearText()))
      {
        i = readInputLine(localByteArrayOutputStream, i, localArmoredInputStream);
        localObject = localByteArrayOutputStream.toByteArray();
        localBufferedOutputStream.write((byte[])localObject, 0, getLengthWithoutSeperator((byte[])localObject));
        localBufferedOutputStream.write(arrayOfByte);
      }
    }
    localBufferedOutputStream.close();
    Object localObject = new PGPPublicKeyRingCollection(paramInputStream2);
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(localArmoredInputStream);
    PGPSignatureList localPGPSignatureList = (PGPSignatureList)localPGPObjectFactory.nextObject();
    PGPSignature localPGPSignature = localPGPSignatureList.get(0);
    localPGPSignature.initVerify(((PGPPublicKeyRingCollection)localObject).getPublicKey(localPGPSignature.getKeyID()), "BC");
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString));
    i = readInputLine(localByteArrayOutputStream, localBufferedInputStream);
    processLine(localPGPSignature, localByteArrayOutputStream.toByteArray());
    if (i != -1) {
      do
      {
        i = readInputLine(localByteArrayOutputStream, i, localBufferedInputStream);
        localPGPSignature.update((byte)13);
        localPGPSignature.update((byte)10);
        processLine(localPGPSignature, localByteArrayOutputStream.toByteArray());
      } while (i != -1);
    }
    if (localPGPSignature.verify()) {
      System.out.println("signature verified.");
    } else {
      System.out.println("signature verification failed.");
    }
  }
  
  private static byte[] getLineSeparator()
  {
    String str = System.getProperty("line.separator");
    byte[] arrayOfByte = new byte[str.length()];
    for (int i = 0; i != arrayOfByte.length; i++) {
      arrayOfByte[i] = ((byte)str.charAt(i));
    }
    return arrayOfByte;
  }
  
  private static void signFile(String paramString1, InputStream paramInputStream, OutputStream paramOutputStream, char[] paramArrayOfChar, String paramString2)
    throws IOException, NoSuchAlgorithmException, NoSuchProviderException, PGPException, SignatureException
  {
    int i;
    if (paramString2.equals("SHA256")) {
      i = 8;
    } else if (paramString2.equals("SHA384")) {
      i = 9;
    } else if (paramString2.equals("SHA512")) {
      i = 10;
    } else if (paramString2.equals("MD5")) {
      i = 1;
    } else if (paramString2.equals("RIPEMD160")) {
      i = 3;
    } else {
      i = 2;
    }
    PGPSecretKey localPGPSecretKey = readSecretKey(paramInputStream);
    PGPPrivateKey localPGPPrivateKey = localPGPSecretKey.extractPrivateKey(paramArrayOfChar, "BC");
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(localPGPSecretKey.getPublicKey().getAlgorithm(), i, "BC");
    PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator = new PGPSignatureSubpacketGenerator();
    localPGPSignatureGenerator.initSign(1, localPGPPrivateKey);
    Iterator localIterator = localPGPSecretKey.getPublicKey().getUserIDs();
    if (localIterator.hasNext())
    {
      localPGPSignatureSubpacketGenerator.setSignerUserID(false, (String)localIterator.next());
      localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketGenerator.generate());
    }
    FileInputStream localFileInputStream = new FileInputStream(paramString1);
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(paramOutputStream);
    localArmoredOutputStream.beginClearText(i);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int j = readInputLine(localByteArrayOutputStream, localFileInputStream);
    processLine(localArmoredOutputStream, localPGPSignatureGenerator, localByteArrayOutputStream.toByteArray());
    if (j != -1) {
      do
      {
        j = readInputLine(localByteArrayOutputStream, j, localFileInputStream);
        localPGPSignatureGenerator.update((byte)13);
        localPGPSignatureGenerator.update((byte)10);
        processLine(localArmoredOutputStream, localPGPSignatureGenerator, localByteArrayOutputStream.toByteArray());
      } while (j != -1);
    }
    localArmoredOutputStream.endClearText();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localArmoredOutputStream);
    localPGPSignatureGenerator.generate().encode(localBCPGOutputStream);
    localArmoredOutputStream.close();
  }
  
  private static void processLine(PGPSignature paramPGPSignature, byte[] paramArrayOfByte)
    throws SignatureException, IOException
  {
    int i = getLengthWithoutWhiteSpace(paramArrayOfByte);
    if (i > 0) {
      paramPGPSignature.update(paramArrayOfByte, 0, i);
    }
  }
  
  private static void processLine(OutputStream paramOutputStream, PGPSignatureGenerator paramPGPSignatureGenerator, byte[] paramArrayOfByte)
    throws SignatureException, IOException
  {
    int i = getLengthWithoutWhiteSpace(paramArrayOfByte);
    if (i > 0) {
      paramPGPSignatureGenerator.update(paramArrayOfByte, 0, i);
    }
    paramOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  private static int getLengthWithoutSeperator(byte[] paramArrayOfByte)
  {
    for (int i = paramArrayOfByte.length - 1; (i >= 0) && (isLineEnding(paramArrayOfByte[i])); i--) {}
    return i + 1;
  }
  
  private static boolean isLineEnding(byte paramByte)
  {
    return (paramByte == 13) || (paramByte == 10);
  }
  
  private static int getLengthWithoutWhiteSpace(byte[] paramArrayOfByte)
  {
    for (int i = paramArrayOfByte.length - 1; (i >= 0) && (isWhiteSpace(paramArrayOfByte[i])); i--) {}
    return i + 1;
  }
  
  private static boolean isWhiteSpace(byte paramByte)
  {
    return (paramByte == 13) || (paramByte == 10) || (paramByte == 9) || (paramByte == 32);
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Security.addProvider(new BouncyCastleProvider());
    Object localObject1;
    Object localObject2;
    if (paramArrayOfString[0].equals("-s"))
    {
      localObject1 = PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[2]));
      localObject2 = new FileOutputStream(paramArrayOfString[1] + ".asc");
      if (paramArrayOfString.length == 4) {
        signFile(paramArrayOfString[1], (InputStream)localObject1, (OutputStream)localObject2, paramArrayOfString[3].toCharArray(), "SHA1");
      } else {
        signFile(paramArrayOfString[1], (InputStream)localObject1, (OutputStream)localObject2, paramArrayOfString[3].toCharArray(), paramArrayOfString[4]);
      }
    }
    else if (paramArrayOfString[0].equals("-v"))
    {
      if (paramArrayOfString[1].indexOf(".asc") < 0)
      {
        System.err.println("file needs to end in \".asc\"");
        System.exit(1);
      }
      localObject1 = new FileInputStream(paramArrayOfString[1]);
      localObject2 = PGPUtil.getDecoderStream(new FileInputStream(paramArrayOfString[2]));
      verifyFile((InputStream)localObject1, (InputStream)localObject2, paramArrayOfString[1].substring(0, paramArrayOfString[1].length() - 4));
    }
    else
    {
      System.err.println("usage: ClearSignedFileProcessor [-s file keyfile passPhrase]|[-v sigFile keyFile]");
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\examples\ClearSignedFileProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */