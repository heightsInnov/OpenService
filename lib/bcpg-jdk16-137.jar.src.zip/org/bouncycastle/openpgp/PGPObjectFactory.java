package org.bouncycastle.openpgp;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.bcpg.BCPGInputStream;

public class PGPObjectFactory
{
  BCPGInputStream in;
  
  public PGPObjectFactory(InputStream paramInputStream)
  {
    this.in = new BCPGInputStream(paramInputStream);
  }
  
  public PGPObjectFactory(byte[] paramArrayOfByte)
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public Object nextObject()
    throws IOException
  {
    ArrayList localArrayList;
    switch (this.in.nextPacketTag())
    {
    case -1: 
      return null;
    case 2: 
      localArrayList = new ArrayList();
      while (this.in.nextPacketTag() == 2) {
        try
        {
          localArrayList.add(new PGPSignature(this.in));
        }
        catch (PGPException localPGPException1)
        {
          throw new IOException("can't create signature object: " + localPGPException1);
        }
      }
      return new PGPSignatureList((PGPSignature[])localArrayList.toArray(new PGPSignature[localArrayList.size()]));
    case 5: 
      try
      {
        return new PGPSecretKeyRing(this.in);
      }
      catch (PGPException localPGPException2)
      {
        throw new IOException("can't create secret key object: " + localPGPException2);
      }
    case 6: 
      return new PGPPublicKeyRing(this.in);
    case 8: 
      return new PGPCompressedData(this.in);
    case 11: 
      return new PGPLiteralData(this.in);
    case 1: 
    case 3: 
      return new PGPEncryptedDataList(this.in);
    case 4: 
      localArrayList = new ArrayList();
      while (this.in.nextPacketTag() == 4) {
        try
        {
          localArrayList.add(new PGPOnePassSignature(this.in));
        }
        catch (PGPException localPGPException3)
        {
          throw new IOException("can't create one pass signature object: " + localPGPException3);
        }
      }
      return new PGPOnePassSignatureList((PGPOnePassSignature[])localArrayList.toArray(new PGPOnePassSignature[localArrayList.size()]));
    case 10: 
      return new PGPMarker(this.in);
    case 60: 
    case 61: 
    case 62: 
    case 63: 
      return this.in.readPacket();
    }
    throw new IOException("unknown object in stream " + this.in.nextPacketTag());
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */