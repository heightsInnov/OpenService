package org.bouncycastle.openpgp;

import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import org.bouncycastle.bcpg.InputStreamPacket;
import org.bouncycastle.bcpg.SymmetricEncIntegrityPacket;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;

public abstract class PGPEncryptedData
  implements SymmetricKeyAlgorithmTags
{
  InputStreamPacket encData;
  InputStream encStream;
  TruncatedStream truncStream;
  
  PGPEncryptedData(InputStreamPacket paramInputStreamPacket)
  {
    this.encData = paramInputStreamPacket;
  }
  
  public InputStream getInputStream()
  {
    return this.encData.getInputStream();
  }
  
  public boolean isIntegrityProtected()
  {
    return this.encData instanceof SymmetricEncIntegrityPacket;
  }
  
  public boolean verify()
    throws PGPException, IOException
  {
    if (!isIntegrityProtected()) {
      throw new PGPException("data not integrity protected.");
    }
    DigestInputStream localDigestInputStream = (DigestInputStream)this.encStream;
    while (this.encStream.read() >= 0) {}
    MessageDigest localMessageDigest = localDigestInputStream.getMessageDigest();
    int[] arrayOfInt = this.truncStream.getLookAhead();
    localMessageDigest.update((byte)arrayOfInt[0]);
    localMessageDigest.update((byte)arrayOfInt[1]);
    byte[] arrayOfByte1 = localMessageDigest.digest();
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    for (int i = 0; i != arrayOfByte2.length; i++) {
      arrayOfByte2[i] = ((byte)arrayOfInt[(i + 2)]);
    }
    return MessageDigest.isEqual(arrayOfByte1, arrayOfByte2);
  }
  
  protected class TruncatedStream
    extends InputStream
  {
    int[] lookAhead = new int[22];
    int bufPtr;
    InputStream in;
    
    TruncatedStream(InputStream paramInputStream)
      throws IOException
    {
      for (int i = 0; i != this.lookAhead.length; i++) {
        this.lookAhead[i] = paramInputStream.read();
      }
      this.bufPtr = 0;
      this.in = paramInputStream;
    }
    
    public int read()
      throws IOException
    {
      int i = this.in.read();
      if (i >= 0)
      {
        int j = this.lookAhead[this.bufPtr];
        this.lookAhead[this.bufPtr] = i;
        this.bufPtr = ((this.bufPtr + 1) % this.lookAhead.length);
        return j;
      }
      return -1;
    }
    
    int[] getLookAhead()
    {
      int[] arrayOfInt = new int[this.lookAhead.length];
      int i = 0;
      for (int j = this.bufPtr; j != this.lookAhead.length; j++) {
        arrayOfInt[(i++)] = this.lookAhead[j];
      }
      for (j = 0; j != this.bufPtr; j++) {
        arrayOfInt[(i++)] = this.lookAhead[j];
      }
      return arrayOfInt;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPEncryptedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */