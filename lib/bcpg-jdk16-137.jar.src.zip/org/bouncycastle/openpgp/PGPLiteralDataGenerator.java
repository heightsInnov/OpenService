package org.bouncycastle.openpgp;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import org.bouncycastle.bcpg.BCPGOutputStream;

public class PGPLiteralDataGenerator
  implements StreamGenerator
{
  public static final char BINARY = 'b';
  public static final char TEXT = 't';
  public static final String CONSOLE = "_CONSOLE";
  public static final Date NOW = PGPLiteralData.NOW;
  private BCPGOutputStream pkOut;
  private boolean oldFormat = false;
  
  public PGPLiteralDataGenerator() {}
  
  public PGPLiteralDataGenerator(boolean paramBoolean)
  {
    this.oldFormat = paramBoolean;
  }
  
  private void writeHeader(OutputStream paramOutputStream, char paramChar, String paramString, long paramLong)
    throws IOException
  {
    paramOutputStream.write(paramChar);
    paramOutputStream.write((byte)paramString.length());
    for (int i = 0; i != paramString.length(); i++) {
      paramOutputStream.write(paramString.charAt(i));
    }
    long l = paramLong / 1000L;
    paramOutputStream.write((byte)(int)(l >> 24));
    paramOutputStream.write((byte)(int)(l >> 16));
    paramOutputStream.write((byte)(int)(l >> 8));
    paramOutputStream.write((byte)(int)l);
  }
  
  public OutputStream open(OutputStream paramOutputStream, char paramChar, String paramString, long paramLong, Date paramDate)
    throws IOException
  {
    if (this.pkOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    this.pkOut = new BCPGOutputStream(paramOutputStream, 11, paramLong + 2L + paramString.length() + 4L, this.oldFormat);
    writeHeader(this.pkOut, paramChar, paramString, paramDate.getTime());
    return new WrappedGeneratorStream(this.pkOut, this);
  }
  
  public OutputStream open(OutputStream paramOutputStream, char paramChar, String paramString, Date paramDate, byte[] paramArrayOfByte)
    throws IOException
  {
    if (this.pkOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    this.pkOut = new BCPGOutputStream(paramOutputStream, 11, paramArrayOfByte);
    writeHeader(this.pkOut, paramChar, paramString, paramDate.getTime());
    return new WrappedGeneratorStream(this.pkOut, this);
  }
  
  public OutputStream open(OutputStream paramOutputStream, char paramChar, File paramFile)
    throws IOException
  {
    if (this.pkOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    this.pkOut = new BCPGOutputStream(paramOutputStream, 11, paramFile.length() + 2L + paramFile.getName().length() + 4L, this.oldFormat);
    writeHeader(this.pkOut, paramChar, paramFile.getName(), paramFile.lastModified());
    return new WrappedGeneratorStream(this.pkOut, this);
  }
  
  public void close()
    throws IOException
  {
    if (this.pkOut != null)
    {
      this.pkOut.finish();
      this.pkOut.flush();
      this.pkOut = null;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPLiteralDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */