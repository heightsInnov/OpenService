package org.bouncycastle.openpgp;

public abstract interface PGPKeyFlags
{
  public static final int CAN_CERTIFY = 1;
  public static final int CAN_SIGN = 2;
  public static final int CAN_ENCRYPT_COMMS = 4;
  public static final int CAN_ENCRYPT_STORAGE = 8;
  public static final int MAYBE_SPLIT = 16;
  public static final int MAYBE_SHARED = 128;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPKeyFlags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */