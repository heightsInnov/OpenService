package org.bouncycastle.openpgp;

public class PGPDataValidationException
  extends PGPException
{
  public PGPDataValidationException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPDataValidationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */