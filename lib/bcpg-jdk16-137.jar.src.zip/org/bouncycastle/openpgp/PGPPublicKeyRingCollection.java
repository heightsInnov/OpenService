package org.bouncycastle.openpgp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bouncycastle.bcpg.BCPGOutputStream;

public class PGPPublicKeyRingCollection
{
  private Map pubRings = new HashMap();
  private List order = new ArrayList();
  
  private PGPPublicKeyRingCollection(Map paramMap, List paramList)
  {
    this.pubRings = paramMap;
    this.order = paramList;
  }
  
  public PGPPublicKeyRingCollection(byte[] paramArrayOfByte)
    throws IOException, PGPException
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }
  
  public PGPPublicKeyRingCollection(InputStream paramInputStream)
    throws IOException, PGPException
  {
    PGPObjectFactory localPGPObjectFactory = new PGPObjectFactory(paramInputStream);
    Object localObject;
    while ((localObject = localPGPObjectFactory.nextObject()) != null)
    {
      if (!(localObject instanceof PGPPublicKeyRing)) {
        throw new PGPException(localObject.getClass().getName() + " found where PGPPublicKeyRing expected");
      }
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localObject;
      Long localLong = new Long(localPGPPublicKeyRing.getPublicKey().getKeyID());
      this.pubRings.put(localLong, localPGPPublicKeyRing);
      this.order.add(localLong);
    }
  }
  
  public PGPPublicKeyRingCollection(Collection paramCollection)
    throws IOException, PGPException
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator.next();
      Long localLong = new Long(localPGPPublicKeyRing.getPublicKey().getKeyID());
      this.pubRings.put(localLong, localPGPPublicKeyRing);
      this.order.add(localLong);
    }
  }
  
  public int size()
  {
    return this.order.size();
  }
  
  public Iterator getKeyRings()
  {
    return this.pubRings.values().iterator();
  }
  
  public Iterator getKeyRings(String paramString, boolean paramBoolean)
    throws PGPException
  {
    Iterator localIterator1 = getKeyRings();
    ArrayList localArrayList = new ArrayList();
    while (localIterator1.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator1.next();
      Iterator localIterator2 = localPGPPublicKeyRing.getPublicKey().getUserIDs();
      while (localIterator2.hasNext()) {
        if (paramBoolean)
        {
          if (((String)localIterator2.next()).indexOf(paramString) > -1) {
            localArrayList.add(localPGPPublicKeyRing);
          }
        }
        else if (localIterator2.next().equals(paramString)) {
          localArrayList.add(localPGPPublicKeyRing);
        }
      }
    }
    return localArrayList.iterator();
  }
  
  public Iterator getKeyRings(String paramString)
    throws PGPException
  {
    return getKeyRings(paramString, false);
  }
  
  public PGPPublicKey getPublicKey(long paramLong)
    throws PGPException
  {
    Iterator localIterator = getKeyRings();
    while (localIterator.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator.next();
      PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey(paramLong);
      if (localPGPPublicKey != null) {
        return localPGPPublicKey;
      }
    }
    return null;
  }
  
  public PGPPublicKeyRing getPublicKeyRing(long paramLong)
    throws PGPException
  {
    Long localLong = new Long(paramLong);
    if (this.pubRings.containsKey(localLong)) {
      return (PGPPublicKeyRing)this.pubRings.get(localLong);
    }
    Iterator localIterator = getKeyRings();
    while (localIterator.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)localIterator.next();
      PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey(paramLong);
      if (localPGPPublicKey != null) {
        return localPGPPublicKeyRing;
      }
    }
    return null;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    Iterator localIterator = this.order.iterator();
    while (localIterator.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)this.pubRings.get(localIterator.next());
      localPGPPublicKeyRing.encode(localBCPGOutputStream);
    }
  }
  
  public static PGPPublicKeyRingCollection addPublicKeyRing(PGPPublicKeyRingCollection paramPGPPublicKeyRingCollection, PGPPublicKeyRing paramPGPPublicKeyRing)
  {
    Long localLong = new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID());
    if (paramPGPPublicKeyRingCollection.pubRings.containsKey(localLong)) {
      throw new IllegalArgumentException("Collection already contains a key with a keyID for the passed in ring.");
    }
    HashMap localHashMap = new HashMap(paramPGPPublicKeyRingCollection.pubRings);
    ArrayList localArrayList = new ArrayList(paramPGPPublicKeyRingCollection.order);
    localHashMap.put(localLong, paramPGPPublicKeyRing);
    localArrayList.add(localLong);
    return new PGPPublicKeyRingCollection(localHashMap, localArrayList);
  }
  
  public static PGPPublicKeyRingCollection removePublicKeyRing(PGPPublicKeyRingCollection paramPGPPublicKeyRingCollection, PGPPublicKeyRing paramPGPPublicKeyRing)
  {
    Long localLong1 = new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID());
    if (!paramPGPPublicKeyRingCollection.pubRings.containsKey(localLong1)) {
      throw new IllegalArgumentException("Collection does not contain a key with a keyID for the passed in ring.");
    }
    HashMap localHashMap = new HashMap(paramPGPPublicKeyRingCollection.pubRings);
    ArrayList localArrayList = new ArrayList(paramPGPPublicKeyRingCollection.order);
    localHashMap.remove(localLong1);
    for (int i = 0; i < localArrayList.size(); i++)
    {
      Long localLong2 = (Long)localArrayList.get(i);
      if (localLong2.longValue() == localLong1.longValue())
      {
        localArrayList.remove(i);
        break;
      }
    }
    return new PGPPublicKeyRingCollection(localHashMap, localArrayList);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPublicKeyRingCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */