package org.bouncycastle.openpgp;

import org.bouncycastle.bcpg.UserAttributeSubpacket;
import org.bouncycastle.bcpg.attr.ImageAttribute;

public class PGPUserAttributeSubpacketVector
{
  UserAttributeSubpacket[] packets;
  
  PGPUserAttributeSubpacketVector(UserAttributeSubpacket[] paramArrayOfUserAttributeSubpacket)
  {
    this.packets = paramArrayOfUserAttributeSubpacket;
  }
  
  public UserAttributeSubpacket getSubpacket(int paramInt)
  {
    for (int i = 0; i != this.packets.length; i++) {
      if (this.packets[i].getType() == paramInt) {
        return this.packets[i];
      }
    }
    return null;
  }
  
  public ImageAttribute getImageAttribute()
  {
    UserAttributeSubpacket localUserAttributeSubpacket = getSubpacket(1);
    if (localUserAttributeSubpacket == null) {
      return null;
    }
    return (ImageAttribute)localUserAttributeSubpacket;
  }
  
  UserAttributeSubpacket[] toSubpacketArray()
  {
    return this.packets;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if ((paramObject instanceof PGPUserAttributeSubpacketVector))
    {
      PGPUserAttributeSubpacketVector localPGPUserAttributeSubpacketVector = (PGPUserAttributeSubpacketVector)paramObject;
      if (localPGPUserAttributeSubpacketVector.packets.length != this.packets.length) {
        return false;
      }
      for (int i = 0; i != this.packets.length; i++) {
        if (!localPGPUserAttributeSubpacketVector.packets[i].equals(this.packets[i])) {
          return false;
        }
      }
      return true;
    }
    return false;
  }
  
  public int hashCode()
  {
    int i = 0;
    for (int j = 0; j != this.packets.length; j++) {
      i ^= this.packets[j].hashCode();
    }
    return i;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPUserAttributeSubpacketVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */