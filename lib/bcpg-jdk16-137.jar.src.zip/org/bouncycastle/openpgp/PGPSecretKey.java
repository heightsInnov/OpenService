package org.bouncycastle.openpgp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.DSAPrivateKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.BCPGObject;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.ContainedPacket;
import org.bouncycastle.bcpg.DSAPublicBCPGKey;
import org.bouncycastle.bcpg.DSASecretBCPGKey;
import org.bouncycastle.bcpg.ElGamalPublicBCPGKey;
import org.bouncycastle.bcpg.ElGamalSecretBCPGKey;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.RSAPublicBCPGKey;
import org.bouncycastle.bcpg.RSASecretBCPGKey;
import org.bouncycastle.bcpg.S2K;
import org.bouncycastle.bcpg.SecretKeyPacket;
import org.bouncycastle.bcpg.SecretSubkeyPacket;
import org.bouncycastle.bcpg.TrustPacket;
import org.bouncycastle.bcpg.UserAttributePacket;
import org.bouncycastle.bcpg.UserIDPacket;
import org.bouncycastle.jce.interfaces.ElGamalPrivateKey;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;
import org.bouncycastle.jce.spec.ElGamalPrivateKeySpec;

public class PGPSecretKey
{
  SecretKeyPacket secret;
  TrustPacket trust;
  List keySigs;
  List ids;
  List idTrusts;
  List idSigs;
  PGPPublicKey pub;
  List subSigs = null;
  
  private PGPSecretKey(SecretKeyPacket paramSecretKeyPacket, TrustPacket paramTrustPacket, List paramList1, List paramList2, List paramList3, List paramList4, PGPPublicKey paramPGPPublicKey)
  {
    this.secret = paramSecretKeyPacket;
    this.trust = paramTrustPacket;
    this.keySigs = paramList1;
    this.ids = paramList2;
    this.idTrusts = paramList3;
    this.idSigs = paramList4;
    this.pub = paramPGPPublicKey;
  }
  
  private PGPSecretKey(SecretKeyPacket paramSecretKeyPacket, TrustPacket paramTrustPacket, List paramList, PGPPublicKey paramPGPPublicKey)
  {
    this.secret = paramSecretKeyPacket;
    this.trust = paramTrustPacket;
    this.subSigs = paramList;
    this.pub = paramPGPPublicKey;
  }
  
  PGPSecretKey(SecretKeyPacket paramSecretKeyPacket, TrustPacket paramTrustPacket, List paramList1, List paramList2, List paramList3, List paramList4)
    throws IOException
  {
    this.secret = paramSecretKeyPacket;
    this.trust = paramTrustPacket;
    this.keySigs = paramList1;
    this.ids = paramList2;
    this.idTrusts = paramList3;
    this.idSigs = paramList4;
    this.pub = new PGPPublicKey(paramSecretKeyPacket.getPublicKeyPacket(), paramTrustPacket, paramList1, paramList2, paramList3, paramList4);
  }
  
  PGPSecretKey(SecretKeyPacket paramSecretKeyPacket, TrustPacket paramTrustPacket, List paramList)
    throws IOException
  {
    this.secret = paramSecretKeyPacket;
    this.trust = paramTrustPacket;
    this.subSigs = paramList;
    this.pub = new PGPPublicKey(paramSecretKeyPacket.getPublicKeyPacket(), paramTrustPacket, paramList);
  }
  
  PGPSecretKey(PGPKeyPair paramPGPKeyPair, TrustPacket paramTrustPacket, List paramList, int paramInt, char[] paramArrayOfChar, boolean paramBoolean, SecureRandom paramSecureRandom, String paramString)
    throws PGPException, NoSuchProviderException
  {
    this(paramPGPKeyPair, paramInt, paramArrayOfChar, paramBoolean, paramSecureRandom, paramString);
    this.secret = new SecretSubkeyPacket(this.secret.getPublicKeyPacket(), this.secret.getEncAlgorithm(), this.secret.getS2KUsage(), this.secret.getS2K(), this.secret.getIV(), this.secret.getSecretKeyData());
    this.trust = paramTrustPacket;
    this.pub = new PGPPublicKey(paramPGPKeyPair.getPublicKey(), paramTrustPacket, paramList);
  }
  
  PGPSecretKey(PGPKeyPair paramPGPKeyPair, int paramInt, char[] paramArrayOfChar, boolean paramBoolean, SecureRandom paramSecureRandom, String paramString)
    throws PGPException, NoSuchProviderException
  {
    PublicKeyPacket localPublicKeyPacket = paramPGPKeyPair.getPublicKey().publicPk;
    Object localObject1;
    switch (paramPGPKeyPair.getPublicKey().getAlgorithm())
    {
    case 1: 
    case 2: 
    case 3: 
      localObject2 = (RSAPrivateCrtKey)paramPGPKeyPair.getPrivateKey().getKey();
      localObject1 = new RSASecretBCPGKey(((RSAPrivateCrtKey)localObject2).getPrivateExponent(), ((RSAPrivateCrtKey)localObject2).getPrimeP(), ((RSAPrivateCrtKey)localObject2).getPrimeQ());
      break;
    case 17: 
      localObject3 = (DSAPrivateKey)paramPGPKeyPair.getPrivateKey().getKey();
      localObject1 = new DSASecretBCPGKey(((DSAPrivateKey)localObject3).getX());
      break;
    case 16: 
    case 20: 
      ElGamalPrivateKey localElGamalPrivateKey = (ElGamalPrivateKey)paramPGPKeyPair.getPrivateKey().getKey();
      localObject1 = new ElGamalSecretBCPGKey(localElGamalPrivateKey.getX());
      break;
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
    case 15: 
    case 18: 
    case 19: 
    default: 
      throw new PGPException("unknown key class");
    }
    Object localObject2 = PGPUtil.getSymmetricCipherName(paramInt);
    Object localObject3 = null;
    if (localObject2 != null) {
      try
      {
        localObject3 = Cipher.getInstance((String)localObject2 + "/CFB/NoPadding", paramString);
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw localNoSuchProviderException;
      }
      catch (Exception localException1)
      {
        throw new PGPException("Exception creating cipher", localException1);
      }
    }
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      localBCPGOutputStream.writeObject((BCPGObject)localObject1);
      byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
      localBCPGOutputStream.write(checksum(paramBoolean, arrayOfByte1, arrayOfByte1.length));
      if (localObject3 != null)
      {
        byte[] arrayOfByte2 = new byte[8];
        paramSecureRandom.nextBytes(arrayOfByte2);
        S2K localS2K = new S2K(2, arrayOfByte2, 96);
        SecretKey localSecretKey = PGPUtil.makeKeyFromPassPhrase(paramInt, localS2K, paramArrayOfChar, paramString);
        ((Cipher)localObject3).init(1, localSecretKey, paramSecureRandom);
        arrayOfByte2 = ((Cipher)localObject3).getIV();
        byte[] arrayOfByte3 = ((Cipher)localObject3).doFinal(localByteArrayOutputStream.toByteArray());
        if (paramBoolean) {
          this.secret = new SecretKeyPacket(localPublicKeyPacket, paramInt, 254, localS2K, arrayOfByte2, arrayOfByte3);
        } else {
          this.secret = new SecretKeyPacket(localPublicKeyPacket, paramInt, 255, localS2K, arrayOfByte2, arrayOfByte3);
        }
        this.trust = null;
      }
      else
      {
        this.secret = new SecretKeyPacket(localPublicKeyPacket, paramInt, null, null, localByteArrayOutputStream.toByteArray());
        this.trust = null;
      }
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException2)
    {
      throw new PGPException("Exception encrypting key", localException2);
    }
    this.keySigs = new ArrayList();
  }
  
  public PGPSecretKey(int paramInt1, PGPKeyPair paramPGPKeyPair, String paramString1, int paramInt2, char[] paramArrayOfChar, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this(paramInt1, paramPGPKeyPair, paramString1, paramInt2, paramArrayOfChar, false, paramPGPSignatureSubpacketVector1, paramPGPSignatureSubpacketVector2, paramSecureRandom, paramString2);
  }
  
  public PGPSecretKey(int paramInt1, PGPKeyPair paramPGPKeyPair, String paramString1, int paramInt2, char[] paramArrayOfChar, boolean paramBoolean, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this(paramPGPKeyPair, paramInt2, paramArrayOfChar, paramBoolean, paramSecureRandom, paramString2);
    try
    {
      this.trust = null;
      this.ids = new ArrayList();
      this.ids.add(paramString1);
      this.idTrusts = new ArrayList();
      this.idTrusts.add(null);
      this.idSigs = new ArrayList();
      PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(paramPGPKeyPair.getPublicKey().getAlgorithm(), 2, paramString2);
      localPGPSignatureGenerator.initSign(paramInt1, paramPGPKeyPair.getPrivateKey());
      localPGPSignatureGenerator.setHashedSubpackets(paramPGPSignatureSubpacketVector1);
      localPGPSignatureGenerator.setUnhashedSubpackets(paramPGPSignatureSubpacketVector2);
      PGPSignature localPGPSignature = localPGPSignatureGenerator.generateCertification(paramString1, paramPGPKeyPair.getPublicKey());
      this.pub = PGPPublicKey.addCertification(paramPGPKeyPair.getPublicKey(), paramString1, localPGPSignature);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(localPGPSignature);
      this.idSigs.add(localArrayList);
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("Exception encrypting key", localException);
    }
  }
  
  public PGPSecretKey(int paramInt1, int paramInt2, PublicKey paramPublicKey, PrivateKey paramPrivateKey, Date paramDate, String paramString1, int paramInt3, char[] paramArrayOfChar, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this(paramInt1, new PGPKeyPair(paramInt2, paramPublicKey, paramPrivateKey, paramDate, paramString2), paramString1, paramInt3, paramArrayOfChar, paramPGPSignatureSubpacketVector1, paramPGPSignatureSubpacketVector2, paramSecureRandom, paramString2);
  }
  
  public PGPSecretKey(int paramInt1, int paramInt2, PublicKey paramPublicKey, PrivateKey paramPrivateKey, Date paramDate, String paramString1, int paramInt3, char[] paramArrayOfChar, boolean paramBoolean, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this(paramInt1, new PGPKeyPair(paramInt2, paramPublicKey, paramPrivateKey, paramDate, paramString2), paramString1, paramInt3, paramArrayOfChar, paramBoolean, paramPGPSignatureSubpacketVector1, paramPGPSignatureSubpacketVector2, paramSecureRandom, paramString2);
  }
  
  public boolean isSigningKey()
  {
    int i = this.pub.getAlgorithm();
    return (i == 1) || (i == 3) || (i == 17) || (i == 19) || (i == 20);
  }
  
  public boolean isMasterKey()
  {
    return this.subSigs == null;
  }
  
  public int getKeyEncryptionAlgorithm()
  {
    return this.secret.getEncAlgorithm();
  }
  
  public long getKeyID()
  {
    return this.pub.getKeyID();
  }
  
  public PGPPublicKey getPublicKey()
  {
    return this.pub;
  }
  
  public Iterator getUserIDs()
  {
    return this.pub.getUserIDs();
  }
  
  public Iterator getUserAttributes()
  {
    return this.pub.getUserAttributes();
  }
  
  private byte[] extractKeyData(char[] paramArrayOfChar, String paramString)
    throws PGPException, NoSuchProviderException
  {
    String str = PGPUtil.getSymmetricCipherName(this.secret.getEncAlgorithm());
    Cipher localCipher = null;
    if (str != null) {
      try
      {
        localCipher = Cipher.getInstance(str + "/CFB/NoPadding", paramString);
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw localNoSuchProviderException;
      }
      catch (Exception localException1)
      {
        throw new PGPException("Exception creating cipher", localException1);
      }
    }
    byte[] arrayOfByte1 = this.secret.getSecretKeyData();
    byte[] arrayOfByte2 = null;
    try
    {
      if (localCipher != null) {
        try
        {
          Object localObject1;
          Object localObject2;
          int i;
          int m;
          if (this.secret.getPublicKeyPacket().getVersion() == 4)
          {
            localObject1 = new IvParameterSpec(this.secret.getIV());
            localObject2 = PGPUtil.makeKeyFromPassPhrase(this.secret.getEncAlgorithm(), this.secret.getS2K(), paramArrayOfChar, paramString);
            localCipher.init(2, (Key)localObject2, (AlgorithmParameterSpec)localObject1);
            arrayOfByte2 = localCipher.doFinal(arrayOfByte1, 0, arrayOfByte1.length);
            i = this.secret.getS2KUsage() == 254 ? 1 : 0;
            byte[] arrayOfByte3 = checksum(i, arrayOfByte2, i != 0 ? arrayOfByte2.length - 20 : arrayOfByte2.length - 2);
            for (m = 0; m != arrayOfByte3.length; m++) {
              if (arrayOfByte3[m] != arrayOfByte2[(arrayOfByte2.length - arrayOfByte3.length + m)]) {
                throw new PGPException("checksum mismatch at " + m + " of " + arrayOfByte3.length);
              }
            }
          }
          else
          {
            localObject1 = PGPUtil.makeKeyFromPassPhrase(this.secret.getEncAlgorithm(), this.secret.getS2K(), paramArrayOfChar, paramString);
            arrayOfByte2 = new byte[arrayOfByte1.length];
            localObject2 = new byte[this.secret.getIV().length];
            System.arraycopy(this.secret.getIV(), 0, localObject2, 0, localObject2.length);
            i = 0;
            int j;
            for (int k = 0; k != 4; k++)
            {
              localCipher.init(2, (Key)localObject1, new IvParameterSpec((byte[])localObject2));
              m = ((arrayOfByte1[i] << 8 | arrayOfByte1[(i + 1)] & 0xFF) + 7) / 8;
              arrayOfByte2[i] = arrayOfByte1[i];
              arrayOfByte2[(i + 1)] = arrayOfByte1[(i + 1)];
              localCipher.doFinal(arrayOfByte1, i + 2, m, arrayOfByte2, i + 2);
              i += 2 + m;
              if (k != 3) {
                System.arraycopy(arrayOfByte1, j - localObject2.length, localObject2, 0, localObject2.length);
              }
            }
            k = arrayOfByte1[j] << 8 & 0xFF00 | arrayOfByte1[(j + 1)] & 0xFF;
            m = 0;
            for (int n = 0; n < arrayOfByte2.length - 2; n++) {
              m += (arrayOfByte2[n] & 0xFF);
            }
            m &= 0xFFFF;
            if (m != k) {
              throw new PGPException("checksum mismatch: passphrase wrong, expected " + Integer.toHexString(k) + " found " + Integer.toHexString(m));
            }
          }
        }
        catch (PGPException localPGPException1)
        {
          throw localPGPException1;
        }
        catch (Exception localException2)
        {
          throw new PGPException("Exception decrypting key", localException2);
        }
      } else {
        arrayOfByte2 = arrayOfByte1;
      }
      return arrayOfByte2;
    }
    catch (PGPException localPGPException2)
    {
      throw localPGPException2;
    }
    catch (Exception localException3)
    {
      throw new PGPException("Exception constructing key", localException3);
    }
  }
  
  public PGPPrivateKey extractPrivateKey(char[] paramArrayOfChar, String paramString)
    throws PGPException, NoSuchProviderException
  {
    PublicKeyPacket localPublicKeyPacket = this.secret.getPublicKeyPacket();
    if (this.secret.getSecretKeyData() == null) {
      return null;
    }
    try
    {
      byte[] arrayOfByte = extractKeyData(paramArrayOfChar, paramString);
      BCPGInputStream localBCPGInputStream = new BCPGInputStream(new ByteArrayInputStream(arrayOfByte));
      KeyFactory localKeyFactory;
      switch (localPublicKeyPacket.getAlgorithm())
      {
      case 1: 
      case 2: 
      case 3: 
        RSAPublicBCPGKey localRSAPublicBCPGKey = (RSAPublicBCPGKey)localPublicKeyPacket.getKey();
        RSASecretBCPGKey localRSASecretBCPGKey = new RSASecretBCPGKey(localBCPGInputStream);
        RSAPrivateCrtKeySpec localRSAPrivateCrtKeySpec = new RSAPrivateCrtKeySpec(localRSASecretBCPGKey.getModulus(), localRSAPublicBCPGKey.getPublicExponent(), localRSASecretBCPGKey.getPrivateExponent(), localRSASecretBCPGKey.getPrimeP(), localRSASecretBCPGKey.getPrimeQ(), localRSASecretBCPGKey.getPrimeExponentP(), localRSASecretBCPGKey.getPrimeExponentQ(), localRSASecretBCPGKey.getCrtCoefficient());
        localKeyFactory = KeyFactory.getInstance("RSA", paramString);
        return new PGPPrivateKey(localKeyFactory.generatePrivate(localRSAPrivateCrtKeySpec), getKeyID());
      case 17: 
        DSAPublicBCPGKey localDSAPublicBCPGKey = (DSAPublicBCPGKey)localPublicKeyPacket.getKey();
        DSASecretBCPGKey localDSASecretBCPGKey = new DSASecretBCPGKey(localBCPGInputStream);
        DSAPrivateKeySpec localDSAPrivateKeySpec = new DSAPrivateKeySpec(localDSASecretBCPGKey.getX(), localDSAPublicBCPGKey.getP(), localDSAPublicBCPGKey.getQ(), localDSAPublicBCPGKey.getG());
        localKeyFactory = KeyFactory.getInstance("DSA", paramString);
        return new PGPPrivateKey(localKeyFactory.generatePrivate(localDSAPrivateKeySpec), getKeyID());
      case 16: 
      case 20: 
        ElGamalPublicBCPGKey localElGamalPublicBCPGKey = (ElGamalPublicBCPGKey)localPublicKeyPacket.getKey();
        ElGamalSecretBCPGKey localElGamalSecretBCPGKey = new ElGamalSecretBCPGKey(localBCPGInputStream);
        ElGamalPrivateKeySpec localElGamalPrivateKeySpec = new ElGamalPrivateKeySpec(localElGamalSecretBCPGKey.getX(), new ElGamalParameterSpec(localElGamalPublicBCPGKey.getP(), localElGamalPublicBCPGKey.getG()));
        localKeyFactory = KeyFactory.getInstance("ElGamal", paramString);
        return new PGPPrivateKey(localKeyFactory.generatePrivate(localElGamalPrivateKeySpec), getKeyID());
      }
      throw new PGPException("unknown public key algorithm encountered");
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("Exception constructing key", localException);
    }
  }
  
  private static byte[] checksum(boolean paramBoolean, byte[] paramArrayOfByte, int paramInt)
    throws PGPException
  {
    if (paramBoolean) {
      try
      {
        MessageDigest localMessageDigest = MessageDigest.getInstance("SHA1");
        localMessageDigest.update(paramArrayOfByte, 0, paramInt);
        return localMessageDigest.digest();
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new PGPException("Can't find SHA-1", localNoSuchAlgorithmException);
      }
    }
    int i = 0;
    for (int j = 0; j != paramInt; j++) {
      i += (paramArrayOfByte[j] & 0xFF);
    }
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)(i >> 8));
    arrayOfByte[1] = ((byte)i);
    return arrayOfByte;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    localBCPGOutputStream.writePacket(this.secret);
    if (this.trust != null) {
      localBCPGOutputStream.writePacket(this.trust);
    }
    int i;
    if (this.subSigs == null)
    {
      for (i = 0; i != this.keySigs.size(); i++) {
        ((PGPSignature)this.keySigs.get(i)).encode(localBCPGOutputStream);
      }
      for (i = 0; i != this.ids.size(); i++)
      {
        if ((this.ids.get(i) instanceof String))
        {
          localObject = (String)this.ids.get(i);
          localBCPGOutputStream.writePacket(new UserIDPacket((String)localObject));
        }
        else
        {
          localObject = (PGPUserAttributeSubpacketVector)this.ids.get(i);
          localBCPGOutputStream.writePacket(new UserAttributePacket(((PGPUserAttributeSubpacketVector)localObject).toSubpacketArray()));
        }
        if (this.idTrusts.get(i) != null) {
          localBCPGOutputStream.writePacket((ContainedPacket)this.idTrusts.get(i));
        }
        Object localObject = (ArrayList)this.idSigs.get(i);
        for (int j = 0; j != ((List)localObject).size(); j++) {
          ((PGPSignature)((List)localObject).get(j)).encode(localBCPGOutputStream);
        }
      }
    }
    else
    {
      for (i = 0; i != this.subSigs.size(); i++) {
        ((PGPSignature)this.subSigs.get(i)).encode(localBCPGOutputStream);
      }
    }
  }
  
  public static PGPSecretKey copyWithNewPassword(PGPSecretKey paramPGPSecretKey, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt, SecureRandom paramSecureRandom, String paramString)
    throws PGPException, NoSuchProviderException
  {
    byte[] arrayOfByte1 = paramPGPSecretKey.extractKeyData(paramArrayOfChar1, paramString);
    int i = paramPGPSecretKey.secret.getS2KUsage();
    byte[] arrayOfByte2 = null;
    S2K localS2K = null;
    byte[] arrayOfByte3 = null;
    if (paramInt == 0)
    {
      i = 0;
      if (paramPGPSecretKey.secret.getS2KUsage() == 254)
      {
        arrayOfByte3 = new byte[arrayOfByte1.length - 18];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, arrayOfByte3.length - 2);
        localObject = checksum(false, arrayOfByte3, arrayOfByte3.length - 2);
        arrayOfByte3[(arrayOfByte3.length - 2)] = localObject[0];
        arrayOfByte3[(arrayOfByte3.length - 1)] = localObject[1];
      }
      else
      {
        arrayOfByte3 = arrayOfByte1;
      }
    }
    else
    {
      localObject = null;
      String str = PGPUtil.getSymmetricCipherName(paramInt);
      try
      {
        localObject = Cipher.getInstance(str + "/CFB/NoPadding", paramString);
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw localNoSuchProviderException;
      }
      catch (Exception localException1)
      {
        throw new PGPException("Exception creating cipher", localException1);
      }
      arrayOfByte2 = new byte[8];
      paramSecureRandom.nextBytes(arrayOfByte2);
      localS2K = new S2K(2, arrayOfByte2, 96);
      try
      {
        SecretKey localSecretKey = PGPUtil.makeKeyFromPassPhrase(paramInt, localS2K, paramArrayOfChar2, paramString);
        ((Cipher)localObject).init(1, localSecretKey, paramSecureRandom);
        arrayOfByte2 = ((Cipher)localObject).getIV();
        arrayOfByte3 = ((Cipher)localObject).doFinal(arrayOfByte1);
      }
      catch (PGPException localPGPException)
      {
        throw localPGPException;
      }
      catch (Exception localException2)
      {
        throw new PGPException("Exception encrypting key", localException2);
      }
    }
    Object localObject = null;
    if ((paramPGPSecretKey.secret instanceof SecretSubkeyPacket)) {
      localObject = new SecretSubkeyPacket(paramPGPSecretKey.secret.getPublicKeyPacket(), paramInt, i, localS2K, arrayOfByte2, arrayOfByte3);
    } else {
      localObject = new SecretKeyPacket(paramPGPSecretKey.secret.getPublicKeyPacket(), paramInt, i, localS2K, arrayOfByte2, arrayOfByte3);
    }
    if (paramPGPSecretKey.subSigs == null) {
      return new PGPSecretKey((SecretKeyPacket)localObject, paramPGPSecretKey.trust, paramPGPSecretKey.keySigs, paramPGPSecretKey.ids, paramPGPSecretKey.idTrusts, paramPGPSecretKey.idSigs, paramPGPSecretKey.pub);
    }
    return new PGPSecretKey((SecretKeyPacket)localObject, paramPGPSecretKey.trust, paramPGPSecretKey.subSigs, paramPGPSecretKey.pub);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSecretKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */