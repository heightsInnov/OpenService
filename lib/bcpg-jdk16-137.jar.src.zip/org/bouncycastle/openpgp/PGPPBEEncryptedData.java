package org.bouncycastle.openpgp;

import java.io.EOFException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.InputStreamPacket;
import org.bouncycastle.bcpg.SymmetricEncIntegrityPacket;
import org.bouncycastle.bcpg.SymmetricKeyEncSessionPacket;

public class PGPPBEEncryptedData
  extends PGPEncryptedData
{
  SymmetricKeyEncSessionPacket keyData;
  
  PGPPBEEncryptedData(SymmetricKeyEncSessionPacket paramSymmetricKeyEncSessionPacket, InputStreamPacket paramInputStreamPacket)
  {
    super(paramInputStreamPacket);
    this.keyData = paramSymmetricKeyEncSessionPacket;
  }
  
  public InputStream getInputStream()
  {
    return this.encData.getInputStream();
  }
  
  public InputStream getDataStream(char[] paramArrayOfChar, String paramString)
    throws PGPException, NoSuchProviderException
  {
    try
    {
      int i = this.keyData.getEncAlgorithm();
      Object localObject = PGPUtil.makeKeyFromPassPhrase(i, this.keyData.getS2K(), paramArrayOfChar, paramString);
      byte[] arrayOfByte1 = this.keyData.getSecKeyData();
      if (arrayOfByte1 != null)
      {
        localCipher = Cipher.getInstance(PGPUtil.getSymmetricCipherName(i) + "/CFB/NoPadding", paramString);
        localCipher.init(2, (Key)localObject, new IvParameterSpec(new byte[localCipher.getBlockSize()]));
        arrayOfByte2 = localCipher.doFinal(arrayOfByte1);
        i = arrayOfByte2[0];
        localObject = new SecretKeySpec(arrayOfByte2, 1, arrayOfByte2.length - 1, PGPUtil.getSymmetricCipherName(i));
      }
      Cipher localCipher = createStreamCipher(i, paramString);
      byte[] arrayOfByte2 = new byte[localCipher.getBlockSize()];
      localCipher.init(2, (Key)localObject, new IvParameterSpec(arrayOfByte2));
      this.encStream = new BCPGInputStream(new CipherInputStream(this.encData.getInputStream(), localCipher));
      if ((this.encData instanceof SymmetricEncIntegrityPacket))
      {
        this.truncStream = new PGPEncryptedData.TruncatedStream(this, this.encStream);
        String str = PGPUtil.getDigestName(2);
        MessageDigest localMessageDigest = MessageDigest.getInstance(str, paramString);
        this.encStream = new DigestInputStream(this.truncStream, localMessageDigest);
      }
      for (int j = 0; j != arrayOfByte2.length; j++)
      {
        k = this.encStream.read();
        if (k < 0) {
          throw new EOFException("unexpected end of stream.");
        }
        arrayOfByte2[j] = ((byte)k);
      }
      j = this.encStream.read();
      int k = this.encStream.read();
      if ((j < 0) || (k < 0)) {
        throw new EOFException("unexpected end of stream.");
      }
      int m = (arrayOfByte2[(arrayOfByte2.length - 2)] == (byte)j) && (arrayOfByte2[(arrayOfByte2.length - 1)] == (byte)k) ? 1 : 0;
      int n = (j == 0) && (k == 0) ? 1 : 0;
      if ((m == 0) && (n == 0)) {
        throw new PGPDataValidationException("data check failed.");
      }
      return this.encStream;
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("Exception creating cipher", localException);
    }
  }
  
  private Cipher createStreamCipher(int paramInt, String paramString)
    throws NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException, PGPException
  {
    String str1 = (this.encData instanceof SymmetricEncIntegrityPacket) ? "CFB" : "OpenPGPCFB";
    String str2 = PGPUtil.getSymmetricCipherName(paramInt) + "/" + str1 + "/NoPadding";
    return Cipher.getInstance(str2, paramString);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPBEEncryptedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */