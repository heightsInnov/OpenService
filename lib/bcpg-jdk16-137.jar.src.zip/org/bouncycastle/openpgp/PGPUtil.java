package org.bouncycastle.openpgp;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.Date;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.bcpg.ArmoredInputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.MPInteger;
import org.bouncycastle.bcpg.S2K;
import org.bouncycastle.util.encoders.Base64;

public class PGPUtil
  implements HashAlgorithmTags
{
  private static String defProvider = "BC";
  private static final int READ_AHEAD = 60;
  
  public static String getDefaultProvider()
  {
    return defProvider;
  }
  
  public static void setDefaultProvider(String paramString)
  {
    defProvider = paramString;
  }
  
  static MPInteger[] dsaSigToMpi(byte[] paramArrayOfByte)
    throws PGPException
  {
    ASN1InputStream localASN1InputStream = new ASN1InputStream(paramArrayOfByte);
    DERInteger localDERInteger1;
    DERInteger localDERInteger2;
    try
    {
      ASN1Sequence localASN1Sequence = (ASN1Sequence)localASN1InputStream.readObject();
      localDERInteger1 = (DERInteger)localASN1Sequence.getObjectAt(0);
      localDERInteger2 = (DERInteger)localASN1Sequence.getObjectAt(1);
    }
    catch (IOException localIOException)
    {
      throw new PGPException("exception encoding signature", localIOException);
    }
    MPInteger[] arrayOfMPInteger = new MPInteger[2];
    arrayOfMPInteger[0] = new MPInteger(localDERInteger1.getValue());
    arrayOfMPInteger[1] = new MPInteger(localDERInteger2.getValue());
    return arrayOfMPInteger;
  }
  
  static String getDigestName(int paramInt)
    throws PGPException
  {
    switch (paramInt)
    {
    case 2: 
      return "SHA1";
    case 5: 
      return "MD2";
    case 1: 
      return "MD5";
    case 3: 
      return "RIPEMD160";
    case 8: 
      return "SHA256";
    case 9: 
      return "SHA384";
    case 10: 
      return "SHA512";
    case 11: 
      return "SHA224";
    }
    throw new PGPException("unknown hash algorithm tag in getDigestName: " + paramInt);
  }
  
  static String getSignatureName(int paramInt1, int paramInt2)
    throws PGPException
  {
    String str;
    switch (paramInt1)
    {
    case 1: 
    case 3: 
      str = "RSA";
      break;
    case 17: 
      str = "DSA";
      break;
    case 16: 
    case 20: 
      str = "ElGamal";
      break;
    default: 
      throw new PGPException("unknown algorithm tag in signature:" + paramInt1);
    }
    return getDigestName(paramInt2) + "with" + str;
  }
  
  static String getSymmetricCipherName(int paramInt)
    throws PGPException
  {
    switch (paramInt)
    {
    case 0: 
      return null;
    case 2: 
      return "DESEDE";
    case 1: 
      return "IDEA";
    case 3: 
      return "CAST5";
    case 4: 
      return "Blowfish";
    case 5: 
      return "SAFER";
    case 6: 
      return "DES";
    case 7: 
      return "AES";
    case 8: 
      return "AES";
    case 9: 
      return "AES";
    case 10: 
      return "Twofish";
    }
    throw new PGPException("unknown symmetric algorithm: " + paramInt);
  }
  
  public static SecretKey makeRandomKey(int paramInt, SecureRandom paramSecureRandom)
    throws PGPException
  {
    String str = null;
    int i = 0;
    switch (paramInt)
    {
    case 2: 
      i = 192;
      str = "DES_EDE";
      break;
    case 1: 
      i = 128;
      str = "IDEA";
      break;
    case 3: 
      i = 128;
      str = "CAST5";
      break;
    case 4: 
      i = 128;
      str = "Blowfish";
      break;
    case 5: 
      i = 128;
      str = "SAFER";
      break;
    case 6: 
      i = 64;
      str = "DES";
      break;
    case 7: 
      i = 128;
      str = "AES";
      break;
    case 8: 
      i = 192;
      str = "AES";
      break;
    case 9: 
      i = 256;
      str = "AES";
      break;
    case 10: 
      i = 256;
      str = "Twofish";
      break;
    default: 
      throw new PGPException("unknown symmetric algorithm: " + paramInt);
    }
    byte[] arrayOfByte = new byte[(i + 7) / 8];
    paramSecureRandom.nextBytes(arrayOfByte);
    return new SecretKeySpec(arrayOfByte, str);
  }
  
  public static SecretKey makeKeyFromPassPhrase(int paramInt, char[] paramArrayOfChar, String paramString)
    throws NoSuchProviderException, PGPException
  {
    return makeKeyFromPassPhrase(paramInt, null, paramArrayOfChar, paramString);
  }
  
  public static SecretKey makeKeyFromPassPhrase(int paramInt, S2K paramS2K, char[] paramArrayOfChar, String paramString)
    throws PGPException, NoSuchProviderException
  {
    String str1 = null;
    int i = 0;
    switch (paramInt)
    {
    case 2: 
      i = 192;
      str1 = "DES_EDE";
      break;
    case 1: 
      i = 128;
      str1 = "IDEA";
      break;
    case 3: 
      i = 128;
      str1 = "CAST5";
      break;
    case 4: 
      i = 128;
      str1 = "Blowfish";
      break;
    case 5: 
      i = 128;
      str1 = "SAFER";
      break;
    case 6: 
      i = 64;
      str1 = "DES";
      break;
    case 7: 
      i = 128;
      str1 = "AES";
      break;
    case 8: 
      i = 192;
      str1 = "AES";
      break;
    case 9: 
      i = 256;
      str1 = "AES";
      break;
    case 10: 
      i = 256;
      str1 = "Twofish";
      break;
    default: 
      throw new PGPException("unknown symmetric algorithm: " + paramInt);
    }
    byte[] arrayOfByte1 = new byte[paramArrayOfChar.length];
    for (int j = 0; j != paramArrayOfChar.length; j++) {
      arrayOfByte1[j] = ((byte)paramArrayOfChar[j]);
    }
    byte[] arrayOfByte2 = new byte[(i + 7) / 8];
    int k = 0;
    for (int m = 0; k < arrayOfByte2.length; m++)
    {
      MessageDigest localMessageDigest;
      if (paramS2K != null)
      {
        String str2 = getS2kDigestName(paramS2K);
        try
        {
          localMessageDigest = getDigestInstance(str2, paramString);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
        {
          throw new PGPException("can't find S2K digest", localNoSuchAlgorithmException2);
        }
        for (int i2 = 0; i2 != m; i2++) {
          localMessageDigest.update((byte)0);
        }
        byte[] arrayOfByte4 = paramS2K.getIV();
        long l;
        switch (paramS2K.getType())
        {
        case 0: 
          localMessageDigest.update(arrayOfByte1);
          break;
        case 1: 
          localMessageDigest.update(arrayOfByte4);
          localMessageDigest.update(arrayOfByte1);
          break;
        case 3: 
          l = paramS2K.getIterationCount();
          localMessageDigest.update(arrayOfByte4);
          localMessageDigest.update(arrayOfByte1);
          l -= arrayOfByte4.length + arrayOfByte1.length;
        case 2: 
        default: 
          while (l > 0L) {
            if (l < arrayOfByte4.length)
            {
              localMessageDigest.update(arrayOfByte4, 0, (int)l);
            }
            else
            {
              localMessageDigest.update(arrayOfByte4);
              l -= arrayOfByte4.length;
              if (l < arrayOfByte1.length)
              {
                localMessageDigest.update(arrayOfByte1, 0, (int)l);
                l = 0L;
              }
              else
              {
                localMessageDigest.update(arrayOfByte1);
                l -= arrayOfByte1.length;
                continue;
                throw new PGPException("unknown S2K type: " + paramS2K.getType());
              }
            }
          }
        }
      }
      else
      {
        try
        {
          localMessageDigest = getDigestInstance("MD5", paramString);
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
        {
          throw new PGPException("can't find MD5 digest", localNoSuchAlgorithmException1);
        }
        for (int n = 0; n != m; n++) {
          localMessageDigest.update((byte)0);
        }
        localMessageDigest.update(arrayOfByte1);
      }
      byte[] arrayOfByte3 = localMessageDigest.digest();
      if (arrayOfByte3.length > arrayOfByte2.length - k) {
        System.arraycopy(arrayOfByte3, 0, arrayOfByte2, k, arrayOfByte2.length - k);
      } else {
        System.arraycopy(arrayOfByte3, 0, arrayOfByte2, k, arrayOfByte3.length);
      }
      k += arrayOfByte3.length;
    }
    for (int i1 = 0; i1 != arrayOfByte1.length; i1++) {
      arrayOfByte1[i1] = 0;
    }
    return new SecretKeySpec(arrayOfByte2, str1);
  }
  
  static MessageDigest getDigestInstance(String paramString1, String paramString2)
    throws NoSuchProviderException, NoSuchAlgorithmException
  {
    try
    {
      return MessageDigest.getInstance(paramString1, paramString2);
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}
    return MessageDigest.getInstance(paramString1);
  }
  
  private static String getS2kDigestName(S2K paramS2K)
    throws PGPException
  {
    switch (paramS2K.getHashAlgorithm())
    {
    case 1: 
      return "MD5";
    case 2: 
      return "SHA1";
    }
    throw new PGPException("unknown hash algorithm: " + paramS2K.getHashAlgorithm());
  }
  
  public static void writeFileToLiteralData(OutputStream paramOutputStream, char paramChar, File paramFile)
    throws IOException
  {
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(paramOutputStream, paramChar, paramFile.getName(), paramFile.length(), new Date(paramFile.lastModified()));
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    byte[] arrayOfByte = new byte['က'];
    int i;
    while ((i = localFileInputStream.read(arrayOfByte)) > 0) {
      localOutputStream.write(arrayOfByte, 0, i);
    }
    localPGPLiteralDataGenerator.close();
    localFileInputStream.close();
  }
  
  public static void writeFileToLiteralData(OutputStream paramOutputStream, char paramChar, File paramFile, byte[] paramArrayOfByte)
    throws IOException
  {
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    OutputStream localOutputStream = localPGPLiteralDataGenerator.open(paramOutputStream, paramChar, paramFile.getName(), new Date(paramFile.lastModified()), paramArrayOfByte);
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    int i;
    while ((i = localFileInputStream.read(arrayOfByte)) > 0) {
      localOutputStream.write(arrayOfByte, 0, i);
    }
    localPGPLiteralDataGenerator.close();
    localFileInputStream.close();
  }
  
  private static boolean isPossiblyBase64(int paramInt)
  {
    return ((paramInt >= 65) && (paramInt <= 90)) || ((paramInt >= 97) && (paramInt <= 122)) || ((paramInt >= 48) && (paramInt <= 57)) || (paramInt == 43) || (paramInt == 47) || (paramInt == 13) || (paramInt == 10);
  }
  
  public static InputStream getDecoderStream(InputStream paramInputStream)
    throws IOException
  {
    if (!paramInputStream.markSupported()) {
      paramInputStream = new BufferedInputStream(paramInputStream);
    }
    paramInputStream.mark(60);
    int i = paramInputStream.read();
    if ((i & 0x80) != 0)
    {
      paramInputStream.reset();
      return paramInputStream;
    }
    if (!isPossiblyBase64(i))
    {
      paramInputStream.reset();
      return new ArmoredInputStream(paramInputStream);
    }
    byte[] arrayOfByte1 = new byte[60];
    int j = 1;
    int k = 1;
    arrayOfByte1[0] = ((byte)i);
    while ((j != 60) && ((i = paramInputStream.read()) >= 0))
    {
      if (!isPossiblyBase64(i))
      {
        paramInputStream.reset();
        return new ArmoredInputStream(paramInputStream);
      }
      if ((i != 10) && (i != 13)) {
        arrayOfByte1[(k++)] = ((byte)i);
      }
      j++;
    }
    paramInputStream.reset();
    if (j < 4) {
      return new ArmoredInputStream(paramInputStream);
    }
    byte[] arrayOfByte2 = new byte[8];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
    byte[] arrayOfByte3 = Base64.decode(arrayOfByte2);
    if ((arrayOfByte3[0] & 0x80) != 0) {
      return new ArmoredInputStream(paramInputStream, false);
    }
    return new ArmoredInputStream(paramInputStream);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */