package org.bouncycastle.openpgp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1OutputStream;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.MPInteger;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.SignaturePacket;
import org.bouncycastle.bcpg.SignatureSubpacket;
import org.bouncycastle.bcpg.TrustPacket;

public class PGPSignature
{
  public static final int BINARY_DOCUMENT = 0;
  public static final int CANONICAL_TEXT_DOCUMENT = 1;
  public static final int STAND_ALONE = 2;
  public static final int DEFAULT_CERTIFICATION = 16;
  public static final int NO_CERTIFICATION = 17;
  public static final int CASUAL_CERTIFICATION = 18;
  public static final int POSITIVE_CERTIFICATION = 19;
  public static final int SUBKEY_BINDING = 24;
  public static final int DIRECT_KEY = 31;
  public static final int KEY_REVOCATION = 32;
  public static final int SUBKEY_REVOCATION = 40;
  public static final int CERTIFICATION_REVOCATION = 48;
  public static final int TIMESTAMP = 64;
  private SignaturePacket sigPck;
  private Signature sig;
  private int signatureType;
  private TrustPacket trustPck;
  private byte lastb;
  
  PGPSignature(BCPGInputStream paramBCPGInputStream)
    throws IOException, PGPException
  {
    this((SignaturePacket)paramBCPGInputStream.readPacket());
  }
  
  PGPSignature(SignaturePacket paramSignaturePacket)
    throws PGPException
  {
    this.sigPck = paramSignaturePacket;
    this.signatureType = this.sigPck.getSignatureType();
    this.trustPck = null;
  }
  
  PGPSignature(SignaturePacket paramSignaturePacket, TrustPacket paramTrustPacket)
    throws PGPException
  {
    this(paramSignaturePacket);
    this.trustPck = paramTrustPacket;
  }
  
  private void getSig(String paramString)
    throws PGPException
  {
    try
    {
      this.sig = Signature.getInstance(PGPUtil.getSignatureName(this.sigPck.getKeyAlgorithm(), this.sigPck.getHashAlgorithm()), paramString);
    }
    catch (Exception localException)
    {
      throw new PGPException("can't set up signature object.", localException);
    }
  }
  
  public int getVersion()
  {
    return this.sigPck.getVersion();
  }
  
  public int getKeyAlgorithm()
  {
    return this.sigPck.getKeyAlgorithm();
  }
  
  public int getHashAlgorithm()
  {
    return this.sigPck.getHashAlgorithm();
  }
  
  public void initVerify(PGPPublicKey paramPGPPublicKey, String paramString)
    throws NoSuchProviderException, PGPException
  {
    if (this.sig == null) {
      getSig(paramString);
    }
    try
    {
      this.sig.initVerify(paramPGPPublicKey.getKey(paramString));
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new PGPException("invalid key.", localInvalidKeyException);
    }
    this.lastb = 0;
  }
  
  public void update(byte paramByte)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      if (paramByte == 13)
      {
        this.sig.update((byte)13);
        this.sig.update((byte)10);
      }
      else if (paramByte == 10)
      {
        if (this.lastb != 13)
        {
          this.sig.update((byte)13);
          this.sig.update((byte)10);
        }
      }
      else
      {
        this.sig.update(paramByte);
      }
      this.lastb = paramByte;
    }
    else
    {
      this.sig.update(paramByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte)
    throws SignatureException
  {
    update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      int i = paramInt1 + paramInt2;
      for (int j = paramInt1; j != i; j++) {
        update(paramArrayOfByte[j]);
      }
    }
    else
    {
      this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
  
  public boolean verify()
    throws PGPException, SignatureException
  {
    this.sig.update(getSignatureTrailer());
    return this.sig.verify(getSignature());
  }
  
  public boolean verifyCertification(String paramString, PGPPublicKey paramPGPPublicKey)
    throws PGPException, SignatureException
  {
    byte[] arrayOfByte1 = getEncodedPublicKey(paramPGPPublicKey);
    update((byte)-103);
    update((byte)(arrayOfByte1.length >> 8));
    update((byte)arrayOfByte1.length);
    update(arrayOfByte1);
    byte[] arrayOfByte2 = new byte[paramString.length()];
    for (int i = 0; i != arrayOfByte2.length; i++) {
      arrayOfByte2[i] = ((byte)paramString.charAt(i));
    }
    update((byte)-76);
    update((byte)(arrayOfByte2.length >> 24));
    update((byte)(arrayOfByte2.length >> 16));
    update((byte)(arrayOfByte2.length >> 8));
    update((byte)arrayOfByte2.length);
    update(arrayOfByte2);
    update(this.sigPck.getSignatureTrailer());
    return this.sig.verify(getSignature());
  }
  
  public boolean verifyCertification(PGPPublicKey paramPGPPublicKey1, PGPPublicKey paramPGPPublicKey2)
    throws SignatureException, PGPException
  {
    byte[] arrayOfByte = getEncodedPublicKey(paramPGPPublicKey1);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    arrayOfByte = getEncodedPublicKey(paramPGPPublicKey2);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    update(this.sigPck.getSignatureTrailer());
    return this.sig.verify(getSignature());
  }
  
  public boolean verifyCertification(PGPPublicKey paramPGPPublicKey)
    throws SignatureException, PGPException
  {
    if ((getSignatureType() != 32) && (getSignatureType() != 40)) {
      throw new IllegalStateException("signature is not a key signature");
    }
    byte[] arrayOfByte = getEncodedPublicKey(paramPGPPublicKey);
    update((byte)-103);
    update((byte)(arrayOfByte.length >> 8));
    update((byte)arrayOfByte.length);
    update(arrayOfByte);
    update(this.sigPck.getSignatureTrailer());
    return this.sig.verify(getSignature());
  }
  
  public int getSignatureType()
  {
    return this.sigPck.getSignatureType();
  }
  
  public long getKeyID()
  {
    return this.sigPck.getKeyID();
  }
  
  public Date getCreationTime()
  {
    return new Date(this.sigPck.getCreationTime());
  }
  
  public byte[] getSignatureTrailer()
  {
    return this.sigPck.getSignatureTrailer();
  }
  
  public PGPSignatureSubpacketVector getHashedSubPackets()
  {
    return createSubpacketVector(this.sigPck.getHashedSubPackets());
  }
  
  public PGPSignatureSubpacketVector getUnhashedSubPackets()
  {
    return createSubpacketVector(this.sigPck.getUnhashedSubPackets());
  }
  
  private PGPSignatureSubpacketVector createSubpacketVector(SignatureSubpacket[] paramArrayOfSignatureSubpacket)
  {
    if (paramArrayOfSignatureSubpacket != null) {
      return new PGPSignatureSubpacketVector(paramArrayOfSignatureSubpacket);
    }
    return null;
  }
  
  public byte[] getSignature()
    throws PGPException
  {
    MPInteger[] arrayOfMPInteger = this.sigPck.getSignature();
    Object localObject1;
    if (arrayOfMPInteger != null)
    {
      Object localObject2;
      if (arrayOfMPInteger.length == 1)
      {
        localObject2 = arrayOfMPInteger[0].getValue().toByteArray();
        if (localObject2[0] == 0)
        {
          localObject1 = new byte[localObject2.length - 1];
          System.arraycopy(localObject2, 1, localObject1, 0, localObject1.length);
        }
        else
        {
          localObject1 = localObject2;
        }
      }
      else
      {
        localObject2 = new ByteArrayOutputStream();
        ASN1OutputStream localASN1OutputStream = new ASN1OutputStream((OutputStream)localObject2);
        try
        {
          ASN1EncodableVector localASN1EncodableVector = new ASN1EncodableVector();
          localASN1EncodableVector.add(new DERInteger(arrayOfMPInteger[0].getValue()));
          localASN1EncodableVector.add(new DERInteger(arrayOfMPInteger[1].getValue()));
          localASN1OutputStream.writeObject(new DERSequence(localASN1EncodableVector));
        }
        catch (IOException localIOException)
        {
          throw new PGPException("exception encoding DSA sig.", localIOException);
        }
        localObject1 = ((ByteArrayOutputStream)localObject2).toByteArray();
      }
    }
    else
    {
      localObject1 = this.sigPck.getSignatureBytes();
    }
    return (byte[])localObject1;
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    localBCPGOutputStream.writePacket(this.sigPck);
    if (this.trustPck != null) {
      localBCPGOutputStream.writePacket(this.trustPck);
    }
  }
  
  private byte[] getEncodedPublicKey(PGPPublicKey paramPGPPublicKey)
    throws PGPException
  {
    byte[] arrayOfByte;
    try
    {
      arrayOfByte = paramPGPPublicKey.publicPk.getEncodedContents();
    }
    catch (IOException localIOException)
    {
      throw new PGPException("exception preparing key.", localIOException);
    }
    return arrayOfByte;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */