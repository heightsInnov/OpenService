package org.bouncycastle.openpgp;

public class PGPException
  extends Exception
{
  Exception underlying;
  
  public PGPException(String paramString)
  {
    super(paramString);
  }
  
  public PGPException(String paramString, Exception paramException)
  {
    super(paramString);
    this.underlying = paramException;
  }
  
  public Exception getUnderlyingException()
  {
    return this.underlying;
  }
  
  public Throwable getCause()
  {
    return this.underlying;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */