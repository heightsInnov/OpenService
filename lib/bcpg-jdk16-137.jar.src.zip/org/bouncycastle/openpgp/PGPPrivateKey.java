package org.bouncycastle.openpgp;

import java.security.PrivateKey;

public class PGPPrivateKey
{
  private long keyID;
  private PrivateKey privateKey;
  
  public PGPPrivateKey(PrivateKey paramPrivateKey, long paramLong)
  {
    this.privateKey = paramPrivateKey;
    this.keyID = paramLong;
  }
  
  public long getKeyID()
  {
    return this.keyID;
  }
  
  public PrivateKey getKey()
  {
    return this.privateKey;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPrivateKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */