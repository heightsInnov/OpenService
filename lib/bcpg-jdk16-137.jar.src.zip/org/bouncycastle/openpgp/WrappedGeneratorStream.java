package org.bouncycastle.openpgp;

import java.io.IOException;
import java.io.OutputStream;

class WrappedGeneratorStream
  extends OutputStream
{
  private final OutputStream _out;
  private final StreamGenerator _sGen;
  
  public WrappedGeneratorStream(OutputStream paramOutputStream, StreamGenerator paramStreamGenerator)
  {
    this._out = paramOutputStream;
    this._sGen = paramStreamGenerator;
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    this._out.write(paramArrayOfByte);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this._out.write(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public void write(int paramInt)
    throws IOException
  {
    this._out.write(paramInt);
  }
  
  public void flush()
    throws IOException
  {
    this._out.flush();
  }
  
  public void close()
    throws IOException
  {
    this._sGen.close();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\WrappedGeneratorStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */