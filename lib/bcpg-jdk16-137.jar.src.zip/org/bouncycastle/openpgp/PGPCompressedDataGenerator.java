package org.bouncycastle.openpgp;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import org.bouncycastle.apache.bzip2.CBZip2OutputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.CompressionAlgorithmTags;

public class PGPCompressedDataGenerator
  implements CompressionAlgorithmTags, StreamGenerator
{
  private int algorithm;
  private int compression;
  private OutputStream out;
  private OutputStream dOut;
  private BCPGOutputStream pkOut;
  
  public PGPCompressedDataGenerator(int paramInt)
  {
    this(paramInt, -1);
  }
  
  public PGPCompressedDataGenerator(int paramInt1, int paramInt2)
  {
    if ((paramInt1 != 0) && (paramInt1 != 1) && (paramInt1 != 2) && (paramInt1 != 3)) {
      throw new IllegalArgumentException("unknown compression algorithm");
    }
    if ((paramInt2 != -1) && ((paramInt2 < 0) || (paramInt2 > 9))) {
      throw new IllegalArgumentException("unknown compression level: " + paramInt2);
    }
    this.algorithm = paramInt1;
    this.compression = paramInt2;
  }
  
  public OutputStream open(OutputStream paramOutputStream)
    throws IOException
  {
    if (this.dOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    this.out = paramOutputStream;
    switch (this.algorithm)
    {
    case 1: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8);
      this.pkOut.write(1);
      this.dOut = new DeflaterOutputStream(this.pkOut, new Deflater(this.compression, true));
      break;
    case 2: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8);
      this.pkOut.write(2);
      this.dOut = new DeflaterOutputStream(this.pkOut, new Deflater(this.compression));
      break;
    case 3: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8);
      this.pkOut.write(3);
      this.dOut = new CBZip2OutputStream(this.pkOut);
      break;
    case 0: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8);
      this.pkOut.write(0);
      this.dOut = this.pkOut;
      break;
    default: 
      throw new IllegalStateException("generator not initialised");
    }
    return new WrappedGeneratorStream(this.dOut, this);
  }
  
  public OutputStream open(OutputStream paramOutputStream, byte[] paramArrayOfByte)
    throws IOException, PGPException
  {
    if (this.dOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    this.out = paramOutputStream;
    switch (this.algorithm)
    {
    case 1: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8, paramArrayOfByte);
      this.pkOut.write(1);
      this.dOut = new DeflaterOutputStream(this.pkOut, new Deflater(this.compression, true));
      break;
    case 2: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8, paramArrayOfByte);
      this.pkOut.write(2);
      this.dOut = new DeflaterOutputStream(this.pkOut, new Deflater(this.compression));
      break;
    case 3: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8, paramArrayOfByte);
      this.pkOut.write(3);
      this.dOut = new CBZip2OutputStream(this.pkOut);
      break;
    case 0: 
      this.pkOut = new BCPGOutputStream(paramOutputStream, 8, paramArrayOfByte);
      this.pkOut.write(0);
      this.dOut = this.pkOut;
      break;
    default: 
      throw new IllegalStateException("generator not initialised");
    }
    return new WrappedGeneratorStream(this.dOut, this);
  }
  
  public void close()
    throws IOException
  {
    if (this.dOut != null)
    {
      Object localObject;
      if ((this.dOut instanceof DeflaterOutputStream))
      {
        localObject = (DeflaterOutputStream)this.dOut;
        ((DeflaterOutputStream)localObject).finish();
      }
      else if ((this.dOut instanceof CBZip2OutputStream))
      {
        localObject = (CBZip2OutputStream)this.dOut;
        ((CBZip2OutputStream)localObject).finish();
      }
      this.dOut.flush();
      this.pkOut.finish();
      this.pkOut.flush();
      this.out.flush();
      this.dOut = null;
      this.pkOut = null;
      this.out = null;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPCompressedDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */