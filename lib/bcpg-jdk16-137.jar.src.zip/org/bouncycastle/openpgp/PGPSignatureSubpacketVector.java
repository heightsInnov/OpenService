package org.bouncycastle.openpgp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bouncycastle.bcpg.SignatureSubpacket;
import org.bouncycastle.bcpg.sig.IssuerKeyID;
import org.bouncycastle.bcpg.sig.KeyExpirationTime;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.bcpg.sig.NotationData;
import org.bouncycastle.bcpg.sig.PreferredAlgorithms;
import org.bouncycastle.bcpg.sig.SignatureCreationTime;
import org.bouncycastle.bcpg.sig.SignatureExpirationTime;
import org.bouncycastle.bcpg.sig.SignerUserID;

public class PGPSignatureSubpacketVector
{
  SignatureSubpacket[] packets;
  
  PGPSignatureSubpacketVector(SignatureSubpacket[] paramArrayOfSignatureSubpacket)
  {
    this.packets = paramArrayOfSignatureSubpacket;
  }
  
  public SignatureSubpacket getSubpacket(int paramInt)
  {
    for (int i = 0; i != this.packets.length; i++) {
      if (this.packets[i].getType() == paramInt) {
        return this.packets[i];
      }
    }
    return null;
  }
  
  public SignatureSubpacket[] getSubpackets(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i != this.packets.length; i++) {
      if (this.packets[i].getType() == paramInt) {
        localArrayList.add(this.packets[i]);
      }
    }
    return (SignatureSubpacket[])localArrayList.toArray(new SignatureSubpacket[0]);
  }
  
  public NotationData[] getNotationDataOccurences()
  {
    SignatureSubpacket[] arrayOfSignatureSubpacket = getSubpackets(20);
    NotationData[] arrayOfNotationData = new NotationData[arrayOfSignatureSubpacket.length];
    for (int i = 0; i < arrayOfSignatureSubpacket.length; i++) {
      arrayOfNotationData[i] = ((NotationData)arrayOfSignatureSubpacket[i]);
    }
    return arrayOfNotationData;
  }
  
  public long getIssuerKeyID()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(16);
    if (localSignatureSubpacket == null) {
      return 0L;
    }
    return ((IssuerKeyID)localSignatureSubpacket).getKeyID();
  }
  
  public Date getSignatureCreationTime()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(2);
    if (localSignatureSubpacket == null) {
      return null;
    }
    return ((SignatureCreationTime)localSignatureSubpacket).getTime();
  }
  
  public long getSignatureExpirationTime()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(3);
    if (localSignatureSubpacket == null) {
      return 0L;
    }
    return ((SignatureExpirationTime)localSignatureSubpacket).getTime();
  }
  
  public long getKeyExpirationTime()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(9);
    if (localSignatureSubpacket == null) {
      return 0L;
    }
    return ((KeyExpirationTime)localSignatureSubpacket).getTime();
  }
  
  public int[] getPreferredHashAlgorithms()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(21);
    if (localSignatureSubpacket == null) {
      return null;
    }
    return ((PreferredAlgorithms)localSignatureSubpacket).getPreferences();
  }
  
  public int[] getPreferredSymmetricAlgorithms()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(11);
    if (localSignatureSubpacket == null) {
      return null;
    }
    return ((PreferredAlgorithms)localSignatureSubpacket).getPreferences();
  }
  
  public int[] getPreferredCompressionAlgorithms()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(22);
    if (localSignatureSubpacket == null) {
      return null;
    }
    return ((PreferredAlgorithms)localSignatureSubpacket).getPreferences();
  }
  
  public int getKeyFlags()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(27);
    if (localSignatureSubpacket == null) {
      return 0;
    }
    return ((KeyFlags)localSignatureSubpacket).getFlags();
  }
  
  public String getSignerUserID()
  {
    SignatureSubpacket localSignatureSubpacket = getSubpacket(28);
    if (localSignatureSubpacket == null) {
      return null;
    }
    return ((SignerUserID)localSignatureSubpacket).getID();
  }
  
  public int[] getCriticalTags()
  {
    int i = 0;
    for (int j = 0; j != this.packets.length; j++) {
      if (this.packets[j].isCritical()) {
        i++;
      }
    }
    int[] arrayOfInt = new int[i];
    i = 0;
    for (int k = 0; k != this.packets.length; k++) {
      if (this.packets[k].isCritical()) {
        arrayOfInt[(i++)] = this.packets[k].getType();
      }
    }
    return arrayOfInt;
  }
  
  public int size()
  {
    return this.packets.length;
  }
  
  SignatureSubpacket[] toSubpacketArray()
  {
    return this.packets;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPSignatureSubpacketVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */