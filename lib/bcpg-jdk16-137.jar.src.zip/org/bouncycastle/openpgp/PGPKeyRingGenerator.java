package org.bouncycastle.openpgp;

import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.bcpg.PublicKeyPacket;
import org.bouncycastle.bcpg.PublicSubkeyPacket;

public class PGPKeyRingGenerator
{
  List keys = new ArrayList();
  private String id;
  private int encAlgorithm;
  private int certificationLevel;
  private char[] passPhrase;
  private boolean useSHA1;
  private PGPKeyPair masterKey;
  private PGPSignatureSubpacketVector hashedPcks;
  private PGPSignatureSubpacketVector unhashedPcks;
  private SecureRandom rand;
  private String provider;
  
  public PGPKeyRingGenerator(int paramInt1, PGPKeyPair paramPGPKeyPair, String paramString1, int paramInt2, char[] paramArrayOfChar, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this(paramInt1, paramPGPKeyPair, paramString1, paramInt2, paramArrayOfChar, false, paramPGPSignatureSubpacketVector1, paramPGPSignatureSubpacketVector2, paramSecureRandom, paramString2);
  }
  
  public PGPKeyRingGenerator(int paramInt1, PGPKeyPair paramPGPKeyPair, String paramString1, int paramInt2, char[] paramArrayOfChar, boolean paramBoolean, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2, SecureRandom paramSecureRandom, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    this.certificationLevel = paramInt1;
    this.masterKey = paramPGPKeyPair;
    this.id = paramString1;
    this.encAlgorithm = paramInt2;
    this.passPhrase = paramArrayOfChar;
    this.useSHA1 = paramBoolean;
    this.hashedPcks = paramPGPSignatureSubpacketVector1;
    this.unhashedPcks = paramPGPSignatureSubpacketVector2;
    this.rand = paramSecureRandom;
    this.provider = paramString2;
    this.keys.add(new PGPSecretKey(paramInt1, paramPGPKeyPair, paramString1, paramInt2, paramArrayOfChar, paramBoolean, paramPGPSignatureSubpacketVector1, paramPGPSignatureSubpacketVector2, paramSecureRandom, paramString2));
  }
  
  public void addSubKey(PGPKeyPair paramPGPKeyPair)
    throws PGPException
  {
    addSubKey(paramPGPKeyPair, this.hashedPcks, this.unhashedPcks);
  }
  
  public void addSubKey(PGPKeyPair paramPGPKeyPair, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector1, PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector2)
    throws PGPException
  {
    try
    {
      PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(this.masterKey.getPublicKey().getAlgorithm(), 2, this.provider);
      localPGPSignatureGenerator.initSign(24, this.masterKey.getPrivateKey());
      localPGPSignatureGenerator.setHashedSubpackets(paramPGPSignatureSubpacketVector1);
      localPGPSignatureGenerator.setUnhashedSubpackets(paramPGPSignatureSubpacketVector2);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(localPGPSignatureGenerator.generateCertification(this.masterKey.getPublicKey(), paramPGPKeyPair.getPublicKey()));
      this.keys.add(new PGPSecretKey(paramPGPKeyPair, null, localArrayList, this.encAlgorithm, this.passPhrase, this.useSHA1, this.rand, this.provider));
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("exception adding subkey: ", localException);
    }
  }
  
  public PGPSecretKeyRing generateSecretKeyRing()
  {
    return new PGPSecretKeyRing(this.keys);
  }
  
  public PGPPublicKeyRing generatePublicKeyRing()
  {
    Iterator localIterator = this.keys.iterator();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(((PGPSecretKey)localIterator.next()).getPublicKey());
    while (localIterator.hasNext())
    {
      PGPPublicKey localPGPPublicKey = new PGPPublicKey(((PGPSecretKey)localIterator.next()).getPublicKey());
      localPGPPublicKey.publicPk = new PublicSubkeyPacket(localPGPPublicKey.getAlgorithm(), localPGPPublicKey.getCreationTime(), localPGPPublicKey.publicPk.getKey());
      localArrayList.add(localPGPPublicKey);
    }
    return new PGPPublicKeyRing(localArrayList);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPKeyRingGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */