package org.bouncycastle.openpgp;

import java.io.IOException;

abstract interface StreamGenerator
{
  public abstract void close()
    throws IOException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\StreamGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */