package org.bouncycastle.openpgp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.Packet;
import org.bouncycastle.bcpg.SignaturePacket;
import org.bouncycastle.bcpg.TrustPacket;
import org.bouncycastle.bcpg.UserAttributePacket;
import org.bouncycastle.bcpg.UserIDPacket;

public abstract class PGPKeyRing
{
  static BCPGInputStream wrap(InputStream paramInputStream)
  {
    if ((paramInputStream instanceof BCPGInputStream)) {
      return (BCPGInputStream)paramInputStream;
    }
    return new BCPGInputStream(paramInputStream);
  }
  
  static TrustPacket readOptionalTrustPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    return paramBCPGInputStream.nextPacketTag() == 12 ? (TrustPacket)paramBCPGInputStream.readPacket() : null;
  }
  
  static List readSignaturesAndTrust(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    try
    {
      ArrayList localArrayList = new ArrayList();
      while (paramBCPGInputStream.nextPacketTag() == 2)
      {
        SignaturePacket localSignaturePacket = (SignaturePacket)paramBCPGInputStream.readPacket();
        TrustPacket localTrustPacket = readOptionalTrustPacket(paramBCPGInputStream);
        localArrayList.add(new PGPSignature(localSignaturePacket, localTrustPacket));
      }
      return localArrayList;
    }
    catch (PGPException localPGPException)
    {
      throw new IOException("can't create signature object: " + localPGPException.getMessage() + ", cause: " + localPGPException.getUnderlyingException().toString());
    }
  }
  
  static void readUserIDs(BCPGInputStream paramBCPGInputStream, List paramList1, List paramList2, List paramList3)
    throws IOException
  {
    while ((paramBCPGInputStream.nextPacketTag() == 13) || (paramBCPGInputStream.nextPacketTag() == 17))
    {
      Packet localPacket = paramBCPGInputStream.readPacket();
      Object localObject;
      if ((localPacket instanceof UserIDPacket))
      {
        localObject = (UserIDPacket)localPacket;
        paramList1.add(((UserIDPacket)localObject).getID());
      }
      else
      {
        localObject = (UserAttributePacket)localPacket;
        paramList1.add(new PGPUserAttributeSubpacketVector(((UserAttributePacket)localObject).getSubpackets()));
      }
      paramList2.add(readOptionalTrustPacket(paramBCPGInputStream));
      paramList3.add(readSignaturesAndTrust(paramBCPGInputStream));
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPKeyRing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */