package org.bouncycastle.openpgp;

import java.security.KeyPair;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Date;

public class PGPKeyPair
{
  PGPPublicKey pub;
  PGPPrivateKey priv;
  
  public PGPKeyPair(int paramInt, KeyPair paramKeyPair, Date paramDate, String paramString)
    throws PGPException, NoSuchProviderException
  {
    this(paramInt, paramKeyPair.getPublic(), paramKeyPair.getPrivate(), paramDate, paramString);
  }
  
  public PGPKeyPair(int paramInt, PublicKey paramPublicKey, PrivateKey paramPrivateKey, Date paramDate, String paramString)
    throws PGPException, NoSuchProviderException
  {
    this.pub = new PGPPublicKey(paramInt, paramPublicKey, paramDate, paramString);
    this.priv = new PGPPrivateKey(paramPrivateKey, this.pub.getKeyID());
  }
  
  public PGPKeyPair(PGPPublicKey paramPGPPublicKey, PGPPrivateKey paramPGPPrivateKey)
  {
    this.pub = paramPGPPublicKey;
    this.priv = paramPGPPrivateKey;
  }
  
  public long getKeyID()
  {
    return this.pub.getKeyID();
  }
  
  public PGPPublicKey getPublicKey()
  {
    return this.pub;
  }
  
  public PGPPrivateKey getPrivateKey()
  {
    return this.priv;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPKeyPair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */