package org.bouncycastle.openpgp;

import java.io.EOFException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.DigestInputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchProviderException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.InputStreamPacket;
import org.bouncycastle.bcpg.PublicKeyEncSessionPacket;
import org.bouncycastle.bcpg.SymmetricEncIntegrityPacket;
import org.bouncycastle.jce.interfaces.ElGamalKey;
import org.bouncycastle.jce.spec.ElGamalParameterSpec;

public class PGPPublicKeyEncryptedData
  extends PGPEncryptedData
{
  PublicKeyEncSessionPacket keyData;
  
  PGPPublicKeyEncryptedData(PublicKeyEncSessionPacket paramPublicKeyEncSessionPacket, InputStreamPacket paramInputStreamPacket)
  {
    super(paramInputStreamPacket);
    this.keyData = paramPublicKeyEncSessionPacket;
  }
  
  private static Cipher getKeyCipher(int paramInt, String paramString)
    throws NoSuchProviderException, PGPException
  {
    try
    {
      switch (paramInt)
      {
      case 1: 
      case 2: 
        return Cipher.getInstance("RSA/ECB/PKCS1Padding", paramString);
      case 16: 
      case 20: 
        return Cipher.getInstance("ElGamal/ECB/PKCS1Padding", paramString);
      }
      throw new PGPException("unknown asymmetric algorithm: " + paramInt);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw localNoSuchProviderException;
    }
    catch (PGPException localPGPException)
    {
      throw localPGPException;
    }
    catch (Exception localException)
    {
      throw new PGPException("Exception creating cipher", localException);
    }
  }
  
  private boolean confirmCheckSum(byte[] paramArrayOfByte)
  {
    int i = 0;
    for (int j = 1; j != paramArrayOfByte.length - 2; j++) {
      i += (paramArrayOfByte[j] & 0xFF);
    }
    return (paramArrayOfByte[(paramArrayOfByte.length - 2)] == (byte)(i >> 8)) && (paramArrayOfByte[(paramArrayOfByte.length - 1)] == (byte)i);
  }
  
  public long getKeyID()
  {
    return this.keyData.getKeyID();
  }
  
  public InputStream getDataStream(PGPPrivateKey paramPGPPrivateKey, String paramString)
    throws PGPException, NoSuchProviderException
  {
    return getDataStream(paramPGPPrivateKey, paramString, paramString);
  }
  
  public InputStream getDataStream(PGPPrivateKey paramPGPPrivateKey, String paramString1, String paramString2)
    throws PGPException, NoSuchProviderException
  {
    Cipher localCipher1 = getKeyCipher(this.keyData.getAlgorithm(), paramString1);
    try
    {
      localCipher1.init(2, paramPGPPrivateKey.getKey());
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new PGPException("error setting asymmetric cipher", localInvalidKeyException);
    }
    BigInteger[] arrayOfBigInteger = this.keyData.getEncSessionKey();
    Object localObject;
    byte[] arrayOfByte2;
    int j;
    if ((this.keyData.getAlgorithm() == 2) || (this.keyData.getAlgorithm() == 1))
    {
      localObject = arrayOfBigInteger[0].toByteArray();
      if (localObject[0] == 0) {
        localCipher1.update((byte[])localObject, 1, localObject.length - 1);
      } else {
        localCipher1.update((byte[])localObject);
      }
    }
    else
    {
      localObject = (ElGamalKey)paramPGPPrivateKey.getKey();
      int i = (((ElGamalKey)localObject).getParameters().getP().bitLength() + 7) / 8;
      byte[] arrayOfByte1 = new byte[i];
      arrayOfByte2 = arrayOfBigInteger[0].toByteArray();
      if (arrayOfByte2.length > i)
      {
        localCipher1.update(arrayOfByte2, 1, arrayOfByte2.length - 1);
      }
      else
      {
        System.arraycopy(arrayOfByte2, 0, arrayOfByte1, arrayOfByte1.length - arrayOfByte2.length, arrayOfByte2.length);
        localCipher1.update(arrayOfByte1);
      }
      arrayOfByte2 = arrayOfBigInteger[1].toByteArray();
      for (j = 0; j != arrayOfByte1.length; j++) {
        arrayOfByte1[j] = 0;
      }
      if (arrayOfByte2.length > i)
      {
        localCipher1.update(arrayOfByte2, 1, arrayOfByte2.length - 1);
      }
      else
      {
        System.arraycopy(arrayOfByte2, 0, arrayOfByte1, arrayOfByte1.length - arrayOfByte2.length, arrayOfByte2.length);
        localCipher1.update(arrayOfByte1);
      }
    }
    try
    {
      localObject = localCipher1.doFinal();
    }
    catch (Exception localException1)
    {
      throw new PGPException("exception decrypting secret key", localException1);
    }
    if (!confirmCheckSum((byte[])localObject)) {
      throw new PGPKeyValidationException("key checksum failed");
    }
    Cipher localCipher2;
    try
    {
      if ((this.encData instanceof SymmetricEncIntegrityPacket)) {
        localCipher2 = Cipher.getInstance(PGPUtil.getSymmetricCipherName(localObject[0]) + "/CFB/NoPadding", paramString2);
      } else {
        localCipher2 = Cipher.getInstance(PGPUtil.getSymmetricCipherName(localObject[0]) + "/OpenPGPCFB/NoPadding", paramString2);
      }
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw localNoSuchProviderException;
    }
    catch (PGPException localPGPException1)
    {
      throw localPGPException1;
    }
    catch (Exception localException2)
    {
      throw new PGPException("exception creating cipher", localException2);
    }
    if (localCipher2 != null) {
      try
      {
        SecretKeySpec localSecretKeySpec = new SecretKeySpec((byte[])localObject, 1, localObject.length - 3, PGPUtil.getSymmetricCipherName(localObject[0]));
        arrayOfByte2 = new byte[localCipher2.getBlockSize()];
        localCipher2.init(2, localSecretKeySpec, new IvParameterSpec(arrayOfByte2));
        this.encStream = new BCPGInputStream(new CipherInputStream(this.encData.getInputStream(), localCipher2));
        if ((this.encData instanceof SymmetricEncIntegrityPacket))
        {
          this.truncStream = new PGPEncryptedData.TruncatedStream(this, this.encStream);
          this.encStream = new DigestInputStream(this.truncStream, MessageDigest.getInstance(PGPUtil.getDigestName(2), paramString2));
        }
        for (j = 0; j != arrayOfByte2.length; j++)
        {
          k = this.encStream.read();
          if (k < 0) {
            throw new EOFException("unexpected end of stream.");
          }
          arrayOfByte2[j] = ((byte)k);
        }
        j = this.encStream.read();
        int k = this.encStream.read();
        if ((j < 0) || (k < 0)) {
          throw new EOFException("unexpected end of stream.");
        }
        return this.encStream;
      }
      catch (PGPException localPGPException2)
      {
        throw localPGPException2;
      }
      catch (Exception localException3)
      {
        throw new PGPException("Exception starting decryption", localException3);
      }
    }
    return this.encData.getInputStream();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPPublicKeyEncryptedData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */