package org.bouncycastle.openpgp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import org.bouncycastle.bcpg.BCPGInputStream;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.OnePassSignaturePacket;

public class PGPOnePassSignature
{
  private OnePassSignaturePacket sigPack;
  private int signatureType;
  private Signature sig;
  private byte lastb;
  
  PGPOnePassSignature(BCPGInputStream paramBCPGInputStream)
    throws IOException, PGPException
  {
    this((OnePassSignaturePacket)paramBCPGInputStream.readPacket());
  }
  
  PGPOnePassSignature(OnePassSignaturePacket paramOnePassSignaturePacket)
    throws PGPException
  {
    this.sigPack = paramOnePassSignaturePacket;
    this.signatureType = paramOnePassSignaturePacket.getSignatureType();
    try
    {
      this.sig = Signature.getInstance(PGPUtil.getSignatureName(paramOnePassSignaturePacket.getKeyAlgorithm(), paramOnePassSignaturePacket.getHashAlgorithm()), PGPUtil.getDefaultProvider());
    }
    catch (Exception localException)
    {
      throw new PGPException("can't set up signature object.", localException);
    }
  }
  
  public void initVerify(PGPPublicKey paramPGPPublicKey, String paramString)
    throws NoSuchProviderException, PGPException
  {
    this.lastb = 0;
    try
    {
      this.sig.initVerify(paramPGPPublicKey.getKey(paramString));
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new PGPException("invalid key.", localInvalidKeyException);
    }
  }
  
  public void update(byte paramByte)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      if (paramByte == 13)
      {
        this.sig.update((byte)13);
        this.sig.update((byte)10);
      }
      else if (paramByte == 10)
      {
        if (this.lastb != 13)
        {
          this.sig.update((byte)13);
          this.sig.update((byte)10);
        }
      }
      else
      {
        this.sig.update(paramByte);
      }
      this.lastb = paramByte;
    }
    else
    {
      this.sig.update(paramByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte)
    throws SignatureException
  {
    if (this.signatureType == 1) {
      for (int i = 0; i != paramArrayOfByte.length; i++) {
        update(paramArrayOfByte[i]);
      }
    } else {
      this.sig.update(paramArrayOfByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      int i = paramInt1 + paramInt2;
      for (int j = paramInt1; j != i; j++) {
        update(paramArrayOfByte[j]);
      }
    }
    else
    {
      this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
  
  public boolean verify(PGPSignature paramPGPSignature)
    throws PGPException, SignatureException
  {
    this.sig.update(paramPGPSignature.getSignatureTrailer());
    return this.sig.verify(paramPGPSignature.getSignature());
  }
  
  public long getKeyID()
  {
    return this.sigPack.getKeyID();
  }
  
  public int getSignatureType()
  {
    return this.sigPack.getSignatureType();
  }
  
  public int getHashAlgorithm()
  {
    return this.sigPack.getHashAlgorithm();
  }
  
  public int getKeyAlgorithm()
  {
    return this.sigPack.getKeyAlgorithm();
  }
  
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    encode(localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    BCPGOutputStream localBCPGOutputStream;
    if ((paramOutputStream instanceof BCPGOutputStream)) {
      localBCPGOutputStream = (BCPGOutputStream)paramOutputStream;
    } else {
      localBCPGOutputStream = new BCPGOutputStream(paramOutputStream);
    }
    localBCPGOutputStream.writePacket(this.sigPack);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPOnePassSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */