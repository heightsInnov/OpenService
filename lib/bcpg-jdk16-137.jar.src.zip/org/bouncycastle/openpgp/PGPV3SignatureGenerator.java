package org.bouncycastle.openpgp;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Date;
import org.bouncycastle.bcpg.MPInteger;
import org.bouncycastle.bcpg.OnePassSignaturePacket;
import org.bouncycastle.bcpg.SignaturePacket;

public class PGPV3SignatureGenerator
{
  private int keyAlgorithm;
  private int hashAlgorithm;
  private PGPPrivateKey privKey;
  private Signature sig;
  private MessageDigest dig;
  private int signatureType;
  private byte lastb;
  
  public PGPV3SignatureGenerator(int paramInt1, int paramInt2, String paramString)
    throws NoSuchAlgorithmException, NoSuchProviderException, PGPException
  {
    this.keyAlgorithm = paramInt1;
    this.hashAlgorithm = paramInt2;
    this.dig = PGPUtil.getDigestInstance(PGPUtil.getDigestName(paramInt2), paramString);
    this.sig = Signature.getInstance(PGPUtil.getSignatureName(paramInt1, paramInt2), paramString);
  }
  
  public void initSign(int paramInt, PGPPrivateKey paramPGPPrivateKey)
    throws PGPException
  {
    this.privKey = paramPGPPrivateKey;
    this.signatureType = paramInt;
    try
    {
      this.sig.initSign(paramPGPPrivateKey.getKey());
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new PGPException("invalid key.", localInvalidKeyException);
    }
    this.dig.reset();
    this.lastb = 0;
  }
  
  public void update(byte paramByte)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      if (paramByte == 13)
      {
        this.sig.update((byte)13);
        this.sig.update((byte)10);
        this.dig.update((byte)13);
        this.dig.update((byte)10);
      }
      else if (paramByte == 10)
      {
        if (this.lastb != 13)
        {
          this.sig.update((byte)13);
          this.sig.update((byte)10);
          this.dig.update((byte)13);
          this.dig.update((byte)10);
        }
      }
      else
      {
        this.sig.update(paramByte);
        this.dig.update(paramByte);
      }
      this.lastb = paramByte;
    }
    else
    {
      this.sig.update(paramByte);
      this.dig.update(paramByte);
    }
  }
  
  public void update(byte[] paramArrayOfByte)
    throws SignatureException
  {
    update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws SignatureException
  {
    if (this.signatureType == 1)
    {
      int i = paramInt1 + paramInt2;
      for (int j = paramInt1; j != i; j++) {
        update(paramArrayOfByte[j]);
      }
    }
    else
    {
      this.sig.update(paramArrayOfByte, paramInt1, paramInt2);
      this.dig.update(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
  
  public PGPOnePassSignature generateOnePassVersion(boolean paramBoolean)
    throws PGPException
  {
    return new PGPOnePassSignature(new OnePassSignaturePacket(this.signatureType, this.hashAlgorithm, this.keyAlgorithm, this.privKey.getKeyID(), paramBoolean));
  }
  
  public PGPSignature generate()
    throws PGPException, SignatureException
  {
    long l = new Date().getTime() / 1000L;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(this.signatureType);
    localByteArrayOutputStream.write((byte)(int)(l >> 24));
    localByteArrayOutputStream.write((byte)(int)(l >> 16));
    localByteArrayOutputStream.write((byte)(int)(l >> 8));
    localByteArrayOutputStream.write((byte)(int)l);
    byte[] arrayOfByte1 = localByteArrayOutputStream.toByteArray();
    this.sig.update(arrayOfByte1);
    this.dig.update(arrayOfByte1);
    MPInteger[] arrayOfMPInteger;
    if ((this.keyAlgorithm == 3) || (this.keyAlgorithm == 1))
    {
      arrayOfMPInteger = new MPInteger[1];
      arrayOfMPInteger[0] = new MPInteger(new BigInteger(1, this.sig.sign()));
    }
    else
    {
      arrayOfMPInteger = PGPUtil.dsaSigToMpi(this.sig.sign());
    }
    byte[] arrayOfByte2 = this.dig.digest();
    byte[] arrayOfByte3 = new byte[2];
    arrayOfByte3[0] = arrayOfByte2[0];
    arrayOfByte3[1] = arrayOfByte2[1];
    return new PGPSignature(new SignaturePacket(3, this.signatureType, this.privKey.getKeyID(), this.keyAlgorithm, this.hashAlgorithm, l * 1000L, arrayOfByte3, arrayOfMPInteger));
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPV3SignatureGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */