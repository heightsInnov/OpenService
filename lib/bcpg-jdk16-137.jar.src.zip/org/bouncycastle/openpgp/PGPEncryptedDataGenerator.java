package org.bouncycastle.openpgp;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.DigestOutputStream;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import org.bouncycastle.bcpg.BCPGOutputStream;
import org.bouncycastle.bcpg.ContainedPacket;
import org.bouncycastle.bcpg.PublicKeyEncSessionPacket;
import org.bouncycastle.bcpg.S2K;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.bcpg.SymmetricKeyEncSessionPacket;

public class PGPEncryptedDataGenerator
  implements SymmetricKeyAlgorithmTags, StreamGenerator
{
  private BCPGOutputStream pOut;
  private CipherOutputStream cOut;
  private Cipher c;
  private boolean withIntegrityPacket = false;
  private boolean oldFormat = false;
  private DigestOutputStream digestOut;
  private List methods = new ArrayList();
  private int defAlgorithm;
  private SecureRandom rand;
  private String defProvider;
  
  public PGPEncryptedDataGenerator(int paramInt, SecureRandom paramSecureRandom, String paramString)
  {
    this.defAlgorithm = paramInt;
    this.rand = paramSecureRandom;
    this.defProvider = paramString;
  }
  
  public PGPEncryptedDataGenerator(int paramInt, boolean paramBoolean, SecureRandom paramSecureRandom, String paramString)
  {
    this.defAlgorithm = paramInt;
    this.rand = paramSecureRandom;
    this.defProvider = paramString;
    this.withIntegrityPacket = paramBoolean;
  }
  
  public PGPEncryptedDataGenerator(int paramInt, SecureRandom paramSecureRandom, boolean paramBoolean, String paramString)
  {
    this.defAlgorithm = paramInt;
    this.rand = paramSecureRandom;
    this.defProvider = paramString;
    this.oldFormat = paramBoolean;
  }
  
  public void addMethod(char[] paramArrayOfChar)
    throws NoSuchProviderException, PGPException
  {
    byte[] arrayOfByte = new byte[8];
    this.rand.nextBytes(arrayOfByte);
    S2K localS2K = new S2K(2, arrayOfByte, 96);
    this.methods.add(new PBEMethod(this.defAlgorithm, localS2K, PGPUtil.makeKeyFromPassPhrase(this.defAlgorithm, localS2K, paramArrayOfChar, this.defProvider)));
  }
  
  public void addMethod(PGPPublicKey paramPGPPublicKey)
    throws NoSuchProviderException, PGPException
  {
    if (!paramPGPPublicKey.isEncryptionKey()) {
      throw new IllegalArgumentException("passed in key not an encryption key!");
    }
    this.methods.add(new PubMethod(paramPGPPublicKey));
  }
  
  private void addCheckSum(byte[] paramArrayOfByte)
  {
    int i = 0;
    for (int j = 1; j != paramArrayOfByte.length - 2; j++) {
      i += (paramArrayOfByte[j] & 0xFF);
    }
    paramArrayOfByte[(paramArrayOfByte.length - 2)] = ((byte)(i >> 8));
    paramArrayOfByte[(paramArrayOfByte.length - 1)] = ((byte)i);
  }
  
  private byte[] createSessionInfo(int paramInt, Key paramKey)
  {
    byte[] arrayOfByte1 = paramKey.getEncoded();
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length + 3];
    arrayOfByte2[0] = ((byte)paramInt);
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 1, arrayOfByte1.length);
    addCheckSum(arrayOfByte2);
    return arrayOfByte2;
  }
  
  private OutputStream open(OutputStream paramOutputStream, long paramLong, byte[] paramArrayOfByte)
    throws IOException, PGPException, IllegalStateException
  {
    if (this.cOut != null) {
      throw new IllegalStateException("generator already in open state");
    }
    if (this.methods.size() == 0) {
      throw new IllegalStateException("no encryption methods specified");
    }
    Object localObject1 = null;
    this.pOut = new BCPGOutputStream(paramOutputStream);
    Object localObject4;
    if (this.methods.size() == 1)
    {
      if ((this.methods.get(0) instanceof PBEMethod))
      {
        localObject2 = (PBEMethod)this.methods.get(0);
        localObject1 = ((PBEMethod)localObject2).getKey();
      }
      else
      {
        localObject1 = PGPUtil.makeRandomKey(this.defAlgorithm, this.rand);
        localObject2 = createSessionInfo(this.defAlgorithm, (Key)localObject1);
        PubMethod localPubMethod = (PubMethod)this.methods.get(0);
        try
        {
          localPubMethod.addSessionInfo((byte[])localObject2);
        }
        catch (Exception localException2)
        {
          throw new PGPException("exception encrypting session key", localException2);
        }
      }
      this.pOut.writePacket((ContainedPacket)this.methods.get(0));
    }
    else
    {
      localObject1 = PGPUtil.makeRandomKey(this.defAlgorithm, this.rand);
      localObject2 = createSessionInfo(this.defAlgorithm, (Key)localObject1);
      for (int i = 0; i != this.methods.size(); i++)
      {
        localObject4 = (EncMethod)this.methods.get(i);
        try
        {
          ((EncMethod)localObject4).addSessionInfo((byte[])localObject2);
        }
        catch (Exception localException3)
        {
          throw new PGPException("exception encrypting session key", localException3);
        }
        this.pOut.writePacket((ContainedPacket)localObject4);
      }
    }
    Object localObject2 = PGPUtil.getSymmetricCipherName(this.defAlgorithm);
    if (localObject2 == null) {
      throw new PGPException("null cipher specified");
    }
    try
    {
      if (this.withIntegrityPacket) {
        this.c = Cipher.getInstance((String)localObject2 + "/CFB/NoPadding", this.defProvider);
      } else {
        this.c = Cipher.getInstance((String)localObject2 + "/OpenPGPCFB/NoPadding", this.defProvider);
      }
      this.c.init(1, (Key)localObject1, new IvParameterSpec(new byte[this.c.getBlockSize()]));
      if (paramArrayOfByte == null)
      {
        if (this.withIntegrityPacket)
        {
          this.pOut = new BCPGOutputStream(paramOutputStream, 18, paramLong + this.c.getBlockSize() + 2L + 1L + 22L);
          this.pOut.write(1);
        }
        else
        {
          this.pOut = new BCPGOutputStream(paramOutputStream, 9, paramLong + this.c.getBlockSize() + 2L, this.oldFormat);
        }
      }
      else if (this.withIntegrityPacket)
      {
        this.pOut = new BCPGOutputStream(paramOutputStream, 18, paramArrayOfByte);
        this.pOut.write(1);
      }
      else
      {
        this.pOut = new BCPGOutputStream(paramOutputStream, 9, paramArrayOfByte);
      }
      Object localObject3 = this.cOut = new CipherOutputStream(this.pOut, this.c);
      if (this.withIntegrityPacket)
      {
        localObject4 = PGPUtil.getDigestName(2);
        MessageDigest localMessageDigest = MessageDigest.getInstance((String)localObject4, this.defProvider);
        localObject3 = this.digestOut = new DigestOutputStream(this.cOut, localMessageDigest);
      }
      localObject4 = new byte[this.c.getBlockSize() + 2];
      this.rand.nextBytes((byte[])localObject4);
      localObject4[(localObject4.length - 1)] = localObject4[(localObject4.length - 3)];
      localObject4[(localObject4.length - 2)] = localObject4[(localObject4.length - 4)];
      ((OutputStream)localObject3).write((byte[])localObject4);
      return new WrappedGeneratorStream((OutputStream)localObject3, this);
    }
    catch (Exception localException1)
    {
      throw new PGPException("Exception creating cipher", localException1);
    }
  }
  
  public OutputStream open(OutputStream paramOutputStream, long paramLong)
    throws IOException, PGPException
  {
    return open(paramOutputStream, paramLong, null);
  }
  
  public OutputStream open(OutputStream paramOutputStream, byte[] paramArrayOfByte)
    throws IOException, PGPException
  {
    return open(paramOutputStream, 0L, paramArrayOfByte);
  }
  
  public void close()
    throws IOException
  {
    if (this.cOut != null)
    {
      if (this.digestOut != null)
      {
        BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(this.digestOut, 19, 20L);
        localBCPGOutputStream.flush();
        this.digestOut.flush();
        byte[] arrayOfByte = this.digestOut.getMessageDigest().digest();
        this.cOut.write(arrayOfByte);
      }
      this.cOut.flush();
      try
      {
        this.pOut.write(this.c.doFinal());
        this.pOut.finish();
      }
      catch (Exception localException)
      {
        throw new IOException(localException.toString());
      }
      this.cOut = null;
      this.pOut = null;
    }
  }
  
  private class PubMethod
    extends PGPEncryptedDataGenerator.EncMethod
  {
    PGPPublicKey pubKey;
    BigInteger[] data;
    
    PubMethod(PGPPublicKey paramPGPPublicKey)
    {
      super(null);
      this.pubKey = paramPGPPublicKey;
    }
    
    public void addSessionInfo(byte[] paramArrayOfByte)
      throws Exception
    {
      Cipher localCipher;
      switch (this.pubKey.getAlgorithm())
      {
      case 1: 
      case 2: 
        localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", PGPEncryptedDataGenerator.this.defProvider);
        break;
      case 16: 
      case 20: 
        localCipher = Cipher.getInstance("ElGamal/ECB/PKCS1Padding", PGPEncryptedDataGenerator.this.defProvider);
        break;
      case 17: 
        throw new PGPException("Can't use DSA for encryption.");
      case 19: 
        throw new PGPException("Can't use ECDSA for encryption.");
      case 3: 
      case 4: 
      case 5: 
      case 6: 
      case 7: 
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 13: 
      case 14: 
      case 15: 
      case 18: 
      default: 
        throw new PGPException("unknown asymmetric algorithm: " + this.pubKey.getAlgorithm());
      }
      PublicKey localPublicKey = this.pubKey.getKey(PGPEncryptedDataGenerator.this.defProvider);
      localCipher.init(1, localPublicKey);
      byte[] arrayOfByte1 = localCipher.doFinal(paramArrayOfByte);
      switch (this.pubKey.getAlgorithm())
      {
      case 1: 
      case 2: 
        this.data = new BigInteger[1];
        this.data[0] = new BigInteger(1, arrayOfByte1);
        break;
      case 16: 
      case 20: 
        byte[] arrayOfByte2 = new byte[arrayOfByte1.length / 2];
        byte[] arrayOfByte3 = new byte[arrayOfByte1.length / 2];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
        System.arraycopy(arrayOfByte1, arrayOfByte2.length, arrayOfByte3, 0, arrayOfByte3.length);
        this.data = new BigInteger[2];
        this.data[0] = new BigInteger(1, arrayOfByte2);
        this.data[1] = new BigInteger(1, arrayOfByte3);
        break;
      default: 
        throw new PGPException("unknown asymmetric algorithm: " + this.encAlgorithm);
      }
    }
    
    public void encode(BCPGOutputStream paramBCPGOutputStream)
      throws IOException
    {
      PublicKeyEncSessionPacket localPublicKeyEncSessionPacket = new PublicKeyEncSessionPacket(this.pubKey.getKeyID(), this.pubKey.getAlgorithm(), this.data);
      paramBCPGOutputStream.writePacket(localPublicKeyEncSessionPacket);
    }
  }
  
  private class PBEMethod
    extends PGPEncryptedDataGenerator.EncMethod
  {
    S2K s2k;
    
    PBEMethod(int paramInt, S2K paramS2K, Key paramKey)
    {
      super(null);
      this.encAlgorithm = paramInt;
      this.s2k = paramS2K;
      this.key = paramKey;
    }
    
    public Key getKey()
    {
      return this.key;
    }
    
    public void addSessionInfo(byte[] paramArrayOfByte)
      throws Exception
    {
      String str = PGPUtil.getSymmetricCipherName(this.encAlgorithm);
      Cipher localCipher = Cipher.getInstance(str + "/CFB/NoPadding", PGPEncryptedDataGenerator.this.defProvider);
      localCipher.init(1, this.key, new IvParameterSpec(new byte[localCipher.getBlockSize()]), PGPEncryptedDataGenerator.this.rand);
      this.sessionInfo = localCipher.doFinal(paramArrayOfByte, 0, paramArrayOfByte.length - 2);
    }
    
    public void encode(BCPGOutputStream paramBCPGOutputStream)
      throws IOException
    {
      SymmetricKeyEncSessionPacket localSymmetricKeyEncSessionPacket = new SymmetricKeyEncSessionPacket(this.encAlgorithm, this.s2k, this.sessionInfo);
      paramBCPGOutputStream.writePacket(localSymmetricKeyEncSessionPacket);
    }
  }
  
  private abstract class EncMethod
    extends ContainedPacket
  {
    protected byte[] sessionInfo;
    protected int encAlgorithm;
    protected Key key;
    
    private EncMethod() {}
    
    public abstract void addSessionInfo(byte[] paramArrayOfByte)
      throws Exception;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\openpgp\PGPEncryptedDataGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */