package org.bouncycastle.apache.bzip2;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class CBZip2OutputStream
  extends OutputStream
  implements BZip2Constants
{
  protected static final int SETMASK = 2097152;
  protected static final int CLEARMASK = -2097153;
  protected static final int GREATER_ICOST = 15;
  protected static final int LESSER_ICOST = 0;
  protected static final int SMALL_THRESH = 20;
  protected static final int DEPTH_THRESH = 10;
  protected static final int QSORT_STACK_SIZE = 1000;
  private boolean finished;
  int last;
  int origPtr;
  int blockSize100k;
  boolean blockRandomised;
  int bytesOut;
  int bsBuff;
  int bsLive;
  CRC mCrc = new CRC();
  private boolean[] inUse = new boolean['Ā'];
  private int nInUse;
  private char[] seqToUnseq = new char['Ā'];
  private char[] unseqToSeq = new char['Ā'];
  private char[] selector = new char['䙒'];
  private char[] selectorMtf = new char['䙒'];
  private char[] block = null;
  private int[] quadrant = null;
  private int[] zptr = null;
  private short[] szptr;
  private int[] ftab = null;
  private int nMTF;
  private int[] mtfFreq = new int['Ă'];
  private int workFactor;
  private int workDone;
  private int workLimit;
  private boolean firstAttempt;
  private int nBlocksRandomised;
  private int currentChar = -1;
  private int runLength = 0;
  boolean closed = false;
  private int blockCRC;
  private int combinedCRC;
  private int allowableBlockSize;
  private OutputStream bsStream;
  private int[] incs = { 1, 4, 13, 40, 121, 364, 1093, 3280, 9841, 29524, 88573, 265720, 797161, 2391484 };
  
  private static void panic()
  {
    System.out.println("panic");
  }
  
  private void makeMaps()
  {
    this.nInUse = 0;
    for (int i = 0; i < 256; i++) {
      if (this.inUse[i] != 0)
      {
        this.seqToUnseq[this.nInUse] = ((char)i);
        this.unseqToSeq[i] = ((char)this.nInUse);
        this.nInUse += 1;
      }
    }
  }
  
  protected static void hbMakeCodeLengths(char[] paramArrayOfChar, int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt1 = new int['Ą'];
    int[] arrayOfInt2 = new int['Ȅ'];
    int[] arrayOfInt3 = new int['Ȅ'];
    for (int n = 0; n < paramInt1; n++) {
      arrayOfInt2[(n + 1)] = ((paramArrayOfInt[n] == 0 ? 1 : paramArrayOfInt[n]) << 8);
    }
    for (;;)
    {
      int i = paramInt1;
      int j = 0;
      arrayOfInt1[0] = 0;
      arrayOfInt2[0] = 0;
      arrayOfInt3[0] = -2;
      int i4;
      int i5;
      for (n = 1; n <= paramInt1; n++)
      {
        arrayOfInt3[n] = -1;
        j++;
        arrayOfInt1[j] = n;
        i4 = j;
        i5 = arrayOfInt1[i4];
        while (arrayOfInt2[i5] < arrayOfInt2[arrayOfInt1[(i4 >> 1)]])
        {
          arrayOfInt1[i4] = arrayOfInt1[(i4 >> 1)];
          i4 >>= 1;
        }
        arrayOfInt1[i4] = i5;
      }
      if (j >= 260) {
        panic();
      }
      while (j > 1)
      {
        int k = arrayOfInt1[1];
        arrayOfInt1[1] = arrayOfInt1[j];
        j--;
        i4 = 0;
        i5 = 0;
        int i6 = 0;
        i4 = 1;
        i6 = arrayOfInt1[i4];
        for (;;)
        {
          i5 = i4 << 1;
          if (i5 > j) {
            break;
          }
          if ((i5 < j) && (arrayOfInt2[arrayOfInt1[(i5 + 1)]] < arrayOfInt2[arrayOfInt1[i5]])) {
            i5++;
          }
          if (arrayOfInt2[i6] < arrayOfInt2[arrayOfInt1[i5]]) {
            break;
          }
          arrayOfInt1[i4] = arrayOfInt1[i5];
          i4 = i5;
        }
        arrayOfInt1[i4] = i6;
        int m = arrayOfInt1[1];
        arrayOfInt1[1] = arrayOfInt1[j];
        j--;
        i4 = 0;
        i5 = 0;
        i6 = 0;
        i4 = 1;
        i6 = arrayOfInt1[i4];
        for (;;)
        {
          i5 = i4 << 1;
          if (i5 > j) {
            break;
          }
          if ((i5 < j) && (arrayOfInt2[arrayOfInt1[(i5 + 1)]] < arrayOfInt2[arrayOfInt1[i5]])) {
            i5++;
          }
          if (arrayOfInt2[i6] < arrayOfInt2[arrayOfInt1[i5]]) {
            break;
          }
          arrayOfInt1[i4] = arrayOfInt1[i5];
          i4 = i5;
        }
        arrayOfInt1[i4] = i6;
        i++;
        arrayOfInt3[k] = (arrayOfInt3[m] = i);
        arrayOfInt2[i] = ((arrayOfInt2[k] & 0xFF00) + (arrayOfInt2[m] & 0xFF00) | 1 + ((arrayOfInt2[k] & 0xFF) > (arrayOfInt2[m] & 0xFF) ? arrayOfInt2[k] & 0xFF : arrayOfInt2[m] & 0xFF));
        arrayOfInt3[i] = -1;
        j++;
        arrayOfInt1[j] = i;
        i4 = 0;
        i5 = 0;
        i4 = j;
        i5 = arrayOfInt1[i4];
        while (arrayOfInt2[i5] < arrayOfInt2[arrayOfInt1[(i4 >> 1)]])
        {
          arrayOfInt1[i4] = arrayOfInt1[(i4 >> 1)];
          i4 >>= 1;
        }
        arrayOfInt1[i4] = i5;
      }
      if (i >= 516) {
        panic();
      }
      int i3 = 0;
      int i1;
      for (n = 1; n <= paramInt1; n++)
      {
        i1 = 0;
        int i2 = n;
        while (arrayOfInt3[i2] >= 0)
        {
          i2 = arrayOfInt3[i2];
          i1++;
        }
        paramArrayOfChar[(n - 1)] = ((char)i1);
        if (i1 > paramInt2) {
          i3 = 1;
        }
      }
      if (i3 == 0) {
        break;
      }
      for (n = 1; n < paramInt1; n++)
      {
        i1 = arrayOfInt2[n] >> 8;
        i1 = 1 + i1 / 2;
        arrayOfInt2[n] = (i1 << 8);
      }
    }
  }
  
  public CBZip2OutputStream(OutputStream paramOutputStream)
    throws IOException
  {
    this(paramOutputStream, 9);
  }
  
  public CBZip2OutputStream(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    paramOutputStream.write(66);
    paramOutputStream.write(90);
    bsSetStream(paramOutputStream);
    this.workFactor = 50;
    if (paramInt > 9) {
      paramInt = 9;
    }
    if (paramInt < 1) {
      paramInt = 1;
    }
    this.blockSize100k = paramInt;
    allocateCompressStructures();
    initialize();
    initBlock();
  }
  
  public void write(int paramInt)
    throws IOException
  {
    int i = (256 + paramInt) % 256;
    if (this.currentChar != -1)
    {
      if (this.currentChar == i)
      {
        this.runLength += 1;
        if (this.runLength > 254)
        {
          writeRun();
          this.currentChar = -1;
          this.runLength = 0;
        }
      }
      else
      {
        writeRun();
        this.runLength = 1;
        this.currentChar = i;
      }
    }
    else
    {
      this.currentChar = i;
      this.runLength += 1;
    }
  }
  
  private void writeRun()
    throws IOException
  {
    if (this.last < this.allowableBlockSize)
    {
      this.inUse[this.currentChar] = true;
      for (int i = 0; i < this.runLength; i++) {
        this.mCrc.updateCRC((char)this.currentChar);
      }
      switch (this.runLength)
      {
      case 1: 
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        break;
      case 2: 
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        break;
      case 3: 
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        break;
      default: 
        this.inUse[(this.runLength - 4)] = true;
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)this.currentChar);
        this.last += 1;
        this.block[(this.last + 1)] = ((char)(this.runLength - 4));
        break;
      }
    }
    else
    {
      endBlock();
      initBlock();
      writeRun();
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    close();
    super.finalize();
  }
  
  public void close()
    throws IOException
  {
    if (this.closed) {
      return;
    }
    finish();
    this.closed = true;
    super.close();
    this.bsStream.close();
  }
  
  public void finish()
    throws IOException
  {
    if (this.finished) {
      return;
    }
    if (this.runLength > 0) {
      writeRun();
    }
    this.currentChar = -1;
    endBlock();
    endCompression();
    this.finished = true;
    flush();
  }
  
  public void flush()
    throws IOException
  {
    super.flush();
    this.bsStream.flush();
  }
  
  private void initialize()
    throws IOException
  {
    this.bytesOut = 0;
    this.nBlocksRandomised = 0;
    bsPutUChar(104);
    bsPutUChar(48 + this.blockSize100k);
    this.combinedCRC = 0;
  }
  
  private void initBlock()
  {
    this.mCrc.initialiseCRC();
    this.last = -1;
    for (int i = 0; i < 256; i++) {
      this.inUse[i] = false;
    }
    this.allowableBlockSize = (100000 * this.blockSize100k - 20);
  }
  
  private void endBlock()
    throws IOException
  {
    this.blockCRC = this.mCrc.getFinalCRC();
    this.combinedCRC = (this.combinedCRC << 1 | this.combinedCRC >>> 31);
    this.combinedCRC ^= this.blockCRC;
    doReversibleTransformation();
    bsPutUChar(49);
    bsPutUChar(65);
    bsPutUChar(89);
    bsPutUChar(38);
    bsPutUChar(83);
    bsPutUChar(89);
    bsPutint(this.blockCRC);
    if (this.blockRandomised)
    {
      bsW(1, 1);
      this.nBlocksRandomised += 1;
    }
    else
    {
      bsW(1, 0);
    }
    moveToFrontCodeAndSend();
  }
  
  private void endCompression()
    throws IOException
  {
    bsPutUChar(23);
    bsPutUChar(114);
    bsPutUChar(69);
    bsPutUChar(56);
    bsPutUChar(80);
    bsPutUChar(144);
    bsPutint(this.combinedCRC);
    bsFinishedWithStream();
  }
  
  private void hbAssignCodes(int[] paramArrayOfInt, char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3)
  {
    int j = 0;
    for (int i = paramInt1; i <= paramInt2; i++)
    {
      for (int k = 0; k < paramInt3; k++) {
        if (paramArrayOfChar[k] == i)
        {
          paramArrayOfInt[k] = j;
          j++;
        }
      }
      j <<= 1;
    }
  }
  
  private void bsSetStream(OutputStream paramOutputStream)
  {
    this.bsStream = paramOutputStream;
    this.bsLive = 0;
    this.bsBuff = 0;
    this.bytesOut = 0;
  }
  
  private void bsFinishedWithStream()
    throws IOException
  {
    while (this.bsLive > 0)
    {
      int i = this.bsBuff >> 24;
      try
      {
        this.bsStream.write(i);
      }
      catch (IOException localIOException)
      {
        throw localIOException;
      }
      this.bsBuff <<= 8;
      this.bsLive -= 8;
      this.bytesOut += 1;
    }
  }
  
  private void bsW(int paramInt1, int paramInt2)
    throws IOException
  {
    while (this.bsLive >= 8)
    {
      int i = this.bsBuff >> 24;
      try
      {
        this.bsStream.write(i);
      }
      catch (IOException localIOException)
      {
        throw localIOException;
      }
      this.bsBuff <<= 8;
      this.bsLive -= 8;
      this.bytesOut += 1;
    }
    this.bsBuff |= paramInt2 << 32 - this.bsLive - paramInt1;
    this.bsLive += paramInt1;
  }
  
  private void bsPutUChar(int paramInt)
    throws IOException
  {
    bsW(8, paramInt);
  }
  
  private void bsPutint(int paramInt)
    throws IOException
  {
    bsW(8, paramInt >> 24 & 0xFF);
    bsW(8, paramInt >> 16 & 0xFF);
    bsW(8, paramInt >> 8 & 0xFF);
    bsW(8, paramInt & 0xFF);
  }
  
  private void bsPutIntVS(int paramInt1, int paramInt2)
    throws IOException
  {
    bsW(paramInt1, paramInt2);
  }
  
  private void sendMTFValues()
    throws IOException
  {
    char[][] arrayOfChar = new char[6]['Ă'];
    int i6 = 0;
    int i7 = this.nInUse + 2;
    int i;
    for (int j = 0; j < 6; j++) {
      for (i = 0; i < i7; i++) {
        arrayOfChar[j][i] = 15;
      }
    }
    if (this.nMTF <= 0) {
      panic();
    }
    int i11;
    if (this.nMTF < 200) {
      i11 = 2;
    } else if (this.nMTF < 600) {
      i11 = 3;
    } else if (this.nMTF < 1200) {
      i11 = 4;
    } else if (this.nMTF < 2400) {
      i11 = 5;
    } else {
      i11 = 6;
    }
    int i13 = i11;
    int i14 = this.nMTF;
    int n = 0;
    int i1;
    int i16;
    while (i13 > 0)
    {
      int i15 = i14 / i13;
      i1 = n - 1;
      i16 = 0;
      while ((i16 < i15) && (i1 < i7 - 1))
      {
        i1++;
        i16 += this.mtfFreq[i1];
      }
      if ((i1 > n) && (i13 != i11) && (i13 != 1) && ((i11 - i13) % 2 == 1))
      {
        i16 -= this.mtfFreq[i1];
        i1--;
      }
      for (i = 0; i < i7; i++) {
        if ((i >= n) && (i <= i1)) {
          arrayOfChar[(i13 - 1)][i] = 0;
        } else {
          arrayOfChar[(i13 - 1)][i] = 15;
        }
      }
      i13--;
      n = i1 + 1;
      i14 -= i16;
    }
    int[][] arrayOfInt = new int[6]['Ă'];
    int[] arrayOfInt1 = new int[6];
    short[] arrayOfShort = new short[6];
    int i20;
    int i19;
    int i17;
    for (int i5 = 0; i5 < 4; i5++)
    {
      for (j = 0; j < i11; j++) {
        arrayOfInt1[j] = 0;
      }
      for (j = 0; j < i11; j++) {
        for (i = 0; i < i7; i++) {
          arrayOfInt[j][i] = 0;
        }
      }
      i6 = 0;
      int i2 = 0;
      for (n = 0; n < this.nMTF; n = i1 + 1)
      {
        i1 = n + 50 - 1;
        if (i1 >= this.nMTF) {
          i1 = this.nMTF - 1;
        }
        for (j = 0; j < i11; j++) {
          arrayOfShort[j] = 0;
        }
        if (i11 == 6)
        {
          int i22;
          int i21;
          i16 = i17 = i19 = i20 = i21 = i22 = 0;
          for (k = n; k <= i1; k++)
          {
            int i23 = this.szptr[k];
            i16 = (short)(i16 + arrayOfChar[0][i23]);
            i17 = (short)(i17 + arrayOfChar[1][i23]);
            i19 = (short)(i19 + arrayOfChar[2][i23]);
            i20 = (short)(i20 + arrayOfChar[3][i23]);
            i21 = (short)(i21 + arrayOfChar[4][i23]);
            i22 = (short)(i22 + arrayOfChar[5][i23]);
          }
          arrayOfShort[0] = i16;
          arrayOfShort[1] = i17;
          arrayOfShort[2] = i19;
          arrayOfShort[3] = i20;
          arrayOfShort[4] = i21;
          arrayOfShort[5] = i22;
        }
        else
        {
          for (k = n; k <= i1; k++)
          {
            i16 = this.szptr[k];
            for (j = 0; j < i11; j++)
            {
              int tmp660_659 = j;
              short[] tmp660_657 = arrayOfShort;
              tmp660_657[tmp660_659] = ((short)(tmp660_657[tmp660_659] + arrayOfChar[j][i16]));
            }
          }
        }
        int i4 = 999999999;
        int i3 = -1;
        for (j = 0; j < i11; j++) {
          if (arrayOfShort[j] < i4)
          {
            i4 = arrayOfShort[j];
            i3 = j;
          }
        }
        i2 += i4;
        arrayOfInt1[i3] += 1;
        this.selector[i6] = ((char)i3);
        i6++;
        for (k = n; k <= i1; k++) {
          arrayOfInt[i3][this.szptr[k]] += 1;
        }
      }
      for (j = 0; j < i11; j++) {
        hbMakeCodeLengths(arrayOfChar[j], arrayOfInt[j], i7, 20);
      }
    }
    arrayOfInt = (int[][])null;
    arrayOfInt1 = null;
    arrayOfShort = null;
    if (i11 >= 8) {
      panic();
    }
    if ((i6 >= 32768) || (i6 > 18002)) {
      panic();
    }
    Object localObject = new char[6];
    for (int k = 0; k < i11; k++) {
      localObject[k] = ((char)k);
    }
    int m;
    for (k = 0; k < i6; k++)
    {
      i17 = this.selector[k];
      m = 0;
      i20 = localObject[m];
      while (i17 != i20)
      {
        m++;
        i19 = i20;
        i20 = localObject[m];
        localObject[m] = i19;
      }
      localObject[0] = i20;
      this.selectorMtf[k] = ((char)m);
    }
    localObject = new int[6]['Ă'];
    for (j = 0; j < i11; j++)
    {
      int i8 = 32;
      int i9 = 0;
      for (k = 0; k < i7; k++)
      {
        if (arrayOfChar[j][k] > i9) {
          i9 = arrayOfChar[j][k];
        }
        if (arrayOfChar[j][k] < i8) {
          i8 = arrayOfChar[j][k];
        }
      }
      if (i9 > 20) {
        panic();
      }
      if (i8 < 1) {
        panic();
      }
      hbAssignCodes(localObject[j], arrayOfChar[j], i8, i9, i7);
    }
    boolean[] arrayOfBoolean = new boolean[16];
    for (k = 0; k < 16; k++)
    {
      arrayOfBoolean[k] = false;
      for (m = 0; m < 16; m++) {
        if (this.inUse[(k * 16 + m)] != 0) {
          arrayOfBoolean[k] = true;
        }
      }
    }
    int i12 = this.bytesOut;
    for (k = 0; k < 16; k++) {
      if (arrayOfBoolean[k] != 0) {
        bsW(1, 1);
      } else {
        bsW(1, 0);
      }
    }
    for (k = 0; k < 16; k++) {
      if (arrayOfBoolean[k] != 0) {
        for (m = 0; m < 16; m++) {
          if (this.inUse[(k * 16 + m)] != 0) {
            bsW(1, 1);
          } else {
            bsW(1, 0);
          }
        }
      }
    }
    i12 = this.bytesOut;
    bsW(3, i11);
    bsW(15, i6);
    for (k = 0; k < i6; k++)
    {
      for (m = 0; m < this.selectorMtf[k]; m++) {
        bsW(1, 1);
      }
      bsW(1, 0);
    }
    i12 = this.bytesOut;
    for (j = 0; j < i11; j++)
    {
      int i18 = arrayOfChar[j][0];
      bsW(5, i18);
      for (k = 0; k < i7; k++)
      {
        while (i18 < arrayOfChar[j][k])
        {
          bsW(2, 2);
          i18++;
        }
        while (i18 > arrayOfChar[j][k])
        {
          bsW(2, 3);
          i18--;
        }
        bsW(1, 0);
      }
    }
    i12 = this.bytesOut;
    int i10 = 0;
    n = 0;
    while (n < this.nMTF)
    {
      i1 = n + 50 - 1;
      if (i1 >= this.nMTF) {
        i1 = this.nMTF - 1;
      }
      for (k = n; k <= i1; k++) {
        bsW(arrayOfChar[this.selector[i10]][this.szptr[k]], localObject[this.selector[i10]][this.szptr[k]]);
      }
      n = i1 + 1;
      i10++;
    }
    if (i10 != i6) {
      panic();
    }
  }
  
  private void moveToFrontCodeAndSend()
    throws IOException
  {
    bsPutIntVS(24, this.origPtr);
    generateMTFValues();
    sendMTFValues();
  }
  
  private void simpleSort(int paramInt1, int paramInt2, int paramInt3)
  {
    int m = paramInt2 - paramInt1 + 1;
    if (m < 2) {
      return;
    }
    for (int n = 0; this.incs[n] < m; n++) {}
    n--;
    while (n >= 0)
    {
      int k = this.incs[n];
      int i = paramInt1 + k;
      while (i <= paramInt2)
      {
        int i1 = this.zptr[i];
        int j = i;
        while (fullGtU(this.zptr[(j - k)] + paramInt3, i1 + paramInt3))
        {
          this.zptr[j] = this.zptr[(j - k)];
          j -= k;
          if (j <= paramInt1 + k - 1) {
            break;
          }
        }
        this.zptr[j] = i1;
        i++;
        if (i <= paramInt2)
        {
          i1 = this.zptr[i];
          j = i;
          while (fullGtU(this.zptr[(j - k)] + paramInt3, i1 + paramInt3))
          {
            this.zptr[j] = this.zptr[(j - k)];
            j -= k;
            if (j <= paramInt1 + k - 1) {
              break;
            }
          }
          this.zptr[j] = i1;
          i++;
          if (i <= paramInt2)
          {
            i1 = this.zptr[i];
            j = i;
            while (fullGtU(this.zptr[(j - k)] + paramInt3, i1 + paramInt3))
            {
              this.zptr[j] = this.zptr[(j - k)];
              j -= k;
              if (j <= paramInt1 + k - 1) {
                break;
              }
            }
            this.zptr[j] = i1;
            i++;
            if ((this.workDone > this.workLimit) && (this.firstAttempt)) {
              return;
            }
          }
        }
      }
      n--;
    }
  }
  
  private void vswap(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 0;
    while (paramInt3 > 0)
    {
      i = this.zptr[paramInt1];
      this.zptr[paramInt1] = this.zptr[paramInt2];
      this.zptr[paramInt2] = i;
      paramInt1++;
      paramInt2++;
      paramInt3--;
    }
  }
  
  private char med3(char paramChar1, char paramChar2, char paramChar3)
  {
    char c;
    if (paramChar1 > paramChar2)
    {
      c = paramChar1;
      paramChar1 = paramChar2;
      paramChar2 = c;
    }
    if (paramChar2 > paramChar3)
    {
      c = paramChar2;
      paramChar2 = paramChar3;
      paramChar3 = c;
    }
    if (paramChar1 > paramChar2) {
      paramChar2 = paramChar1;
    }
    return paramChar2;
  }
  
  private void qSort3(int paramInt1, int paramInt2, int paramInt3)
  {
    StackElem[] arrayOfStackElem = new StackElem['Ϩ'];
    for (int i7 = 0; i7 < 1000; i7++) {
      arrayOfStackElem[i7] = new StackElem(null);
    }
    int i3 = 0;
    arrayOfStackElem[i3].ll = paramInt1;
    arrayOfStackElem[i3].hh = paramInt2;
    arrayOfStackElem[i3].dd = paramInt3;
    i3++;
    while (i3 > 0)
    {
      if (i3 >= 1000) {
        panic();
      }
      i3--;
      int i4 = arrayOfStackElem[i3].ll;
      int i5 = arrayOfStackElem[i3].hh;
      int i6 = arrayOfStackElem[i3].dd;
      if ((i5 - i4 < 20) || (i6 > 10))
      {
        simpleSort(i4, i5, i6);
        if ((this.workDone <= this.workLimit) || (!this.firstAttempt)) {}
      }
      else
      {
        int n = med3(this.block[(this.zptr[i4] + i6 + 1)], this.block[(this.zptr[i5] + i6 + 1)], this.block[(this.zptr[(i4 + i5 >> 1)] + i6 + 1)]);
        int k;
        int i = k = i4;
        int m;
        int j = m = i5;
        int i1;
        for (;;)
        {
          if (i <= j)
          {
            i1 = this.block[(this.zptr[i] + i6 + 1)] - n;
            if (i1 == 0)
            {
              i7 = 0;
              i7 = this.zptr[i];
              this.zptr[i] = this.zptr[k];
              this.zptr[k] = i7;
              k++;
              i++;
              continue;
            }
            if (i1 <= 0)
            {
              i++;
              continue;
            }
          }
          while (i <= j)
          {
            i1 = this.block[(this.zptr[j] + i6 + 1)] - n;
            if (i1 == 0)
            {
              i7 = 0;
              i7 = this.zptr[j];
              this.zptr[j] = this.zptr[m];
              this.zptr[m] = i7;
              m--;
              j--;
            }
            else
            {
              if (i1 < 0) {
                break;
              }
              j--;
            }
          }
          if (i > j) {
            break;
          }
          i7 = 0;
          i7 = this.zptr[i];
          this.zptr[i] = this.zptr[j];
          this.zptr[j] = i7;
          i++;
          j--;
        }
        if (m < k)
        {
          arrayOfStackElem[i3].ll = i4;
          arrayOfStackElem[i3].hh = i5;
          arrayOfStackElem[i3].dd = (i6 + 1);
          i3++;
        }
        else
        {
          i1 = k - i4 < i - k ? k - i4 : i - k;
          vswap(i4, i - i1, i1);
          int i2 = i5 - m < m - j ? i5 - m : m - j;
          vswap(i, i5 - i2 + 1, i2);
          i1 = i4 + i - k - 1;
          i2 = i5 - (m - j) + 1;
          arrayOfStackElem[i3].ll = i4;
          arrayOfStackElem[i3].hh = i1;
          arrayOfStackElem[i3].dd = i6;
          i3++;
          arrayOfStackElem[i3].ll = (i1 + 1);
          arrayOfStackElem[i3].hh = (i2 - 1);
          arrayOfStackElem[i3].dd = (i6 + 1);
          i3++;
          arrayOfStackElem[i3].ll = i2;
          arrayOfStackElem[i3].hh = i5;
          arrayOfStackElem[i3].dd = i6;
          i3++;
        }
      }
    }
  }
  
  private void mainSort()
  {
    int[] arrayOfInt1 = new int['Ā'];
    int[] arrayOfInt2 = new int['Ā'];
    boolean[] arrayOfBoolean = new boolean['Ā'];
    for (int i = 0; i < 20; i++) {
      this.block[(this.last + i + 2)] = this.block[(i % (this.last + 1) + 1)];
    }
    for (i = 0; i <= this.last + 20; i++) {
      this.quadrant[i] = 0;
    }
    this.block[0] = this.block[(this.last + 1)];
    if (this.last < 4000)
    {
      for (i = 0; i <= this.last; i++) {
        this.zptr[i] = i;
      }
      this.firstAttempt = false;
      this.workDone = (this.workLimit = 0);
      simpleSort(0, this.last, 0);
    }
    else
    {
      int i2 = 0;
      for (i = 0; i <= 255; i++) {
        arrayOfBoolean[i] = false;
      }
      for (i = 0; i <= 65536; i++) {
        this.ftab[i] = 0;
      }
      int n = this.block[0];
      int i1;
      for (i = 0; i <= this.last; i++)
      {
        i1 = this.block[(i + 1)];
        this.ftab[((n << 8) + i1)] += 1;
        n = i1;
      }
      for (i = 1; i <= 65536; i++) {
        this.ftab[i] += this.ftab[(i - 1)];
      }
      n = this.block[1];
      for (i = 0; i < this.last; i++)
      {
        i1 = this.block[(i + 2)];
        j = (n << 8) + i1;
        n = i1;
        this.ftab[j] -= 1;
        this.zptr[this.ftab[j]] = i;
      }
      int j = (this.block[(this.last + 1)] << '\b') + this.block[1];
      this.ftab[j] -= 1;
      this.zptr[this.ftab[j]] = this.last;
      for (i = 0; i <= 255; i++) {
        arrayOfInt1[i] = i;
      }
      int i4 = 1;
      do
      {
        i4 = 3 * i4 + 1;
      } while (i4 <= 256);
      int i3;
      do
      {
        i4 /= 3;
        for (i = i4; i <= 255; i++)
        {
          i3 = arrayOfInt1[i];
          j = i;
          while (this.ftab[(arrayOfInt1[(j - i4)] + 1 << 8)] - this.ftab[(arrayOfInt1[(j - i4)] << 8)] > this.ftab[(i3 + 1 << 8)] - this.ftab[(i3 << 8)])
          {
            arrayOfInt1[j] = arrayOfInt1[(j - i4)];
            j -= i4;
            if (j <= i4 - 1) {
              break;
            }
          }
          arrayOfInt1[j] = i3;
        }
      } while (i4 != 1);
      for (i = 0; i <= 255; i++)
      {
        int k = arrayOfInt1[i];
        for (j = 0; j <= 255; j++)
        {
          int m = (k << 8) + j;
          if ((this.ftab[m] & 0x200000) != 2097152)
          {
            i3 = this.ftab[m] & 0xFFDFFFFF;
            i4 = (this.ftab[(m + 1)] & 0xFFDFFFFF) - 1;
            if (i4 > i3)
            {
              qSort3(i3, i4, 2);
              i2 += i4 - i3 + 1;
              if ((this.workDone > this.workLimit) && (this.firstAttempt)) {
                return;
              }
            }
            this.ftab[m] |= 0x200000;
          }
        }
        arrayOfBoolean[k] = true;
        if (i < 255)
        {
          i3 = this.ftab[(k << 8)] & 0xFFDFFFFF;
          i4 = (this.ftab[(k + 1 << 8)] & 0xFFDFFFFF) - i3;
          for (int i5 = 0; i4 >> i5 > 65534; i5++) {}
          for (j = 0; j < i4; j++)
          {
            int i6 = this.zptr[(i3 + j)];
            int i7 = j >> i5;
            this.quadrant[i6] = i7;
            if (i6 < 20) {
              this.quadrant[(i6 + this.last + 1)] = i7;
            }
          }
          if (i4 - 1 >> i5 > 65535) {
            panic();
          }
        }
        for (j = 0; j <= 255; j++) {
          arrayOfInt2[j] = (this.ftab[((j << 8) + k)] & 0xFFDFFFFF);
        }
        for (j = this.ftab[(k << 8)] & 0xFFDFFFFF; j < (this.ftab[(k + 1 << 8)] & 0xFFDFFFFF); j++)
        {
          n = this.block[this.zptr[j]];
          if (arrayOfBoolean[n] == 0)
          {
            this.zptr[arrayOfInt2[n]] = (this.zptr[j] == 0 ? this.last : this.zptr[j] - 1);
            arrayOfInt2[n] += 1;
          }
        }
        for (j = 0; j <= 255; j++) {
          this.ftab[((j << 8) + k)] |= 0x200000;
        }
      }
    }
  }
  
  private void randomiseBlock()
  {
    int j = 0;
    int k = 0;
    for (int i = 0; i < 256; i++) {
      this.inUse[i] = false;
    }
    for (i = 0; i <= this.last; i++)
    {
      if (j == 0)
      {
        j = (char)rNums[k];
        k++;
        if (k == 512) {
          k = 0;
        }
      }
      j--;
      int tmp69_68 = (i + 1);
      char[] tmp69_63 = this.block;
      tmp69_63[tmp69_68] = ((char)(tmp69_63[tmp69_68] ^ (j == 1 ? 1 : '\000')));
      int tmp91_90 = (i + 1);
      char[] tmp91_85 = this.block;
      tmp91_85[tmp91_90] = ((char)(tmp91_85[tmp91_90] & 0xFF));
      this.inUse[this.block[(i + 1)]] = true;
    }
  }
  
  private void doReversibleTransformation()
  {
    this.workLimit = (this.workFactor * this.last);
    this.workDone = 0;
    this.blockRandomised = false;
    this.firstAttempt = true;
    mainSort();
    if ((this.workDone > this.workLimit) && (this.firstAttempt))
    {
      randomiseBlock();
      this.workLimit = (this.workDone = 0);
      this.blockRandomised = true;
      this.firstAttempt = false;
      mainSort();
    }
    this.origPtr = -1;
    for (int i = 0; i <= this.last; i++) {
      if (this.zptr[i] == 0)
      {
        this.origPtr = i;
        break;
      }
    }
    if (this.origPtr == -1) {
      panic();
    }
  }
  
  private boolean fullGtU(int paramInt1, int paramInt2)
  {
    int j = this.block[(paramInt1 + 1)];
    int k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    j = this.block[(paramInt1 + 1)];
    k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    j = this.block[(paramInt1 + 1)];
    k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    j = this.block[(paramInt1 + 1)];
    k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    j = this.block[(paramInt1 + 1)];
    k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    j = this.block[(paramInt1 + 1)];
    k = this.block[(paramInt2 + 1)];
    if (j != k) {
      return j > k;
    }
    paramInt1++;
    paramInt2++;
    int i = this.last + 1;
    do
    {
      j = this.block[(paramInt1 + 1)];
      k = this.block[(paramInt2 + 1)];
      if (j != k) {
        return j > k;
      }
      int m = this.quadrant[paramInt1];
      int n = this.quadrant[paramInt2];
      if (m != n) {
        return m > n;
      }
      paramInt1++;
      paramInt2++;
      j = this.block[(paramInt1 + 1)];
      k = this.block[(paramInt2 + 1)];
      if (j != k) {
        return j > k;
      }
      m = this.quadrant[paramInt1];
      n = this.quadrant[paramInt2];
      if (m != n) {
        return m > n;
      }
      paramInt1++;
      paramInt2++;
      j = this.block[(paramInt1 + 1)];
      k = this.block[(paramInt2 + 1)];
      if (j != k) {
        return j > k;
      }
      m = this.quadrant[paramInt1];
      n = this.quadrant[paramInt2];
      if (m != n) {
        return m > n;
      }
      paramInt1++;
      paramInt2++;
      j = this.block[(paramInt1 + 1)];
      k = this.block[(paramInt2 + 1)];
      if (j != k) {
        return j > k;
      }
      m = this.quadrant[paramInt1];
      n = this.quadrant[paramInt2];
      if (m != n) {
        return m > n;
      }
      paramInt1++;
      paramInt2++;
      if (paramInt1 > this.last)
      {
        paramInt1 -= this.last;
        paramInt1--;
      }
      if (paramInt2 > this.last)
      {
        paramInt2 -= this.last;
        paramInt2--;
      }
      i -= 4;
      this.workDone += 1;
    } while (i >= 0);
    return false;
  }
  
  private void allocateCompressStructures()
  {
    int i = 100000 * this.blockSize100k;
    this.block = new char[i + 1 + 20];
    this.quadrant = new int[i + 20];
    this.zptr = new int[i];
    this.ftab = new int[65537];
    if ((this.block != null) && (this.quadrant != null) && (this.zptr != null) && (this.ftab == null)) {}
    this.szptr = new short[2 * i];
  }
  
  private void generateMTFValues()
  {
    char[] arrayOfChar = new char['Ā'];
    makeMaps();
    int i2 = this.nInUse + 1;
    for (int i = 0; i <= i2; i++) {
      this.mtfFreq[i] = 0;
    }
    int i1 = 0;
    int n = 0;
    for (i = 0; i < this.nInUse; i++) {
      arrayOfChar[i] = ((char)i);
    }
    for (i = 0; i <= this.last; i++)
    {
      int i3 = this.unseqToSeq[this.block[this.zptr[i]]];
      int j = 0;
      int k = arrayOfChar[j];
      while (i3 != k)
      {
        j++;
        int m = k;
        k = arrayOfChar[j];
        arrayOfChar[j] = m;
      }
      arrayOfChar[0] = k;
      if (j == 0)
      {
        n++;
      }
      else
      {
        if (n > 0)
        {
          n--;
          for (;;)
          {
            switch (n % 2)
            {
            case 0: 
              this.szptr[i1] = 0;
              i1++;
              this.mtfFreq[0] += 1;
              break;
            case 1: 
              this.szptr[i1] = 1;
              i1++;
              this.mtfFreq[1] += 1;
            }
            if (n < 2) {
              break;
            }
            n = (n - 2) / 2;
          }
          n = 0;
        }
        this.szptr[i1] = ((short)(j + 1));
        i1++;
        this.mtfFreq[(j + 1)] += 1;
      }
    }
    if (n > 0)
    {
      n--;
      for (;;)
      {
        switch (n % 2)
        {
        case 0: 
          this.szptr[i1] = 0;
          i1++;
          this.mtfFreq[0] += 1;
          break;
        case 1: 
          this.szptr[i1] = 1;
          i1++;
          this.mtfFreq[1] += 1;
        }
        if (n < 2) {
          break;
        }
        n = (n - 2) / 2;
      }
    }
    this.szptr[i1] = ((short)i2);
    i1++;
    this.mtfFreq[i2] += 1;
    this.nMTF = i1;
  }
  
  private static class StackElem
  {
    int ll;
    int hh;
    int dd;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\apache\bzip2\CBZip2OutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */