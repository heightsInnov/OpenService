package org.bouncycastle.apache.bzip2;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

public class CBZip2InputStream
  extends InputStream
  implements BZip2Constants
{
  private int last;
  private int origPtr;
  private int blockSize100k;
  private boolean blockRandomised;
  private int bsBuff;
  private int bsLive;
  private CRC mCrc = new CRC();
  private boolean[] inUse = new boolean['Ā'];
  private int nInUse;
  private char[] seqToUnseq = new char['Ā'];
  private char[] unseqToSeq = new char['Ā'];
  private char[] selector = new char['䙒'];
  private char[] selectorMtf = new char['䙒'];
  private int[] tt = null;
  private char[] ll8 = null;
  private int[] unzftab = new int['Ā'];
  private int[][] limit = new int[6]['Ă'];
  private int[][] base = new int[6]['Ă'];
  private int[][] perm = new int[6]['Ă'];
  private int[] minLens = new int[6];
  private InputStream bsStream;
  private boolean streamEnd = false;
  private int currentChar = -1;
  private static final int START_BLOCK_STATE = 1;
  private static final int RAND_PART_A_STATE = 2;
  private static final int RAND_PART_B_STATE = 3;
  private static final int RAND_PART_C_STATE = 4;
  private static final int NO_RAND_PART_A_STATE = 5;
  private static final int NO_RAND_PART_B_STATE = 6;
  private static final int NO_RAND_PART_C_STATE = 7;
  private int currentState = 1;
  private int storedBlockCRC;
  private int storedCombinedCRC;
  private int computedBlockCRC;
  private int computedCombinedCRC;
  int i2;
  int count;
  int chPrev;
  int ch2;
  int i;
  int tPos;
  int rNToGo = 0;
  int rTPos = 0;
  int j2;
  char z;
  
  private static void cadvise()
  {
    System.out.println("CRC Error");
  }
  
  private static void badBGLengths() {}
  
  private static void bitStreamEOF() {}
  
  private static void compressedStreamEOF() {}
  
  private void makeMaps()
  {
    this.nInUse = 0;
    for (int j = 0; j < 256; j++) {
      if (this.inUse[j] != 0)
      {
        this.seqToUnseq[this.nInUse] = ((char)j);
        this.unseqToSeq[j] = ((char)this.nInUse);
        this.nInUse += 1;
      }
    }
  }
  
  public CBZip2InputStream(InputStream paramInputStream)
    throws IOException
  {
    bsSetStream(paramInputStream);
    initialize();
    initBlock();
    setupBlock();
  }
  
  public int read()
  {
    if (this.streamEnd) {
      return -1;
    }
    int j = this.currentChar;
    switch (this.currentState)
    {
    case 1: 
      break;
    case 2: 
      break;
    case 3: 
      setupRandPartB();
      break;
    case 4: 
      setupRandPartC();
      break;
    case 5: 
      break;
    case 6: 
      setupNoRandPartB();
      break;
    case 7: 
      setupNoRandPartC();
      break;
    }
    return j;
  }
  
  private void initialize()
    throws IOException
  {
    int j = bsGetUChar();
    int k = bsGetUChar();
    if ((j != 66) && (k != 90)) {
      throw new IOException("Not a BZIP2 marked stream");
    }
    j = bsGetUChar();
    k = bsGetUChar();
    if ((j != 104) || (k < 49) || (k > 57))
    {
      bsFinishedWithStream();
      this.streamEnd = true;
      return;
    }
    setDecompressStructureSizes(k - 48);
    this.computedCombinedCRC = 0;
  }
  
  private void initBlock()
  {
    int j = bsGetUChar();
    int k = bsGetUChar();
    int m = bsGetUChar();
    int n = bsGetUChar();
    int i1 = bsGetUChar();
    int i3 = bsGetUChar();
    if ((j == 23) && (k == 114) && (m == 69) && (n == 56) && (i1 == 80) && (i3 == 144))
    {
      complete();
      return;
    }
    if ((j != 49) || (k != 65) || (m != 89) || (n != 38) || (i1 != 83) || (i3 != 89))
    {
      badBlockHeader();
      this.streamEnd = true;
      return;
    }
    this.storedBlockCRC = bsGetInt32();
    if (bsR(1) == 1) {
      this.blockRandomised = true;
    } else {
      this.blockRandomised = false;
    }
    getAndMoveToFrontDecode();
    this.mCrc.initialiseCRC();
    this.currentState = 1;
  }
  
  private void endBlock()
  {
    this.computedBlockCRC = this.mCrc.getFinalCRC();
    if (this.storedBlockCRC != this.computedBlockCRC) {
      crcError();
    }
    this.computedCombinedCRC = (this.computedCombinedCRC << 1 | this.computedCombinedCRC >>> 31);
    this.computedCombinedCRC ^= this.computedBlockCRC;
  }
  
  private void complete()
  {
    this.storedCombinedCRC = bsGetInt32();
    if (this.storedCombinedCRC != this.computedCombinedCRC) {
      crcError();
    }
    bsFinishedWithStream();
    this.streamEnd = true;
  }
  
  private static void blockOverrun() {}
  
  private static void badBlockHeader() {}
  
  private static void crcError() {}
  
  private void bsFinishedWithStream()
  {
    try
    {
      if ((this.bsStream != null) && (this.bsStream != System.in))
      {
        this.bsStream.close();
        this.bsStream = null;
      }
    }
    catch (IOException localIOException) {}
  }
  
  private void bsSetStream(InputStream paramInputStream)
  {
    this.bsStream = paramInputStream;
    this.bsLive = 0;
    this.bsBuff = 0;
  }
  
  private int bsR(int paramInt)
  {
    while (this.bsLive < paramInt)
    {
      int m = 0;
      try
      {
        m = (char)this.bsStream.read();
      }
      catch (IOException localIOException)
      {
        compressedStreamEOF();
      }
      if (m == -1) {
        compressedStreamEOF();
      }
      int k = m;
      this.bsBuff = (this.bsBuff << 8 | k & 0xFF);
      this.bsLive += 8;
    }
    int j = this.bsBuff >> this.bsLive - paramInt & (1 << paramInt) - 1;
    this.bsLive -= paramInt;
    return j;
  }
  
  private char bsGetUChar()
  {
    return (char)bsR(8);
  }
  
  private int bsGetint()
  {
    int j = 0;
    j = j << 8 | bsR(8);
    j = j << 8 | bsR(8);
    j = j << 8 | bsR(8);
    j = j << 8 | bsR(8);
    return j;
  }
  
  private int bsGetIntVS(int paramInt)
  {
    return bsR(paramInt);
  }
  
  private int bsGetInt32()
  {
    return bsGetint();
  }
  
  private void hbCreateDecodeTables(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3)
  {
    int j = 0;
    for (int k = paramInt1; k <= paramInt2; k++) {
      for (int m = 0; m < paramInt3; m++) {
        if (paramArrayOfChar[m] == k)
        {
          paramArrayOfInt3[j] = m;
          j++;
        }
      }
    }
    for (k = 0; k < 23; k++) {
      paramArrayOfInt2[k] = 0;
    }
    for (k = 0; k < paramInt3; k++) {
      paramArrayOfInt2[(paramArrayOfChar[k] + '\001')] += 1;
    }
    for (k = 1; k < 23; k++) {
      paramArrayOfInt2[k] += paramArrayOfInt2[(k - 1)];
    }
    for (k = 0; k < 23; k++) {
      paramArrayOfInt1[k] = 0;
    }
    int n = 0;
    for (k = paramInt1; k <= paramInt2; k++)
    {
      n += paramArrayOfInt2[(k + 1)] - paramArrayOfInt2[k];
      paramArrayOfInt1[k] = (n - 1);
      n <<= 1;
    }
    for (k = paramInt1 + 1; k <= paramInt2; k++) {
      paramArrayOfInt2[k] = ((paramArrayOfInt1[(k - 1)] + 1 << 1) - paramArrayOfInt2[k]);
    }
  }
  
  private void recvDecodingTables()
  {
    char[][] arrayOfChar = new char[6]['Ă'];
    boolean[] arrayOfBoolean = new boolean[16];
    for (int j = 0; j < 16; j++) {
      if (bsR(1) == 1) {
        arrayOfBoolean[j] = true;
      } else {
        arrayOfBoolean[j] = false;
      }
    }
    for (j = 0; j < 256; j++) {
      this.inUse[j] = false;
    }
    int k;
    for (j = 0; j < 16; j++) {
      if (arrayOfBoolean[j] != 0) {
        for (k = 0; k < 16; k++) {
          if (bsR(1) == 1) {
            this.inUse[(j * 16 + k)] = true;
          }
        }
      }
    }
    makeMaps();
    int i3 = this.nInUse + 2;
    int n = bsR(3);
    int i1 = bsR(15);
    for (j = 0; j < i1; j++)
    {
      for (k = 0; bsR(1) == 1; k++) {}
      this.selectorMtf[j] = ((char)k);
    }
    char[] arrayOfChar1 = new char[6];
    for (int i8 = 0; i8 < n; i8 = (char)(i8 + 1)) {
      arrayOfChar1[i8] = i8;
    }
    for (j = 0; j < i1; j++)
    {
      i8 = this.selectorMtf[j];
      int i7 = arrayOfChar1[i8];
      while (i8 > 0)
      {
        arrayOfChar1[i8] = arrayOfChar1[(i8 - 1)];
        i8 = (char)(i8 - 1);
      }
      arrayOfChar1[0] = i7;
      this.selector[j] = i7;
    }
    for (int m = 0; m < n; m++)
    {
      int i6 = bsR(5);
      for (j = 0; j < i3; j++)
      {
        while (bsR(1) == 1) {
          if (bsR(1) == 0) {
            i6++;
          } else {
            i6--;
          }
        }
        arrayOfChar[m][j] = ((char)i6);
      }
    }
    for (m = 0; m < n; m++)
    {
      int i4 = 32;
      int i5 = 0;
      for (j = 0; j < i3; j++)
      {
        if (arrayOfChar[m][j] > i5) {
          i5 = arrayOfChar[m][j];
        }
        if (arrayOfChar[m][j] < i4) {
          i4 = arrayOfChar[m][j];
        }
      }
      hbCreateDecodeTables(this.limit[m], this.base[m], this.perm[m], arrayOfChar[m], i4, i5, i3);
      this.minLens[m] = i4;
    }
  }
  
  private void getAndMoveToFrontDecode()
  {
    char[] arrayOfChar = new char['Ā'];
    int n = 100000 * this.blockSize100k;
    this.origPtr = bsGetIntVS(24);
    recvDecodingTables();
    int i1 = this.nInUse + 1;
    int i3 = -1;
    int i4 = 0;
    for (int j = 0; j <= 255; j++) {
      this.unzftab[j] = 0;
    }
    for (j = 0; j <= 255; j++) {
      arrayOfChar[j] = ((char)j);
    }
    this.last = -1;
    if (i4 == 0)
    {
      i3++;
      i4 = 50;
    }
    i4--;
    int i5 = this.selector[i3];
    int i6 = this.minLens[i5];
    int i10;
    int i9;
    int i8;
    for (int i7 = bsR(i6); i7 > this.limit[i5][i6]; i7 = i7 << 1 | i8)
    {
      i6++;
      while (this.bsLive < 1)
      {
        i10 = 0;
        try
        {
          i10 = (char)this.bsStream.read();
        }
        catch (IOException localIOException1)
        {
          compressedStreamEOF();
        }
        if (i10 == -1) {
          compressedStreamEOF();
        }
        i9 = i10;
        this.bsBuff = (this.bsBuff << 8 | i9 & 0xFF);
        this.bsLive += 8;
      }
      i8 = this.bsBuff >> this.bsLive - 1 & 0x1;
      this.bsLive -= 1;
    }
    int m = this.perm[i5][(i7 - this.base[i5][i6])];
    while (m != i1)
    {
      int i11;
      if ((m == 0) || (m == 1))
      {
        i6 = -1;
        i7 = 1;
        do
        {
          if (m == 0) {
            i6 += 1 * i7;
          } else if (m == 1) {
            i6 += 2 * i7;
          }
          i7 *= 2;
          if (i4 == 0)
          {
            i3++;
            i4 = 50;
          }
          i4--;
          i8 = this.selector[i3];
          i9 = this.minLens[i8];
          for (i10 = bsR(i9); i10 > this.limit[i8][i9]; i10 = i10 << 1 | i11)
          {
            i9++;
            while (this.bsLive < 1)
            {
              int i13 = 0;
              try
              {
                i13 = (char)this.bsStream.read();
              }
              catch (IOException localIOException3)
              {
                compressedStreamEOF();
              }
              if (i13 == -1) {
                compressedStreamEOF();
              }
              int i12 = i13;
              this.bsBuff = (this.bsBuff << 8 | i12 & 0xFF);
              this.bsLive += 8;
            }
            i11 = this.bsBuff >> this.bsLive - 1 & 0x1;
            this.bsLive -= 1;
          }
          m = this.perm[i8][(i10 - this.base[i8][i9])];
        } while ((m == 0) || (m == 1));
        i6++;
        i5 = this.seqToUnseq[arrayOfChar[0]];
        this.unzftab[i5] += i6;
        while (i6 > 0)
        {
          this.last += 1;
          this.ll8[this.last] = i5;
          i6--;
        }
        if (this.last >= n) {
          blockOverrun();
        }
      }
      else
      {
        this.last += 1;
        if (this.last >= n) {
          blockOverrun();
        }
        i5 = arrayOfChar[(m - 1)];
        this.unzftab[this.seqToUnseq[i5]] += 1;
        this.ll8[this.last] = this.seqToUnseq[i5];
        for (int k = m - 1; k > 3; k -= 4)
        {
          arrayOfChar[k] = arrayOfChar[(k - 1)];
          arrayOfChar[(k - 1)] = arrayOfChar[(k - 2)];
          arrayOfChar[(k - 2)] = arrayOfChar[(k - 3)];
          arrayOfChar[(k - 3)] = arrayOfChar[(k - 4)];
        }
        while (k > 0)
        {
          arrayOfChar[k] = arrayOfChar[(k - 1)];
          k--;
        }
        arrayOfChar[0] = i5;
        if (i4 == 0)
        {
          i3++;
          i4 = 50;
        }
        i4--;
        i6 = this.selector[i3];
        i7 = this.minLens[i6];
        for (i8 = bsR(i7); i8 > this.limit[i6][i7]; i8 = i8 << 1 | i9)
        {
          i7++;
          while (this.bsLive < 1)
          {
            i11 = 0;
            try
            {
              i11 = (char)this.bsStream.read();
            }
            catch (IOException localIOException2)
            {
              compressedStreamEOF();
            }
            i10 = i11;
            this.bsBuff = (this.bsBuff << 8 | i10 & 0xFF);
            this.bsLive += 8;
          }
          i9 = this.bsBuff >> this.bsLive - 1 & 0x1;
          this.bsLive -= 1;
        }
        m = this.perm[i6][(i8 - this.base[i6][i7])];
      }
    }
  }
  
  private void setupBlock()
  {
    int[] arrayOfInt = new int['ā'];
    arrayOfInt[0] = 0;
    for (this.i = 1; this.i <= 256; this.i += 1) {
      arrayOfInt[this.i] = this.unzftab[(this.i - 1)];
    }
    for (this.i = 1; this.i <= 256; this.i += 1) {
      arrayOfInt[this.i] += arrayOfInt[(this.i - 1)];
    }
    for (this.i = 0; this.i <= this.last; this.i += 1)
    {
      int j = this.ll8[this.i];
      this.tt[arrayOfInt[j]] = this.i;
      arrayOfInt[j] += 1;
    }
    arrayOfInt = null;
    this.tPos = this.tt[this.origPtr];
    this.count = 0;
    this.i2 = 0;
    this.ch2 = 256;
    if (this.blockRandomised)
    {
      this.rNToGo = 0;
      this.rTPos = 0;
      setupRandPartA();
    }
    else
    {
      setupNoRandPartA();
    }
  }
  
  private void setupRandPartA()
  {
    if (this.i2 <= this.last)
    {
      this.chPrev = this.ch2;
      this.ch2 = this.ll8[this.tPos];
      this.tPos = this.tt[this.tPos];
      if (this.rNToGo == 0)
      {
        this.rNToGo = rNums[this.rTPos];
        this.rTPos += 1;
        if (this.rTPos == 512) {
          this.rTPos = 0;
        }
      }
      this.rNToGo -= 1;
      this.ch2 ^= (this.rNToGo == 1 ? 1 : 0);
      this.i2 += 1;
      this.currentChar = this.ch2;
      this.currentState = 3;
      this.mCrc.updateCRC(this.ch2);
    }
    else
    {
      endBlock();
      initBlock();
      setupBlock();
    }
  }
  
  private void setupNoRandPartA()
  {
    if (this.i2 <= this.last)
    {
      this.chPrev = this.ch2;
      this.ch2 = this.ll8[this.tPos];
      this.tPos = this.tt[this.tPos];
      this.i2 += 1;
      this.currentChar = this.ch2;
      this.currentState = 6;
      this.mCrc.updateCRC(this.ch2);
    }
    else
    {
      endBlock();
      initBlock();
      setupBlock();
    }
  }
  
  private void setupRandPartB()
  {
    if (this.ch2 != this.chPrev)
    {
      this.currentState = 2;
      this.count = 1;
      setupRandPartA();
    }
    else
    {
      this.count += 1;
      if (this.count >= 4)
      {
        this.z = this.ll8[this.tPos];
        this.tPos = this.tt[this.tPos];
        if (this.rNToGo == 0)
        {
          this.rNToGo = rNums[this.rTPos];
          this.rTPos += 1;
          if (this.rTPos == 512) {
            this.rTPos = 0;
          }
        }
        this.rNToGo -= 1;
        this.z = ((char)(this.z ^ (this.rNToGo == 1 ? '\001' : '\000')));
        this.j2 = 0;
        this.currentState = 4;
        setupRandPartC();
      }
      else
      {
        this.currentState = 2;
        setupRandPartA();
      }
    }
  }
  
  private void setupRandPartC()
  {
    if (this.j2 < this.z)
    {
      this.currentChar = this.ch2;
      this.mCrc.updateCRC(this.ch2);
      this.j2 += 1;
    }
    else
    {
      this.currentState = 2;
      this.i2 += 1;
      this.count = 0;
      setupRandPartA();
    }
  }
  
  private void setupNoRandPartB()
  {
    if (this.ch2 != this.chPrev)
    {
      this.currentState = 5;
      this.count = 1;
      setupNoRandPartA();
    }
    else
    {
      this.count += 1;
      if (this.count >= 4)
      {
        this.z = this.ll8[this.tPos];
        this.tPos = this.tt[this.tPos];
        this.currentState = 7;
        this.j2 = 0;
        setupNoRandPartC();
      }
      else
      {
        this.currentState = 5;
        setupNoRandPartA();
      }
    }
  }
  
  private void setupNoRandPartC()
  {
    if (this.j2 < this.z)
    {
      this.currentChar = this.ch2;
      this.mCrc.updateCRC(this.ch2);
      this.j2 += 1;
    }
    else
    {
      this.currentState = 5;
      this.i2 += 1;
      this.count = 0;
      setupNoRandPartA();
    }
  }
  
  private void setDecompressStructureSizes(int paramInt)
  {
    if ((0 <= paramInt) && (paramInt <= 9) && (0 <= this.blockSize100k) && (this.blockSize100k > 9)) {}
    this.blockSize100k = paramInt;
    if (paramInt == 0) {
      return;
    }
    int j = 100000 * paramInt;
    this.ll8 = new char[j];
    this.tt = new int[j];
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\apache\bzip2\CBZip2InputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */