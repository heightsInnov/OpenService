package org.bouncycastle.bcpg;

import java.io.IOException;

public class LiteralDataPacket
  extends InputStreamPacket
{
  int format;
  char[] fileName;
  long modDate;
  
  LiteralDataPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
    this.format = paramBCPGInputStream.read();
    int i = paramBCPGInputStream.read();
    this.fileName = new char[i];
    for (int j = 0; j != this.fileName.length; j++) {
      this.fileName[j] = ((char)paramBCPGInputStream.read());
    }
    this.modDate = (paramBCPGInputStream.read() << 24 | paramBCPGInputStream.read() << 16 | paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read());
  }
  
  public int getFormat()
  {
    return this.format;
  }
  
  public long getModificationTime()
  {
    return this.modDate * 1000L;
  }
  
  public String getFileName()
  {
    return new String(this.fileName);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\LiteralDataPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */