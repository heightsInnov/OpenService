package org.bouncycastle.bcpg;

import java.io.IOException;

public class SecretSubkeyPacket
  extends SecretKeyPacket
{
  SecretSubkeyPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
  }
  
  public SecretSubkeyPacket(PublicKeyPacket paramPublicKeyPacket, int paramInt, S2K paramS2K, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    super(paramPublicKeyPacket, paramInt, paramS2K, paramArrayOfByte1, paramArrayOfByte2);
  }
  
  public SecretSubkeyPacket(PublicKeyPacket paramPublicKeyPacket, int paramInt1, int paramInt2, S2K paramS2K, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    super(paramPublicKeyPacket, paramInt1, paramInt2, paramS2K, paramArrayOfByte1, paramArrayOfByte2);
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(7, getEncodedContents(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SecretSubkeyPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */