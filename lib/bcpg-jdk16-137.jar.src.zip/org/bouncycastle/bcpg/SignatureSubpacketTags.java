package org.bouncycastle.bcpg;

public abstract interface SignatureSubpacketTags
{
  public static final int CREATION_TIME = 2;
  public static final int EXPIRE_TIME = 3;
  public static final int EXPORTABLE = 4;
  public static final int TRUST_SIG = 5;
  public static final int REG_EXP = 6;
  public static final int REVOCABLE = 7;
  public static final int KEY_EXPIRE_TIME = 9;
  public static final int PLACEHOLDER = 10;
  public static final int PREFERRED_SYM_ALGS = 11;
  public static final int REVOCATION_KEY = 12;
  public static final int ISSUER_KEY_ID = 16;
  public static final int NOTATION_DATA = 20;
  public static final int PREFERRED_HASH_ALGS = 21;
  public static final int PREFERRED_COMP_ALGS = 22;
  public static final int KEY_SERVER_PREFS = 23;
  public static final int PREFERRED_KEY_SERV = 24;
  public static final int PRIMARY_USER_ID = 25;
  public static final int POLICY_URL = 26;
  public static final int KEY_FLAGS = 27;
  public static final int SIGNER_USER_ID = 28;
  public static final int REVOCATION_REASON = 29;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SignatureSubpacketTags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */