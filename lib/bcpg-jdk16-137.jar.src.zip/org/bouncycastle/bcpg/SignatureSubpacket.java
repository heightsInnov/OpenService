package org.bouncycastle.bcpg;

import java.io.IOException;
import java.io.OutputStream;

public class SignatureSubpacket
{
  int type;
  boolean critical;
  protected byte[] data;
  
  protected SignatureSubpacket(int paramInt, boolean paramBoolean, byte[] paramArrayOfByte)
  {
    this.type = paramInt;
    this.critical = paramBoolean;
    this.data = paramArrayOfByte;
  }
  
  public int getType()
  {
    return this.type;
  }
  
  public boolean isCritical()
  {
    return this.critical;
  }
  
  public byte[] getData()
  {
    return this.data;
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    int i = this.data.length + 1;
    if (i < 192)
    {
      paramOutputStream.write((byte)i);
    }
    else if (i <= 8383)
    {
      i -= 192;
      paramOutputStream.write((byte)((i >> 8 & 0xFF) + 192));
      paramOutputStream.write((byte)i);
    }
    else
    {
      paramOutputStream.write(255);
      paramOutputStream.write((byte)(i >> 24));
      paramOutputStream.write((byte)(i >> 16));
      paramOutputStream.write((byte)(i >> 8));
      paramOutputStream.write((byte)i);
    }
    if (this.critical) {
      paramOutputStream.write(0x80 | this.type);
    } else {
      paramOutputStream.write(this.type);
    }
    paramOutputStream.write(this.data);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SignatureSubpacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */