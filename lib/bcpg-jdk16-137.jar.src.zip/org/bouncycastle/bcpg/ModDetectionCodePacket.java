package org.bouncycastle.bcpg;

import java.io.IOException;

public class ModDetectionCodePacket
  extends ContainedPacket
{
  private byte[] digest;
  
  ModDetectionCodePacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.digest = new byte[20];
    paramBCPGInputStream.readFully(this.digest);
  }
  
  public ModDetectionCodePacket(byte[] paramArrayOfByte)
    throws IOException
  {
    this.digest = new byte[paramArrayOfByte.length];
    System.arraycopy(paramArrayOfByte, 0, this.digest, 0, this.digest.length);
  }
  
  public byte[] getDigest()
  {
    byte[] arrayOfByte = new byte[this.digest.length];
    System.arraycopy(this.digest, 0, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(19, this.digest, false);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\ModDetectionCodePacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */