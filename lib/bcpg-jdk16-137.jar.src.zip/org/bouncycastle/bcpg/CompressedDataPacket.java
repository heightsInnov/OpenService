package org.bouncycastle.bcpg;

import java.io.IOException;

public class CompressedDataPacket
  extends InputStreamPacket
{
  int algorithm;
  
  CompressedDataPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
    this.algorithm = paramBCPGInputStream.read();
  }
  
  public int getAlgorithm()
  {
    return this.algorithm;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\CompressedDataPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */