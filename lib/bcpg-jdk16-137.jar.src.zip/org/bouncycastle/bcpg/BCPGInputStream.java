package org.bouncycastle.bcpg;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class BCPGInputStream
  extends InputStream
  implements PacketTags
{
  InputStream in;
  boolean next = false;
  int nextB;
  
  public BCPGInputStream(InputStream paramInputStream)
  {
    this.in = paramInputStream;
  }
  
  public int available()
    throws IOException
  {
    return this.in.available();
  }
  
  public int read()
    throws IOException
  {
    if (this.next)
    {
      this.next = false;
      return this.nextB;
    }
    return this.in.read();
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 == 0) {
      return 0;
    }
    if (!this.next) {
      return this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    }
    if (this.nextB < 0) {
      return -1;
    }
    paramArrayOfByte[paramInt1] = ((byte)this.nextB);
    this.next = false;
    return 1;
  }
  
  public void readFully(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    if (paramInt2 > 0)
    {
      i = read();
      if (i < 0) {
        throw new EOFException();
      }
      paramArrayOfByte[paramInt1] = ((byte)i);
      paramInt1++;
      paramInt2--;
    }
    while (paramInt2 > 0)
    {
      i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
      if (i < 0) {
        throw new EOFException();
      }
      paramInt1 += i;
      paramInt2 -= i;
    }
  }
  
  public void readFully(byte[] paramArrayOfByte)
    throws IOException
  {
    readFully(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public int nextPacketTag()
    throws IOException
  {
    if (!this.next) {
      try
      {
        this.nextB = this.in.read();
      }
      catch (EOFException localEOFException)
      {
        this.nextB = -1;
      }
    }
    this.next = true;
    if (this.nextB >= 0)
    {
      if ((this.nextB & 0x40) != 0) {
        return this.nextB & 0x3F;
      }
      return (this.nextB & 0x3F) >> 2;
    }
    return this.nextB;
  }
  
  public Packet readPacket()
    throws IOException
  {
    int i = read();
    if (i < 0) {
      return null;
    }
    if ((i & 0x80) == 0) {
      throw new IOException("invalid header encountered");
    }
    int j = (i & 0x40) != 0 ? 1 : 0;
    int k = 0;
    int m = 0;
    boolean bool = false;
    int n;
    if (j != 0)
    {
      k = i & 0x3F;
      n = read();
      if (n < 192)
      {
        m = n;
      }
      else if (n <= 223)
      {
        int i1 = this.in.read();
        m = (n - 192 << 8) + i1 + 192;
      }
      else if (n == 255)
      {
        m = this.in.read() << 24 | this.in.read() << 16 | this.in.read() << 8 | this.in.read();
      }
      else
      {
        bool = true;
        m = 1 << (n & 0x1F);
      }
    }
    else
    {
      n = i & 0x3;
      k = (i & 0x3F) >> 2;
      switch (n)
      {
      case 0: 
        m = read();
        break;
      case 1: 
        m = read() << 8 | read();
        break;
      case 2: 
        m = read() << 24 | read() << 16 | read() << 8 | read();
        break;
      case 3: 
        bool = true;
        break;
      default: 
        throw new IOException("unknown length type encountered");
      }
    }
    BCPGInputStream localBCPGInputStream;
    if ((m == 0) && (bool)) {
      localBCPGInputStream = this;
    } else {
      localBCPGInputStream = new BCPGInputStream(new PartialInputStream(this, bool, m));
    }
    switch (k)
    {
    case 0: 
      return new InputStreamPacket(localBCPGInputStream);
    case 1: 
      return new PublicKeyEncSessionPacket(localBCPGInputStream);
    case 2: 
      return new SignaturePacket(localBCPGInputStream);
    case 3: 
      return new SymmetricKeyEncSessionPacket(localBCPGInputStream);
    case 4: 
      return new OnePassSignaturePacket(localBCPGInputStream);
    case 5: 
      return new SecretKeyPacket(localBCPGInputStream);
    case 6: 
      return new PublicKeyPacket(localBCPGInputStream);
    case 7: 
      return new SecretSubkeyPacket(localBCPGInputStream);
    case 8: 
      return new CompressedDataPacket(localBCPGInputStream);
    case 9: 
      return new SymmetricEncDataPacket(localBCPGInputStream);
    case 10: 
      return new MarkerPacket(localBCPGInputStream);
    case 11: 
      return new LiteralDataPacket(localBCPGInputStream);
    case 12: 
      return new TrustPacket(localBCPGInputStream);
    case 13: 
      return new UserIDPacket(localBCPGInputStream);
    case 17: 
      return new UserAttributePacket(localBCPGInputStream);
    case 14: 
      return new PublicSubkeyPacket(localBCPGInputStream);
    case 18: 
      return new SymmetricEncIntegrityPacket(localBCPGInputStream);
    case 19: 
      return new ModDetectionCodePacket(localBCPGInputStream);
    case 60: 
    case 61: 
    case 62: 
    case 63: 
      return new ExperimentalPacket(k, localBCPGInputStream);
    }
    throw new IOException("unknown packet type encountered: " + k);
  }
  
  public void close()
    throws IOException
  {
    this.in.close();
  }
  
  private static class PartialInputStream
    extends InputStream
  {
    private BCPGInputStream in;
    private boolean partial;
    private int dataLength;
    
    PartialInputStream(BCPGInputStream paramBCPGInputStream, boolean paramBoolean, int paramInt)
    {
      this.in = paramBCPGInputStream;
      this.partial = paramBoolean;
      this.dataLength = paramInt;
    }
    
    public int available()
      throws IOException
    {
      int i = this.in.available();
      if (i <= this.dataLength) {
        return i;
      }
      if ((this.partial) && (this.dataLength == 0)) {
        return 1;
      }
      return this.dataLength;
    }
    
    private int loadDataLength()
      throws IOException
    {
      int i = this.in.read();
      if (i < 0) {
        return -1;
      }
      this.partial = false;
      if (i < 192)
      {
        this.dataLength = i;
      }
      else if (i <= 223)
      {
        this.dataLength = ((i - 192 << 8) + this.in.read() + 192);
      }
      else if (i == 255)
      {
        this.dataLength = (this.in.read() << 24 | this.in.read() << 16 | this.in.read() << 8 | this.in.read());
      }
      else
      {
        this.partial = true;
        this.dataLength = (1 << (i & 0x1F));
      }
      return this.dataLength;
    }
    
    public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
      throws IOException
    {
      if (this.dataLength > 0)
      {
        int i = this.dataLength > paramInt2 ? paramInt2 : this.dataLength;
        i = this.in.read(paramArrayOfByte, paramInt1, i);
        this.dataLength -= i;
        return i;
      }
      if (this.partial)
      {
        if (loadDataLength() < 0) {
          return -1;
        }
        return read(paramArrayOfByte, paramInt1, paramInt2);
      }
      return -1;
    }
    
    public int read()
      throws IOException
    {
      if (this.dataLength > 0)
      {
        this.dataLength -= 1;
        return this.in.read();
      }
      if (this.partial)
      {
        if (loadDataLength() < 0) {
          return -1;
        }
        return read();
      }
      return -1;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\BCPGInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */