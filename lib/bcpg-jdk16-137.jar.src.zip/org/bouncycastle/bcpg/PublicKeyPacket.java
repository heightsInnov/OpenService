package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;

public class PublicKeyPacket
  extends ContainedPacket
  implements PublicKeyAlgorithmTags
{
  private int version;
  private long time;
  private int validDays;
  private int algorithm;
  private BCPGKey key;
  
  PublicKeyPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.version = paramBCPGInputStream.read();
    this.time = (paramBCPGInputStream.read() << 24 | paramBCPGInputStream.read() << 16 | paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read());
    if (this.version <= 3) {
      this.validDays = (paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read());
    }
    this.algorithm = ((byte)paramBCPGInputStream.read());
    switch (this.algorithm)
    {
    case 1: 
    case 2: 
    case 3: 
      this.key = new RSAPublicBCPGKey(paramBCPGInputStream);
      break;
    case 17: 
      this.key = new DSAPublicBCPGKey(paramBCPGInputStream);
      break;
    case 16: 
    case 20: 
      this.key = new ElGamalPublicBCPGKey(paramBCPGInputStream);
      break;
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
    case 15: 
    case 18: 
    case 19: 
    default: 
      throw new IOException("unknown PGP public key algorithm encountered");
    }
  }
  
  public PublicKeyPacket(int paramInt, Date paramDate, BCPGKey paramBCPGKey)
  {
    this.version = 4;
    this.time = (paramDate.getTime() / 1000L);
    this.algorithm = paramInt;
    this.key = paramBCPGKey;
  }
  
  public int getVersion()
  {
    return this.version;
  }
  
  public int getAlgorithm()
  {
    return this.algorithm;
  }
  
  public int getValidDays()
  {
    return this.validDays;
  }
  
  public Date getTime()
  {
    return new Date(this.time * 1000L);
  }
  
  public BCPGKey getKey()
  {
    return this.key;
  }
  
  public byte[] getEncodedContents()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.write(this.version);
    localBCPGOutputStream.write((byte)(int)(this.time >> 24));
    localBCPGOutputStream.write((byte)(int)(this.time >> 16));
    localBCPGOutputStream.write((byte)(int)(this.time >> 8));
    localBCPGOutputStream.write((byte)(int)this.time);
    if (this.version <= 3)
    {
      localBCPGOutputStream.write((byte)(this.validDays >> 8));
      localBCPGOutputStream.write((byte)this.validDays);
    }
    localBCPGOutputStream.write(this.algorithm);
    localBCPGOutputStream.writeObject((BCPGObject)this.key);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(6, getEncodedContents(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\PublicKeyPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */