package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class SymmetricKeyEncSessionPacket
  extends ContainedPacket
{
  private int version;
  private int encAlgorithm;
  private S2K s2k;
  private byte[] secKeyData;
  
  public SymmetricKeyEncSessionPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.version = paramBCPGInputStream.read();
    this.encAlgorithm = paramBCPGInputStream.read();
    this.s2k = new S2K(paramBCPGInputStream);
    if (paramBCPGInputStream.available() != 0)
    {
      this.secKeyData = new byte[paramBCPGInputStream.available()];
      paramBCPGInputStream.readFully(this.secKeyData, 0, this.secKeyData.length);
    }
  }
  
  public SymmetricKeyEncSessionPacket(int paramInt, S2K paramS2K, byte[] paramArrayOfByte)
  {
    this.version = 4;
    this.encAlgorithm = paramInt;
    this.s2k = paramS2K;
    this.secKeyData = paramArrayOfByte;
  }
  
  public int getEncAlgorithm()
  {
    return this.encAlgorithm;
  }
  
  public S2K getS2K()
  {
    return this.s2k;
  }
  
  public byte[] getSecKeyData()
  {
    return this.secKeyData;
  }
  
  public int getVersion()
  {
    return this.version;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.write(this.version);
    localBCPGOutputStream.write(this.encAlgorithm);
    localBCPGOutputStream.writeObject(this.s2k);
    if (this.secKeyData != null) {
      localBCPGOutputStream.write(this.secKeyData);
    }
    paramBCPGOutputStream.writePacket(3, localByteArrayOutputStream.toByteArray(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SymmetricKeyEncSessionPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */