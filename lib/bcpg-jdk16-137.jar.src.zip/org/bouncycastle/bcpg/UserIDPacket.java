package org.bouncycastle.bcpg;

import java.io.IOException;
import org.bouncycastle.util.Strings;

public class UserIDPacket
  extends ContainedPacket
{
  private byte[] idData;
  
  public UserIDPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.idData = new byte[paramBCPGInputStream.available()];
    paramBCPGInputStream.readFully(this.idData);
  }
  
  public UserIDPacket(String paramString)
  {
    this.idData = Strings.toUTF8ByteArray(paramString);
  }
  
  public String getID()
  {
    return Strings.fromUTF8ByteArray(this.idData);
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(13, this.idData, true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\UserIDPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */