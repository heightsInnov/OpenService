package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class TrustPacket
  extends ContainedPacket
{
  byte[] levelAndTrustAmount;
  
  public TrustPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = paramBCPGInputStream.read()) >= 0) {
      localByteArrayOutputStream.write(i);
    }
    this.levelAndTrustAmount = localByteArrayOutputStream.toByteArray();
  }
  
  public TrustPacket(int paramInt)
  {
    this.levelAndTrustAmount = new byte[1];
    this.levelAndTrustAmount[0] = ((byte)paramInt);
  }
  
  public byte[] getLevelAndTrustAmount()
  {
    return this.levelAndTrustAmount;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(12, this.levelAndTrustAmount, true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\TrustPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */