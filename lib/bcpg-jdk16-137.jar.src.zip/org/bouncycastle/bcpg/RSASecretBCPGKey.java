package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class RSASecretBCPGKey
  extends BCPGObject
  implements BCPGKey
{
  MPInteger d;
  MPInteger p;
  MPInteger q;
  MPInteger u;
  BigInteger expP;
  BigInteger expQ;
  BigInteger crt;
  
  public RSASecretBCPGKey(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.d = new MPInteger(paramBCPGInputStream);
    this.p = new MPInteger(paramBCPGInputStream);
    this.q = new MPInteger(paramBCPGInputStream);
    this.u = new MPInteger(paramBCPGInputStream);
    this.expP = this.d.getValue().remainder(this.p.getValue().subtract(BigInteger.valueOf(1L)));
    this.expQ = this.d.getValue().remainder(this.q.getValue().subtract(BigInteger.valueOf(1L)));
    this.crt = this.q.getValue().modInverse(this.p.getValue());
  }
  
  public RSASecretBCPGKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    int i = paramBigInteger2.compareTo(paramBigInteger3);
    if (i >= 0)
    {
      if (i == 0) {
        throw new IllegalArgumentException("p and q cannot be equal");
      }
      BigInteger localBigInteger = paramBigInteger2;
      paramBigInteger2 = paramBigInteger3;
      paramBigInteger3 = localBigInteger;
    }
    this.d = new MPInteger(paramBigInteger1);
    this.p = new MPInteger(paramBigInteger2);
    this.q = new MPInteger(paramBigInteger3);
    this.u = new MPInteger(paramBigInteger2.modInverse(paramBigInteger3));
    this.expP = paramBigInteger1.remainder(paramBigInteger2.subtract(BigInteger.valueOf(1L)));
    this.expQ = paramBigInteger1.remainder(paramBigInteger3.subtract(BigInteger.valueOf(1L)));
    this.crt = paramBigInteger3.modInverse(paramBigInteger2);
  }
  
  public BigInteger getModulus()
  {
    return this.p.getValue().multiply(this.q.getValue());
  }
  
  public BigInteger getPrivateExponent()
  {
    return this.d.getValue();
  }
  
  public BigInteger getPrimeP()
  {
    return this.p.getValue();
  }
  
  public BigInteger getPrimeQ()
  {
    return this.q.getValue();
  }
  
  public BigInteger getPrimeExponentP()
  {
    return this.expP;
  }
  
  public BigInteger getPrimeExponentQ()
  {
    return this.expQ;
  }
  
  public BigInteger getCrtCoefficient()
  {
    return this.crt;
  }
  
  public String getFormat()
  {
    return "PGP";
  }
  
  public byte[] getEncoded()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      localBCPGOutputStream.writeObject(this);
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writeObject(this.d);
    paramBCPGOutputStream.writeObject(this.p);
    paramBCPGOutputStream.writeObject(this.q);
    paramBCPGOutputStream.writeObject(this.u);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\RSASecretBCPGKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */