package org.bouncycastle.bcpg;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

public class ArmoredInputStream
  extends InputStream
{
  private static final byte[] decodingTable = new byte[''];
  InputStream in;
  boolean start = true;
  int[] outBuf = new int[3];
  int bufPtr = 3;
  CRC24 crc = new CRC24();
  boolean crcFound = false;
  boolean hasHeaders = true;
  String header = null;
  boolean newLineFound = false;
  boolean clearText = false;
  boolean restart = false;
  Vector headerList = new Vector();
  int lastC = 0;
  
  private int decode(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
    throws EOFException
  {
    if (paramInt4 < 0) {
      throw new EOFException("unexpected end of file in armored stream.");
    }
    if (paramInt3 == 61)
    {
      i = decodingTable[paramInt1] & 0xFF;
      j = decodingTable[paramInt2] & 0xFF;
      paramArrayOfInt[2] = ((i << 2 | j >> 4) & 0xFF);
      return 2;
    }
    if (paramInt4 == 61)
    {
      i = decodingTable[paramInt1];
      j = decodingTable[paramInt2];
      k = decodingTable[paramInt3];
      paramArrayOfInt[1] = ((i << 2 | j >> 4) & 0xFF);
      paramArrayOfInt[2] = ((j << 4 | k >> 2) & 0xFF);
      return 1;
    }
    int i = decodingTable[paramInt1];
    int j = decodingTable[paramInt2];
    int k = decodingTable[paramInt3];
    int m = decodingTable[paramInt4];
    paramArrayOfInt[0] = ((i << 2 | j >> 4) & 0xFF);
    paramArrayOfInt[1] = ((j << 4 | k >> 2) & 0xFF);
    paramArrayOfInt[2] = ((k << 6 | m) & 0xFF);
    return 0;
  }
  
  public ArmoredInputStream(InputStream paramInputStream)
    throws IOException
  {
    this(paramInputStream, true);
  }
  
  public ArmoredInputStream(InputStream paramInputStream, boolean paramBoolean)
    throws IOException
  {
    this.in = paramInputStream;
    this.hasHeaders = paramBoolean;
    if (paramBoolean) {
      parseHeaders();
    }
    this.start = false;
  }
  
  public int available()
    throws IOException
  {
    return this.in.available();
  }
  
  private boolean parseHeaders()
    throws IOException
  {
    this.header = null;
    int j = 0;
    boolean bool = false;
    this.headerList = new Vector();
    int i;
    if (this.restart) {
      bool = true;
    } else {
      while ((i = this.in.read()) >= 0)
      {
        if ((i == 45) && ((j == 0) || (j == 10) || (j == 13)))
        {
          bool = true;
          break;
        }
        j = i;
      }
    }
    if (bool)
    {
      StringBuffer localStringBuffer = new StringBuffer("-");
      int k = 0;
      int m = 0;
      if (this.restart) {
        localStringBuffer.append('-');
      }
      while ((i = this.in.read()) >= 0)
      {
        if ((j == 13) && (i == 10)) {
          m = 1;
        }
        if (((k != 0) && (j != 13) && (i == 10)) || ((k != 0) && (i == 13))) {
          break;
        }
        if ((i == 13) || ((j != 13) && (i == 10)))
        {
          this.headerList.addElement(localStringBuffer.toString());
          localStringBuffer.setLength(0);
        }
        if ((i != 10) && (i != 13))
        {
          localStringBuffer.append((char)i);
          k = 0;
        }
        else if ((i == 13) || ((j != 13) && (i == 10)))
        {
          k = 1;
        }
        j = i;
      }
      if (m != 0) {
        this.in.read();
      }
    }
    if (this.headerList.size() > 0) {
      this.header = ((String)this.headerList.elementAt(0));
    }
    this.clearText = "-----BEGIN PGP SIGNED MESSAGE-----".equals(this.header);
    this.newLineFound = true;
    return bool;
  }
  
  public boolean isClearText()
  {
    return this.clearText;
  }
  
  public String getArmorHeaderLine()
  {
    return this.header;
  }
  
  public String[] getArmorHeaders()
  {
    if (this.headerList.size() <= 1) {
      return null;
    }
    String[] arrayOfString = new String[this.headerList.size() - 1];
    for (int i = 0; i != arrayOfString.length; i++) {
      arrayOfString[i] = ((String)this.headerList.elementAt(i + 1));
    }
    return arrayOfString;
  }
  
  private int readIgnoreSpace()
    throws IOException
  {
    for (int i = this.in.read(); (i == 32) || (i == 9); i = this.in.read()) {}
    return i;
  }
  
  public int read()
    throws IOException
  {
    if (this.start)
    {
      if (this.hasHeaders) {
        parseHeaders();
      }
      this.crc.reset();
      this.start = false;
    }
    if (this.clearText)
    {
      i = this.in.read();
      if ((i == 13) || ((i == 10) && (this.lastC != 13)))
      {
        this.newLineFound = true;
      }
      else if ((this.newLineFound) && (i == 45))
      {
        i = this.in.read();
        if (i == 45)
        {
          this.clearText = false;
          this.start = true;
          this.restart = true;
        }
        else
        {
          i = this.in.read();
        }
        this.newLineFound = false;
      }
      else if ((i != 10) && (this.lastC != 13))
      {
        this.newLineFound = false;
      }
      this.lastC = i;
      return i;
    }
    if ((this.bufPtr > 2) || (this.crcFound))
    {
      i = readIgnoreSpace();
      if ((i == 13) || (i == 10))
      {
        for (i = readIgnoreSpace(); (i == 10) || (i == 13); i = readIgnoreSpace()) {}
        if (i < 0) {
          return -1;
        }
        if (i == 61)
        {
          this.bufPtr = decode(readIgnoreSpace(), readIgnoreSpace(), readIgnoreSpace(), readIgnoreSpace(), this.outBuf);
          if (this.bufPtr == 0)
          {
            int j = (this.outBuf[0] & 0xFF) << 16 | (this.outBuf[1] & 0xFF) << 8 | this.outBuf[2] & 0xFF;
            this.crcFound = true;
            if (j != this.crc.getValue()) {
              throw new IOException("crc check failed in armored message.");
            }
            return read();
          }
          throw new IOException("no crc found in armored message.");
        }
        if (i == 45)
        {
          while (((i = this.in.read()) >= 0) && (i != 10)) {
            if (i == 13) {
              break;
            }
          }
          if (!this.crcFound) {
            throw new IOException("crc check not found.");
          }
          this.crcFound = false;
          this.start = true;
          this.bufPtr = 3;
          return -1;
        }
        this.bufPtr = decode(i, readIgnoreSpace(), readIgnoreSpace(), readIgnoreSpace(), this.outBuf);
      }
      else if (i >= 0)
      {
        this.bufPtr = decode(i, readIgnoreSpace(), readIgnoreSpace(), readIgnoreSpace(), this.outBuf);
      }
      else
      {
        return -1;
      }
    }
    int i = this.outBuf[(this.bufPtr++)];
    this.crc.update(i);
    return i;
  }
  
  public void close()
    throws IOException
  {
    this.in.close();
  }
  
  static
  {
    for (int i = 65; i <= 90; i++) {
      decodingTable[i] = ((byte)(i - 65));
    }
    for (i = 97; i <= 122; i++) {
      decodingTable[i] = ((byte)(i - 97 + 26));
    }
    for (i = 48; i <= 57; i++) {
      decodingTable[i] = ((byte)(i - 48 + 52));
    }
    decodingTable[43] = 62;
    decodingTable[47] = 63;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\ArmoredInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */