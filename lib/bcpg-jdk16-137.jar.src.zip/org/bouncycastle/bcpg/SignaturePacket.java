package org.bouncycastle.bcpg;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;
import org.bouncycastle.bcpg.sig.IssuerKeyID;
import org.bouncycastle.bcpg.sig.SignatureCreationTime;
import org.bouncycastle.util.Arrays;

public class SignaturePacket
  extends ContainedPacket
  implements PublicKeyAlgorithmTags
{
  private int version;
  private int signatureType;
  private long creationTime;
  private long keyID;
  private int keyAlgorithm;
  private int hashAlgorithm;
  private MPInteger[] signature;
  private byte[] fingerPrint;
  private SignatureSubpacket[] hashedData;
  private SignatureSubpacket[] unhashedData;
  private byte[] signatureEncoding;
  
  SignaturePacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.version = paramBCPGInputStream.read();
    int i;
    Object localObject1;
    Object localObject3;
    Object localObject4;
    Object localObject2;
    Object localObject5;
    int k;
    if ((this.version == 3) || (this.version == 2))
    {
      i = paramBCPGInputStream.read();
      this.signatureType = paramBCPGInputStream.read();
      this.creationTime = ((paramBCPGInputStream.read() << 24 | paramBCPGInputStream.read() << 16 | paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read()) * 1000L);
      this.keyID |= paramBCPGInputStream.read() << 56;
      this.keyID |= paramBCPGInputStream.read() << 48;
      this.keyID |= paramBCPGInputStream.read() << 40;
      this.keyID |= paramBCPGInputStream.read() << 32;
      this.keyID |= paramBCPGInputStream.read() << 24;
      this.keyID |= paramBCPGInputStream.read() << 16;
      this.keyID |= paramBCPGInputStream.read() << 8;
      this.keyID |= paramBCPGInputStream.read();
      this.keyAlgorithm = paramBCPGInputStream.read();
      this.hashAlgorithm = paramBCPGInputStream.read();
    }
    else if (this.version == 4)
    {
      this.signatureType = paramBCPGInputStream.read();
      this.keyAlgorithm = paramBCPGInputStream.read();
      this.hashAlgorithm = paramBCPGInputStream.read();
      i = paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read();
      localObject1 = new byte[i];
      paramBCPGInputStream.readFully((byte[])localObject1);
      localObject3 = new SignatureSubpacketInputStream(new ByteArrayInputStream((byte[])localObject1));
      localObject4 = new Vector();
      while ((localObject2 = ((SignatureSubpacketInputStream)localObject3).readPacket()) != null) {
        ((Vector)localObject4).addElement(localObject2);
      }
      this.hashedData = new SignatureSubpacket[((Vector)localObject4).size()];
      for (int j = 0; j != this.hashedData.length; j++)
      {
        localObject5 = (SignatureSubpacket)((Vector)localObject4).elementAt(j);
        if ((localObject5 instanceof IssuerKeyID)) {
          this.keyID = ((IssuerKeyID)localObject5).getKeyID();
        } else if ((localObject5 instanceof SignatureCreationTime)) {
          this.creationTime = ((SignatureCreationTime)localObject5).getTime().getTime();
        }
        this.hashedData[j] = localObject5;
      }
      j = paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read();
      localObject5 = new byte[j];
      paramBCPGInputStream.readFully((byte[])localObject5);
      localObject3 = new SignatureSubpacketInputStream(new ByteArrayInputStream((byte[])localObject5));
      ((Vector)localObject4).removeAllElements();
      while ((localObject2 = ((SignatureSubpacketInputStream)localObject3).readPacket()) != null) {
        ((Vector)localObject4).addElement(localObject2);
      }
      this.unhashedData = new SignatureSubpacket[((Vector)localObject4).size()];
      for (k = 0; k != this.unhashedData.length; k++)
      {
        SignatureSubpacket localSignatureSubpacket = (SignatureSubpacket)((Vector)localObject4).elementAt(k);
        if ((localSignatureSubpacket instanceof IssuerKeyID)) {
          this.keyID = ((IssuerKeyID)localSignatureSubpacket).getKeyID();
        } else if ((localSignatureSubpacket instanceof SignatureCreationTime)) {
          this.creationTime = ((SignatureCreationTime)localSignatureSubpacket).getTime().getTime();
        }
        this.unhashedData[k] = localSignatureSubpacket;
      }
    }
    else
    {
      throw new RuntimeException("unsupported version: " + this.version);
    }
    this.fingerPrint = new byte[2];
    paramBCPGInputStream.readFully(this.fingerPrint);
    switch (this.keyAlgorithm)
    {
    case 1: 
    case 3: 
      MPInteger localMPInteger1 = new MPInteger(paramBCPGInputStream);
      this.signature = new MPInteger[1];
      this.signature[0] = localMPInteger1;
      break;
    case 17: 
      localObject1 = new MPInteger(paramBCPGInputStream);
      localObject2 = new MPInteger(paramBCPGInputStream);
      this.signature = new MPInteger[2];
      this.signature[0] = localObject1;
      this.signature[1] = localObject2;
      break;
    case 16: 
    case 20: 
      localObject3 = new MPInteger(paramBCPGInputStream);
      localObject4 = new MPInteger(paramBCPGInputStream);
      MPInteger localMPInteger2 = new MPInteger(paramBCPGInputStream);
      this.signature = new MPInteger[3];
      this.signature[0] = localObject3;
      this.signature[1] = localObject4;
      this.signature[2] = localMPInteger2;
      break;
    default: 
      if ((this.keyAlgorithm >= 100) && (this.keyAlgorithm <= 110))
      {
        this.signature = null;
        localObject5 = new ByteArrayOutputStream();
        while ((k = paramBCPGInputStream.read()) >= 0) {
          ((ByteArrayOutputStream)localObject5).write(k);
        }
        this.signatureEncoding = ((ByteArrayOutputStream)localObject5).toByteArray();
      }
      else
      {
        throw new IOException("unknown signature key algorithm: " + this.keyAlgorithm);
      }
      break;
    }
  }
  
  public SignaturePacket(int paramInt1, long paramLong, int paramInt2, int paramInt3, SignatureSubpacket[] paramArrayOfSignatureSubpacket1, SignatureSubpacket[] paramArrayOfSignatureSubpacket2, byte[] paramArrayOfByte, MPInteger[] paramArrayOfMPInteger)
  {
    this(4, paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfSignatureSubpacket1, paramArrayOfSignatureSubpacket2, paramArrayOfByte, paramArrayOfMPInteger);
  }
  
  public SignaturePacket(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2, byte[] paramArrayOfByte, MPInteger[] paramArrayOfMPInteger)
  {
    this(paramInt1, paramInt2, paramLong1, paramInt3, paramInt4, null, null, paramArrayOfByte, paramArrayOfMPInteger);
    this.creationTime = paramLong2;
  }
  
  public SignaturePacket(int paramInt1, int paramInt2, long paramLong, int paramInt3, int paramInt4, SignatureSubpacket[] paramArrayOfSignatureSubpacket1, SignatureSubpacket[] paramArrayOfSignatureSubpacket2, byte[] paramArrayOfByte, MPInteger[] paramArrayOfMPInteger)
  {
    this.version = paramInt1;
    this.signatureType = paramInt2;
    this.keyID = paramLong;
    this.keyAlgorithm = paramInt3;
    this.hashAlgorithm = paramInt4;
    this.hashedData = paramArrayOfSignatureSubpacket1;
    this.unhashedData = paramArrayOfSignatureSubpacket2;
    this.fingerPrint = paramArrayOfByte;
    this.signature = paramArrayOfMPInteger;
  }
  
  public int getVersion()
  {
    return this.version;
  }
  
  public int getSignatureType()
  {
    return this.signatureType;
  }
  
  public long getKeyID()
  {
    return this.keyID;
  }
  
  public byte[] getSignatureTrailer()
  {
    byte[] arrayOfByte1 = null;
    if ((this.version == 3) || (this.version == 2))
    {
      arrayOfByte1 = new byte[5];
      long l = this.creationTime / 1000L;
      arrayOfByte1[0] = ((byte)this.signatureType);
      arrayOfByte1[1] = ((byte)(int)(l >> 24));
      arrayOfByte1[2] = ((byte)(int)(l >> 16));
      arrayOfByte1[3] = ((byte)(int)(l >> 8));
      arrayOfByte1[4] = ((byte)(int)l);
    }
    else
    {
      ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
      try
      {
        localByteArrayOutputStream1.write((byte)getVersion());
        localByteArrayOutputStream1.write((byte)getSignatureType());
        localByteArrayOutputStream1.write((byte)getKeyAlgorithm());
        localByteArrayOutputStream1.write((byte)getHashAlgorithm());
        ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
        SignatureSubpacket[] arrayOfSignatureSubpacket = getHashedSubPackets();
        for (int i = 0; i != arrayOfSignatureSubpacket.length; i++) {
          arrayOfSignatureSubpacket[i].encode(localByteArrayOutputStream2);
        }
        byte[] arrayOfByte2 = localByteArrayOutputStream2.toByteArray();
        localByteArrayOutputStream1.write((byte)(arrayOfByte2.length >> 8));
        localByteArrayOutputStream1.write((byte)arrayOfByte2.length);
        localByteArrayOutputStream1.write(arrayOfByte2);
        byte[] arrayOfByte3 = localByteArrayOutputStream1.toByteArray();
        localByteArrayOutputStream1.write((byte)getVersion());
        localByteArrayOutputStream1.write(-1);
        localByteArrayOutputStream1.write((byte)(arrayOfByte3.length >> 24));
        localByteArrayOutputStream1.write((byte)(arrayOfByte3.length >> 16));
        localByteArrayOutputStream1.write((byte)(arrayOfByte3.length >> 8));
        localByteArrayOutputStream1.write((byte)arrayOfByte3.length);
      }
      catch (IOException localIOException)
      {
        throw new RuntimeException("exception generating trailer: " + localIOException);
      }
      arrayOfByte1 = localByteArrayOutputStream1.toByteArray();
    }
    return arrayOfByte1;
  }
  
  public int getKeyAlgorithm()
  {
    return this.keyAlgorithm;
  }
  
  public int getHashAlgorithm()
  {
    return this.hashAlgorithm;
  }
  
  public MPInteger[] getSignature()
  {
    return this.signature;
  }
  
  public byte[] getSignatureBytes()
  {
    if (this.signatureEncoding == null)
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      for (int i = 0; i != this.signature.length; i++) {
        try
        {
          localBCPGOutputStream.writeObject(this.signature[i]);
        }
        catch (IOException localIOException)
        {
          throw new RuntimeException("internal error: " + localIOException);
        }
      }
      return localByteArrayOutputStream.toByteArray();
    }
    return Arrays.clone(this.signatureEncoding);
  }
  
  public SignatureSubpacket[] getHashedSubPackets()
  {
    return this.hashedData;
  }
  
  public SignatureSubpacket[] getUnhashedSubPackets()
  {
    return this.unhashedData;
  }
  
  public long getCreationTime()
  {
    return this.creationTime;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream1 = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream1);
    localBCPGOutputStream.write(this.version);
    if ((this.version == 3) || (this.version == 2))
    {
      localBCPGOutputStream.write(5);
      long l = this.creationTime / 1000L;
      localBCPGOutputStream.write(this.signatureType);
      localBCPGOutputStream.write((byte)(int)(l >> 24));
      localBCPGOutputStream.write((byte)(int)(l >> 16));
      localBCPGOutputStream.write((byte)(int)(l >> 8));
      localBCPGOutputStream.write((byte)(int)l);
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 56));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 48));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 40));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 32));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 24));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 16));
      localBCPGOutputStream.write((byte)(int)(this.keyID >> 8));
      localBCPGOutputStream.write((byte)(int)this.keyID);
      localBCPGOutputStream.write(this.keyAlgorithm);
      localBCPGOutputStream.write(this.hashAlgorithm);
    }
    else if (this.version == 4)
    {
      localBCPGOutputStream.write(this.signatureType);
      localBCPGOutputStream.write(this.keyAlgorithm);
      localBCPGOutputStream.write(this.hashAlgorithm);
      ByteArrayOutputStream localByteArrayOutputStream2 = new ByteArrayOutputStream();
      for (int j = 0; j != this.hashedData.length; j++) {
        this.hashedData[j].encode(localByteArrayOutputStream2);
      }
      byte[] arrayOfByte = localByteArrayOutputStream2.toByteArray();
      localBCPGOutputStream.write(arrayOfByte.length >> 8);
      localBCPGOutputStream.write(arrayOfByte.length);
      localBCPGOutputStream.write(arrayOfByte);
      localByteArrayOutputStream2.reset();
      for (int k = 0; k != this.unhashedData.length; k++) {
        this.unhashedData[k].encode(localByteArrayOutputStream2);
      }
      arrayOfByte = localByteArrayOutputStream2.toByteArray();
      localBCPGOutputStream.write(arrayOfByte.length >> 8);
      localBCPGOutputStream.write(arrayOfByte.length);
      localBCPGOutputStream.write(arrayOfByte);
    }
    else
    {
      throw new IOException("unknown version: " + this.version);
    }
    localBCPGOutputStream.write(this.fingerPrint);
    if (this.signature != null) {
      for (int i = 0; i != this.signature.length; i++) {
        localBCPGOutputStream.writeObject(this.signature[i]);
      }
    } else {
      localBCPGOutputStream.write(this.signatureEncoding);
    }
    paramBCPGOutputStream.writePacket(2, localByteArrayOutputStream1.toByteArray(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SignaturePacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */