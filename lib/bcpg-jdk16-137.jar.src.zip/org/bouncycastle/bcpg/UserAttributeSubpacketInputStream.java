package org.bouncycastle.bcpg;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.bcpg.attr.ImageAttribute;

public class UserAttributeSubpacketInputStream
  extends InputStream
  implements UserAttributeSubpacketTags
{
  InputStream in;
  
  public UserAttributeSubpacketInputStream(InputStream paramInputStream)
  {
    this.in = paramInputStream;
  }
  
  public int available()
    throws IOException
  {
    return this.in.available();
  }
  
  public int read()
    throws IOException
  {
    return this.in.read();
  }
  
  private void readFully(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    if (paramInt2 > 0)
    {
      i = read();
      if (i < 0) {
        throw new EOFException();
      }
      paramArrayOfByte[paramInt1] = ((byte)i);
      paramInt1++;
      paramInt2--;
    }
    while (paramInt2 > 0)
    {
      i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
      if (i < 0) {
        throw new EOFException();
      }
      paramInt1 += i;
      paramInt2 -= i;
    }
  }
  
  public UserAttributeSubpacket readPacket()
    throws IOException
  {
    int i = read();
    int j = 0;
    if (i < 0) {
      return null;
    }
    if (i < 192) {
      j = i;
    } else if (i < 223) {
      j = (i - 192 << 8) + this.in.read() + 192;
    } else if (i == 255) {
      j = this.in.read() << 24 | this.in.read() << 16 | this.in.read() << 8 | this.in.read();
    }
    int k = this.in.read();
    if (k < 0) {
      throw new EOFException("unexpected EOF reading user attribute sub packet");
    }
    byte[] arrayOfByte = new byte[j - 1];
    readFully(arrayOfByte, 0, arrayOfByte.length);
    int m = k;
    switch (m)
    {
    case 1: 
      return new ImageAttribute(arrayOfByte);
    }
    return new UserAttributeSubpacket(m, arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\UserAttributeSubpacketInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */