package org.bouncycastle.bcpg;

import java.io.IOException;
import java.util.Date;

public class PublicSubkeyPacket
  extends PublicKeyPacket
{
  PublicSubkeyPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
  }
  
  public PublicSubkeyPacket(int paramInt, Date paramDate, BCPGKey paramBCPGKey)
  {
    super(paramInt, paramDate, paramBCPGKey);
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(14, getEncodedContents(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\PublicSubkeyPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */