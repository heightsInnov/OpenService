package org.bouncycastle.bcpg;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import org.bouncycastle.bcpg.sig.Exportable;
import org.bouncycastle.bcpg.sig.IssuerKeyID;
import org.bouncycastle.bcpg.sig.KeyExpirationTime;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.bcpg.sig.NotationData;
import org.bouncycastle.bcpg.sig.PreferredAlgorithms;
import org.bouncycastle.bcpg.sig.PrimaryUserID;
import org.bouncycastle.bcpg.sig.Revocable;
import org.bouncycastle.bcpg.sig.SignatureCreationTime;
import org.bouncycastle.bcpg.sig.SignatureExpirationTime;
import org.bouncycastle.bcpg.sig.SignerUserID;
import org.bouncycastle.bcpg.sig.TrustSignature;

public class SignatureSubpacketInputStream
  extends InputStream
  implements SignatureSubpacketTags
{
  InputStream in;
  
  public SignatureSubpacketInputStream(InputStream paramInputStream)
  {
    this.in = paramInputStream;
  }
  
  public int available()
    throws IOException
  {
    return this.in.available();
  }
  
  public int read()
    throws IOException
  {
    return this.in.read();
  }
  
  private void readFully(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    if (paramInt2 > 0)
    {
      i = read();
      if (i < 0) {
        throw new EOFException();
      }
      paramArrayOfByte[paramInt1] = ((byte)i);
      paramInt1++;
      paramInt2--;
    }
    while (paramInt2 > 0)
    {
      i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
      if (i < 0) {
        throw new EOFException();
      }
      paramInt1 += i;
      paramInt2 -= i;
    }
  }
  
  public SignatureSubpacket readPacket()
    throws IOException
  {
    int i = read();
    int j = 0;
    if (i < 0) {
      return null;
    }
    if (i < 192) {
      j = i;
    } else if (i < 223) {
      j = (i - 192 << 8) + this.in.read() + 192;
    } else if (i == 255) {
      j = this.in.read() << 24 | this.in.read() << 16 | this.in.read() << 8 | this.in.read();
    }
    int k = this.in.read();
    if (k < 0) {
      throw new EOFException("unexpected EOF reading signature sub packet");
    }
    byte[] arrayOfByte = new byte[j - 1];
    readFully(arrayOfByte, 0, arrayOfByte.length);
    boolean bool = (k & 0x80) != 0;
    int m = k & 0x7F;
    switch (m)
    {
    case 2: 
      return new SignatureCreationTime(bool, arrayOfByte);
    case 9: 
      return new KeyExpirationTime(bool, arrayOfByte);
    case 3: 
      return new SignatureExpirationTime(bool, arrayOfByte);
    case 7: 
      return new Revocable(bool, arrayOfByte);
    case 4: 
      return new Exportable(bool, arrayOfByte);
    case 16: 
      return new IssuerKeyID(bool, arrayOfByte);
    case 5: 
      return new TrustSignature(bool, arrayOfByte);
    case 11: 
    case 21: 
    case 22: 
      return new PreferredAlgorithms(m, bool, arrayOfByte);
    case 27: 
      return new KeyFlags(bool, arrayOfByte);
    case 25: 
      return new PrimaryUserID(bool, arrayOfByte);
    case 28: 
      return new SignerUserID(bool, arrayOfByte);
    case 20: 
      return new NotationData(bool, arrayOfByte);
    }
    return new SignatureSubpacket(m, bool, arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SignatureSubpacketInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */