package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class DSAPublicBCPGKey
  extends BCPGObject
  implements BCPGKey
{
  MPInteger p;
  MPInteger q;
  MPInteger g;
  MPInteger y;
  
  public DSAPublicBCPGKey(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.p = new MPInteger(paramBCPGInputStream);
    this.q = new MPInteger(paramBCPGInputStream);
    this.g = new MPInteger(paramBCPGInputStream);
    this.y = new MPInteger(paramBCPGInputStream);
  }
  
  public DSAPublicBCPGKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4)
  {
    this.p = new MPInteger(paramBigInteger1);
    this.q = new MPInteger(paramBigInteger2);
    this.g = new MPInteger(paramBigInteger3);
    this.y = new MPInteger(paramBigInteger4);
  }
  
  public String getFormat()
  {
    return "PGP";
  }
  
  public byte[] getEncoded()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      localBCPGOutputStream.writeObject(this);
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writeObject(this.p);
    paramBCPGOutputStream.writeObject(this.q);
    paramBCPGOutputStream.writeObject(this.g);
    paramBCPGOutputStream.writeObject(this.y);
  }
  
  public BigInteger getG()
  {
    return this.g.getValue();
  }
  
  public BigInteger getP()
  {
    return this.p.getValue();
  }
  
  public BigInteger getQ()
  {
    return this.q.getValue();
  }
  
  public BigInteger getY()
  {
    return this.y.getValue();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\DSAPublicBCPGKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */