package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class KeyFlags
  extends SignatureSubpacket
{
  private static final byte[] intToByteArray(int paramInt)
  {
    byte[] arrayOfByte = new byte[1];
    arrayOfByte[0] = ((byte)paramInt);
    return arrayOfByte;
  }
  
  public KeyFlags(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(27, paramBoolean, paramArrayOfByte);
  }
  
  public KeyFlags(boolean paramBoolean, int paramInt)
  {
    super(27, paramBoolean, intToByteArray(paramInt));
  }
  
  public int getFlags()
  {
    return this.data[0] & 0xFF;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\KeyFlags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */