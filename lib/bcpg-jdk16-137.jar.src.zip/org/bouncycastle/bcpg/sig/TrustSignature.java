package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class TrustSignature
  extends SignatureSubpacket
{
  private static final byte[] intToByteArray(int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)paramInt1);
    arrayOfByte[1] = ((byte)paramInt2);
    return arrayOfByte;
  }
  
  public TrustSignature(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(5, paramBoolean, paramArrayOfByte);
  }
  
  public TrustSignature(boolean paramBoolean, int paramInt1, int paramInt2)
  {
    super(5, paramBoolean, intToByteArray(paramInt1, paramInt2));
  }
  
  public int getDepth()
  {
    return this.data[0] & 0xFF;
  }
  
  public int getTrustAmount()
  {
    return this.data[1] & 0xFF;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\TrustSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */