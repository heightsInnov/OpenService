package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class SignerUserID
  extends SignatureSubpacket
{
  private static byte[] userIDToBytes(String paramString)
  {
    byte[] arrayOfByte = new byte[paramString.length()];
    for (int i = 0; i != paramString.length(); i++) {
      arrayOfByte[i] = ((byte)paramString.charAt(i));
    }
    return arrayOfByte;
  }
  
  public SignerUserID(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(28, paramBoolean, paramArrayOfByte);
  }
  
  public SignerUserID(boolean paramBoolean, String paramString)
  {
    super(28, paramBoolean, userIDToBytes(paramString));
  }
  
  public String getID()
  {
    char[] arrayOfChar = new char[this.data.length];
    for (int i = 0; i != arrayOfChar.length; i++) {
      arrayOfChar[i] = ((char)(this.data[i] & 0xFF));
    }
    return new String(arrayOfChar);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\SignerUserID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */