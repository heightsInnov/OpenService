package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class PreferredAlgorithms
  extends SignatureSubpacket
{
  private static final byte[] intToByteArray(int[] paramArrayOfInt)
  {
    byte[] arrayOfByte = new byte[paramArrayOfInt.length];
    for (int i = 0; i != paramArrayOfInt.length; i++) {
      arrayOfByte[i] = ((byte)paramArrayOfInt[i]);
    }
    return arrayOfByte;
  }
  
  public PreferredAlgorithms(int paramInt, boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(paramInt, paramBoolean, paramArrayOfByte);
  }
  
  public PreferredAlgorithms(int paramInt, boolean paramBoolean, int[] paramArrayOfInt)
  {
    super(paramInt, paramBoolean, intToByteArray(paramArrayOfInt));
  }
  
  /**
   * @deprecated
   */
  public int[] getPreferrences()
  {
    return getPreferences();
  }
  
  public int[] getPreferences()
  {
    int[] arrayOfInt = new int[this.data.length];
    for (int i = 0; i != arrayOfInt.length; i++) {
      arrayOfInt[i] = (this.data[i] & 0xFF);
    }
    return arrayOfInt;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\PreferredAlgorithms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */