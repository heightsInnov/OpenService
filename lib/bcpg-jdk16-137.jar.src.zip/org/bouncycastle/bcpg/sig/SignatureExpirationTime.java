package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class SignatureExpirationTime
  extends SignatureSubpacket
{
  protected static byte[] timeToBytes(long paramLong)
  {
    byte[] arrayOfByte = new byte[4];
    arrayOfByte[0] = ((byte)(int)(paramLong >> 24));
    arrayOfByte[1] = ((byte)(int)(paramLong >> 16));
    arrayOfByte[2] = ((byte)(int)(paramLong >> 8));
    arrayOfByte[3] = ((byte)(int)paramLong);
    return arrayOfByte;
  }
  
  public SignatureExpirationTime(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(3, paramBoolean, paramArrayOfByte);
  }
  
  public SignatureExpirationTime(boolean paramBoolean, long paramLong)
  {
    super(3, paramBoolean, timeToBytes(paramLong));
  }
  
  public long getTime()
  {
    long l = (this.data[0] & 0xFF) << 24 | (this.data[1] & 0xFF) << 16 | (this.data[2] & 0xFF) << 8 | this.data[3] & 0xFF;
    return l;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\SignatureExpirationTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */