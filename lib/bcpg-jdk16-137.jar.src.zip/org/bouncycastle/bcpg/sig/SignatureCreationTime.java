package org.bouncycastle.bcpg.sig;

import java.util.Date;
import org.bouncycastle.bcpg.SignatureSubpacket;

public class SignatureCreationTime
  extends SignatureSubpacket
{
  protected static byte[] timeToBytes(Date paramDate)
  {
    byte[] arrayOfByte = new byte[4];
    long l = paramDate.getTime() / 1000L;
    arrayOfByte[0] = ((byte)(int)(l >> 24));
    arrayOfByte[1] = ((byte)(int)(l >> 16));
    arrayOfByte[2] = ((byte)(int)(l >> 8));
    arrayOfByte[3] = ((byte)(int)l);
    return arrayOfByte;
  }
  
  public SignatureCreationTime(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(2, paramBoolean, paramArrayOfByte);
  }
  
  public SignatureCreationTime(boolean paramBoolean, Date paramDate)
  {
    super(2, paramBoolean, timeToBytes(paramDate));
  }
  
  public Date getTime()
  {
    long l = (this.data[0] & 0xFF) << 24 | (this.data[1] & 0xFF) << 16 | (this.data[2] & 0xFF) << 8 | this.data[3] & 0xFF;
    return new Date(l * 1000L);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\SignatureCreationTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */