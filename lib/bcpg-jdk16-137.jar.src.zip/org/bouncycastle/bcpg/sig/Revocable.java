package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class Revocable
  extends SignatureSubpacket
{
  private static final byte[] booleanToByteArray(boolean paramBoolean)
  {
    byte[] arrayOfByte = new byte[1];
    if (paramBoolean)
    {
      arrayOfByte[0] = 1;
      return arrayOfByte;
    }
    return arrayOfByte;
  }
  
  public Revocable(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(7, paramBoolean, paramArrayOfByte);
  }
  
  public Revocable(boolean paramBoolean1, boolean paramBoolean2)
  {
    super(7, paramBoolean1, booleanToByteArray(paramBoolean2));
  }
  
  public boolean isRevocable()
  {
    return this.data[0] != 0;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\Revocable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */