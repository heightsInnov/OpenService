package org.bouncycastle.bcpg.sig;

import org.bouncycastle.bcpg.SignatureSubpacket;

public class IssuerKeyID
  extends SignatureSubpacket
{
  protected static byte[] keyIDToBytes(long paramLong)
  {
    byte[] arrayOfByte = new byte[8];
    arrayOfByte[0] = ((byte)(int)(paramLong >> 56));
    arrayOfByte[1] = ((byte)(int)(paramLong >> 48));
    arrayOfByte[2] = ((byte)(int)(paramLong >> 40));
    arrayOfByte[3] = ((byte)(int)(paramLong >> 32));
    arrayOfByte[4] = ((byte)(int)(paramLong >> 24));
    arrayOfByte[5] = ((byte)(int)(paramLong >> 16));
    arrayOfByte[6] = ((byte)(int)(paramLong >> 8));
    arrayOfByte[7] = ((byte)(int)paramLong);
    return arrayOfByte;
  }
  
  public IssuerKeyID(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(16, paramBoolean, paramArrayOfByte);
  }
  
  public IssuerKeyID(boolean paramBoolean, long paramLong)
  {
    super(16, paramBoolean, keyIDToBytes(paramLong));
  }
  
  public long getKeyID()
  {
    long l = (this.data[0] & 0xFF) << 56 | (this.data[1] & 0xFF) << 48 | (this.data[2] & 0xFF) << 40 | (this.data[3] & 0xFF) << 32 | (this.data[4] & 0xFF) << 24 | (this.data[5] & 0xFF) << 16 | (this.data[6] & 0xFF) << 8 | this.data[7] & 0xFF;
    return l;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\IssuerKeyID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */