package org.bouncycastle.bcpg.sig;

import java.io.ByteArrayOutputStream;
import org.bouncycastle.bcpg.SignatureSubpacket;
import org.bouncycastle.util.Strings;

public class NotationData
  extends SignatureSubpacket
{
  public static final int HEADER_FLAG_LENGTH = 4;
  public static final int HEADER_NAME_LENGTH = 2;
  public static final int HEADER_VALUE_LENGTH = 2;
  
  public NotationData(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(20, paramBoolean, paramArrayOfByte);
  }
  
  public NotationData(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2)
  {
    super(20, paramBoolean1, createData(paramBoolean2, paramString1, paramString2));
  }
  
  private static byte[] createData(boolean paramBoolean, String paramString1, String paramString2)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(paramBoolean ? 128 : 0);
    localByteArrayOutputStream.write(0);
    localByteArrayOutputStream.write(0);
    localByteArrayOutputStream.write(0);
    byte[] arrayOfByte2 = null;
    byte[] arrayOfByte1 = Strings.toUTF8ByteArray(paramString1);
    int i = Math.min(arrayOfByte1.length, 255);
    arrayOfByte2 = Strings.toUTF8ByteArray(paramString2);
    int j = Math.min(arrayOfByte2.length, 255);
    localByteArrayOutputStream.write(i >>> 8 & 0xFF);
    localByteArrayOutputStream.write(i >>> 0 & 0xFF);
    localByteArrayOutputStream.write(j >>> 8 & 0xFF);
    localByteArrayOutputStream.write(j >>> 0 & 0xFF);
    localByteArrayOutputStream.write(arrayOfByte1, 0, i);
    localByteArrayOutputStream.write(arrayOfByte2, 0, j);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public boolean isHumanReadable()
  {
    return this.data[0] == Byte.MIN_VALUE;
  }
  
  public String getNotationName()
  {
    int i = (this.data[4] << 8) + (this.data[5] << 0);
    byte[] arrayOfByte = new byte[i];
    System.arraycopy(this.data, 8, arrayOfByte, 0, i);
    return Strings.fromUTF8ByteArray(arrayOfByte);
  }
  
  public String getNotationValue()
  {
    int i = (this.data[4] << 8) + (this.data[5] << 0);
    int j = (this.data[6] << 8) + (this.data[7] << 0);
    byte[] arrayOfByte = new byte[j];
    System.arraycopy(this.data, 8 + i, arrayOfByte, 0, j);
    return Strings.fromUTF8ByteArray(arrayOfByte);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\sig\NotationData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */