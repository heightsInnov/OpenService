package org.bouncycastle.bcpg;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;

public class ArmoredOutputStream
  extends OutputStream
{
  private static final byte[] encodingTable = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
  OutputStream out;
  int[] buf = new int[3];
  int bufPtr = 0;
  CRC24 crc = new CRC24();
  int chunkCount = 0;
  int lastb;
  boolean start = true;
  boolean clearText = false;
  boolean newLine = false;
  String nl = System.getProperty("line.separator");
  String type;
  String headerStart = "-----BEGIN PGP ";
  String headerTail = "-----";
  String footerStart = "-----END PGP ";
  String footerTail = "-----";
  String version = "BCPG v1.37";
  Hashtable headers = new Hashtable();
  
  private void encode(OutputStream paramOutputStream, int[] paramArrayOfInt, int paramInt)
    throws IOException
  {
    int i;
    int j;
    switch (paramInt)
    {
    case 0: 
      break;
    case 1: 
      i = paramArrayOfInt[0];
      paramOutputStream.write(encodingTable[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(encodingTable[(i << 4 & 0x3F)]);
      paramOutputStream.write(61);
      paramOutputStream.write(61);
      break;
    case 2: 
      i = paramArrayOfInt[0];
      j = paramArrayOfInt[1];
      paramOutputStream.write(encodingTable[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(encodingTable[((i << 4 | j >>> 4) & 0x3F)]);
      paramOutputStream.write(encodingTable[(j << 2 & 0x3F)]);
      paramOutputStream.write(61);
      break;
    case 3: 
      i = paramArrayOfInt[0];
      j = paramArrayOfInt[1];
      int k = paramArrayOfInt[2];
      paramOutputStream.write(encodingTable[(i >>> 2 & 0x3F)]);
      paramOutputStream.write(encodingTable[((i << 4 | j >>> 4) & 0x3F)]);
      paramOutputStream.write(encodingTable[((j << 2 | k >>> 6) & 0x3F)]);
      paramOutputStream.write(encodingTable[(k & 0x3F)]);
      break;
    default: 
      throw new IOException("unknown length in encode");
    }
  }
  
  public ArmoredOutputStream(OutputStream paramOutputStream)
  {
    this.out = paramOutputStream;
    if (this.nl == null) {
      this.nl = "\r\n";
    }
    resetHeaders();
  }
  
  public ArmoredOutputStream(OutputStream paramOutputStream, Hashtable paramHashtable)
  {
    this(paramOutputStream);
    Enumeration localEnumeration = paramHashtable.keys();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      this.headers.put(localObject, paramHashtable.get(localObject));
    }
  }
  
  public void setHeader(String paramString1, String paramString2)
  {
    this.headers.put(paramString1, paramString2);
  }
  
  public void resetHeaders()
  {
    this.headers.clear();
    this.headers.put("Version", this.version);
  }
  
  public void beginClearText(int paramInt)
    throws IOException
  {
    String str1;
    switch (paramInt)
    {
    case 2: 
      str1 = "SHA1";
      break;
    case 8: 
      str1 = "SHA256";
      break;
    case 9: 
      str1 = "SHA384";
      break;
    case 10: 
      str1 = "SHA512";
      break;
    case 5: 
      str1 = "MD2";
      break;
    case 1: 
      str1 = "MD5";
      break;
    case 3: 
      str1 = "RIPEMD160";
      break;
    case 4: 
    case 6: 
    case 7: 
    default: 
      throw new IOException("unknown hash algorithm tag in beginClearText: " + paramInt);
    }
    String str2 = "-----BEGIN PGP SIGNED MESSAGE-----" + this.nl;
    String str3 = "Hash: " + str1 + this.nl + this.nl;
    for (int i = 0; i != str2.length(); i++) {
      this.out.write(str2.charAt(i));
    }
    for (i = 0; i != str3.length(); i++) {
      this.out.write(str3.charAt(i));
    }
    this.clearText = true;
    this.newLine = true;
    this.lastb = 0;
  }
  
  public void endClearText()
  {
    this.clearText = false;
  }
  
  private void writeHeaderEntry(String paramString1, String paramString2)
    throws IOException
  {
    for (int i = 0; i != paramString1.length(); i++) {
      this.out.write(paramString1.charAt(i));
    }
    this.out.write(58);
    this.out.write(32);
    for (i = 0; i != paramString2.length(); i++) {
      this.out.write(paramString2.charAt(i));
    }
    for (i = 0; i != this.nl.length(); i++) {
      this.out.write(this.nl.charAt(i));
    }
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (this.clearText)
    {
      this.out.write(paramInt);
      if (this.newLine)
      {
        if ((paramInt != 10) || (this.lastb != 13)) {
          this.newLine = false;
        }
        if (paramInt == 45)
        {
          this.out.write(32);
          this.out.write(45);
        }
      }
      if ((paramInt == 13) || ((paramInt == 10) && (this.lastb != 13))) {
        this.newLine = true;
      }
      this.lastb = paramInt;
      return;
    }
    int i;
    if (this.start)
    {
      i = (paramInt & 0x40) != 0 ? 1 : 0;
      int j = 0;
      if (i != 0) {
        j = paramInt & 0x3F;
      } else {
        j = (paramInt & 0x3F) >> 2;
      }
      switch (j)
      {
      case 6: 
        this.type = "PUBLIC KEY BLOCK";
        break;
      case 5: 
        this.type = "PRIVATE KEY BLOCK";
        break;
      case 2: 
        this.type = "SIGNATURE";
        break;
      case 3: 
      case 4: 
      default: 
        this.type = "MESSAGE";
      }
      for (int k = 0; k != this.headerStart.length(); k++) {
        this.out.write(this.headerStart.charAt(k));
      }
      for (k = 0; k != this.type.length(); k++) {
        this.out.write(this.type.charAt(k));
      }
      for (k = 0; k != this.headerTail.length(); k++) {
        this.out.write(this.headerTail.charAt(k));
      }
      for (k = 0; k != this.nl.length(); k++) {
        this.out.write(this.nl.charAt(k));
      }
      writeHeaderEntry("Version", (String)this.headers.get("Version"));
      Enumeration localEnumeration = this.headers.keys();
      while (localEnumeration.hasMoreElements())
      {
        String str = (String)localEnumeration.nextElement();
        if (!str.equals("Version")) {
          writeHeaderEntry(str, (String)this.headers.get(str));
        }
      }
      for (int m = 0; m != this.nl.length(); m++) {
        this.out.write(this.nl.charAt(m));
      }
      this.start = false;
    }
    if (this.bufPtr == 3)
    {
      encode(this.out, this.buf, this.bufPtr);
      this.bufPtr = 0;
      if ((++this.chunkCount & 0xF) == 0) {
        for (i = 0; i != this.nl.length(); i++) {
          this.out.write(this.nl.charAt(i));
        }
      }
    }
    this.crc.update(paramInt);
    this.buf[(this.bufPtr++)] = (paramInt & 0xFF);
  }
  
  public void flush()
    throws IOException
  {}
  
  public void close()
    throws IOException
  {
    if (this.type != null)
    {
      encode(this.out, this.buf, this.bufPtr);
      for (int i = 0; i != this.nl.length(); i++) {
        this.out.write(this.nl.charAt(i));
      }
      this.out.write(61);
      i = this.crc.getValue();
      this.buf[0] = (i >> 16 & 0xFF);
      this.buf[1] = (i >> 8 & 0xFF);
      this.buf[2] = (i & 0xFF);
      encode(this.out, this.buf, 3);
      for (int j = 0; j != this.nl.length(); j++) {
        this.out.write(this.nl.charAt(j));
      }
      for (j = 0; j != this.footerStart.length(); j++) {
        this.out.write(this.footerStart.charAt(j));
      }
      for (j = 0; j != this.type.length(); j++) {
        this.out.write(this.type.charAt(j));
      }
      for (j = 0; j != this.footerTail.length(); j++) {
        this.out.write(this.footerTail.charAt(j));
      }
      for (j = 0; j != this.nl.length(); j++) {
        this.out.write(this.nl.charAt(j));
      }
      this.out.flush();
      this.type = null;
      this.start = true;
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\ArmoredOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */