package org.bouncycastle.bcpg;

import java.io.IOException;

public class SymmetricEncIntegrityPacket
  extends InputStreamPacket
{
  int version;
  
  SymmetricEncIntegrityPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
    this.version = paramBCPGInputStream.read();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SymmetricEncIntegrityPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */