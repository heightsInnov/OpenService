package org.bouncycastle.bcpg;

public class InputStreamPacket
  extends Packet
{
  private BCPGInputStream in;
  
  public InputStreamPacket(BCPGInputStream paramBCPGInputStream)
  {
    this.in = paramBCPGInputStream;
  }
  
  public BCPGInputStream getInputStream()
  {
    return this.in;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\InputStreamPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */