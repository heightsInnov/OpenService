package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ExperimentalPacket
  extends ContainedPacket
  implements PublicKeyAlgorithmTags
{
  private int tag;
  private byte[] contents;
  
  ExperimentalPacket(int paramInt, BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.tag = paramInt;
    if (paramBCPGInputStream.available() != 0)
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramBCPGInputStream.available());
      int i;
      while ((i = paramBCPGInputStream.read()) >= 0) {
        localByteArrayOutputStream.write(i);
      }
      this.contents = localByteArrayOutputStream.toByteArray();
    }
    else
    {
      this.contents = new byte[0];
    }
  }
  
  public int getTag()
  {
    return this.tag;
  }
  
  public byte[] getContents()
  {
    byte[] arrayOfByte = new byte[this.contents.length];
    System.arraycopy(this.contents, 0, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(this.tag, this.contents, true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\ExperimentalPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */