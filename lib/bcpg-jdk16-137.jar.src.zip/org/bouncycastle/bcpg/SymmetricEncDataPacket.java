package org.bouncycastle.bcpg;

public class SymmetricEncDataPacket
  extends InputStreamPacket
{
  public SymmetricEncDataPacket(BCPGInputStream paramBCPGInputStream)
  {
    super(paramBCPGInputStream);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SymmetricEncDataPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */