package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class DSASecretBCPGKey
  extends BCPGObject
  implements BCPGKey
{
  MPInteger x;
  
  public DSASecretBCPGKey(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.x = new MPInteger(paramBCPGInputStream);
  }
  
  public DSASecretBCPGKey(BigInteger paramBigInteger)
  {
    this.x = new MPInteger(paramBigInteger);
  }
  
  public String getFormat()
  {
    return "PGP";
  }
  
  public byte[] getEncoded()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      localBCPGOutputStream.writeObject(this);
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writeObject(this.x);
  }
  
  public BigInteger getX()
  {
    return this.x.getValue();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\DSASecretBCPGKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */