package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class SecretKeyPacket
  extends ContainedPacket
  implements PublicKeyAlgorithmTags
{
  public static final int USAGE_NONE = 0;
  public static final int USAGE_CHECKSUM = 255;
  public static final int USAGE_SHA1 = 254;
  private PublicKeyPacket pubKeyPacket;
  private byte[] secKeyData;
  private int s2kUsage;
  private int encAlgorithm;
  private S2K s2k;
  private byte[] iv;
  
  SecretKeyPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.pubKeyPacket = new PublicKeyPacket(paramBCPGInputStream);
    this.s2kUsage = paramBCPGInputStream.read();
    if ((this.s2kUsage == 255) || (this.s2kUsage == 254))
    {
      this.encAlgorithm = paramBCPGInputStream.read();
      this.s2k = new S2K(paramBCPGInputStream);
    }
    else
    {
      this.encAlgorithm = this.s2kUsage;
    }
    if (((this.s2k == null) || (this.s2k.getType() != 101) || (this.s2k.getProtectionMode() != 1)) && (this.s2kUsage != 0))
    {
      if (this.encAlgorithm < 7) {
        this.iv = new byte[8];
      } else {
        this.iv = new byte[16];
      }
      paramBCPGInputStream.readFully(this.iv, 0, this.iv.length);
    }
    if (paramBCPGInputStream.available() != 0)
    {
      this.secKeyData = new byte[paramBCPGInputStream.available()];
      paramBCPGInputStream.readFully(this.secKeyData);
    }
  }
  
  public SecretKeyPacket(PublicKeyPacket paramPublicKeyPacket, int paramInt, S2K paramS2K, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.pubKeyPacket = paramPublicKeyPacket;
    this.encAlgorithm = paramInt;
    if (paramInt != 0) {
      this.s2kUsage = 255;
    } else {
      this.s2kUsage = 0;
    }
    this.s2k = paramS2K;
    this.iv = paramArrayOfByte1;
    this.secKeyData = paramArrayOfByte2;
  }
  
  public SecretKeyPacket(PublicKeyPacket paramPublicKeyPacket, int paramInt1, int paramInt2, S2K paramS2K, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    this.pubKeyPacket = paramPublicKeyPacket;
    this.encAlgorithm = paramInt1;
    this.s2kUsage = paramInt2;
    this.s2k = paramS2K;
    this.iv = paramArrayOfByte1;
    this.secKeyData = paramArrayOfByte2;
  }
  
  public int getEncAlgorithm()
  {
    return this.encAlgorithm;
  }
  
  public int getS2KUsage()
  {
    return this.s2kUsage;
  }
  
  public byte[] getIV()
  {
    return this.iv;
  }
  
  public S2K getS2K()
  {
    return this.s2k;
  }
  
  public PublicKeyPacket getPublicKeyPacket()
  {
    return this.pubKeyPacket;
  }
  
  public byte[] getSecretKeyData()
  {
    return this.secKeyData;
  }
  
  public byte[] getEncodedContents()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.write(this.pubKeyPacket.getEncodedContents());
    localBCPGOutputStream.write(this.s2kUsage);
    if ((this.s2kUsage == 255) || (this.s2kUsage == 254))
    {
      localBCPGOutputStream.write(this.encAlgorithm);
      localBCPGOutputStream.writeObject(this.s2k);
    }
    if (this.iv != null) {
      localBCPGOutputStream.write(this.iv);
    }
    if (this.secKeyData != null) {
      localBCPGOutputStream.write(this.secKeyData);
    }
    return localByteArrayOutputStream.toByteArray();
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(5, getEncodedContents(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\SecretKeyPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */