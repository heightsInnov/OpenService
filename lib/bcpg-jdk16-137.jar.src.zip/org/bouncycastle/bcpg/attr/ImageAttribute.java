package org.bouncycastle.bcpg.attr;

import org.bouncycastle.bcpg.UserAttributeSubpacket;

public class ImageAttribute
  extends UserAttributeSubpacket
{
  private int hdrLength = (paramArrayOfByte[1] & 0xFF) << 8 | paramArrayOfByte[0] & 0xFF;
  private int version = paramArrayOfByte[2] & 0xFF;
  private int encoding = paramArrayOfByte[3] & 0xFF;
  private byte[] imageData;
  
  public ImageAttribute(byte[] paramArrayOfByte)
  {
    super(1, paramArrayOfByte);
    this.imageData = new byte[paramArrayOfByte.length - this.hdrLength];
    System.arraycopy(paramArrayOfByte, this.hdrLength, this.imageData, 0, this.imageData.length);
  }
  
  public int version()
  {
    return this.version;
  }
  
  public int getEncoding()
  {
    return this.encoding;
  }
  
  public byte[] getImageData()
  {
    return this.imageData;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\attr\ImageAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */