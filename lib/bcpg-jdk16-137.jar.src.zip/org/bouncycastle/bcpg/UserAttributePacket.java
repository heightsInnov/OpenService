package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Vector;

public class UserAttributePacket
  extends ContainedPacket
{
  private UserAttributeSubpacket[] subpackets;
  
  public UserAttributePacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    UserAttributeSubpacketInputStream localUserAttributeSubpacketInputStream = new UserAttributeSubpacketInputStream(paramBCPGInputStream);
    Vector localVector = new Vector();
    UserAttributeSubpacket localUserAttributeSubpacket;
    while ((localUserAttributeSubpacket = localUserAttributeSubpacketInputStream.readPacket()) != null) {
      localVector.addElement(localUserAttributeSubpacket);
    }
    this.subpackets = new UserAttributeSubpacket[localVector.size()];
    for (int i = 0; i != this.subpackets.length; i++) {
      this.subpackets[i] = ((UserAttributeSubpacket)localVector.elementAt(i));
    }
  }
  
  public UserAttributePacket(UserAttributeSubpacket[] paramArrayOfUserAttributeSubpacket)
  {
    this.subpackets = paramArrayOfUserAttributeSubpacket;
  }
  
  public UserAttributeSubpacket[] getSubpackets()
  {
    return this.subpackets;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    for (int i = 0; i != this.subpackets.length; i++) {
      this.subpackets[i].encode(localByteArrayOutputStream);
    }
    paramBCPGOutputStream.writePacket(17, localByteArrayOutputStream.toByteArray(), false);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\UserAttributePacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */