package org.bouncycastle.bcpg;

public abstract interface BCPGKey
{
  public abstract String getFormat();
  
  public abstract byte[] getEncoded();
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\BCPGKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */