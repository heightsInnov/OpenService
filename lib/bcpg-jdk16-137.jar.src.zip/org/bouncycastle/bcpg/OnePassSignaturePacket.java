package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class OnePassSignaturePacket
  extends ContainedPacket
{
  private int version;
  private int sigType;
  private int hashAlgorithm;
  private int keyAlgorithm;
  private long keyID;
  private int nested;
  
  OnePassSignaturePacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.version = paramBCPGInputStream.read();
    this.sigType = paramBCPGInputStream.read();
    this.hashAlgorithm = paramBCPGInputStream.read();
    this.keyAlgorithm = paramBCPGInputStream.read();
    this.keyID |= paramBCPGInputStream.read() << 56;
    this.keyID |= paramBCPGInputStream.read() << 48;
    this.keyID |= paramBCPGInputStream.read() << 40;
    this.keyID |= paramBCPGInputStream.read() << 32;
    this.keyID |= paramBCPGInputStream.read() << 24;
    this.keyID |= paramBCPGInputStream.read() << 16;
    this.keyID |= paramBCPGInputStream.read() << 8;
    this.keyID |= paramBCPGInputStream.read();
    this.nested = paramBCPGInputStream.read();
  }
  
  public OnePassSignaturePacket(int paramInt1, int paramInt2, int paramInt3, long paramLong, boolean paramBoolean)
  {
    this.version = 3;
    this.sigType = paramInt1;
    this.hashAlgorithm = paramInt2;
    this.keyAlgorithm = paramInt3;
    this.keyID = paramLong;
    this.nested = (paramBoolean ? 0 : 1);
  }
  
  public int getSignatureType()
  {
    return this.sigType;
  }
  
  public int getKeyAlgorithm()
  {
    return this.keyAlgorithm;
  }
  
  public int getHashAlgorithm()
  {
    return this.hashAlgorithm;
  }
  
  public long getKeyID()
  {
    return this.keyID;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.write(this.version);
    localBCPGOutputStream.write(this.sigType);
    localBCPGOutputStream.write(this.hashAlgorithm);
    localBCPGOutputStream.write(this.keyAlgorithm);
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 56));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 48));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 40));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 32));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 24));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 16));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 8));
    localBCPGOutputStream.write((byte)(int)this.keyID);
    localBCPGOutputStream.write(this.nested);
    paramBCPGOutputStream.writePacket(4, localByteArrayOutputStream.toByteArray(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\OnePassSignaturePacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */