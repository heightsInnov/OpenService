package org.bouncycastle.bcpg;

import java.io.IOException;
import java.io.OutputStream;

public class BCPGOutputStream
  extends OutputStream
  implements PacketTags, CompressionAlgorithmTags
{
  OutputStream out;
  private byte[] partialBuffer;
  private int partialBufferLength;
  private int partialPower;
  private int partialOffset;
  private static final int BUF_SIZE_POWER = 16;
  
  public BCPGOutputStream(OutputStream paramOutputStream)
  {
    this.out = paramOutputStream;
  }
  
  public BCPGOutputStream(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    this.out = paramOutputStream;
    writeHeader(paramInt, true, true, 0L);
  }
  
  public BCPGOutputStream(OutputStream paramOutputStream, int paramInt, long paramLong, boolean paramBoolean)
    throws IOException
  {
    this.out = paramOutputStream;
    if (paramLong > 4294967295L)
    {
      writeHeader(paramInt, false, true, 0L);
      this.partialBufferLength = 65536;
      this.partialBuffer = new byte[this.partialBufferLength];
      this.partialOffset = 0;
    }
    else
    {
      writeHeader(paramInt, paramBoolean, false, paramLong);
    }
  }
  
  public BCPGOutputStream(OutputStream paramOutputStream, int paramInt, long paramLong)
    throws IOException
  {
    this.out = paramOutputStream;
    writeHeader(paramInt, false, false, paramLong);
  }
  
  public BCPGOutputStream(OutputStream paramOutputStream, int paramInt, byte[] paramArrayOfByte)
    throws IOException
  {
    this.out = paramOutputStream;
    writeHeader(paramInt, false, true, 0L);
    this.partialBuffer = paramArrayOfByte;
    int i = this.partialBuffer.length;
    for (this.partialPower = 0; i != 1; this.partialPower += 1) {
      i >>>= 1;
    }
    if (this.partialPower > 30) {
      throw new IOException("Buffer cannot be greater than 2^30 in length.");
    }
    this.partialBufferLength = (1 << this.partialPower);
    this.partialOffset = 0;
  }
  
  private void writeNewPacketLength(long paramLong)
    throws IOException
  {
    if (paramLong < 192L)
    {
      this.out.write((byte)(int)paramLong);
    }
    else if (paramLong <= 8383L)
    {
      paramLong -= 192L;
      this.out.write((byte)(int)((paramLong >> 8 & 0xFF) + 192L));
      this.out.write((byte)(int)paramLong);
    }
    else
    {
      this.out.write(255);
      this.out.write((byte)(int)(paramLong >> 24));
      this.out.write((byte)(int)(paramLong >> 16));
      this.out.write((byte)(int)(paramLong >> 8));
      this.out.write((byte)(int)paramLong);
    }
  }
  
  private void writeHeader(int paramInt, boolean paramBoolean1, boolean paramBoolean2, long paramLong)
    throws IOException
  {
    int i = 128;
    if (this.partialBuffer != null)
    {
      partialFlush(true);
      this.partialBuffer = null;
    }
    if (paramBoolean1)
    {
      i |= paramInt << 2;
      if (paramBoolean2)
      {
        write(i | 0x3);
      }
      else if (paramLong <= 255L)
      {
        write(i);
        write((byte)(int)paramLong);
      }
      else if (paramLong <= 65535L)
      {
        write(i | 0x1);
        write((byte)(int)(paramLong >> 8));
        write((byte)(int)paramLong);
      }
      else
      {
        write(i | 0x2);
        write((byte)(int)(paramLong >> 24));
        write((byte)(int)(paramLong >> 16));
        write((byte)(int)(paramLong >> 8));
        write((byte)(int)paramLong);
      }
    }
    else
    {
      i |= 0x40 | paramInt;
      write(i);
      if (paramBoolean2) {
        this.partialOffset = 0;
      } else {
        writeNewPacketLength(paramLong);
      }
    }
  }
  
  private void partialFlush(boolean paramBoolean)
    throws IOException
  {
    if (paramBoolean)
    {
      writeNewPacketLength(this.partialOffset);
      this.out.write(this.partialBuffer, 0, this.partialOffset);
    }
    else
    {
      this.out.write(0xE0 | this.partialPower);
      this.out.write(this.partialBuffer, 0, this.partialBufferLength);
    }
    this.partialOffset = 0;
  }
  
  private void writePartial(byte paramByte)
    throws IOException
  {
    if (this.partialOffset == this.partialBufferLength) {
      partialFlush(false);
    }
    this.partialBuffer[(this.partialOffset++)] = paramByte;
  }
  
  private void writePartial(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (this.partialOffset == this.partialBufferLength) {
      partialFlush(false);
    }
    if (paramInt2 <= this.partialBufferLength - this.partialOffset)
    {
      System.arraycopy(paramArrayOfByte, paramInt1, this.partialBuffer, this.partialOffset, paramInt2);
      this.partialOffset += paramInt2;
    }
    else
    {
      System.arraycopy(paramArrayOfByte, paramInt1, this.partialBuffer, this.partialOffset, this.partialBufferLength - this.partialOffset);
      paramInt1 += this.partialBufferLength - this.partialOffset;
      paramInt2 -= this.partialBufferLength - this.partialOffset;
      partialFlush(false);
      while (paramInt2 > this.partialBufferLength)
      {
        System.arraycopy(paramArrayOfByte, paramInt1, this.partialBuffer, 0, this.partialBufferLength);
        paramInt1 += this.partialBufferLength;
        paramInt2 -= this.partialBufferLength;
        partialFlush(false);
      }
      System.arraycopy(paramArrayOfByte, paramInt1, this.partialBuffer, 0, paramInt2);
      this.partialOffset += paramInt2;
    }
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (this.partialBuffer != null) {
      writePartial((byte)paramInt);
    } else {
      this.out.write(paramInt);
    }
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (this.partialBuffer != null) {
      writePartial(paramArrayOfByte, paramInt1, paramInt2);
    } else {
      this.out.write(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
  
  public void writePacket(ContainedPacket paramContainedPacket)
    throws IOException
  {
    paramContainedPacket.encode(this);
  }
  
  void writePacket(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean)
    throws IOException
  {
    writeHeader(paramInt, paramBoolean, false, paramArrayOfByte.length);
    write(paramArrayOfByte);
  }
  
  public void writeObject(BCPGObject paramBCPGObject)
    throws IOException
  {
    paramBCPGObject.encode(this);
  }
  
  public void flush()
    throws IOException
  {
    this.out.flush();
  }
  
  public void finish()
    throws IOException
  {
    if (this.partialBuffer != null)
    {
      partialFlush(true);
      this.partialBuffer = null;
    }
  }
  
  public void close()
    throws IOException
  {
    finish();
    this.out.flush();
    this.out.close();
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\BCPGOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */