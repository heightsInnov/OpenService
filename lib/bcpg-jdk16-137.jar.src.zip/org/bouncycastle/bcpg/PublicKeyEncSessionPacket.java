package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class PublicKeyEncSessionPacket
  extends ContainedPacket
  implements PublicKeyAlgorithmTags
{
  private int version;
  private long keyID;
  private int algorithm;
  private BigInteger[] data;
  
  PublicKeyEncSessionPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.version = paramBCPGInputStream.read();
    this.keyID |= paramBCPGInputStream.read() << 56;
    this.keyID |= paramBCPGInputStream.read() << 48;
    this.keyID |= paramBCPGInputStream.read() << 40;
    this.keyID |= paramBCPGInputStream.read() << 32;
    this.keyID |= paramBCPGInputStream.read() << 24;
    this.keyID |= paramBCPGInputStream.read() << 16;
    this.keyID |= paramBCPGInputStream.read() << 8;
    this.keyID |= paramBCPGInputStream.read();
    this.algorithm = paramBCPGInputStream.read();
    switch (this.algorithm)
    {
    case 1: 
    case 2: 
      this.data = new BigInteger[1];
      this.data[0] = new MPInteger(paramBCPGInputStream).getValue();
      break;
    case 16: 
    case 20: 
      this.data = new BigInteger[2];
      this.data[0] = new MPInteger(paramBCPGInputStream).getValue();
      this.data[1] = new MPInteger(paramBCPGInputStream).getValue();
      break;
    default: 
      throw new IOException("unknown PGP public key algorithm encountered");
    }
  }
  
  public PublicKeyEncSessionPacket(long paramLong, int paramInt, BigInteger[] paramArrayOfBigInteger)
  {
    this.version = 3;
    this.keyID = paramLong;
    this.algorithm = paramInt;
    this.data = paramArrayOfBigInteger;
  }
  
  public int getVersion()
  {
    return this.version;
  }
  
  public long getKeyID()
  {
    return this.keyID;
  }
  
  public int getAlgorithm()
  {
    return this.algorithm;
  }
  
  public BigInteger[] getEncSessionKey()
  {
    return this.data;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.write(this.version);
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 56));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 48));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 40));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 32));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 24));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 16));
    localBCPGOutputStream.write((byte)(int)(this.keyID >> 8));
    localBCPGOutputStream.write((byte)(int)this.keyID);
    localBCPGOutputStream.write(this.algorithm);
    for (int i = 0; i != this.data.length; i++) {
      localBCPGOutputStream.writeObject(new MPInteger(this.data[i]));
    }
    paramBCPGOutputStream.writePacket(1, localByteArrayOutputStream.toByteArray(), true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\PublicKeyEncSessionPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */