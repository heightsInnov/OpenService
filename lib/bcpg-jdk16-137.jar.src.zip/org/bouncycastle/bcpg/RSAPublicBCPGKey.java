package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;

public class RSAPublicBCPGKey
  extends BCPGObject
  implements BCPGKey
{
  MPInteger n;
  MPInteger e;
  
  public RSAPublicBCPGKey(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    this.n = new MPInteger(paramBCPGInputStream);
    this.e = new MPInteger(paramBCPGInputStream);
  }
  
  public RSAPublicBCPGKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    this.n = new MPInteger(paramBigInteger1);
    this.e = new MPInteger(paramBigInteger2);
  }
  
  public BigInteger getPublicExponent()
  {
    return this.e.getValue();
  }
  
  public BigInteger getModulus()
  {
    return this.n.getValue();
  }
  
  public String getFormat()
  {
    return "PGP";
  }
  
  public byte[] getEncoded()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
      localBCPGOutputStream.writeObject(this);
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException) {}
    return null;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writeObject(this.n);
    paramBCPGOutputStream.writeObject(this.e);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\RSAPublicBCPGKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */