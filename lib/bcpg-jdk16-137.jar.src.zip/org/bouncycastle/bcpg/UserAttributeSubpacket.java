package org.bouncycastle.bcpg;

import java.io.IOException;
import java.io.OutputStream;
import org.bouncycastle.util.Arrays;

public class UserAttributeSubpacket
{
  int type;
  protected byte[] data;
  
  protected UserAttributeSubpacket(int paramInt, byte[] paramArrayOfByte)
  {
    this.type = paramInt;
    this.data = paramArrayOfByte;
  }
  
  public int getType()
  {
    return this.type;
  }
  
  public byte[] getData()
  {
    return this.data;
  }
  
  public void encode(OutputStream paramOutputStream)
    throws IOException
  {
    int i = this.data.length + 1;
    if (i < 192)
    {
      paramOutputStream.write((byte)i);
    }
    else if (i <= 8383)
    {
      i -= 192;
      paramOutputStream.write((byte)((i >> 8 & 0xFF) + 192));
      paramOutputStream.write((byte)i);
    }
    else
    {
      paramOutputStream.write(255);
      paramOutputStream.write((byte)(i >> 24));
      paramOutputStream.write((byte)(i >> 16));
      paramOutputStream.write((byte)(i >> 8));
      paramOutputStream.write((byte)i);
    }
    paramOutputStream.write(this.type);
    paramOutputStream.write(this.data);
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof UserAttributeSubpacket)) {
      return false;
    }
    UserAttributeSubpacket localUserAttributeSubpacket = (UserAttributeSubpacket)paramObject;
    return (this.type == localUserAttributeSubpacket.type) && (Arrays.areEqual(this.data, localUserAttributeSubpacket.data));
  }
  
  public int hashCode()
  {
    return this.type ^ Arrays.hashCode(this.data);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\UserAttributeSubpacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */