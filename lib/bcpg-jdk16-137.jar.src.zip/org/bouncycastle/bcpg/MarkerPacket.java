package org.bouncycastle.bcpg;

import java.io.IOException;

public class MarkerPacket
  extends ContainedPacket
{
  byte[] marker = { 80, 71, 80 };
  
  public MarkerPacket(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    paramBCPGInputStream.readFully(this.marker);
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.writePacket(10, this.marker, true);
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\MarkerPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */