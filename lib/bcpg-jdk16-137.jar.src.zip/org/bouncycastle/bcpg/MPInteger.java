package org.bouncycastle.bcpg;

import java.io.IOException;
import java.math.BigInteger;

public class MPInteger
  extends BCPGObject
{
  BigInteger value = null;
  
  public MPInteger(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    int i = paramBCPGInputStream.read() << 8 | paramBCPGInputStream.read();
    byte[] arrayOfByte = new byte[(i + 7) / 8];
    paramBCPGInputStream.readFully(arrayOfByte);
    this.value = new BigInteger(1, arrayOfByte);
  }
  
  public MPInteger(BigInteger paramBigInteger)
  {
    if ((paramBigInteger == null) || (paramBigInteger.signum() < 0)) {
      throw new IllegalArgumentException("value must not be null, or negative");
    }
    this.value = paramBigInteger;
  }
  
  public BigInteger getValue()
  {
    return this.value;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    int i = this.value.bitLength();
    paramBCPGOutputStream.write(i >> 8);
    paramBCPGOutputStream.write(i);
    byte[] arrayOfByte = this.value.toByteArray();
    if (arrayOfByte[0] == 0) {
      paramBCPGOutputStream.write(arrayOfByte, 1, arrayOfByte.length - 1);
    } else {
      paramBCPGOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\MPInteger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */