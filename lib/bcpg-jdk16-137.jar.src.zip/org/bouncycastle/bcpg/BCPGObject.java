package org.bouncycastle.bcpg;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public abstract class BCPGObject
{
  public byte[] getEncoded()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BCPGOutputStream localBCPGOutputStream = new BCPGOutputStream(localByteArrayOutputStream);
    localBCPGOutputStream.writeObject(this);
    return localByteArrayOutputStream.toByteArray();
  }
  
  public abstract void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\BCPGObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */