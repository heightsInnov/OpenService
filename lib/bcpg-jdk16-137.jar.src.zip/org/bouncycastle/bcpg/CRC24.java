package org.bouncycastle.bcpg;

public class CRC24
{
  private static final int CRC24_INIT = 11994318;
  private static final int CRC24_POLY = 25578747;
  private int crc = 11994318;
  
  public void update(int paramInt)
  {
    this.crc ^= paramInt << 16;
    for (int i = 0; i < 8; i++)
    {
      this.crc <<= 1;
      if ((this.crc & 0x1000000) != 0) {
        this.crc ^= 0x1864CFB;
      }
    }
  }
  
  public int getValue()
  {
    return this.crc;
  }
  
  public void reset()
  {
    this.crc = 11994318;
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\CRC24.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */