package org.bouncycastle.bcpg;

import java.io.IOException;

public abstract class OutputStreamPacket
{
  protected BCPGOutputStream out;
  
  public OutputStreamPacket(BCPGOutputStream paramBCPGOutputStream)
  {
    this.out = paramBCPGOutputStream;
  }
  
  public abstract BCPGOutputStream open()
    throws IOException;
  
  public abstract void close()
    throws IOException;
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\OutputStreamPacket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */