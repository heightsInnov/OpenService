package org.bouncycastle.bcpg;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public class S2K
  extends BCPGObject
{
  private static final int EXPBIAS = 6;
  public static final int SIMPLE = 0;
  public static final int SALTED = 1;
  public static final int SALTED_AND_ITERATED = 3;
  public static final int GNU_DUMMY_S2K = 101;
  int type;
  int algorithm;
  byte[] iv;
  int itCount = -1;
  int protectionMode = -1;
  
  S2K(InputStream paramInputStream)
    throws IOException
  {
    DataInputStream localDataInputStream = new DataInputStream(paramInputStream);
    this.type = localDataInputStream.read();
    this.algorithm = localDataInputStream.read();
    if (this.type != 101)
    {
      if (this.type != 0)
      {
        this.iv = new byte[8];
        localDataInputStream.readFully(this.iv, 0, this.iv.length);
      }
      if (this.type == 3) {
        this.itCount = localDataInputStream.read();
      }
    }
    else
    {
      localDataInputStream.read();
      localDataInputStream.read();
      localDataInputStream.read();
      this.protectionMode = localDataInputStream.read();
    }
  }
  
  public S2K(int paramInt)
  {
    this.type = 0;
    this.algorithm = paramInt;
  }
  
  public S2K(int paramInt, byte[] paramArrayOfByte)
  {
    this.type = 1;
    this.algorithm = paramInt;
    this.iv = paramArrayOfByte;
  }
  
  public S2K(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    this.type = 3;
    this.algorithm = paramInt1;
    this.iv = paramArrayOfByte;
    this.itCount = paramInt2;
  }
  
  public int getType()
  {
    return this.type;
  }
  
  public int getHashAlgorithm()
  {
    return this.algorithm;
  }
  
  public byte[] getIV()
  {
    return this.iv;
  }
  
  public long getIterationCount()
  {
    return 16 + (this.itCount & 0xF) << (this.itCount >> 4) + 6;
  }
  
  public int getProtectionMode()
  {
    return this.protectionMode;
  }
  
  public void encode(BCPGOutputStream paramBCPGOutputStream)
    throws IOException
  {
    paramBCPGOutputStream.write(this.type);
    paramBCPGOutputStream.write(this.algorithm);
    if (this.type != 101)
    {
      if (this.type != 0) {
        paramBCPGOutputStream.write(this.iv);
      }
      if (this.type == 3) {
        paramBCPGOutputStream.write(this.itCount);
      }
    }
    else
    {
      paramBCPGOutputStream.write(71);
      paramBCPGOutputStream.write(78);
      paramBCPGOutputStream.write(85);
      paramBCPGOutputStream.write(this.protectionMode);
    }
  }
}


/* Location:              C:\ProjectsJava\New folder\AccountFlexServiceFcubs.war!\WEB-INF\lib\bcpg-jdk16-137.jar!\org\bouncycastle\bcpg\S2K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */